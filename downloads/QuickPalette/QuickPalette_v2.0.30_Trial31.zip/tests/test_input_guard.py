"""Win32 API simulations for InputGuard; no actual Windows focus/paste is performed."""
import ctypes
from ctypes import wintypes
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import main as qp


class FakeGUIThreadInfo(ctypes.Structure):
    _fields_ = [('cbSize', wintypes.DWORD), ('flags', wintypes.DWORD),
                ('hwndActive', wintypes.HWND), ('hwndFocus', wintypes.HWND),
                ('hwndCapture', wintypes.HWND), ('hwndMenuOwner', wintypes.HWND),
                ('hwndMoveSize', wintypes.HWND), ('hwndCaret', wintypes.HWND),
                ('rcCaret', wintypes.RECT)]


class FakeUser32:
    def __init__(self, class_name='Edit', style=0, enabled=True, readonly=False):
        self.class_name = class_name
        self.style = style
        self.enabled = enabled
        self.readonly = readonly
        self.selection = (2, 8)
        self.messages = []
        self.timeout = False
        self.gui_ok = True
        self.caret_owner = 101
        self.focus = 101
        self.gui_flags = 1
        self.child = False

    def GetClassNameW(self, hwnd, buffer, size):
        buffer.value = self.class_name
        return len(self.class_name)

    def GetWindowLongW(self, hwnd, index):
        return self.style

    def IsWindowEnabled(self, hwnd):
        return self.enabled

    def IsChild(self, parent, child):
        return self.child

    def SendMessageTimeoutW(self, hwnd, message, wparam, lparam, flags, timeout, result):
        self.messages.append((hwnd, message, flags, timeout))
        if self.timeout:
            return 0
        value = 0
        if message == 2140:  # SCI_GETREADONLY
            value = int(self.readonly)
        elif message == 2143:
            value = self.selection[0]
        elif message == 2145:
            value = self.selection[1]
        elif message == 0x00B0:
            ctypes.cast(wparam, ctypes.POINTER(wintypes.DWORD)).contents.value = self.selection[0]
            ctypes.cast(lparam, ctypes.POINTER(wintypes.DWORD)).contents.value = self.selection[1]
        result._obj.value = value
        return 1

    def GetForegroundWindow(self):
        return 100

    def GetWindowTextLengthW(self, hwnd):
        return 4

    def GetWindowTextW(self, hwnd, buffer, size):
        buffer.value = 'Test'
        return 4

    def GetWindowThreadProcessId(self, hwnd, pid):
        pid._obj.value = 10
        return 20

    def GetGUIThreadInfo(self, thread, info):
        # Also fill fields on failure: failed calls must never leak stale output.
        info._obj.hwndFocus = self.focus
        info._obj.hwndCaret = self.caret_owner
        info._obj.flags = self.gui_flags
        info._obj.rcCaret = wintypes.RECT(10, 20, 12, 40)
        return self.gui_ok

    def ClientToScreen(self, hwnd, point):
        point._obj.x += 100
        point._obj.y += 100
        return True


class InputGuardTests(unittest.TestCase):
    def setUp(self):
        self.api = FakeUser32()
        self.patchers = [patch.object(qp, 'sys', SimpleNamespace(platform='win32')),
                         patch.object(qp, 'user32', self.api, create=True)]
        for p in self.patchers:
            p.start()
            self.addCleanup(p.stop)

    def target(self, caret=True, selected=True, focus=101):
        return qp.TargetInfo(hwnd=100, exe='editor.exe', focus_hwnd=focus,
                             caret=qp.QRect(5, 5, 2, 20) if caret else None,
                             selection_kind='edit' if selected else '',
                             selection_start=2 if selected else None,
                             selection_end=8 if selected else None)

    def test_readonly_native_edits_reject_caret_and_selection(self):
        self.api.style = 0x0800
        for cls in ('Edit', 'RichEdit20W', 'RICHEDIT50W', 'WindowsForms10.EDIT.app.0.x', 'TMemo'):
            self.api.class_name = cls
            with self.subTest(cls=cls):
                self.assertEqual(qp.input_focus_state(self.target())[0], qp.INPUT_STATE_NOT_INPUT)

    def test_non_input_controls_reject_caret_and_selection(self):
        for cls in ('Button', 'Static', 'SysListView32', 'SysTreeView32', 'ListBox',
                    'ComboBox', 'ToolbarWindow32', 'SysTabControl32'):
            self.api.class_name = cls
            with self.subTest(cls=cls):
                self.assertEqual(qp.input_focus_state(self.target())[0], qp.INPUT_STATE_NOT_INPUT)

    def test_enabled_writable_native_edit_remains_input_with_or_without_selection(self):
        for caret, selected in ((True, False), (False, True), (False, False)):
            with self.subTest(caret=caret, selected=selected):
                self.assertEqual(qp.input_focus_state(self.target(caret, selected))[0], qp.INPUT_STATE_INPUT)

    def test_disabled_edit_is_not_input(self):
        self.api.enabled = False
        self.assertEqual(qp.input_focus_state(self.target())[0], qp.INPUT_STATE_NOT_INPUT)

    def test_scintilla_readonly_is_checked_before_selection(self):
        self.api.class_name = 'Scintilla'
        target = self.target()
        target.selection_kind = 'scintilla'
        self.api.readonly = True
        self.assertEqual(qp.input_focus_state(target)[0], qp.INPUT_STATE_NOT_INPUT)
        self.api.readonly = False
        self.assertEqual(qp.input_focus_state(target)[0], qp.INPUT_STATE_INPUT)
        self.api.timeout = True
        self.assertEqual(qp.input_focus_state(target)[0], qp.INPUT_STATE_UNKNOWN)

    def test_unknown_class_selection_does_not_establish_input(self):
        for cls in ('Chrome_WidgetWin_1', 'CreditDisplay', 'CustomTextBoxPanel'):
            self.api.class_name = cls
            with self.subTest(cls=cls):
                self.assertEqual(qp.input_focus_state(self.target(caret=False))[0], qp.INPUT_STATE_UNKNOWN)
                self.assertEqual(qp.focused_selection_range(101), ('', None, None))
        self.assertEqual(self.api.messages, [])

    def test_unknown_custom_control_with_current_caret_remains_supported(self):
        self.api.class_name = 'CustomEditor'
        self.assertEqual(qp.input_focus_state(self.target(selected=False))[0], qp.INPUT_STATE_INPUT)

    def test_missing_focus_cannot_be_replaced_with_old_caret_or_selection(self):
        self.assertEqual(qp.input_focus_state(self.target(focus=0))[0], qp.INPUT_STATE_UNKNOWN)

    def test_edit_selection_query_and_zero_length(self):
        self.assertEqual(qp.focused_selection_range(101), ('edit', 2, 8))
        self.api.selection = (4, 4)
        self.assertEqual(qp.focused_selection_range(101), ('', None, None))
        self.api.timeout = True
        self.assertEqual(qp.focused_selection_range(101), ('', None, None))
        self.assertTrue(all(flags == 3 and timeout == 30 for _, _, flags, timeout in self.api.messages))

    def test_scintilla_selection_queries_are_bounded(self):
        self.api.class_name = 'Scintilla'
        self.assertEqual(qp.focused_selection_range(101), ('scintilla', 2, 8))
        self.api.timeout = True
        self.assertEqual(qp.focused_selection_range(101), ('', None, None))

    def capture(self):
        with patch.object(qp, 'GUITHREADINFO', FakeGUIThreadInfo, create=True), \
             patch.object(qp, 'resolved_window_exe', return_value='browser.exe'):
            return qp.foreground_target()

    def test_foreground_accepts_current_visible_caret(self):
        self.api.class_name = 'Chrome_WidgetWin_1'
        target = self.capture()
        self.assertEqual(target.focus_hwnd, 101)
        self.assertIsNotNone(target.caret)
        self.assertEqual(qp.input_focus_state(target)[0], qp.INPUT_STATE_INPUT)

    def test_blink_off_phase_does_not_block_current_input(self):
        self.api.class_name = 'Chrome_WidgetWin_1'
        self.api.gui_flags = 0
        target = self.capture()
        self.assertIsNotNone(target.caret)
        self.assertEqual(qp.input_focus_state(target)[0], qp.INPUT_STATE_INPUT)

    def test_menu_or_window_move_cannot_be_rescued_by_old_edit_focus(self):
        for flags in (0x0002, 0x0004, 0x0008, 0x0010):
            self.api.gui_flags = flags
            with self.subTest(flags=flags):
                target = self.capture()
                self.assertIsNone(target.caret)
                self.assertFalse(target.has_selection)
                self.assertEqual(qp.input_focus_state(target)[0], qp.INPUT_STATE_NOT_INPUT)

    def test_foreground_rejects_stale_or_focusless_caret(self):
        self.api.class_name = 'Chrome_WidgetWin_1'
        for owner, flags, focus, ok in ((102, 1, 101, True),
                                      (101, 1, 0, True), (101, 1, 101, False)):
            self.api.caret_owner, self.api.gui_flags, self.api.focus, self.api.gui_ok = owner, flags, focus, ok
            with self.subTest(owner=owner, flags=flags, focus=focus, ok=ok):
                target = self.capture()
                self.assertIsNone(target.caret)
                self.assertEqual(qp.input_focus_state(target)[0], qp.INPUT_STATE_UNKNOWN)

    def test_foreground_accepts_focused_controls_child_caret(self):
        self.api.class_name = 'CustomEditor'
        self.api.caret_owner = 102
        self.api.child = True
        self.assertIsNotNone(self.capture().caret)


if __name__ == '__main__':
    unittest.main()
