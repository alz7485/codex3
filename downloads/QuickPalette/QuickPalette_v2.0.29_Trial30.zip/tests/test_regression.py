"""Synthetic-data Qt regressions. Run: QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -v"""
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import main as qp
from PySide6.QtTest import QTest


def fixture(count=20, categories=2):
    data = copy.deepcopy(qp.DEFAULT_DATA)
    template = data['profiles'][0]['categories'][0]
    data['profiles'][0]['categories'] = []
    for c in range(categories):
        category = copy.deepcopy(template)
        category.update(id=f'cat{c}', name=f'Category {c}', hotkey=('M' if c == 0 else 'N') if c < 2 else '')
        category['phrases'] = [dict(id=f'p{c}_{i}', label=f'Phrase {i}', text=f'Text {c}/{i}', hotkey='') for i in range(count)]
        data['profiles'][0]['categories'].append(category)
    return data


class QtCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = qp.QApplication.instance() or qp.QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.directory = Path(self.tmp.name)
        self.patchers = [patch.object(qp, name, self.directory / filename) for name, filename in (
            ('DATA_FILE', 'phrases.json'), ('SETTING_FILE', 'setting.json'))]
        for p in self.patchers:
            p.start()
        self.widgets = []
        self.controllers = []

    def tearDown(self):
        for c in self.controllers:
            self.app.removeNativeEventFilter(c.hotkey_filter)
            c.tray.hide()
            if c.editor is not None:
                c.editor.deleteLater()
            c.bar.deleteLater()
            c.deleteLater()
        for w in self.widgets:
            w.deleteLater()
        self.app.sendPostedEvents(None, qp.QEvent.DeferredDelete)
        for p in reversed(self.patchers):
            p.stop()
        qp.reload_themes()
        self.app.clipboard().clear()
        self.tmp.cleanup()

    def editor(self, count=20, categories=2):
        data = fixture(count, categories)
        e = qp.EditorWindow(data)
        self.widgets.append(e)
        return e

    def controller(self, count=20):
        qp.DATA_FILE.write_text(json.dumps(fixture(count)), encoding='utf-8')
        qp.SETTING_FILE.write_text(json.dumps(qp.DEFAULT_SETTINGS), encoding='utf-8')
        with patch.object(qp.QSystemTrayIcon, 'show'), patch.object(qp.Controller, 'register_global_hotkey'):
            c = qp.Controller(self.app)
        self.controllers.append(c)
        return c

    def assert_keys(self, e):
        category = e.current_category()
        expected = qp.phrase_keys_for_category(category)
        self.assertEqual([e.phrases.item(i).text().split('  ', 1)[0] for i in range(e.phrases.count())],
                         [key or '–' for key in expected])

    def test_standard_themes_and_removed_editor(self):
        self.assertEqual(len(qp._read_theme_file(qp.THEMES_DEFAULT_FILE)), 25)
        self.assertFalse(hasattr(qp, 'ThemeEditorDialog'))
        dialog = qp.SettingsDialog(dict(qp.DEFAULT_SETTINGS))
        self.widgets.append(dialog)
        self.assertEqual(dialog.theme_combo.count(), 25)
        self.assertFalse(any('テーマを編集' in b.text() for b in dialog.findChildren(qp.QPushButton)))
        for name in qp.THEMES:
            self.assertIn('QWidget#phraseBar', qp.theme_qss(name))
            self.assertFalse(qp.theme_preview_icon(name).isNull())

    def test_only_standard_themes_in_settings_and_backup(self):
        normalized, _ = qp.normalize_settings(dict(qp.DEFAULT_SETTINGS, theme='Removed Custom'))
        self.assertEqual(normalized['theme'], 'ホワイト')
        c = self.controller()
        payload = c._portable_backup_payload()
        self.assertNotIn('custom_themes', payload)
        payload['settings'] = dict(qp.DEFAULT_SETTINGS, theme='Sapphire')
        _, imported_settings = c._validate_backup_payload(payload)
        self.assertEqual(imported_settings['theme'], 'Sapphire')
        self.assertFalse(hasattr(qp, 'THEMES_CUSTOM_FILE'))
        self.assertIsNone(c.editor)

    def test_lazy_editor_hotkey_and_paste_before_open(self):
        c = self.controller(1000)
        self.assertIsNone(c.editor)
        target = qp.TargetInfo(hwnd=123, exe='editor.exe', caret=qp.QRect(5, 5, 2, 20))
        with patch.object(qp, 'foreground_target', return_value=target), \
             patch.object(qp, 'input_focus_state', return_value=(qp.INPUT_STATE_INPUT, 'test')), \
             patch.object(c, 'focus_bar_from_hotkey'):
            c.on_global_hotkey()
        self.assertEqual(c.bar.list.count(), 1000)
        self.assertIsNone(c.editor)
        phrase = c.data['profiles'][0]['categories'][0]['phrases'][0]
        with patch.object(c, '_paste_resolved') as paste:
            c.paste(phrase)
        paste.assert_called_once_with(phrase['text'], False)
        self.assertEqual(phrase['use_count'], 1)
        self.assertIsNone(c.editor)
        e = c._ensure_editor()
        self.assertIs(e, c._ensure_editor())
        self.assertIs(e.data, c.data)
        self.assertFalse(e.dirty)
        self.assertEqual(e.phrases.count(), 1000)
        QTest.keyClicks(e.phrase_label, 'edited')
        self.assertIsNone(c.bar.profile)
        self.assertTrue(e.dirty)

    def test_variables_before_editor_creation(self):
        c = self.controller()
        c.last_target = qp.TargetInfo(hwnd=123)
        phrase = {'text': 'Hello {name}', 'use_count': 0}
        with patch.object(qp, 'VariableInputDialog') as dialog, patch.object(c, '_paste_resolved') as paste:
            dialog.return_value.exec.return_value = qp.QDialog.Accepted
            dialog.return_value.result_text.return_value = 'Hello Alice'
            c.paste(phrase)
        dialog.assert_called_once_with('Hello {name}', None)
        paste.assert_called_once_with('Hello Alice', False)
        self.assertIsNone(c.editor)
        self.assertEqual(qp.user_variables('{date} {time} {datetime} {clipboard} {name} {name}'), ['name'])

    def test_settings_apply_and_cancel_before_editor_creation(self):
        c = self.controller()
        def apply_theme(dialog):
            dialog.theme_combo.setCurrentIndex(dialog.theme_combo.findData('ダーク'))
            return qp.QDialog.Accepted
        with patch.object(qp.SettingsDialog, 'exec', apply_theme), patch.object(c, 'register_global_hotkey'):
            c.show_settings()
        self.assertIsNone(c.editor)
        self.assertEqual(c.settings['theme'], 'ダーク')
        self.assertEqual(json.loads(qp.SETTING_FILE.read_text(encoding='utf-8'))['theme'], 'ダーク')
        def cancel_theme(dialog):
            dialog.theme_combo.setCurrentIndex(dialog.theme_combo.findData('Sapphire'))
            dialog.reject()
            return qp.QDialog.Rejected
        with patch.object(qp.SettingsDialog, 'exec', cancel_theme):
            c.show_settings()
        self.assertEqual(c.settings['theme'], 'ダーク')
        self.assertIsNone(c.editor)

    def test_quit_before_editor_creation_saves_and_handles_failure(self):
        c = self.controller()
        with patch.object(qp, 'write_json', return_value=False), \
             patch.object(qp.QMessageBox, 'question', return_value=qp.QMessageBox.No), \
             patch.object(self.app, 'quit') as quit_app:
            c.quit()
            quit_app.assert_not_called()
        with patch.object(qp, 'write_json', return_value=True) as write, patch.object(self.app, 'quit') as quit_app:
            c.quit()
            self.assertEqual(write.call_count, 2)
            quit_app.assert_called_once()
        self.assertIsNone(c.editor)

    def test_editor_navigation_and_reloads_do_not_edit_data(self):
        e = self.editor()
        before = copy.deepcopy(e.data)
        e.categories.setCurrentRow(1)
        e.phrases.setCurrentRow(15)
        e.reload_profiles()
        self.assertEqual(e.data, before)
        self.assertFalse(e.dirty)
        self.assert_keys(e)

    def test_key_assignment_updates_automatic_digits_and_conflicts(self):
        e = self.editor(1000)
        e.phrases.setCurrentRow(11)
        e.save_phrase_hotkey('1')
        self.assert_keys(e)
        self.assertTrue(e.phrases.item(0).text().startswith('–  '))
        e.phrases.setCurrentRow(12)
        e.save_phrase_hotkey('1')
        self.assertEqual(e.current_phrase()['hotkey'], '')
        e.save_phrase_hotkey('M')
        self.assertEqual(e.current_phrase()['hotkey'], '')
        e.phrases.setCurrentRow(11)
        e.save_phrase_hotkey('')
        self.assert_keys(e)
        self.assertTrue(e.phrases.item(0).text().startswith('1  '))
        e.categories.setCurrentRow(1)
        e.save_phrase_hotkey('1')
        self.assertEqual(e.current_phrase()['hotkey'], '1')

    def test_typing_and_navigation_keep_keys_without_rescans_or_io(self):
        e = self.editor(1000)
        e.save_phrase_hotkey('Z')
        with patch.object(qp, 'phrase_keys_for_category', wraps=qp.phrase_keys_for_category) as resolver, \
             patch.object(qp, 'write_json') as write:
            for i in range(25):
                e.phrase_label.selectAll()
                QTest.keyClicks(e.phrase_label, f'Renamed {i}')
                e.phrase_text.setPlainText(f'Body {i}')
                e.phrases.setCurrentRow(i + 1)
            resolver.assert_not_called()
            write.assert_not_called()
        self.assert_keys(e)
        e.categories.setCurrentRow(1)
        e.categories.setCurrentRow(0)
        self.assert_keys(e)
        e.phrases.setCurrentRow(0)
        self.assertEqual(e.phrase_key_effective.text(), '割当: Z')

    def test_reorder_preserves_ids_and_updates_fields_and_keys(self):
        e = self.editor(100)
        e.phrases.setCurrentRow(3)
        e.save_phrase_hotkey('R')
        before = copy.deepcopy(e.current_category()['phrases'])
        e.move_item(e.phrases, 1)
        expected = before[:]
        expected[3], expected[4] = expected[4], expected[3]
        self.assertEqual(e.current_category()['phrases'], expected)
        self.assertEqual(e.phrase_label.text(), expected[4]['label'])
        self.assertEqual(e.phrase_text.toPlainText(), expected[4]['text'])
        self.assert_keys(e)
        e.phrase_label.selectAll()
        QTest.keyClicks(e.phrase_label, 'Moved renamed')
        self.assertEqual(e.current_category()['phrases'][4]['label'], 'Moved renamed')
        e.categories.setCurrentRow(0)
        selected_id = e.current_category()['id']
        e.move_item(e.categories, 1)
        self.assertEqual(e.current_category()['id'], selected_id)
        self.assertEqual(e.phrase_text.toPlainText(), e.current_phrase()['text'])
        self.assert_keys(e)

    def test_duplicate_and_delete_refresh_keys(self):
        e = self.editor()
        e.save_phrase_hotkey('R')
        source = copy.deepcopy(e.current_phrase())
        e.current_phrase()['use_count'] = 10
        e.duplicate_phrase()
        duplicate = e.current_phrase()
        self.assertNotEqual(source['id'], duplicate['id'])
        self.assertEqual(duplicate['hotkey'], '')
        self.assertEqual(duplicate.get('use_count', 0), 0)
        self.assertEqual(duplicate['text'], source['text'])
        self.assert_keys(e)
        e.delete_from(e.phrases)
        self.assert_keys(e)

    def test_editor_close_saves_once_and_failure_stays_dirty(self):
        c = self.controller()
        e = c._ensure_editor()
        with patch.object(qp, 'write_json', return_value=True) as write:
            e.phrase_label.setText('A')
            e.phrase_text.setPlainText('B')
            write.assert_not_called()
            e.close()
            write.assert_called_once_with(qp.DATA_FILE, c.data)
            self.assertFalse(e.dirty)
            e.close()
            self.assertEqual(write.call_count, 1)
        QTest.keyClicks(e.phrase_label, 'C')
        with patch.object(qp, 'write_json', return_value=False), patch.object(qp.QMessageBox, 'critical'):
            e.close()
        self.assertTrue(e.dirty)

    def test_shortcut_reuse_routes_current_category_and_updated_rows(self):
        data = fixture(20)
        profile = data['profiles'][0]
        profile['categories'][0]['phrases'][11]['hotkey'] = 'R'
        profile['categories'][1]['phrases'][13]['hotkey'] = 'R'
        b = qp.PhraseBar(dict(qp.DEFAULT_SETTINGS))
        self.widgets.append(b)
        b.set_profile(profile)
        shortcuts = dict(b._shortcuts_by_key)
        executed = []
        b.paste_requested.connect(executed.append)
        for i in range(50):
            b._shortcuts_by_key['N'].activated.emit()
            b._shortcuts_by_key['R'].activated.emit()
            self.assertIs(executed[-1], profile['categories'][1]['phrases'][13])
            b._shortcuts_by_key['M'].activated.emit()
            b._shortcuts_by_key['R'].activated.emit()
            self.assertIs(executed[-1], profile['categories'][0]['phrases'][11])
        self.assertEqual(b._shortcuts_by_key, shortcuts)
        self.assertTrue(all(not s.autoRepeat() for s in b.dynamic_shortcuts))
        profile['categories'][0]['phrases'][11]['hotkey'] = ''
        b.select_category(profile['categories'][0])
        self.assertFalse(b._shortcuts_by_key['R'].isEnabled())
        before = len(executed)
        b._shortcuts_by_key['R'].activated.emit()
        self.assertEqual(len(executed), before)
        b._shortcuts_by_key['1'].activated.emit()
        self.assertIs(executed[-1], profile['categories'][0]['phrases'][0])
        profile['categories'].clear()
        b.rebuild()
        self.assertTrue(all(not s.isEnabled() for s in b.dynamic_shortcuts))

    def test_keyboard_category_phrase_space_and_tab(self):
        profile = fixture(20)['profiles'][0]
        profile['categories'][1]['phrases'][11]['hotkey'] = 'R'
        b = qp.PhraseBar(dict(qp.DEFAULT_SETTINGS))
        self.widgets.append(b)
        b.set_profile(profile)
        b.show(); b.activateWindow(); b.list.setFocus()
        self.app.processEvents()
        executed = []
        b.paste_requested.connect(executed.append)
        QTest.keyClick(b.list, qp.Qt.Key_1)
        self.assertIs(executed[-1], profile['categories'][0]['phrases'][0])
        QTest.keyClick(b.list, qp.Qt.Key_N)
        QTest.keyClick(b.list, qp.Qt.Key_R)
        self.assertIs(executed[-1], profile['categories'][1]['phrases'][11])
        QTest.keyClick(b.list, qp.Qt.Key_Down)
        QTest.keyClick(b.list, qp.Qt.Key_Space)
        self.assertIs(executed[-1], profile['categories'][1]['phrases'][12])
        QTest.keyClick(b.list, qp.Qt.Key_Tab)
        self.assertTrue(b.key_guide.isVisible())
        QTest.keyClick(b.list, qp.Qt.Key_Tab)
        self.assertFalse(b.key_guide.isVisible())

    def test_category_selection_memory_and_compact_header(self):
        profile = fixture(100, 8)['profiles'][0]
        b = qp.PhraseBar(dict(qp.DEFAULT_SETTINGS))
        self.widgets.append(b)
        b.set_profile(profile)
        self.assertTrue(b.compact_category_mode)
        b.list.setCurrentRow(57)
        b.move_category(1)
        b.move_category(-1)
        self.assertEqual(b.list.currentRow(), 57)

    def test_backup_import_and_rollback_with_lazy_editor(self):
        c = self.controller()
        c._ensure_editor()
        imported = fixture(30)
        imported['profiles'][0]['categories'][0]['phrases'][0]['hotkey'] = 'Z'
        payload = c._portable_backup_payload()
        payload['data'] = imported
        payload['settings'] = dict(qp.DEFAULT_SETTINGS, theme='Sapphire')
        path = self.directory / 'restore.qpbak'
        path.write_text(json.dumps(payload), encoding='utf-8')
        with patch.object(qp.QFileDialog, 'getOpenFileName', return_value=(str(path), '')), \
             patch.object(qp.QMessageBox, 'question', return_value=qp.QMessageBox.Yes), \
             patch.object(qp.QMessageBox, 'information'), patch.object(qp.QMessageBox, 'critical') as critical, \
             patch.object(c, 'register_global_hotkey'), patch.object(c, '_save_preimport_rollback', return_value=None):
            c.import_portable_backup()
            critical.assert_not_called()
            self.assertEqual(c.editor.phrases.count(), 30)
            self.assertEqual(c.settings['theme'], 'Sapphire')
            self.assert_keys(c.editor)
            before = copy.deepcopy(c.data)
            before_settings = copy.deepcopy(c.settings)
            payload['data'] = fixture(45)
            payload['settings'] = dict(qp.DEFAULT_SETTINGS, theme='ダーク')
            path.write_text(json.dumps(payload), encoding='utf-8')
            real_write = qp.write_json
            calls = 0
            def fail_once(*args):
                nonlocal calls
                calls += 1
                return False if calls == 1 else real_write(*args)
            with patch.object(qp, 'write_json', side_effect=fail_once):
                c.import_portable_backup()
            critical.assert_called_once()
            self.assertEqual(c.data, before)
            self.assertEqual(c.settings, before_settings)
            self.assertEqual(json.loads(qp.DATA_FILE.read_text(encoding='utf-8')), before)
            self.assert_keys(c.editor)

    def test_clipboard_generation_and_external_copy_protection(self):
        c = self.controller()
        c.last_target = qp.TargetInfo(hwnd=123)
        clip = self.app.clipboard()
        original = qp.QMimeData(); original.setText('original'); original.setHtml('<b>original</b>')
        clip.setMimeData(original)
        with patch.object(qp.QTimer, 'singleShot'):
            c._paste_resolved('first', False)
            old_generation = c.clipboard_restore_generation
            c._paste_resolved('second', False)
        c._restore_clipboard_after_paste(old_generation, 'first')
        self.assertEqual(clip.text(), 'second')
        c._restore_clipboard_after_paste(c.clipboard_restore_generation, 'second')
        self.assertEqual(clip.text(), 'original')
        self.assertEqual(clip.mimeData().html(), '<b>original</b>')
        with patch.object(qp.QTimer, 'singleShot'):
            c._paste_resolved('third', False)
        external = qp.QMimeData(); external.setText('third'); external.setHtml('<i>third</i>')
        clip.setMimeData(external)
        c._restore_clipboard_after_paste(c.clipboard_restore_generation, 'third')
        self.assertEqual(clip.mimeData().html(), '<i>third</i>')


if __name__ == '__main__':
    unittest.main()
