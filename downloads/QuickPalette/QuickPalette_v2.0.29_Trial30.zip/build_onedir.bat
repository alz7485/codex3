@echo off
setlocal
python -m PyInstaller --noconfirm --clean --windowed --onedir --name QuickPalette --icon icon.ico main.py
if errorlevel 1 exit /b %errorlevel%
copy /Y themes_default.json dist\QuickPalette\themes_default.json >nul
if errorlevel 1 exit /b %errorlevel%
echo Build complete.
endlocal
