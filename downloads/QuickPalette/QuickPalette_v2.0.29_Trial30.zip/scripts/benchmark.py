"""Compare synthetic Qt operations with a baseline main.py or handoff ZIP.

python scripts/benchmark.py --baseline QuickPalette_v2.0.28_Codex_Handoff.zip --output result.json
On Linux the offscreen Qt platform is selected automatically. No real user data,
hotkeys, autostart settings or clipboard contents are touched.
"""
import argparse
import copy
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
from statistics import median
import sys
import tempfile
from time import perf_counter
from unittest.mock import patch
import zipfile

if sys.platform != 'win32':
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import main as current
import PySide6


def sample_data(count):
    data = copy.deepcopy(current.DEFAULT_DATA)
    template = data['profiles'][0]['categories'][0]
    cats = []
    for c in range(2):
        category = copy.deepcopy(template)
        category.update(id=f'cat{c}', name=f'Category {c}', hotkey=('M' if c == 0 else 'N'))
        category['phrases'] = [dict(id=f'p{c}_{i}', label=f'Phrase {i}', text=f'Text {c}/{i}', hotkey='') for i in range(count)]
        cats.append(category)
    data['profiles'][0]['categories'] = cats
    return data


def time_ms(action):
    start = perf_counter()
    action()
    return (perf_counter() - start) * 1000


def dispose(app, controller):
    app.removeNativeEventFilter(controller.hotkey_filter)
    controller.tray.hide()
    if controller.editor is not None:
        controller.editor.deleteLater()
    controller.bar.deleteLater()
    controller.deleteLater()
    app.sendPostedEvents(None, current.QEvent.DeferredDelete)
    gc.collect()


def measure(module, app, count, directory, runs):
    module.DATA_FILE = directory / 'phrases.json'
    module.SETTING_FILE = directory / 'setting.json'
    module.THEMES_DEFAULT_FILE = ROOT / 'themes_default.json'
    module.reload_themes()
    if hasattr(module, 'THEMES_CUSTOM_FILE'):
        module.THEMES_CUSTOM_FILE = directory / 'themes_custom.json'
        module.reload_themes()
    module.DATA_FILE.write_text(json.dumps(sample_data(count)), encoding='utf-8')
    module.SETTING_FILE.write_text(json.dumps(module.DEFAULT_SETTINGS), encoding='utf-8')
    values = {k: [] for k in ('controller_init_ms', 'first_editor_ready_ms', 'assign_key_ms',
                             'reorder_ms', 'edit_label_ms', 'category_roundtrip_ms')}
    for run in range(runs + 1):
        start = perf_counter()
        controller = module.Controller(app)
        elapsed = (perf_counter() - start) * 1000
        assert not controller.startup_warnings
        start = perf_counter()
        if hasattr(controller, '_ensure_editor'):
            controller._ensure_editor()
        editor = controller.editor
        editor.refresh_key_displays()
        editor.refresh_usage_display()
        first_editor = (perf_counter() - start) * 1000
        controller.bar.set_profile(controller.data['profiles'][0])
        cats = controller.bar.profile['categories']
        editor.phrases.setCurrentRow(11)
        def assign():
            editor.save_phrase_hotkey('Z')
        def reorder():
            editor.move_item(editor.phrases, 1)
        def edit_label():
            # Invoke the connected user-edit handler with exactly one changed label.
            editor.phrase_label.setText(f'Renamed {run}')
            editor.save_phrase_fields()
        def roundtrip():
            controller.bar.select_category(cats[1])
            controller.bar.select_category(cats[0])
        measured = dict(controller_init_ms=elapsed, first_editor_ready_ms=first_editor,
                        assign_key_ms=time_ms(assign), reorder_ms=time_ms(reorder),
                        edit_label_ms=time_ms(edit_label))
        # Editing invalidates the palette profile. Rebind it before timing a real
        # category change, and verify the fixture did not silently become a no-op.
        controller.bar.set_profile(controller.data['profiles'][0])
        measured['category_roundtrip_ms'] = time_ms(roundtrip)
        assert controller.bar.list.count() == count
        if run:  # Warm Qt/font initialization once per fixture; report medians.
            for key, value in measured.items():
                values[key].append(value)
        dispose(app, controller)
    return {key: round(median(value), 4) for key, value in values.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--runs', type=int, default=7)
    args = parser.parse_args()
    if args.runs < 1:
        parser.error('--runs must be positive')
    app = current.QApplication([])
    app.setQuitOnLastWindowClosed(False)
    app.setFont(current.QFont('Yu Gothic UI', 10))
    report = dict(platform=platform.platform(), python=platform.python_version(), qt=PySide6.__version__,
                  runs=args.runs, counts_per_category=[100, 500, 1000], categories=2,
                  note='Warm in-process medians; excludes Python/Qt import, OS tray/hotkey registration and native paste latency.', results={})
    with tempfile.TemporaryDirectory() as temporary:
        temp = Path(temporary)
        modules = [('updated', current)]
        if args.baseline:
            path = args.baseline.resolve()
            raw = zipfile.ZipFile(path).read('main.py') if path.suffix.lower() == '.zip' else path.read_bytes()
            report['baseline_main_sha256'] = hashlib.sha256(raw).hexdigest()
            source = temp / 'baseline.py'
            source.write_bytes(raw)
            spec = importlib.util.spec_from_file_location('qp_baseline', source)
            baseline = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = baseline
            spec.loader.exec_module(baseline)
            modules.insert(0, ('baseline', baseline))
        with patch.object(current.QSystemTrayIcon, 'show'):
            for name, module in modules:
                directory = temp / name
                directory.mkdir()
                with patch.object(module.Controller, 'register_global_hotkey'), \
                     patch.object(module, 'reconcile_autostart', return_value=(True, '')):
                    report['results'][name] = {str(count): measure(module, app, count, directory, args.runs)
                                               for count in report['counts_per_category']}
        # Leave no application pointers in module-level callback cycles at shutdown.
        del modules
        gc.collect()
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text + '\n', encoding='utf-8')
    print(text)


if __name__ == '__main__':
    main()
