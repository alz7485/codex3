# 勤怠チェッカー Trial56 必要ファイル版

実行・ビルド用ソースとアイコン、19ページ図解マニュアルです。テスト・監査資料・サンプルを省いています。社員や勤怠の実データは含みません。

Windows 11 / Python 3.11 推奨。PowerShellでこのフォルダに移動して実行します。

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

ビルド後は dist\AttendSync 全体を配布します。ビルド済みEXEは含みません。既存userdataはバックアップ後に引き継いでください。

「社員情報」にID・メールを統合。「社員情報を読み込む」で紐付け用CSV／勤怠用CSVを列指定。紐付け用はID＋メール、勤怠用はIDだけです。社員ID列なしはスタッフID候補として保持。仮反映後「紐付けを保存」で確定し、キャンセルで取込・編集を破棄します。紐付け用に登録したCSVパスを勤怠読込から除外します。勤怠照合はメインのフォルダで実行します。

「メールを作成」画面でも自動送信ON/OFFを切り替えられます。今回だけの変更で、設定の初期値は変えません。OFFはOutlook下書き、ONは送信。新しいOutlook／Microsoft 365接続は Manual/Microsoft連携ガイド.html、図解は Manual/index.html を参照。全45テスト成功。Windows EXE・会社テナント実接続と送信は未検証です。
