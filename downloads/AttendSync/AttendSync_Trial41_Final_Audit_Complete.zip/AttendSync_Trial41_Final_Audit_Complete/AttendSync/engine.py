from __future__ import annotations
import csv, json, re, sqlite3, hashlib, math, os, tempfile
from pathlib import Path
from datetime import datetime, date, time, timedelta
from dataclasses import dataclass
from openpyxl import load_workbook
from openpyxl.utils.cell import column_index_from_string

FIELDS = {'month':'A','day':'B','label':'E','code':'F','start':'G','end':'H','break_day':'I','break_night':'J','ot_break_day':'K','ot_break_night':'L','break_total':'M','ot':'O','ot_night':'P','holiday_ot':'Q','holiday_night':'R','work':'T'}
CSV_FIELDS={'date':'A','calendar':'B','staff':'D','name':'E','start':'K','end':'L','work':'M','break_total':'N'}
NAMES={'month':'月','day':'日','label':'勤怠名称','code':'勤怠区分','start':'始業時刻','end':'終業時刻','break_day':'所定内休憩（昼）','break_night':'所定内休憩（深夜）','ot_break_day':'残業内休憩（昼）','ot_break_night':'残業内休憩（深夜）','break_total':'休憩合計','ot':'普通残業','ot_night':'深夜残業','holiday_ot':'法休残業','holiday_night':'法休深夜','work':'実働時間','calendar':'カレンダ区分'}
CODES={'0':'欠勤','1':'勤怠Ⅰ','2':'遅早退','3':'休日出勤','4':'法休出勤','5':'休日','6':'有給休暇','7':'特別休暇','8':'午前半休','9':'午後半休','10':'勤怠Ⅱ','11':'勤怠Ⅲ','12':'勤怠Ⅳ','20':'代休','21':'代休出勤','22':'休日出(短)','23':'法休出(短)','99':'その他'}
DEFAULT={'folder':'','year':2026,'month':10,'xlsx_columns':FIELDS,'csv_columns':CSV_FIELDS,'info_cells':{'period':'A1','employee':'N1','organization':'P1','name':'U1'},'sheet_names':{str(i):f'{i}月' for i in range(1,13)},'data_first_row':9,'data_last_row':100,'csv_first_row':2,'xlsx_schedule':{'label':'H','start':'I','end':'J','break_total':'K','rows':{'1':4,'10':5,'11':6,'12':7}},'codes':CODES,'comparisons':[{'name':'始業時刻','xlsx':'start','csv':'start','type':'clock','enabled':True},{'name':'終業時刻','xlsx':'end','csv':'end','type':'clock','enabled':True},{'name':'実働時間','xlsx':'work','csv':'work','type':'duration','enabled':True},{'name':'休憩時間','xlsx':'break_total','csv':'break_total','type':'duration','enabled':False}], 'csv_encoding':'auto'}

def validate_config(cfg):
    """Reject invalid layout settings before scanning employee data."""
    errors=[]
    if not isinstance(cfg,dict):return ['設定はオブジェクト形式で指定してください']
    try:
        year=int(cfg['year']);month=int(cfg['month'])
        if not (2000<=year<=2100 and 1<=month<=12):errors.append('対象年月が範囲外です')
    except (TypeError,ValueError,KeyError,OverflowError):errors.append('対象年月が無効です')
    for key,required in [('xlsx_columns',('month','day')),('csv_columns',('date','staff'))]:
        mapping=cfg.get(key)
        if not isinstance(mapping,dict):
            errors.append(f'{key} が不正です');continue
        for field in required:
            if field not in mapping or (field!='month' and not mapping.get(field)):
                errors.append(f'{key}.{field}: 日付・社員識別に必要な列が未設定です')
        for field,letter in mapping.items():
            if letter in (None,''):continue
            if not isinstance(letter,str) or not re.fullmatch(r'[A-Za-z]{1,3}',letter.strip()):
                errors.append(f'{key}.{field}: 列記号が不正です')
            else:
                try:
                    if column_index_from_string(letter.strip().upper())>16384:
                        errors.append(f'{key}.{field}: 列がExcelの上限XFDを超えています')
                except ValueError:errors.append(f'{key}.{field}: 列が範囲外です')
    for key in ('data_first_row','data_last_row','csv_first_row'):
        try:
            value=cfg[key]
            if isinstance(value,bool) or (isinstance(value,float) and not value.is_integer()) or not 1<=int(value)<=1048576:
                errors.append(f'{key} は1～1,048,576です')
        except (TypeError,ValueError,KeyError,OverflowError):errors.append(f'{key} が無効です')
    try:
        if int(cfg['data_first_row'])>int(cfg['data_last_row']):errors.append('データ開始行が終了行より後です')
    except (TypeError,ValueError,KeyError,OverflowError):pass
    try:
        sheet=cfg['sheet_names'][str(int(cfg['month']))]
        if not isinstance(sheet,str) or not sheet.strip():errors.append('対象月のシート名が未設定です')
    except (KeyError,TypeError,ValueError,OverflowError):errors.append('対象月のシート名がありません')
    info=cfg.get('info_cells',{})
    if not isinstance(info,dict):
        errors.append('基本情報のセル設定が不正です');info={}
    for key in dict.fromkeys(('employee','period','name','organization',*info)):
        cell=info.get(key,'')
        match=re.fullmatch(r'([A-Za-z]{1,3})([1-9][0-9]{0,6})',cell.strip()) if isinstance(cell,str) else None
        if not match:
            errors.append(f'基本情報 {key}: セル番地が不正です')
        elif column_index_from_string(match[1].upper())>16384 or int(match[2])>1048576:
            errors.append(f'基本情報 {key}: Excelの上限XFD列・1,048,576行を超えています')
    comparisons=cfg.get('comparisons')
    if not isinstance(comparisons,list):errors.append('照合項目が不正です')
    else:
        for item in comparisons:
            if not isinstance(item,dict):errors.append('照合項目の設定形式が不正です');continue
            if not item.get('enabled'):continue
            if not isinstance(item.get('name'),str) or not item['name'].strip():errors.append('照合項目名が未設定です')
            for source,side in [('xlsx_columns','xlsx'),('csv_columns','csv')]:
                mapping=cfg.get(source,{})
                field=item.get(side)
                if not isinstance(field,str) or not isinstance(mapping,dict) or not mapping.get(field):
                    errors.append(f'{item.get("name", "照合項目")}: 照合元の列が未設定です')
    return errors

def load_json(path, default):
    if not Path(path).exists(): return json.loads(json.dumps(default,ensure_ascii=False))
    with open(path,encoding='utf-8-sig') as f: return json.load(f)
def save_json(path,data):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=p.parent,prefix=p.name+'.',suffix='.tmp',delete=False) as stream:
            temporary=Path(stream.name)
            json.dump(data,stream,ensure_ascii=False,indent=2)
            stream.flush();os.fsync(stream.fileno())
        temporary.replace(p)
    finally:
        if temporary is not None:
            try:temporary.unlink(missing_ok=True)
            except OSError:pass
def normalize_name(x):return re.sub(r'[\s\u3000]+','',str(x or '')).strip()
def ident(x):
    if x is None:return ''
    s=str(x).strip()
    return s[:-2] if s.endswith('.0') and s[:-2].isdigit() else s

def col(row,letter):
    if not letter:return None
    try:i=column_index_from_string(str(letter).strip().upper())-1
    except ValueError:return None
    return row[i] if i<len(row) else None

def time_minutes(v,kind='clock'):
    if v is None or str(v).strip()=='':return None
    if isinstance(v,bool):raise ValueError('真偽値は時刻・時間として扱えません')
    if isinstance(v,(datetime,time)):
        minutes=v.hour*60+v.minute+(v.second/60)
    elif isinstance(v,timedelta):minutes=v.total_seconds()/60
    elif isinstance(v,(int,float)):
        # Excel times/durations are fractions of a day.
        minutes=float(v)*1440
    else:
        s=str(v).strip().replace('：',':')
        m=re.fullmatch(r'(\d{1,3}):(\d{1,2})(?::(\d{1,2}))?',s)
        if not m:raise ValueError('時間を解釈できません: '+s)
        h,minute,second=map(int,(m[1],m[2],m[3] or 0))
        if minute>59 or second>59:raise ValueError('分・秒が範囲外: '+s)
        minutes=h*60+minute+second/60
    # Validate before clock normalization. Otherwise -12:00 or 56:30 can
    # become an ordinary time and falsely match 12:00 or 8:30. Apply this
    # rule to both sources and every later-added comparison field.
    if not math.isfinite(minutes) or minutes<0 or (kind=='clock' and minutes>=48*60):
        raise ValueError('時刻・時間の範囲外')
    return minutes
def display_time(v,kind):
    if v is None or str(v).strip()=='':return ''
    try:
        n=time_minutes(v,kind)
        n=int(round(n))
        if kind=='clock':n=n%1440
        return f'{n//60}:{n%60:02d}'
    except Exception:return str(v)
def compare_time(a,b,kind):
    a_empty=a is None or str(a).strip()==''
    b_empty=b is None or str(b).strip()==''
    if a_empty and b_empty:return '一致'
    try:
        x=None if a_empty else time_minutes(a,kind)
        y=None if b_empty else time_minutes(b,kind)
        if a_empty or b_empty:return '不一致'
        if kind=='clock':x%=1440;y%=1440
        return '一致' if abs(x-y)<0.001 else '不一致'
    except Exception:return '要確認'

def calendar_integer(value):
    """Accept integral Excel calendar values without truncating corrupt dates."""
    if isinstance(value,bool) or (isinstance(value,float) and (not math.isfinite(value) or not value.is_integer())):
        raise ValueError('月・日は整数で指定してください')
    return int(value)
def canonical_row_date(year,month,day,period_year,period_month):
    d=date(int(year),int(month),int(day))
    end=date(period_year,period_month,15)
    start=(end.replace(day=1)-timedelta(days=1)).replace(day=16)
    return d if start<=d<=end else None

def xlsx_read(path,cfg):
    # A single target sheet per workbook; never launch Excel.
    sh=cfg['sheet_names'][str(cfg['month'])]
    wb=load_workbook(path,read_only=True,data_only=True)
    try:
        if sh not in wb.sheetnames:return {'error':f'対象シート「{sh}」なし'}
        ws=wb[sh]; info={k:ident(ws[cell].value) for k,cell in cfg['info_cells'].items()}
        employee=ident(info.get('employee'))
        if not employee:return {'error':'社員番号が空欄'}
        period=info.get('period','')
        period_match=re.search(r'(\d{4})年\s*(\d{1,2})月度',period)
        if period_match and (int(period_match[1]),int(period_match[2])) != (int(cfg['year']),int(cfg['month'])):
            return {'error':f'対象年月の不一致: A1={period} / 指定={cfg["year"]}年{cfg["month"]}月度'}
        year=int(cfg['year']);month=int(cfg['month']);records=[];warnings=[]
        source_stat=Path(path).stat()
        current_month=(month-2)%12+1
        first=int(cfg['data_first_row']);last=int(cfg['data_last_row'])
        for rno,row in enumerate(ws.iter_rows(min_row=first,max_row=last,values_only=True),first):
            dd=col(row,cfg['xlsx_columns']['day'])
            if dd is None or str(dd).strip()=='':continue
            if isinstance(dd,datetime):dd=dd.day
            try:day=calendar_integer(dd)
            except (ValueError,TypeError,OverflowError):
                warnings.append(f'{sh} {rno}行: 日が不正 ({dd!r})')
                continue
            mm=col(row,cfg['xlsx_columns']['month'])
            if mm is not None and str(mm).strip():
                try:current_month=calendar_integer(mm)
                except (ValueError,TypeError,OverflowError):warnings.append(f'{sh} {rno}行: 月が不正');continue
            yy=year-1 if month==1 and current_month==12 else year
            try:dt=canonical_row_date(yy,current_month,day,year,month)
            except ValueError:dt=None
            if dt is None:
                warnings.append(f'{sh} {rno}行: 期間外の日付 {current_month}/{day}')
                continue
            values={k:col(row,v) for k,v in cfg['xlsx_columns'].items()}
            values={k:(v.total_seconds()/86400 if isinstance(v,timedelta) else v.strftime('%H:%M:%S') if isinstance(v,(time,datetime)) else v.isoformat() if isinstance(v,date) else v) for k,v in values.items()}
            code=ident(values.get('code'))
            values['code_label']=cfg.get('codes',CODES).get(code,'不明')
            records.append({'date':dt.isoformat(),'row':rno,'sheet':sh,'file':str(path),'employee':employee,'name':info.get('name',''),'values':values,
                            'file_size':source_stat.st_size,'file_mtime_ns':source_stat.st_mtime_ns})
        return {'info':info,'records':records,'warnings':warnings}
    finally:wb.close()

def csv_read(path,cfg):
    encoding=cfg.get('csv_encoding','auto');raw=Path(path).read_bytes()
    if encoding=='auto':
        for enc in ('utf-8-sig','cp932','utf-8'):
            try:content=raw.decode(enc);break
            except UnicodeDecodeError:continue
        else:raise ValueError('CSV文字コードが不明')
    else:content=raw.decode(encoding)
    import io
    records=[];warnings=[]
    for line,row in enumerate(csv.reader(io.StringIO(content)),1):
        if line<int(cfg['csv_first_row']):continue
        f=cfg['csv_columns'];dateval=col(row,f['date']); staff=ident(col(row,f['staff']))
        if not staff and not dateval:continue
        if not staff or not dateval:
            warnings.append(f'{path.name}:{line}行 IDまたは日付が空欄 (スタッフID={staff!r}, 日付={dateval!r})')
            continue
        try:
            ds=str(dateval).strip()
            if not re.fullmatch(r'[0-9]{8}',ds):raise ValueError('日付は8桁のYYYYMMDDで指定してください')
            dt=datetime.strptime(ds,'%Y%m%d').date().isoformat()
        except ValueError:
            warnings.append(f'{path.name}:{line}行 日付不正 (スタッフID={staff}, 値={dateval!r})');continue
        vals={k:col(row,v) for k,v in f.items()}
        # Validate all configured CSV time fields, including fields whose comparisons are OFF.
        # Keep the record so the corresponding employee/day cannot silently disappear.
        invalid_fields=[]
        for field in ('start','end','work','break_total'):
            value=vals.get(field)
            if value is None or str(value).strip()=='':
                continue
            try:
                minutes=time_minutes(value, 'clock' if field in ('start','end') else 'duration')
                if minutes is None:
                    raise ValueError('時刻・時間の範囲外')
            except (ValueError,TypeError,OverflowError) as exc:
                invalid_fields.append(field)
                warnings.append(f'{path.name}:{line}行 スタッフID={staff} 日付={dt} {NAMES.get(field,field)}の値が不正 ({value!r}): {exc}')
        records.append({'staff':staff,'name':str(vals.get('name') or ''),'date':dt,'row':line,'file':str(path),'values':vals,'invalid_fields':invalid_fields})
    return {'records':records,'warnings':warnings}

class Cache:
    def __init__(self,path):
        self.db=sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS cache (path TEXT PRIMARY KEY, sig TEXT, data TEXT)')
    def parse(self,path,tag,parser):
        p=Path(path);st=p.stat();sig=f'{st.st_size}:{st.st_mtime_ns}:{tag}'
        old=self.db.execute('SELECT data FROM cache WHERE path=? AND sig=?',(str(p),sig)).fetchone()
        if old:
            try:
                packet=json.loads(old[0])
                if (p.stat().st_size,p.stat().st_mtime_ns)==(st.st_size,st.st_mtime_ns):
                    return packet,True
            except (ValueError,TypeError):pass
        parsed=parser(p)
        after=p.stat()
        if (after.st_size,after.st_mtime_ns)!=(st.st_size,st.st_mtime_ns):
            raise RuntimeError(f'キャッシュ保存前に元ファイルが更新されました: {p.name}')
        self.db.execute('INSERT OR REPLACE INTO cache VALUES(?,?,?)',(str(p),sig,json.dumps(parsed,ensure_ascii=False,default=str)))
        self.db.commit();return parsed,False
    def close(self):self.db.close()

def candidates(xfiles,cfiles,mapping):
    out=[];used={str(v) for v in mapping.values() if v}
    csv_ids={}
    for rec in cfiles:
        name=normalize_name(rec['name'])
        if name:csv_ids.setdefault(name,set()).add(rec['staff'])
    for employee,v in xfiles.items():
        if employee in mapping:continue
        name=normalize_name(v['info']['name'])
        poss=sorted(csv_ids.get(name,set())) if name else []
        if len(poss)==1 and poss[0] not in used:
            mapping[employee]=poss[0];used.add(poss[0])
        else:out.append((employee,v['info'].get('name',''),poss))
    return out

def reconcile(xdata,cdata,mapping,cfg):
    """Compare only unambiguous employee/staff/date pairs; expose coverage gaps."""
    from collections import Counter
    cindex={};rows=[];issues=[]
    for item in cfg.get('comparisons',[]):
        if item.get('enabled') and item.get('type','text') not in ('clock','duration','text','number'):
            issues.append(f'{item.get("name", "照合項目")}: 未対応の照合形式「{item.get("type")}」のため要確認')
    for item in cdata:
        cindex.setdefault((item['staff'],item['date']),[]).append(item)
    staff_dates={}
    for (staff,day),items in cindex.items():
        staff_dates.setdefault(staff,[]).append((day,items))
    counts=Counter(v for v in mapping.values() if v)
    duplicated_staff={v for v,n in counts.items() if n>1}
    end=date(int(cfg['year']),int(cfg['month']),15)
    start=(end.replace(day=1)-timedelta(days=1)).replace(day=16)
    def issue_row(eid,sid,name,when,field,x=None,c=None):
        rows.append({'date':when,'employee':eid,'staff':sid or '', 'name':name,
                     'field':field,'xlsx':'—','csv':'—','status':'要確認',
                     'xrecord':x,'crecord':c})
        issues.append(f'{eid} {when}: {field}')
    for eid,packet in xdata.items():
        sid=mapping.get(eid)
        if sid in duplicated_staff:
            issue_row(eid,sid,packet.get('info',{}).get('name',''),'—','スタッフID重複割当')
            continue
        if not sid:
            for x in packet['records']:
                issue_row(eid,'',x['name'],x['date'],'スタッフID未紐付け',x)
            if not packet['records']:
                issue_row(eid,'',packet.get('info',{}).get('name',''),'—','スタッフID未紐付け')
            continue
        xindex={}
        for x in packet['records']:
            xindex.setdefault(x['date'],[]).append(x)
        for day,options_x in xindex.items():
            if len(options_x)>1:
                issue_row(eid,sid,options_x[0]['name'],day,f'XLSX同日重複（{len(options_x)}行）',options_x[0])
                continue
            x=options_x[0]
            options=cindex.get((sid,day),[])
            if not options:
                issue_row(eid,sid,x['name'],day,'CSV記録なし',x)
                continue
            if len(options)>1:
                issue_row(eid,sid,x['name'],day,f'CSV同日重複（{len(options)}行）',x)
                continue
            c=options[0]
            # Input corruption must never be interpreted as an ordinary match/mismatch.
            for invalid in c.get('invalid_fields',[]):
                issue_row(eid,sid,x['name'],day,f'CSV入力異常：{NAMES.get(invalid, invalid)}',x,c)
            for item in cfg['comparisons']:
                if not item.get('enabled') or not item.get('csv'):continue
                a=x['values'].get(item['xlsx']);b=c['values'].get(item['csv'])
                kind=item.get('type','text')
                status=('要確認' if kind not in ('clock','duration','text','number') or item['csv'] in c.get('invalid_fields',[]) else
                        compare_time(a,b,kind) if kind in ('clock','duration') else
                        ('一致' if ('' if a is None else str(a))==('' if b is None else str(b)) else '不一致'))
                rows.append({'date':day,'employee':eid,'staff':sid,'name':x['name'],'field':item['name'],
                    'xlsx':display_time(a,kind) if kind in ('clock','duration') else ('' if a is None else str(a)),
                    'csv':display_time(b,kind) if kind in ('clock','duration') else ('' if b is None else str(b)),
                    'status':status,'xrecord':x,'crecord':c,'xlsx_key':item['xlsx'],'csv_key':item['csv']})
        # Only scrutinize unmatched CSV dates for employees explicitly present in XLSX,
        # not other employees in the all-staff CSV exports.
        for day,options in staff_dates.get(sid,[]):
            if day in xindex:continue
            if not (start.isoformat()<=day<=end.isoformat()):continue
            # No source day is a coverage gap, whether worked or blank; check, do not assume leave.
            issue_row(eid,sid,packet.get('info',{}).get('name',''),day,
                      f'XLSX記録なし（CSV {len(options)}行）',None,options[0] if len(options)==1 else None)
    rows.sort(key=lambda r:(r['employee'],r['date'],r['field']))
    return rows,issues


def coverage_report(xdata, cdata, mapping, cfg):
    """Count loaded days, detect missing expected days and orphan/duplicate staff-day records.

    A gap is reported for review, not automatically judged as an attendance mismatch.
    """
    from collections import Counter
    end = date(int(cfg['year']), int(cfg['month']), 15)
    start = (end.replace(day=1) - timedelta(days=1)).replace(day=16)
    days = [(start + timedelta(days=i)).isoformat() for i in range((end-start).days+1)]
    expected = set(days)
    ccounts = Counter((ident(r.get('staff')),r.get('date')) for r in cdata)
    result = {'employees':len(xdata),'expected_days_per_employee':len(days),
              'expected_employee_days':len(xdata)*len(days),'xlsx_days_present':0,
              'csv_days_present':0,'review':[]}
    for eid, packet in sorted(xdata.items()):
        sid = ident(mapping.get(eid))
        xcounts = Counter(r.get('date') for r in packet.get('records',[]))
        for d in days:
            nx=xcounts.get(d,0)
            nc=ccounts.get((sid,d),0) if sid else 0
            result['xlsx_days_present']+=int(nx>0)
            result['csv_days_present']+=int(nc>0)
            # Leave classification to the operator; no invented calendar rows.
            if nx!=1 or (sid and nc!=1) or not sid:
                reason = 'XLSX記録なし' if nx==0 else 'XLSX同日重複' if nx>1 else 'ID未紐付け' if not sid else 'CSV記録なし' if nc==0 else 'CSV同日重複'
                result['review'].append({'employee':eid,'staff':sid,'date':d,'reason':reason,'xlsx_count':nx,'csv_count':nc})
        for d,n in xcounts.items():
            if d not in expected:
                result['review'].append({'employee':eid,'staff':sid,'date':d,'reason':'XLSX期間外','xlsx_count':n,'csv_count':0})
    result['complete']=len(result['review'])==0
    return result
