# 勤怠チェッカー Trial60 必要ファイル版

読込設定は1行へ統合。CSV読込1000px、社員情報1040px、メイン1180px、メール作成1080pxへ初期幅を縮小しました。

実行・ビルド用ソース、アイコン、18ページ図解です。社員・勤怠の実データ、テスト・監査・サンプル、ビルド済みEXEは含みません。

Windows11 / Python3.11推奨。PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

ビルド後はdist\AttendSync全体を配布。旧userdataはバックアップ後に引き継ぎます。

最初に「社員情報」でCSVを選択またはドロップしてください。スタッフID=A、社員ID（派遣元スタッフコード）=B、氏名=C、メール=Jが初期値です。保存済み列指定は保持します。列などを変えると自動で読み直します。4列一覧をダブルクリックすると元CSVのセルへ移動できます（Windows版Excel・pywin32が必要）。

「一覧に反映」→「社員情報を登録」で確定し、メイン画面から勤怠を読み込みます。未登録で勤怠を読もうとすると「勤怠チェックを行う前に社員情報を登録してください」と表示して社員情報を開き、勤怠は読み込みません。勤怠データからIDを推測・登録しません。登録のみで勤怠を自動実行せず、取消では仮取込を破棄します。

図解：Manual/index.html。メール初回接続：Manual/Microsoft連携ガイド.html。メール自動送信初期OFF。前版47本成功を継承し、今回の関連6本も成功。Windows EXE・実Excel操作・実Microsoft365接続／送信は未検証です。
