from __future__ import annotations
import sys, json, traceback, time
from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
from PySide6.QtCore import Qt,QObject,Signal,QThread,QAbstractTableModel,QSize,QTimer,QEvent,QRectF
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QPushButton,QLabel,QLineEdit,QFileDialog,QSpinBox,QComboBox,QTableWidget,QTableWidgetItem,QTableView,QHeaderView,QMessageBox,QDialog,QDialogButtonBox,QTextEdit,QGroupBox,QFormLayout,QProgressBar,QMenu,QAbstractItemView,QTabWidget,QCheckBox,QFrame,QScrollArea,QSizePolicy,QAbstractSpinBox,QStyledItemDelegate,QStyleOptionViewItem,QStyle)
from PySide6.QtGui import QAction,QTextDocument,QColor,QBrush,QFont,QPen,QPainter,QPalette
from PySide6.QtPrintSupport import QPrinter,QPrintDialog
from engine import comparison_totals, coverage_report, validate_config, load_json,save_json,DEFAULT,Cache,xlsx_read,csv_read,candidates,reconcile,NAMES,display_time,normalize_name
from cache_tags import parser_tag
from stable_read import parse_stable_file
from startup_period import current_attendance_month

from runtime_paths import get_data_dir, application_dir
from excel_jump import open_source_cell, source_cell_for
from printing import print_html, print_cell
from ui_theme import button,icon,refresh_button_icons,apply_theme,theme_colors
from settings_dialog import SettingsDialog, DETAIL_REFERENCE_FIELDS, detail_fields_for, comparison_for_pair
DATA_DIR=get_data_dir()
CONFIG=DATA_DIR/'settings.json';MAP=DATA_DIR/'staff_mapping.json';DB=DATA_DIR/'attendance_cache.sqlite3'

def set_item(table,r,c,value):
    item=QTableWidgetItem(str(value or ''));item.setFlags(item.flags() & ~Qt.ItemIsEditable);table.setItem(r,c,item)

def esc(text):
    import html
    return html.escape(str(text or ''))

def selected_staff_id(combo):
    """Read the candidate ID, keeping display captions out of saved mappings."""
    typed=combo.currentText().strip()
    index=combo.currentIndex()
    selected=(str(combo.itemData(index) or '').strip()
              if index>=0 and typed==combo.itemText(index).strip() else typed)
    return '' if selected=='未紐付け' else selected

class ReadWorker(QThread):
    progress=Signal(int,int,str)
    result=Signal(object,object,object,object)
    def cancel(self):
        self.requestInterruption()
    def __init__(self,folder,cfg,full=False):
        super().__init__();self.folder=Path(folder);self.cfg=json.loads(json.dumps(cfg));self.full=full
    @staticmethod
    def _same_file_state(path, original_stat):
        try:
            now=path.stat()
            return (now.st_size,now.st_mtime_ns)==(original_stat.st_size,original_stat.st_mtime_ns)
        except OSError:
            return False
    def run(self):
        xdata={};cdata=[];issues=[];cache=None
        started=time.perf_counter();cache_hits=0;parsed_count=0;file_errors=[];read_warnings=[]
        try:
            cache=Cache(DB)
            files=sorted(p for p in self.folder.iterdir() if p.is_file() and not p.name.startswith('~$') and p.suffix.lower() in ('.xlsx','.csv'))
            if self.full:
                cache.db.execute('DELETE FROM cache');cache.db.commit()
            tag=parser_tag(self.cfg,'xlsx')
            csvtag=parser_tag(self.cfg,'csv')
            jobs={};ready=[];preflight_failures=0
            pool=ThreadPoolExecutor(max_workers=max(1,min(8,int(self.cfg.get('read_workers',4)))))
            try:
                for p in files:
                    if self.isInterruptionRequested():break
                    key=tag if p.suffix.lower()=='.xlsx' else csvtag
                    try:
                        st=p.stat()
                    except OSError as exc:
                        issues.append(f'{p.name}: ファイル情報の取得に失敗: {exc}')
                        file_errors.append({'file':p.name,'reason':f'ファイル情報取得失敗: {exc}'})
                        preflight_failures+=1
                        continue
                    sig=f'{st.st_size}:{st.st_mtime_ns}:{key}'
                    cached=cache.db.execute('SELECT data FROM cache WHERE path=? AND sig=?',(str(p),sig)).fetchone()
                    try:
                        packet_from_cache=json.loads(cached[0]) if cached else None
                    except (json.JSONDecodeError,TypeError,ValueError):
                        packet_from_cache=None
                    if (isinstance(packet_from_cache,dict) and not packet_from_cache.get('error')
                        and ('info' in packet_from_cache and 'records' in packet_from_cache if p.suffix.lower()=='.xlsx' else 'records' in packet_from_cache)
                        and self._same_file_state(p,st)):
                        ready.append((p,packet_from_cache,True,sig))
                    else:
                        parser=xlsx_read if p.suffix.lower()=='.xlsx' else csv_read
                        jobs[pool.submit(parse_stable_file,parser,p,self.cfg)]=(p,sig)
                completed=preflight_failures
                def absorb(p,packet,was_cached):
                    nonlocal completed,cache_hits,parsed_count
                    if was_cached:cache_hits+=1
                    else:parsed_count+=1
                    for w in packet.get('warnings',[]):
                        issues.append(f'{p.name}: {w}')
                        read_warnings.append({'file':p.name,'reason':str(w)})
                    if packet.get('error'):
                        issues.append(f'{p.name}: {packet["error"]}')
                        file_errors.append({'file':p.name,'reason':packet['error']})
                    elif p.suffix.lower()=='.xlsx':
                        eid=packet['info']['employee']
                        if eid in xdata:
                            issues.append(f'社員番号 {eid} が複数のXLSXで重複: {p.name}')
                            # Mark the employee unsafe instead of silently taking whichever file finishes first.
                            xdata[eid]['duplicate_xlsx'] = True
                            sources=xdata[eid].setdefault('duplicate_sources',[{'file':xdata[eid].get('source_file', '不明'), 'records':xdata[eid].get('records',[])}])
                            sources.append({'file':str(p), 'records':packet.get('records',[])})
                            xdata[eid]['duplicate_files'] = [Path(a['file']).name for a in sources]
                        else:
                            packet['source_file']=str(p)
                            xdata[eid]=packet
                    else:cdata.extend(packet['records'])
                    completed+=1
                    self.progress.emit(completed,len(files),f'{p.name}  (キャッシュ {cache_hits} / 新規 {parsed_count})')
                for p,packet,_,sig in ready:
                    if self.isInterruptionRequested():break
                    try:
                        current=p.stat()
                        sig_now=f'{current.st_size}:{current.st_mtime_ns}:{tag if p.suffix.lower()==".xlsx" else csvtag}'
                        if sig_now!=sig:
                            raise RuntimeError('キャッシュ再利用前に元ファイルが更新されました。再読み込みしてください。')
                        absorb(p,packet,True)
                    except (OSError, RuntimeError) as exc:
                        file_errors.append({'file':p.name,'reason':f'キャッシュ検証失敗: {exc}'})
                        issues.append(f'{p.name}: キャッシュ検証失敗: {exc}')
                        completed+=1
                        self.progress.emit(completed,len(files),p.name+' キャッシュ検証失敗')
                pending=set(jobs)
                while pending:
                    if self.isInterruptionRequested():
                        for f in pending:f.cancel()
                        issues.append('ユーザー操作により読み込みを中止しました。')
                        break
                    done,pending=wait(pending,timeout=0.15,return_when=FIRST_COMPLETED)
                    for future in done:
                        if self.isInterruptionRequested():
                            break
                        p,sig=jobs[future]
                        try:
                            packet=future.result()
                            # Invalid/changed source must never enter the persistent cache.
                            if packet.get('error'):
                                absorb(p,packet,False)
                                continue
                            current=p.stat()
                            expected=f'{current.st_size}:{current.st_mtime_ns}:{tag if p.suffix.lower()==".xlsx" else csvtag}'
                            if expected!=sig:
                                raise RuntimeError('解析後からキャッシュ保存前に元ファイルが更新されました')
                            cache.db.execute('INSERT OR REPLACE INTO cache VALUES(?,?,?)',(str(p),sig,json.dumps(packet,ensure_ascii=False,default=str)))
                            cache.db.commit()
                            absorb(p,packet,False)
                        except Exception as e:
                            issues.append(f'{p.name}: {type(e).__name__}: {e}')
                            file_errors.append({'file':p.name,'reason':f'{type(e).__name__}: {e}'})
                            completed+=1;self.progress.emit(completed,len(files),p.name+' 読み込み失敗')
            finally:
                # Cancellation stops pending jobs, then joins active parsers *in this QThread*.
                # Detaching the executor left orphan reader threads accessing files after a
                # subsequent run. The GUI remains responsive while this QThread joins them.
                pool.shutdown(wait=True, cancel_futures=self.isInterruptionRequested())
            if self.isInterruptionRequested():
                self.result.emit({},[],issues or ['読み込みを中止しました。'],{'cancelled':True,'elapsed':time.perf_counter()-started,'cache_hits':cache_hits,'parsed':parsed_count,'file_errors':file_errors,'read_warnings':read_warnings,'files_found':len(files),'files_completed':completed,'files_failed':len(file_errors)})
            else:
                self.result.emit(xdata,cdata,issues,{'cancelled':False,'elapsed':time.perf_counter()-started,'cache_hits':cache_hits,'parsed':parsed_count,'file_errors':file_errors,'read_warnings':read_warnings,'files_found':len(files),'files_completed':completed,'files_failed':len(file_errors)})
        except Exception as e:
            issues.append(f'処理エラー: {e}\n{traceback.format_exc()}')
            self.result.emit({},[],issues,{'cancelled':self.isInterruptionRequested(),'fatal_error':str(e),'elapsed':time.perf_counter()-started,'cache_hits':cache_hits,'parsed':parsed_count,'file_errors':file_errors,'read_warnings':read_warnings})
        finally:
            if cache:cache.close()


# ── Shared UI helpers ────────────────────────────────────────────────────────
def label(text, role=None):
    obj = QLabel(text)
    if role:
        obj.setObjectName(role)
    obj.setWordWrap(True)
    return obj


def card_box(parent=None):
    box = QFrame(parent)
    box.setObjectName('card')
    return box


def section_page():
    canvas = QWidget()
    root = QVBoxLayout(canvas)
    root.setContentsMargins(18, 20, 18, 20)
    root.setSpacing(14)
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setWidget(canvas)
    return scroll, root


def grid_line_edit(grid, row, col, title, value, width=125):
    cell = QWidget()
    v = QVBoxLayout(cell)
    v.setContentsMargins(0, 0, 0, 0)
    v.setSpacing(5)
    v.addWidget(label(title, 'fieldHint'))
    edit = QLineEdit(str(value if value is not None else ''))
    edit.setMaximumWidth(width)
    v.addWidget(edit)
    grid.addWidget(cell, row, col)
    return edit


class MappingDialog(QDialog):
    """Only ambiguous or missing staff ID candidates require human action."""
    def __init__(self, parent, unresolved, mapping):
        super().__init__(parent)
        self.setWindowTitle('社員IDの紐付け確認')
        self.resize(780, 570)
        self.setMinimumSize(650, 430)
        self.mapping = dict(mapping)
        self.inputs = []
        root = QVBoxLayout(self)
        root.setContentsMargins(22, 22, 22, 20)
        root.setSpacing(12)
        root.addWidget(label('社員IDの紐付け確認', 'pageTitle'))
        root.addWidget(label('XLSXの社員番号を基準にCSVのスタッフIDを選択してください。候補がない場合は直接入力できます。', 'muted'))
        table = QTableWidget(len(unresolved), 3)
        table.setHorizontalHeaderLabels(['XLSX 社員番号', '氏名', 'CSV スタッフID'])
        table.setAlternatingRowColors(True)
        table.verticalHeader().setDefaultSectionSize(47)
        table.verticalHeader().hide()
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for i, (eid, name, options) in enumerate(unresolved):
            set_item(table, i, 0, eid)
            set_item(table, i, 1, name)
            combo = QComboBox()
            combo.addItem('未紐付け', '')
            for sid in options:
                combo.addItem(sid, sid)
            combo.setEditable(True)
            combo.setToolTip('候補を選択、またはスタッフIDを直接入力')
            table.setCellWidget(i, 2, combo)
            self.inputs.append((eid, combo))
        root.addWidget(table, 1)
        foot = QHBoxLayout()
        foot.addWidget(label(f'確認が必要な社員：{len(unresolved)}人', 'muted'))
        foot.addStretch()
        cancel = button('キャンセル', 'x')
        cancel.clicked.connect(self.reject)
        ok = button('紐付けを確定', 'check', 'primary')
        ok.clicked.connect(self.accept)
        foot.addWidget(cancel)
        foot.addWidget(ok)
        root.addLayout(foot)
        refresh_button_icons(self, parent.is_dark)

    def accept(self):
        new_mapping = dict(self.mapping)
        for eid, cb in self.inputs:
            selected = selected_staff_id(cb)
            if selected:
                new_mapping[eid] = selected
            else:
                new_mapping.pop(eid, None)
        values = [v for v in new_mapping.values() if v]
        if len(values) != len(set(values)):
            QMessageBox.warning(self, 'IDの重複', '複数の社員番号に同じスタッフIDが割り当てられています。')
            return
        self.mapping = new_mapping
        super().accept()


class ComparisonBorderDelegate(QStyledItemDelegate):
    """Visually divide the XLSX and CSV comparison columns with thick blue/green rails."""
    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        if index.column() not in (1, 2):
            return
        painter.save()
        painter.setPen(QPen(QColor('#1675dc' if index.column()==1 else '#18a45b'), 3))
        r=option.rect.adjusted(2,0,-2,0)
        painter.drawLine(r.topLeft(),r.bottomLeft())
        painter.drawLine(r.topRight(),r.bottomRight())
        if index.row()==0:
            painter.drawLine(r.topLeft(),r.topRight())
        if index.row()==index.model().rowCount()-1:
            painter.drawLine(r.bottomLeft(),r.bottomRight())
        painter.restore()

class FolderDropLineEdit(QLineEdit):
    """Accept only a folder, never a dropped file (which could replace path text)."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setAcceptDrops(True)
        self.setToolTip('ここに勤怠データフォルダをドロップできます。')

    @staticmethod
    def dropped_folder(event):
        urls = event.mimeData().urls() if event.mimeData().hasUrls() else []
        if len(urls) != 1 or not urls[0].isLocalFile():
            return None
        candidate = Path(urls[0].toLocalFile())
        return str(candidate.resolve()) if candidate.is_dir() else None

    def dragEnterEvent(self, event):
        if self.dropped_folder(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if self.dropped_folder(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        folder = self.dropped_folder(event)
        if folder:
            self.setText(folder)
            event.acceptProposedAction()
        else:
            event.ignore()


class DetailDialog(QDialog):
    FIELDS=DETAIL_REFERENCE_FIELDS

    def __init__(self,parent,row,cfg):
        super().__init__(parent)
        self.setWindowTitle('全項目の対比表')
        self.resize(910,720)
        self.setMinimumSize(760,550)
        self.row=row
        self.cfg=json.loads(json.dumps(cfg))
        root=QVBoxLayout(self)
        root.setContentsMargins(20,18,20,16)
        root.setSpacing(11)
        header=QHBoxLayout()
        title=QVBoxLayout()
        title.addWidget(label('全項目の対比表','pageTitle'))
        title.addWidget(label(f'{row["date"]}   {row["name"]}    社員番号: {row["employee"]}  /  スタッフID: {row["staff"]}', 'muted'))
        header.addLayout(title,1)
        root.addLayout(header)
        header=QHBoxLayout()
        header.setSpacing(8)
        header.addStretch()
        printbtn=button('この対比表を印刷', 'print','primary')
        printbtn.clicked.connect(self.do_print)
        header.addWidget(printbtn)
        previewbtn=button("プレビュー", "print", "secondary")
        previewbtn.clicked.connect(lambda: self.do_print(preview=True))
        header.addWidget(previewbtn)
        optionsbtn=button('表示項目を設定','settings','secondary')
        optionsbtn.clicked.connect(self.edit_visible_fields)
        header.addWidget(optionsbtn)
        root.addLayout(header)
        root.addWidget(label('照合対象外の項目は「参照のみ」と表示します。双方にある項目のみ比較します。','muted'))
        table=QTableWidget(0,4)
        table.setHorizontalHeaderLabels(['項目','派遣元 XLSX','派遣先 CSV','扱い'])
        table.setItemDelegate(ComparisonBorderDelegate(table))
        table.horizontalHeaderItem(1).setForeground(QBrush(QColor(theme_colors(parent.is_dark)['accent'])))
        table.horizontalHeaderItem(2).setForeground(QBrush(QColor(theme_colors(parent.is_dark)['success'])))
        table.cellDoubleClicked.connect(lambda r,c: self.jump_to_excel(self.detail_fields[r][1]) if c==1 else None)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.verticalHeader().hide()
        table.verticalHeader().setDefaultSectionSize(37)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(3,QHeaderView.Fixed)
        table.setColumnWidth(3,120)
        # Merge configured comparisons with the default reference-only items.
        # Keep comparison keys as identity: display labels may be renamed.
        self.detail_fields=detail_fields_for(cfg)
        self.detail_table=table
        self.printrows=[]
        self.printflags=[]
        x=row.get('xrecord')
        c=row.get('crecord')
        enabled={(entry['xlsx'],entry['csv']) for entry in cfg['comparisons'] if entry.get('enabled')}
        for i,(name,xkey,ckey) in enumerate(self.detail_fields):
            a=x['values'].get(xkey) if x else None
            b=c['values'].get(ckey) if c and ckey else None
            comparison=comparison_for_pair(cfg,xkey,ckey)
            selected=next((entry for entry in cfg.get('comparisons',[]) if entry.get('enabled')
                           and entry.get('xlsx')==xkey and entry.get('csv')==ckey
                           and entry.get('name')==row.get('field')),None)
            if selected is not None:
                comparison=selected
                if not cfg.get('field_labels',{}).get('xlsx_columns',{}).get(xkey):name=selected['name']
                self.detail_fields[i]=(name,xkey,ckey)
            typ=(comparison.get('type') if comparison else
                 'clock' if xkey in ('start','end') else
                 'duration' if xkey in ('break_day','break_night','ot_break_day','ot_break_night','break_total','ot','ot_night','holiday_ot','holiday_night','work') else None)
            if typ in ('clock','duration'):
                a=display_time(a,typ)
                b=display_time(b,typ) if b is not None else None
            if xkey=='code' and x:
                a=f'{a}（{x["values"].get("code_label", "")}）'
            checked=(xkey,ckey) in enabled
            flag='照合対象' if checked else '参照のみ'
            if checked and typ not in ('clock','duration','text','number'):flag='要確認（未対応の形式）'
            vals=[name,str(a if a is not None else ''),str(b if b is not None else '—'),flag]
            self.printrows.append(vals)
            self.printflags.append(False)
            table.insertRow(i)
            for j,v in enumerate(vals):
                set_item(table,i,j,v)
            if checked and x and c:
                statuses={r['status'] for r in parent.results
                          if r['employee']==row['employee'] and r['date']==row['date']
                          and r.get('xlsx_key')==xkey and r.get('csv_key')==ckey}
                if '不一致' in statuses:
                    self.printflags[-1]=True
                    for j in (1,2):
                        table.item(i,j).setForeground(QBrush(QColor(theme_colors(parent.is_dark)['error'])))
                        font=table.item(i,j).font();font.setBold(True);table.item(i,j).setFont(font)
        self.apply_visible_fields()
        root.addWidget(table,1)
        jump=button('Excelの該当セルを開く','file','secondary')
        jump.clicked.connect(lambda: self.jump_to_excel(self.detail_fields[table.currentRow()][1]) if 0 <= table.currentRow() < len(self.detail_fields) else QMessageBox.information(self,'行を選択','移動するXLSX項目の行を先に選択してください。'))
        jump.setToolTip('選択中の行のXLSXセルへ移動します。先に対象行を選択してください。')
        jump.setEnabled(bool(x))
        root.addWidget(jump)
        self.source=label(f'XLSX: {Path(x["file"]).name if x else "記録なし"} / {x["sheet"] if x else "—"} / {x["row"] if x else "—"}行\nCSV: {Path(c["file"]).name if c else "記録なし"} / {c["row"] if c else "—"}行','muted')
        root.addWidget(self.source)
        refresh_button_icons(self,parent.is_dark)

    def field_key(self, field):
        return str(field[1]) + '|' + str(field[2] or '')

    def apply_visible_fields(self):
        allowed=self.cfg.get('detail_visible_fields')
        allowed=set(allowed) if isinstance(allowed,list) else None
        for i,field in enumerate(self.detail_fields):
            self.detail_table.setRowHidden(i, allowed is not None and self.field_key(field) not in allowed)

    def edit_visible_fields(self):
        dialog=QDialog(self)
        dialog.setWindowTitle('全項目対比表・表示項目の設定')
        dialog.resize(480,620)
        layout=QVBoxLayout(dialog)
        layout.addWidget(label('対比表の表示項目を選択','pageTitle'))
        layout.addWidget(label('照合項目のON/OFFとは独立しています。変更内容は次回起動時にも保持されます。','muted'))
        area=QScrollArea();area.setWidgetResizable(True)
        panel=QWidget();inner=QVBoxLayout(panel)
        stored=self.cfg.get('detail_visible_fields')
        allowed=set(stored) if isinstance(stored,list) else None
        checks=[]
        for field in self.detail_fields:
            box=QCheckBox(field[0])
            box.setChecked(allowed is None or self.field_key(field) in allowed)
            inner.addWidget(box)
            checks.append(box)
        inner.addStretch(1)
        area.setWidget(panel);layout.addWidget(area,1)
        buttons=QHBoxLayout()
        allbtn=button('すべてON','check','secondary')
        nonebtn=button('すべてOFF','stop','secondary')
        allbtn.clicked.connect(lambda: [box.setChecked(True) for box in checks])
        nonebtn.clicked.connect(lambda: [box.setChecked(False) for box in checks])
        buttons.addWidget(allbtn);buttons.addWidget(nonebtn);buttons.addStretch(1)
        layout.addLayout(buttons)
        actions=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel)
        actions.accepted.connect(dialog.accept);actions.rejected.connect(dialog.reject)
        layout.addWidget(actions)
        refresh_button_icons(dialog,self.parent().is_dark)
        if dialog.exec()==QDialog.Accepted:
            keys={self.field_key(field) for field in self.detail_fields}
            current_cfg=getattr(self.parent(),'cfg',self.cfg)
            stored=current_cfg.get('detail_visible_fields',self.cfg.get('detail_visible_fields',[]))
            extra=[key for key in stored if key not in keys] if isinstance(stored,list) else []
            visible=[self.field_key(field) for field,cb in zip(self.detail_fields,checks) if cb.isChecked()]+extra
            updated=json.loads(json.dumps(current_cfg));updated['detail_visible_fields']=visible
            try:save_json(CONFIG,updated)
            except Exception as exc:
                QMessageBox.warning(self,'表示項目の保存に失敗',str(exc));return
            current_cfg['detail_visible_fields']=list(visible)
            self.cfg['detail_visible_fields']=list(visible)
            self.apply_visible_fields()

    def jump_to_excel(self, field):
        x=self.row.get('xrecord')
        if not x:
            QMessageBox.information(self,'元データなし','該当するXLSX記録がありません。')
            return
        self.parent().open_excel_source(x,field)

    def do_print(self, checked=False, *, preview=False):
        heading='<h2>AttendSync 勤怠詳細対比表</h2><p>'+esc(f'{self.row["date"]}  {self.row["name"]}')+'</p>'
        if not any(not self.detail_table.isRowHidden(i) for i in range(self.detail_table.rowCount())):
            QMessageBox.information(self,'印刷対象なし','表示項目を1つ以上選択してください。')
            return
        body=''
        for i,(row,bad) in enumerate(zip(self.printrows,self.printflags)):
            if self.detail_table.isRowHidden(i):
                continue
            cells=[]
            for j,v in enumerate(row):
                color='border-left:3px solid '+('#1675dc' if j==1 else '#18a45b')+';' if j in (1,2) else ''
                if bad and j in (1,2):color+='color:#c12c3f;font-weight:bold;'
                cells.append('<td style="'+color+'">'+print_cell(v)+'</td>')
            body+='<tr>'+''.join(cells)+'</tr>'
        print_html(self,heading+'<table border="1" width="100%" cellspacing="0" cellpadding="5"><thead><tr><th>項目</th><th style="color:#1675dc">派遣元</th><th style="color:#18a45b">派遣先</th><th>扱い</th></tr></thead>'+body+'</table>', preview=preview)


class ResultsModel(QAbstractTableModel):
    """Virtual rows: faster than populating thousands of QTableWidgetItem widgets."""
    FIELDS=('status','date','employee','name','field','xlsx','csv','staff')
    HEADERS=('判定','日付','社員番号','氏名','項目','派遣元 XLSX','派遣先 CSV','スタッフID')
    def __init__(self,parent=None):
        super().__init__(parent)
        self.rows=[]
        self.dark=False

    def rowCount(self,parent=None):
        return 0 if parent is not None and parent.isValid() else len(self.rows)

    def columnCount(self,parent=None):
        return len(self.FIELDS)

    def headerData(self,section,orientation,role=Qt.DisplayRole):
        if role==Qt.DisplayRole and orientation==Qt.Horizontal:
            return self.HEADERS[section]
        return None

    def data(self,index,role=Qt.DisplayRole):
        if not index.isValid() or not (0<=index.row()<len(self.rows)):
            return None
        r=self.rows[index.row()]
        field=self.FIELDS[index.column()]
        if role==Qt.DisplayRole:
            return str(r.get(field,'') or '')
        if role==Qt.ToolTipRole:
            return str(r.get(field,'') or '')
        if role==Qt.TextAlignmentRole:
            return int(Qt.AlignVCenter | (Qt.AlignCenter if index.column() in (0,1) else Qt.AlignLeft))
        if role==Qt.ForegroundRole and index.column()==0:
            return QBrush(QColor(theme_colors(self.dark)[{'一致':'success','不一致':'error','要確認':'warning'}.get(r['status'],'muted')]))
        if role==Qt.ForegroundRole and index.column() in (5,6) and r['status']=='不一致':
            return QBrush(QColor(theme_colors(self.dark)['error']))
        return None

    def set_rows(self,rows,dark=False):
        self.beginResetModel()
        self.rows=rows
        self.dark=dark
        self.endResetModel()


class ElidedLabel(QLabel):
    """Keep complete status text for accessibility, elide only the painted line."""
    def __init__(self, text='', parent=None):
        super().__init__(text,parent)
        self.setWordWrap(False)
        self.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self.setMinimumWidth(0)

    def paintEvent(self,event):
        painter=QPainter(self)
        text=self.fontMetrics().elidedText(self.text(),Qt.ElideRight,self.contentsRect().width())
        self.style().drawItemText(painter,self.contentsRect(),int(self.alignment()),self.palette(),self.isEnabled(),text,QPalette.WindowText)


class ResultsEmptyState(QWidget):
    def __init__(self, viewport):
        super().__init__(viewport)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        viewport.installEventFilter(self)
        self.setGeometry(viewport.rect())
        root=QVBoxLayout(self)
        root.setContentsMargins(20,12,20,12)
        root.setSpacing(7)
        root.addStretch()
        self.glyph=QLabel();self.glyph.setAlignment(Qt.AlignCenter)
        self.glyph.setVisible(viewport.height()>=140)
        root.addWidget(self.glyph)
        self.title=label('照合結果はここに表示されます','emptyTitle')
        self.title.setAlignment(Qt.AlignCenter);root.addWidget(self.title)
        self.caption=label('対象フォルダと月度を選び、「読み込み・照合」を押してください。','muted')
        self.caption.setAlignment(Qt.AlignCenter);root.addWidget(self.caption)
        root.addStretch()

    def set_message(self,title,caption):
        self.title.setText(title);self.caption.setText(caption)

    def refresh_icon(self,dark):
        self.glyph.setPixmap(icon('table',theme_colors(dark)['muted'],32).pixmap(32,32))

    def eventFilter(self,watched,event):
        if event.type()==QEvent.Resize:
            self.setGeometry(watched.rect())
            self.glyph.setVisible(watched.height()>=140)
        return super().eventFilter(watched,event)


class ResultStatusDelegate(QStyledItemDelegate):
    """Readable status pills, retaining the table's native selection/focus."""
    def paint(self,painter,option,index):
        opt=QStyleOptionViewItem(option);self.initStyleOption(opt,index)
        text=opt.text;opt.text=''
        opt.widget.style().drawControl(QStyle.CE_ItemViewItem,opt,painter,opt.widget)
        colors=theme_colors(getattr(index.model(),'dark',False))
        semantic={'一致':'success','不一致':'error','要確認':'warning'}.get(text)
        if not semantic:
            super().paint(painter,option,index);return
        painter.save();painter.setRenderHint(QPainter.Antialiasing)
        pill=QRectF(option.rect.center().x()-34,option.rect.center().y()-12,68,24)
        painter.setPen(Qt.NoPen);painter.setBrush(QColor(colors['soft_'+semantic]))
        painter.drawRoundedRect(pill,6,6)
        painter.setPen(QColor(colors[semantic]));font=QFont(option.font);font.setBold(True);painter.setFont(font)
        painter.drawText(pill,Qt.AlignCenter,text);painter.restore()


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        try:
            self.cfg=load_json(CONFIG,DEFAULT)
            SettingsDialog.validate_json_config(self.cfg)
        except Exception as exc:
            raise ValueError(f'設定ファイルを読み込めません：{CONFIG}\n{exc}') from exc
        try:
            self.mapping=load_json(MAP,{})
            if not isinstance(self.mapping,dict) or not all(isinstance(key,str) and key.strip() and isinstance(value,str) for key,value in self.mapping.items()):
                raise ValueError('社員ID対応は社員番号とスタッフIDの文字列で指定してください。')
        except Exception as exc:
            raise ValueError(f'社員ID対応ファイルを読み込めません：{MAP}\n{exc}') from exc
        # Apply the local date once on startup; keep manual choices for this session.
        self.cfg['year'],self.cfg['month']=current_attendance_month()
        self.results=[]
        self.results_cfg=None
        self.comparison_summary=None
        self.loaded_xdata={}
        self.loaded_cdata=[]
        self.visible=[]
        self.issues=[]
        self.read_diagnostics={'failures':[], 'warnings':[], 'other':[]}
        self.filter_state='不一致のみ'
        self.is_dark=self.cfg.get('theme','light')=='dark'
        apply_theme(QApplication.instance(),self.is_dark)
        self.setWindowTitle('AttendSync | 勤怠照合')
        from PySide6.QtGui import QIcon
        self.setWindowIcon(QIcon(str(application_dir()/'AttendSync.ico')))
        self.resize(1280,860)
        self.setMinimumSize(1040,690)
        root=QWidget()
        root.setObjectName('mainCanvas')
        self.setCentralWidget(root)
        outer=QVBoxLayout(root)
        outer.setContentsMargins(24,14,24,12)
        outer.setSpacing(6)

        header=QHBoxLayout()
        header.setSpacing(14)
        mark=QLabel()
        mark.setObjectName('brandMark')
        mark.setFixedSize(48,48)
        mark.setAlignment(Qt.AlignCenter)
        mark.setPixmap(self.windowIcon().pixmap(38,38))
        header.addWidget(mark)
        titleblock=QVBoxLayout()
        titleblock.setSpacing(2)
        titleblock.addWidget(label('AttendSync', 'appTitle'))
        titleblock.addWidget(label('勤怠照合  ·  派遣元と派遣先の記録を、ひとつの画面で。', 'subtitle'))
        header.addLayout(titleblock,1)
        self.btn_theme=button('ダーク表示' if not self.is_dark else 'ライト表示','moon' if not self.is_dark else 'sun','quiet')
        self.btn_theme.clicked.connect(self.toggle_theme)
        self.btn_map=button('社員ID管理','users','quiet')
        self.btn_map.clicked.connect(self.edit_map)
        self.btn_settings=button('設定','settings','quiet')
        self.btn_settings.clicked.connect(self.edit_settings)
        self.btn_manual=button('操作マニュアル','book','quiet',tooltip='画像付きの操作マニュアルを開きます（F1）')
        self.btn_manual.clicked.connect(self.open_manual)
        self.manual_action=QAction('操作マニュアル',self)
        self.manual_action.setShortcut('F1');self.manual_action.triggered.connect(self.open_manual)
        self.addAction(self.manual_action)
        for widget in (self.btn_theme,self.btn_map,self.btn_settings,self.btn_manual):header.addWidget(widget)
        outer.addLayout(header)

        source_card=card_box()
        source_card.setObjectName('sourceCard')
        sl=QVBoxLayout(source_card)
        sl.setContentsMargins(18,10,18,10)
        sl.setSpacing(6)
        row=QHBoxLayout()
        row.setSpacing(10)
        step=label('01','stepBadge');step.setAlignment(Qt.AlignCenter);step.setFixedSize(28,26)
        row.addWidget(step)
        row.addWidget(label('データの読み込み','sectionTitle'))
        self.path=FolderDropLineEdit(self.cfg.get('folder',''))
        self.path.setPlaceholderText('XLSX と CSV が入ったフォルダを選択、またはドロップ')
        self.path.setMinimumHeight(40)
        self.path.setToolTip('対象フォルダ：社員別XLSXと月別CSVを同じフォルダへ配置してください。')
        row.addWidget(self.path,1)
        self.btn_browse=button('フォルダ選択','folder')
        self.btn_browse.clicked.connect(self.browse)
        row.addWidget(self.btn_browse)
        sl.addLayout(row)
        row=QHBoxLayout()
        row.setSpacing(8)
        month_caption=label('対象月度','fieldHint');month_caption.setWordWrap(False)
        row.addWidget(month_caption)
        self.year=QSpinBox()
        self.year.setRange(2000,2100)
        self.year.setValue(int(self.cfg.get('year',2026)))
        self.year.setSuffix(' 年')
        self.year.setFixedWidth(104)
        row.addWidget(self.year)
        self.month=QSpinBox()
        self.month.setRange(1,12)
        self.month.setValue(int(self.cfg.get('month',10)))
        self.month.setSuffix(' 月度')
        period_help='起動時のPCの日付の年・月を対象月度に自動設定します。例：10月中は10月度（9/16～10/15）。手動変更もできます。'
        self.year.setToolTip(period_help)
        self.month.setToolTip(period_help)
        self.month.setFixedWidth(96)
        row.addWidget(self.month)
        self.period_hint=label('','periodHint')
        self.period_hint.setWordWrap(False)
        row.addWidget(self.period_hint)
        self.year.valueChanged.connect(self.update_period_hint)
        self.month.valueChanged.connect(self.update_period_hint)
        self.update_period_hint()
        row.addStretch()
        self.full_button=button('完全再読み込み','refresh','quiet',tooltip='キャッシュを使わず全ファイルを再解析します')
        self.full_button.clicked.connect(lambda:self.run_read(True))
        self.stop_button=button('中止','stop','danger')
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_read)
        self.run_button=button('読み込み・照合','play','primary')
        self.run_button.clicked.connect(self.run_read)
        row.addWidget(self.full_button)
        row.addWidget(self.stop_button)
        row.addWidget(self.run_button)
        sl.addLayout(row)
        outer.addWidget(source_card)

        metrics=QHBoxLayout()
        metrics.setSpacing(12)
        self.metric_values={}
        self.metric_icons={}
        for title,key,glyph,caption in [('対象社員','people','users','読み込み済みの社員'),('一致','ok','check','比較項目の一致数'),('不一致','bad','x','差異のある比較項目'),('要確認','review','alert','確認が必要な比較項目')]:
            tile=card_box();tile.setObjectName('metricCard')
            tile.setProperty('metric',key)
            v=QHBoxLayout(tile)
            v.setContentsMargins(14,10,14,10)
            v.setSpacing(8)
            glyph_label=label('','metricIcon')
            glyph_label.setFixedSize(26,26);glyph_label.setAlignment(Qt.AlignCenter)
            glyph_label.setProperty('metric',key)
            self.metric_icons[key]=(glyph_label,glyph)
            v.addWidget(glyph_label)
            v.addWidget(label(title,'metricTitle'))
            v.addStretch()
            number=label('—','metricValue')
            number.setProperty('metric',key)
            number.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
            number.setWordWrap(False)
            v.addWidget(number)
            tile.setToolTip(caption)
            number.setToolTip(caption)
            self.metric_values[key]=number
            metrics.addWidget(tile,1)
        outer.addLayout(metrics)

        resultcard=card_box();resultcard.setObjectName('resultCard')
        resultlayout=QVBoxLayout(resultcard)
        resultlayout.setContentsMargins(18,10,18,9)
        resultlayout.setSpacing(6)
        title_row=QHBoxLayout()
        step=label('02','stepBadge');step.setAlignment(Qt.AlignCenter);step.setFixedSize(28,26)
        title_row.addWidget(step)
        title_row.addWidget(label('照合結果','sectionTitle'))
        title_row.addStretch()
        self.print_button=button('表示リストを印刷','print','quiet')
        self.print_button.setEnabled(False)
        self.print_button.clicked.connect(self.print_list)
        title_row.addWidget(self.print_button)
        self.preview_button=button('プレビュー','eye','quiet')
        self.preview_button.setEnabled(False)
        self.preview_button.clicked.connect(lambda: self.print_list(preview=True))
        title_row.addWidget(self.preview_button)
        resultlayout.addLayout(title_row)
        self.total_formula=label('全数：照合項目数 × 対象社員数 × 月度日数 ＝ 照合予定件数','fieldHint')
        self.total_formula.setObjectName('totalFormula')
        self.total_formula.setWordWrap(True)
        self.total_check=label('読み込み後に、全数と一致数・未照合数を表示します。','muted')
        self.total_check.setObjectName('totalCheck')
        self.total_check.setWordWrap(True)
        summary_layout=QVBoxLayout()
        summary_layout.setSpacing(2)
        summary_layout.addWidget(self.total_formula)
        summary_layout.addWidget(self.total_check)
        resultlayout.addLayout(summary_layout)
        tool=QHBoxLayout()
        tool.setSpacing(6)
        self.filter_buttons={}
        for text in ('不一致のみ','一致のみ','すべて'):
            b=button(text,'','segment')
            b.setCheckable(True)
            b.setChecked(text==self.filter_state)
            b.clicked.connect(lambda checked,t=text:self.select_filter(t))
            self.filter_buttons[text]=b
            tool.addWidget(b)
        tool.addStretch()
        self.search=QLineEdit()
        self.search.setPlaceholderText('社員番号・氏名で検索')
        self.search.setClearButtonEnabled(True)
        self.search.addAction(icon('search',theme_colors(self.is_dark)['muted']),QLineEdit.LeadingPosition)
        self.search.setMinimumWidth(220)
        self.search.setMaximumWidth(320)
        self.search.textChanged.connect(self.show_results)
        tool.addWidget(self.search,1)
        resultlayout.addLayout(tool)
        self.model=ResultsModel(self)
        self.table=QTableView()
        self.table.setModel(self.model)
        self.table.setItemDelegateForColumn(0,ResultStatusDelegate(self.table))
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(True)
        self.table.setGridStyle(Qt.SolidLine)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(40)
        self.table.horizontalHeader().setStretchLastSection(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setMinimumSectionSize(70)
        for col,width in enumerate((90,108,92,160,125,120,120,108)):
            self.table.setColumnWidth(col,width)
        self.table.horizontalHeader().setSectionResizeMode(4,QHeaderView.Stretch)
        self.table.doubleClicked.connect(self.open_detail)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.context_menu)
        resultlayout.addWidget(self.table,1)
        self.empty_state=ResultsEmptyState(self.table.viewport())
        resultfoot=QHBoxLayout()
        self.count_label=label('表示 0 件','muted');self.count_label.setWordWrap(False)
        resultfoot.addWidget(self.count_label)
        resultfoot.addStretch()
        help_label=label('ダブルクリックで詳細  ·  右クリックで元のExcelへ','muted')
        help_label.setWordWrap(False)
        resultfoot.addWidget(help_label)
        resultlayout.addLayout(resultfoot)
        outer.addWidget(resultcard,1)

        status_card=card_box();status_card.setObjectName('statusCard')
        status_layout=QVBoxLayout(status_card)
        status_layout.setContentsMargins(13,8,13,8)
        status_layout.setSpacing(6)
        bottom=QHBoxLayout()
        self.status=ElidedLabel('フォルダを選択して、読み込みを開始してください。')
        self.status.setObjectName('statusLabel')
        bottom.addWidget(self.status,1)
        self.progress=QProgressBar()
        self.progress.setFixedWidth(115)
        self.progress.setValue(0)
        self.progress.setTextVisible(True)
        bottom.addWidget(self.progress)
        self.btn_diagnostics=button('読み込み診断','alert-circle','quiet')
        self.btn_diagnostics.setMinimumHeight(30)
        self.btn_diagnostics.clicked.connect(self.show_diagnostics)
        bottom.addWidget(self.btn_diagnostics)
        self.btn_logs=button('ログを表示','list','quiet')
        self.btn_logs.setMinimumHeight(30)
        self.btn_logs.clicked.connect(self.show_log_window)
        bottom.addWidget(self.btn_logs)
        status_layout.addLayout(bottom)
        log_row=QHBoxLayout()
        log_caption=label('最新ログ','eyebrow');log_caption.setWordWrap(False)
        log_row.addWidget(log_caption)
        self.log_line=QLineEdit()
        self.log_line.setObjectName('latestLog')
        self.log_line.setReadOnly(True)
        self.log_line.setPlaceholderText('ログはありません')
        self.log_line.setToolTip('最新のログ。全件を見るには「ログを表示」を押してください。')
        self.log_line.setMinimumHeight(26)
        log_row.addWidget(self.log_line,1)
        status_layout.addLayout(log_row)
        outer.addWidget(status_card)
        self.log_history=[]
        self.worker=None
        self._close_after_worker=False
        self.refresh_semantic_icons()
        refresh_button_icons(self,self.is_dark)

    def update_period_hint(self):
        from datetime import date
        year,month=self.year.value(),self.month.value()
        previous=date(year-1,12,16) if month==1 else date(year,month-1,16)
        end=date(year,month,15)
        days=(end-previous).days+1
        self.period_hint.setText(f'{previous.month}/{previous.day} – {end.month}/{end.day}（{days}日）')
        self.period_hint.setToolTip(f'{previous:%Y/%m/%d} ～ {end:%Y/%m/%d}（両端・休日を含む{days}日）')

    def update_comparison_summary(self,cfg,coverage,incomplete):
        total=comparison_totals(self.loaded_xdata,self.results,cfg)
        self.comparison_summary=total
        self.total_formula.setText(
            f'全数：照合 {total["items"]:,}項目 × 対象社員 {total["employees"]:,}人 × 月度 {total["days"]}日'
            f' ＝ {total["expected"]:,}件（{cfg["year"]}年{cfg["month"]}月度）')
        complete=(total['expected']>0 and total['matched']==total['expected']
                  and not any(total[key] for key in ('mismatched','review','missing','duplicates','outside','additional_review'))
                  and coverage['complete'] and not incomplete)
        state=('全数一致' if complete else '照合項目がすべてOFF' if not total['items'] else
               '対象社員なし' if not total['employees'] else '全数一致に未達')
        extra=f' · 追加の要確認 {total["additional_review"]:,}件' if total['additional_review'] else ''
        if total['duplicates'] or total['outside']:
            extra+=f' · 集計対象の異常 {total["duplicates"]+total["outside"]:,}件'
        if incomplete:extra+=' · 読み込み未完了'
        self.total_check.setText(
            f'一致 {total["matched"]:,} / 全数 {total["expected"]:,}件 ｜ 不一致 {total["mismatched"]:,}'
            f' · 判定要確認 {total["review"]:,} · 未照合 {total["missing"]:,}件{extra} ｜ {state}')
        explanation=(
            '休日・両端の日付を含む月度日数 × 読み込み済みのXLSX社員数 × ONの照合項目数で計算します。\n'
            '設定変更は再読み込み後に反映します。検索・表示フィルターでは全数は変わりません。\n'
            '全数 ＝ 一致 ＋ 不一致 ＋ 判定要確認 ＋ 未照合。\n'
            '欠損・重複・未紐付けで比較できない項目は未照合です。診断用の要確認行は追加の通知として別計上します。\n'
            '読み込みに失敗した社員の人数は特定できないため、表示全数は読み込み済み社員だけの予定件数です。')
        self.total_formula.setToolTip(explanation)
        self.total_check.setToolTip(explanation)

    def refresh_semantic_icons(self):
        colors=theme_colors(self.is_dark)
        for key,(widget,glyph) in self.metric_icons.items():
            semantic={'people':'accent','ok':'success','bad':'error','review':'warning'}[key]
            widget.setPixmap(icon(glyph,colors[semantic],16).pixmap(16,16))
        self.empty_state.refresh_icon(self.is_dark)
        self.search.actions()[0].setIcon(icon('search',colors['muted']))

    def toggle_theme(self):
        updated=json.loads(json.dumps(self.cfg))
        updated['theme']='light' if self.is_dark else 'dark'
        try:save_json(CONFIG,updated)
        except Exception as exc:
            QMessageBox.warning(self,'設定の保存に失敗',str(exc));return
        self.cfg=updated
        self.is_dark=not self.is_dark
        apply_theme(QApplication.instance(),self.is_dark)
        self.btn_theme.setText('ライト表示' if self.is_dark else 'ダーク表示')
        self.btn_theme.setProperty('glyph','sun' if self.is_dark else 'moon')
        refresh_button_icons(self,self.is_dark)
        self.model.set_rows(self.visible,self.is_dark)
        self.refresh_semantic_icons()

    def open_manual(self):
        from manual import open_manual
        return open_manual(self)

    def browse(self):
        folder=QFileDialog.getExistingDirectory(self,'勤怠フォルダを指定',self.path.text() or str(Path.home()))
        if folder:self.path.setText(folder)

    def edit_settings(self):
        dlg=SettingsDialog(self,self.cfg)
        if dlg.exec():
            try:save_json(CONFIG,dlg.value)
            except Exception as exc:
                QMessageBox.warning(self,'設定の保存に失敗',str(exc));return
            old=self.cfg
            self.cfg=dlg.value
            for key,control in [('folder',self.path),('year',self.year),('month',self.month)]:
                if self.cfg.get(key,DEFAULT[key])!=old.get(key,DEFAULT[key]):
                    value=self.cfg.get(key,DEFAULT[key])
                    control.setText(value) if key=='folder' else control.setValue(value)
            self.status.setText('設定を保存しました。次の読み込みで反映します。')

    def edit_map(self):
        dialog=QDialog(self)
        dialog.setWindowTitle('社員ID管理 | AttendSync')
        dialog.resize(950,680)
        dialog.setMinimumSize(760,510)
        layout=QVBoxLayout(dialog)
        layout.setContentsMargins(18,16,18,16)
        layout.setSpacing(10)
        layout.addWidget(label('社員ID管理','pageTitle'))
        layout.addWidget(label('派遣元の社員番号を基準に、未使用のスタッフIDを選択するか直接入力できます。','muted'))
        # Current imported staff IDs and XLSX employees are remembered only in memory.
        packets=getattr(self,'loaded_xdata',{})
        csv_rows=getattr(self,'loaded_cdata',[])
        employees={str(k): str(v.get('info',{}).get('name','') or v.get('name','') or (v.get('records') or [{}])[0].get('name',''))
                   for k,v in packets.items() if isinstance(v,dict)}
        employees.update({str(k):employees.get(str(k),'') for k in self.mapping})
        staff_names={}
        for r in csv_rows:
            sid=str(r.get('staff','') or '').strip()
            if sid:staff_names.setdefault(sid,str(r.get('name','') or ''))
        assigned={str(v).strip() for v in self.mapping.values() if str(v).strip()}
        unused=sorted(k for k in staff_names if k not in assigned)
        toolbar=QHBoxLayout()
        unlinked=button('すべて表示','users')
        unlinked.setCheckable(True)
        unlinked.setChecked(True)
        toolbar.addWidget(unlinked)
        toolbar.addWidget(label(f'社員：{len(employees)}人  /  未使用スタッフID：{len(unused)}件','muted'))
        toolbar.addStretch()
        layout.addLayout(toolbar)
        table=QTableWidget(0,3)
        table.setHorizontalHeaderLabels(['社員番号（XLSX）','氏名','スタッフID（CSV）'])
        table.verticalHeader().hide()
        table.setAlternatingRowColors(True)
        table.verticalHeader().setDefaultSectionSize(44)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        edits=[]
        def row_for(eid,name,sid):
            i=table.rowCount();table.insertRow(i)
            table.setItem(i,0,QTableWidgetItem(str(eid)))
            set_item(table,i,1,str(name))
            combo=QComboBox();combo.setEditable(True)
            combo.setInsertPolicy(QComboBox.NoInsert)
            combo.addItem('未紐付け','')
            # Candidate IDs already assigned to another employee must not be offered.
            for candidate in sorted(unused, key=lambda sid: (normalize_name(staff_names.get(sid,'')) != normalize_name(name), sid)):
                combo.addItem(f'{candidate}  —  {staff_names.get(candidate,"")}',candidate)
            if sid and combo.findData(sid)<0:
                combo.addItem(f'{sid}  —  {staff_names.get(sid, "")}',sid)
            idx=combo.findData(sid) if sid else 0
            combo.setCurrentIndex(max(0,idx))
            combo.setToolTip('候補を選択、またはスタッフIDを直接入力')
            table.setCellWidget(i,2,combo)
            edits.append((eid,combo))
            combo.activated.connect(lambda _=None: filter_rows())
            combo.lineEdit().editingFinished.connect(lambda: filter_rows())
        for eid in sorted(employees):row_for(eid,employees[eid],str(self.mapping.get(eid,'')).strip())
        def filter_rows():
            showing_unlinked=unlinked.isChecked()
            unlinked.setText('すべて表示' if showing_unlinked else '未紐づけを表示')
            for i,(eid,combo) in enumerate(edits):
                table.setRowHidden(i,showing_unlinked and bool(selected_staff_id(combo)))
        unlinked.clicked.connect(filter_rows)
        # Open all employees when there are no unlinked rows to work on.
        unlinked.setChecked(any(not selected_staff_id(combo) for _,combo in edits))
        filter_rows()
        layout.addWidget(table,1)
        footer=QHBoxLayout()
        add=button('社員番号を追加','plus')
        def add_row():
            row_for('','', '')
            table.setRowHidden(table.rowCount()-1,False)
            table.setCurrentCell(table.rowCount()-1,0)
        add.clicked.connect(add_row)
        footer.addWidget(add)
        footer.addStretch()
        cancel=button('キャンセル','x');cancel.clicked.connect(dialog.reject)
        save=button('紐付けを保存','save','primary')
        footer.addWidget(cancel);footer.addWidget(save)
        layout.addLayout(footer)
        def do_save():
            try:
                table.setCurrentCell(-1,-1)
                result={}
                for i,(_,combo) in enumerate(edits):
                    eid=(table.item(i,0).text() if table.item(i,0) else '').strip()
                    sid=selected_staff_id(combo)
                    if not eid and not sid:continue
                    if not eid:raise ValueError(f'{i+1}行目の社員番号が空欄です。')
                    if eid in result:raise ValueError('社員番号の重複：'+eid)
                    if sid:result[eid]=sid
                ids=list(result.values())
                if len(ids)!=len(set(ids)):raise ValueError('同じスタッフIDが複数の社員に割り当てられています。')
                unknown=[sid for sid in ids if staff_names and sid not in staff_names]
                if unknown and QMessageBox.question(dialog,'候補外のスタッフID',
                      'CSVに存在しないスタッフIDがあります：'+', '.join(unknown[:8])+'\nこのまま登録しますか？',
                      QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
                save_json(MAP,result)
                self.mapping=result
                dialog.accept()
                # Recompute results with the new ID assignments (worker reuses valid caches).
                QTimer.singleShot(0, lambda: self.run_read())
            except Exception as e:
                QMessageBox.warning(dialog,'紐付け表のエラー',str(e))
        save.clicked.connect(do_save)
        refresh_button_icons(dialog,self.is_dark)
        dialog.exec()

    def run_read(self,full=False):
        if self.worker is not None and self.worker.isRunning():return
        folder_text=self.path.text().strip()
        folder=Path(folder_text)
        try:folder_valid=bool(folder_text) and folder.is_dir()
        except OSError as exc:
            QMessageBox.warning(self,'フォルダの読み込みに失敗',str(exc));return
        if not folder_valid:
            QMessageBox.warning(self,'フォルダ指定','有効なフォルダを選択してください。')
            return
        updated=json.loads(json.dumps(self.cfg))
        updated['folder']=str(folder)
        updated['year']=self.year.value()
        updated['month']=self.month.value()
        errors=validate_config(updated)
        if errors:
            QMessageBox.warning(self,'読み込み設定エラー','\n'.join(errors[:20]))
            return
        try:
            candidates_files=[p for p in folder.iterdir() if p.is_file() and not p.name.startswith('~$')]
        except OSError as exc:
            QMessageBox.warning(self,'フォルダの読み込みに失敗',str(exc));return
        xlsx_count=sum(p.suffix.lower()=='.xlsx' for p in candidates_files)
        csv_count=sum(p.suffix.lower()=='.csv' for p in candidates_files)
        if xlsx_count==0 or csv_count==0:
            QMessageBox.warning(self,'入力ファイル不足',f'XLSX {xlsx_count}件 / CSV {csv_count}件です。両方必要です。')
            return
        try:save_json(CONFIG,updated)
        except Exception as exc:
            QMessageBox.warning(self,'設定の保存に失敗',str(exc));return
        self.cfg=updated
        self.run_button.setEnabled(False)
        self.full_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status.setText('ファイルの読み込み中…')
        if not self.visible:
            self.empty_state.set_message('読み込み・照合中…','ファイルを確認しています。中止する場合は「中止」を押してください。')
        self.progress.setValue(0)
        self.set_log_history([])
        self.worker=ReadWorker(folder,self.cfg,full)
        self.worker.progress.connect(self.on_progress)
        self.worker.result.connect(self.read_done)
        self.worker.finished.connect(self.worker_finished)
        self.worker.start()

    def worker_finished(self):
        if self.sender() is not self.worker:
            return
        self.run_button.setEnabled(True)
        self.full_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        if self._close_after_worker:self.close()

    def stop_read(self):
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.status.setText('中止処理中…')
            self.stop_button.setEnabled(False)

    def on_progress(self,n,total,name):
        if self.sender() is not self.worker:
            return
        if self.worker is not None and self.worker.isInterruptionRequested():
            return
        self.progress.setValue(round(n/max(total,1)*100))
        self.status.setText(f'読み込み {n}/{total}　{name}')

    def read_done(self,xdata,cdata,issues,stats):
        if self.sender() is not self.worker:
            return
        if self.worker is not None and self.worker.isInterruptionRequested():
            stats=dict(stats, cancelled=True)
        if stats.get('cancelled'):
            self.status.setText('読み込み中止 / 前回の結果を維持しました')
            self.progress.setValue(0)
            self.set_log_history([str(v) for v in issues])
            self.show_results()
            return
        if stats.get('fatal_error') and not stats.get('cancelled'):
            reason=str(stats['fatal_error'])
            self.issues=list(issues) or [reason]
            self.read_diagnostics={'failures':[{'file':'読み込み処理','reason':reason}]+list(stats.get('file_errors',[])),
                                   'warnings':list(stats.get('read_warnings',[])),'other':list(self.issues)}
            self.btn_diagnostics.setText('読み込み診断 (失敗 {0} / 注意 {1})'.format(len(self.read_diagnostics['failures']),len(self.read_diagnostics['warnings'])))
            self.status.setText('読み込み失敗 / 前回の結果を維持しました')
            self.status.setToolTip(reason)
            self.progress.setValue(0)
            self.set_log_history(self.issues)
            self.show_results()
            if not self.visible:self.empty_state.set_message('読み込みに失敗しました','読み込み診断で原因を確認してください。')
            return
        cfg=json.loads(json.dumps(getattr(self.worker,'cfg',self.cfg)))
        self.results_cfg=cfg
        self.issues=list(issues)
        self.read_diagnostics={
            'failures': list(stats.get('file_errors',[])),
            'warnings': list(stats.get('read_warnings',[])),
            'other': list(issues),
        }
        self.btn_diagnostics.setText('読み込み診断 (失敗 {0} / 注意 {1})'.format(
            len(self.read_diagnostics['failures']), len(self.read_diagnostics['warnings'])))
        self.loaded_xdata=xdata
        self.loaded_cdata=cdata
        if not cdata:
            self.issues.append('【未完了】CSVの有効な勤怠行が0件です。CSV設定・対象ファイルを確認してください。')
        if stats.get('file_errors'):
            self.issues.append('【未完了】読み込み失敗したファイルがあります。該当ファイルを再確認してください。')
        # Distinguish attempted, successfully imported, and failed sources.
        # Some error branches increment files_completed, while earlier failures do not.
        # Therefore never treat files_completed + file_errors as a trustworthy sum.
        found=stats.get('files_found')
        completed=stats.get('files_completed')
        failed=len(stats.get('file_errors', []))
        if found is not None and completed is not None and completed < found:
            # Already accounted for failures may be inside completed; show the raw
            # counts rather than claiming a mathematically exact missing count.
            self.issues.append(
                f'【未完了】検出 {found}件 / 処理報告 {completed}件 / 読み込み失敗 {failed}件。'
                'ファイル単位の読み込み状況を診断画面で確認してください。')
        if failed:
            self.issues.append(f'【未完了】{failed}件のファイルを読み込めませんでした。照合完了とは判断できません。')
        proposed_mapping=dict(self.mapping)
        missing=candidates(xdata,cdata,proposed_mapping)
        if proposed_mapping!=self.mapping:
            try:save_json(MAP,proposed_mapping)
            except Exception as exc:
                self.issues.append(f'【保存失敗】社員IDの自動紐付けを保存できませんでした：{exc}')
            else:self.mapping=proposed_mapping
        used=[s for s in self.mapping.values() if s]
        if len(used)!=len(set(used)):
            self.issues.append('既存の社員ID紐付けに重複があります。')
        if missing:
            dlg=MappingDialog(self,missing,self.mapping)
            if dlg.exec():
                try:save_json(MAP,dlg.mapping)
                except Exception as exc:
                    self.issues.append(f'【保存失敗】社員IDの紐付けを保存できませんでした：{exc}')
                    QMessageBox.warning(self,'紐付けの保存に失敗',str(exc))
                else:self.mapping=dlg.mapping
        duplicates={eid:packet for eid,packet in xdata.items() if packet.get('duplicate_xlsx')}
        safe={eid:packet for eid,packet in xdata.items() if eid not in duplicates}
        self.results,problems=reconcile(safe,cdata,self.mapping,cfg)
        self.issues.extend(problems)
        for eid,packet in duplicates.items():
            sources=packet.get('duplicate_sources',[])
            self.issues.append(f"{eid}: 重複XLSXのため照合を保留 / 候補: {', '.join(Path(src['file']).name for src in sources)}")
            for source in sources:
                for rec in source.get('records',[]):
                    self.results.append({'date':rec['date'],'employee':eid,'staff':self.mapping.get(eid,''),
                                         'name':rec['name'],'field':'XLSX重複・照合保留','xlsx':Path(source['file']).name,'csv':'—',
                                         'status':'要確認','xrecord':rec,'crecord':None})
        for warning in stats.get('read_warnings',[]):
            self.issues.append(f"【読込注意】{warning['file']}: {warning['reason']}")
            # Unparseable date/ID rows have no reliable employee/day association.
            # Show them as review items instead of hiding them only in diagnostics.
            reason=str(warning.get('reason',''))
            if '日付不正' in reason or 'IDまたは日付が空欄' in reason:
                self.results.append({'date':'—','employee':'—','staff':'','name':warning['file'],
                    'field':'CSV行の識別情報不正','xlsx':'—','csv':reason,
                    'status':'要確認','xrecord':None,'crecord':None})
        for failure in stats.get('file_errors',[]):
            self.results.append({'date':'—','employee':'—','staff':'','name':failure['file'],
                                 'field':'ファイル読み込み失敗','xlsx':failure['reason'],'csv':'—',
                                 'status':'要確認','xrecord':None,'crecord':None})
        for eid,packet in xdata.items():
            if not packet.get('records') and not packet.get('duplicate_xlsx'):
                self.results.append({'date':'—','employee':eid,'staff':self.mapping.get(eid,''),
                                     'name':packet.get('info',{}).get('name',''), 'field':'対象期間の勤怠行なし',
                                     'xlsx':'—','csv':'—','status':'要確認','xrecord':None,'crecord':None})
                self.issues.append(f'{eid}: 対象期間の勤怠行なし')
        coverage=coverage_report(xdata,cdata,self.mapping,cfg)
        existing={(str(r.get('employee')),str(r.get('date'))) for r in self.results if r.get('status')=='要確認'}
        for gap in coverage['review']:
            key=(str(gap['employee']),str(gap['date']))
            if key in existing:
                continue
            self.results.append({'date':gap['date'],'employee':gap['employee'],'staff':gap['staff'],
                                 'name':xdata.get(gap['employee'],{}).get('info',{}).get('name',''),
                                 'field':'期間整合性：'+gap['reason'],'xlsx':str(gap['xlsx_count'])+'行',
                                 'csv':str(gap['csv_count'])+'行','status':'要確認','xrecord':None,'crecord':None})
            existing.add(key)
        self.issues.append('照合範囲検証：対象 '+str(coverage['expected_employee_days'])+'日 / XLSX '+str(coverage['xlsx_days_present'])+'日 / CSV '+str(coverage['csv_days_present'])+'日 / 要確認 '+str(len(coverage['review']))+'日')
        if not coverage['complete']:
            self.issues.append('【未完了】照合対象に欠落・重複・未紐付けがあります。全件照合完了とは判断しないでください。')
        self.results.sort(key=lambda r:(r['employee'],r['date'],r['field']))
        self.metric_values['people'].setText(f'{len(xdata):,}')
        count=Counter(r['status'] for r in self.results)
        self.metric_values['ok'].setText(f"{count['一致']:,}")
        self.metric_values['bad'].setText(f"{count['不一致']:,}")
        self.metric_values['review'].setText(f"{count['要確認']:,}")
        self.show_results()
        self.set_log_history(self.issues or ['読み込みエラーなし'])
        self.progress.setValue(100 if not (found is not None and completed is not None and completed < found) else round(100*completed/max(found,1)))
        incomplete = bool(stats.get('file_errors')) or (not cdata) or (not coverage['complete']) or (found is not None and completed is not None and completed < found)
        self.update_comparison_summary(cfg,coverage,incomplete)
        prefix = '要確認・読み込み未完了' if incomplete else '読込完了'
        if any('【保存失敗】' in issue for issue in self.issues):prefix=(prefix+' / 保存失敗') if incomplete else '要確認・保存失敗'
        elif not any(entry.get('enabled') for entry in cfg['comparisons']):
            prefix+=' / 照合項目がすべてOFF'
        self.status.setText(f'{prefix}：XLSX {len(xdata)}人・CSV {len(cdata)}行 ／ {stats["elapsed"]:.1f}秒 ／ キャッシュ {stats["cache_hits"]}件・解析 {stats["parsed"]}件 ／ 診断 {len(self.issues)}件')
        self.status.setToolTip('\n'.join(self.issues[-15:]))

    def select_filter(self,state):
        self.filter_state=state
        for text,btn in self.filter_buttons.items():
            btn.setChecked(text==state)
        self.show_results()

    def show_results(self,*args):
        search=self.search.text().strip().replace(' ','').replace('　','')
        state=self.filter_state
        def matches_state(r):
            if state=='すべて': return True
            if state=='一致のみ': return r['status']=='一致'
            return r['status'] in ('不一致','要確認')
        self.visible=[r for r in self.results if matches_state(r)
            and (not search or search in str(r['employee']) or search in r['name'].replace(' ','').replace('　',''))]
        self.model.set_rows(self.visible,self.is_dark)
        period=getattr(self,'results_cfg',None)
        prefix=f'{period["year"]}年{period["month"]}月度 · ' if period else ''
        self.count_label.setText(prefix+f'表示 {len(self.visible):,}件 / 全 {len(self.results):,}件')
        self.print_button.setEnabled(bool(self.visible))
        self.preview_button.setEnabled(bool(self.visible))
        if hasattr(self,'empty_state'):
            self.empty_state.setVisible(not self.visible)
            if not self.visible:
                if self.results:
                    if not search and state=='不一致のみ':
                        self.empty_state.set_message('不一致・要確認はありません','比較項目は一致しています。「すべて」で全件を確認できます。')
                    else:
                        self.empty_state.set_message('表示する結果がありません','検索条件や表示モードを変更すると、結果を確認できます。')
                elif self.loaded_xdata or self.loaded_cdata:
                    if self.results_cfg is not None and not any(entry.get('enabled') for entry in self.results_cfg['comparisons']):
                        self.empty_state.set_message('照合項目がすべてOFFです','設定の「照合項目」で、比較する項目をONにしてください。')
                    else:self.empty_state.set_message('比較できる結果がありません','読み込み診断と社員IDの対応を確認してください。')
                else:
                    self.empty_state.set_message('照合結果はここに表示されます','対象フォルダと月度を選び、「読み込み・照合」を押してください。')

    def selected_row(self):
        idx=self.table.currentIndex()
        return self.visible[idx.row()] if idx.isValid() and 0<=idx.row()<len(self.visible) else None

    def result_config(self):
        # Pending source/comparison edits affect only the next read. Visibility
        # is independent and can be changed immediately for existing results.
        cfg=json.loads(json.dumps(self.results_cfg if self.results_cfg is not None else self.cfg))
        if isinstance(self.cfg.get('detail_visible_fields'),list):
            cfg['detail_visible_fields']=list(self.cfg['detail_visible_fields'])
        else:cfg.pop('detail_visible_fields',None)
        return cfg

    def open_detail(self,*args):
        row=self.selected_row()
        if row:DetailDialog(self,row,self.result_config()).exec()

    def context_menu(self,point):
        idx=self.table.indexAt(point)
        if not idx.isValid():return
        self.table.selectRow(idx.row())
        menu=QMenu(self)
        action=menu.addAction(icon('table'),'全項目の対比表を表示')
        source=menu.addAction(icon('file'),'Excelの該当セルを開く')
        source.setEnabled(bool(self.selected_row() and self.selected_row().get('xrecord')))
        chosen=menu.exec(self.table.viewport().mapToGlobal(point))
        if chosen==action:self.open_detail()
        if chosen==source:self.open_selected_excel()

    def open_excel_source(self,xrecord,field):
        try:
            column=self.result_config().get('xlsx_columns',{}).get(field)
            if not column:
                QMessageBox.warning(self,'列未設定',f'{field} の参照列がありません。')
                return
            open_source_cell(xrecord,column)
        except Exception as e:
            QMessageBox.warning(self,'Excelへの移動に失敗',str(e))

    def open_selected_excel(self):
        row=self.selected_row()
        if not row or not row.get('xrecord'):return
        cfgmatch=next((c for c in self.result_config()['comparisons'] if c.get('xlsx')==row.get('xlsx_key') and c.get('csv')==row.get('csv_key')),None)
        field=cfgmatch['xlsx'] if cfgmatch else None
        if field is None:
            QMessageBox.information(self,'列を選択してください','この行は照合項目に対応しません。詳細対比表で対象のXLSX項目を選択してください。')
            return
        self.open_excel_source(row['xrecord'],field)

    def print_list(self, checked=False, *, preview=False):
        if not self.visible:
            QMessageBox.information(self,'印刷対象なし','表示中の照合結果がありません。')
            return
        keys=('status','date','employee','name','field','xlsx','csv','staff')
        cfg=self.result_config()
        heading=f'勤怠照合結果 {cfg["year"]}年{cfg["month"]}月度 / {self.filter_state} / {len(self.visible)}件'
        body=''.join('<tr>'+''.join('<td>'+print_cell(r.get(k,''))+'</td>' for k in keys)+'</tr>' for r in self.visible)
        print_html(self,'<h2>'+esc(heading)+'</h2><table border="1" width="100%" cellspacing="0" cellpadding="4"><thead><tr>'+''.join('<th>'+esc(c)+'</th>' for c in ResultsModel.HEADERS)+'</tr></thead>'+body+'</table>', preview=preview)

    def show_diagnostics(self):
        dialog=QDialog(self)
        dialog.setWindowTitle('読み込み診断')
        dialog.resize(860,530)
        layout=QVBoxLayout(dialog)
        layout.addWidget(QLabel('読み込み時の失敗・注意・その他のログを分類して表示します。'))
        actions=QHBoxLayout()
        actions.addStretch()
        export_btn=button('診断を保存','save')
        def export_diagnostics():
            destination,_=QFileDialog.getSaveFileName(dialog,'読み込み診断を保存',
                                                      'AttendSync_読み込み診断.txt','テキストファイル (*.txt)')
            if not destination:return
            try:
                lines=[]
                for title,key in (('読み込み失敗','failures'),('読み込み注意','warnings'),('その他のログ','other')):
                    lines.append('['+title+']')
                    for entry in self.read_diagnostics.get(key,[]):
                        lines.append((str(entry.get('file',''))+' : '+str(entry.get('reason','')))
                                     if isinstance(entry,dict) else str(entry))
                    lines.append('')
                Path(destination).write_text('\n'.join(lines),encoding='utf-8-sig')
            except Exception as exc:
                QMessageBox.warning(dialog,'診断の保存に失敗',str(exc))
        export_btn.clicked.connect(export_diagnostics)
        actions.addWidget(export_btn)
        layout.addLayout(actions)
        tabs=QTabWidget()
        for title,key in (('読み込み失敗','failures'),('読み込み注意','warnings'),('その他のログ','other')):
            entries=self.read_diagnostics.get(key,[])
            view=QTextEdit()
            view.setReadOnly(True)
            view.setLineWrapMode(QTextEdit.NoWrap)
            if key=='other':
                lines=[str(v) for v in entries]
            else:
                lines=[str(v.get('file','')) + ' : ' + str(v.get('reason','')) for v in entries]
            view.setPlainText('\n'.join(lines) if lines else '該当なし')
            tabs.addTab(view,f'{title} ({len(entries)})')
        layout.addWidget(tabs)
        close_button=button('閉じる','x')
        close_button.clicked.connect(dialog.accept)
        layout.addWidget(close_button)
        refresh_button_icons(dialog,self.is_dark)
        dialog.exec()

    def set_log_history(self, entries):
        self.log_history=[str(v) for v in entries]
        latest=self.log_history[-1] if self.log_history else ''
        self.log_line.setText(latest.replace('\r',' ').replace('\n','  '))
        self.log_line.setCursorPosition(0)
        self.log_line.setToolTip(latest or 'ログはありません')

    def show_log_window(self):
        dialog=QDialog(self)
        dialog.setWindowTitle('AttendSync - ログ一覧')
        dialog.resize(900,560)
        layout=QVBoxLayout(dialog)
        layout.addWidget(QLabel(f'ログ全体（{len(self.log_history)}件）'))
        view=QTextEdit()
        view.setReadOnly(True)
        view.setLineWrapMode(QTextEdit.NoWrap)
        view.setPlainText('\n'.join(self.log_history))
        layout.addWidget(view,1)
        controls=QHBoxLayout()
        controls.addStretch()
        copy_btn=button('すべてコピー','copy')
        copy_btn.clicked.connect(lambda: QApplication.clipboard().setText(view.toPlainText()))
        controls.addWidget(copy_btn)
        save_btn=button('テキスト保存','save')
        def save_logs():
            path,_=QFileDialog.getSaveFileName(dialog,'ログを保存','AttendSync_ログ.txt','テキストファイル (*.txt)')
            if path:
                try:Path(path).write_text(view.toPlainText(),encoding='utf-8-sig')
                except Exception as exc:QMessageBox.warning(dialog,'保存エラー',str(exc))
        save_btn.clicked.connect(save_logs)
        controls.addWidget(save_btn)
        close_btn=button('閉じる','x')
        close_btn.clicked.connect(dialog.accept)
        controls.addWidget(close_btn)
        layout.addLayout(controls)
        refresh_button_icons(dialog,self.is_dark)
        dialog.exec()

    def closeEvent(self,event):
        if self.worker is not None and self.worker.isRunning():
            if self._close_after_worker:
                event.ignore()
                return
            response=QMessageBox.question(self,'読み込み中','読み込み処理を中止して終了しますか？')
            if response==QMessageBox.Yes:
                self._close_after_worker=True
                self.stop_read()
            event.ignore()
        else:
            event.accept()


def main():
    app=QApplication.instance() or QApplication(sys.argv)
    app.setStyle('Fusion')
    try:window=Window()
    except Exception as exc:
        QMessageBox.critical(None,'AttendSyncを起動できません',
            str(exc)+'\n\nファイルは変更していません。設定・社員ID対応の内容を確認するか、バックアップから復元してください。')
        return 1
    window.show()
    return app.exec()


if __name__=='__main__':
    sys.exit(main())
