"""Independent startup-path regressions; no company data or real userdata.

When copied next to main.py, imports that source automatically. For standalone
review use ATTENDSYNC_AUDIT_ROOT=/path/to/AttendSync python this_script.py.
"""
import importlib.util
import os
import sys
import tempfile
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
SOURCE=Path(os.environ.get('ATTENDSYNC_AUDIT_ROOT',str(Path(__file__).resolve().parent))).resolve()
if not (SOURCE/'main.py').is_file():
    raise RuntimeError('Place this test beside main.py or set ATTENDSYNC_AUDIT_ROOT to the source folder.')
sys.path.insert(0,str(SOURCE))
from PySide6.QtWidgets import QApplication
import runtime_paths


class StartupDistribution46(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='attendsync-startup46-')
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        self.portable=self.base/'会社 配布'
        self.portable.mkdir()
        self.local=self.base/'Local App'
        self.local.mkdir()
        for context in (patch.object(runtime_paths,'application_dir',return_value=self.portable),
                        patch.dict(os.environ,{'LOCALAPPDATA':str(self.local)})):
            context.start();self.addCleanup(context.stop)

    def load_app(self):
        # A fresh module exercises startup initialization on every case while
        # sharing the already initialized Qt library; no production import runs
        # before application_dir/LOCALAPPDATA point to temporary locations.
        name='attendsync_startup46_'+uuid.uuid4().hex
        spec=importlib.util.spec_from_file_location(name,SOURCE/'main.py')
        module=importlib.util.module_from_spec(spec)
        sys.modules[name]=module
        self.addCleanup(sys.modules.pop,name,None)
        spec.loader.exec_module(module)
        return module

    def assert_startup_error(self,module):
        self.assertIsNone(module.DATA_DIR)
        self.assertIsNone(module.CONFIG)
        self.assertIsNone(module.MAP)
        self.assertIsNone(module.DB)
        self.assertIsNotNone(module._DATA_DIR_ERROR)
        with patch.object(module.QMessageBox,'critical') as critical:
            self.assertEqual(module.main(),1)
        critical.assert_called_once()
        self.assertEqual(critical.call_args.args[1],'AttendSyncを起動できません')
        message=critical.call_args.args[2]
        self.assertIn(str(self.portable/'userdata'),message)
        self.assertIn(str(self.local/'AttendSync'),message)
        self.assertIn('権限',message)

    def assert_normal_startup(self,module,expected):
        self.assertIsNone(module._DATA_DIR_ERROR)
        self.assertEqual(module.DATA_DIR,expected)
        self.assertEqual(module.CONFIG,expected/'settings.json')
        self.assertEqual(module.MAP,expected/'staff_mapping.json')
        self.assertEqual(module.DB,expected/'attendance_cache.sqlite3')
        self.assertTrue(expected.is_dir())
        window=module.Window()
        try:
            window.show();self.app.processEvents()
            self.assertIsNone(window.worker)
        finally:
            window.close();window.deleteLater();self.app.processEvents()
        for filename in ('settings.json','staff_mapping.json','attendance_cache.sqlite3'):
            self.assertFalse((expected/filename).exists(),filename)

    def test_double_denied_actual_files_reports_error_and_preserves_originals(self):
        # Actual filesystem mkdir failures; not a mocked get_data_dir result.
        portable=self.portable/'userdata';fallback=self.local/'AttendSync'
        portable.write_bytes(b'keep portable collision')
        fallback.write_bytes(b'keep fallback collision')
        self.assert_startup_error(self.load_app())
        self.assertEqual(portable.read_bytes(),b'keep portable collision')
        self.assertEqual(fallback.read_bytes(),b'keep fallback collision')

    def denied_probe(self,stage):
        fallback=self.local/'AttendSync';fallback.mkdir()
        testcase=self
        class Probe:
            def __enter__(self):return self
            def __exit__(self,*args):return False
            def write(self,data):
                if stage=='write':raise PermissionError('fallback write denied')
                return len(data)
            def flush(self):
                if stage=='flush':raise PermissionError('fallback flush denied')
        def temporary(*args,**kwargs):
            if Path(kwargs['dir'])==testcase.portable/'userdata':
                raise PermissionError('portable denied')
            testcase.assertEqual(Path(kwargs['dir']),fallback)
            return Probe()
        with patch.object(runtime_paths.tempfile,'TemporaryFile',side_effect=temporary):
            self.assert_startup_error(self.load_app())
        self.assertTrue(fallback.is_dir())

    def test_existing_fallback_write_denied_is_reported_at_startup(self):
        self.denied_probe('write')

    def test_existing_fallback_flush_denied_is_reported_at_startup(self):
        self.denied_probe('flush')

    def test_normal_portable_does_not_initialize_localappdata_or_save_settings(self):
        self.assert_normal_startup(self.load_app(),self.portable/'userdata')
        self.assertFalse((self.local/'AttendSync').exists())

    def test_normal_fallback_when_portable_has_file_collision(self):
        collision=self.portable/'userdata';collision.write_bytes(b'keep collision')
        self.assert_normal_startup(self.load_app(),self.local/'AttendSync')
        self.assertEqual(collision.read_bytes(),b'keep collision')

    def test_frozen_application_dir_is_executable_parent_with_unicode_and_spaces(self):
        # Restore the real application_dir for this case only.
        spec=importlib.util.spec_from_file_location('fresh_runtime_paths46',SOURCE/'runtime_paths.py')
        runtime=importlib.util.module_from_spec(spec);spec.loader.exec_module(runtime)
        with patch.object(sys,'frozen',True,create=True),patch.object(sys,'executable',str(self.portable/'AttendSync.exe')):
            self.assertEqual(runtime.application_dir(),self.portable)
            self.assertEqual(runtime.get_data_dir(),self.portable/'userdata')
        self.assertFalse((self.local/'AttendSync').exists())


if __name__=='__main__':
    unittest.main(verbosity=2)
