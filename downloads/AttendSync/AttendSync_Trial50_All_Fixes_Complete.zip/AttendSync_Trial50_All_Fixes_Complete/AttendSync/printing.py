"""Shared print layout, preview and recoverable native printing errors."""
import html
import re
from PySide6.QtCore import QMarginsF
from PySide6.QtGui import QFont, QPageLayout, QPageSize, QTextDocument
from PySide6.QtWidgets import QDialog, QMessageBox
from PySide6.QtPrintSupport import QPrinter, QPrinterInfo, QPrintDialog, QPrintPreviewDialog


def print_cell(value):
    # Qt rich text does not support CSS word-break. Provide safe wrap points.
    text = str('' if value is None else value)
    text = re.sub(r'[^\s]{24,}', lambda m: '\u200b'.join(
        m[0][i:i+24] for i in range(0, len(m[0]), 24)), text)
    return html.escape(text).replace('\n', '<br>')


def make_printer():
    printer = QPrinter(QPrinter.HighResolution)
    printer.setPageSize(QPageSize(QPageSize.A4))
    printer.setPageOrientation(QPageLayout.Landscape)
    printer.setPageMargins(QMarginsF(10, 10, 10, 10), QPageLayout.Millimeter)
    return printer


def make_document(markup, parent=None):
    document = QTextDocument(parent)
    document.setDefaultFont(QFont('Sans Serif', 9))
    document.setDefaultStyleSheet('table { width: 100%; } th { background-color: #eeeeee; } td, th { vertical-align: top; }')
    document.setHtml(markup)
    return document


def render_document(document, printer):
    document.print_(printer)
    if printer.printerState() in (QPrinter.Error, QPrinter.Aborted):
        raise RuntimeError('印刷が中止されたか、プリンタでエラーが発生しました。')


def print_html(parent, markup, preview=False):
    document = None
    dialog = None
    try:
        printer = make_printer()
        document = make_document(markup, parent)
        if preview:
            dialog = QPrintPreviewDialog(printer, parent)
            dialog.setWindowTitle('AttendSync 印刷プレビュー')
            dialog.resize(1000, 720)
            def paint(target):
                try:
                    render_document(document, target)
                except Exception as exc:
                    QMessageBox.warning(parent, '印刷に失敗', str(exc))
            dialog.paintRequested.connect(paint)
            dialog.exec()
            return
        if not QPrinterInfo.availablePrinters():
            QMessageBox.information(parent, 'プリンタなし', 'プリンタが見つかりません。Windowsのプリンタ設定を確認してください。印刷プレビューは利用できます。')
            return
        dialog = QPrintDialog(printer, parent)
        if dialog.exec() != QDialog.Accepted:
            return
        render_document(document, printer)
    except Exception as exc:
        QMessageBox.warning(parent, '印刷に失敗', str(exc))

    finally:
        if dialog is not None:
            dialog.deleteLater()
        if document is not None:
            document.deleteLater()
