"""Real Qt checks for Trial33's layout, search, and accessible status rendering.

Run with ``python -m unittest -v test_trial33_ui``.  A display is unnecessary:
the tests use Qt's offscreen platform unless one was explicitly selected.
User settings, staff mappings, and the cache are isolated in temporary folders.
When PySide6 is unavailable, unittest reports these GUI checks as skipped.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

try:
    from PySide6.QtCore import QPoint, QRect, QSize, Qt
    from PySide6.QtGui import QColor, QImage, QPainter
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import (
        QApplication, QPushButton, QStyle, QStyleOptionViewItem, QTabWidget,
        QToolButton,
    )
except ModuleNotFoundError as exc:
    if exc.name != 'PySide6':
        raise
    QT_AVAILABLE = False
else:
    QT_AVAILABLE = True
    # main obtains DATA_DIR on import.  Patch the accessor before importing so
    # even that initialization cannot create files in an actual user directory.
    import runtime_paths
    _import_directory = tempfile.TemporaryDirectory(prefix='attendsync-ui-import-')
    with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_directory.name)):
        import main
    from ui_theme import theme_colors


def contrast_ratio(foreground, background):
    def luminance(hex_color):
        rgb = [int(hex_color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
        linear = [value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4
                  for value in rgb]
        return sum(weight * value for weight, value in zip((0.2126, 0.7152, 0.0722), linear))
    lighter, darker = sorted((luminance(foreground), luminance(background)), reverse=True)
    return (lighter + 0.05) / (darker + 0.05)


@unittest.skipUnless(QT_AVAILABLE, 'PySide6 is required for real Qt UI checks')
class Trial33UI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='attendsync-ui-test-')
        self.addCleanup(self.directory.cleanup)
        self.data_dir = Path(self.directory.name)
        self.paths_patch = patch.multiple(
            main, DATA_DIR=self.data_dir, CONFIG=self.data_dir / 'settings.json',
            MAP=self.data_dir / 'staff_mapping.json', DB=self.data_dir / 'attendance_cache.sqlite3',
        )
        self.paths_patch.start()
        self.addCleanup(self.paths_patch.stop)
        self.windows = []
        self.addCleanup(self.close_windows)

    def close_windows(self):
        for window in reversed(self.windows):
            window.close()
            window.deleteLater()
        self.app.processEvents()

    def settle(self):
        # Two passes allow parent and viewport resize events to finish without
        # adding a time-dependent sleep to geometry checks.
        self.app.processEvents()
        self.app.processEvents()

    def window(self, dark=False, size=(1180, 800)):
        cfg = json.loads(json.dumps(main.DEFAULT))
        cfg['theme'] = 'dark' if dark else 'light'
        (self.data_dir / 'settings.json').write_text(json.dumps(cfg), encoding='utf-8')
        window = main.Window()
        self.windows.append(window)
        window.resize(*size)
        window.show()
        self.settle()
        return window

    @staticmethod
    def sample_rows():
        rows = []
        for employee, name, status in (
            ('10001', '山田　太郎', '一致'),
            ('10001', '山田　太郎', '不一致'),
            ('10002', '佐藤 花子', '要確認'),
        ):
            rows.append({
                'status': status, 'date': '2026-10-01', 'employee': employee,
                'name': name, 'field': '始業時刻', 'xlsx': '09:00', 'csv': '09:05',
                'staff': 'S' + employee, 'xlsx_key': 'start', 'csv_key': 'start',
                'xrecord': None, 'crecord': None,
            })
        return rows

    def assert_controls_fit(self, container, controls):
        rects = []
        for control in controls:
            rect = QRect(control.mapTo(container, QPoint(0, 0)), control.size())
            name = control.text() if isinstance(control, QPushButton) else type(control).__name__
            self.assertTrue(control.isVisible(), f'{name} is hidden')
            self.assertTrue(container.rect().contains(rect),
                            f'{name} is outside {container.size().toTuple()}: {rect.getRect()}')
            self.assertGreater(rect.width(), 0, name)
            self.assertGreater(rect.height(), 0, name)
            rects.append((name, rect))
        for index, (name, rect) in enumerate(rects):
            for other_name, other_rect in rects[index + 1:]:
                self.assertFalse(rect.intersects(other_rect),
                                 f'{name} overlaps {other_name}: {rect.getRect()}, {other_rect.getRect()}')

    @staticmethod
    def main_controls(window):
        return [
            window.btn_theme, window.btn_map, window.btn_settings, window.btn_manual, window.path,
            window.btn_browse, window.year, window.month, window.period_hint,
            window.run_button, window.full_button, window.stop_button,
            *window.filter_buttons.values(), window.search, window.print_button,
            window.preview_button, window.status, window.progress,
            window.btn_diagnostics, window.btn_logs,
        ]

    def test_palette_text_contrast(self):
        for dark in (False, True):
            colors = theme_colors(dark)
            pairs = [(foreground, background) for foreground in ('text', 'muted')
                     for background in ('background', 'panel', 'field', 'alternate')]
            pairs += [(semantic, background) for semantic in ('success', 'error', 'warning')
                      for background in ('panel', 'alternate', 'soft_' + semantic)]
            pairs += [('accent', 'panel'), ('accent', 'soft_accent'), ('text', 'selection')]
            for foreground, background in pairs:
                with self.subTest(dark=dark, foreground=foreground, background=background):
                    self.assertGreaterEqual(contrast_ratio(colors[foreground], colors[background]), 4.5)
            for background in ('primary', 'primary_hover', 'primary_pressed'):
                with self.subTest(dark=dark, white_text_on=background):
                    self.assertGreaterEqual(contrast_ratio('#ffffff', colors[background]), 4.5)

    def test_main_layout_keeps_result_rows_and_actions_visible(self):
        for dark in (False, True):
            for size in ((1040, 690), (1280, 860)):
                with self.subTest(dark=dark, size=size):
                    window = self.window(dark, size)
                    self.assertEqual(window.size(), QSize(*size))
                    self.assert_controls_fit(window, self.main_controls(window))
                    self.assertGreaterEqual(window.table.viewport().height(), 100,
                                            'Result rows must remain usable at the supported minimum size')
                    self.assertEqual(window.empty_state.geometry(), window.table.viewport().rect())

    def test_long_status_cannot_push_actions_outside_window(self):
        for dark in (False, True):
            with self.subTest(dark=dark):
                window = self.window(dark, (1040, 690))
                message = '読み込み 50/121  社員番号12345_' + '非常に長い勤怠ファイル名_' * 80 + '.xlsx'
                window.status.setText(message)
                window.btn_diagnostics.setText('読み込み診断 (失敗 120 / 注意 999)')
                self.settle()
                self.assertEqual(window.status.text(), message)
                self.assertEqual(window.size(), QSize(1040, 690))
                self.assertLessEqual(window.minimumSizeHint().width(), 1040)
                self.assert_controls_fit(window, self.main_controls(window))
                self.assertGreaterEqual(window.table.viewport().height(), 100)

    def test_period_hint_handles_january_and_year_changes(self):
        window = self.window()
        window.year.setValue(2026)
        window.month.setValue(1)
        self.assertIn('12/16', window.period_hint.text())
        self.assertIn('1/15', window.period_hint.text())
        self.assertIn('2025/12/16', window.period_hint.toolTip())
        self.assertIn('2026/01/15', window.period_hint.toolTip())
        window.year.setValue(2027)
        self.assertIn('2026/12/16', window.period_hint.toolTip())
        self.assertIn('2027/01/15', window.period_hint.toolTip())
        window.month.setValue(3)
        self.assertIn('2027/02/16', window.period_hint.toolTip())
        self.assertIn('2027/03/15', window.period_hint.toolTip())

    def test_empty_states_distinguish_unloaded_and_no_matches(self):
        window = self.window()
        self.assertTrue(window.empty_state.isVisible())
        self.assertIn('ここに表示', window.empty_state.title.text())
        self.assertFalse(window.print_button.isEnabled())
        self.assertFalse(window.preview_button.isEnabled())
        window.results = self.sample_rows()
        window.show_results()
        self.assertFalse(window.empty_state.isVisible())
        window.search.setText('存在しない社員')
        self.settle()
        self.assertEqual(window.model.rowCount(), 0)
        self.assertTrue(window.empty_state.isVisible())
        self.assertIn('ありません', window.empty_state.title.text())
        self.assertIn('検索条件', window.empty_state.caption.text())
        self.assertFalse(window.print_button.isEnabled())
        self.assertFalse(window.preview_button.isEnabled())
        window.search.clear()
        window.results = [self.sample_rows()[0]]
        window.show_results()
        self.assertTrue(window.empty_state.isVisible())
        self.assertIn('不一致・要確認はありません', window.empty_state.title.text())
        self.assertIn('一致しています', window.empty_state.caption.text())
        window.results = []
        window.loaded_xdata = {'10001': {'records': {}}}
        window.show_results()
        self.assertIn('比較できる結果', window.empty_state.title.text())
        self.assertIn('読み込み診断', window.empty_state.caption.text())

    def test_filters_japanese_search_and_clear_action(self):
        window = self.window()
        window.results = self.sample_rows()
        window.show_results()
        self.assertEqual([row['status'] for row in window.visible], ['不一致', '要確認'])
        QTest.mouseClick(window.filter_buttons['一致のみ'], Qt.LeftButton)
        self.assertEqual([row['status'] for row in window.visible], ['一致'])
        QTest.mouseClick(window.filter_buttons['すべて'], Qt.LeftButton)
        self.assertEqual(len(window.visible), 3)
        window.search.setText('山田 太郎')
        self.assertEqual(len(window.visible), 2)
        window.search.setText('10002')
        self.assertEqual([row['employee'] for row in window.visible], ['10002'])
        self.settle()
        clear_buttons = [button for button in window.search.findChildren(QToolButton)
                         if button.defaultAction() is not None
                         and button.defaultAction().objectName() == '_q_qlineeditclearaction']
        self.assertEqual(len(clear_buttons), 1, 'Search must expose its actual clear action')
        self.assertTrue(clear_buttons[0].isVisible())
        QTest.mouseClick(clear_buttons[0], Qt.LeftButton)
        self.assertEqual(window.search.text(), '')
        self.assertEqual(len(window.visible), 3)
        self.assertEqual(window.count_label.text(), '表示 3件 / 全 3件')
        self.assertTrue(window.print_button.isEnabled())
        self.assertTrue(window.preview_button.isEnabled())
        self.assertEqual(sum(button.isChecked() for button in window.filter_buttons.values()), 1)

    def test_theme_toggle_preserves_results_and_renders_status_pills(self):
        window = self.window()
        window.results = self.sample_rows()
        window.select_filter('すべて')
        for dark in (False, True):
            if window.is_dark != dark:
                QTest.mouseClick(window.btn_theme, Qt.LeftButton)
                self.settle()
            colors = theme_colors(dark)
            self.assertEqual(window.model.dark, dark)
            self.assertEqual(window.model.rowCount(), 3)
            for row, semantic in enumerate(('success', 'error', 'warning')):
                index = window.model.index(row, 0)
                self.assertEqual(window.model.data(index, Qt.ForegroundRole).color().name(), colors[semantic])
                image = QImage(90, 40, QImage.Format_ARGB32_Premultiplied)
                image.fill(Qt.transparent)
                painter = QPainter(image)
                option = QStyleOptionViewItem()
                option.widget = window.table
                option.rect = QRect(0, 0, 90, 40)
                option.font = window.table.font()
                option.state = QStyle.State_Enabled
                try:
                    window.table.itemDelegateForColumn(0).paint(painter, option, index)
                finally:
                    painter.end()
                # A real paint verifies the pill background, rather than merely
                # asserting that the custom delegate class was installed.
                self.assertEqual(image.pixelColor(20, 12).name(), colors['soft_' + semantic])
            bad_value = window.model.index(1, 5)
            self.assertEqual(window.model.data(bad_value, Qt.ForegroundRole).color().name(), colors['error'])
        saved = json.loads((self.data_dir / 'settings.json').read_text(encoding='utf-8'))
        self.assertEqual(saved['theme'], 'dark')
        self.assertFalse((self.data_dir / 'attendance_cache.sqlite3').exists())

    def test_detail_minimum_layout_and_source_header_contrast(self):
        for dark in (False, True):
            with self.subTest(dark=dark):
                window = self.window(dark)
                row = self.sample_rows()[1]
                window.results = [row]
                dialog = main.DetailDialog(window, row, window.cfg)
                self.windows.append(dialog)
                dialog.resize(760, 550)
                dialog.show()
                self.settle()
                self.assertEqual(dialog.size(), QSize(760, 550))
                self.assert_controls_fit(dialog, dialog.findChildren(QPushButton))
                self.assertGreaterEqual(dialog.detail_table.viewport().height(), 100)
                colors = theme_colors(dark)
                for column in (1, 2):
                    header_color = dialog.detail_table.horizontalHeaderItem(column).foreground().color().name()
                    self.assertGreaterEqual(contrast_ratio(header_color, colors['alternate']), 4.5,
                                            f'Source column {column} header needs readable contrast')

    def test_settings_minimum_keeps_save_cancel_available_on_every_tab(self):
        for dark in (False, True):
            with self.subTest(dark=dark):
                window = self.window(dark)
                dialog = main.SettingsDialog(window, window.cfg)
                self.windows.append(dialog)
                dialog.resize(780, 580)
                dialog.show()
                self.settle()
                tabs = dialog.findChild(QTabWidget)
                self.assertEqual(tabs.count(), 4)
                buttons = [button for button in dialog.findChildren(QPushButton)
                           if button.text() in ('キャンセル', '設定を保存')]
                self.assertEqual(len(buttons), 2)
                for tab in range(tabs.count()):
                    tabs.setCurrentIndex(tab)
                    self.settle()
                    self.assertEqual(dialog.size(), QSize(780, 580))
                    self.assert_controls_fit(dialog, [tabs, *buttons])


if __name__ == '__main__':
    unittest.main(verbosity=2)
