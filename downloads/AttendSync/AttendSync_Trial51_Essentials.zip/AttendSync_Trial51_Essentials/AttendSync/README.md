# 勤怠チェッカー Trial51 必要ファイル版

ソース/アイコン/依存定義/14ページ図解マニュアルを同梱。
Windows PowerShellでAttendSyncフォルダへ移動:

```
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

生成したdist\AttendSync全体を配布。Windows EXEはZIPに未同梱。旧userdataをバックアップして継承。内部保存名AttendSyncは互換性のため継続。Windows実機検証は未実施。
