# 勤怠チェッカー Trial55 必要ファイル版

ソース/アイコン/依存定義/19ページ図解マニュアルを同梱。
Windows PowerShellでAttendSyncフォルダへ移動:

```
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

生成したdist\AttendSync全体を配布。Windows EXEはZIPに未同梱。旧userdataをバックアップして継承。内部保存名AttendSyncは互換性のため継続。Windows実機検証は未実施。

印刷の左「メールを作成」で表示中の不一致を社員別メールへ。自動送信初期OFF。設定→メールで文面とMicrosoft接続を設定。初回はManual/Microsoft連携ガイド.htmlを参照。

敬称初期値は「殿」。不一致内容は「派遣元」「派遣先」の表記。保存済み敬称は設定→メールで変更できます。
