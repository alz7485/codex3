# 勤怠チェッカー Trial63 必要ファイル版

Windows11 / Python3.11推奨のソース版。実行・ビルド用ソース、アイコン、18ページ図解です。実データ・テスト・サンプル・EXEは含みません。

PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

配布はdist\AttendSync全体。旧userdataはバックアップ後に引き継ぎます。

最初に「社員情報」で社員CSVを選択・ドロップし「一覧に反映」→「社員情報を登録」。初期列はスタッフID=A、社員ID=B、氏名=C、メール=J。その後メインで勤怠を読み込みます。

「設定」→「メール」の「起動中のOutlookから取得」はWindowsのクラシックOutlookからアドレス・表示名だけを入力します。複数アカウントは選択、「設定を保存」で確定。メールの作成・送信はMicrosoft Graph経由のため、アプリID・テナントID設定と初回サインインが別途必要です。取得操作では送信しません。自動送信の初期値はOFFです。

図解：Manual/index.html。初回接続：Manual/Microsoft連携ガイド.html。関連6本・81テスト成功。Windows実機のOutlook接続・実認証/送信・EXEビルドは未検証です。
