# 勤怠チェッカー Trial62 必要ファイル版

実行・ビルド用Pythonソース、アイコン、18ページ図解だけの版です。テスト・監査証跡・サンプル・社員や勤怠の実データ・EXEは含みません。全49テストスクリプト成功。独立監査で確認した問題を修正しました。

Windows11 / Python3.11推奨。PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

ビルド後はdist\AttendSync全体を配布します。既存のuserdataはバックアップしてから引き継いでください。

最初に「社員情報」で社員CSVを選択・ドロップし「一覧に反映」→「社員情報を登録」。初期列はスタッフID=A、社員ID=B、氏名=C、メール=J。保存済みの独自設定は維持します。その後メインで勤怠を読み込みます。

「CSVが無い月度分は非表示」は初期ON、OFFで全件に戻せます。個人別欠落・入力異常は表示し、全数と診断は保持します。メール自動送信は初期OFFです。

図解：Manual/index.html。Microsoft初回設定：Manual/Microsoft連携ガイド.html。Windows実機・実Excel・実Microsoft365認証/送信は未検証です。
