# 勤怠チェッカー Trial52 必要ファイル版

ソース/アイコン/依存定義/14ページ図解マニュアルを同梱。
Windows PowerShellでAttendSyncフォルダへ移動:

```
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

生成したdist\AttendSync全体を配布。Windows EXEはZIPに未同梱。旧userdataをバックアップして継承。内部保存名AttendSyncは互換性のため継続。Windows実機検証は未実施。

数式の0が表示形式やシートゼロ非表示で空欄になる時刻セルを、空欄として扱います。通常の0:00と実働0は保持。旧キャッシュは自動再解析。
