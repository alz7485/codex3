# 勤怠チェッカー Trial58 必要ファイル版

実行・ビルド用ソース、アイコン、19ページ図解マニュアルです。テスト・監査・サンプルを省き、社員・勤怠の実データは含みません。Windows EXEは未同梱です。

Windows 11 / Python3.11推奨。PowerShellでこのフォルダに移動して実行します。

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

ビルド後は dist\AttendSync 全体を配布します。既存userdataはバックアップ後に引き継いでください。

「社員情報」かCSV読込画面へCSVを1つドロップすると、自動で確認一覧を表示します。初期列はスタッフID=A、社員ID（派遣元スタッフコード）=B、氏名=C、メール=J。保存済みの列設定は保持します。用途を「勤怠用CSV」にするとメールは変更せずIDだけを紐付けます。

CSV行番号は表示せず、確認一覧のダブルクリックで元CSVの対応するセルへ移動できます（Windows版Excel・pywin32が必要）。元CSVが更新されていたら再読込します。「一覧に反映」→「紐付けを保存」で確定。キャンセルは仮の取込を破棄します。

「メールを作成」画面でも今回の自動送信を切り替えられます。初期値OFFは下書き、ONは送信。初回連携は Manual/Microsoft連携ガイド.html、図解は Manual/index.html を参照。全46テストスクリプト成功。Windows EXE・実Excelの操作・Microsoft 365実接続／送信は未検証です。
