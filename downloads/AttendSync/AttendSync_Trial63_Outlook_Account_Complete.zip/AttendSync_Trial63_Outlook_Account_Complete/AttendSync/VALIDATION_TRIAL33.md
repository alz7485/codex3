# Trial33 検証結果

環境: Linux-6.18.44-x86_64-with-glibc2.41
Python: 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]
PySide6: 6.12.0 / openpyxl: 3.1.5
QT_QPA_PLATFORM=offscreen

24テストスクリプト全合格。新規test_trial33_ui.pyは9件のunittestがすべて合格。
Python全ファイルAST構文検査合格。

| スクリプト | 結果 | 秒 |
|---|---|---|
| test_120_performance.py | PASS | 1.38 |
| test_cache_tags.py | PASS | 0.08 |
| test_comparison_extensions.py | PASS | 0.17 |
| test_coverage_trial16.py | PASS | 1.14 |
| test_engine.py | PASS | 0.1 |
| test_excel_jump.py | PASS | 0.02 |
| test_final_validation.py | PASS | 0.09 |
| test_month_spacers_trial19.py | PASS | 0.13 |
| test_sample_integration.py | PASS | 0.17 |
| test_stable_read.py | PASS | 0.02 |
| test_trial15.py | PASS | 0.09 |
| test_trial21.py | PASS | 0.08 |
| test_trial22_static.py | PASS | 0.02 |
| test_trial23_static.py | PASS | 0.02 |
| test_trial24_integrity.py | PASS | 0.02 |
| test_trial27_toggle_static.py | PASS | 0.02 |
| test_trial28_input_review.py | PASS | 0.09 |
| test_trial29_completion.py | PASS | 0.04 |
| test_trial30_dynamic_failures.py | PASS | 0.19 |
| test_trial31_excel_mock.py | PASS | 0.09 |
| test_trial32_gui_print.py | PASS | 1.41 |
| test_trial32_sessions_mapping.py | PASS | 6.57 |
| test_trial33_ui.py | PASS | 4.15 |
| test_ui_static.py | PASS | 0.05 |

## 検証の内容

- 120人・3600勤怠日・10800項目の期待値、一致10,797／不一致3／要確認0。
- 既存のキャッシュ、破損ファイル診断、Excel COMモック、印刷対象・PDF・プレビュー・取消、中止再実行。
- UI新規検証：ライト／ダークのコントラスト比、操作の重なりと画面内配置、1040×690の表viewport100px以上（実測107px）。
- 長文ファイル名でも画面幅を押し広げず、ステータス全文を保持。
- 年跨ぎ期間、フィルター、日本語検索、検索クリア、状況ごとの空状態、判定バッジの実ピクセル。
- 詳細760×550と設定780×580で操作を確認。
- 明暗・標準幅・狭幅・詳細・設定の実画面を取得、目視確認。合成サンプルのみ使用。

## 結果抜粋

```
trial12-120: 120 XLSX + 2 CSV, cache_hits=0/122, elapsed=1.18s; 一致=10797 不一致=3
trial12-120: 120 XLSX + 2 CSV, cache_hits=122/122, elapsed=0.10s; 一致=10797 不一致=3
PASS: 120人、3600勤怠日、10800照合、3不一致、キャッシュ再利用

```

```

test_detail_minimum_layout_and_source_header_contrast (__main__.Trial33UI.test_detail_minimum_layout_and_source_header_contrast) ... Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
Fontconfig error: No writable cache directories
ok
test_empty_states_distinguish_unloaded_and_no_matches (__main__.Trial33UI.test_empty_states_distinguish_unloaded_and_no_matches) ... ok
test_filters_japanese_search_and_clear_action (__main__.Trial33UI.test_filters_japanese_search_and_clear_action) ... ok
test_long_status_cannot_push_actions_outside_window (__main__.Trial33UI.test_long_status_cannot_push_actions_outside_window) ... ok
test_main_layout_keeps_result_rows_and_actions_visible (__main__.Trial33UI.test_main_layout_keeps_result_rows_and_actions_visible) ... ok
test_palette_text_contrast (__main__.Trial33UI.test_palette_text_contrast) ... ok
test_period_hint_handles_january_and_year_changes (__main__.Trial33UI.test_period_hint_handles_january_and_year_changes) ... ok
test_settings_minimum_keeps_save_cancel_available_on_every_tab (__main__.Trial33UI.test_settings_minimum_keeps_save_cancel_available_on_every_tab) ... ok
test_theme_toggle_preserves_results_and_renders_status_pills (__main__.Trial33UI.test_theme_toggle_preserves_results_and_renders_status_pills) ... ok

----------------------------------------------------------------------
Ran 9 tests in 3.855s

OK
```

## 未検証

Windows 11での実フォント・高DPI・ネイティブダイアログ・Office/Excel・物理プリンタ・onedir EXE起動・会社ネットワーク性能は未検証。
過去の静的検査は静的検査として扱い、全テストを実機動作確認とは表現しない。
オフスクリーン実行時のFontconfigキャッシュ警告とpropagateSizeHints警告は、テスト結果JSONに記録。

## Python差分

- 変更：main.py、ui_theme.py
- 追加：test_trial33_ui.py
- 削除：なし
