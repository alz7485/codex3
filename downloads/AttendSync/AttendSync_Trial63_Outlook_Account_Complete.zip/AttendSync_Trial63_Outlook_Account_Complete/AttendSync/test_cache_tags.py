from copy import deepcopy
from engine import DEFAULT
from cache_tags import parser_tag

def test_tags():
    x=parser_tag(DEFAULT,'xlsx'); c=parser_tag(DEFAULT,'csv')
    assert x==parser_tag(deepcopy(DEFAULT),'xlsx')
    assert c==parser_tag(deepcopy(DEFAULT),'csv')
    for kind, path, value in (
       ('xlsx',('xlsx_columns','start'),'Z'),
       ('xlsx',('sheet_names','10'),'Oct'),
       ('xlsx',('info_cells','employee'),'B2'),
       ('xlsx',('data_first_row',),11),
       ('xlsx',('year',),2027),
       ('csv',('csv_columns','staff'),'F'),
       ('csv',('csv_first_row',),3),
       ('csv',('csv_encoding',),'utf-8-sig')):
        copy=deepcopy(DEFAULT)
        obj=copy
        for key in path[:-1]:obj=obj[key]
        obj[path[-1]]=value
        assert parser_tag(copy,kind)!= (x if kind=='xlsx' else c),path
    copy=deepcopy(DEFAULT)
    copy['comparisons'][0]['enabled']=False
    assert parser_tag(copy,'xlsx')==x
    assert parser_tag(copy,'csv')==c
    print('PASS: 10 settings/cache signature checks')

if __name__=='__main__':test_tags()
