from tempfile import TemporaryDirectory
from pathlib import Path
from openpyxl import Workbook
from engine import DEFAULT, xlsx_read, csv_read, Cache
from cache_tags import parser_tag
import csv
with TemporaryDirectory() as tmp:
    p=Path(tmp); w=Workbook(); sh=w.active;sh.title='10月'
    sh['A1']='2026年10月度';sh['N1']='001';sh['U1']='試験　社員'
    sh['A9']=9;sh['B9']='誤日付'; sh['A10']=9;sh['B10']=16
    xp=p/'test.xlsx';w.save(xp)
    packet=xlsx_read(xp,DEFAULT)
    assert len(packet['records'])==1 and any('日が不正' in x for x in packet['warnings'])
    cp=p/'test.csv'
    with cp.open('w',encoding='utf-8',newline='') as f:
        q=csv.writer(f);q.writerow(['head']*14)
        bad=['']*14;bad[0]='20261355';bad[3]='ID123';q.writerow(bad)
        good=['']*14;good[0]='20260916';good[3]='ID123';q.writerow(good)
    data=csv_read(cp,DEFAULT)
    assert len(data['records'])==1 and len(data['warnings'])==1
    db=Cache(p/'cache.sqlite3');tag=parser_tag(DEFAULT,'csv')
    r,hit=db.parse(cp,tag,lambda f:csv_read(f,DEFAULT));assert not hit
    r,hit=db.parse(cp,tag,lambda f:csv_read(f,DEFAULT));assert hit
    cp.write_text('changed',encoding='utf-8')
    r,hit=db.parse(cp,tag,lambda f:{'records':[]}); assert not hit
    db.close()
print('PASS Trial15: malformed XLSX day, invalid CSV date, cache reuse/invalidation')
