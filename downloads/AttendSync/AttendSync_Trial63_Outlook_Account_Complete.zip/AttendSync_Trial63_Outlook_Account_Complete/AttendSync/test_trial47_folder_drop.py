"""Native Qt drop routing across the main window, with isolated user data."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, Mock
from PySide6.QtCore import QEvent, QCoreApplication, QMimeData, QPoint, QPointF, Qt, QUrl
from PySide6.QtGui import QDragEnterEvent, QDragMoveEvent, QDropEvent
from PySide6.QtWidgets import QApplication, QDialog, QLineEdit, QWidget
import runtime_paths
_import_dir = tempfile.TemporaryDirectory(prefix='attendsync-drop-import-')
with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_dir.name)):
    import main

class FolderDrop47(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='attendsync-drop-')
        self.addCleanup(self.tmp.cleanup)
        base = Path(self.tmp.name)
        p = patch.multiple(main, DATA_DIR=base, CONFIG=base/'settings.json', MAP=base/'mapping.json', DB=base/'cache.db')
        p.start(); self.addCleanup(p.stop)
        self.folder = base/'勤怠 データ'; self.folder.mkdir()
        self.file = base/'勤怠.csv'; self.file.write_text('test')
        self.w = main.Window(); self.w.show(); self.app.processEvents()
        self.addCleanup(self.cleanup_window)
    def cleanup_window(self):
        self.w.worker = None
        self.w.close(); self.w.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    def mime(self, urls):
        mime = QMimeData(); mime.setUrls(urls); return mime
    def dispatch(self, target, mime):
        # Send through QApplication, rather than calling handlers directly.
        events = [QDragEnterEvent(QPoint(5,5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier),
                  QDragMoveEvent(QPoint(5,5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier),
                  QDropEvent(QPointF(5,5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier)]
        for event in events: self.app.sendEvent(target, event)
        return events
    def test_all_native_drop_targets(self):
        targets = [self.w, self.w.centralWidget(), self.w.btn_settings, self.w.path,
                   self.w.search, self.w.year, self.w.year.lineEdit(), self.w.log_line,
                   self.w.table.viewport(), self.w.table.horizontalHeader().viewport(), self.w.empty_state]
        with patch.object(self.w, 'run_read') as run:
            for target in targets:
                with self.subTest(target=type(target).__name__):
                    self.w.path.setText('before'); self.w.search.setText('検索を保持')
                    events = self.dispatch(target, self.mime([QUrl.fromLocalFile(str(self.folder))]))
                    self.assertTrue(all(event.isAccepted() for event in events))
                    self.assertEqual(self.w.path.text(), str(self.folder.resolve()))
                    self.assertEqual(self.w.search.text(), '検索を保持')
                    self.assertTrue(all(event.dropAction()==Qt.CopyAction for event in events))
            run.assert_not_called()
        self.assertFalse(main.CONFIG.exists())
    def test_invalid_payload_never_replaces_fields(self):
        cases = [[QUrl.fromLocalFile(str(self.file))], [QUrl.fromLocalFile(str(self.folder))]*2,
                 [QUrl('https://example.com/folder')], [QUrl.fromLocalFile(str(self.folder/'missing'))], []]
        text = QMimeData(); text.setText('unexpected text')
        for mime in [self.mime(urls) for urls in cases] + [text]:
            for target in [self.w, self.w.path, self.w.search, self.w.table.viewport()]:
                self.w.path.setText('before'); self.w.search.setText('keep')
                events = self.dispatch(target, mime)
                self.assertFalse(any(event.isAccepted() for event in events))
                self.assertEqual(self.w.path.text(), 'before'); self.assertEqual(self.w.search.text(), 'keep')
    def test_busy_read_rejects_even_programmatic_drop(self):
        self.w.worker = Mock(); self.w.worker.isRunning.return_value = True
        self.w.path.setText('reading')
        for target in [self.w, self.w.search, self.w.path]:
            self.assertFalse(any(e.isAccepted() for e in self.dispatch(target, self.mime([QUrl.fromLocalFile(str(self.folder))]))))
            self.assertEqual(self.w.path.text(), 'reading')
    def test_separate_dialog_is_not_intercepted(self):
        dialog = QDialog(self.w); edit = QLineEdit(dialog); dialog.show()
        try:
            self.w.path.setText('main unchanged')
            self.dispatch(edit, self.mime([QUrl.fromLocalFile(str(self.folder))]))
            self.assertEqual(self.w.path.text(), 'main unchanged')
        finally:
            dialog.close(); dialog.deleteLater()
    def test_dynamic_child_routes_to_main(self):
        edit = QLineEdit(self.w.centralWidget()); edit.show()
        events = self.dispatch(edit, self.mime([QUrl.fromLocalFile(str(self.folder))]))
        self.assertTrue(all(e.isAccepted() for e in events))
        self.assertEqual(self.w.path.text(), str(self.folder.resolve()))

if __name__ == '__main__': unittest.main(verbosity=2)
