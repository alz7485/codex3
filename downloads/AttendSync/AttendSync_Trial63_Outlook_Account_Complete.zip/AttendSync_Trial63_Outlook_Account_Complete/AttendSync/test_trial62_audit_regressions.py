"""Regression coverage for independent Trial62 fault audits. No external mail."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import copy,json,tempfile,unittest,base64
from pathlib import Path
from engine import DEFAULT,csv_read,reconcile,save_json
from employee_information import recover_employee_save,load_information,plan_employee_import
from result_filters import csv_month_coverage,is_missing_month_csv_gap

class Audit62(unittest.TestCase):
 def test_all_recovery_snapshots_validate_before_any_file_change(self):
  for bad in ('!!corrupt!!',23,False,[]):
   for contact in (None,base64.b64encode(b'{"version":1}').decode()):
    with self.subTest(bad=bad,contact=contact),tempfile.TemporaryDirectory() as t:
     root=Path(t);mp=root/'staff_mapping.json';cp=root/'employee_contacts.json'
     mp.write_bytes(b'{"E1":"S1"}');cp.write_bytes(b'{"version":1,"contacts":[]}')
     before=(mp.read_bytes(),cp.read_bytes());journal=root/'employee_save_transaction.json'
     save_json(journal,{'mapping':bad,'contacts':contact})
     with self.assertRaises(ValueError):recover_employee_save(mp,cp)
     self.assertEqual((mp.read_bytes(),cp.read_bytes()),before);self.assertTrue(journal.exists())
 def parsed(self,root,length):
  row=['']*length;row[0]='20261001';row[3]='S1';row[4]='Name'
  path=root/'attendance.csv';path.write_text('header\n'+','.join(row)+'\n')
  return csv_read(path,copy.deepcopy(DEFAULT))['records'][0]
 def compare(self,record,cfg=None):
  x={'employee':'E1','name':'Name','date':'2026-10-01','values':{'start':None,'end':None,'work':None,'break_total':None}}
  return reconcile({'E1':{'info':{'name':'Name'},'records':[x]}},[record],{'E1':'S1'},cfg or copy.deepcopy(DEFAULT))[0]
 def test_absent_csv_columns_are_reviewed_instead_of_blank_matches(self):
  with tempfile.TemporaryDirectory() as t:
   record=self.parsed(Path(t),5);rows=self.compare(record)
   self.assertTrue({'start','end','work'}<=set(record['missing_fields']))
   self.assertFalse(any(r['status']=='一致' for r in rows))
   self.assertEqual(sum(r['field'].startswith('CSV列不足') for r in rows),3)
 def test_present_empty_csv_cells_still_match_blank_holiday(self):
  with tempfile.TemporaryDirectory() as t:
   rows=self.compare(self.parsed(Path(t),14))
   self.assertEqual(len(rows),3);self.assertTrue(all(r['status']=='一致' for r in rows))
 def test_cached_metadata_survives_comparison_toggle(self):
  with tempfile.TemporaryDirectory() as t:
   record=json.loads(json.dumps(self.parsed(Path(t),13)))
   self.assertFalse(any(r['field'].startswith('CSV列不足') for r in self.compare(record)))
   cfg=copy.deepcopy(DEFAULT);cfg['comparisons'][3]['enabled']=True
   self.assertTrue(any(r['field']=='CSV列不足：休憩合計' for r in self.compare(record,cfg)))
 def test_nonempty_row_missing_both_identifiers_warns(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'bad.csv';p.write_text('header\n,,,,name,,,,,,9:00\n')
   packet=csv_read(p,copy.deepcopy(DEFAULT));self.assertFalse(packet['records'])
   self.assertIn('IDまたは日付が空欄',packet['warnings'][0])
 def test_empty_file_warning_disables_month_hiding(self):
  self.assertIsNone(csv_month_coverage([{'date':'2026-10-01'}],warnings=[{'file':'empty.csv','reason':'CSVに有効な勤怠行がありません'}]))
 def test_invalid_xlsx_time_never_disappears_in_absent_month(self):
  for value in ('NOT_A_TIME',True,-1,float('nan'),'49:00'):
   row={'status':'要確認','field':'CSV記録なし','date':'2026-09-20','crecord':None,'xrecord':{'values':{'start':value}}}
   self.assertFalse(is_missing_month_csv_gap(row,{'2026-09'},copy.deepcopy(DEFAULT)))
 def test_import_profile_corruption_is_rejected_at_load(self):
  for profile in (None,[],{'columns':None},{'columns':{'staff':5}},{'first_row':'two'},{'first_row':True},{'first_row':1048577},{'encoding':'bad'}):
   with self.subTest(profile=profile),tempfile.TemporaryDirectory() as t:
    p=Path(t)/'employee_contacts.json';save_json(p,{'version':1,'contacts':[],'employee_import_settings':{'linking':profile}})
    with self.assertRaises(ValueError):load_information(p)
 def test_name_update_cannot_override_conflicting_id_pair(self):
  old={'version':1,'contacts':[],'employee_names':{'E1':'Old'}}
  for sid,expected in (('S1','New'),('S2','Old')):
   _,data,_=plan_employee_import([{'employee':'E1','staff':sid,'name':'New','email':''}],'linking',{'E1':'S1'},old)
   self.assertEqual(data['employee_names']['E1'],expected)
 def test_corrupt_cached_field_metadata_is_reparsed(self):
  # Corruption is disposable cache data, never trusted as parsed input.
  from test_trial54_mail import main
  for field in ('invalid_fields','missing_fields'):
   for bad in (None,'start',[[]],[{}],[False],[0]):
    packet={'records':[{'date':'2026-10-01','staff':'S1','name':'Name','values':{},field:bad}]}
    self.assertFalse(main.ReadWorker._valid_cached_packet(packet,False))
  packet={'records':[{'date':'2026-10-01','staff':'S1','name':'Name','values':{},'missing_fields':['start']}]}
  self.assertTrue(main.ReadWorker._valid_cached_packet(packet,False))
 def test_falsey_history_entry_cannot_trigger_duplicate_remote_call(self):
  from test_trial54_mail import Mail
  from microsoft_mail import process_graph_plans
  fixture=Mail();plan=fixture.plans()[:1];settings=fixture.settings(True)
  for bad in ({},None,'',False,[]):
   with self.subTest(bad=bad),tempfile.TemporaryDirectory() as t:
    calls=[]
    def transport(method,path,payload):
     calls.append(path);return {'_http_status':202} if path.endswith('/send') else {'id':'mock'}
    process_graph_plans(plan,settings,t,transport)
    path=Path(t)/'mail_processing_history.json';ledger=json.loads(path.read_text())
    key=next(iter(ledger));ledger[key]=bad;save_json(path,ledger);calls.clear()
    result=process_graph_plans(plan,settings,t,transport)
    self.assertFalse(calls);self.assertIn('再実行を停止',result[0]['status'])

if __name__=='__main__':unittest.main()
