"""User-facing settings with stable field identities and lossless extension data."""
from __future__ import annotations
import copy
import json
import re
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
    QLabel, QLineEdit, QSpinBox, QComboBox, QCheckBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QTabWidget,
    QScrollArea, QStackedWidget, QButtonGroup, QTextEdit, QMenu, QFormLayout, QFrame,
    QInputDialog, QMessageBox, QSizePolicy,
)
from openpyxl.utils.cell import column_index_from_string
from engine import DEFAULT, NAMES
from outlook_mail import DEFAULT_MAIL_SETTINGS,validate_mail_settings
from ui_theme import button, refresh_button_icons

DETAIL_REFERENCE_FIELDS=[('月','month',None),('日','day','date'),('勤怠名称','label','calendar'),('勤怠区分','code',None),
    ('始業時刻','start','start'),('終業時刻','end','end'),('所定内休憩（昼）','break_day',None),
    ('所定内休憩（深夜）','break_night',None),('残業内休憩（昼）','ot_break_day',None),
    ('残業内休憩（深夜）','ot_break_night',None),('休憩合計','break_total','break_total'),
    ('普通残業','ot',None),('深夜残業','ot_night',None),('法休残業','holiday_ot',None),
    ('法休深夜','holiday_night',None),('実働時間','work','work')]
TITLES={'date':'日付','staff':'スタッフID','name':'氏名','employee':'社員番号','period':'対象年月','organization':'所属',
        **NAMES}
SHORT_TITLES={'break_day':'所定休憩・昼','break_night':'所定休憩深夜','ot_break_day':'残業休憩・昼','ot_break_night':'残業休憩深夜',
              'holiday_night':'法休深夜','organization':'所属'}
REQUIRED={'xlsx_columns':{'day'},'csv_columns':{'date','staff'},'info_cells':{'period','employee','name','organization'}}
FORMATS=[('clock','時刻（始業・終業）'),('duration','時間（実働・休憩）'),('text','文字列'),('number','値（文字列として比較）')]


def field_caption(cfg,source,key):
    custom=cfg.get('field_labels',{}).get(source,{}).get(key)
    if custom:return custom
    if key in TITLES:return TITLES[key]
    side={'xlsx_columns':'xlsx','csv_columns':'csv'}.get(source)
    if side:
        matching=next((entry for entry in cfg.get('comparisons',[]) if entry.get(side)==key and entry.get('name')),None)
        if matching:return matching['name']
    return str(key)


def comparison_for_pair(cfg,xkey,ckey):
    """Prefer an enabled rule when a legacy OFF rule shares the same pair."""
    matches=[entry for entry in cfg.get('comparisons',[])
             if entry.get('xlsx')==xkey and entry.get('csv')==ckey]
    return next((entry for entry in matches if entry.get('enabled')),matches[0] if matches else None)


def detail_fields_for(cfg):
    fields=[]
    comparisons=cfg.get('comparisons',[])
    for name,xkey,ckey in DETAIL_REFERENCE_FIELDS:
        matching=comparison_for_pair(cfg,xkey,ckey)
        custom=cfg.get('field_labels',{}).get('xlsx_columns',{}).get(xkey)
        fields.append((custom or (matching.get('name') if matching else None) or name,xkey,ckey))
    pairs={(f[1],f[2]) for f in fields}
    for entry in cfg.get('comparisons',[]):
        pair=(entry.get('xlsx'),entry.get('csv'))
        if pair not in pairs:
            fields.append((entry.get('name') or field_caption(cfg,'xlsx_columns',pair[0]),*pair));pairs.add(pair)
    for key in cfg.get('xlsx_columns',{}):
        if key not in {f[1] for f in fields}:
            ckey=key if key in cfg.get('csv_columns',{}) else None
            fields.append((field_caption(cfg,'xlsx_columns',key),key,ckey))
    for key in cfg.get('csv_columns',{}):
        if key not in {f[2] for f in fields}:
            fields.append((field_caption(cfg,'csv_columns',key),None,key))
    return fields


class SettingsError(ValueError):
    def __init__(self,message,control=None):
        super().__init__(message);self.control=control


class SettingsDialog(QDialog):
    """Three main tabs; each task has its own short, navigable page."""
    def __init__(self,parent,cfg):
        super().__init__(parent)
        self.setWindowTitle('設定 | 勤怠チェッカー')
        self.resize(1060,780);self.setMinimumSize(780,580)
        self._building=True
        self._base=copy.deepcopy(cfg);self.original=copy.deepcopy(cfg)
        self._labels=copy.deepcopy(cfg.get('field_labels',{}))
        self.entries=[];self._field_groups={};self._labels_changed=False
        self._extra_detail_keys=[];self._detail_initial=None
        self.setObjectName('settingsDialog')
        root=QVBoxLayout(self);root.setContentsMargins(20,18,20,16);root.setSpacing(10)
        root.addWidget(self._label('設定','pageTitle'))
        root.addWidget(self._label('読み込む場所、照合する項目、詳細に表示する項目を設定します。','subtitle'))
        self.tabs=QTabWidget();self.tabs.setDocumentMode(True);root.addWidget(self.tabs,1)

        read_page,read_layout=self._page(scroll=False)
        self.read_navigation,self.read_stack=self._navigation(read_layout,[('xlsx','派遣元 XLSX'),('csv','派遣先 CSV')])
        self.tabs.addTab(read_page,'読み込み設定')
        xpage,xroot=self._page();self.read_stack.addWidget(xpage)
        group,grid=self._group_grid(xroot,'読み込み速度')
        self.workers=self._spin(cfg.get('read_workers',4),1,8)
        self._control(grid,0,0,'同時読み込み数',self.workers)
        grid.addWidget(self._label('通常は4。ネットワーク上で不安定な場合は1～2へ下げます。','muted'),0,1);grid.setColumnStretch(1,1)
        self.first=self._spin(cfg.get('data_first_row',9),1,1048576)
        self.last=self._spin(cfg.get('data_last_row',100),1,1048576)
        group,grid=self._group_grid(xroot,'日別データの読み込み範囲')
        self.range_group=group
        self._control(grid,0,0,'開始行',self.first);self._control(grid,0,1,'終了行',self.last)
        grid.addWidget(self._label('月の境目の空白行は読み飛ばします。','muted'),0,2);grid.setColumnStretch(2,1)
        self._section_columns(xroot,'基本情報のセル','info_cells',cfg.get('info_cells',DEFAULT['info_cells']),
                              '社員番号を基準にCSVのスタッフIDと対応付けます。入力例：N1。')
        self._section_columns(xroot,'日別データの列','xlsx_columns',cfg.get('xlsx_columns',DEFAULT['xlsx_columns']),
                              '列記号を指定します。入力例：G。使わない任意項目は空欄にできます。')
        xroot.addWidget(self._label('1月度は前年12/16～1/15、10月度は9/16～10/15です。','banner'))
        group,grid=self._group_grid(xroot,'月度ごとのシート名')
        self.sheet_edits={}
        for n in range(1,13):
            edit=QLineEdit(cfg.get('sheet_names',{}).get(str(n),f'{n}月'));edit.setMaximumWidth(88);edit.setMinimumWidth(62)
            self.sheet_edits[str(n)]=edit;self._control(grid,(n-1)//6,(n-1)%6,f'{n}月度',edit)
        grid.setColumnStretch(6,1)
        xroot.addStretch()
        cpage,croot=self._page();self.read_stack.addWidget(cpage)
        self._section_columns(croot,'CSVの列','csv_columns',cfg.get('csv_columns',DEFAULT['csv_columns']),
                              '日付はYYYYMMDD形式。氏名だけでなくスタッフIDで社員を特定します。')
        group,grid=self._group_grid(croot,'CSVの読み込み方法')
        self.csv_first=self._spin(cfg.get('csv_first_row',2),1,1048576)
        self.csv_encoding=QComboBox()
        for text,value in [('自動判定（推奨）','auto'),('CP932 / Shift-JIS','cp932'),('UTF-8','utf-8'),('UTF-8 BOM','utf-8-sig')]:self.csv_encoding.addItem(text,value)
        self._select_data(self.csv_encoding,cfg.get('csv_encoding','auto'),'既存の文字コード')
        self.csv_encoding.setMinimumWidth(170);self.csv_encoding.setMaximumWidth(240)
        self._control(grid,0,0,'データ開始行',self.csv_first);self._control(grid,0,1,'文字コード',self.csv_encoding)
        grid.setColumnStretch(2,1)
        croot.addWidget(self._label('見出しが1行ある場合は開始行を「2」にします。通常は文字コードを自動判定します。','muted'))
        croot.addStretch()

        compare_page,compare_layout=self._page(scroll=False)
        self.compare_navigation,self.compare_stack=self._navigation(compare_layout,[('compare','照合項目'),('codes','勤怠区分の名称')])
        self.tabs.addTab(compare_page,'照合・勤怠設定')
        self.compare_stack.addWidget(self._build_comparisons(cfg))
        self.compare_stack.addWidget(self._build_codes(cfg))

        detail_page,detail_layout=self._page()
        self.tabs.addTab(detail_page,'詳細設定')
        self._detail_layout=detail_layout
        self.detail_group=QGroupBox('詳細対比表・印刷に表示する項目')
        self.detail_grid=QGridLayout(self.detail_group);self.detail_grid.setContentsMargins(14,16,14,12)
        detail_layout.addWidget(self.detail_group)
        self._build_detail_checks(cfg)
        self.compatibility_toggle=button('所定時刻の互換設定を表示','clock','quiet')
        self.compatibility_toggle.setCheckable(True);detail_layout.addWidget(self.compatibility_toggle)
        self.compatibility_panel=self._build_schedule(cfg);self.compatibility_panel.hide()
        detail_layout.addWidget(self.compatibility_panel)
        self.compatibility_toggle.toggled.connect(self._toggle_compatibility)
        self.advanced_toggle=button('詳細JSONを表示','sliders','quiet');self.advanced_toggle.setCheckable(True)
        detail_layout.addWidget(self.advanced_toggle)
        self.advanced_panel=QGroupBox('追加設定の編集')
        adv=QVBoxLayout(self.advanced_panel);adv.setSpacing(8)
        adv.addWidget(self._label('JSONを変更したら「入力欄に反映」を押してください。追加の設定も保存されます。','muted'))
        self.advanced=QTextEdit();self.advanced.setLineWrapMode(QTextEdit.NoWrap);self.advanced.setMinimumHeight(210)
        self.advanced.setAccessibleName('追加設定のJSON');adv.addWidget(self.advanced)
        actions=QHBoxLayout()
        self.advanced_apply=button('JSONを入力欄に反映','check')
        self.advanced_export=button('現在の入力をJSONに反映','refresh')
        actions.addWidget(self.advanced_apply);actions.addWidget(self.advanced_export);actions.addStretch();adv.addLayout(actions)
        self.advanced_apply.clicked.connect(self.apply_json_to_form);self.advanced_export.clicked.connect(self.export_form_to_json)
        self.advanced_panel.hide();detail_layout.addWidget(self.advanced_panel);detail_layout.addStretch()
        self.advanced_toggle.toggled.connect(self._toggle_advanced)
        mail_page,mail_layout=self._page()
        self.tabs.addTab(mail_page,'メール')
        mail_layout.addWidget(self._label('社員ごとの宛先は社員情報のメールアドレスを使います。ここでは全メールに入れる宛先と文面を設定します。','muted'))
        self.mail_controls={}
        mail=validate_mail_settings(cfg.get('mail_settings',{}))
        auto=QCheckBox('メール作成時に自動送信する（OFF：下書き保存）');auto.setChecked(mail['auto_send']);self.mail_controls['auto_send']=auto;mail_layout.addWidget(auto)
        connection=QGroupBox('Microsoftアカウント接続');connection_form=QFormLayout(connection)
        for key,title in [('account','接続するアカウント'),('client_id','MicrosoftアプリID'),('tenant_id','テナントID')]:
            edit=QLineEdit(mail[key]);self.mail_controls[key]=edit;connection_form.addRow(title,edit)
        self.outlook_account_button=button('起動中のOutlookから取得','mail')
        self.outlook_account_button.setObjectName('readOutlookAccount')
        self.outlook_account_button.setSizePolicy(QSizePolicy.Maximum,QSizePolicy.Fixed)
        self.outlook_account_button.setToolTip('クラシックOutlookのメールアドレスと表示名を取得します。')
        connection_form.addRow(self.outlook_account_button)
        self.outlook_account_status=self._label('','muted');self.outlook_account_status.hide()
        connection_form.addRow(self.outlook_account_status)
        self.outlook_account_button.clicked.connect(self._read_outlook_account)
        mail_layout.addWidget(connection)
        mail_layout.addWidget(self._label('初回はMicrosoftアプリ登録（デスクトップ/パブリッククライアント、http://localhost）とメール権限の設定が必要です。実行時にブラウザでサインインします。詳しくは操作ガイドを参照してください。','muted'))
        group=QGroupBox('宛先と名前');form=QFormLayout(group)
        for key,title in [('always_to','必ず入れる宛先（To）'),('always_cc','必ず入れるCC'),('sender_name','差出人名（本文用）'),('name_suffix','宛名の敬称')]:
            edit=QLineEdit(mail[key]);self.mail_controls[key]=edit;form.addRow(title,edit)
            if key in ('always_to','always_cc'):edit.setPlaceholderText('例：tanto@example.com; manager@example.com')
        mail_layout.addWidget(group)
        mail_layout.addWidget(self._label('複数アドレスは ; で区切ります。「人名 <アドレス>」の形式でも指定できます。','muted'))
        subject=QLineEdit(mail['subject']);self.mail_controls['subject']=subject
        mail_layout.addWidget(self._label('件名','fieldHint'));mail_layout.addWidget(subject)
        mail_layout.addWidget(self._label('本文','fieldHint'))
        body=QTextEdit();body.setAcceptRichText(False);body.setPlainText(mail['body']);body.setMinimumHeight(220);self.mail_controls['body']=body;mail_layout.addWidget(body)
        mail_layout.addWidget(self._label('差し込み：{recipient_name} 宛名、{name} 社員名、{employee_id} 社員ID、{staff_id} スタッフID、{year} 年、{month} 月度、{count} 不一致件数、{differences} 不一致内容、{sender_name} 差出人名、{signature} 署名。本文に {differences} を含めてください。','muted'))
        mail_layout.addWidget(self._label('署名','fieldHint'))
        signature=QTextEdit();signature.setAcceptRichText(False);signature.setPlainText(mail['signature']);signature.setMinimumHeight(90);self.mail_controls['signature']=signature;mail_layout.addWidget(signature)
        mail_layout.addStretch()
        self._set_json(cfg)

        self.error_label=self._label('','settingsError');self.error_label.hide();root.addWidget(self.error_label)
        separator=QFrame();separator.setObjectName('footerSeparator');separator.setFixedHeight(1)
        root.addWidget(separator)
        footer=QHBoxLayout();footer.setSpacing(8)
        footer.addWidget(self._label('読み込み設定は再読み込み、メール設定は保存後すぐ反映します。','muted'),1)
        cancel=button('キャンセル','x');cancel.clicked.connect(self.reject)
        save=button('設定を保存','save','primary');save.clicked.connect(self.accept)
        footer.addWidget(cancel);footer.addWidget(save);root.addLayout(footer)
        self._building=False
        self.compares.itemChanged.connect(self._comparison_changed)
        self.tabs.currentChanged.connect(lambda index:self._refresh_detail_fields() if index==2 else None)
        refresh_button_icons(self,parent.is_dark)

    def _read_outlook_account(self):
        from classic_outlook import running_outlook_accounts
        self.outlook_account_button.setEnabled(False)
        self.outlook_account_status.hide()
        try:
            accounts=running_outlook_accounts()
            if len(accounts)==1:selected=accounts[0]
            else:
                choices=[f'{item["sender_name"] or "名称なし"} <{item["account"]}>' for item in accounts]
                current=self.mail_controls['account'].text().strip().casefold()
                index=next((i for i,item in enumerate(accounts) if item['account'].casefold()==current),0)
                choice,accepted=QInputDialog.getItem(self,'Outlookのアカウント','設定に使うアカウント',choices,index,False)
                if not accepted:return
                selected=accounts[choices.index(choice)]
            self.mail_controls['account'].setText(selected['account'])
            if selected['sender_name']:self.mail_controls['sender_name'].setText(selected['sender_name'])
            self.outlook_account_status.setText('アカウントと表示名を反映しました。「設定を保存」で確定します。' if selected['sender_name'] else 'アカウントを反映しました。差出人名を確認して「設定を保存」してください。')
            self.outlook_account_status.show()
        except Exception as exc:
            QMessageBox.warning(self,'Outlookから取得できません',str(exc))
        finally:self.outlook_account_button.setEnabled(True)

    @staticmethod
    def _label(text,role=None):
        widget=QLabel(text);widget.setWordWrap(True)
        if role:widget.setObjectName(role)
        return widget

    @staticmethod
    def _page(scroll=True):
        inner=QWidget();layout=QVBoxLayout(inner);layout.setContentsMargins(12,12,12,12);layout.setSpacing(12)
        if not scroll:return inner,layout
        area=QScrollArea();area.setWidgetResizable(True);area.setWidget(inner)
        return area,layout

    @staticmethod
    def _navigation(layout,items):
        row=QHBoxLayout();row.setSpacing(6);buttons={};group=QButtonGroup(layout.parentWidget());group.setExclusive(True)
        stack=QStackedWidget()
        for index,(key,text) in enumerate(items):
            btn=button(text,'','segment');btn.setCheckable(True);btn.setChecked(index==0);group.addButton(btn)
            btn.clicked.connect(lambda checked=False,i=index:stack.setCurrentIndex(i));row.addWidget(btn);buttons[key]=btn
        row.addStretch();layout.addLayout(row);layout.addWidget(stack,1)
        return buttons,stack

    @staticmethod
    def _spin(value,minimum,maximum):
        spin=QSpinBox();spin.setRange(minimum,maximum);spin.setValue(int(value));spin.setMaximumWidth(110)
        return spin

    def _group_grid(self,layout,title):
        group=QGroupBox(title);grid=QGridLayout(group);grid.setHorizontalSpacing(10);grid.setVerticalSpacing(8)
        layout.addWidget(group);return group,grid

    def _control(self,grid,row,col,title,control):
        cell=QWidget();layout=QVBoxLayout(cell);layout.setContentsMargins(0,0,0,0);layout.setSpacing(4)
        caption=self._label(title,'fieldHint');caption.setToolTip(title);layout.addWidget(caption);layout.addWidget(control)
        grid.addWidget(cell,row,col);return caption

    def _section_columns(self,layout,title,source,items,description):
        group=QGroupBox(title);root=QVBoxLayout(group);root.setSpacing(8)
        heading=QHBoxLayout();heading.addWidget(self._label(description,'muted'),1)
        actions=button('項目を編集','settings','quiet');actions.setToolTip('項目の追加・名称変更・削除')
        menu=QMenu(actions)
        menu.addAction('項目を追加',lambda:self._add_field_dialog(source))
        menu.addAction('項目名を変更',lambda:self._rename_field_dialog(source))
        menu.addAction('項目を削除',lambda:self._remove_field_dialog(source))
        actions.setMenu(menu);heading.addWidget(actions);root.addLayout(heading)
        grid=QGridLayout();grid.setHorizontalSpacing(8);grid.setVerticalSpacing(7);root.addLayout(grid)
        self._field_groups[source]=(grid,group)
        for key,value in items.items():self._append_source_entry(source,key,value)
        layout.addWidget(group)

    def _field_label(self,source,key):
        return field_caption({'field_labels':self._labels,'comparisons':self._base.get('comparisons',[])},source,key)

    def _append_source_entry(self,source,key,value):
        grid,_=self._field_groups[source]
        n=sum(k==source for k,_,_ in self.entries)
        title=self._labels.get(source,{}).get(key,SHORT_TITLES.get(key,self._field_label(source,key)))
        edit=QLineEdit('' if value is None else str(value));edit.setMaximumWidth(88);edit.setMinimumWidth(62)
        edit.setAccessibleName(title);edit.setToolTip(f'{title}の'+('セル番地（例：N1）。必須項目です。' if source=='info_cells' else '列記号（例：G）。'+('必須項目です。' if key in REQUIRED[source] else '任意項目は空欄で読み込み対象外。')))
        caption=self._control(grid,n//6,n%6,title,edit);caption.setWordWrap(False)
        caption.setMaximumWidth(88);caption.setText(caption.fontMetrics().elidedText(title,Qt.ElideRight,88))
        edit.setProperty('captionWidget',caption);self.entries.append((source,key,edit));grid.setColumnStretch(6,1)

    @staticmethod
    def _select_data(combo,value,caption):
        index=combo.findData(value)
        if index<0:combo.addItem(f'{caption}：{value}',value);index=combo.count()-1
        combo.setCurrentIndex(index)

    def _build_comparisons(self,cfg):
        page,layout=self._page(scroll=False)
        layout.addWidget(self._label('ONの項目だけを照合します。詳細対比表の表示項目とは独立しています。','banner'))
        self.compares=QTableWidget(0,5)
        self.compares.setHorizontalHeaderLabels(['照合','項目名','派遣元 XLSX','派遣先 CSV','比較方法'])
        self.compares.verticalHeader().hide();self.compares.verticalHeader().setDefaultSectionSize(44)
        self.compares.setAlternatingRowColors(True);self.compares.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.compares.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.compares.horizontalHeader().setSectionResizeMode(0,QHeaderView.Fixed);self.compares.setColumnWidth(0,60)
        for item in cfg.get('comparisons',[]):self.add_compare(item)
        layout.addWidget(self.compares,1)
        row=QHBoxLayout()
        add=button('照合項目を追加','plus');add.clicked.connect(self.add_comparison_from_columns)
        remove=button('選択項目を削除','trash','danger');remove.clicked.connect(self.remove_compare)
        row.addWidget(add);row.addWidget(remove);row.addStretch();layout.addLayout(row)
        layout.addWidget(self._label('時刻：25:00と1:00を同じ時刻として比較。時間：24時間を超える長さも保持します。','muted'))
        return page

    def _source_combo(self,source,key):
        combo=QComboBox();combo.setMinimumWidth(90)
        combo.addItem('項目を選択','')
        for _,field,_ in (entry for entry in self.entries if entry[0]==source):
            combo.addItem(self._field_label(source,field),field)
        self._select_data(combo,key,'既存の項目')
        return combo

    def add_compare(self,data):
        previous_building=self._building;self._building=True
        row=self.compares.rowCount();self.compares.insertRow(row)
        panel=QWidget();line=QHBoxLayout(panel);line.setContentsMargins(0,0,0,0);line.setAlignment(Qt.AlignCenter)
        checked=QCheckBox();checked.setChecked(bool(data.get('enabled')));checked.setAccessibleName('この項目を照合');line.addWidget(checked)
        # Preserve the historical cellWidget(0).isChecked API for integrations.
        panel.isChecked=checked.isChecked;panel.setChecked=checked.setChecked
        self.compares.setCellWidget(row,0,panel)
        name=QTableWidgetItem(str(data.get('name','')));name.setData(Qt.UserRole,copy.deepcopy(data));self.compares.setItem(row,1,name)
        for column,source,key in [(2,'xlsx_columns',data.get('xlsx','')),(3,'csv_columns',data.get('csv',''))]:
            raw=QTableWidgetItem(str(key or ''));self.compares.setItem(row,column,raw)
            combo=self._source_combo(source,key);self.compares.setCellWidget(row,column,combo)
            combo.currentIndexChanged.connect(lambda index,c=combo,item=raw:item.setText(str(c.currentData() or '')))
        combo=QComboBox()
        for value,text in FORMATS:combo.addItem(text,value)
        self._select_data(combo,data.get('type','text'),'未対応の形式（要確認になります）')
        self.compares.setCellWidget(row,4,combo)
        self._building=previous_building
        for column in (2,3):self.compares.cellWidget(row,column).currentIndexChanged.connect(self._comparison_changed)
        if hasattr(self,'detail_grid'):self._refresh_detail_fields()

    def add_comparison_from_columns(self):
        self.add_compare({'name':'新しい照合項目','xlsx':'','csv':'','type':'duration','enabled':False})
        row=self.compares.rowCount()-1;self.compares.setCurrentCell(row,1);self.compares.editItem(self.compares.item(row,1))

    def remove_compare(self):
        row=self.compares.currentRow()
        if row>=0:self.compares.removeRow(row);self._refresh_detail_fields()

    def _build_codes(self,cfg):
        page,layout=self._page(scroll=False)
        layout.addWidget(self._label('Excelの勤怠区分コードに表示名を付けます。CSVに区分がない場合は、この区分だけで照合しません。','muted'))
        self.codes=QTableWidget(0,2);self.codes.setHorizontalHeaderLabels(['区分コード','表示する勤怠名称'])
        self.codes.verticalHeader().hide();self.codes.verticalHeader().setDefaultSectionSize(38)
        self.codes.setAlternatingRowColors(True);self.codes.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.codes.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch);self.codes.setColumnWidth(0,140)
        for code,name in cfg.get('codes',{}).items():self.add_code(code,name)
        layout.addWidget(self.codes,1)
        row=QHBoxLayout();add=button('区分を追加','plus');add.clicked.connect(lambda:self.add_code('',''))
        remove=button('選択区分を削除','trash','danger');remove.clicked.connect(lambda:self.codes.removeRow(self.codes.currentRow()) if self.codes.currentRow()>=0 else None)
        row.addWidget(add);row.addWidget(remove);row.addStretch();layout.addLayout(row)
        return page

    def add_code(self,code,name):
        row=self.codes.rowCount();self.codes.insertRow(row)
        self.codes.setItem(row,0,QTableWidgetItem(str(code)));self.codes.setItem(row,1,QTableWidgetItem(str(name)))

    def _build_schedule(self,cfg):
        group=QGroupBox('既存の所定時刻設定');grid=QGridLayout(group)
        grid.addWidget(self._label('既存設定の保持用です。現在の照合判定には使用しません。','muted'),0,0,1,4)
        sched=cfg.get('xlsx_schedule',DEFAULT['xlsx_schedule']);self.schedule_cols={};self.schedule_rows={}
        for i,(key,title) in enumerate([('label','勤怠種類の列'),('start','始業の列'),('end','終業の列'),('break_total','休憩の列')]):
            edit=QLineEdit(str(sched.get(key,DEFAULT['xlsx_schedule'][key])));edit.setMaximumWidth(88)
            self.schedule_cols[key]=edit;self._control(grid,1,i,title,edit)
        for i,(code,title) in enumerate([('1','勤務Ⅰ'),('10','勤務Ⅱ'),('11','勤務Ⅲ'),('12','勤務Ⅳ')]):
            edit=QLineEdit(str(sched.get('rows',{}).get(code,4+i)));edit.setMaximumWidth(88)
            self.schedule_rows[code]=edit;self._control(grid,2,i,f'{title}の行',edit)
        return group

    @staticmethod
    def _detail_key(field):return str(field[1])+'|'+str(field[2] or '')

    def _comparison_values(self):
        values=[]
        for row in range(self.compares.rowCount()):
            name=self.compares.item(row,1);entry=copy.deepcopy(name.data(Qt.UserRole) or {})
            entry.update(enabled=self.compares.cellWidget(row,0).isChecked(),name=name.text().strip(),
                xlsx=self.compares.cellWidget(row,2).currentData(),csv=self.compares.cellWidget(row,3).currentData(),
                type=self.compares.cellWidget(row,4).currentData())
            values.append(entry)
        return values

    def _build_detail_checks(self,cfg):
        while self.detail_grid.count():
            item=self.detail_grid.takeAt(0)
            if item.widget():item.widget().hide();item.widget().deleteLater()
        self.detail_checks={}
        self.detail_grid.addWidget(self._label('チェックした項目を詳細対比表と詳細印刷に表示します。照合のON/OFFは変わりません。','muted'),0,0,1,3)
        fields=detail_fields_for(cfg);allowed=cfg.get('detail_visible_fields');allowed_set=set(allowed) if isinstance(allowed,list) else None
        keys={self._detail_key(f) for f in fields};self._extra_detail_keys=[k for k in allowed or [] if k not in keys]
        for n,field in enumerate(fields):
            key=self._detail_key(field);check=QCheckBox(field[0]);check.setChecked(allowed_set is None or key in allowed_set)
            check.setToolTip(field[0]);self.detail_checks[key]=check;self.detail_grid.addWidget(check,1+n//3,n%3)
        actions=QWidget();row=QHBoxLayout(actions);row.setContentsMargins(0,0,0,0)
        all_on=button('すべて表示','check','quiet');all_off=button('すべて非表示','stop','quiet')
        all_on.clicked.connect(lambda:[check.setChecked(True) for check in self.detail_checks.values()])
        all_off.clicked.connect(lambda:[check.setChecked(False) for check in self.detail_checks.values()])
        row.addWidget(all_on);row.addWidget(all_off);row.addStretch()
        self.detail_grid.addWidget(actions,2+(len(fields)-1)//3,0,1,3)
        self._detail_initial={key:check.isChecked() for key,check in self.detail_checks.items()}
        refresh_button_icons(self,self.parent().is_dark)

    def _comparison_changed(self,*args):
        if not self._building:self._refresh_detail_fields()

    def _refresh_detail_fields(self):
        if self._building or not hasattr(self,'detail_grid'):return
        cfg=copy.deepcopy(self._base);cfg['comparisons']=self._comparison_values()
        for source,key,edit in self.entries:cfg.setdefault(source,{})[key]=edit.text()
        cfg['field_labels']=copy.deepcopy(self._labels)
        current={key:check.isChecked() for key,check in self.detail_checks.items()}
        self._build_detail_checks(cfg)
        for key,check in self.detail_checks.items():
            if key in current:check.setChecked(current[key])

    def _toggle_advanced(self,checked):
        self.advanced_panel.setVisible(checked);self.advanced_toggle.setText('詳細JSONを閉じる' if checked else '詳細JSONを表示')

    def _toggle_compatibility(self,checked):
        self.compatibility_panel.setVisible(checked);self.compatibility_toggle.setText('所定時刻の互換設定を閉じる' if checked else '所定時刻の互換設定を表示')

    def _set_json(self,cfg):
        self._json_snapshot=json.dumps(cfg,ensure_ascii=False,indent=2);self.advanced.setPlainText(self._json_snapshot)

    def _show_error(self,error):
        self.error_label.setText(str(error));self.error_label.show()
        control=getattr(error,'control',None)
        if control is not None:
            if control is self.advanced:self.tabs.setCurrentIndex(2);self.advanced_toggle.setChecked(True)
            else:
                for tab in range(self.tabs.count()):
                    if self.tabs.widget(tab).isAncestorOf(control):self.tabs.setCurrentIndex(tab);break
                for stack in (self.read_stack,self.compare_stack):
                    for index in range(stack.count()):
                        if stack.widget(index).isAncestorOf(control):
                            stack.setCurrentIndex(index)
                            buttons=self.read_navigation if stack is self.read_stack else self.compare_navigation
                            list(buttons.values())[index].setChecked(True);break
                if self.compatibility_panel.isAncestorOf(control):self.compatibility_toggle.setChecked(True)
            area=control.parentWidget()
            while area is not None and not isinstance(area,QScrollArea):area=area.parentWidget()
            if area is not None:area.ensureWidgetVisible(control)
            control.setFocus(Qt.OtherFocusReason)
            if isinstance(control,QLineEdit):control.selectAll()

    def _clear_error(self):self.error_label.hide();self.error_label.clear()

    def _parse_json(self):
        try:value=json.loads(self.advanced.toPlainText())
        except json.JSONDecodeError as exc:raise SettingsError(f'JSONの{exc.lineno}行{exc.colno}文字目を確認してください。',self.advanced) from exc
        if not isinstance(value,dict):raise SettingsError('JSONは設定名と値を持つオブジェクト形式で入力してください。',self.advanced)
        return value

    def _ensure_json_applied(self):
        if self.advanced.toPlainText()!=self._json_snapshot:
            self._parse_json()
            raise SettingsError('JSONの変更は「JSONを入力欄に反映」を押してから保存してください。',self.advanced)

    @staticmethod
    def _valid_address(value,cell=False):
        match=re.fullmatch(r'([A-Z]{1,3})([1-9]\d*)' if cell else r'([A-Z]{1,3})',value)
        if not match:return False
        try:valid=column_index_from_string(match[1])<=16384
        except ValueError:return False
        return valid and (not cell or int(match[2])<=1048576)

    def _collect_config(self):
        updated=copy.deepcopy(self._base)
        for source in REQUIRED:
            expected=REQUIRED[source]|({'month'} if source=='xlsx_columns' else set())
            missing=expected-{key for s,key,_ in self.entries if s==source}
            if missing:raise SettingsError('日付や社員識別に必要な項目がありません。読み込み項目を確認してください。')
        for source,key,edit in self.entries:
            if '|' in key:raise SettingsError('内部項目IDには区切り文字「|」を使用できません。表示する項目名は自由に設定できます。',edit)
            value=edit.text().strip().upper();name=self._field_label(source,key)
            if not value and (key in REQUIRED[source] or source=='info_cells'):raise SettingsError(f'「{name}」を入力してください。',edit)
            if value and not self._valid_address(value,source=='info_cells'):
                raise SettingsError(f'「{name}」の'+('セル番地' if source=='info_cells' else '列記号')+'を確認してください。Excelの上限はXFD列・1,048,576行です。',edit)
            original=self._base.get(source,{}).get(key,'')
            updated.setdefault(source,{})[key]=None if original is None and not value else value
        for key,control,default in [('csv_first_row',self.csv_first,2),('data_first_row',self.first,9),('data_last_row',self.last,100),('read_workers',self.workers,4)]:
            if key in self._base or control.value()!=default:updated[key]=control.value()
        updated['csv_encoding']=self.csv_encoding.currentData()
        if self.first.value()>self.last.value():raise SettingsError('終了行は開始行以降を指定してください。',self.last)
        updated.setdefault('sheet_names',{}).update({month:edit.text().strip() for month,edit in self.sheet_edits.items()})
        for month,edit in self.sheet_edits.items():
            if not edit.text().strip():raise SettingsError(f'{month}月度のシート名を入力してください。',edit)
        sched=updated.setdefault('xlsx_schedule',{})
        for key,edit in self.schedule_cols.items():
            value=edit.text().strip().upper()
            if not self._valid_address(value):raise SettingsError('所定時刻の列記号を確認してください。',edit)
            sched[key]=value
        for code,edit in self.schedule_rows.items():
            value=edit.text().strip()
            if not value.isdecimal() or not 1<=int(value)<=1048576:raise SettingsError('所定時刻の行番号は1～1,048,576で入力してください。',edit)
            sched.setdefault('rows',{})[code]=int(value)
        codes={}
        for row in range(self.codes.rowCount()):
            key=self.codes.item(row,0).text().strip() if self.codes.item(row,0) else ''
            name=self.codes.item(row,1).text().strip() if self.codes.item(row,1) else ''
            if not key or not name:raise SettingsError(f'勤怠区分の{row+1}行目にコードと名称を入力してください。',self.codes)
            if key in codes:raise SettingsError(f'勤怠区分コード「{key}」が重複しています。',self.codes)
            codes[key]=name
        updated['codes']=codes
        comparisons=self._comparison_values()
        from collections import Counter
        existing_names=Counter(e.get('name','') for e in self._base.get('comparisons',[]))
        names=Counter(e['name'] for e in comparisons)
        for name,count in names.items():
            if count>1 and count>existing_names[name]:raise SettingsError(f'照合項目名「{name}」が重複しています。区別できる名前を入力してください。',self.compares)
        for row,entry in enumerate(comparisons):
            if not entry['name']:raise SettingsError(f'照合項目の{row+1}行目に項目名を入力してください。',self.compares)
            if any('|' in (entry.get(side) or '') for side in ('xlsx','csv')):
                raise SettingsError('照合元の内部項目IDには区切り文字「|」を使用できません。',self.compares)
            if entry['enabled']:
                for source,key,column in [('xlsx_columns',entry['xlsx'],2),('csv_columns',entry['csv'],3)]:
                    if not key or not updated.get(source,{}).get(key):
                        control=next((edit for s,field,edit in self.entries if s==source and field==key),self.compares.cellWidget(row,column))
                        raise SettingsError(f'「{entry["name"]}」の照合元項目と列を設定してください。',control)
        updated['comparisons']=comparisons
        current={key:check.isChecked() for key,check in self.detail_checks.items()}
        if 'detail_visible_fields' in self._base or current!=self._detail_initial:
            if current==self._detail_initial and 'detail_visible_fields' in self._base:
                updated['detail_visible_fields']=copy.deepcopy(self._base['detail_visible_fields'])
            else:updated['detail_visible_fields']=[key for key,checked in current.items() if checked]+self._extra_detail_keys
        if self._labels_changed or 'field_labels' in self._base:updated['field_labels']=copy.deepcopy(self._labels)
        mail={**copy.deepcopy(self._base.get('mail_settings',{})),**{key:(control.isChecked() if isinstance(control,QCheckBox) else control.toPlainText() if isinstance(control,QTextEdit) else control.text()) for key,control in self.mail_controls.items()}}
        try:validate_mail_settings(mail)
        except ValueError as exc:raise SettingsError(str(exc),self.mail_controls['body']) from exc
        if 'mail_settings' in self._base or mail!=DEFAULT_MAIL_SETTINGS:updated['mail_settings']=mail
        return updated

    def accept(self):
        try:
            self.compares.setCurrentCell(-1,-1);self.codes.setCurrentCell(-1,-1)
            self._ensure_json_applied();updated=self._collect_config()
        except SettingsError as error:self._show_error(error);return
        self._clear_error();self.value=updated;super().accept()

    @classmethod
    def validate_json_config(cls,cfg,control=None):
        """Validate persisted or edited settings without constructing Qt widgets."""
        def fail(message):raise SettingsError(message,control)
        if not isinstance(cfg,dict):fail('JSONは設定名と値を持つオブジェクト形式で入力してください。')
        if not isinstance(cfg.get('folder',''),str):fail('JSONのフォルダは文字列で入力してください。')
        for name,lower,upper in [('year',2000,2100),('month',1,12)]:
            value=cfg.get(name,DEFAULT[name])
            if isinstance(value,bool) or not isinstance(value,int) or not lower<=value<=upper:fail(f'JSONの「{name}」の数値範囲を確認してください。')
        if cfg.get('theme','light') not in ('light','dark'):fail('JSONのテーマはlightまたはdarkで入力してください。')
        try:validate_mail_settings(cfg.get('mail_settings',{}))
        except ValueError as exc:fail(str(exc))
        for source in ('xlsx_columns','csv_columns','info_cells'):
            mapping=cfg.get(source)
            if not isinstance(mapping,dict):fail('JSONの読み込み項目を項目名と列・セルの形式で入力してください。')
            if not all(isinstance(key,str) and key and (value is None or isinstance(value,str)) for key,value in mapping.items()):fail('JSONの項目名と列・セルは文字列で入力してください。')
            if any('|' in key for key in mapping):fail('JSONの内部項目IDには区切り文字「|」を使用できません。表示する項目名は自由に設定できます。')
            required=REQUIRED[source]|({'month'} if source=='xlsx_columns' else set())
            if required-mapping.keys():fail('JSONに日付・社員識別の必須項目がありません。')
            for key,value in mapping.items():
                text=(value or '').strip().upper()
                if not text and (key in REQUIRED[source] or source=='info_cells'):fail('JSONの必須項目に列・セルを入力してください。')
                if text and not cls._valid_address(text,source=='info_cells'):fail('JSONの列・セルがExcelの有効範囲にありません。')
        for name,default,maximum in [('data_first_row',9,1048576),('data_last_row',100,1048576),('csv_first_row',2,1048576),('read_workers',4,8)]:
            value=cfg.get(name,default)
            if not isinstance(value,int) or isinstance(value,bool) or not 1<=value<=maximum:fail(f'JSONの「{name}」の数値範囲を確認してください。')
        if cfg.get('data_first_row',9)>cfg.get('data_last_row',100):fail('JSONの終了行は開始行以降にしてください。')
        if not isinstance(cfg.get('csv_encoding','auto'),str) or not cfg.get('csv_encoding','auto'):fail('JSONの文字コードを文字列で入力してください。')
        sheets=cfg.get('sheet_names')
        if not isinstance(sheets,dict) or any(not isinstance(sheets.get(str(month)),str) or not sheets[str(month)].strip() for month in range(1,13)):fail('JSONの12か月分のシート名を入力してください。')
        codes=cfg.get('codes')
        if not isinstance(codes,dict) or not all(isinstance(k,str) and k and isinstance(v,str) and v for k,v in codes.items()):fail('JSONの勤怠区分はコードと名称の文字列で入力してください。')
        comparisons=cfg.get('comparisons')
        if not isinstance(comparisons,list):fail('JSONの照合項目はリストで入力してください。')
        for entry in comparisons:
            if not isinstance(entry,dict):fail('JSONの各照合項目は設定名と値で入力してください。')
            if not all(isinstance(entry.get(key,''),str) for key in ('name','xlsx','csv','type')):fail('JSONの照合項目名・対応項目・形式は文字列で入力してください。')
            if any('|' in entry.get(side,'') for side in ('xlsx','csv')):fail('JSONの照合元の内部項目IDには区切り文字「|」を使用できません。')
            if not isinstance(entry.get('enabled',False),bool):fail('JSONの照合ON/OFFはtrueまたはfalseで入力してください。')
            if not entry.get('name','').strip():fail('JSONの照合項目名を入力してください。')
            if entry.get('enabled') and any(not cfg[source].get(entry.get(side,'')) for source,side in [('xlsx_columns','xlsx'),('csv_columns','csv')]):fail('JSONのONの照合項目には有効な列を対応付けてください。')
        labels=cfg.get('field_labels',{})
        if not isinstance(labels,dict) or not all(isinstance(k,str) and isinstance(v,dict) and all(isinstance(f,str) and isinstance(n,str) and n.strip() for f,n in v.items()) for k,v in labels.items()):fail('JSONの表示名設定は項目と名称の文字列で入力してください。')
        visible=cfg.get('detail_visible_fields')
        if visible is not None and (not isinstance(visible,list) or not all(isinstance(k,str) for k in visible)):fail('JSONの詳細表示項目は文字列のリストで入力してください。')
        sched=cfg.get('xlsx_schedule',{})
        if not isinstance(sched,dict):fail('JSONの所定時刻設定は設定名と値で入力してください。')
        for key in ('label','start','end','break_total'):
            value=sched.get(key,DEFAULT['xlsx_schedule'][key])
            if not isinstance(value,str) or not cls._valid_address(value.strip().upper()):fail('JSONの所定時刻の列を確認してください。')
        rows=sched.get('rows',{})
        if not isinstance(rows,dict):fail('JSONの所定時刻の行は勤務区分と行番号で入力してください。')
        for key,value in rows.items():
            if not isinstance(key,str) or isinstance(value,bool) or not isinstance(value,(int,str)) or not str(value).isdecimal() or not 1<=int(value)<=1048576:fail('JSONの所定時刻の行番号を確認してください。')

    def _validate_json_config(self,cfg):
        return self.validate_json_config(cfg,self.advanced)

    def apply_json_to_form(self):
        try:
            cfg=self._parse_json();self._validate_json_config(cfg)
        except SettingsError as error:self._show_error(error);return False
        self._building=True
        self._base=copy.deepcopy(cfg);self.original=copy.deepcopy(cfg);self._labels=copy.deepcopy(cfg.get('field_labels',{}));self._labels_changed=False
        for key,value in validate_mail_settings(cfg.get('mail_settings',{})).items():
            if key in self.mail_controls:
                control=self.mail_controls[key]
                control.setChecked(value) if isinstance(control,QCheckBox) else control.setPlainText(value) if isinstance(control,QTextEdit) else control.setText(value)
        for source in self._field_groups:
            grid,_=self._field_groups[source]
            while grid.count():
                item=grid.takeAt(0)
                if item.widget():item.widget().hide();item.widget().deleteLater()
            self.entries=[entry for entry in self.entries if entry[0]!=source]
            for key,value in cfg[source].items():self._append_source_entry(source,key,value)
        for key,control,default in [('data_first_row',self.first,9),('data_last_row',self.last,100),('csv_first_row',self.csv_first,2),('read_workers',self.workers,4)]:control.setValue(cfg.get(key,default))
        self._select_data(self.csv_encoding,cfg.get('csv_encoding','auto'),'既存の文字コード')
        for month,edit in self.sheet_edits.items():edit.setText(str(cfg['sheet_names'].get(month,'')))
        sched=cfg.get('xlsx_schedule',DEFAULT['xlsx_schedule'])
        for key,edit in self.schedule_cols.items():edit.setText(str(sched.get(key,DEFAULT['xlsx_schedule'][key])))
        for code,edit in self.schedule_rows.items():edit.setText(str(sched.get('rows',{}).get(code,DEFAULT['xlsx_schedule']['rows'][code])))
        self.compares.setRowCount(0)
        for entry in cfg['comparisons']:self.add_compare(entry)
        self.codes.setRowCount(0)
        for code,name in cfg['codes'].items():self.add_code(code,name)
        self._build_detail_checks(cfg);self._set_json(cfg);self._building=False;self._clear_error();return True

    def export_form_to_json(self):
        try:self._ensure_json_applied();cfg=self._collect_config()
        except SettingsError as error:self._show_error(error);return False
        self._set_json(cfg);self._clear_error();return True

    def _refresh_source_options(self):
        for row in range(self.compares.rowCount()):
            for column,source in [(2,'xlsx_columns'),(3,'csv_columns')]:
                combo=self.compares.cellWidget(row,column);key=combo.currentData();combo.blockSignals(True);combo.clear();combo.addItem('項目を選択','')
                for s,field,_ in self.entries:
                    if s==source:combo.addItem(self._field_label(source,field),field)
                self._select_data(combo,key,'既存の項目');combo.blockSignals(False)
        self._refresh_detail_fields()

    def add_source_field(self,source,name,column,key=None):
        if source not in self._field_groups or not name.strip():self._show_error(SettingsError('追加する項目名を入力してください。'));return None
        if key is None:
            used={field for _,field,_ in self.entries}
            # Extension metadata may reserve an ID before its column exists.
            # Reusing it would overwrite a label or attach a future rule to a
            # newly added, unrelated field.
            for labels in self._labels.values():
                if isinstance(labels,dict):used.update(labels)
            for entry in self._comparison_values():
                used.update(value for side in ('xlsx','csv') if isinstance(value:=entry.get(side),str))
            visible=self._base.get('detail_visible_fields')
            for identity in (visible if isinstance(visible,list) else [])+self._extra_detail_keys:
                if isinstance(identity,str):used.update(identity.split('|'))
            index=1
            while f'custom_{index:03d}' in used:index+=1
            key=f'custom_{index:03d}'
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',key) or any(s==source and field==key for s,field,_ in self.entries):
            self._show_error(SettingsError('同じ項目が既に登録されています。'));return None
        value=column.strip().upper()
        if (source=='info_cells' and not value) or (value and not self._valid_address(value,source=='info_cells')):self._show_error(SettingsError('追加項目の列・セルを確認してください。'));return None
        self._labels.setdefault(source,{})[key]=name.strip();self._labels_changed=True
        self._append_source_entry(source,key,value);self._refresh_source_options();self._clear_error();return key

    def rename_source_field(self,source,key,name):
        found=next((edit for s,field,edit in self.entries if s==source and field==key),None)
        if found is None or not name.strip():self._show_error(SettingsError('変更する項目名を入力してください。'));return False
        self._labels.setdefault(source,{})[key]=name.strip();self._labels_changed=True
        caption=found.property('captionWidget');caption.setToolTip(name.strip());caption.setText(caption.fontMetrics().elidedText(name.strip(),Qt.ElideRight,88))
        self._refresh_source_options();self._clear_error();return True

    def remove_source_field(self,source,key):
        if key in REQUIRED.get(source,set()) or (source=='xlsx_columns' and key=='month'):
            self._show_error(SettingsError('日付や社員識別に必要な項目は削除できません。'));return False
        side='xlsx' if source=='xlsx_columns' else 'csv'
        if source!='info_cells' and any(entry.get(side)==key for entry in self._comparison_values()):
            self._show_error(SettingsError('照合項目で使用中です。先に照合項目の対応を変更してください。'));return False
        retained=[(field,edit.text()) for s,field,edit in self.entries if s==source and field!=key]
        if len(retained)==sum(s==source for s,_,_ in self.entries):return False
        grid,_=self._field_groups[source]
        while grid.count():
            item=grid.takeAt(0)
            if item.widget():item.widget().hide();item.widget().deleteLater()
        self.entries=[entry for entry in self.entries if entry[0]!=source]
        for field,value in retained:self._append_source_entry(source,field,value)
        self._base.setdefault(source,{}).pop(key,None);self._labels.get(source,{}).pop(key,None);self._labels_changed=True
        self._refresh_source_options();self._clear_error();return True

    def _field_editor(self,source,mode):
        titles={'add':'読み込み項目を追加','rename':'項目名を変更','remove':'読み込み項目を削除'}
        dialog=QDialog(self);dialog.setWindowTitle(titles[mode]);dialog.resize(440,240)
        root=QVBoxLayout(dialog);root.setContentsMargins(18,16,18,16);root.setSpacing(10)
        root.addWidget(self._label(titles[mode],'sectionTitle'))
        form=QFormLayout();form.setSpacing(10);root.addLayout(form)
        selector=QComboBox();name=QLineEdit();column=QLineEdit();column.setMaximumWidth(110)
        if mode!='add':
            for s,key,edit in self.entries:
                if s==source:
                    text=self._field_label(source,key)+'（'+(edit.text().strip() or '未設定')+'）'
                    selector.addItem(text,key)
            form.addRow('対象の項目',selector)
            def show_name():
                key=selector.currentData();name.setText(self._labels.get(source,{}).get(key,TITLES.get(key,key or '')))
            selector.currentIndexChanged.connect(show_name);show_name()
        if mode!='remove':form.addRow('表示する項目名',name)
        if mode=='add':
            column.setPlaceholderText('V1' if source=='info_cells' else 'V')
            form.addRow('セル番地' if source=='info_cells' else '列記号',column)
            root.addWidget(self._label('社員別の基本情報を取得するセルを追加します。' if source=='info_cells' else '追加した日別項目は、照合項目から選択できます。','muted'))
        elif mode=='rename':root.addWidget(self._label('項目名を変えても、照合の対応は保持されます。','muted'))
        else:root.addWidget(self._label('使用中の項目は、照合の対応を変更してから削除します。','muted'))
        error=self._label('','settingsError');error.hide();root.addWidget(error)
        actions=QHBoxLayout();actions.addStretch()
        cancel=button('キャンセル','x');cancel.clicked.connect(dialog.reject);actions.addWidget(cancel)
        apply=button({'add':'追加','rename':'変更','remove':'削除'}[mode],{'add':'plus','rename':'check','remove':'trash'}[mode],'danger' if mode=='remove' else 'primary')
        actions.addWidget(apply);root.addLayout(actions)
        def commit():
            if mode=='add':ok=self.add_source_field(source,name.text(),column.text())
            elif mode=='rename':ok=self.rename_source_field(source,selector.currentData(),name.text())
            else:ok=self.remove_source_field(source,selector.currentData())
            if ok:dialog.accept()
            else:error.setText(self.error_label.text());error.show();(column if mode=='add' and name.text().strip() else name if mode!='remove' else selector).setFocus()
        apply.clicked.connect(commit);refresh_button_icons(dialog,self.parent().is_dark)
        dialog.exec()

    def _add_field_dialog(self,source):self._field_editor(source,'add')
    def _rename_field_dialog(self,source):self._field_editor(source,'rename')
    def _remove_field_dialog(self,source):self._field_editor(source,'remove')
