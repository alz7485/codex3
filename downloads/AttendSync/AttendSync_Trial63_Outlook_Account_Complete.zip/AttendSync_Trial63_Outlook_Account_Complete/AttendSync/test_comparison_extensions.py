from pathlib import Path
from copy import deepcopy
from engine import DEFAULT, xlsx_read, csv_read, reconcile
root=Path(__file__).parent/'SampleData'
cfg=deepcopy(DEFAULT)
cfg['comparisons'].append({'name':'休憩確認（追加）','xlsx':'break_total','csv':'break_total','type':'duration','enabled':True})
x={}
for p in root.glob('*.xlsx'):
    v=xlsx_read(p,cfg);x[v['info']['employee']]=v
c=[]
for p in root.glob('*.csv'):c.extend(csv_read(p,cfg)['records'])
rows,issues=reconcile(x,c,{'10001':'S001','10002':'S002','10003':'S003','10004':'S004'},cfg)
added=[r for r in rows if r['field']=='休憩確認（追加）']
assert len(added)==120,len(added)
assert all(r['xlsx_key']=='break_total' and r['csv_key']=='break_total' for r in added)
assert not issues,issues
print('PASS: 追加した照合項目120件・キー保持・照合結果')
