main.py: 読込前検証・0件阻止・キャッシュパケット検査
engine.py: validate_config追加
FINAL_AUDIT.md: 残存リスク明記
