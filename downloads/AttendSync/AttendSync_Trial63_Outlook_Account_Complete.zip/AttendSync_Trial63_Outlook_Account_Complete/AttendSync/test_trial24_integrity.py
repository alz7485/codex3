from pathlib import Path
s=(Path(__file__).parent/'main.py').read_text(encoding='utf-8')
assert 'except (OSError, RuntimeError) as exc:' in s
assert '【未完了】読み込み失敗したファイルがあります。' in s
assert 'files_completed' in s
print('Trial24 diagnostic guard checks OK')
