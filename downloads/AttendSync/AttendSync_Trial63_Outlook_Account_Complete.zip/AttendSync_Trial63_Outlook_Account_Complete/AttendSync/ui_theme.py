"""AttendSync's accessible light/dark palette and embedded vector icons.

Cards, input fields and table cells use visible blue-gray outlines. This keeps
dense Japanese business forms easy to scan in both light and dark themes.
No external image or font files are required.
"""
from PySide6.QtCore import QByteArray, QSize, Qt, QPointF
from PySide6.QtGui import QIcon, QPainter, QPixmap, QFont, QFontDatabase, QPalette, QColor, QPolygonF
from PySide6.QtWidgets import QApplication, QPushButton, QProxyStyle, QStyle, QStyleFactory
try:
    from PySide6.QtSvg import QSvgRenderer
except ImportError:
    QSvgRenderer = None

# Simple outlined icons sized to 24x24, embedded in this Python source.
ICONS = {
    'mail': '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
    'book': '<path d="M12 5v16M3 4h5a4 4 0 0 1 4 2 4 4 0 0 1 4-2h5v15h-5a4 4 0 0 0-4 2 4 4 0 0 0-4-2H3z"/>' ,
    'folder': '<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    'search': '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    'eye': '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    'alert-circle': '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 17h.01"/>',
    'play': '<path d="m8 5 12 7-12 7z"/>',
    'refresh': '<path d="M20 11a8 8 0 1 0-2 6"/><path d="M20 4v7h-7"/>',
    'stop': '<rect x="5" y="5" width="14" height="14" rx="2"/>',
    'settings': '<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="2" fill="none"/><circle cx="16" cy="17" r="2" fill="none"/>',
    'users': '<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2"/><path d="M17 5a3 3 0 0 1 0 6M18 14a5 5 0 0 1 3 5"/>',
    'print': '<path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 15h12v6H6z"/><path d="M18 12h1"/>',
    'check': '<path d="M20 6 9 17l-5-5"/>',
    'alert': '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 17h.01"/>',
    'x': '<path d="M6 6l12 12M18 6 6 18"/>',
    'info': '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    'plus': '<path d="M12 5v14M5 12h14"/>',
    'trash': '<path d="M3 6h18M9 6V4h6v2M6 6l1 15h10l1-15M10 10v7M14 10v7"/>',
    'save': '<path d="M4 4h14l2 3v13H4zM7 4v6h10V4M7 20v-7h10v7"/>',
    'file': '<path d="M6 3h8l5 5v13H6zM14 3v5h5M9 13h7M9 17h7"/>',
    'list': '<path d="M9 6h12M9 12h12M9 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
    'chevron-down': '<path d="m6 9 6 6 6-6"/>',
    'chevron-up': '<path d="m6 15 6-6 6 6"/>',
    'moon': '<path d="M20 15.5A8 8 0 0 1 8.5 4 8 8 0 1 0 20 15.5z"/>',
    'sun': '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    'table': '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M10 4v16"/>',
    'clock': '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 3"/>',
    'arrow-right': '<path d="M5 12h14m-6-6 6 6-6 6"/>',
    'sliders': '<path d="M3 7h18M3 17h18"/><circle cx="8" cy="7" r="2"/><circle cx="16" cy="17" r="2"/>',
}


def theme_colors(dark=False):
    """Semantic colours shared by stylesheets and custom table delegates."""
    if dark:
        return {
            'background': '#101827', 'panel': '#172234', 'field': '#142033',
            'text': '#eef3fc', 'muted': '#a8b6cb', 'border': '#7184a1',
            'control_border': '#8395b0', 'grid': '#485f7d',
            'group_background': '#1c2940', 'header_background': '#1c2940',
            'hover': '#23334e', 'alternate': '#1c2940',
            'accent': '#83a1ff', 'primary': '#4267db', 'primary_hover': '#486de0', 'primary_pressed': '#3556bc',
            'soft_accent': '#253960', 'selection': '#2d4670',
            'success': '#75dca9', 'error': '#ffa2aa', 'warning': '#f3c36b',
            'soft_success': '#1b3b32', 'soft_error': '#452b37', 'soft_warning': '#413725',
            'disabled': '#8393ac', 'disabled_bg': '#1d2a40', 'disabled_primary': '#354a7c',
            'scrollbar': '#52627d', 'scrollbar_hover': '#7485a0',
        }
    return {
        'background': '#f3f6fb', 'panel': '#ffffff', 'field': '#ffffff',
        'text': '#18263f', 'muted': '#5c6d85', 'border': '#8193ae',
        'control_border': '#8f9fb7', 'grid': '#b1bfd1',
        'group_background': '#f5f7fb', 'header_background': '#edf2f8',
        'hover': '#eef3fc', 'alternate': '#f8fafd',
        'accent': '#3558cc', 'primary': '#355bd7', 'primary_hover': '#294ac3', 'primary_pressed': '#2442a9',
        'soft_accent': '#edf2ff', 'selection': '#e1eaff',
        'success': '#18724c', 'error': '#b93745', 'warning': '#8d5c06',
        'soft_success': '#eaf7ef', 'soft_error': '#fff0f2', 'soft_warning': '#fff6e5',
        'disabled': '#78889e', 'disabled_bg': '#f0f3f8', 'disabled_primary': '#a7b8e8',
        'scrollbar': '#c2cddd', 'scrollbar_hover': '#95a5bd',
    }


def _icon_pixmap(name, color, size):
    fragment = ICONS.get(name, ICONS['info'])
    markup = (f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" '
              f'fill="none" stroke="{color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'
              f'{fragment}</svg>')
    renderer = QSvgRenderer(QByteArray(markup.encode('utf-8')))
    pix = QPixmap(size * 2, size * 2)
    pix.fill(Qt.transparent)
    painter = QPainter(pix)
    renderer.render(painter)
    painter.end()
    pix.setDevicePixelRatio(2)
    return pix


def icon(name, color='#334155', size=20):
    # QSvgRenderer ships with Qt for Python and is collected by PyInstaller.
    if QSvgRenderer is None:
        return QIcon()
    return QIcon(_icon_pixmap(name, color, size))


def button(label, glyph, role='secondary', parent=None, tooltip=None):
    btn = QPushButton(label, parent)
    btn.setProperty('role', role)
    btn.setProperty('glyph', glyph)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setMinimumHeight(32 if role == 'quiet' else 36)
    if tooltip:
        btn.setToolTip(tooltip)
    return btn


def refresh_button_icons(container, dark=False):
    colors = theme_colors(dark)
    for btn in container.findChildren(QPushButton):
        glyph = btn.property('glyph')
        if not glyph:
            continue
        role = btn.property('role')
        color = '#ffffff' if role == 'primary' else colors['text']
        if role == 'danger':
            color = colors['error']
        button_icon = icon(str(glyph), color, 18)
        if QSvgRenderer is not None:
            # QIcon selects these states automatically as filters are toggled.
            if role == 'segment':
                button_icon.addPixmap(_icon_pixmap(str(glyph), '#ffffff', 18), QIcon.Normal, QIcon.On)
            disabled = '#e3eaff' if role == 'primary' else colors['disabled']
            button_icon.addPixmap(_icon_pixmap(str(glyph), disabled, 18), QIcon.Disabled, QIcon.Off)
            button_icon.addPixmap(_icon_pixmap(str(glyph), disabled, 18), QIcon.Disabled, QIcon.On)
        btn.setIcon(button_icon)
        btn.setIconSize(QSize(18, 18))


def stylesheet(dark=False):
    c = theme_colors(dark)
    return f"""
    QWidget {{ color: {c['text']}; font-size: 10pt; }}
    QMainWindow, QDialog, QWidget#mainCanvas {{ background: {c['background']}; }}
    QWidget#card, QFrame#card, QFrame#sourceCard, QFrame#resultCard,
    QFrame#statusCard, QFrame#metricCard {{
        background: {c['panel']}; border: 1px solid {c['border']}; border-radius: 12px;
    }}
    QLabel#brandMark {{
        background: transparent; border: none;
        font-size: 20pt; font-weight: 700;
    }}
    QLabel#appTitle {{ font-size: 23pt; font-weight: 700; color: {c['text']}; }}
    QLabel#pageTitle {{ font-size: 20pt; font-weight: 700; color: {c['text']}; }}
    QLabel#eyebrow {{ color: {c['accent']}; font-size: 9pt; font-weight: 600; }}
    QLabel#sectionTitle {{ font-size: 11pt; font-weight: 700; }}
    QLabel#muted, QLabel#subtitle, QLabel#helpText, QLabel#fieldHint,
    QLabel#periodHint, QLabel#latestLog, QLabel#totalCheck {{ color: {c['muted']}; }}
    QLabel#totalFormula {{ color: {c['text']}; font-size: 9pt; font-weight: 600; }}
    QLabel#totalCheck {{ font-size: 9pt; }}
    QLabel#subtitle, QLabel#fieldHint, QLabel#periodHint, QLabel#latestLog {{ font-size: 9pt; }}
    QLabel#stepBadge {{
        background: {c['soft_accent']}; color: {c['accent']};
        border: 1px solid {c['border']}; border-radius: 8px; font-size: 10pt; font-weight: 700;
    }}
    QLabel#metricValue {{ font-size: 22pt; font-weight: 700; color: {c['text']}; }}
    QLabel#metricTitle {{ color: {c['muted']}; font-size: 9pt; font-weight: 600; }}
    QLabel#metricValue[metric="people"] {{ color: {c['accent']}; }}
    QLabel#metricValue[metric="ok"] {{ color: {c['success']}; }}
    QLabel#metricValue[metric="bad"] {{ color: {c['error']}; }}
    QLabel#metricValue[metric="review"] {{ color: {c['warning']}; }}
    QLabel#metricIcon {{ border-radius: 10px; background: {c['soft_accent']}; color: {c['accent']}; }}
    QLabel#metricIcon[metric="ok"] {{ background: {c['soft_success']}; color: {c['success']}; }}
    QLabel#metricIcon[metric="bad"] {{ background: {c['soft_error']}; color: {c['error']}; }}
    QLabel#metricIcon[metric="review"] {{ background: {c['soft_warning']}; color: {c['warning']}; }}
    QLabel#emptyTitle {{ font-size: 14pt; font-weight: 600; color: {c['text']}; }}
    QLabel#statusLabel {{ font-size: 10pt; font-weight: 600; color: {c['text']}; }}
    QLabel#settingsError {{ color: {c['error']}; background: {c['soft_error']}; border: 1px solid {c['error']}; border-radius: 6px; padding: 7px 10px; }}
    QLabel#banner {{
        background: {c['soft_accent']}; border: 1px solid {c['border']};
        border-radius: 8px; padding: 8px 12px; color: {c['text']};
    }}
    QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QTextEdit, QPlainTextEdit, QListWidget {{
        background: {c['field']}; color: {c['text']}; border: 1px solid {c['control_border']};
        border-radius: 6px; padding: 6px 9px; selection-background-color: {c['primary']};
        selection-color: white; min-height: 18px; font-weight: 400;
    }}
    QLineEdit#latestLog {{
        min-height: 16px; padding: 2px 8px; font-size: 9pt;
        color: {c['muted']}; background: {c['alternate']};
    }}
    QLineEdit:hover, QSpinBox:hover, QDoubleSpinBox:hover, QComboBox:hover {{ border-color: {c['accent']}; }}
    QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus,
    QTextEdit:focus, QPlainTextEdit:focus, QListWidget:focus {{ border: 1px solid {c['accent']}; }}
    QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled, QComboBox:disabled,
    QTextEdit:disabled, QPlainTextEdit:disabled {{ color: {c['disabled']}; background: {c['disabled_bg']}; }}
    QComboBox {{ padding-right: 30px; }}
    QComboBox QAbstractItemView {{
        background: {c['panel']}; color: {c['text']}; border: 1px solid {c['control_border']};
        selection-background-color: {c['selection']}; selection-color: {c['text']};
        outline: none; padding: 4px;
    }}
    QSpinBox, QDoubleSpinBox {{ padding-right: 23px; }}
    QCheckBox, QRadioButton {{ spacing: 7px; padding: 3px 1px; border: 1px solid transparent; border-radius: 3px; }}
    QCheckBox::indicator, QRadioButton::indicator {{ width: 18px; height: 18px; }}
    QCheckBox:focus, QRadioButton:focus {{ border: 1px dotted {c['accent']}; }}
    QCheckBox:disabled, QRadioButton:disabled {{ color: {c['disabled']}; }}
    QPushButton {{
        background: {c['panel']}; border: 1px solid {c['control_border']}; border-radius: 7px;
        padding: 6px 12px; font-weight: 600; color: {c['text']};
    }}
    QPushButton:hover {{ background: {c['hover']}; border-color: {c['accent']}; }}
    QPushButton:pressed {{ background: {c['selection']}; border-color: {c['accent']}; }}
    QPushButton:focus {{ border: 2px solid {c['accent']}; padding: 5px 11px; }}
    QPushButton:disabled {{ color: {c['disabled']}; background: {c['disabled_bg']}; border-color: {c['border']}; }}
    QPushButton[role="primary"] {{ background: {c['primary']}; color: white; border-color: {c['primary']}; }}
    QPushButton[role="primary"]:hover {{ background: {c['primary_hover']}; border-color: {c['primary_hover']}; }}
    QPushButton[role="primary"]:pressed {{ background: {c['primary_pressed']}; border-color: {c['primary_pressed']}; }}
    QPushButton[role="primary"]:focus {{ border: 2px solid {c['text']}; }}
    QPushButton[role="primary"]:disabled {{ background: {c['disabled_primary']}; color: #e3eaff; border-color: {c['disabled_primary']}; }}
    QPushButton[role="quiet"] {{ padding: 5px 10px; font-size: 9pt; color: {c['muted']}; }}
    QPushButton[role="quiet"]:focus {{ padding: 4px 9px; color: {c['text']}; }}
    QPushButton[role="danger"] {{ background: {c['panel']}; border-color: {c['control_border']}; color: {c['error']}; }}
    QPushButton[role="danger"]:hover {{ background: {c['soft_error']}; border-color: {c['error']}; }}
    QPushButton[role="danger"]:disabled {{ color: {c['disabled']}; background: {c['disabled_bg']}; border-color: {c['border']}; }}
    QPushButton[role="segment"] {{ border-radius: 6px; padding: 6px 12px; font-size: 9pt; }}
    QPushButton[role="segment"]:checked {{ background: {c['primary']}; color: white; border-color: {c['primary']}; }}
    QPushButton[role="segment"]:checked:hover {{ background: {c['primary_hover']}; }}
    QPushButton[role="segment"]:focus {{ padding: 5px 11px; }}
    QTabWidget::pane {{ border: 1px solid {c['border']}; border-radius: 8px; background: {c['panel']}; }}
    QTabBar::tab {{
        padding: 10px 15px; background: {c['background']}; color: {c['muted']};
        border: 1px solid {c['border']}; border-bottom: none; margin-right: 3px;
        border-top-left-radius: 7px; border-top-right-radius: 7px;
    }}
    QTabBar::tab:hover {{ color: {c['text']}; background: {c['hover']}; }}
    QTabBar::tab:selected {{ color: {c['accent']}; font-weight: 600; background: {c['panel']}; border-top: 2px solid {c['accent']}; }}
    QHeaderView::section {{
        background: {c['header_background']}; color: {c['muted']}; padding: 10px 10px; font-weight: 600;
        border: none; border-right: 1px solid {c['grid']}; border-bottom: 1px solid {c['grid']};
    }}
    QTableView, QTableWidget {{
        background: {c['panel']}; alternate-background-color: {c['alternate']}; color: {c['text']};
        border: 1px solid {c['border']}; border-radius: 7px; gridline-color: {c['grid']};
        selection-background-color: {c['selection']}; selection-color: {c['text']};
    }}
    QTableView::item, QTableWidget::item {{ padding: 5px 9px; border: none; }}
    QTableView::item:selected, QTableWidget::item:selected {{ background: {c['selection']}; color: {c['text']}; }}
    QTableView::item:focus, QTableWidget::item:focus {{ border: 1px solid {c['accent']}; }}
    QTableCornerButton::section {{ background: {c['header_background']}; border: 1px solid {c['grid']}; }}
    QGroupBox {{
        border: 1px solid {c['border']}; border-radius: 9px; margin-top: 13px;
        padding: 14px 12px 12px; font-weight: 600; background: {c['group_background']};
    }}
    QGroupBox::title {{ subcontrol-origin: margin; subcontrol-position: top left; left: 12px; padding: 0 6px; color: {c['text']}; }}
    QFrame#footerSeparator {{ background: {c['border']}; border: none; }}
    QProgressBar {{
        background: {c['disabled_bg']}; border: 1px solid {c['border']}; border-radius: 5px;
        min-height: 9px; text-align: center; color: {c['text']};
    }}
    QProgressBar::chunk {{ background: {c['primary']}; border-radius: 4px; }}
    QMenu {{ background: {c['panel']}; color: {c['text']}; border: 1px solid {c['control_border']}; border-radius: 6px; padding: 5px; }}
    QMenu::item {{ padding: 8px 22px; border-radius: 4px; }}
    QMenu::item:selected {{ background: {c['selection']}; color: {c['text']}; }}
    QMenu::item:disabled {{ color: {c['disabled']}; }}
    QMenu::separator {{ height: 1px; background: {c['border']}; margin: 5px 7px; }}
    QToolTip {{ color: {c['text']}; background: {c['panel']}; border: 1px solid {c['control_border']}; border-radius: 4px; padding: 6px 9px; }}
    QScrollArea {{ background: transparent; border: none; }}
    QScrollArea > QWidget > QWidget {{ background: {c['panel']}; }}
    QScrollBar:vertical {{ background: {c['background']}; width: 11px; margin: 1px; border: none; }}
    QScrollBar:horizontal {{ background: {c['background']}; height: 11px; margin: 1px; border: none; }}
    QScrollBar::handle:vertical {{ background: {c['scrollbar']}; min-height: 28px; border-radius: 4px; }}
    QScrollBar::handle:horizontal {{ background: {c['scrollbar']}; min-width: 28px; border-radius: 4px; }}
    QScrollBar::handle:hover {{ background: {c['scrollbar_hover']}; }}
    QScrollBar::add-line, QScrollBar::sub-line {{ width: 0px; height: 0px; border: none; }}
    QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}
    QSplitter::handle {{ background: {c['border']}; }}
    """


def _application_font():
    # These families cover Japanese on Windows, macOS, and the Linux preview.
    available = set(QFontDatabase.families())
    candidates = ['Yu Gothic UI', 'Meiryo', 'Noto Sans CJK JP', 'Noto Sans JP', 'Hiragino Sans', 'Segoe UI']
    families = [family for family in candidates if family in available]
    font = QFont()
    if families:
        font.setFamilies(families)
    font.setPointSize(10)
    return font


class _ArrowStyle(QProxyStyle):
    """Draw small native arrows with the palette instead of platform images."""
    def drawPrimitive(self, element, option, painter, widget=None):
        up = element in (QStyle.PE_IndicatorArrowUp, QStyle.PE_IndicatorSpinUp)
        down = element in (QStyle.PE_IndicatorArrowDown, QStyle.PE_IndicatorSpinDown)
        if not (up or down):
            return super().drawPrimitive(element, option, painter, widget)
        center = option.rect.center()
        x, y = center.x(), center.y()
        points = [QPointF(x - 3.5, y + 2), QPointF(x + 3.5, y + 2), QPointF(x, y - 2)] if up else [
            QPointF(x - 3.5, y - 2), QPointF(x + 3.5, y - 2), QPointF(x, y + 2)]
        group = QPalette.Active if option.state & QStyle.State_Enabled else QPalette.Disabled
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(option.palette.color(group, QPalette.ButtonText))
        painter.drawPolygon(QPolygonF(points))
        painter.restore()


def apply_theme(app, dark=False):
    c = theme_colors(dark)
    # Fusion renders native checkbox ticks and popup arrows consistently in both
    # themes; keeping these native also preserves high-DPI/keyboard behaviour.
    app.setStyle(_ArrowStyle(QStyleFactory.create('Fusion')))
    palette = QPalette()
    for role, color in {
        QPalette.Window: c['background'], QPalette.WindowText: c['text'],
        QPalette.Base: c['field'], QPalette.AlternateBase: c['alternate'],
        QPalette.Text: c['text'], QPalette.Button: c['panel'], QPalette.ButtonText: c['text'],
        QPalette.ToolTipBase: c['panel'], QPalette.ToolTipText: c['text'],
        QPalette.Highlight: c['primary'], QPalette.HighlightedText: '#ffffff',
        QPalette.Link: c['accent'], QPalette.Light: c['panel'], QPalette.Mid: c['control_border'],
        QPalette.Dark: c['border'], QPalette.PlaceholderText: c['muted'],
    }.items():
        palette.setColor(role, QColor(color))
    for role in (QPalette.WindowText, QPalette.Text, QPalette.ButtonText, QPalette.PlaceholderText):
        palette.setColor(QPalette.Disabled, role, QColor(c['disabled']))
    for role in (QPalette.Base, QPalette.Button):
        palette.setColor(QPalette.Disabled, role, QColor(c['disabled_bg']))
    app.setPalette(palette)
    app.setFont(_application_font())
    app.setStyleSheet(stylesheet(dark))
