# Trial39 操作マニュアル・起動測定

変更Python:
- main.py: 操作マニュアルボタンとメイン画面のF1。manual.pyはクリック時に読み込む。
- ui_theme.py: マニュアル用の本アイコンを追加。
- build_onedir.py: Manual/index.htmlの存在確認、Manual全体をEXE隣へコピー。
- test_trial33_ui.py: 最小サイズの確認対象にマニュアルボタンを追加。

追加Python:
- manual.py: ローカルの画像付きHTMLを既定ブラウザで開く。資料不足・起動失敗は警告し、アプリの状態を維持。
- test_trial39_manual.py: ボタン/F1、Unicode/空白パス、全画像・目次、配布コピー、資料不足、起動時の読み込み抑止、将来列のJSON保存・再読込の10テスト。
- benchmark_startup.py: 一時userdataで新規プロセスの最初の描画イベントを測定。実userdataに触れず、OSキャッシュはクリアしない。

削除Pythonなし。Manual/index.html・画像・追加JSONの例、起動結果と最終検証を同梱。ManualのJSON例は追加部分だけで、設定全体の置き換え用ではない。列追加・改名・照合追加と未知属性の保持、速度/範囲が先頭・月度が末尾の配置を維持。
