"""同梱サンプルを使った一括照合回帰テスト。python test_sample_integration.py"""
from pathlib import Path
from collections import Counter
from engine import DEFAULT, xlsx_read, csv_read, candidates, reconcile
base=Path(__file__).resolve().parent/'SampleData'
assert base.is_dir(), 'SampleData フォルダがありません'
xfiles=list(base.glob('*.xlsx')); cfiles=list(base.glob('*.csv'))
assert len(xfiles)==4 and len(cfiles)==2, (len(xfiles),len(cfiles))
xdata={}; cdata=[]
for f in xfiles:
    result=xlsx_read(f,DEFAULT)
    assert not result.get('error'),(f.name,result)
    assert len(result['records'])==30,(f.name,len(result['records']))
    eid=result['info']['employee']
    assert eid not in xdata
    xdata[eid]=result
for f in cfiles:
    packet=csv_read(f,DEFAULT)
    assert not packet['warnings'],packet['warnings']
    cdata.extend(packet['records'])
assert len(cdata)==120,len(cdata)
mapping={}
missing=candidates(xdata,cdata,mapping)
assert set(mapping)=={'10001','10002'},mapping
assert {v[0] for v in missing}=={'10003','10004'},missing
mapping.update({'10003':'S003','10004':'S004'})
rows,issues=reconcile(xdata,cdata,mapping,DEFAULT)
counts=Counter(r['status'] for r in rows)
assert counts==Counter({'一致':357,'不一致':3}),counts
assert not issues,issues
actual={(r['employee'],r['date'],r['field']) for r in rows if r['status']=='不一致'}
expected={('10001','2026-10-02','終業時刻'),('10001','2026-10-02','実働時間'),('10002','2026-10-05','実働時間')}
assert actual==expected,(actual,expected)
wrong=dict(DEFAULT,year=2027)
assert '対象年月の不一致' in xlsx_read(xfiles[0],wrong)['error']
print(f'PASS: XLSX {len(xfiles)}件 / CSV {len(cfiles)}件 / CSV {len(cdata)}行')
print(f'PASS: 一致 {counts["一致"]}項目 / 不一致 {counts["不一致"]}項目 / 要確認 0件')
print('PASS: 同姓同名2人の候補選択・対象年月チェック・期待不一致3項目')
