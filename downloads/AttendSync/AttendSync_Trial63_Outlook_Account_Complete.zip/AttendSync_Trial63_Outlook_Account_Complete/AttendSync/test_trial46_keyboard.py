"""Real Qt keyboard, mouse activation and modal lifetime regressions.

Run with python -m unittest -v test_trial46_keyboard. All user data is isolated.
"""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import tempfile
import unittest
from unittest.mock import MagicMock,patch
from PySide6.QtCore import QCoreApplication,QEvent,Qt,QTimer
from PySide6.QtGui import QContextMenuEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QDialog
import runtime_paths
_import_dir=tempfile.TemporaryDirectory(prefix='attendsync-keyboard-import-')
with patch.object(runtime_paths,'get_data_dir',return_value=Path(_import_dir.name)):
 import main
import manual

class Keyboard46(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='attendsync-keyboard-test-');self.addCleanup(self.tmp.cleanup)
  base=Path(self.tmp.name)
  p=patch.multiple(main,DATA_DIR=base,CONFIG=base/'settings.json',MAP=base/'mapping.json',DB=base/'cache.db')
  p.start();self.addCleanup(p.stop)
  self.w=main.Window();self.w.resize(1040,690);self.w.show()
  self.addCleanup(self.cleanup_window)
  self.w.results=[dict(status='不一致',date='2026-10-01',employee='10001',name='山田 太郎',field='始業時刻',xlsx='09:00',csv='09:05',staff='S10001',xlsx_key='start',csv_key='start',xrecord=None,crecord=None)]
  self.w.show_results();self.w.activateWindow();self.w.table.setFocus();self.settle()
  self.index=self.w.model.index(0,0);self.w.table.setCurrentIndex(self.index)
 def settle(self):
  self.app.processEvents();self.app.processEvents()
  QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
 def cleanup_window(self):self.w.close();self.w.deleteLater();self.settle()
 def test_return_opens_detail_once(self):
  with patch.object(main.DetailDialog,'exec',return_value=0) as detail:
   QTest.keyClick(self.w.table,Qt.Key_Return);self.settle()
   self.assertEqual(detail.call_count,1)
 def test_double_click_opens_detail_once(self):
  with patch.object(main.DetailDialog,'exec',return_value=0) as detail:
   center=self.w.table.visualRect(self.index).center()
   QTest.mouseClick(self.w.table.viewport(),Qt.LeftButton,pos=center)
   QTest.mouseDClick(self.w.table.viewport(),Qt.LeftButton,pos=center)
   self.settle();self.assertEqual(detail.call_count,1)
 def test_native_keyboard_context_dispatch_and_menu_cleanup(self):
  # Synthetic Key_Menu does not generate a native context event offscreen.
  # Verify native event dispatch separately from the menu's application handler.
  signals=[]
  self.w.table.customContextMenuRequested.disconnect(self.w.context_menu)
  self.w.table.customContextMenuRequested.connect(lambda point:signals.append(point))
  center=self.w.table.visualRect(self.index).center()
  event=QContextMenuEvent(QContextMenuEvent.Keyboard,center,self.w.table.viewport().mapToGlobal(center))
  self.app.sendEvent(self.w.table.viewport(),event);self.settle()
  self.assertEqual(len(signals),1)
  menu=MagicMock();menu.exec.return_value=None
  with patch.object(main,'QMenu',return_value=menu):self.w.context_menu(signals[0])
  self.assertEqual(menu.addAction.call_count,2)
  menu.exec.assert_called_once();menu.deleteLater.assert_called_once()
 def test_f1_from_search_opens_manual_once(self):
  with patch.object(manual,'open_manual',return_value=True) as guide:
   self.w.search.setFocus();QTest.keyClick(self.w.search,Qt.Key_F1);self.settle()
   guide.assert_called_once_with(self.w)
 def test_real_detail_closes_is_deleted_and_main_remains_usable(self):
  closed=[];destroyed=[];errors=[]
  def close_actual():
   dialog=self.app.activeModalWidget()
   # Record failures outside Qt callbacks, where exceptions would be swallowed.
   if not isinstance(dialog,main.DetailDialog):
    errors.append(repr(type(dialog)))
    if isinstance(dialog,QDialog):dialog.reject()
    return
   dialog.destroyed.connect(lambda:destroyed.append(True))
   closed.append(dialog.isVisible());dialog.reject()
  for count in (1,2):
   self.w.activateWindow();self.w.table.setFocus();self.w.table.setCurrentIndex(self.index);self.settle()
   QTimer.singleShot(0,close_actual)
   QTest.keyClick(self.w.table,Qt.Key_Return);self.settle()
   self.assertEqual(errors,[]);self.assertEqual(len(closed),count)
   self.assertTrue(all(closed));self.assertEqual(len(destroyed),count)
   self.assertEqual(self.w.findChildren(main.DetailDialog),[])
   self.assertTrue(self.w.run_button.isEnabled())
  self.w.filter_buttons['一致のみ'].click();self.settle();self.assertEqual(self.w.model.rowCount(),0)
  self.w.filter_buttons['すべて'].click();self.settle();self.assertEqual(self.w.model.rowCount(),1)

if __name__=='__main__':unittest.main(verbosity=2)
