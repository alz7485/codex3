"""Real offscreen Qt widgets/PDF rendering; native dialog decisions mocked."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import copy
import tempfile
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication, QDialog, QMessageBox, QScrollArea, QLineEdit
from PySide6.QtCore import QTimer
from PySide6.QtPrintSupport import QPrinter
import main
import printing
from engine import DEFAULT

app=QApplication.instance() or QApplication([])
with tempfile.TemporaryDirectory() as temp:
    main.CONFIG=Path(temp)/'settings.json'
    main.MAP=Path(temp)/'mapping.json'
    main.DB=Path(temp)/'cache.db'
    window=main.Window()
    window.cfg=copy.deepcopy(DEFAULT)
    def row(eid, status):
        return dict(status=status,date='2026-09-16',employee=eid,name='社員'+eid,field='始業時刻',xlsx='<8:30>',csv='9:00',staff='S'+eid)
    window.results=[row('A','不一致'),row('B','一致'),row('C','要確認')]
    window.search.setText('A');window.show_results()
    captured=[]
    with patch.object(main,'print_html',side_effect=lambda *a,**kw:captured.append((a[1],kw))):
        window.print_list(preview=True)
        assert '社員A' in captured[-1][0] and '社員B' not in captured[-1][0]
        assert '&lt;8:30&gt;' in captured[-1][0] and '<thead>' in captured[-1][0]
        assert captured[-1][1]['preview']
        detail=main.DetailDialog(window,window.results[0],window.cfg)
        for i in range(detail.detail_table.rowCount()): detail.detail_table.setRowHidden(i,i!=4)
        detail.do_print()
        assert '<td style="">始業時刻</td>' in captured[-1][0]
        assert '<td style="">終業時刻</td>' not in captured[-1][0]
        count=len(captured)
        for i in range(detail.detail_table.rowCount()): detail.detail_table.setRowHidden(i,True)
        with patch.object(QMessageBox,'information') as message:
            detail.do_print();assert message.call_count==1 and len(captured)==count
        detail.close()
    with patch.object(QMessageBox,'information') as message:
        window.search.setText('absent');window.print_list();assert message.called
    # Exercise dark/light themes, one-line log, compact settings at narrow width.
    for dark in (False,True):
        window.is_dark=not dark;window.toggle_theme()
        window.set_log_history(['first','latest\nline'])
        assert window.log_line.text()=='latest  line'
        settings=main.SettingsDialog(window,copy.deepcopy(DEFAULT))
        settings.resize(640,600);settings.show();app.processEvents()
        assert settings.tabs.count()==4 if hasattr(settings,'tabs') else settings.findChildren(main.QTabWidget)[0].count()==4
        assert all(edit.maximumWidth()==88 for _,_,edit in settings.entries)
        assert settings.findChildren(QScrollArea)
        settings.close()
    # Excel failure is shown without replacing results/selection.
    window.search.clear();window.show_results();original=list(window.visible)
    with patch.object(main,'open_source_cell',side_effect=RuntimeError('updated source')),patch.object(QMessageBox,'warning') as message:
        window.open_excel_source({'file':'missing.xlsx'},'start')
        assert message.called and window.visible==original
    # File removal/update must stop before COM is touched.
    import excel_jump
    source=Path(temp)/'source.xlsx';source.write_bytes(b'original')
    st=source.stat()
    record=dict(file=str(source),sheet='10月',row=34,file_size=st.st_size,file_mtime_ns=st.st_mtime_ns)
    with patch.object(excel_jump.sys,'platform','win32'):
        source.write_bytes(b'changed source')
        try:excel_jump.open_source_cell(record,'H')
        except RuntimeError as exc:assert '更新' in str(exc)
        else:raise AssertionError('updated file accepted')
        source.unlink()
        try:excel_jump.open_source_cell(record,'H')
        except FileNotFoundError:pass
        else:raise AssertionError('missing file accepted')
    # Real text layout and multi-page PDF including long unbroken strings.
    markup='<h2>AttendSync</h2><table border="1" width="100%"><thead><tr><th>ID</th><th>Value</th></tr></thead>'
    markup+=''.join('<tr><td>'+str(i)+'</td><td>'+printing.print_cell('x'*180)+'</td></tr>' for i in range(300))+'</table>'
    printer=printing.make_printer();printer.setOutputFormat(QPrinter.PdfFormat)
    output=Path(temp)/'pages.pdf';printer.setOutputFileName(str(output))
    document=printing.make_document(markup)
    printing.render_document(document,printer)
    assert output.read_bytes().startswith(b'%PDF') and output.stat().st_size>5000
    from PySide6.QtPdf import QPdfDocument
    pdf=QPdfDocument();pdf.load(str(output));assert pdf.pageCount()>1
    pages=pdf.pageCount();pdf.close()
    # Actual preview dialog paint cycle, automatically closed by event loop.
    QTimer.singleShot(100, lambda: [w.reject() for w in app.topLevelWidgets() if isinstance(w,printing.QPrintPreviewDialog)])
    printing.print_html(window,markup,preview=True)
    with patch.object(printing.QPrinterInfo,'availablePrinters',return_value=[]),patch.object(QMessageBox,'information') as message:
        printing.print_html(window,markup);assert message.called
    with patch.object(printing.QPrinterInfo,'availablePrinters',return_value=[object()]),patch.object(printing.QPrintDialog,'exec',return_value=QDialog.Rejected),patch.object(printing,'render_document') as render:
        printing.print_html(window,markup);render.assert_not_called()
    with patch.object(printing.QPrinterInfo,'availablePrinters',return_value=[object()]),patch.object(printing.QPrintDialog,'exec',return_value=QDialog.Accepted),patch.object(printing,'render_document',side_effect=RuntimeError('printer failure')),patch.object(QMessageBox,'warning') as message:
        printing.print_html(window,markup);assert message.called
    window.close()
print(f'PASS: real Qt filters/detail/empty/theme/settings/log/Excel failure; PDF {pages} pages; preview, cancel, no printer, print error')
