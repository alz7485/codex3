"""Regression checks for calendar totals, missing slots and completed-read snapshots."""
import copy
import unittest
from unittest.mock import patch
from engine import DEFAULT,comparison_totals,reconcile
import test_trial38_audit as fixture
from PySide6.QtCore import QSize


class Totals42(unittest.TestCase):
    setUpClass=classmethod(fixture.Audit38.setUpClass.__func__)
    setUp=fixture.Audit38.setUp
    load_results=fixture.Audit38.load_results

    def summary(self,xdata=None,cdata=None,cfg=None):
        cfg=cfg or self.w.cfg
        xdata=self.xdata if xdata is None else xdata
        cdata=self.cdata if cdata is None else cdata
        rows,_=reconcile(xdata,cdata,self.w.mapping,cfg)
        return comparison_totals(xdata,rows,cfg),rows

    def test_period_includes_both_endpoints_and_leap_year(self):
        for year,month,days in [(2026,10,30),(2026,11,31),(2026,1,31),(2024,3,29),(2026,3,28)]:
            self.w.year.setValue(year);self.w.month.setValue(month)
            self.assertIn(f'（{days}日）',self.w.period_hint.text())
            cfg=copy.deepcopy(DEFAULT);cfg.update(year=year,month=month)
            self.assertEqual(comparison_totals({},[],cfg)['days'],days)

    def test_full_sample_total_and_identity(self):
        total,_=self.summary()
        self.assertEqual((total['items'],total['employees'],total['days'],total['expected']),(3,4,30,360))
        self.assertEqual(total['expected'],sum(total[k] for k in ('matched','mismatched','review','missing')))
        self.assertEqual(total['missing'],0)

    def test_missing_csv_day_counts_each_uncompared_item(self):
        cdata=[r for r in self.cdata if not (r['staff']=='S001' and r['date']=='2026-09-16')]
        total,_=self.summary(cdata=cdata)
        self.assertEqual(total['missing'],3)
        self.assertEqual(total['additional_review'],1)
        self.assertEqual(total['evaluated'],357)

    def test_missing_xlsx_day_keeps_full_calendar_denominator(self):
        xdata=copy.deepcopy(self.xdata)
        xdata['10001']['records']=[r for r in xdata['10001']['records'] if r['date']!='2026-09-16']
        total,_=self.summary(xdata=xdata)
        self.assertEqual(total['expected'],360);self.assertEqual(total['missing'],3)

    def test_duplicate_csv_and_unmapped_employee_leave_slots_uncompared(self):
        cdata=copy.deepcopy(self.cdata);cdata.append(copy.deepcopy(next(r for r in cdata if r['staff']=='S001' and r['date']=='2026-09-16')))
        total,_=self.summary(cdata=cdata);self.assertEqual(total['missing'],3)
        self.w.mapping.pop('10001');total,_=self.summary()
        self.assertEqual(total['missing'],90)

    def test_duplicate_labels_and_pairs_are_distinct_comparisons(self):
        cfg=copy.deepcopy(DEFAULT);cfg['comparisons'].append(copy.deepcopy(cfg['comparisons'][0]))
        total,_=self.summary(cfg=cfg)
        self.assertEqual(total['items'],4);self.assertEqual(total['expected'],480);self.assertEqual(total['missing'],0)

    def test_extra_enabled_item_changes_total_off_item_does_not(self):
        cfg=copy.deepcopy(DEFAULT);cfg['comparisons'][3]['enabled']=True
        total,_=self.summary(cfg=cfg);self.assertEqual(total['expected'],480)
        cfg['comparisons'][0]['enabled']=False
        total,_=self.summary(cfg=cfg);self.assertEqual(total['expected'],360)

    def test_duplicate_result_cannot_inflate_matches_and_period_outside_is_detected(self):
        total,rows=self.summary();match=next(r for r in rows if r['status']=='一致')
        duplicate=copy.deepcopy(match);outside=dict(match,date='2026-10-16')
        result=comparison_totals(self.xdata,rows+[duplicate,outside],self.w.cfg)
        self.assertEqual(result['matched'],total['matched']-1)
        self.assertEqual(result['duplicates'],1);self.assertEqual(result['outside'],1)
        self.assertEqual(result['expected'],sum(result[k] for k in ('matched','mismatched','review','missing')))

    def make_matching(self):
        xdata=copy.deepcopy(self.xdata)
        for eid,packet in xdata.items():
            sid=self.w.mapping[eid]
            for row in packet['records']:
                c=next(c for c in self.cdata if c['staff']==sid and c['date']==row['date'])
                row['values'].update({i['xlsx']:c['values'].get(i['csv']) for i in self.w.cfg['comparisons'] if i.get('enabled')})
        return xdata

    def stats(self,**kw):
        return dict(elapsed=.1,cache_hits=0,parsed=6,files_found=6,files_completed=6,**kw)

    def test_all_match_and_missing_data_ui(self):
        xdata=self.make_matching();self.w.read_done(xdata,self.cdata,[],self.stats())
        self.assertIn('3項目 × 対象社員 4人 × 月度 30日 ＝ 360件',self.w.total_formula.text())
        self.assertIn('一致 360 / 全数 360件',self.w.total_check.text());self.assertTrue(self.w.total_check.text().endswith('全数一致'))
        cdata=[r for r in self.cdata if not (r['staff']=='S001' and r['date']=='2026-09-16')]
        self.w.read_done(xdata,cdata,[],self.stats())
        self.assertIn('未照合 3件',self.w.total_check.text());self.assertTrue(self.w.total_check.text().endswith('全数一致に未達'))

    def test_invalid_comparison_slot_is_review_not_match(self):
        xdata=self.make_matching();xdata['10001']['records'][0]['values']['start']='bad-time'
        self.w.read_done(xdata,self.cdata,[],self.stats())
        self.assertEqual(self.w.comparison_summary['review'],1)
        self.assertIn('判定要確認 1',self.w.total_check.text())

    def test_loading_failure_prevents_all_match_claim(self):
        self.w.read_done(self.make_matching(),self.cdata,[],self.stats(file_errors=[dict(file='unknown.xlsx',reason='bad file')]))
        self.assertEqual(self.w.comparison_summary['matched'],360)
        self.assertIn('追加の要確認 1件',self.w.total_check.text())
        self.assertIn('読み込み未完了',self.w.total_check.text())
        self.assertTrue(self.w.total_check.text().endswith('全数一致に未達'))

    def test_results_formula_uses_snapshot_and_ignores_filters(self):
        emit=self.load_results(worker=True)
        self.w.cfg['comparisons'][0]['enabled']=False;self.w.year.setValue(2027);self.w.month.setValue(1)
        emit();formula=self.w.total_formula.text();check=self.w.total_check.text()
        self.assertIn('3項目',formula);self.assertIn('2026年10月度',formula)
        for filter_state in ('一致のみ','すべて','不一致のみ'):
            self.w.select_filter(filter_state);self.w.search.setText('10001')
            self.assertEqual(self.w.total_formula.text(),formula);self.assertEqual(self.w.total_check.text(),check)

    def test_cancel_or_fatal_error_preserves_previous_total(self):
        self.load_results();before=self.w.total_formula.text(),self.w.total_check.text()
        for stats in (self.stats(cancelled=True),self.stats(fatal_error='cache failure')):
            self.w.read_done({},[],[],stats)
            self.assertEqual((self.w.total_formula.text(),self.w.total_check.text()),before)

    def test_all_off_and_zero_employees_never_claim_all_matched(self):
        for entry in self.w.cfg['comparisons']:entry['enabled']=False
        self.load_results();self.assertIn('照合項目がすべてOFF',self.w.total_check.text());self.assertEqual(self.w.comparison_summary['expected'],0)
        self.w.cfg=copy.deepcopy(DEFAULT);self.w.read_done({},self.cdata,[],self.stats())
        self.assertIn('対象社員なし',self.w.total_check.text());self.assertEqual(self.w.comparison_summary['expected'],0)

    def test_formula_and_result_rows_fit_minimum_window_with_data(self):
        self.load_results();self.w.resize(1040,690);self.w.show()
        for dark in (False,True):
            if self.w.is_dark!=dark:self.w.toggle_theme()
            self.app.processEvents();self.app.processEvents()
            self.assertEqual(self.w.size(),QSize(1040,690))
            self.assertLessEqual(self.w.minimumSizeHint().width(),1040)
            self.assertGreaterEqual(self.w.table.viewport().height(),100)
            for widget in (self.w.total_formula,self.w.total_check):
                self.assertGreaterEqual(widget.height(),widget.heightForWidth(widget.width()))

    def test_minimum_window_with_loading_failure_and_large_totals(self):
        self.load_results();cfg=copy.deepcopy(DEFAULT)
        cfg['comparisons']*=10
        xdata={str(i):{} for i in range(120)}
        self.w.loaded_xdata=xdata;self.w.results=[dict(status='要確認') for i in range(20)]
        self.w.update_comparison_summary(cfg,{'complete':False},True)
        self.w.resize(1040,690);self.w.show();self.app.processEvents();self.app.processEvents()
        self.assertEqual(self.w.size(),QSize(1040,690))
        self.assertGreaterEqual(self.w.table.viewport().height(),100)
        self.assertGreaterEqual(self.w.total_check.height(),self.w.total_check.heightForWidth(self.w.total_check.width()))


if __name__=='__main__':unittest.main(verbosity=2)
