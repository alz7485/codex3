# Trial61 誤判定・集計監査

対象 `/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync`。本体は未変更。合成社員・既存サンプルのみ使用し、外部通信・実メール操作なし。

## 確認済み J62-01（中）

**CSVの無い月の通常セル入力異常が初期フィルターで隠れる。**

- 該当: `result_filters.py:47`、`engine.py:317`、`engine.py:447`。
- 再現: サンプル社員10001の9月16日G列を通常文字列 `NOT_A_TIME` にし保存。`xlsx_read()` で実ファイルを再読込。勤怠CSVは10月の有効行だけを渡し、Qtメイン画面の `read_done()` を実行。
- 期待: 始業時刻として解析できないXLSX入力は要確認として一覧に残す。CSVなしの通知だけを非表示にする。
- 実際: `xlsx_read()` の `invalid_fields=[]`, `warnings=[]`。reconcileはCSVなし分岐を先に通り、対象日は `CSV記録なし` の1行だけとなる。既定ONで当該行が非表示になる。OFFに戻すと行は復帰するが入力異常とは示されない。
- 原因: XLSXの `invalid_fields` は主に数式の未計算を示す。通常文字列、不正時刻、真偽値などの時間値検証はCSVが対になる場合の `compare_time()` まで行われないため、フィルターの `invalid_fields` 保護が効かない。
- 修正案: 非表示判定前に有効比較項目のclock/duration値を `time_minutes` で検証し、不正なら当該日を非表示から除外する。できればCSV有無にかかわらずXLSX入力異常の要確認行を生成する。空白・休日の正規空欄は異常にしない。
- 再現コマンド: `/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/judgment/probe.py`
- 証跡: `probe.log`。実XLSX→パーサー→Qt一覧まで確認。

## 他役と重複した確認事項

前月CSVが空/ヘッダーだけで今月CSVが有効な場合、空CSVに有効行ゼロの警告がなく、前月を存在しない月として非表示にする。欠損データ役と同一原因なので本監査では重複計上しない。親エージェントが修正予定。

## 合成境界17ケース（成功）

`boundaries.py` / `boundaries.log`。2026年10月、2027年1月の年越し、2028年3月の閏年2月を対象とし、両月CSV、前月のみ、当月のみを検証。

追加境界: 一社員だけ前月全欠落、未知スタッフの前月行、CSV日付不正、CSV識別欄空白、CSV読込失敗、全CSV空、XLSX数式未計算、当月だが対象期間外の日付。

各ケース共通で次を確認:

- `全数 = 一致 + 不一致 + 判定要確認 + 未照合` が成立。
- 「すべて」の表示行数が生結果行数-月非表示件数と一致。
- Qtモデル行数と表示行数が一致。
- 印刷HTMLの本文行数と表示行数が一致。
- OFFで生結果全行に戻り、ON/OFFで生結果・全数集計を改変しない。
- CSV片月だけの場合、全数一致と誤表示しない。
- 同月に別社員の行がある場合、一社員の月全欠落は非表示にしない。
- CSV日付不正/識別情報欠落/失敗はフィルター抑止、数式未計算のXLSX日は非表示にならない。

再実行: `ATTENDSYNC_AUDIT_SOURCE=/path/to/AttendSync /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/judgment/boundaries.py`

## 仕様確認を要する観察（不具合として未計上）

当月のCSV日付が対象月度の15日より後だけ（例:10月20日1行）でも、月被覆は当月ありと判断され、前月の欠落は隠れる。実際に30行非表示/未照合180件。全数一致の誤表示はない。現在のUIは「CSVの日付の年月から判定」と説明しているため現仕様とも読めるが、「対象月度に有効CSV行がゼロなら非表示しない」条件にするとより保守的になる。

## 暦・重複項目の追加マトリクス（成功）

`calendar_matrix.py` / `calendar_matrix.log`。2000/2026/2027/2028/2100年の全12月（60月度）で、前月のみ/当月のみをそれぞれ与え、対象期間の日付すべてと両端の1日前後について非表示判定を確認。さらに各月で同名・同一列の有効比較項目を追加し、比較インデックスによる全数集計が別枠を保持することを確認。3,954回のアサーション成功。

## Trial62 修正後の独立再監査

対象 `/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync`。本体変更なし。

- **J62-01 修正確認済み**。同じ実XLSXの `NOT_A_TIME` が、CSV欠月のチェックONでも一覧に残る。前月非表示件数は60→59となり、異常のある1日を除外する。証跡 `probe_fixed.log`（`EXPECT_FIXED=1` で可視性をアサート）。通知の表題自体は `CSV記録なし` のままだが、不正値のある行が消える問題は解消。
- 独立合成17境界を修正版に対して再実行し成功。全数恒等式、表示/モデル/印刷の行数、ON/OFF時の生結果・集計無改変、未知ID、年越し/閏年等を再確認。`boundaries_fixed.log`。
- 暦60月度、3,954アサーションを修正版に対して再実行し成功。`calendar_matrix_fixed.log`。
- 追加の値境界17ケース: 通常不正文字列、不正な分、負の数、48時間相当、真偽値、NaN、Infinity、負のtimedeltaの9値は非表示不可。空白、0時、24時/47:59、26時間timedeltaの8値は従来どおり非表示可。`fixed_value_guards.py` / `.log`。

以上の範囲で修正の退行・新たな誤一致・集計/印刷のずれは未検出。
