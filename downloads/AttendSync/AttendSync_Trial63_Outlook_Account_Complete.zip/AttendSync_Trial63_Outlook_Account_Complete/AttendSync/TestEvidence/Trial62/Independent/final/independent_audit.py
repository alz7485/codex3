import os,sys,tempfile,csv,copy,json,unittest,hashlib,base64
from pathlib import Path
from unittest.mock import patch
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
SRC=Path('/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync')
sys.path.insert(0,str(SRC))
from engine import DEFAULT,csv_read,reconcile,Cache,save_json
from result_filters import is_missing_month_csv_gap,csv_month_coverage,missing_csv_months
from cache_tags import parser_tag
def csv_cache_tag(cfg):return parser_tag(cfg,"csv")
from employee_information import plan_employee_import,load_information,recover_employee_save
def empty_contacts():return {"version":1,"contacts":[],"unlinked_contacts":[],"import_settings":{}}
from microsoft_mail import process_graph_plans,graph_payload
from outlook_mail import DEFAULT_MAIL_SETTINGS

class IndependentAudit(unittest.TestCase):
 def cfg(self):return copy.deepcopy(DEFAULT)
 def packet(self,root,length,cfg=None):
  cfg=cfg or self.cfg(); p=Path(root)/f'length-{length}.csv'
  row=['']*length; row[0]='20261001';row[3]='S001';row[4]='監査社員'
  with p.open('w',encoding='utf-8',newline='') as f:csv.writer(f).writerows([['見出し'],row])
  return p,csv_read(p,cfg)
 def x(self):return {'E001':{'info':{'name':'監査社員'},'records':[{'employee':'E001','name':'監査社員','date':'2026-10-01','values':dict(start=None,end=None,work=None,break_total=None),'invalid_fields':[]}]}}
 def test_each_row_length_and_enabled_comparison(self):
  with tempfile.TemporaryDirectory() as root:
   for length in range(5,16):
    for break_on in (False,True):
     with self.subTest(length=length,break_on=break_on):
      cfg=self.cfg();cfg['comparisons'][3]['enabled']=break_on;p,packet=self.packet(root,length,cfg)
      rows,_=reconcile(self.x(),packet['records'],{'E001':'S001'},cfg)
      comp=[r for r in rows if 'comparison_index' in r]
      for row in comp:
       index={'start':11,'end':12,'work':13,'break_total':14}[row['csv_key']]
       self.assertEqual(row['status'],'要確認' if index>length else '一致')
      self.assertEqual(sum('CSV列不足' in r['field'] for r in rows),sum(i>length for i in ([11,12,13,14] if break_on else [11,12,13])))
 def test_missing_fields_survive_cache_and_newly_enabled_comparison(self):
  cfg=self.cfg()
  with tempfile.TemporaryDirectory() as root:
   p,packet=self.packet(root,13,cfg);cache=Cache(Path(root)/'cache.db')
   try:
    a,hit=cache.parse(p,csv_cache_tag(cfg),lambda p:csv_read(p,cfg));self.assertFalse(hit)
    cfg['comparisons'][3]['enabled']=True
    b,hit=cache.parse(p,csv_cache_tag(cfg),lambda p:self.fail('cache unexpectedly missed'));self.assertTrue(hit)
    self.assertEqual(a,b);self.assertIn('break_total',b['records'][0]['missing_fields'])
    rows,_=reconcile(self.x(),b['records'],{'E001':'S001'},cfg)
    self.assertEqual(next(r['status'] for r in rows if r.get('csv_key')=='break_total'),'要確認')
   finally:cache.close()
 def test_custom_extra_column_missing_as_text(self):
  cfg=self.cfg();cfg['csv_columns']['custom']='Z';cfg['xlsx_columns']['custom']='U';cfg['comparisons'].append(dict(name='追加入力',xlsx='custom',csv='custom',type='text',enabled=True))
  with tempfile.TemporaryDirectory() as root:
   _,packet=self.packet(root,14,cfg);rows,_=reconcile(self.x(),packet['records'],{'E001':'S001'},cfg)
   self.assertEqual(next(r['status'] for r in rows if r.get('csv_key')=='custom'),'要確認')
 def test_bad_source_values_not_hidden_but_blank_and_midnight_can_hide(self):
  cfg=self.cfg();row=dict(status='要確認',field='CSV記録なし',crecord=None,date='2026-09-16',xrecord={'values':{},'invalid_fields':[]})
  for value in ('garbage','48:00',True,False,-.1,float('nan'),float('inf'),'-1:00','9:99',{},[]):
   with self.subTest(value=value):
    row['xrecord']['values']={'start':value};self.assertFalse(is_missing_month_csv_gap(row,{'2026-09'},cfg))
  for value in (None,'','  ',0,'0:00','00:00','23:59','25:00','47:59:59'):
   with self.subTest(value=value):
    row['xrecord']['values']={'start':value};self.assertTrue(is_missing_month_csv_gap(row,{'2026-09'},cfg))
 def test_case_insensitive_warning_and_failure_conservative(self):
  records=[{'date':'2026-10-01'}]
  for warning in ('CSVに有効な勤怠行がありません','IDまたは日付が空欄','日付不正'):
   self.assertIsNone(csv_month_coverage(records,warnings=[{'file':'PREV.CsV','reason':warning}]))
  self.assertIsNone(csv_month_coverage(records,failures=[{'file':'PREV.CsV'}]))
  self.assertEqual(missing_csv_months(csv_month_coverage(records),self.cfg()),frozenset({'2026-09'}))
 def test_ambiguous_names_do_not_overwrite_known_name(self):
  data=empty_contacts();data['employee_names']={'E001':'登録済氏名'}
  rows=[dict(employee='E001',staff='S001',name=name,email='one@example.com') for name in ('別名A','別名B')]
  for inputs in (rows,list(reversed(rows))):
   mapping,updated,results=plan_employee_import(inputs,'linking',{'E001':'S001'},data)
   self.assertEqual(updated['employee_names']['E001'],'登録済氏名')
  rows[0]['name']=rows[1]['name']='新氏名'
  _,updated,_=plan_employee_import(rows,'linking',{'E001':'S001'},data)
  self.assertEqual(updated['employee_names']['E001'],'新氏名')
 def test_recovery_all_encoding_errors_preserve_other_file(self):
  for key in ('mapping','contacts'):
   for value in (False,0,[],{},'å','====','not!valid'):
    with self.subTest(key=key,value=value),tempfile.TemporaryDirectory() as root:
     root=Path(root);mp=root/'employee_mapping.json';cp=root/'employee_contacts.json';mp.write_bytes(b'current-mapping');cp.write_bytes(b'current-contacts')
     snapshots={x:base64.b64encode(b'previous').decode() for x in ('mapping','contacts')};snapshots[key]=value
     save_json(root/'employee_save_transaction.json',snapshots)
     with self.assertRaises(ValueError):recover_employee_save(mp,cp)
     self.assertEqual(mp.read_bytes(),b'current-mapping');self.assertEqual(cp.read_bytes(),b'current-contacts');self.assertTrue((root/'employee_save_transaction.json').exists())
 def test_corrupt_cache_field_lists_are_rejected(self):
  import runtime_paths
  with tempfile.TemporaryDirectory() as root,patch.object(runtime_paths,'get_data_dir',return_value=Path(root)):
   import main
   for field in ('invalid_fields','missing_fields'):
    for value in ([[]],[{}],[False],[None],[1],['start',{}]):
     with self.subTest(field=field,value=value):
      c=dict(staff='S001',name='監査社員',date='2026-10-01',values={},invalid_fields=[],missing_fields=[]);c[field]=value
      self.assertFalse(main.ReadWorker._valid_cached_packet({'records':[c],'warnings':[]},False))
   c=dict(staff='S001',name='監査社員',date='2026-10-01',values={},invalid_fields=[],missing_fields=['start'])
   self.assertTrue(main.ReadWorker._valid_cached_packet({'records':[c],'warnings':[]},False))
 def test_actual_worker_reparses_corrupt_cache_metadata(self):
  import runtime_paths
  from PySide6.QtCore import QCoreApplication
  app=QCoreApplication.instance() or QCoreApplication([])
  with tempfile.TemporaryDirectory() as root,patch.object(runtime_paths,'get_data_dir',return_value=Path(root)):
   import main
   folder=Path(root)/'attendance';folder.mkdir();p,packet=self.packet(folder,14);db=Path(root)/'cache.sqlite3'
   for field in ('invalid_fields','missing_fields'):
    for value in ([[]],[{}],[False],[None],[1],['start',{}]):
     with self.subTest(field=field,value=value):
      cache=Cache(db);cache.parse(p,csv_cache_tag(self.cfg()),lambda p:csv_read(p,self.cfg()))
      corrupt=copy.deepcopy(packet);corrupt['records'][0][field]=value
      cache.db.execute('UPDATE cache SET data=?',(json.dumps(corrupt),));cache.db.commit();cache.close()
      with patch.object(main,'DB',db):
       capture=[];worker=main.ReadWorker(folder,self.cfg());worker.result.connect(lambda *args:capture.append(args));worker.run()
      self.assertEqual(len(capture),1);x,c,issues,stats=capture[0]
      self.assertFalse(stats.get('fatal_error'));self.assertFalse(stats['file_errors']);self.assertEqual(stats['cache_hits'],0);self.assertEqual(stats['parsed'],1)
      self.assertEqual(c[0]['invalid_fields'],[]);self.assertEqual(c[0]['missing_fields'],[])
      rows,_=reconcile(self.x(),c,{'E001':'S001'},self.cfg());self.assertTrue(all(r['status']=='一致' for r in rows))
 def test_every_falsey_history_value_blocks_remote(self):
  settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com'}
  plan=dict(employee='E001',staff='S001',name='監査社員',to=['one@example.com'],cc=[],subject='合成監査',body='合成本文',problem='')
  for auto_send in (False,True):
   settings['auto_send']=auto_send
   key=hashlib.sha256(json.dumps([settings['account'].casefold(),settings['client_id'],settings['tenant_id'],settings['auto_send'],plan['employee'],plan['staff'],graph_payload(plan)],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
   for value in (None,False,0,'',[],{}):
    with self.subTest(auto_send=auto_send,value=value),tempfile.TemporaryDirectory() as root:
     save_json(Path(root)/'mail_processing_history.json',{key:value});calls=[]
     outcomes=process_graph_plans([plan],settings,root,lambda *a:calls.append(a))
     self.assertFalse(calls);self.assertIn('再実行を停止',outcomes[0]['status'])
if __name__=='__main__':unittest.main(verbosity=2)
