import os,sys,copy,json
from pathlib import Path
from datetime import timedelta
src=Path('/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync');sys.path.insert(0,str(src))
from result_filters import is_missing_month_csv_gap
from engine import DEFAULT
cfg=copy.deepcopy(DEFAULT)
for c in cfg['comparisons']:c['enabled']=c['xlsx']=='start'
base=dict(status='要確認',field='CSV記録なし',date='2026-09-16',crecord=None)
invalid=['NOT_A_TIME','25:77',-0.5,2,True,False,float('nan'),float('inf'),timedelta(hours=-1)]
valid=[None,'','  ',0,'0:00','24:00','47:59',timedelta(hours=26)]
for v in invalid:
 row={**base,'xrecord':dict(values=dict(start=v),invalid_fields=[])}
 assert not is_missing_month_csv_gap(row,{'2026-09'},cfg),repr(v)
for v in valid:
 row={**base,'xrecord':dict(values=dict(start=v),invalid_fields=[])}
 assert is_missing_month_csv_gap(row,{'2026-09'},cfg),repr(v)
print(json.dumps(dict(source=str(src),invalid_values_preserved=len(invalid),valid_or_blank_values_hide_as_expected=len(valid),passed=True),indent=2))
