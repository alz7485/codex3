# 集約担当の追加監査: メール処理履歴の破損

対象: Trial61（修正前）とTrial62（修正後）。合成社員・TemporaryDirectory・Graph通信の代替関数のみ使用。外部通信・認証・実メール送信なし。

## R1 / P2: 処理済み履歴の値が空だと再処理される

`microsoft_mail._process_graph_plans` は `ledger.get(key)` の真偽で既存履歴を判定していた。送信済みfingerprintのキーは残っていても、破損・外部編集で値が `{}` / `null` / `""` / `false` / `[]` になると新規扱いとなる。

`probe_falsey_history.py` で、最初の合成送信後に各値へ変更し再実行。修正前は5条件すべてで作成と送信の代替関数が再度呼ばれた（2回）。修正後はキーの存在で判断し、全5条件で呼び出し0回、処理状況要確認として停止。通常操作がこの破損を生成したことは確認していない。

証拠: mail_before.log / mail_after.log。専用回帰は `test_trial62_audit_regressions.py` に追加。
