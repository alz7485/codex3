"""Isolated fault-injection audit. Does not modify distribution source."""
import sys, os, tempfile, unittest, json, base64, copy
from pathlib import Path
from unittest.mock import patch
SOURCE=Path(os.environ.get('AUDIT_SOURCE','/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync'))
sys.path.insert(0,str(SOURCE))
os.environ['QT_QPA_PLATFORM']='offscreen'
import engine
import employee_information as info
from microsoft_mail import mail_lock
import runtime_paths
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):import main
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtGui import QCloseEvent
APP=QApplication.instance() or QApplication([])
APP.setQuitOnLastWindowClosed(False)

def b64(raw):return base64.b64encode(raw).decode('ascii')

class DestructiveAudit(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.mp=self.root/'staff_mapping.json';self.cp=self.root/'employee_contacts.json';self.jp=self.root/'employee_save_transaction.json'
  self.mp.write_bytes(b'{"E1":"S1"}\n');self.cp.write_bytes(b'{"version":1,"contacts":[],"marker":"original"}\n')
  self.original=(self.mp.read_bytes(),self.cp.read_bytes())
 def before(self):return self.mp.read_bytes(),self.cp.read_bytes()
 def test_write_failure_at_first_file_preserves_both(self):
  def writer(path,value):raise PermissionError('first-file fault')
  with self.assertRaises(PermissionError):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},{'version':1,'contacts':[]},writer)
  self.assertEqual(self.before(),self.original);self.assertFalse(self.jp.exists())
 def test_partial_second_writer_restores_exact_original_bytes(self):
  def writer(path,value):
   path.write_text('{broken',encoding='utf-8')
   if path==self.mp:raise OSError('disk fault after truncation')
  with self.assertRaises(OSError):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},{'version':1,'contacts':[]},writer)
  self.assertEqual(self.before(),self.original);self.assertFalse(self.jp.exists())
 def test_crash_and_retry_with_both_original_files_absent(self):
  self.mp.unlink();self.cp.unlink();engine.save_json(self.jp,{'mapping':None,'contacts':None})
  self.mp.write_text('{partial');self.cp.write_text('{partial')
  info.recover_employee_save(self.mp,self.cp)
  self.assertFalse(self.mp.exists());self.assertFalse(self.cp.exists());self.assertFalse(self.jp.exists())
 def test_valid_crash_journal_restores_both(self):
  engine.save_json(self.jp,{'mapping':b64(self.original[0]),'contacts':b64(self.original[1])})
  self.mp.write_bytes(b'partial');self.cp.write_bytes(b'partial')
  info.recover_employee_save(self.mp,self.cp)
  self.assertEqual(self.before(),self.original);self.assertFalse(self.jp.exists())
 def test_malformed_json_journal_leaves_files_untouched(self):
  self.jp.write_text('{broken')
  with self.assertRaises(ValueError):info.recover_employee_save(self.mp,self.cp)
  self.assertEqual(self.before(),self.original);self.assertTrue(self.jp.exists())
 def test_unknown_journal_keys_leave_files_untouched(self):
  engine.save_json(self.jp,{'mapping':None,'contacts':None,'extra':True})
  with self.assertRaises(ValueError):info.recover_employee_save(self.mp,self.cp)
  self.assertEqual(self.before(),self.original);self.assertTrue(self.jp.exists())
 def test_corrupt_mapping_snapshot_must_not_restore_contacts_first(self):
  engine.save_json(self.jp,{'mapping':'!!corrupt!!','contacts':b64(b'{"version":1,"contacts":[],"marker":"stale"}')})
  with self.assertRaises(ValueError):info.recover_employee_save(self.mp,self.cp)
  self.assertEqual(self.before(),self.original,'CONFIRMED: invalid mapping snapshot changed contacts before rejection')
 def test_invalid_mapping_snapshot_type_must_not_delete_contacts_first(self):
  engine.save_json(self.jp,{'mapping':23,'contacts':None})
  with self.assertRaises((ValueError,TypeError)):info.recover_employee_save(self.mp,self.cp)
  self.assertTrue(self.cp.exists(),'CONFIRMED: invalid snapshot type deleted contacts before rejection')
  self.assertEqual(self.before(),self.original)
 def test_lock_contention_leaves_both_files_untouched(self):
  with mail_lock(self.root):
   with self.assertRaises(RuntimeError):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},{'version':1,'contacts':[]})
  self.assertEqual(self.before(),self.original);self.assertFalse(self.jp.exists())
 def test_failed_rollback_keeps_journal_and_retry_recovers(self):
  def writer(path,value):
   path.write_bytes(b'partial')
   if path==self.mp:raise PermissionError('write fault')
  original_restore=info._restore
  def fail_restore(path,encoded):raise PermissionError('temporary rollback permission failure')
  with patch.object(info,'_restore',side_effect=fail_restore):
   with self.assertRaises(PermissionError):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},{'version':1,'contacts':[]},writer)
  self.assertTrue(self.jp.exists())
  info.recover_employee_save(self.mp,self.cp)
  self.assertEqual(self.before(),self.original);self.assertFalse(self.jp.exists())
 def test_json_serialization_failure_does_not_truncate_existing_file(self):
  with self.assertRaises(TypeError):engine.save_json(self.mp,{'cannot_encode':object()})
  self.assertEqual(self.before(),self.original);self.assertFalse(list(self.root.glob('*.tmp')))
 def test_every_invalid_snapshot_is_rejected_before_any_restore(self):
  for key in ('mapping','contacts'):
   for invalid in (True,False,23,{},[],['AAAA'],'日本語','!not-base64!','A'):
    with self.subTest(key=key,invalid=invalid):
     self.mp.write_bytes(self.original[0]);self.cp.write_bytes(self.original[1])
     snapshots={'mapping':None,'contacts':None};snapshots[key]=invalid;engine.save_json(self.jp,snapshots)
     with self.assertRaises(ValueError):info.recover_employee_save(self.mp,self.cp)
     self.assertEqual(self.before(),self.original);self.assertTrue(self.jp.exists())
 def test_invalid_second_json_key_still_prevents_any_restore(self):
  snapshots={'contacts':None,'mapping':'not base64'};engine.save_json(self.jp,snapshots)
  with self.assertRaises(ValueError):info.recover_employee_save(self.mp,self.cp)
  self.assertEqual(self.before(),self.original);self.assertTrue(self.jp.exists())
 def test_second_restore_permission_failure_preserves_retry_journal(self):
  engine.save_json(self.jp,{'mapping':b64(self.original[0]),'contacts':b64(self.original[1])})
  self.mp.write_bytes(b'partial map');self.cp.write_bytes(b'partial contacts');original_restore=info._restore
  def restore(path,raw):
   if path==self.mp:raise PermissionError('second restore unavailable')
   return original_restore(path,raw)
  with patch.object(info,'_restore',side_effect=restore):
   with self.assertRaises(PermissionError):info.recover_employee_save(self.mp,self.cp)
  self.assertTrue(self.jp.exists());self.assertEqual(self.cp.read_bytes(),self.original[1]);self.assertEqual(self.mp.read_bytes(),b'partial map')
  info.recover_employee_save(self.mp,self.cp);self.assertEqual(self.before(),self.original);self.assertFalse(self.jp.exists())

class FakeWorker:
 def __init__(self):self.running=True;self.interrupted=False;self.cancel_count=0
 def isRunning(self):return self.running
 def isInterruptionRequested(self):return self.interrupted
 def cancel(self):self.interrupted=True;self.cancel_count+=1

class InterruptedUIAudit(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);root=Path(self.tmp.name)
  self.paths=patch.multiple(main,CONFIG=root/'settings.json',MAP=root/'staff_mapping.json',DB=root/'attendance_cache.sqlite3');self.paths.start();self.addCleanup(self.paths.stop)
  self.window=main.Window();self.worker=FakeWorker();self.window.worker=self.worker
 def tearDown(self):self.worker.running=False;self.window.worker=None;self.window.close();APP.processEvents()
 def test_close_yes_defers_until_worker_stops_and_does_not_reprompt(self):
  first=QCloseEvent();again=QCloseEvent()
  with patch.object(main.QMessageBox,'question',return_value=QMessageBox.Yes) as question:
   self.window.closeEvent(first);self.window.closeEvent(again)
  self.assertFalse(first.isAccepted());self.assertFalse(again.isAccepted());self.assertTrue(self.window._close_after_worker);self.assertEqual(self.worker.cancel_count,1);question.assert_called_once()
 def test_close_no_preserves_active_worker(self):
  event=QCloseEvent()
  with patch.object(main.QMessageBox,'question',return_value=QMessageBox.No):self.window.closeEvent(event)
  self.assertFalse(event.isAccepted());self.assertFalse(self.window._close_after_worker);self.assertEqual(self.worker.cancel_count,0)
 def test_cancelled_result_preserves_last_month_filter_coverage(self):
  old=[dict(date='2026-09-20',employee='E1',staff='S1',name='合成氏名',field='CSV記録なし',status='要確認',xlsx='09:00',csv='—',xrecord=None,crecord=None)]
  self.window.results=copy.deepcopy(old);self.window.results_cfg={**copy.deepcopy(engine.DEFAULT),'year':2026,'month':10};self.window.result_csv_months=frozenset({'2026-10'})
  self.worker.interrupted=True
  with patch.object(self.window,'sender',return_value=self.worker):self.window.read_done({},[],['合成中止'],{'cancelled':False})
  self.assertEqual(self.window.results,old);self.assertEqual(self.window.result_csv_months,frozenset({'2026-10'}));self.assertEqual(self.window.results_cfg['month'],10);self.assertEqual(self.window.visible,[]);self.assertEqual(self.window.hidden_csv_month_rows_count,1)
 def test_stale_worker_signal_does_not_overwrite_results(self):
  self.window.results=[{'marker':'must remain'}];self.window.result_csv_months=frozenset({'2026-10'})
  with patch.object(self.window,'sender',return_value=object()):self.window.read_done({},[],[],{})
  self.assertEqual(self.window.results,[{'marker':'must remain'}]);self.assertEqual(self.window.result_csv_months,frozenset({'2026-10'}))

if __name__=='__main__':unittest.main(verbosity=2)
