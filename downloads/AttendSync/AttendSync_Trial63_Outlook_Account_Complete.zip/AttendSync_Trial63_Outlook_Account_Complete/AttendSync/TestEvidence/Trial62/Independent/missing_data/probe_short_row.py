import sys,tempfile,json,copy,csv
from pathlib import Path
sys.path.insert(0,'/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync')
from engine import csv_read,reconcile,DEFAULT
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'truncated.csv'
 with p.open('w',newline='',encoding='utf-8') as f:csv.writer(f).writerows([['date','','','staff'],['20261001','','','S001','合成人員']])
 packet=csv_read(p,DEFAULT)
 x={'employee':'E001','name':'合成人員','date':'2026-10-01','values':{'start':None,'end':None,'work':None},'invalid_fields':[]}
 rows,issues=reconcile({'E001':{'info':{'name':'合成人員'},'records':[x]}},packet['records'],{'E001':'S001'},DEFAULT)
 result={'packet':packet,'comparison_rows':rows,'issues':issues}
 print(json.dumps(result,ensure_ascii=False,indent=2))
 assert len(rows)==3 and all(r['status']=='一致' for r in rows)
 assert packet['warnings']==[]
