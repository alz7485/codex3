# Trial 61 設定・保存・移行監査

対象: `/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync`。
本体は変更していない。CSV/JSONはtempdirの合成データ、GUIはoffscreen、Microsoftへの接続・実メール処理なし。

## S-1 / P2 / 確認済み: 社員情報CSVの再取込で氏名の変更が反映されない

- ソース: `employee_information.py:123` の `names.setdefault(eid,row['name'])`、`main.py:1125` 付近の `employee_names` 優先表示、`main.py:1140` 付近の表示名からの保存。
- 最小条件: 既存の employee_names が `0001: 旧姓 太郎`、対応は `0001/S01`。新CSVは同一両ID・同一メールのまま氏名のみ `新姓 太郎` に変更。
- 期待: CSVを一覧へ反映し社員情報を登録すると、社員情報画面・保存JSON双方に新氏名が反映される。
- 実際: import plan の contacts/name と staff_candidates/name は新氏名になるが、employee_names は旧姓のまま。実Qt統合画面も旧姓を表示し、そのまま「社員情報を登録」すると contacts/name まで旧姓へ戻る。氏名セルは読取専用なのでUIから補正できない。
- 再現: `/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/settings/audit_settings.py`。
- ログ: `audit_settings.log` の `reimport_name_plan` / `reimport_name_real_editor`。後者は実画面の読込→一覧反映→登録まで実行し `saved_name`、`saved_contact_name` とも旧姓であることを確認。
- 修正案: IDの紐付けが安全に成立した行で、CSVに一意かつ空でない氏名がある場合は employee_names を更新する。競合両ID・同一IDで複数氏名のCSVは既存名へ任意上書きせず、明示確認または保留する。再取込・登録後の再読込まで回帰テストを追加。

## S-2 / P3 / 確認済み（不正な保存JSONが前提）: 読込設定のネスト検証不足

- ソース: `employee_information.py:20-21` は employee_import_settings 自身のdictのみ検証。`employee_information.py:183-186` が linking/columns/first_row の型を未検証で使用。
- 条件: 保存済JSONを手編集・破損等により `employee_import_settings={"linking":null}`、`{"linking":[]}`、`{"linking":{"columns":null}}`、`{"linking":{"first_row":"two"}}` とする。
- 期待: 社員情報のload時点で対象設定を示す日本語ValueError、または読込設定だけ既定値へ戻して安全に再設定できる。
- 実際: load_information は受理。読込ダイアログ構築中に AttributeError/TypeError が発生し、CSV選択前に画面が開かなくなる。first_row=true も受理されQtの値1へ変換される。
- 再現: S-1と同じコマンド。`bad_import_settings_*` のログ参照。
- 修正案: 既知のlinking設定について、dict構造、columns=dict[str,str]、first_row=1..1048576のint（bool除外）、encodingの既知値を検証する。未知の拡張キーは保持する。
- 制限: 正常操作でアプリがこの不正データを書き出すことは確認していない。自然に発生する本番不具合S-1とは区別する。

## 正常系と互換性の確認

- 保存された独自列 E/F/G/K・開始行5は読込ダイアログにそのまま復元される。既定列 A/B/C/J はソースと現行テストで確認。
- 社員JSONの未知拡張、全体設定JSONの未知拡張、照合項目内の未知ルールは実UI保存後も保持。
- 登録判定: 未登録・旧勤怠ID対応だけ・attendance用途だけ・対応表が空の明示登録は通さない。旧linking用途がある社員情報と有効な対応表は移行後も使用できる。
- 既存GUI回帰の重点実行対象: test_trial34_settings、test_trial38_audit、test_trial41_settings、test_trial59_registration、test_trial54_mail、test_trial61_month_filter。
- ログ: `existing_regressions.log`。上記6モジュールの83テストが55.987秒で全成功。主に設定書込失敗、JSON適用/不正構造、未知データ保持、完了済結果の列/年月/比較スナップショット、登録ゲート、メール自動送信モード、欠損月フィルタを実行。

## 未検証・仮説

- Windows実機でのExcel起動、MSAL実認証、Graph実送信は本監査では実施しない。
- 不正JSONの発生原因や移行経路は確認しておらず、S-2の前提は外部編集・破損である。

## Trial 62 修正確認

対象を `/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync` に替え、独自再現だけを再実行した。本体は変更していない。

- S-1修正済み。正常な両IDペア・一意な非空氏名のCSVを反映し、実Qt統合画面から登録後、employee_names と contacts/name が両方とも `新姓 太郎` になった。
- 同じ両IDペアへ異なる2氏名を含むCSVは、行順を逆転させた場合も既存の `旧姓 太郎` を保持した。既存名を複数候補のいずれかへ勝手に更新しない。
- S-2修正済み。linking:null、linking:[]、columns:null、first_row:"two"、first_row:true はすべてload_informationの段階で日本語ValueErrorになり、Qt構築時の例外へ持ち越されない。
- 独自列E/F/G/K・開始行5の復元、未知の社員JSON拡張・全体設定拡張・照合項目内拡張の保持も継続確認。
- 再現: `/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/settings/audit_settings_trial62.py`。
- ログ: `audit_settings_trial62.log`、構造化結果: `results_trial62.json`。正しい新氏名・競合時の旧名保持・不正設定の読込時拒否をassertし、終了コード0で成功。
- 既存83テストはroot側で全体再実行するため、本担当では重複実行していない。
