import sys,json,tempfile
from pathlib import Path
from unittest.mock import patch
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
source=Path(os.environ['AUDIT_SOURCE']);sys.path.insert(0,str(source))
import runtime_paths
sandbox=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(sandbox.name)):
 from test_trial54_mail import Mail
from microsoft_mail import process_graph_plans
from engine import save_json
fixture=Mail();settings=fixture.settings(True);plans=fixture.plans()[:1]
results=[]
for bad in ({},None,'',False,[]):
 with tempfile.TemporaryDirectory() as t:
  calls=[]
  def transport(method,path,payload):
   calls.append(path);return {'_http_status':202} if path.endswith('/send') else {'id':'mock'}
  process_graph_plans(plans,settings,t,transport)
  path=Path(t)/'mail_processing_history.json';ledger=json.loads(path.read_text());ledger[next(iter(ledger))]=bad;save_json(path,ledger)
  calls.clear();outcome=process_graph_plans(plans,settings,t,transport)
  results.append({'history_value':bad,'remote_calls':len(calls),'outcome':outcome})
print(json.dumps(results,ensure_ascii=False,indent=2))
if os.environ.get('EXPECT_FIXED')=='1':assert all(r['remote_calls']==0 for r in results)
else:assert all(r['remote_calls']==2 for r in results)
