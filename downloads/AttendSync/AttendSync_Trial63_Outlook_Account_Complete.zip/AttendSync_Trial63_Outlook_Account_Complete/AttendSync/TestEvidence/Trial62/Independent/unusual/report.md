# 変な使用・一般ユーザー誤操作監査（Trial61）

対象: `AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync`（ソース未変更）。Python 3.12 + PySide6、offscreen の実 Qt ダイアログ。全ファイルを TemporaryDirectory に隔離。認証、外部通信、メール送信なし。

## 確認済み不具合

### U1: CSV再取込の氏名変更が反映されず、メール宛名も旧名へ戻る（P2）

- ソース: `employee_information.py:123`、`main.py:1125`、`main.py:1138`。
- 再現: 既存 `0001/S01/旧姓 社員/one@example.com` を登録後、同じIDペア・同じメール・新氏名 `新姓 社員` のCSVを計画。CSVから更新されたcontactには新氏名があるが、`employee_names` は setdefault で旧名を維持。統合画面では旧名を表示し、登録するとその旧名でcontactまで再作成される。
- 期待: 正常に一致するIDペアの再取込では新氏名へ更新。
- 実際: 新氏名がUIへ出ず、登録でメール宛名データの新氏名も失われる。
- コマンド: `QT_QPA_PLATFORM=offscreen timeout 45 /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/unusual/reproduce.py Misuse.test_csv_reimport_name_change_does_not_update_display_and_reverts_contact`
- 修正案: IDの競合がなく linked が成立する行の非空氏名のみ `names[eid]` を更新する。競合行で既存氏名を更新しない。

### U2: 社員ID訂正後に旧IDが未紐付け社員として復活（P2）

- ソース: `main.py:1139` と `main.py:1125`。
- 再現: 統合画面で0001を0002に訂正して登録し、再度開く。
- 期待: 現在の行0002だけを表示。
- 実際: mappingは0002/S01だけなのに、残った社員名辞書から旧0001/旧姓 社員/スタッフID空欄の幽霊行を表示。氏名は読み取り専用で通常のID解除でも名前辞書が残る。
- コマンド: 上と同じPythonで `reproduce.py Misuse.test_renaming_employee_id_resurrects_old_unlinked_employee`。
- 修正案: collect 時に employee_names を現在表の非空IDから再構成し、消えた旧IDを残さない。

### U3: 検索中の社員追加が即非表示（P3）

- ソース: `main.py:1151`、`main.py:1088` 付近 filter_rows。
- 再現: 社員情報で0001を検索中に「社員番号を追加」。
- 期待: 追加直後の行を表示し入力できる。
- 実際: 行を作成し一度表示した直後にfilter_rowsが空欄行を隠す。検索解除まで入力できず、ボタン連打で見えない空欄行を複数作れる。
- コマンド: 上と同じPythonで `reproduce.py Misuse.test_add_row_during_search_stays_accessible`。
- 修正案: 行追加時に検索を解除する、または追加行を一時表示する。

## 不具合なしを確認した操作

- CSVドロップの直後に別CSVを15回連打: 処理待ちの追加ドロップを拒否し、最初のCSVだけ読込。処理完了後の別CSVドロップは正常に切替。
- ドロップ直後、キュー処理前にキャンセルして再び開く: 閉じた画面の保留ドロップが新画面に流れ込まない。
- 読込後の列を A→Z→空欄→C→B と連続変更: 古いプレビュー/反映ボタンを即無効化、最終値Bで再読込し復旧。
- 上の各キャンセルでmapping/contactのファイルが完全一致、保存なし。
- 氏名更新の修正を安全に行うためのID競合4ケース: 既存社員に別SID、既存SIDに別社員、CSV内の同社員複数SID、CSV内の同SID複数社員。いずれも既存mapping・氏名・contactを維持、全行 id_matched=False。`conflict_names.log` に成功記録。

## 証跡・制限

`reproduce.log`: 最初の6試験中3件失敗（上記3バグ）、3件成功、約2.5秒。`conflict_names.log`: 追加1試験内の4競合ケース成功。
`reproduce.py` は `ATTENDSYNC_SOURCE_ROOT` 環境変数で修正版にも適用可能。
Windows実機、Excel実体、新しいOutlook実体はこの監査の対象外。表示配置の好みや、仕様不明のCSV全件置換等をバグとして数えていない。

## Trial62 修正後の再監査

対象を `AttendSync_Trial62_Final_Audit_Complete/AttendSync` に切り替え、同じ再現コードの全7試験を再実行。**7/7成功、約2.9秒**。

- U1: 新氏名が employee_names、統合画面、登録後contactの3箇所で維持。
- U2: ID訂正後の再表示は0002の1行だけ。旧0001は再出現しない。
- U3: 検索中の追加行を表示できる（isRowHidden=False）。
- ID競合4ケースの氏名・メール・mapping保持、およびドロップ連打/閉じた画面の保留ドロップ/高速列変更/取消のファイル不変も再度成功。
- この7試験の範囲で追加の回帰なし。監査対象ソースの編集なし。

再現コマンド:

```sh
ATTENDSYNC_SOURCE_ROOT=/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync QT_QPA_PLATFORM=offscreen timeout 45 /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/unusual/reproduce.py
```

証跡: `recheck_trial62.log`。

### 最終ソースでの再実行

社員追加時の表示モードを維持し、検索だけ解除する最終変更後にも全7試験を再実行し、**7/7成功（2.860秒）**。`recheck_trial62.log` はこの最終実行で更新。U1/U2/U3の修正と既存保護を維持している。
