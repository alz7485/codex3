"""Synthetic data only; no app source changes or network activity."""
import copy,csv,io,json,sys,tempfile
from pathlib import Path
SOURCE=Path('/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync')
sys.path.insert(0,str(SOURCE))
from engine import DEFAULT,csv_read,xlsx_read,reconcile
from employee_information import read_information_csv,plan_employee_import
from result_filters import csv_month_coverage,missing_csv_months,is_missing_month_csv_gap
from openpyxl import Workbook
out=[]
def record(name,**data):out.append(dict(case=name,**data))
def csvtext(rows):
 s=io.StringIO(newline='');csv.writer(s).writerows(rows);return s.getvalue()
def attendance(day='20261001',staff='S001',start='09:00',end='18:00',work='08:00'):
 r=['']*14;r[0]=day;r[3]=staff;r[4]='合成人員';r[10:14]=[start,end,work,'01:00'];return r
header=['date','calendar','','staff','name','','','','','','start','end','work','break']
cfg=copy.deepcopy(DEFAULT)
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp)
 current=root/'current.csv';current.write_text(csvtext([header,attendance()]),encoding='utf-8-sig')
 current_data=csv_read(current,cfg)
 cases={
 'empty_file':'','header_only':csvtext([header]),'all_empty_rows':csvtext([header,['']*14,[' ']*14]),
 'short_nonempty_no_keys':csvtext([header,['','勤務実績']]),
 'missing_both_keys_but_times':csvtext([header,attendance(day='',staff='')]),
 'missing_staff':csvtext([header,attendance(day='20260930',staff='')]),
 'missing_date':csvtext([header,attendance(day='',staff='S001')]),
 'invalid_date':csvtext([header,attendance(day='20260931')]),
 'invalid_time':csvtext([header,attendance(day='20260930',start='bad')]),
 'real_midnight':csvtext([header,attendance(day='20260930',start='0:00')]),
 'leading_zero_staff':csvtext([header,attendance(day='20260930',staff='00001')]),
 'duplicate_day':csvtext([header,attendance(day='20260930'),attendance(day='20260930')]),
 }
 gap={'date':'2026-09-30','status':'要確認','field':'CSV記録なし','crecord':None,'xrecord':{'invalid_fields':[]}}
 for name,text in cases.items():
  path=root/(name+'.csv');path.write_text(text,encoding='utf-8-sig')
  packet=csv_read(path,cfg)
  warnings=[{'file':path.name,'reason':w} for w in packet['warnings']]
  months=csv_month_coverage(current_data['records']+packet['records'],warnings=warnings)
  absent=missing_csv_months(months,cfg)
  record(name,records=len(packet['records']),warnings=packet['warnings'],months=sorted(months) if months is not None else None,absent=sorted(absent),previous_month_review_hidden=is_missing_month_csv_gap(gap,absent,cfg))
 # Current and previous month have different workers: absence of S001 cannot be hidden.
 path=root/'other_employee.csv';path.write_text(csvtext([header,attendance(day='20260930',staff='S999')]),encoding='cp932')
 p=csv_read(path,cfg);months=csv_month_coverage(current_data['records']+p['records']);record('individual_missing_not_hidden',months=sorted(months),hidden=is_missing_month_csv_gap(gap,missing_csv_months(months,cfg),cfg))
 path=root/'bad_encoding.csv';path.write_bytes(b'\xff\xfe\x80\xff')
 try:csv_read(path,cfg)
 except Exception as e:record('invalid_encoding',error=type(e).__name__+': '+str(e))
 # Employee import matrix, with actual A/B/C/J mapping.
 columns={'staff':'A','employee':'B','name':'C','email':'J'}
 def employee(s='00001',e='00002',name='合成人員',email='sample@example.invalid'):
  return [s,e,name,'','','','','','',email]
 info_cases={'leading_zeros':[employee()], 'missing_employee':[employee(e='')], 'missing_staff':[employee(s='')], 'missing_email':[employee(email='')], 'invalid_email':[employee(email='bad')], 'short_row':[['S1','E1']], 'conflicting_staff':[employee(s='S1'),employee(s='S2')], 'conflicting_employee':[employee(e='E1'),employee(e='E2')], 'duplicate_email':[employee(s='S1',e='E1'),employee(s='S2',e='E2')], 'all_blank':[['']*10], 'header_only':[]}
 for name,rows in info_cases.items():
  path=root/('employee_'+name+'.csv');path.write_text(csvtext([['スタッフID','派遣元スタッフコード','氏名','','','','','','','メール']]+rows),encoding='cp932')
  rows=read_information_csv(path,'linking',columns)
  mapping,data,results=plan_employee_import(rows,'linking',{}, {'version':1,'contacts':[]})
  record('employee_'+name,mapping=mapping,contact_count=len(data['contacts']),statuses=[r['status'] for r in results])
 # XLSX missing ID, genuine midnight, uncached time formula and missing calendar cell.
 for name,eid,day,start in [('missing_id','',1,'09:00'),('midnight','00002',1,0),('uncached_formula','00002',1,'=IF(1=1,"",0)'),('missing_day','00002',None,'09:00')]:
  wb=Workbook();ws=wb.active;ws.title='10月';ws['A1']='2026年10月度';ws['N1']=eid;ws['U1']='合成人員';ws['A9']=10;ws['B9']=day;ws['G9']=start;ws['H9']='18:00';ws['T9']='08:00'
  path=root/('book_'+name+'.xlsx');wb.save(path);wb.close();packet=xlsx_read(path,cfg)
  record('xlsx_'+name,error=packet.get('error'),records=len(packet.get('records',[])),warnings=packet.get('warnings'),invalid_fields=[r.get('invalid_fields') for r in packet.get('records',[])],starts=[r['values']['start'] for r in packet.get('records',[])])
path=Path(__file__).with_name('results.json');path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(out,ensure_ascii=False,indent=2))
