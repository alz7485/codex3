import os,sys,tempfile,copy,unittest,json
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
SOURCE=Path(os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync'))
sys.path.insert(0,str(SOURCE))
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication,QTableWidget,QPushButton,QLineEdit
from PySide6.QtTest import QTest
import test_trial58_csv_drop as f
import main
from engine import save_json,load_json
from employee_information import plan_employee_import
APP=f.APP

class Misuse(unittest.TestCase):
 setUp=f.CsvDrop58.setUp
 button=f.CsvDrop58.button
 dispatch=f.CsvDrop58.dispatch
 wizard=f.CsvDrop58.wizard
 def seed(self):
  self.window.mapping={'0001':'S01'}
  self.original={'version':1,'contacts':[{'employee':'0001','staff':'S01','name':'旧姓 社員','email':'one@example.com'}],'employee_names':{'0001':'旧姓 社員'},'staff_candidates':[{'employee':'0001','staff':'S01','name':'旧姓 社員'}],'employee_information_registered':True}
  save_json(main.MAP,self.window.mapping);save_json(main.MAP.with_name('employee_contacts.json'),self.original)
 def editor(self,fn):
  errors=[]
  def op():
   d=APP.activeModalWidget()
   try:fn(d)
   except Exception as e:errors.append(e)
   finally:
    if d.isVisible():d.reject()
  QTimer.singleShot(0,op)
  with patch.object(main.QMessageBox,'question',return_value=main.QMessageBox.Yes),patch.object(main.QMessageBox,'warning') as warning:
   self.window.edit_map();APP.processEvents()
  if errors:raise errors[0]
  self.assertFalse(warning.called,str(warning.call_args_list))
 def test_renaming_employee_id_resurrects_old_unlinked_employee(self):
  self.seed()
  def rename(d):
   t=d.findChild(QTableWidget,'employeeIdTable');t.item(0,0).setText('0002');t.cellWidget(0,3).setEditText('one@example.com')
   self.button(d,'社員情報を登録').click()
  self.editor(rename)
  self.assertEqual(self.window.mapping,{'0002':'S01'})
  result=[]
  def inspect(d):
   t=d.findChild(QTableWidget,'employeeIdTable')
   result.extend((t.item(i,0).text(),t.item(i,1).text(),main.selected_staff_id(t.cellWidget(i,2))) for i in range(t.rowCount()))
  self.editor(inspect)
  print('RENAMED_REOPEN_ROWS',result,flush=True)
  self.assertEqual(result,[('0002','旧姓 社員','S01')], '旧IDが名前辞書から未紐付け社員として復活')
 def test_csv_reimport_name_change_does_not_update_display_and_reverts_contact(self):
  self.seed()
  row={'employee':'0001','staff':'S01','name':'新姓 社員','email':'one@example.com','line':2}
  mapping,data,results=plan_employee_import([row],'linking',self.window.mapping,self.original)
  print('REIMPORT_NAME',data['employee_names'],data['contacts'],flush=True)
  # Actual UI rebuild after an import: start with the planned data as persisted input.
  save_json(main.MAP.with_name('employee_contacts.json'),data)
  display=[]
  def inspect_save(d):
   t=d.findChild(QTableWidget,'employeeIdTable');display.append(t.item(0,1).text());self.button(d,'社員情報を登録').click()
  self.editor(inspect_save)
  saved=load_json(main.MAP.with_name('employee_contacts.json'),{})
  print('AFTER_REGISTER_NAME',display,saved['contacts'],flush=True)
  self.assertEqual(display,['新姓 社員'],'再取込CSVの新氏名が表示されない')
 def test_add_row_during_search_stays_accessible(self):
  self.seed();rows=[]
  def op(d):
   search=next(x for x in d.findChildren(QLineEdit) if x.placeholderText()=='社員ID・氏名・メールで検索')
   search.setText('0001');self.button(d,'社員番号を追加').click()
   t=d.findChild(QTableWidget,'employeeIdTable');rows.append((t.rowCount(),t.isRowHidden(t.rowCount()-1)))
  self.editor(op);print('ADD_ROW_DURING_SEARCH',rows,flush=True)
  self.assertFalse(rows[0][1],'追加直後の空欄行が検索フィルタで非表示になる')
 def test_rapid_column_changes_and_cancel_preserve_files(self):
  self.seed();before=main.MAP.read_bytes();contacts=main.MAP.with_name('employee_contacts.json').read_bytes()
  errors=[]
  from employee_information import show_employee_import_dialog
  def op():
   d=APP.activeModalWidget()
   try:
    path=d.findChild(QLineEdit,'informationCsvPath');path.setText(str(self.csv));QTest.qWait(300)
    t=d.findChild(QTableWidget,'informationPreview');self.assertEqual(t.rowCount(),1)
    field=d.findChild(QLineEdit,'informationColumn_employee')
    for value in ['A','Z','','C','B']:field.setText(value)
    self.assertEqual(t.rowCount(),0);self.assertFalse(self.button(d,'一覧に反映').isEnabled())
    QTest.qWait(300);self.assertEqual(t.rowCount(),1);self.assertEqual(t.item(0,1).text(),'0001')
   except Exception as e:errors.append(e)
   finally:d.reject()
  QTimer.singleShot(0,op);result=show_employee_import_dialog(self.window,self.window.mapping,copy.deepcopy(self.original),main.DEFAULT)
  self.assertFalse(errors,errors);self.assertIsNone(result);self.assertEqual(main.MAP.read_bytes(),before);self.assertEqual(main.MAP.with_name('employee_contacts.json').read_bytes(),contacts)

 def test_drop_burst_then_new_drop_and_cancel_isolated(self):
  self.seed();second=self.folder/'second.csv';second.write_text('sid,eid,name,D,E,F,G,H,I,email\nS02,0002,新社員,,,,,,,two@example.com\n')
  before=main.MAP.read_bytes();contact=main.MAP.with_name('employee_contacts.json').read_bytes()
  from PySide6.QtCore import QUrl
  def op(d):
   first=self.dispatch(d);self.assertTrue(all(e.isAccepted() for e in first))
   for _ in range(15):self.assertFalse(any(e.isAccepted() for e in self.dispatch(d,[QUrl.fromLocalFile(str(second))])))
   APP.processEvents();table=d.findChild(QTableWidget,'informationPreview');self.assertEqual(table.item(0,1).text(),'0001')
   self.assertTrue(all(e.isAccepted() for e in self.dispatch(d,[QUrl.fromLocalFile(str(second))])))
   APP.processEvents();self.assertEqual(table.item(0,1).text(),'0002');d.reject()
  self.assertIsNone(self.wizard(op,self.original));self.assertEqual(main.MAP.read_bytes(),before);self.assertEqual(main.MAP.with_name('employee_contacts.json').read_bytes(),contact)
 def test_pending_drop_closed_before_delivery_never_updates_reopened_dialog(self):
  def close(d):self.dispatch(d);d.reject()
  self.assertIsNone(self.wizard(close))
  def reopened(d):
   QTest.qWait(350)
   self.assertEqual(d.findChild(QTableWidget,'informationPreview').rowCount(),0)
   self.assertEqual(d.findChild(QLineEdit,'informationCsvPath').text(),'')
   self.assertFalse(self.button(d,'一覧に反映').isEnabled());d.reject()
  self.assertIsNone(self.wizard(reopened))

 def test_conflicting_csv_ids_never_replace_existing_name_or_mail(self):
  self.seed()
  conflict_cases=[
   [{'employee':'0001','staff':'S99','name':'無関係な氏名','email':'other@example.com','line':2}],
   [{'employee':'0002','staff':'S01','name':'無関係な氏名','email':'other@example.com','line':2}],
   [{'employee':'0001','staff':'S01','name':'無関係な氏名A','email':'other@example.com','line':2}, {'employee':'0001','staff':'S99','name':'無関係な氏名B','email':'other@example.com','line':3}],
   [{'employee':'0001','staff':'S01','name':'無関係な氏名A','email':'other@example.com','line':2}, {'employee':'0002','staff':'S01','name':'無関係な氏名B','email':'other@example.com','line':3}]
  ]
  for rows in conflict_cases:
   with self.subTest(rows=rows):
    mapping,data,results=plan_employee_import(rows,'linking',self.window.mapping,self.original)
    self.assertEqual(mapping,self.window.mapping)
    self.assertEqual(data['employee_names']['0001'],'旧姓 社員')
    self.assertEqual(data['contacts'],self.original['contacts'])
    self.assertTrue(all(not r['id_matched'] for r in results))
    self.assertEqual(self.original['employee_names']['0001'],'旧姓 社員')

if __name__=='__main__':unittest.main(verbosity=2)
