import os,sys,copy,tempfile
from pathlib import Path
from unittest.mock import patch
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
sys.path.insert(0,'/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync')
import runtime_paths
from engine import DEFAULT,reconcile
with tempfile.TemporaryDirectory() as tmp,patch.object(runtime_paths,'get_data_dir',return_value=Path(tmp)):
 import main
 x={'E001':{'info':{'name':'監査社員'},'records':[dict(employee='E001',name='監査社員',date='2026-10-01',values=dict(start='',end='',work=''),invalid_fields=[])]}}
 for field,value in [('missing_fields',[[]]),('missing_fields',[{}]),('invalid_fields',[[]])]:
  c=dict(staff='S001',name='監査社員',date='2026-10-01',values=dict(start='',end='',work=''),invalid_fields=[],missing_fields=[])
  c[field]=value;packet={'records':[c],'warnings':[]}
  accepted=main.ReadWorker._valid_cached_packet(packet,False)
  try:
   rows,issues=reconcile(x,[c],{'E001':'S001'},copy.deepcopy(DEFAULT));result='no exception'
  except Exception as exc:result=f'{type(exc).__name__}: {exc}'
  print(field,repr(value),'cache_accepted=',accepted,'reconcile=',result)
