import os,sys,copy,json,tempfile
from pathlib import Path
os.environ['QT_QPA_PLATFORM']='offscreen'
SRC=Path(os.environ.get('ATTENDSYNC_AUDIT_SOURCE','/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync'))
sys.path.insert(0,str(SRC))
import test_trial38_audit as f
from engine import DEFAULT,xlsx_read
from openpyxl import load_workbook
f.Audit38.setUpClass()
t=f.Audit38('runTest');t.setUp();w=t.w
stats=dict(elapsed=.1,cache_hits=0,parsed=2,files_found=2,files_completed=2)
try:
    source=Path(t.xdata['10001']['records'][0]['file'])
    target=Path(t.tmp.name)/'invalid.xlsx'
    book=load_workbook(source);sheet=book['10月'];rec=next(r for r in t.xdata['10001']['records'] if r['date']=='2026-09-16')
    sheet[f'G{rec["row"]}']='NOT_A_TIME'
    book.save(target);book.close()
    packet=xlsx_read(target,DEFAULT)
    bad=next(r for r in packet['records'] if r['date']=='2026-09-16')
    x=copy.deepcopy(t.xdata);x['10001']=packet
    current=[r for r in t.cdata if r['date'].startswith('2026-10')]
    w.read_done(x,current,[],stats)
    hidden=[r for r in w.results if r.get('employee')=='10001' and r['date']=='2026-09-16']
    print(json.dumps(dict(case='invalid xlsx plain text in absent CSV month',value=bad['values']['start'],invalid_fields=bad['invalid_fields'],parser_warnings=packet['warnings'],raw_rows=[{k:r.get(k) for k in ['employee','date','field','status']} for r in hidden],visible_bad_date=any(r in w.visible for r in hidden),hidden_count=w.hidden_csv_month_rows_count),ensure_ascii=False,indent=2))
    if os.environ.get('EXPECT_FIXED')=='1':
        assert hidden and all(r in w.visible for r in hidden), 'Source input error was hidden'
        assert w.hidden_csv_month_rows_count==59
        print('FIX VERIFIED: malformed XLSX source date stays visible with checkbox ON')
    w.hide_missing_csv_months.setChecked(False)
    print('OFF restores row:',any(r in w.visible for r in hidden))
finally:t.doCleanups()
