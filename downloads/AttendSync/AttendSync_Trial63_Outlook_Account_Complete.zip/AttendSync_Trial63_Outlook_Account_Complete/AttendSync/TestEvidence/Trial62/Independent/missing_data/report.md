# Trial61 欠損・不正データ監査

監査対象: `/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync`。アプリ本体は編集していません。外部通信・メール認証・送信なし。すべて tempfile 内の合成CSV/XLSXです。

## 確認済み 1: 空CSV・キー両方欠損行を「月のCSVなし」として隠す（高）

- 該当: `engine.py:338,364`, `result_filters.py:16-26`。
- 条件: 正常な10月CSVと、0バイト/ヘッダーのみ/空行のみ/日付とスタッフIDは両方空だが時刻がある前月CSVを読み込む。
- 期待: 前月のCSVが存在していて内容を正常に読めていない場合は、その旨を警告し、月度非表示による前月の要確認の自動除外を抑止する。
- 実際: これらのCSVは `records=[]`, `warnings=[]` の成功扱い。coverage が `{'2026-10'}` となり、9月の `CSV記録なし` の要確認が非表示対象になる。
- 再現: `/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/missing_data/probe_missing_data.py`。
- 証拠: `results.json` の `empty_file`, `header_only`, `all_empty_rows`, `short_nonempty_no_keys`, `missing_both_keys_but_times` はいずれも `previous_month_review_hidden=true`, `warnings=[]`。
- 対照: 日付だけ欠損、スタッフIDだけ欠損、不正日付は警告が出て非表示が抑止される。別社員の前月行が1件でも存在するケースでは個人欠落は隠さない。
- 修正案: 非空のキー両欠損行を警告。各CSVの有効行0件も検出し警告し、空CSV警告がある読込では月度非表示を保守的に抑止。キャッシュ済み旧パケットも対象となるようparser版更新かworker側判定を行う。
- 同一原因は別監査役でも再現中とのroot連絡あり。二重計上不要。

## 確認済み 2: 短いCSV行の存在しない時刻列が休日空欄と一致する（中）

- 該当: `engine.py:348,351-355`、`engine.py:99-103` の `col`。
- 条件: CSVデータ行が `20261001,,,S001,合成人員` の5列のみで、設定列K/L/Mの始業・終業・実働が物理的に存在しない。XLSX側の同日の3項目は休日空欄。
- 期待: 既存セルの空文字と、設定列自体を含まない短い行は区別し、列欠損の入力異常として要確認にする。
- 実際: `col()` が存在しない列も `None` に変換し、`csv_read()` は `invalid_fields=[]`, `warnings=[]` で採用する。`reconcile()` の3項目すべてが `一致`。
- 最小再現: `/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/missing_data/probe_short_row.py`。
- 証拠: `short_row.log`。末尾のassertで「3項目一致かつ警告ゼロ」を確認済み。
- 修正案: CSV行の長さと列位置を比較し、必須比較列の物理的欠損を `invalid_fields` と警告にする。14列あり対象セルが空文字の通常休日CSVは引き続き一致。将来追加された比較列も対象とし、無効項目の扱いは既存の入力異常検出方針と整合させる。

## 追加確認と未確定事項

`probe_missing_data.py` で28条件を追加実行しました。上記以外にクラッシュや既存IDの無断上書きは確認していません。

- CP932社員CSV、スタッフID/社員IDのleading zero、欠損ID/メール、メール不正、短い社員CSV、ID競合、全空/見出しのみを確認。
- 社員CSVのID競合は自動紐付けされない。メールなしはID登録のみで、これは既存仕様。
- 勤怠CSVの不正日付・単独欠損ID・不正時刻・本当の0:00・同日重複・不明文字コードを確認。不正日付/単独欠損IDは警告。不正時刻はinvalid_fields保持。不明文字コードは例外になりworkerのファイルエラー処理の対象。
- XLSX社員ID空欄はerror、本当の0:00は数値0として保持、未計算時刻数式はinvalid_fields保持。
- 日付セルが空のXLSX行は警告なしで行を除外する。ただし期間整合性チェック/CSV側日付がある場合の「XLSX記録なし」が残るため、今回新たな非表示や誤一致の実害とは認定していません。
- 社員CSVで2社員に同じメールを指定するとimport計画には両方入るが、最終保存は `save_manual_contacts` が同一メールを拒否するため、誤登録確定とはしていません。

## 実行結果

- `probe_missing_data.py`: exit 0、28条件、出力 `results.json`, `probe.log`。
- `probe_short_row.py`: exit 0、短い行の誤一致をassertで確認、出力 `short_row.log`。
- 本報告はTrial61に対する修正前の監査です。rootによる修正後の再実行は別途必要です。

## Trial62修正確認（追記）

対象: `/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync`。

独立した `verify_trial62.py` を作成し、実際の `ReadWorker.run()`・SQLiteキャッシュ・CSVパーサ・reconcile・月度フィルタを通して14条件すべて成功しました。

- 空/見出しのみ/空行のみ/キー両欠損の4種類それぞれについて、初回解析と2回目キャッシュヒット（両CSVがcache_hits=2）を検証。どちらでも0有効行警告が出て、9月の要確認を隠さない。
- 短い5列CSVを初回解析・キャッシュヒットの両方で検証。K/L/M列のmissing_fieldsが保持され、3項目の「CSV列不足」と3項目の「要確認」が出る。
- 正常な14列で時刻セルだけ空の休日CSVは3項目すべて一致を維持。
- 比較OFFでは不足列の要確認を出さず、その後同じ構造メタデータの比較をONにすると要確認を出す。
- 一部社員だけ前月が欠けるケースは隠さない。
- Trial61の実parser_tagを使用して旧SQLiteキャッシュパケットを投入し、Trial62でcache_hits=0/parsed=1となり、missing_fields付きで再解析されることを確認。

コマンド: `/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/missing_data/verify_trial62.py`

出力: `trial62_verification.json`, `trial62_verification.log`。修正後の監査で追加不具合なし。指摘2件はいずれも解消を確認しました。本体変更なし。
