import sys,copy,json
from datetime import date,timedelta
from pathlib import Path
import os
src=Path(os.environ.get('ATTENDSYNC_AUDIT_SOURCE','/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync'))
sys.path.insert(0,str(src))
from result_filters import csv_month_coverage,missing_csv_months,is_missing_month_csv_gap
from engine import DEFAULT,reconcile,comparison_totals
count=0
for y in (2000,2026,2027,2028,2100):
 for m in range(1,13):
  cfg=copy.deepcopy(DEFAULT);cfg.update(year=y,month=m)
  end=date(y,m,15);start=(end.replace(day=1)-timedelta(days=1)).replace(day=16)
  days=[start+timedelta(days=i) for i in range((end-start).days+1)]
  for keep in (start.strftime('%Y-%m'),end.strftime('%Y-%m')):
   coverage=csv_month_coverage([dict(date=d.isoformat()) for d in days if d.strftime('%Y-%m')==keep])
   absent=missing_csv_months(coverage,cfg)
   for d in days+[start-timedelta(days=1),end+timedelta(days=1)]:
    row=dict(status='要確認',date=d.isoformat(),field='CSV記録なし',crecord=None,xrecord={})
    assert is_missing_month_csv_gap(row,absent,cfg)==(start<=d<=end and d.strftime('%Y-%m')!=keep)
    count+=1
  vals=dict(start='8:30',end='17:30',work='8:00')
  x={'E':dict(info=dict(name='監査社員'),records=[dict(date=d.isoformat(),name='監査社員',values=vals) for d in days])}
  c=[dict(date=d.isoformat(),staff='S',values=vals) for d in days]
  cfg['comparisons'].append(copy.deepcopy(cfg['comparisons'][0]))
  rows,issues=reconcile(x,c,{'E':'S'},cfg)
  total=comparison_totals(x,rows,cfg)
  assert total['matched']==total['expected']==4*len(days)
  assert total['missing']==total['duplicates']==total['review']==0
  count+=1
print(json.dumps(dict(source=str(src),calendar_cases=60,assertions=count,passed=True),indent=2))
