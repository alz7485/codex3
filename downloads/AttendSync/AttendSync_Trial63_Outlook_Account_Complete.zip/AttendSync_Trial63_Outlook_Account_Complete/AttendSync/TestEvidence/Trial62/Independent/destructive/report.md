# Trial61 破壊・故障注入監査

対象: `/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync`。
社員情報登録・回復処理、読み込み中止、終了、古いワーカー通知と月なしCSV非表示状態を監査した。配布ソースを編集せず、全ファイル操作を合成データのTemporaryDirectoryで隔離。外部メール、認証、ネットワークは使用していない。

## 確認済み不具合 D1 — P2

**破損した回復ジャーナルを拒否する前に、社員メール情報が書き換わる／削除される。**

- 箇所: `employee_information.py:49` `_recover()`、特に54行。`_restore()`は35行、base64検証は39行。
- 期待: 回復データの型・エンコードが不正なら、mapping/contactsのどちらも変更せず、ジャーナルを残してエラーにする。
- 実際: `contacts`を復元／削除してから`mapping`のbase64・型を検証する。後者が壊れていると、例外で起動は止まるがcontactsは既に変更済み。
- 条件1: ジャーナル`mapping`が`"!!corrupt!!"`、`contacts`が旧版JSONの有効base64。現在のcontactsを旧版へ巻き戻した後にValueError。
- 条件2: ジャーナル`mapping`が数値23、`contacts`がnull。現在のemployee_contacts.jsonを削除した後にTypeError。
- 影響: クラッシュ回復データの部分破損・手編集などに限る。通常CSV操作だけで発生するものではないが、破損時の既存ファイル保護を満たさない。
- 最小再現コマンド（2条件のうち1つ）:

```bash
/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/destructive/audit_destructive.py DestructiveAudit.test_corrupt_mapping_snapshot_must_not_restore_contacts_first
```

- 修正案: snapshotsの2値をいずれもnullか文字列か検証し、すべてのbase64をdecodeし終えてから復元・削除を開始する。形式エラーは一律ValueErrorにし、ジャーナルを残す。ファイル権限障害の途中回復は既存ジャーナルを残して再実行できる挙動を保持する。

## 実行結果

独立した新規試験15件、13件成功・D1を検出する2件失敗。約0.7秒。ログ: `results.log`、再現コード: `audit_destructive.py`。

成功した境界条件:

- 1ファイル目のPermissionErrorで両方の原本を保持。
- 2ファイル目を途中で切断してからOSErrorにしても両方の原本をバイト単位で復元。
- 新規登録のクラッシュ（元ファイル両方なし）で部分ファイルを除去。
- 正常なクラッシュジャーナルから両方復元。
- JSON自体の破損・想定外ジャーナルキーでは原本を保持。
- 他処理のOSロック取得中は保存を拒否し、原本を保持。
- 復元時もPermissionErrorになる場合はジャーナルを保持し、障害解消後の再回復で原本を復元。
- JSONシリアライズ失敗で既存ファイルを切断しない。
- 読み込み中に終了Yesを選ぶとキャンセル要求後も閉じるイベントを拒否し、ワーカー終了を待つ。再度閉じても再確認／再中止しない。
- 終了Noでは実行中のワーカーを中止しない。
- 中止済みワーカーの結果は前回結果・前回月度・CSV月度カバレッジを保持し、前月非表示の結果も保持。
- 古いワーカーからの結果通知は現行結果を上書きしない。

## 限界・未確認

権限障害はモックによる決定的な故障注入（root実行のためchmodだけでは有効な否認にならない）。GUIはLinux/offscreen。終了のQCloseEvent経路にはFakeWorkerを使い、実際のExcel/Windowsファイルロック、プロセス強制終了／電源断を再現した保証はしない。確認済みの不具合はD1のみで、これらの限界を不具合として数えていない。

## Trial62 修正後再監査

対象を `/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync` に切り替えて実行。**18件すべて成功**（うち追加試験1件は18通りの破損スナップショットをsubTestで検証）。D1の2つの再現条件はいずれも原本がバイト単位で保護され、解消を確認した。

追加確認:

- mapping/contactsそれぞれに真偽値・数値・dict・list・非ASCII・不正base64・padding不正を入れても、いずれのファイルも変更／削除されない。全18パターン。
- JSONキー順をcontacts→mappingに変えても、mapping破損を検出する前にcontactsを削除しない。
- 正常なスナップショットの2ファイル目の復元でPermissionErrorになった場合は、ジャーナルを保持。障害解消後の再実行で両原本へ回復する。

```bash
AUDIT_SOURCE=/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial62-audit/destructive/audit_destructive.py
```

修正後ログ: `results-trial62.log`。監査担当はTrial61/62の本体ソースを変更していない。元のTrial61失敗ログ`results.log`は証跡として保持した。修正後に確認済みの未解決不具合なし。
