import os,sys,copy,json,unittest
from pathlib import Path
from datetime import date,timedelta
from unittest.mock import patch
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
SRC=Path(os.environ.get('ATTENDSYNC_AUDIT_SOURCE','/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync'))
sys.path.insert(0,str(SRC))
import test_trial38_audit as fixture
from engine import DEFAULT
import main
fixture.Audit38.setUpClass()
t=fixture.Audit38('runTest');t.setUp();w=t.w
out=[]
def sample(year=2026,month=10):
    cfg=copy.deepcopy(DEFAULT);cfg.update(year=year,month=month)
    end=date(year,month,15);start=(end.replace(day=1)-timedelta(days=1)).replace(day=16)
    days=[(start+timedelta(days=i)).isoformat() for i in range((end-start).days+1)]
    x={};c=[]
    for i in (1,2):
        eid,sid=f'E{i}',f'S{i}';x[eid]={'info':{'name':f'監査社員{i}'},'records':[]}
        for d in days:
            vals=dict(start='8:30',end='17:30',work='8:00',break_total='1:00')
            x[eid]['records'].append(dict(employee=eid,name=f'監査社員{i}',date=d,values=copy.deepcopy(vals),file='fixture.xlsx',row=9,invalid_fields=[]))
            c.append(dict(staff=sid,name=f'監査社員{i}',date=d,values=copy.deepcopy(vals),file='fixture.csv',row=2,invalid_fields=[]))
    return cfg,x,c,days

def run(name,cfg,x,c,extra=None):
    w.cfg=copy.deepcopy(cfg);w.mapping={'E1':'S1','E2':'S2'};w.search.clear();w.hide_missing_csv_months.setChecked(True);w.filter_state='不一致のみ'
    stats=dict(elapsed=.1,cache_hits=0,parsed=2,files_found=2,files_completed=2,**(extra or {}))
    w.read_done(x,c,[],stats)
    s=w.comparison_summary
    assert s['expected']==s['matched']+s['mismatched']+s['review']+s['missing'],name
    total=copy.deepcopy(s);allrows=copy.deepcopy(w.results)
    w.select_filter('すべて');assert len(w.visible)==len(w.results)-w.hidden_csv_month_rows_count,name
    assert w.model.rowCount()==len(w.visible),name
    if w.visible:
        with patch.object(main,'print_html') as p:w.print_list(preview=True)
        html=p.call_args.args[1];assert html.count('<tr>')-1==len(w.visible),name
    w.hide_missing_csv_months.setChecked(False)
    assert w.visible==w.results,name
    assert w.comparison_summary==total and w.results==allrows,name
    w.hide_missing_csv_months.setChecked(True)
    rec=dict(name=name,rows=len(w.results),hidden=w.hidden_csv_month_rows_count,summary=total,total_label=w.total_check.text())
    out.append(rec);return rec
try:
    for year,month in ((2026,10),(2027,1),(2028,3)):
        cfg,x,c,days=sample(year,month);prev=days[0][:7];curr=days[-1][:7]
        full=run(f'{year}-{month} both months',cfg,x,c);assert full['hidden']==0 and full['summary']['matched']==full['summary']['expected']
        for keep in (prev,curr):
            rec=run(f'{year}-{month} only {keep}',cfg,x,[r for r in c if r['date'].startswith(keep)])
            assert rec['hidden']==2*sum(not d.startswith(keep) for d in days)
            assert '全数一致に未達' in rec['total_label']
    cfg,x,c,days=sample();prev=days[0][:7];curr=days[-1][:7]
    rec=run('employee missing entire previous month',cfg,x,[r for r in c if not(r['staff']=='S1' and r['date'].startswith(prev))]);assert rec['hidden']==0
    rec=run('unknown staff has previous month',cfg,x,[r for r in c if r['date'].startswith(curr)]+[{**r,'staff':'UNREGISTERED'} for r in c if r['date'].startswith(prev)]);assert rec['hidden']==0
    current=[r for r in c if r['date'].startswith(curr)]
    for reason in ('日付不正','IDまたは日付が空欄'):
        rec=run(reason,cfg,x,current,dict(read_warnings=[dict(file='previous.CSV',reason=reason)]));assert rec['hidden']==0
    rec=run('failed CSV',cfg,x,current,dict(file_errors=[dict(file='previous.CSV',reason='broken')]));assert rec['hidden']==0
    rec=run('all CSV empty',cfg,x,[]);assert rec['hidden']==0
    xx=copy.deepcopy(x);xx['E1']['records'][0]['invalid_fields']=['start']
    rec=run('formula cached result absent stays visible',cfg,xx,current);assert rec['hidden']==29
    run('current calendar month but out of attendance period',cfg,x,[{**r,'date':'2026-10-20'} for r in current[:1]])
    print(json.dumps(dict(source=str(SRC),cases=len(out),passed=True,results=out),ensure_ascii=False,indent=2))
finally:t.doCleanups()
