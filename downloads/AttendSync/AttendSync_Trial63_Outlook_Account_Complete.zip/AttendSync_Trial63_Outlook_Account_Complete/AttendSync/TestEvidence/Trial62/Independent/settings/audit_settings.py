"""Read-only Trial 61 audit; only temp employee/settings data are written."""
import os,sys,copy,json,tempfile
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
SOURCE=Path('/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync')
sys.path.insert(0,str(SOURCE))
from PySide6.QtWidgets import QApplication,QTableWidget,QPushButton,QLineEdit,QDialog
from PySide6.QtCore import QTimer
import runtime_paths
tmp=tempfile.TemporaryDirectory();root=Path(tmp.name)
with patch.object(runtime_paths,'get_data_dir',return_value=root):import main
from engine import DEFAULT,save_json
from employee_information import load_information,plan_employee_import,show_employee_import_dialog,registration_is_ready
from settings_dialog import SettingsDialog
app=QApplication.instance() or QApplication([]);app.setQuitOnLastWindowClosed(False)
results=[]
def record(name,**data):
    item=dict(name=name,**data);results.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
def button(d,text):return next(b for b in d.findChildren(QPushButton) if b.text()==text)
with patch.multiple(main,CONFIG=root/'settings.json',MAP=root/'staff_mapping.json',DB=root/'cache.db'):
    old={'version':1,'contacts':[{'employee':'0001','staff':'S01','name':'旧姓 太郎','email':'one@example.com'}],
         'employee_names':{'0001':'旧姓 太郎'},'staff_candidates':[{'employee':'0001','staff':'S01','name':'旧姓 太郎'}],
         'employee_information_registered':True,'future_extension':{'retain':[1,2]}}
    mapping={'0001':'S01'}
    row={'employee':'0001','staff':'S01','name':'新姓 太郎','email':'one@example.com','line':2}
    newmap,data,imported_rows=plan_employee_import([row],'linking',mapping,old)
    record('reimport_name_plan',employee_names=data['employee_names'],contact_name=data['contacts'][0]['name'],staff_name=data['staff_candidates'][0]['name'])
    save_json(main.MAP,mapping);save_json(main.MAP.with_name('employee_contacts.json'),old)
    w=main.Window();errors=[];seen={}
    def update():
        dlg=app.activeModalWidget()
        try:
            button(dlg,'社員情報を読み込む').click()
            table=dlg.findChild(QTableWidget,'employeeIdTable');seen['name_after_import']=table.item(0,1).text()
            button(dlg,'社員情報を登録').click()
        except Exception as e:errors.append(repr(e));dlg.reject()
    with patch('employee_information.show_employee_import_dialog',return_value={'mapping':newmap,'contacts':data,'results':imported_rows}):
        QTimer.singleShot(0,update);w.edit_map()
    saved=load_information(main.MAP.with_name('employee_contacts.json'))
    record('reimport_name_real_editor',**seen,saved_name=saved['employee_names']['0001'],saved_contact_name=saved['contacts'][0]['name'],errors=errors)
    record('unknown_employee_metadata_preserved',actual=saved['future_extension'])
    w.close()
    # Public loader currently accepts malformed nested employee import settings.
    for label,value in [('null',None),('list',[]),('columns_null',{'columns':None}),('first_row_text',{'first_row':'two'}),('first_row_bool',{'first_row':True})]:
        bad={**old,'employee_import_settings':{'linking':value}}
        save_json(main.MAP.with_name('employee_contacts.json'),bad)
        try:loaded=load_information(main.MAP.with_name('employee_contacts.json'));loader='accepted'
        except Exception as e:record('bad_import_settings_'+label,loader=repr(e));continue
        # Ensure modal widgets always get closed if construction succeeds.
        QTimer.singleShot(0,lambda: app.activeModalWidget().reject() if app.activeModalWidget() else None)
        try:show_employee_import_dialog(None,mapping,loaded,DEFAULT);outcome='opened'
        except Exception as e:outcome=repr(e)
        for d in app.topLevelWidgets():
            if isinstance(d,QDialog):d.close()
        app.processEvents()
        record('bad_import_settings_'+label,loader=loader,dialog=outcome)
    # Unknown settings and comparison metadata survive normal UI save.
    cfg=copy.deepcopy(DEFAULT);cfg['future_extension']={'retain':[1,2]};cfg['comparisons'][0]['future_rule']={'threshold':13}
    dlg=SettingsDialog(w,cfg);dlg.accept()
    record('unknown_settings_roundtrip',unknown=dlg.value.get('future_extension'),comparison_unknown=dlg.value['comparisons'][0].get('future_rule'));dlg.close()
    # Persisted custom columns and first row are actually shown without rewriting.
    custom={**old,'employee_import_settings':{'linking':{'columns':{'staff':'E','employee':'F','name':'G','email':'K'},'first_row':5,'encoding':'cp932'}}}
    fields={}
    def inspect():
        dlg=app.activeModalWidget()
        try:
            fields.update({k:dlg.findChild(QLineEdit,'informationColumn_'+k).text() for k in ('staff','employee','name','email')})
            fields['first_row']=dlg.findChild(__import__('PySide6.QtWidgets',fromlist=['QSpinBox']).QSpinBox,'informationFirstRow').value()
        finally:dlg.reject()
    QTimer.singleShot(0,inspect);show_employee_import_dialog(None,mapping,custom,DEFAULT)
    record('custom_columns_roundtrip',actual=fields)
    for label,metadata,mapping2 in [('missing',{},mapping),('old_contact',old,mapping),('link_role',{'csv_sources':{'/x.csv':'linking'}},mapping),('attendance_role',{'csv_sources':{'/x.csv':'attendance'}},mapping),('flag_without_mapping',{'employee_information_registered':True},{})]:
        record('registration_'+label,ready=registration_is_ready(metadata,mapping2))
Path(__file__).with_name('results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
tmp.cleanup()
