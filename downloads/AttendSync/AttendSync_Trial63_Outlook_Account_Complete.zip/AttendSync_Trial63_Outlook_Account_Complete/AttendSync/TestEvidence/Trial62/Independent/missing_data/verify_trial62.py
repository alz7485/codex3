"""Independent fix verification through the real parser/worker/cache paths."""
import os;os.environ['QT_QPA_PLATFORM']='offscreen'
import copy,csv,io,json,sqlite3,sys,tempfile
from pathlib import Path
from unittest.mock import patch
SOURCE=Path('/workspace/attendsync-audit/AttendSync_Trial62_Final_Audit_Complete/AttendSync');sys.path.insert(0,str(SOURCE))
import runtime_paths
isolation=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(isolation.name)):
 import main
from PySide6.QtCore import QCoreApplication
from engine import DEFAULT,csv_read,reconcile
from result_filters import csv_month_coverage,missing_csv_months,is_missing_month_csv_gap
from cache_tags import PARSER_VERSION
app=QCoreApplication.instance() or QCoreApplication([])
checks=[]
def passed(case,**data):checks.append(dict(case=case,passed=True,**data))
def text(rows):
 stream=io.StringIO(newline='');csv.writer(stream).writerows(rows);return stream.getvalue()
header=['date','calendar','','staff','name','','','','','','start','end','work','break']
row=['20261001','','','S1','合成人員','','','','','','','','','']
gap={'date':'2026-09-30','status':'要確認','field':'CSV記録なし','crecord':None,'xrecord':{'invalid_fields':[]}}
variants={'empty':'','header_only':text([header]),'blank_rows':text([header,['']*14]),'both_keys_missing':text([header,['','','','','合成人員','','','','','','09:00']])}
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp)
 for name,broken in variants.items():
  folder=root/name;folder.mkdir();(folder/'current.csv').write_text(text([header,row]),encoding='utf-8');(folder/'previous.csv').write_text(broken,encoding='utf-8')
  db=root/(name+'.sqlite3')
  with patch.object(main,'DB',db):
   for run in (1,2):
    worker=main.ReadWorker(folder,copy.deepcopy(DEFAULT));capture=[];worker.result.connect(lambda *args:capture.append(args));worker.run();assert len(capture)==1
    x,c,issues,stats=capture[0]
    assert not stats.get('fatal_error'),stats
    assert not stats['file_errors'],stats
    warning=[w for w in stats['read_warnings'] if w['file']=='previous.csv' and '有効な勤怠行がありません' in w['reason']]
    assert warning,(name,run,stats)
    assert len(c)==1,(name,c)
    months=csv_month_coverage(c,stats['file_errors'],stats['read_warnings']);assert months is None,(name,months)
    assert not is_missing_month_csv_gap(gap,missing_csv_months(months,DEFAULT),DEFAULT)
    assert stats['cache_hits']==(0 if run==1 else 2),stats
    passed(name+('_parse' if run==1 else '_cache'),cache_hits=stats['cache_hits'],warnings=stats['read_warnings'])
 # Short rows no longer pass as holiday blanks, for both direct parsing and cached worker.
 folder=root/'short';folder.mkdir();p=folder/'attendance.csv';p.write_text(text([header,row[:5]]),encoding='utf-8')
 xrecord={'employee':'E1','name':'合成人員','date':'2026-10-01','values':{'start':None,'end':None,'work':None},'invalid_fields':[]}
 xd={'E1':{'info':{'name':'合成人員'},'records':[xrecord]}}
 for run in (1,2):
  with patch.object(main,'DB',root/'short.sqlite3'):
   worker=main.ReadWorker(folder,copy.deepcopy(DEFAULT));capture=[];worker.result.connect(lambda *args:capture.append(args));worker.run()
  _,c,issues,stats=capture[0];assert stats['cache_hits']==run-1
  assert {'start','end','work'}<=set(c[0]['missing_fields'])
  rows,_=reconcile(xd,c,{'E1':'S1'},DEFAULT)
  comparisons=[r for r in rows if 'comparison_index' in r];assert len(comparisons)==3 and all(r['status']=='要確認' for r in comparisons),rows
  assert len([r for r in rows if r['field'].startswith('CSV列不足')])==3,rows
  passed('short_row'+('_parse' if run==1 else '_cache'),cache_hits=stats['cache_hits'],statuses=[r['status'] for r in comparisons])
 # Explicitly existing blank columns remain valid holiday data.
 p.write_text(text([header,row]),encoding='utf-8');packet=csv_read(p,DEFAULT);rows,_=reconcile(xd,packet['records'],{'E1':'S1'},DEFAULT)
 assert len(rows)==3 and all(r['status']=='一致' for r in rows),rows
 passed('full_width_holiday_blank_still_matches')
 # Deferred disabled comparisons must inspect cached structural metadata when reenabled.
 p.write_text(text([header,row[:5]]),encoding='utf-8');packet=csv_read(p,DEFAULT);cfg=copy.deepcopy(DEFAULT)
 for comparison in cfg['comparisons']:comparison['enabled']=False
 rows,_=reconcile(xd,packet['records'],{'E1':'S1'},cfg);assert rows==[],rows
 cfg['comparisons'][0]['enabled']=True;rows,_=reconcile(xd,packet['records'],{'E1':'S1'},cfg)
 assert len(rows)==2 and all(r['status']=='要確認' for r in rows),rows
 passed('disabled_then_enabled_comparison_uses_structural_metadata')
 # A single employee missing previous month must remain visible when some other employee provides the month.
 previous=dict(packet['records'][0],staff='S_OTHER',date='2026-09-30')
 months=csv_month_coverage([dict(previous,date='2026-10-01'),previous]);assert not is_missing_month_csv_gap(gap,missing_csv_months(months,DEFAULT),DEFAULT)
 passed('individual_month_absence_not_hidden')
 # Seed a genuine Trial61-signature cache packet that lacks new structural metadata.
 import runpy
 old_tags=runpy.run_path('/workspace/attendsync-audit/AttendSync_Trial61_Missing_CSV_Month_Filter_Complete/AttendSync/cache_tags.py')
 from cache_tags import parser_tag
 assert PARSER_VERSION!=old_tags['PARSER_VERSION']
 assert parser_tag(DEFAULT,'csv')!=old_tags['parser_tag'](DEFAULT,'csv')
 stale_db=root/'stale.sqlite3';cache=main.Cache(stale_db);stat=p.stat();old_packet=copy.deepcopy(packet)
 for r in old_packet['records']:r.pop('missing_fields',None)
 stale_sig=f"{stat.st_size}:{stat.st_mtime_ns}:{old_tags['parser_tag'](DEFAULT,'csv')}"
 cache.db.execute('INSERT INTO cache VALUES(?,?,?)',(str(p),stale_sig,json.dumps(old_packet)));cache.db.commit();cache.close()
 with patch.object(main,'DB',stale_db):
  worker=main.ReadWorker(folder,copy.deepcopy(DEFAULT));capture=[];worker.result.connect(lambda *args:capture.append(args));worker.run()
 _,c,_,stats=capture[0];assert stats['cache_hits']==0 and stats['parsed']==1,stats
 assert {'start','end','work'}<=set(c[0]['missing_fields'])
 passed('trial61_cache_signature_forces_reparse',parser_version=PARSER_VERSION,parsed=stats['parsed'])
Path(__file__).with_name('trial62_verification.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'checks':len(checks),'all_passed':True,'results':checks},ensure_ascii=False,indent=2))
isolation.cleanup()
