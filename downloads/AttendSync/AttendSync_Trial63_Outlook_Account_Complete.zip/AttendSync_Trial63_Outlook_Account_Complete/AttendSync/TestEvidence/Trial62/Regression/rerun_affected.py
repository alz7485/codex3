from pathlib import Path
import subprocess,json,os,time
out=Path(__file__).parent;root=out/'test_copy';rows=json.loads((out/'existing_results.json').read_text())
names={'test_trial44_audit.py','test_trial62_audit_regressions.py','test_trial30_dynamic_failures.py','test_trial50_regressions.py','test_trial61_month_filter.py'}
for item in rows:
 if item['script'] not in names:continue
 start=time.monotonic();p=subprocess.run(['/workspace/attendsync-audit/venv/bin/python',item['script']],cwd=root,env={**os.environ,'QT_QPA_PLATFORM':'offscreen','PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=45)
 (out/item['log']).write_text(p.stdout+p.stderr);item.update(returncode=p.returncode,seconds=round(time.monotonic()-start,2));print(item['script'],p.returncode,flush=True)
(out/'existing_results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));assert all(r['returncode']==0 for r in rows)
print('ALL',len(rows),'PASS')
