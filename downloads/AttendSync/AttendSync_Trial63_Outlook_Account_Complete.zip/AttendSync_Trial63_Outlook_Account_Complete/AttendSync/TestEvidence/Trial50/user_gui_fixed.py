import os, sys, json, tempfile, copy
from pathlib import Path
from unittest.mock import patch, Mock
os.environ['QT_QPA_PLATFORM']='offscreen'
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import runtime_paths
TMP=tempfile.TemporaryDirectory(dir=Path(__file__).parent)
base=Path(TMP.name)
with patch.object(runtime_paths,'get_data_dir',return_value=base):
    import main, printing
from PySide6.QtWidgets import QApplication,QDialog,QTableWidget,QPushButton
from PySide6.QtCore import QTimer,QCoreApplication,QEvent
app=QApplication.instance() or QApplication([])
app.setQuitOnLastWindowClosed(False)
records=[]
def record(name,**facts):records.append(dict(name=name,**facts))
def flush():
    app.processEvents();QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
def close_modal():
    d=app.activeModalWidget()
    if d:d.reject()
with patch.multiple(main,DATA_DIR=base,CONFIG=base/'settings.json',MAP=base/'mapping.json',DB=base/'cache.sqlite'):
    w=main.Window()
    old=copy.deepcopy(w.cfg)
    for value in ['',str(base/'missing'),str(base/'plain.txt'),str(base)]:
        (base/'plain.txt').write_text('synthetic')
        w.path.setText(value)
        with patch.object(main.QMessageBox,'warning') as warn,patch.object(main,'ReadWorker') as worker:
            w.run_read()
            record('invalid folder or missing pair',input=value,warning_count=warn.call_count,worker_started=worker.called,cfg_unchanged=w.cfg==old)
    w.worker=Mock();w.worker.isRunning.return_value=True
    with patch.object(main,'ReadWorker') as worker:
        for _ in range(20):w.run_read()
        record('repeated read while busy',created_workers=worker.call_count)
    w.stop_read();w.stop_read()
    record('repeated cancel',cancel_requests=w.worker.cancel.call_count,stop_enabled=w.stop_button.isEnabled())
    w.worker=None
    w.loaded_xdata={'E01':{'info':{'name':'合成氏名'}}}
    w.loaded_cdata=[{'staff':'S01','name':'合成氏名'}]
    w.mapping={}
    errors=[]
    def duplicate_employee():
        try:
            d=app.activeModalWidget();table=d.findChild(QTableWidget)
            add=next(b for b in d.findChildren(QPushButton) if b.text()=='社員番号を追加');add.click()
            table.item(1,0).setText('E01');table.cellWidget(1,2).setEditText('S01')
            next(b for b in d.findChildren(QPushButton) if b.text()=='紐付けを保存').click()
        except Exception as e:errors.append(str(e))
        finally:close_modal()
    with patch.object(main.QMessageBox,'warning') as warning,patch.object(w,'run_read'):
        QTimer.singleShot(0,duplicate_employee);w.edit_map();flush()
        record('duplicate employee with first row unlinked',warnings=warning.call_count,saved_mapping=w.mapping,errors=errors)
    # The dialogs are real Qt objects. Printer availability is synthetic so
    # the native cancellation path is reachable without a host printer.
    for preview in [False,True]:
        before=len(w.findChildren(QDialog));counts=[]
        for _ in range(4):
            QTimer.singleShot(0,close_modal)
            with patch.object(printing.QPrinterInfo,'availablePrinters',return_value=[Mock()]):
                printing.print_html(w,'<p>synthetic</p>',preview=preview)
            flush();counts.append(len(w.findChildren(QDialog)))
        record('print dialog cancellation lifecycle',preview=preview,before=before,after_each=counts)
    with patch.object(main.QMessageBox,'warning') as warning:
        w.open_excel_source({'file':str(base/'missing.xlsx'),'sheet':'10月','row':9},'start')
        record('Excel unavailable recovery',warnings=warning.call_count)
    w.worker=None;w.close();w.deleteLater();flush()
print(json.dumps(records,ensure_ascii=False,indent=2))
Path(__file__).with_suffix('.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
TMP.cleanup()

for item in records:
    if item['name']=='duplicate employee with first row unlinked':
        assert item['warnings']==1 and item['saved_mapping']=={} and not item['errors'],item
    if item['name']=='print dialog cancellation lifecycle':
        assert all(count==item['before'] for count in item['after_each']),item
print('PASS real Qt duplicate-ID and print/preview lifecycle regressions')
