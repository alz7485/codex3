import copy,json,os,sys,tempfile
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication,QDialog
import runtime_paths
with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
    with patch.object(runtime_paths,'get_data_dir',return_value=Path(directory)):
        import main
    app=QApplication([]);w=main.Window()
    w.cfg['theme']='light'
    initial=w.is_dark
    original=main.SettingsDialog
    def construct(parent,cfg):
        dlg=original(parent,cfg)
        def edit_and_save():
            new=copy.deepcopy(cfg);new['theme']='dark';new['read_workers']=2 if cfg.get('read_workers')!=2 else 3
            dlg.advanced.setPlainText(json.dumps(new))
            assert dlg.apply_json_to_form(),dlg.error_label.text()
            dlg.accept()
            assert dlg.result()==QDialog.Accepted,dlg.error_label.text()
        QTimer.singleShot(0,edit_and_save)
        return dlg
    with patch.object(main,'SettingsDialog',side_effect=construct):w.edit_settings()
    print('theme result:',{'before_is_dark':initial,'cfg_theme':w.cfg['theme'],'after_is_dark':w.is_dark,'disk_theme':json.loads(main.CONFIG.read_text())['theme'],'button_text':w.btn_theme.text()})
    assert w.cfg['theme']=='dark' and w.is_dark is True
    before=copy.deepcopy(w.cfg)
    with patch.object(main,'SettingsDialog',side_effect=construct),patch.object(main,'save_json',side_effect=PermissionError('synthetic save denial')),patch.object(main.QMessageBox,'warning') as warning:
        w.edit_settings()
    assert w.cfg==before;warning.assert_called_once()
    print('PASS failed UI settings save preserves memory config')
    w.close()
