from pathlib import Path
import subprocess,os,json,time
root=Path('/workspace/attendsync-audit/AttendSync_Trial63_Outlook_Account_Complete/AttendSync');out=Path(__file__).parent;results=[]
for name in ('test_trial34_settings.py','test_trial41_settings.py','test_trial54_mail.py','test_trial39_manual.py','test_trial33_ui.py','test_trial63_outlook_account.py'):
 start=time.monotonic();p=subprocess.run(['/workspace/attendsync-audit/venv/bin/python',name],cwd=root,env={**os.environ,'QT_QPA_PLATFORM':'offscreen','PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=60)
 (out/(Path(name).stem+'.log')).write_text(p.stdout+p.stderr)
 results.append({'script':name,'returncode':p.returncode,'seconds':round(time.monotonic()-start,2)})
 (out/'related_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(name,p.returncode,flush=True)
assert all(r['returncode']==0 for r in results)
