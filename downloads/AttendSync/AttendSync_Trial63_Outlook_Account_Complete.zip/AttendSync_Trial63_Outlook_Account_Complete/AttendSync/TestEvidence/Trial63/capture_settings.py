import sys,copy,json
from pathlib import Path
from unittest.mock import patch
root=Path('/workspace/attendsync-audit/AttendSync_Trial63_Outlook_Account_Complete/AttendSync');sys.path.insert(0,str(root))
from PySide6.QtWidgets import QApplication,QWidget
from engine import DEFAULT
from settings_dialog import SettingsDialog
from ui_theme import apply_theme
from outlook_mail import DEFAULT_MAIL_SETTINGS
app=QApplication([]);parent=QWidget();parent.is_dark=False
apply_theme(app,False)
cfg=copy.deepcopy(DEFAULT);cfg['mail_settings']={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com','sender_name':'勤怠担当','always_cc':'support@example.com'}
d=SettingsDialog(parent,cfg);d.tabs.setCurrentIndex(3);d.show();app.processEvents()
d.grab().save(str(root/'Manual/images/17-mail-settings-top.png'))
import classic_outlook
with patch.object(classic_outlook,'running_outlook_accounts',return_value=[{'account':'operator@example.com','sender_name':'勤怠担当'}]):d.outlook_account_button.click()
app.processEvents();d.grab().save(str(Path(__file__).parent/'outlook-account-settings.png'))
checks=[]
for dark in (False,True):
 apply_theme(app,dark);parent.is_dark=dark
 for width,height in ((1060,780),(780,580)):
  d.resize(width,height);app.processEvents();area=d.tabs.currentWidget()
  checks.append({'dark':dark,'width':width,'button_width':d.outlook_account_button.width(),'horizontal_scroll_max':area.horizontalScrollBar().maximum()})
  assert area.horizontalScrollBar().maximum()==0
area.verticalScrollBar().setValue(area.verticalScrollBar().maximum());d.resize(1060,780);apply_theme(app,False);app.processEvents();d.grab().save(str(root/'Manual/images/18-mail-settings-body.png'))
Path(__file__).with_name('capture_check.json').write_text(json.dumps(checks,indent=2));d.close();parent.close();app.processEvents();print('Mail settings screenshot and 4 layout checks OK; synthetic identity, no COM/Graph activity')
