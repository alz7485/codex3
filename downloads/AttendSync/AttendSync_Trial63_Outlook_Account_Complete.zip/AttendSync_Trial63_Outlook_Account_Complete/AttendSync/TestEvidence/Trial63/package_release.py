from pathlib import Path
import json,shutil,hashlib,zipfile
base=Path('/workspace/attendsync-audit');full=base/'AttendSync_Trial63_Outlook_Account_Complete';app=full/'AttendSync';out=base/'trial63-validation';dest=Path('/workspace/codex3/downloads/AttendSync')
results=json.loads((out/'related_results.json').read_text());assert len(results)==6 and all(r['returncode']==0 for r in results)
changes='''# Trial63 起動中のクラシックOutlookから設定を取得

「設定」→「メール」に「起動中のOutlookから取得」を追加しました。

1. WindowsでクラシックOutlookを開きます。
2. 取得ボタンを押します。メールアカウントが複数あれば、使うアカウントを選びます。
3. メールアドレスが「接続するアカウント」、表示名が「差出人名（本文用）」へ反映されます。「設定を保存」で確定します。

取得に失敗した場合・選択をキャンセルした場合は入力を保持します。表示名を取得できない場合も手入力した差出人名を保持します。Outlookの起動やプロファイルの切替、メール作成・送信は行いません。現在起動中のOutlookに接続してアカウント情報だけを読み取ります。

取得できるのはメールアドレスと表示名です。MicrosoftアプリID・テナントIDや必須To/CC、本文・署名は設定画面で指定します。下書き保存・送信は従来どおりMicrosoft Graph経由なので、Microsoftアプリ登録と初回サインインが必要です。

WindowsのクラシックOutlook専用です。起動中のOutlookを取得できない場合は、Outlookとツールが同じWindowsユーザー・権限で動いているか確認してください。必要なpywin32はrequirements-build.txtに加えてrequirements.txtにもWindows用依存として指定しました。

図解ガイドは18ページのままメール設定2ページを更新し、Microsoft連携ガイドにも取得手順を追加しました。前版の勤怠・社員情報・メール重複防止の修正を継承します。
'''
validation='''# Trial63 検証結果

関連6テストスクリプト・81テストが成功しました。

- 新規14テスト: Windows以外の案内、アカウント読取、複数/重複アカウント、Exchange SMTPとMAPIプロパティの補完、Outlook未起動、セッション異常、SMTPなし、UIへの反映・保存、複数選択・取消、取得失敗時の保持、差出人名欠損、設定キャンセル。
- 既存67テスト: 設定・JSON・未知拡張保持、メール下書き/送信の代替API、自動送信ON/OFF、UI、マニュアル・配布。
- ライト/ダーク × 通常1060px/最小780pxの4レイアウトで、メール設定の横スクロールが不要なことを確認。
- PDF/HTMLは18ページを維持し、メール設定の実UI画像と説明を更新。ローカル参照・画像をマニュアル試験で確認。
- 完全版と必要ファイル版の実行用ソース同一、ZIP CRCと全ファイルSHA256を検証。

実行環境: Linux / Python3.12 / PySide6 / Qt offscreen。COMとGraphは模擬オブジェクト/関数を使用し、実データ・実アカウントの読取・認証・メール送信を行っていません。Windows実機のクラシックOutlook接続・EXEビルドは未検証です。前版Trial62の49本成功記録は履歴として保持し、今回は変更に関係する6本を検証しました。
'''
for name,content in [('CHANGES_TRIAL63.md',changes),('VALIDATION_TRIAL63.md',validation)]:
 (app/name).write_text(content);(dest/name).write_text(content)
p=app/'README.md';p.write_text('''# 勤怠チェッカー Trial63

「設定」→「メール」→「起動中のOutlookから取得」で、WindowsのクラシックOutlookのメールアドレス・表示名を入力できます。複数アカウントは選択し、「設定を保存」で確定。取得時にメールは作成・送信しません。

CHANGES_TRIAL63.md / VALIDATION_TRIAL63.mdを参照。MicrosoftアプリID等は別設定で、下書き・送信はMicrosoft Graph経由です。関連6本・81テスト成功、Windows実機の接続は未検証。ソース版でEXEは含みません。図解：Manual/index.html。

以下は過去版の説明です。

'''+p.read_text())
(full/'CODEX_START_HERE.txt').write_text('最新版Trial63。クラシックOutlook起動中のアカウント取得をメール設定に追加。メールアドレスと表示名のみ取得し、設定保存で確定。送信は引き続きMicrosoft Graph。CHANGES_TRIAL63.md / VALIDATION_TRIAL63.md / TestEvidence/Trial63参照。次版Trial64。\n派遣元CSVの勤怠読込は未実装。社員情報CSVとは別仕様。\n')
(full/'CODEX_NEXT_TASKS.txt').write_text('次版Trial64。Windows実機でクラシックOutlookのアカウント取得を確認。COMのGetActiveObjectのみ利用し、新しいOutlookからの取得・Outlookの新規起動はしない。Microsoft Graph実認証/送信とEXEビルドは未検証。\n')
with (full/'CODEX_HANDOFF_SPEC.txt').open('a') as f:f.write('\n\n【Trial63：現在の追加仕様】\n'+changes+'\n'+validation)
evidence=app/'TestEvidence/Trial63';evidence.mkdir(exist_ok=True)
for p in out.iterdir():
 if p.is_file() and p.suffix in ('.log','.json','.py','.png'):shutil.copy2(p,evidence/p.name)
shutil.copy2(out/'outlook-account-settings.png',dest/'Trial63_Outlook_Account_Settings.png')
shutil.copy2(app/'Manual/操作マニュアル.pdf',dest/'AttendSync_Trial63_図解操作ガイド.pdf')
for p in full.rglob('__pycache__'):shutil.rmtree(p)
assert not list(full.rglob('userdata'))
essential=base/'AttendSync_Trial63_Essentials';runtime=essential/'AttendSync';runtime.mkdir(parents=True)
for p in app.glob('*.py'):
 if not p.name.startswith(('test_','benchmark_')):shutil.copy2(p,runtime/p.name)
for p in app.glob('requirements*.txt'):shutil.copy2(p,runtime/p.name)
shutil.copy2(app/'AttendSync.ico',runtime/'AttendSync.ico');shutil.copytree(app/'Manual',runtime/'Manual')
(runtime/'README.md').write_text('''# 勤怠チェッカー Trial63 必要ファイル版

Windows11 / Python3.11推奨のソース版。実行・ビルド用ソース、アイコン、18ページ図解です。実データ・テスト・サンプル・EXEは含みません。

PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\\.venv\\Scripts\\python.exe -m pip install -r requirements-build.txt
.\\.venv\\Scripts\\python.exe main.py
.\\.venv\\Scripts\\python.exe build_onedir.py
```

配布はdist\\AttendSync全体。旧userdataはバックアップ後に引き継ぎます。

最初に「社員情報」で社員CSVを選択・ドロップし「一覧に反映」→「社員情報を登録」。初期列はスタッフID=A、社員ID=B、氏名=C、メール=J。その後メインで勤怠を読み込みます。

「設定」→「メール」の「起動中のOutlookから取得」はWindowsのクラシックOutlookからアドレス・表示名だけを入力します。複数アカウントは選択、「設定を保存」で確定。メールの作成・送信はMicrosoft Graph経由のため、アプリID・テナントID設定と初回サインインが別途必要です。取得操作では送信しません。自動送信の初期値はOFFです。

図解：Manual/index.html。初回接続：Manual/Microsoft連携ガイド.html。関連6本・81テスト成功。Windows実機のOutlook接続・実認証/送信・EXEビルドは未検証です。
''')
for p in runtime.glob('*.py'):assert p.read_bytes()==(app/p.name).read_bytes()
checks=[]
for root in (full,essential):
 manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and p.name!='MANIFEST_SHA256.json'}
 (root/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));path=dest/(root.name+'.zip')
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,root.name+'/'+p.relative_to(root).as_posix())
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for name,digest in manifest.items():assert hashlib.sha256(z.read(root.name+'/'+name)).hexdigest()==digest
 sha=hashlib.sha256(path.read_bytes()).hexdigest();path.with_suffix('.zip.sha256').write_text(sha+'  '+path.name+'\n');checks.append(dict(file=path.name,bytes=path.stat().st_size,sha256=sha,crc='OK',manifest='OK'))
(out/'package_check.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
p=dest/'README.md';p.write_text('''# 勤怠チェッカー Trial63 — クラシックOutlookから設定を取得

- [必要ファイル版ZIP](https://github.com/alz7485/codex3/raw/refs/heads/main/downloads/AttendSync/AttendSync_Trial63_Essentials.zip)
- [完全版ZIP](https://github.com/alz7485/codex3/raw/refs/heads/main/downloads/AttendSync/AttendSync_Trial63_Outlook_Account_Complete.zip)
- [取得ボタンの画面](Trial63_Outlook_Account_Settings.png) / [変更内容](CHANGES_TRIAL63.md) / [検証](VALIDATION_TRIAL63.md) / [図解18ページ](AttendSync_Trial63_図解操作ガイド.pdf)
- [社員登録サンプルCSV](AttendSync_Employee_Registration_Sample.csv) / [説明付きZIP](AttendSync_Employee_Registration_Sample.zip)

「設定」→「メール」→「起動中のOutlookから取得」でメールアドレス・表示名を入力。複数アカウントは選択し、保存で確定します。送信は引き続きMicrosoft Graph経由でアプリID等が必要です。関連6本・81テスト成功。Windows実機のOutlook接続は未検証。ソース版でEXEは未同梱です。

以下は過去版の説明です。

'''+p.read_text())
