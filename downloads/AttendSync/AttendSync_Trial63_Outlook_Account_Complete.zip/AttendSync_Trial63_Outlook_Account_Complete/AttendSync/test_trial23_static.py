from pathlib import Path
s=Path(__file__).with_name('main.py').read_text(encoding='utf-8')
assert 'pool.shutdown(wait=True, cancel_futures=self.isInterruptionRequested())' in s
assert 'pool.shutdown(wait=not self.isInterruptionRequested()' not in s
assert s.index("if stats.get('cancelled'):",s.index('    def read_done(')) < s.index('self.read_diagnostics={',s.index('    def read_done('))
assert "export_btn=button('診断を保存','save')" in s
print('trial23 worker/diagnostics static checks OK')
