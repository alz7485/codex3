"""120人サンプルの一括照合・キャッシュ速度・内容検証。WindowsもPython 3.11で可。"""
from pathlib import Path
from collections import Counter
from time import perf_counter
import json, tempfile
from engine import DEFAULT,Cache,xlsx_read,csv_read,reconcile

base=Path(__file__).resolve().parent/'SampleData_120'
expected=json.loads((base/'期待結果.json').read_text(encoding='utf-8'))
files_x=sorted(base.glob('*.xlsx'));files_c=sorted(base.glob('*.csv'))
assert len(files_x)==120 and len(files_c)==2, (len(files_x),len(files_c))

def run(cache,tag):
    start=perf_counter();hits=0
    xdata={};cdata=[]
    for path in files_x:
        packet,cached=cache.parse(path,tag+':xlsx',lambda p:xlsx_read(p,DEFAULT));hits+=cached
        assert not packet.get('error'), (path.name,packet.get('error'))
        assert len(packet['records'])==30,(path.name,len(packet['records']))
        eid=packet['info']['employee']
        assert eid not in xdata,eid
        xdata[eid]=packet
    for path in files_c:
        packet,cached=cache.parse(path,tag+':csv',lambda p:csv_read(p,DEFAULT));hits+=cached
        assert not packet.get('warnings'),packet['warnings']
        cdata.extend(packet['records'])
    mapping=expected['id_mapping']
    rows,issues=reconcile(xdata,cdata,mapping,DEFAULT)
    counts=Counter(r['status'] for r in rows)
    assert len(cdata)==3600,len(cdata)
    assert counts==Counter({'一致':10797,'不一致':3}),counts
    assert not issues,issues[:3]
    found={(r['employee'],r['date'],r['field']) for r in rows if r['status']=='不一致'}
    anticipated={(m['employee'],m['date'],m['field']) for m in expected['mismatches']}
    assert found==anticipated,(found,anticipated)
    took=perf_counter()-start
    print(f'{tag}: {len(files_x)} XLSX + {len(files_c)} CSV, cache_hits={hits}/122, elapsed={took:.2f}s; 一致={counts["一致"]} 不一致={counts["不一致"]}')
    return took

with tempfile.TemporaryDirectory(prefix='attendsync_bench_') as temp:
    cache=Cache(Path(temp)/'bench.sqlite')
    cold=run(cache,'trial12-120')
    warm=run(cache,'trial12-120')
    cache.close()
print('PASS: 120人、3600勤怠日、10800照合、3不一致、キャッシュ再利用')
