from __future__ import annotations

def parse_stable_file(parser, path, cfg):
    """Reject any source modified while it was being parsed.

    A successful return is only trusted when both size and nanosecond mtime
    remain unchanged across the parse. Exceptions are handled by ReadWorker.
    """
    before = path.stat()
    result = parser(path, cfg)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        return {'error': '解析中に元ファイルが更新されました。保存完了後に再読み込みしてください。'}
    return result


