"""Regression cases for the six independently reproduced Trial49 defects."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import ast, copy, json, sqlite3, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from PySide6.QtWidgets import QApplication, QDialog
from PySide6.QtCore import QCoreApplication, QEvent
import runtime_paths
TEMP = tempfile.TemporaryDirectory()
with patch.object(runtime_paths, 'get_data_dir', return_value=Path(TEMP.name)):
    import main
import engine, printing
APP = QApplication.instance() or QApplication([])
APP.setQuitOnLastWindowClosed(False)

class RegressionTests(unittest.TestCase):
    def test_same_name_requires_manual_assignment_in_both_orders(self):
        for order in [('E1', 'E2'), ('E2', 'E1')]:
            employees={eid:{'info':{'name':'同姓 同名'}} for eid in order}
            mapping={}
            pending=engine.candidates(employees,[{'name':'同姓同名','staff':'S1'}],mapping)
            self.assertEqual(mapping,{})
            self.assertEqual({item[0] for item in pending},set(order))
        mapping={}
        engine.candidates({'E1':{'info':{'name':'一意'}}},[{'name':'一意','staff':'S1'}],mapping)
        self.assertEqual(mapping,{'E1':'S1'})
        mapping={'E1':'S1'}
        pending=engine.candidates({'E1':{'info':{'name':'同名'}},'E2':{'info':{'name':'同名'}}},[{'name':'同名','staff':'S2'}],mapping)
        self.assertEqual(mapping,{'E1':'S1'})
        self.assertEqual(pending[0][0],'E2')

    def test_cache_write_failure_preserves_parsed_records(self):
        with tempfile.TemporaryDirectory() as directory:
            folder=Path(directory); db=folder/'cache.sqlite'
            (folder/'valid.csv').write_text('date,calendar,x,staff,name,x,x,x,x,x,start,end,work,break\n20261001,0,,123,TEST,,,,,,09:00,18:00,08:00,01:00\n')
            cache=engine.Cache(db)
            cache.db.execute("CREATE TRIGGER deny_insert BEFORE INSERT ON cache BEGIN SELECT RAISE(FAIL, 'disk failure'); END")
            cache.db.commit();cache.close()
            with patch.object(main,'DB',db):
                worker=main.ReadWorker(folder,engine.DEFAULT);results=[]
                worker.result.connect(lambda *args:results.append(args));worker.run()
            self.assertEqual(len(results[0][1]),1)
            self.assertEqual(results[0][3]['files_failed'],0)
            self.assertTrue(results[0][3]['read_warnings'])

    def test_corrupt_cache_structure_reparses_source(self):
        with tempfile.TemporaryDirectory() as directory:
            folder=Path(directory); db=folder/'cache.sqlite'
            (folder/'valid.csv').write_text('date,calendar,x,staff,name,x,x,x,x,x,start,end,work,break\n20261001,0,,123,TEST,,,,,,09:00,18:00,08:00,01:00\n')
            def read():
                with patch.object(main,'DB',db):
                    worker=main.ReadWorker(folder,engine.DEFAULT);results=[]
                    worker.result.connect(lambda *args:results.append(args));worker.run()
                return results[0]
            self.assertEqual(len(read()[1]),1)
            for packet in [{'records':None},{'records':[None]},{'records':[{'date':1}]},{'records':[],'warnings':None}]:
                with sqlite3.connect(db) as connection:
                    connection.execute('UPDATE cache SET data=?',(json.dumps(packet),))
                result=read()
                self.assertEqual(len(result[1]),1)
                self.assertEqual(result[3]['parsed'],1)
                self.assertNotIn('fatal_error',result[3])
            self.assertEqual(read()[3]['cache_hits'],1)

    def test_employee_duplicate_rejected_even_when_first_unlinked(self):
        from employee_information import validate_information_rows
        for ids in [[('E1',''),('E1','S1')],[('E1','S1'),('E1','')]]:
            with self.assertRaisesRegex(ValueError,'重複'):
                validate_information_rows([(eid,sid,'','') for eid,sid in ids])

    def test_settings_theme_applies_only_after_successful_save(self):
        window=main.Window()
        try:
            window.is_dark=False;window.cfg['theme']='light'
            updated=copy.deepcopy(window.cfg);updated['theme']='dark'
            dialog=SimpleNamespace(exec=lambda:True,value=updated,deleteLater=Mock())
            with patch.object(main,'SettingsDialog',return_value=dialog):window.edit_settings()
            self.assertTrue(window.is_dark)
            self.assertEqual(window.btn_theme.text(),'ライト表示')
            self.assertEqual(json.loads(main.CONFIG.read_text())['theme'],'dark')
            before=copy.deepcopy(window.cfg);updated=copy.deepcopy(before);updated['theme']='light'
            dialog.value=updated
            with patch.object(main,'SettingsDialog',return_value=dialog),patch.object(main,'save_json',side_effect=OSError('denied')),patch.object(main.QMessageBox,'warning'):
                window.edit_settings()
            self.assertTrue(window.is_dark);self.assertEqual(window.cfg,before)
        finally:window.close();window.deleteLater()

    def test_print_cancel_and_error_release_dialogs(self):
        parent=QDialog()
        try:
            for outcome in [QDialog.Rejected,QDialog.Accepted]:
                for _ in range(4):
                    with patch.object(printing.QPrinterInfo,'availablePrinters',return_value=[Mock()]),patch.object(printing.QPrintDialog,'exec',return_value=outcome),patch.object(printing,'render_document',side_effect=RuntimeError('printer failed')),patch.object(printing.QMessageBox,'warning'):
                        printing.print_html(parent,'<p>test</p>')
                    APP.processEvents();QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
                    self.assertEqual(parent.findChildren(QDialog),[])
        finally:parent.deleteLater()

if __name__=='__main__':
    unittest.main()
