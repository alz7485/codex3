# AttendSync Trial 11 変更点

- `main.py`：詳細対比表に、設定から追加した照合項目を自動表示。照合結果との対応を表示名ではなく XLSX/CSV キーで判定。詳細のセル移動は選択行を必須に変更。一覧のExcel移動もキーで照合。
- `engine.py`：通常の比較結果に `xlsx_key` / `csv_key` を保持。
- `test_comparison_extensions.py`：追加比較項目の実データ回帰テストを追加。
- その他の既存ファイルはTrial10から引き継ぎ。

## 未検証

- Windows環境でのExcel COM/印刷操作
- Windows GUIの実画面のレイアウト
- 120人分の読み込み性能

元データは読み取り専用。EXE化は `build_onedir.py` を実行してください。
