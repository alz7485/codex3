# Trial34 検証報告

環境: Linux-6.18.44-x86_64-with-glibc2.41
Python: 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]
PySide6 6.12.0 / openpyxl 3.1.5 / offscreen

25本のテストスクリプト全合格。新規の実Qt設定テスト27件全合格。
全Python構文検査合格。

| スクリプト | 結果 | 秒 |
|---|---|---|
| test_120_performance.py | PASS | 1.35 |
| test_cache_tags.py | PASS | 0.08 |
| test_comparison_extensions.py | PASS | 0.15 |
| test_coverage_trial16.py | PASS | 1.12 |
| test_engine.py | PASS | 0.11 |
| test_excel_jump.py | PASS | 0.02 |
| test_final_validation.py | PASS | 0.09 |
| test_month_spacers_trial19.py | PASS | 0.13 |
| test_sample_integration.py | PASS | 0.2 |
| test_stable_read.py | PASS | 0.02 |
| test_trial15.py | PASS | 0.1 |
| test_trial21.py | PASS | 0.09 |
| test_trial22_static.py | PASS | 0.02 |
| test_trial23_static.py | PASS | 0.02 |
| test_trial24_integrity.py | PASS | 0.02 |
| test_trial27_toggle_static.py | PASS | 0.02 |
| test_trial28_input_review.py | PASS | 0.09 |
| test_trial29_completion.py | PASS | 0.04 |
| test_trial30_dynamic_failures.py | PASS | 0.19 |
| test_trial31_excel_mock.py | PASS | 0.1 |
| test_trial32_gui_print.py | PASS | 1.28 |
| test_trial32_sessions_mapping.py | PASS | 6.86 |
| test_trial33_ui.py | PASS | 5.18 |
| test_trial34_settings.py | PASS | 6.79 |
| test_ui_static.py | PASS | 0.05 |

## 重点確認

- DEFAULTの保存・再表示で設定値とキーを変更しない。キャンセルと失敗時に入力元を変更しない。
- 未知の設定や照合行属性、独自形式・文字コード、月別シートの追加メタデータを保持。
- 読み込み項目の追加・改名・削除、対応元変更後も内部識別子と詳細表示を保持。
- XLSX/CSVに各8項目を追加し、780×580で配置・保存・再表示を確認。
- 不正なJSON内部構造10種類などを事前に検出し、設定と入力欄を壊さない。
- Excel列XFD・行1,048,576の上限、必須・任意欄、重複コードと新規の重複照合名、エラー位置への誘導。
- 数値0・False・空欄を正しく区別し、詳細表示で文字列値を時刻へ変換しない。
- 合成Excel/CSV：追加の列V/Oで2:00対2:30を不一致、列W/Pと名称を変更して3:00対3:00を一致と判定。
- 追加ダイアログを実操作し、保存・再表示・追加属性の保持を確認。
- ライト／ダークの画面画像を取得・目視確認。

## 結果抜粋

```
trial12-120: 120 XLSX + 2 CSV, cache_hits=0/122, elapsed=1.15s; 一致=10797 不一致=3
trial12-120: 120 XLSX + 2 CSV, cache_hits=122/122, elapsed=0.10s; 一致=10797 不一致=3
PASS: 120人、3600勤怠日、10800照合、3不一致、キャッシュ再利用
```

```
...........................
----------------------------------------------------------------------
Ran 27 tests in 6.496s

OK
```

## 検証範囲

過去の静的検査は静的検査として扱っています。COMとネイティブ印刷の一部はモックで検証。Windows実機・Office/Excel・物理プリンタ・onedir EXE起動・高DPI・会社ネットワーク性能は未検証。
Linuxの実Qtオフスクリーン画像はWindows実機合格を示すものではありません。
