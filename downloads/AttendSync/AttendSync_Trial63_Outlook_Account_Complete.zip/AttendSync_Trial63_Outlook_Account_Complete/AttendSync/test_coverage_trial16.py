from collections import Counter
from pathlib import Path
from engine import DEFAULT,xlsx_read,csv_read,coverage_report
import json
base=Path(__file__).resolve().parent/'SampleData_120'
expected=json.loads((base/'期待結果.json').read_text(encoding='utf-8'))
xdata={}
for p in base.glob('*.xlsx'):
    packet=xlsx_read(p,DEFAULT)
    assert not packet.get('error')
    xdata[packet['info']['employee']]=packet
cdata=[]
for p in base.glob('*.csv'):
    cdata+=csv_read(p,DEFAULT)['records']
report=coverage_report(xdata,cdata,expected['id_mapping'],DEFAULT)
assert report['complete'],report['review'][:3]
assert report['expected_employee_days']==3600
assert report['xlsx_days_present']==3600 and report['csv_days_present']==3600
bad=coverage_report(xdata,cdata[1:],expected['id_mapping'],DEFAULT)
assert not bad['complete'] and any(g['reason']=='CSV記録なし' for g in bad['review'])
one=next(iter(xdata)); missing=dict(xdata);missing[one]=dict(xdata[one]);missing[one]['records']=missing[one]['records'][1:]
bad2=coverage_report(missing,cdata,expected['id_mapping'],DEFAULT)
assert not bad2['complete'] and any(g['reason']=='XLSX記録なし' for g in bad2['review'])
print('PASS Trial16: 3600日整合、CSV欠落、XLSX欠落を検出')
