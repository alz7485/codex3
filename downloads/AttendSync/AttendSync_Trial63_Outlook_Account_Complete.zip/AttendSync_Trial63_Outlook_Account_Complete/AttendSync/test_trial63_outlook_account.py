"""Classic Outlook identity reads and settings UI; all COM access is mocked."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import sys,copy,types,unittest
from unittest.mock import patch
from types import SimpleNamespace as NS
import classic_outlook as subject
from engine import DEFAULT
from outlook_mail import DEFAULT_MAIL_SETTINGS
from PySide6.QtWidgets import QApplication,QWidget,QDialog
from settings_dialog import SettingsDialog

class Collection:
 def __init__(self,items):self.items=items;self.Count=len(items)
 def Item(self,index):
  item=self.items[index-1]
  if isinstance(item,Exception):raise item
  return item

class OutlookAccount63(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
 def setUp(self):
  self.parent=QWidget();self.parent.is_dark=False;self.dialogs=[]
  self.addCleanup(self.clean)
 def clean(self):
  for dialog in self.dialogs:dialog.close();dialog.deleteLater()
  self.parent.close();self.parent.deleteLater();self.app.processEvents()
 def dialog(self):
  self.cfg=copy.deepcopy(DEFAULT);self.cfg['mail_settings']={**DEFAULT_MAIL_SETTINGS,'account':'old@example.com','sender_name':'Old','always_cc':'cc@example.com','client_id':'11111111-1111-1111-1111-111111111111','future_rule':{'keep':1}}
  d=SettingsDialog(self.parent,self.cfg);self.dialogs.append(d);return d
 def read(self,items=None,error=None,outlook=None):
  calls=[];com=types.ModuleType('pythoncom');com.CoInitialize=lambda:calls.append('initialize');com.CoUninitialize=lambda:calls.append('uninitialize')
  client=types.ModuleType('win32com.client')
  def active(name):
   calls.append(name)
   if error:raise error
   return outlook or NS(Session=NS(Accounts=Collection(items or [])))
  client.GetActiveObject=active
  parent=types.ModuleType('win32com');parent.__path__=[];parent.client=client
  with patch.object(subject.sys,'platform','win32'),patch.dict(sys.modules,{'pythoncom':com,'win32com':parent,'win32com.client':client}):
   try:return subject.running_outlook_accounts(),calls
   finally:self.last_calls=calls
 def test_non_windows_is_reported(self):
  with patch.object(subject.sys,'platform','linux'),self.assertRaisesRegex(RuntimeError,'Windows'):subject.running_outlook_accounts()
 def test_single_identity_uses_current_user_display_name(self):
  accounts,calls=self.read([NS(SmtpAddress=' person@example.com ',DisplayName='Mailbox',CurrentUser=NS(Name='User\r\n Name'))])
  self.assertEqual(accounts,[{'account':'person@example.com','sender_name':'User Name'}]);self.assertEqual(calls,['initialize','Outlook.Application','uninitialize'])
 def test_multiple_deduplicate_case_and_skip_bad_individual_account(self):
  accounts,_=self.read([RuntimeError('bad item'),NS(SmtpAddress='a@example.com',DisplayName='A'),NS(SmtpAddress='A@example.com',DisplayName='duplicate'),NS(SmtpAddress='b@example.com',DisplayName='B'),NS(SmtpAddress='invalid')])
  self.assertEqual([r['account'] for r in accounts],['a@example.com','b@example.com'])
 def test_exchange_primary_smtp_fallback(self):
  entry=NS(GetExchangeUser=lambda:NS(PrimarySmtpAddress='exchange@example.com'))
  result,_=self.read([NS(SmtpAddress='/o=Exchange/ou=invalid',CurrentUser=NS(Name='Exchange User',AddressEntry=entry))])
  self.assertEqual(result,[{'account':'exchange@example.com','sender_name':'Exchange User'}])
 def test_smtp_property_fallback(self):
  calls=[]
  def prop(tag):calls.append(tag);return 'property@example.com'
  entry=NS(PropertyAccessor=NS(GetProperty=prop))
  result,_=self.read([NS(CurrentUser=NS(Name='User',AddressEntry=entry))]);self.assertEqual(result[0]['account'],'property@example.com');self.assertEqual(len(calls),1)
 def test_no_running_outlook_does_not_start_an_instance(self):
  with self.assertRaisesRegex(RuntimeError,'起動中'):self.read(error=OSError('not running'))
  self.assertEqual(self.last_calls,['initialize','Outlook.Application','uninitialize'])
 def test_bad_session_is_reported_and_com_is_released(self):
  with self.assertRaisesRegex(RuntimeError,'アカウント情報'):self.read(outlook=NS())
  self.assertEqual(self.last_calls[-1],'uninitialize')
 def test_empty_or_invalid_accounts_preserve_clear_error(self):
  for items in ([],[NS(SmtpAddress='bad')]):
   with self.assertRaisesRegex(RuntimeError,'有効なメールアドレス'):self.read(items)
   self.assertEqual(self.last_calls[-1],'uninitialize')
 def test_ui_single_account_save_only_replaces_identity(self):
  d=self.dialog();before=copy.deepcopy(self.cfg)
  with patch.object(subject,'running_outlook_accounts',return_value=[{'account':'new@example.com','sender_name':'New Name'}]):d.outlook_account_button.click()
  self.assertEqual(self.cfg,before);self.assertTrue(d.outlook_account_button.isEnabled());self.assertIn('設定を保存',d.outlook_account_status.text())
  d.accept();self.assertEqual(d.result(),QDialog.Accepted,d.error_label.text());saved=d.value['mail_settings']
  self.assertEqual(saved,{**before['mail_settings'],'account':'new@example.com','sender_name':'New Name'})
 def test_ui_multiple_accounts_require_selection(self):
  d=self.dialog();accounts=[{'account':'one@example.com','sender_name':'One'},{'account':'old@example.com','sender_name':'Two'}]
  choices=['One <one@example.com>','Two <old@example.com>']
  with patch.object(subject,'running_outlook_accounts',return_value=accounts),patch('settings_dialog.QInputDialog.getItem',return_value=(choices[1],True)) as select:d.outlook_account_button.click()
  self.assertEqual(select.call_args.args[4],1);self.assertEqual(select.call_args.args[3],choices);self.assertFalse(select.call_args.args[5])
  self.assertEqual(d.mail_controls['sender_name'].text(),'Two')
 def test_account_selection_cancel_keeps_existing_values(self):
  d=self.dialog();before={k:e.text() for k,e in d.mail_controls.items() if hasattr(e,'text')}
  with patch.object(subject,'running_outlook_accounts',return_value=[{'account':'one@example.com','sender_name':'One'},{'account':'two@example.com','sender_name':'Two'}]),patch('settings_dialog.QInputDialog.getItem',return_value=('',False)):d.outlook_account_button.click()
  self.assertEqual({k:e.text() for k,e in d.mail_controls.items() if hasattr(e,'text')},before);self.assertTrue(d.outlook_account_button.isEnabled())
 def test_get_failure_keeps_identity_and_reenables_button(self):
  d=self.dialog()
  with patch.object(subject,'running_outlook_accounts',side_effect=RuntimeError('取得エラー')),patch('settings_dialog.QMessageBox.warning') as warning:d.outlook_account_button.click()
  self.assertEqual(d.mail_controls['account'].text(),'old@example.com');self.assertEqual(d.mail_controls['sender_name'].text(),'Old');self.assertTrue(d.outlook_account_button.isEnabled());self.assertIn('取得エラー',warning.call_args.args[2])
 def test_missing_display_name_keeps_manual_sender_name(self):
  d=self.dialog()
  with patch.object(subject,'running_outlook_accounts',return_value=[{'account':'new@example.com','sender_name':''}]):d.outlook_account_button.click()
  self.assertEqual(d.mail_controls['sender_name'].text(),'Old');self.assertIn('差出人名を確認',d.outlook_account_status.text())
 def test_cancel_settings_does_not_modify_input(self):
  d=self.dialog();before=copy.deepcopy(self.cfg)
  with patch.object(subject,'running_outlook_accounts',return_value=[{'account':'new@example.com','sender_name':'New'}]):d.outlook_account_button.click()
  d.reject();self.assertEqual(d.result(),QDialog.Rejected);self.assertEqual(self.cfg,before);self.assertFalse(hasattr(d,'value'))

if __name__=='__main__':unittest.main()
