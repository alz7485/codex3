from pathlib import Path
from excel_jump import source_cell_for
sample={"file":str(Path("SampleData/社員_10001.xlsx").resolve()),"sheet":"10月","row":12}
p,sh,cell=source_cell_for(sample,"H")
assert p.exists() and sh=="10月" and cell=="H12"
for bad in ('H1','A:Z',''):
    try: source_cell_for(sample,bad)
    except ValueError: pass
    else: raise AssertionError(f'bad column accepted: {bad}')
print('PASS: XLSX元セル番地・不正列検出')
