"""Final audit: extension identities and atomic settings validation."""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

os.environ.setdefault('QT_QPA_PLATFORM','offscreen')

from PySide6.QtWidgets import QApplication, QDialog, QWidget
from engine import DEFAULT
from settings_dialog import SettingsDialog, SettingsError


class FinalSettingsAudit(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])

    def setUp(self):
        self.parent=QWidget();self.parent.is_dark=False
        self.dialogs=[]
        self.addCleanup(self.clean_up)

    def clean_up(self):
        for dialog in self.dialogs:
            dialog.close();dialog.deleteLater()
        self.parent.close();self.parent.deleteLater();self.app.processEvents()

    def dialog(self,cfg=None):
        dialog=SettingsDialog(self.parent,copy.deepcopy(DEFAULT) if cfg is None else cfg)
        self.dialogs.append(dialog)
        return dialog

    def test_generated_field_does_not_overwrite_reserved_extension_identity(self):
        cfg=copy.deepcopy(DEFAULT)
        cfg['field_labels']={
            'xlsx_columns':{'custom_001':'将来のXLSX項目'},
            'csv_columns':{'custom_002':'将来のCSV項目'},
            'future_source':{'custom_003':'将来の別ソース'},
        }
        future_rule=dict(name='将来の照合',xlsx='custom_004',csv='custom_005',
                         type='text',enabled=False,future={'preserve':[1,2]})
        cfg['comparisons'].append(future_rule)
        cfg['detail_visible_fields']=['start|start','custom_006|custom_007',
                                      'None|custom_008','custom_009|']
        cfg['future_plugin']={'metadata':['keep',17]}
        before=copy.deepcopy(cfg);dialog=self.dialog(cfg)
        reserved={f'custom_{number:03d}' for number in range(1,10)}
        key=dialog.add_source_field('xlsx_columns','今追加する別項目','V')
        self.assertIsInstance(key,str);self.assertNotIn(key,reserved)
        dialog.accept();self.assertEqual(dialog.result(),QDialog.Accepted,dialog.error_label.text())
        saved=dialog.value
        for source,labels in before['field_labels'].items():
            for field,label in labels.items():self.assertEqual(saved['field_labels'][source][field],label)
        self.assertEqual(saved['comparisons'][-1],future_rule)
        self.assertEqual(saved['detail_visible_fields'],before['detail_visible_fields'])
        self.assertEqual(saved['future_plugin'],before['future_plugin'])
        self.assertEqual(cfg,before)
        reopened=self.dialog(saved)
        next_key=reopened.add_source_field('csv_columns','さらに別の項目','O')
        self.assertNotIn(next_key,reserved|{key})

    def test_current_unsaved_comparison_references_reserve_ids(self):
        dialog=self.dialog()
        dialog.add_compare(dict(name='後で列を追加',xlsx='custom_001',csv='custom_002',
                                type='text',enabled=False))
        key=dialog.add_source_field('xlsx_columns','別の追加項目','V')
        self.assertNotIn(key,{'custom_001','custom_002'})
        self.assertEqual(dialog._comparison_values()[-1]['xlsx'],'custom_001')
        self.assertEqual(dialog._comparison_values()[-1]['csv'],'custom_002')

    def test_ambiguous_column_ids_are_rejected_before_any_form_change(self):
        base=copy.deepcopy(DEFAULT);base['future_plugin']={'keep':['metadata']}
        dialog=self.dialog(base)
        entries_before=[(source,key,edit.text()) for source,key,edit in dialog.entries]
        for source,column in [('xlsx_columns','V'),('csv_columns','O'),('info_cells','V1')]:
            with self.subTest(source=source):
                invalid=copy.deepcopy(base);invalid[source]['a|b']=column
                dialog.advanced.setPlainText(json.dumps(invalid,ensure_ascii=False))
                self.assertFalse(dialog.apply_json_to_form())
                self.assertIn('|',dialog.error_label.text())
                self.assertEqual(dialog._base,base)
                self.assertEqual([(s,k,e.text()) for s,k,e in dialog.entries],entries_before)
                dialog.accept();self.assertEqual(dialog.result(),QDialog.Rejected)
                self.assertFalse(hasattr(dialog,'value'))
        self.assertEqual(base['future_plugin'],{'keep':['metadata']})

    def test_disabled_comparison_cannot_import_ambiguous_source_id(self):
        dialog=self.dialog();before=copy.deepcopy(dialog._base)
        invalid=copy.deepcopy(before)
        invalid['comparisons'].append(dict(name='後日有効にする照合',xlsx='a|b',csv='future_csv',
                                           type='text',enabled=False))
        dialog.advanced.setPlainText(json.dumps(invalid,ensure_ascii=False))
        self.assertFalse(dialog.apply_json_to_form());self.assertEqual(dialog._base,before)
        self.assertIn('|',dialog.error_label.text())

    def test_direct_form_save_rejects_ambiguous_existing_id(self):
        cfg=copy.deepcopy(DEFAULT);cfg['xlsx_columns']['a|b']='V'
        before=copy.deepcopy(cfg);dialog=self.dialog(cfg)
        dialog.accept();self.assertEqual(dialog.result(),QDialog.Rejected)
        self.assertIn('|',dialog.error_label.text());self.assertEqual(cfg,before)
        self.assertFalse(hasattr(dialog,'value'))

    def test_display_names_can_include_separator_without_changing_identity(self):
        cfg=copy.deepcopy(DEFAULT)
        cfg['comparisons'][0]['name']='始業 | 時刻'
        cfg['field_labels']={'xlsx_columns':{'start':'始業 | 出勤'}}
        cfg['future_plugin']={'free_text':'A | B'}
        dialog=self.dialog()
        dialog.advanced.setPlainText(json.dumps(cfg,ensure_ascii=False))
        self.assertTrue(dialog.apply_json_to_form(),dialog.error_label.text())
        dialog.accept();self.assertEqual(dialog.result(),QDialog.Accepted)
        self.assertEqual(dialog.value,cfg)

    def test_shared_validator_runs_without_a_qt_application(self):
        code='''
import copy
from PySide6.QtWidgets import QApplication
from engine import DEFAULT
from settings_dialog import SettingsDialog,SettingsError
assert QApplication.instance() is None
SettingsDialog.validate_json_config(copy.deepcopy(DEFAULT))
for value in (None, [], 'wrong', 7):
    try: SettingsDialog.validate_json_config(value)
    except SettingsError as exc: assert exc.control is None
    else: raise AssertionError('invalid root accepted')
cfg=copy.deepcopy(DEFAULT);cfg['xlsx_columns']['a|b']='V'
try: SettingsDialog.validate_json_config(cfg)
except SettingsError as exc: assert '|' in str(exc)
else: raise AssertionError('ambiguous ID accepted')
assert QApplication.instance() is None
'''
        result=subprocess.run([sys.executable,'-c',code],cwd=Path(__file__).parent,
                              text=True,capture_output=True,timeout=30)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)

    def test_instance_validator_preserves_gui_error_control(self):
        dialog=self.dialog()
        with self.assertRaises(SettingsError) as caught:dialog._validate_json_config([])
        self.assertIs(caught.exception.control,dialog.advanced)


if __name__=='__main__':unittest.main(verbosity=2)
