"""Final audit regressions for startup, fatal reads, persistence and settings controls."""
import copy,json,tempfile,unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from unittest.mock import patch
from PySide6.QtWidgets import QDialog
import test_trial38_audit as fixture
import main,runtime_paths
from engine import DEFAULT,load_json,save_json,validate_config
from settings_dialog import SettingsError

class RuntimeAudit(unittest.TestCase):
 setUpClass=classmethod(fixture.Audit38.setUpClass.__func__)
 setUp=fixture.Audit38.setUp
 load_results=fixture.Audit38.load_results
 def test_corrupt_or_invalid_settings_reports_failure_and_preserves_original(self):
  invalids=[b'{"year":',b'[]',json.dumps(dict(DEFAULT,year=None)).encode(),json.dumps(dict(DEFAULT,folder=[])).encode(),json.dumps(dict(DEFAULT,info_cells=[])).encode()]
  for raw in invalids:
   with self.subTest(raw=raw[:30]):
    main.CONFIG.write_bytes(raw)
    with patch.object(main.QMessageBox,'critical') as critical:
     self.assertEqual(main.main(),1)
    critical.assert_called_once();self.assertIn(str(main.CONFIG),critical.call_args.args[2]);self.assertEqual(main.CONFIG.read_bytes(),raw)
 def test_invalid_mapping_reports_failure_and_does_not_overwrite(self):
  for data in [[],None,{'10001':['S001']},{'':'S001'},{'10001':True}]:
   with self.subTest(data=data):
    raw=json.dumps(data).encode();main.MAP.write_bytes(raw)
    with patch.object(main.QMessageBox,'critical') as critical:self.assertEqual(main.main(),1)
    self.assertEqual(main.MAP.read_bytes(),raw);self.assertIn(str(main.MAP),critical.call_args.args[2])
 def test_bom_settings_and_mapping_start_normally_and_preserve_extensions(self):
  cfg=copy.deepcopy(DEFAULT);cfg['future_extension']={'keep':9}
  main.CONFIG.write_text(json.dumps(cfg),encoding='utf-8-sig');main.MAP.write_text(json.dumps({'10001':'S001'}),encoding='utf-8-sig')
  window=main.Window();self.addCleanup(window.close)
  self.assertEqual(window.cfg['future_extension'],{'keep':9});self.assertEqual(window.mapping,{'10001':'S001'})
 def test_corrupt_database_reports_failure_and_preserves_completed_results(self):
  self.load_results();old=copy.deepcopy(self.w.results);snapshot=copy.deepcopy(self.w.results_cfg)
  main.DB.write_bytes(b'not a SQLite database')
  self.w.worker=main.ReadWorker(Path(fixture.__file__).parent/'SampleData',self.w.cfg)
  self.w.worker.result.connect(self.w.read_done);self.w.worker.run()
  self.assertEqual(self.w.results,old);self.assertEqual(self.w.results_cfg,snapshot);self.assertIn('読み込み失敗',self.w.status.text());self.assertNotIn('中止',self.w.status.text());self.assertTrue(self.w.read_diagnostics['failures']);self.assertIn('database',self.w.read_diagnostics['failures'][0]['reason']);self.assertIn('失敗 1',self.w.btn_diagnostics.text())
 def test_first_fatal_read_reports_diagnostic_without_inventing_results(self):
  main.DB.write_bytes(b'invalid database')
  self.w.worker=main.ReadWorker(Path(fixture.__file__).parent/'SampleData',self.w.cfg);self.w.worker.result.connect(self.w.read_done);self.w.worker.run()
  self.assertFalse(self.w.results);self.assertIsNone(self.w.results_cfg);self.assertIn('読み込み失敗',self.w.status.text());self.assertTrue(self.w.read_diagnostics['failures'])
 def test_all_comparisons_off_is_explicit_in_status_and_empty_view(self):
  for item in self.w.cfg['comparisons']:item['enabled']=False
  self.load_results()
  self.assertFalse(self.w.results);self.assertIn('照合項目がすべてOFF',self.w.status.text());self.assertIn('照合項目がすべてOFF',self.w.empty_state.findChildren(main.QLabel)[1].text())
 def edit(self,value):
  with patch.object(main,'SettingsDialog') as dialog:
   dialog.return_value.exec.return_value=QDialog.Accepted;dialog.return_value.value=value;self.w.edit_settings()
 def test_json_period_folder_changes_update_controls_but_keep_result_snapshot(self):
  self.load_results();new=copy.deepcopy(self.w.cfg);new.update(year=2027,month=1,folder=self.tmp.name);self.edit(new)
  self.assertEqual((self.w.year.value(),self.w.month.value(),self.w.path.text()),(2027,1,self.tmp.name));self.assertEqual((self.w.results_cfg['year'],self.w.results_cfg['month']),(2026,10));self.assertEqual(load_json(main.CONFIG,{})['year'],2027)
 def test_normal_settings_save_keeps_unsaved_main_controls(self):
  self.w.year.setValue(2027);self.w.month.setValue(1);self.w.path.setText(self.tmp.name)
  new=copy.deepcopy(self.w.cfg);new['read_workers']=2;self.edit(new)
  self.assertEqual((self.w.year.value(),self.w.month.value(),self.w.path.text()),(2027,1,self.tmp.name));self.assertEqual(self.w.cfg['read_workers'],2)
 def test_unknown_enabled_comparison_is_reviewed_without_rewriting_metadata(self):
  cfg=copy.deepcopy(DEFAULT);cfg['comparisons'][0]['type']='future_formula'
  main.SettingsDialog.validate_json_config(cfg);self.assertFalse(validate_config(cfg));self.w.cfg=cfg;self.load_results()
  rows=[r for r in self.w.results if r['field']=='始業時刻'];self.assertTrue(rows);self.assertTrue(all(r['status']=='要確認' for r in rows));self.assertTrue(any('未対応' in issue for issue in self.w.issues));self.assertEqual(self.w.cfg['comparisons'][0]['type'],'future_formula')
  detail=main.DetailDialog(self.w,rows[0],cfg);self.addCleanup(detail.close);self.assertTrue(any('未対応' in values[3] for values in detail.printrows))
  cfg['comparisons'][0]['enabled']=False;self.w.cfg=cfg;self.load_results();self.assertFalse(any(r['field']=='始業時刻' for r in self.w.results));self.assertEqual(cfg['comparisons'][0]['type'],'future_formula')
 def test_unsupported_reserved_type_can_be_preserved_by_normal_form(self):
  cfg=copy.deepcopy(DEFAULT);cfg['comparisons'][0].update(type='future_formula',enabled=False)
  dialog=main.SettingsDialog(self.w,cfg);self.addCleanup(dialog.close)
  dialog.compares.cellWidget(0,0).setChecked(True);dialog.accept()
  self.assertEqual(dialog.result(),QDialog.Accepted);self.assertEqual(dialog.value['comparisons'][0]['type'],'future_formula');self.assertTrue(dialog.value['comparisons'][0]['enabled'])
 def test_folder_stat_permission_error_is_reported_without_mutating_settings(self):
  old=copy.deepcopy(self.w.cfg);self.w.path.setText(self.tmp.name)
  with patch.object(Path,'is_dir',side_effect=PermissionError('denied')),patch.object(main.QMessageBox,'warning') as warning:self.w.run_read()
  warning.assert_called_once();self.assertEqual(self.w.cfg,old);self.assertIsNone(self.w.worker)
 def test_parallel_json_saves_have_unique_temporary_files_and_both_succeed(self):
  path=Path(self.tmp.name)/'parallel.json';barrier=Barrier(2);original=Path.replace;seen=[]
  def synchronized(temporary,destination):
   seen.append(temporary);barrier.wait(timeout=5);return original(temporary,destination)
  with patch.object(Path,'replace',synchronized),ThreadPoolExecutor(max_workers=2) as pool:
   jobs=[pool.submit(save_json,path,{'writer':i,'values':list(range(200))}) for i in (1,2)]
   for job in jobs:job.result(timeout=10)
  self.assertEqual(len(set(seen)),2);self.assertIn(load_json(path,{})['writer'],(1,2));self.assertFalse(list(path.parent.glob('parallel.json.*.tmp')))
 def test_failed_json_serialization_retains_previous_file_and_cleans_temporary(self):
  path=Path(self.tmp.name)/'atomic.json';save_json(path,{'keep':12});before=path.read_bytes()
  with self.assertRaises(TypeError):save_json(path,{'bad':object()})
  self.assertEqual(path.read_bytes(),before);self.assertFalse(list(path.parent.glob('atomic.json.*.tmp')))
 def test_concurrent_startup_write_probes_keep_same_portable_directory(self):
  root=Path(self.tmp.name)/'portable';root.mkdir()
  with patch.object(runtime_paths,'application_dir',return_value=root),ThreadPoolExecutor(max_workers=4) as pool:paths=list(pool.map(lambda _:runtime_paths.get_data_dir(),range(12)))
  self.assertEqual(set(paths),{root/'userdata'});self.assertFalse(list((root/'userdata').iterdir()))

if __name__=='__main__':unittest.main(verbosity=2)
