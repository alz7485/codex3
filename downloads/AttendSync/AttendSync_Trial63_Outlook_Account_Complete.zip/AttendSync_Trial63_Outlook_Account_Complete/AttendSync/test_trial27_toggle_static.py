from pathlib import Path
s=Path(__file__).with_name("main.py").read_text(encoding="utf-8")
for text,value in [('すべて','all'),('ID未紐付け','id'),('メール未紐付け','mail')]:
    assert f"filter_mode.addItem('{text}','{value}')" in s
assert "table.setObjectName('employeeIdTable')" in s
print('PASS unified employee information filter structure')
