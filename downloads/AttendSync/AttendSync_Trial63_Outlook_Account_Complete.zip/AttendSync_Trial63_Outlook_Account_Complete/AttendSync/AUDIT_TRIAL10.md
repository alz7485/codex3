# AttendSync Trial 10 監査記録

## 修正
- runtime_paths.py: LocalAppDataへのフォールバック名を AttendSync に統一。既存の旧名フォルダからの移行は自動では行わないため必要に応じて設定をコピーする。
- main.py: 詳細画面の「Excelの該当セル」ボタンは選択中の項目を参照。未対応項目を始業時刻へ誤誘導しない。
- engine.py / excel_jump.py: 読込時に元XLSXのサイズと更新時刻を保持し、変更されたファイルに対してセルジャンプを保留する。キャッシュタグを更新。

## 実施済み検査
- Python構文チェック
- test_engine.py、test_sample_integration.py、test_excel_jump.py、test_ui_static.py
- サンプルは一致357、不一致3、要確認0。

## 未検証・残課題
- Excel COMによる既存Excelとの相互作用・前面化・印刷はWindows実機試験が必要。
- 120件Excelの読込速度は実ファイル環境で要測定。
- サンプル未網羅: 24時を跨ぐ実データ、部分休暇、設定変更時の全項目、破損ファイル。
- 詳細対比表は固定項目を基本としており、照合項目の自由追加と表示行の完全な同期は未整備。
- Excelが開かれたまま元ファイルが変更されたときは内容が異なる可能性あり。
