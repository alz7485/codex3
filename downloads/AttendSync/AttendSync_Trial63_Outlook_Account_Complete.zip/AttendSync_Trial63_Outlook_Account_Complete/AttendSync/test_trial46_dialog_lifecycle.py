"""Real Qt regression: modal lifetimes, successful saves and failed saves.

Run from the app source directory. ATTENDSYNC_SOURCE_ROOT optionally points
at a separate source checkout during independent review. All user data goes
to TemporaryDirectory; no production settings or mappings are accessed.
"""
import copy,os,sys,tempfile,unittest,json
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
source_root=Path(os.environ.get('ATTENDSYNC_SOURCE_ROOT',Path(__file__).resolve().parent))
sys.path.insert(0,str(source_root))
import runtime_paths
_import_tmp=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(_import_tmp.name)):
 import main
import engine
from PySide6.QtCore import QTimer,QCoreApplication,QEvent,QPoint
from PySide6.QtWidgets import QApplication,QDialog,QWidget,QMenu,QCheckBox
import shiboken6

class Recheck46(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.app=QApplication.instance() or QApplication([]);cls.app.setQuitOnLastWindowClosed(False)
  cls.xdata={};cls.cdata=[]
  for p in (Path(main.__file__).parent/'SampleData').glob('*.xlsx'):
   d=engine.xlsx_read(p,engine.DEFAULT);cls.xdata[d['info']['employee']]=d
  for p in (Path(main.__file__).parent/'SampleData').glob('*.csv'):cls.cdata+=engine.csv_read(p,engine.DEFAULT)['records']
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);base=Path(self.tmp.name)
  p=patch.multiple(main,CONFIG=base/'settings.json',MAP=base/'mapping.json',DB=base/'cache.sqlite3');p.start();self.addCleanup(p.stop)
  with patch.object(main,'current_attendance_month',return_value=(2026,10)):self.w=main.Window()
  self.w.cfg=copy.deepcopy(engine.DEFAULT)
  self.addCleanup(self.dispose)
 def flush(self):
  self.app.processEvents();QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
 def dispose(self):self.w.close();self.w.deleteLater();self.flush()
 def counts(self,parent):return (len(parent.findChildren(QDialog)),len(parent.findChildren(QWidget)))
 def exercise(self,opening,parent=None,callback=None,repeat=3):
  parent=parent or self.w;before=self.counts(parent);seen=[];errors=[]
  for n in range(repeat):
   def act():
    d=self.app.activeModalWidget();seen.append(d)
    try:
     if callback:callback(d,n)
     else:d.reject()
    except Exception as e:errors.append(e)
    finally:
     if shiboken6.isValid(d) and d.isVisible():d.reject()
   QTimer.singleShot(0,act);opening();self.flush()
   self.assertFalse(errors,errors);self.assertEqual(self.counts(parent),before)
   self.assertFalse(shiboken6.isValid(seen[-1]))
 def test_settings_cancel_three_times(self):self.exercise(self.w.edit_settings)
 def test_mapping_cancel_three_times(self):self.exercise(self.w.edit_map)
 def test_diagnostics_cancel_three_times(self):self.exercise(self.w.show_diagnostics)
 def test_logs_cancel_three_times(self):self.exercise(self.w.show_log_window)
 def sample_row(self):
  rows,_=engine.reconcile(self.xdata,self.cdata,{'10001':'S001','10002':'S002','10003':'S003','10004':'S004'},engine.DEFAULT)
  return rows[0]
 def test_detail_cancel_three_times(self):
  with patch.object(self.w,'selected_row',return_value=self.sample_row()):self.exercise(self.w.open_detail)
 def test_detail_fields_save_three_times(self):
  detail=main.DetailDialog(self.w,self.sample_row(),self.w.cfg)
  try:
   def save(d,n):
    checks=d.findChildren(QCheckBox);checks[0].setChecked(False);d.accept()
   self.exercise(detail.edit_visible_fields,parent=detail,callback=save)
   cfg=engine.load_json(main.CONFIG,{})
   self.assertEqual(cfg['detail_visible_fields'],detail.cfg['detail_visible_fields'])
   self.assertNotIn(detail.field_key(detail.detail_fields[0]),cfg['detail_visible_fields'])
  finally:detail.deleteLater();self.flush()
 def test_settings_success_and_failure_three_times(self):
  def save(d,n):d.workers.setValue(5+n);d.accept()
  self.exercise(self.w.edit_settings,callback=save)
  self.assertEqual(self.w.cfg['read_workers'],7);self.assertEqual(engine.load_json(main.CONFIG,{})['read_workers'],7)
  before=copy.deepcopy(self.w.cfg);raw=main.CONFIG.read_bytes()
  with patch.object(main,'save_json',side_effect=PermissionError('locked')),patch.object(main.QMessageBox,'warning') as warn:self.exercise(self.w.edit_settings,callback=save)
  self.assertEqual(warn.call_count,3);self.assertEqual(self.w.cfg,before);self.assertEqual(main.CONFIG.read_bytes(),raw)
 def unresolved(self):
  xs={next(iter(self.xdata)):copy.deepcopy(next(iter(self.xdata.values())))}
  cs=copy.deepcopy(self.cdata)
  for r in cs:r['name']='別の社員氏名'
  return xs,cs
 def test_read_done_unregistered_ids_never_open_dialog_three_times(self):
  xs,cs=self.unresolved();before=self.counts(self.w)
  for _ in range(3):
   self.w.mapping={};self.w.read_done(xs,cs,[],dict(elapsed=.1,cache_hits=0,parsed=2,files_found=2,files_completed=2));self.flush()
   self.assertEqual(self.w.mapping,{});self.assertEqual(self.counts(self.w),before)
   self.assertTrue(any('未登録' in item for item in self.w.issues))
 def test_read_done_uses_only_previously_registered_mapping_three_times(self):
  xs,cs=self.unresolved();eid=next(iter(xs));self.w.mapping={eid:'S001'}
  before=self.counts(self.w)
  for _ in range(3):
   self.w.read_done(xs,cs,[],dict(elapsed=.1,cache_hits=0,parsed=2,files_found=2,files_completed=2));self.flush()
   self.assertEqual(self.w.mapping,{eid:'S001'});self.assertEqual(self.counts(self.w),before)
 def test_context_menu_three_times(self):
  self.w.results=[self.sample_row()];self.w.filter_state='すべて';self.w.show_results();self.w.show();self.flush()
  idx=self.w.model.index(0,0);point=self.w.table.visualRect(idx).center();self.assertTrue(self.w.table.indexAt(point).isValid())
  before=self.counts(self.w);seen=[]
  for _ in range(3):
   def close():
    menu=self.w.findChildren(QMenu)[-1];seen.append(menu);menu.close()
   QTimer.singleShot(0,close);self.w.context_menu(point);self.flush()
   self.assertFalse(shiboken6.isValid(seen[-1]));self.assertEqual(self.counts(self.w),before)

if __name__=='__main__':unittest.main(verbosity=2)
