# Trial40 検証結果

28テストスクリプトすべて合格。完成監査8件、前回監査16件、設定27件、UI9件、マニュアル10件を含む。

| スクリプト | 結果 | 秒 |
|---|---|---|
| test_120_performance.py | PASS | 1.55 |
| test_cache_tags.py | PASS | 0.08 |
| test_comparison_extensions.py | PASS | 0.17 |
| test_coverage_trial16.py | PASS | 1.17 |
| test_engine.py | PASS | 0.12 |
| test_excel_jump.py | PASS | 0.02 |
| test_final_validation.py | PASS | 0.09 |
| test_month_spacers_trial19.py | PASS | 0.12 |
| test_sample_integration.py | PASS | 0.19 |
| test_stable_read.py | PASS | 0.02 |
| test_trial15.py | PASS | 0.11 |
| test_trial21.py | PASS | 0.09 |
| test_trial22_static.py | PASS | 0.02 |
| test_trial23_static.py | PASS | 0.02 |
| test_trial24_integrity.py | PASS | 0.02 |
| test_trial27_toggle_static.py | PASS | 0.02 |
| test_trial28_input_review.py | PASS | 0.09 |
| test_trial29_completion.py | PASS | 0.04 |
| test_trial30_dynamic_failures.py | PASS | 0.19 |
| test_trial31_excel_mock.py | PASS | 0.1 |
| test_trial32_gui_print.py | PASS | 1.32 |
| test_trial32_sessions_mapping.py | PASS | 6.75 |
| test_trial33_ui.py | PASS | 4.62 |
| test_trial34_settings.py | PASS | 6.65 |
| test_trial38_audit.py | PASS | 3.66 |
| test_trial39_manual.py | PASS | 4.36 |
| test_trial40_completion.py | PASS | 1.28 |
| test_ui_static.py | PASS | 0.06 |

120人・3,600勤怠日・10,800照合：一致10,797、不一致3、要確認0。初回解析とキャッシュ再利用の双方で一致。CSVエラー・範囲欠落・重複・中止・再実行、設定拡張と未知JSON保持、一覧・詳細印刷、Excel移動先のCOMモックを既存テストで確認。

実Qtで明暗UI、最小メイン1040×690・設定780×580、操作ボタンとF1、マニュアル配布コピーを確認。画像更新後、マニュアル10件を再実行して合格。QtWebEngineで18章・19画像のHTML描画、検索・0件時・画像拡大を確認。検証用ブラウザはアプリの依存関係に追加していない。

環境：Linux、Python3.12.14、PySide6 6.12.0、openpyxl3.1.5、Qtオフスクリーン。Windows11 / Python3.11、実EXE・実Excel・実プリンタ・会社ネットワークは未検証。テスト原本はTEST_RESULTS_TRIAL40.json。
