from pathlib import Path
from tempfile import TemporaryDirectory
import csv
from engine import csv_read,reconcile,DEFAULT
with TemporaryDirectory() as tmp:
    path=Path(tmp)/'bad.csv'
    def row(date, start):
        r=['']*14;r[0]=date;r[3]='S1';r[10:14]=[start,'17:30:00','8:00','1:00'];return r
    with path.open('w',encoding='cp932',newline='') as f:
        w=csv.writer(f);w.writerow(['header']*14);w.writerow(row('20261001','broken'));w.writerow(row('WRONG','8:30:00'))
    packet=csv_read(path,DEFAULT)
    assert len(packet['records'])==1
    assert packet['records'][0]['invalid_fields']==['start']
    assert len(packet['warnings'])==2
    x={'E1':{'info':{'name':'Test'},'records':[{'date':'2026-10-01','name':'Test','values':{'start':'8:30','end':'17:30','work':'8:00'}}]}}
    cfg=dict(DEFAULT);cfg['year']=2026;cfg['month']=10
    # October sheet covers September 16 to October 15
    rows,issues=reconcile(x,packet['records'],{'E1':'S1'},cfg)
    assert any(r['status']=='要確認' and 'CSV入力異常' in r['field'] for r in rows),rows
    assert any(r['status']=='要確認' and r['field']=='始業時刻' for r in rows) or any(r['status']=='要確認' and r['csv_key']=='start' for r in rows),rows
print('Trial28 invalid input review OK')
