"""Structural/filter tests executable even without Qt installed.
GUI display and icon rendering still require Windows/PySide6 integration tests.
"""
import ast
from pathlib import Path
from types import SimpleNamespace
from result_filters import missing_csv_months,is_missing_month_csv_gap

ROOT=Path(__file__).resolve().parent
source=(ROOT/'main.py').read_text(encoding='utf-8')
tree=ast.parse(source)
window=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Window')
func=next(n for n in window.body if isinstance(n,ast.FunctionDef) and n.name=='show_results')
namespace={'missing_csv_months':missing_csv_months,'is_missing_month_csv_gap':is_missing_month_csv_gap}
exec(compile(ast.Module(body=[func],type_ignores=[]),filename='<show_results>',mode='exec'),namespace)
show_results=namespace['show_results']

class DummyWidget:
    def __init__(self):self.value=None
    def setText(self,v):self.value=v
    def setEnabled(self,v):self.value=v
    def set_rows(self,rs,*args):self.value=rs
    def text(self):return self.value or ''

rows=[
  {'employee':'10001','name':'山田　太郎','status':'一致'},
  {'employee':'10001','name':'山田　太郎','status':'不一致'},
  {'employee':'10002','name':'佐藤　花子','status':'要確認'},
]
state=SimpleNamespace(results=rows,filter_state='不一致のみ',search=DummyWidget(),model=DummyWidget(),count_label=DummyWidget(),mail_button=DummyWidget(),print_button=DummyWidget(),preview_button=DummyWidget(),is_dark=False)
state.results_cfg=None
state.cfg={'year':2026,'month':10}
state.result_csv_months=None
state.hide_missing_csv_months=SimpleNamespace(isChecked=lambda:True)
state.search.value=''
show_results(state)
assert len(state.visible)==2 and {r['status'] for r in state.visible}=={'不一致','要確認'}
assert state.mail_button.value is True
state.filter_state='一致のみ'
show_results(state)
assert len(state.visible)==1 and state.visible[0]['status']=='一致'
assert state.mail_button.value is False
state.filter_state='すべて'
show_results(state)
assert len(state.visible)==3
state.search.value='10002'
show_results(state)
assert len(state.visible)==1 and state.visible[0]['name']=='佐藤　花子'
assert state.print_button.value is True
state.search.value='nobody'
show_results(state)
assert state.visible==[] and state.print_button.value is False and state.preview_button.value is False

ui=(ROOT/'ui_theme.py').read_text(encoding='utf-8')
assert 'QSvgRenderer' in ui and 'ICONS' in ui
assert 'refresh_button_icons' in source
assert "('XLSX 列・セル'" not in source or 'XLSX 列・セル' in source
assert 'QAbstractTableModel' in source and 'QTableView' in source
assert 'setCurrentCell(-1,-1)' in source  # Ensure mapping commit on active editor
print('PASS: 3表示モード、社員検索、表示件数、印刷ボタン制御、UI構造')
