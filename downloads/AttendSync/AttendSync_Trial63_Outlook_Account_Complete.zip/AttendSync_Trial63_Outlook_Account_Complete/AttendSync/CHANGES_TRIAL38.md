# Trial38 監査修正

変更Python:
- `main.py`: 読み込み結果の設定を保持し、照合・期間表示・詳細・印刷・Excel移動へ使用。表示選択の保存は未知キーと次回設定を保持。保存失敗時の設定保持。複数照合の表示・不一致表示、行が空の社員名を修正。一覧・詳細の印刷表を用紙幅へ合わせる。
- `settings_dialog.py`: 詳細の対応項目に有効な照合条件の名前を優先。設定の速度・範囲が先頭、月度が末尾の配置を維持。
- `engine.py`: 読み込み前のExcel上限・必須項目検証を強化。Excel timedeltaをJSONで保持できる日数へ正規化し24時間超を照合。
- `cache_tags.py`: 解析版を更新して旧形式の時間キャッシュを再利用しない。

追加Python:
- `test_trial38_audit.py`: 実Qtと実XLSX/CSVによる監査回帰16テスト。

削除Pythonなし。設定保存形式・未知属性・項目追加/改名/列変更/照合追加を維持。詳しい証拠はAUDIT_TRIAL38.md、全テスト結果はVALIDATION_TRIAL38.md。Windowsビルド済EXEは含まない。
