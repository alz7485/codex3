"""Independent final-audit regressions for unsafe employee/date/time matches."""
from collections import Counter
from copy import deepcopy
from datetime import timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
import csv
import unittest

from openpyxl import Workbook

from cache_tags import parser_tag
from engine import (DEFAULT, Cache, candidates, compare_time, coverage_report,
                    csv_read, display_time, reconcile, xlsx_read)


class FinalEngineAudit(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.cfg=deepcopy(DEFAULT)
        self.cfg['xlsx_columns']['extra']='V'
        self.cfg['csv_columns']['extra']='O'

    def tearDown(self):
        self.temp.cleanup()

    def workbook(self, *, day=16, month=9, start='8:30', extra=None):
        path=self.root/'employee.xlsx'
        wb=Workbook();ws=wb.active;ws.title='10月'
        ws['A1']='2026年10月度';ws['N1']='E1';ws['U1']='テスト社員'
        ws['A9']=month;ws['B9']=day;ws['G9']=start
        ws['H9']='17:30';ws['T9']='8:00';ws['V9']=extra
        wb.save(path);wb.close()
        return path

    def csv_source(self, *, start='8:30', extra=''):
        path=self.root/'attendance.csv'
        row=['']*15
        row[0]='20260916';row[3]='S1';row[4]='テスト社員'
        row[10:15]=[start,'17:30','8:00','1:00',extra]
        with path.open('w',encoding='utf-8-sig',newline='') as stream:
            writer=csv.writer(stream);writer.writerow(['header']*15);writer.writerow(row)
        return path

    def rows(self, source, target):
        return reconcile({'E1':source},target['records'],{'E1':'S1'},self.cfg)[0]

    def test_blank_names_never_create_an_automatic_employee_assignment(self):
        for xname,cname in [('', ''),(' \u3000\t',''),('', ' \u3000')]:
            with self.subTest(xname=xname,cname=cname):
                mapping={}
                missing=candidates({'E1':{'info':{'name':xname}}},
                                   [{'name':cname,'staff':'S1'}],mapping)
                self.assertEqual(mapping,{})
                self.assertEqual(missing,[('E1',xname,[])])
        mapping={}
        self.assertEqual(candidates({'E1':{'info':{'name':'テスト 社員'}}},
                                    [{'name':'テスト社員','staff':'S1'}],mapping),[])
        self.assertEqual(mapping,{'E1':'S1'})

    def test_fractional_and_boolean_excel_dates_do_not_become_other_days(self):
        for field,value in [('day',16.9),('month',9.8),('day',True),('month',True)]:
            with self.subTest(field=field,value=value):
                source=xlsx_read(self.workbook(**{field:value}),self.cfg)
                self.assertEqual(source['records'],[])
                self.assertTrue(source['warnings'])
                target=csv_read(self.csv_source(),self.cfg)
                self.assertTrue(all(row['status']=='要確認' for row in self.rows(source,target)))
                report=coverage_report({'E1':source},target['records'],{'E1':'S1'},self.cfg)
                self.assertFalse(report['complete'])

    def test_integral_numeric_and_text_calendar_values_remain_usable(self):
        for day,month in [(16,9),(16.0,9.0),('16','9')]:
            with self.subTest(day=day,month=month):
                source=xlsx_read(self.workbook(day=day,month=month),self.cfg)
                self.assertEqual([row['date'] for row in source['records']],['2026-09-16'])
                self.assertEqual(source['warnings'],[])

    def test_invalid_excel_clock_cannot_match_after_modulo_normalization(self):
        for value,target_value in [(-.5,'12:00'),('56:30','8:30'),(True,'0:00'),(False,'0:00')]:
            with self.subTest(value=value):
                source=xlsx_read(self.workbook(start=value),self.cfg)
                target=csv_read(self.csv_source(start=target_value),self.cfg)
                row=next(row for row in self.rows(source,target) if row['field']=='始業時刻')
                self.assertEqual(row['status'],'要確認')
                self.assertEqual(row['xlsx'],str(value))

    def test_added_csv_clock_fields_have_the_same_range_validation(self):
        self.cfg['comparisons']=[{'name':'追加の時刻','xlsx':'extra','csv':'extra','type':'clock','enabled':True}]
        source=xlsx_read(self.workbook(extra='8:30'),self.cfg)
        target=csv_read(self.csv_source(extra='56:30'),self.cfg)
        row=self.rows(source,target)[0]
        self.assertEqual(row['status'],'要確認')
        self.assertEqual(row['csv'],'56:30')

    def test_negative_nonfinite_and_boolean_values_are_reviewed_on_either_side(self):
        for kind in ('clock','duration'):
            for value in (-.5,float('nan'),float('inf'),float('-inf'),True,False):
                for other in ('0:00',None):
                    with self.subTest(kind=kind,value=value,other=other):
                        self.assertEqual(compare_time(value,other,kind),'要確認')
                        self.assertEqual(compare_time(other,value,kind),'要確認')
                        self.assertEqual(display_time(value,kind),str(value))

    def test_next_day_clock_and_long_durations_still_match(self):
        for value,other in [('24:00','0:00'),('25:00','1:00'),('47:59:59','23:59:59'),(1,'0:00')]:
            with self.subTest(value=value):
                self.assertEqual(compare_time(value,other,'clock'),'一致')
        for value in ('26:00',timedelta(hours=26),26/24):
            with self.subTest(value=value):
                self.assertEqual(compare_time(value,'26:00','duration'),'一致')
                self.assertEqual(display_time(value,'duration'),'26:00')
        self.assertEqual(compare_time('999:59','999:59','duration'),'一致')
        self.assertEqual(compare_time('48:00','0:00','clock'),'要確認')
        self.assertEqual(compare_time(None,'','clock'),'一致')
        self.assertEqual(compare_time(0,None,'duration'),'不一致')

    def test_csv_last_second_of_next_day_is_valid_but_48_hours_is_not(self):
        valid=csv_read(self.csv_source(start='47:59:59'),self.cfg)
        self.assertEqual(valid['records'][0]['invalid_fields'],[])
        self.assertEqual(valid['warnings'],[])
        invalid=csv_read(self.csv_source(start='48:00'),self.cfg)
        self.assertEqual(invalid['records'][0]['invalid_fields'],['start'])
        self.assertTrue(invalid['warnings'])

    def test_reused_source_cache_keeps_invalid_clock_under_review(self):
        source_path=self.workbook(start=-.5)
        target=csv_read(self.csv_source(start='12:00'),self.cfg)
        cache=Cache(self.root/'cache.sqlite3')
        try:
            for expected_hit in (False,True):
                source,hit=cache.parse(source_path,parser_tag(self.cfg,'xlsx'),lambda path:xlsx_read(path,self.cfg))
                self.assertEqual(hit,expected_hit)
                row=next(row for row in self.rows(source,target) if row['field']=='始業時刻')
                self.assertEqual(row['status'],'要確認')
        finally:cache.close()

    def test_csv_dates_require_eight_digits_instead_of_guessing_missing_zeroes(self):
        for value in ('2026102','2026111','202609016','2026-09-16'):
            with self.subTest(value=value):
                path=self.csv_source()
                path.write_text(path.read_text(encoding='utf-8-sig').replace('20260916',value),encoding='utf-8-sig')
                packet=csv_read(path,self.cfg)
                self.assertFalse(packet['records']);self.assertTrue(any('日付不正' in warning for warning in packet['warnings']))
        packet=csv_read(self.csv_source(),self.cfg)
        self.assertEqual(packet['records'][0]['date'],'2026-09-16')

    def test_complete_sample_results_remain_unchanged(self):
        base=Path(__file__).parent/'SampleData';cfg=deepcopy(DEFAULT)
        sources={};targets=[]
        for path in base.glob('*.xlsx'):
            packet=xlsx_read(path,cfg);sources[packet['info']['employee']]=packet
        for path in base.glob('*.csv'):
            targets.extend(csv_read(path,cfg)['records'])
        rows,issues=reconcile(sources,targets,{'10001':'S001','10002':'S002','10003':'S003','10004':'S004'},cfg)
        self.assertEqual(Counter(row['status'] for row in rows),Counter({'一致':357,'不一致':3}))
        self.assertEqual(issues,[])


if __name__=='__main__':
    unittest.main()
