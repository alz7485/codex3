# Trial41 独立最終監査の修正

- 氏名が空欄の社員は空欄同士で自動紐付けしない。
- XLSXの小数・真偽値の日月を切り捨てず警告にする。CSV日付は8桁YYYYMMDDを要求。
- 不正な時間は両側・追加項目・キャッシュ経由でも要確認。負値・非有限値・真偽値、48時間以上のclockを正規化して一致させない。翌日時刻と24時間超durationは維持。
- 将来の項目ID・表示名・未実装参照を予約済みとして保持。内部IDの区切り文字による詳細表示の衝突を拒否。
- 起動時に設定・社員ID対応の形を検証し、破損原本を上書きせず原因と復元方法を表示。UTF-8 BOMに対応。
- DBなどの致命的障害はユーザー中止と区別。前回結果を保持し、診断の失敗欄に原因を残す。
- 詳細JSONでフォルダ・年月度を変更した場合、メインの対応入力も更新。通常設定保存では未読込のメイン入力を保持。
- 全照合OFFを明示。未対応の比較形式は設定を保持し、ONなら要確認（文字列比較へ暗黙変換しない）。
- JSON保存と起動時書込み確認の一時ファイルを一意にし、競合と誤fallbackを防ぐ。
- 26画面を更新。画像付きマニュアルに障害時の手順を追加。

変更Python：engine.py、cache_tags.py、settings_dialog.py、main.py、runtime_paths.py、benchmark_startup.py、test_trial32_sessions_mapping.py（クラウド環境の速度変動に合わせ待機上限15→60秒）。
追加Python：test_trial41_engine.py、test_trial41_settings.py、test_trial41_runtime.py、benchmark_startup_comparison.py。削除なし。
PARSER_VERSIONを更新したため、旧解析キャッシュは初回に再解析する。
