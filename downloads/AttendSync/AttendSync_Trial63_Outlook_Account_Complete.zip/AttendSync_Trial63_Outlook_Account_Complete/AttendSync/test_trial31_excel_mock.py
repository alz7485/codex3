"""Mock Excel COM to verify navigation and cleanup without Windows/Excel."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from types import SimpleNamespace
import sys
from excel_jump import open_source_cell,source_cell_for

class WS:
    def __init__(self):self.selected=[]
    def Activate(self):pass
    def Range(self,name):return SimpleNamespace(Select=lambda:self.selected.append(name))
class WB:
    def __init__(self,path,fail=False):self.FullName=str(path);self.fail=fail;self.closed=False;self.ws=WS()
    def Worksheets(self,sheet):
        if self.fail:raise LookupError('sheet missing')
        return self.ws
    def Activate(self):pass
    def Close(self,SaveChanges=False):self.closed=True
class Excel:
    def __init__(self,path,fail=False,already_open=False):
        self.wb=WB(path,fail);self.Workbooks=SimpleNamespace(__iter__=lambda self:iter([])) if False else []
        self.Workbooks=Workbooks(self.wb,already_open)
        self.ActiveWindow=SimpleNamespace(ScrollRow=1)
        self.Visible=False;self.WindowState=0;self.quit=False
    def Quit(self):self.quit=True
class Workbooks:
    def __init__(self,wb,existing):self.wb=wb;self.existing=existing
    def __iter__(self):return iter([self.wb] if self.existing else [])
    def Open(self,*args,**kw):return self.wb

with TemporaryDirectory() as tmp:
    path=Path(tmp)/'demo.xlsx';path.write_bytes(b'fake for mock')
    rec=dict(file=str(path),sheet='10月',row=34)
    for existing in (True,False):
        for fail in (True,False):
            excel=Excel(path,fail,existing)
            module=SimpleNamespace(CoInitialize=lambda:None,CoUninitialize=lambda:None)
            com=SimpleNamespace(GetActiveObject=(lambda name:excel) if existing else (lambda name:(_ for _ in ()).throw(Exception('not running'))),DispatchEx=lambda name:excel)
            with patch.dict(sys.modules,{'pythoncom':module,'win32com':SimpleNamespace(client=com),'win32com.client':com}),patch('excel_jump.sys.platform','win32'):
                try: result=open_source_cell(rec,'H')
                except RuntimeError as e:
                    assert fail and 'シート' in str(e)
                else:
                    assert not fail and result[2]=='H34' and excel.wb.ws.selected==['H34']
                assert excel.wb.closed==(fail and not existing)
                assert excel.quit==(fail and not existing)
    for invalid in ({**rec,'row':None},{**rec,'row':'foo'},{**rec,'sheet':' '}):
        try:source_cell_for(invalid,'H')
        except ValueError:pass
        else:raise AssertionError('invalid source location accepted')
print('PASS: Excel COM mock success/failure, no close existing, cleanup new')
