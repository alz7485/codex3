"""Read account identities from an already running classic Outlook on Windows."""
import sys
from employee_contacts import valid_email


def _get(value,name):
    try:return getattr(value,name)
    except Exception:return None


def _text(value):
    return value.strip() if isinstance(value,str) else ''


def _account_identity(account):
    user=_get(account,'CurrentUser')
    name=_text(_get(user,'Name')) or _text(_get(account,'DisplayName'))
    address=_text(_get(account,'SmtpAddress'))
    if not valid_email(address):
        entry=_get(user,'AddressEntry')
        try:exchange_user=entry.GetExchangeUser()
        except Exception:exchange_user=None
        address=_text(_get(exchange_user,'PrimarySmtpAddress'))
        if not valid_email(address):
            accessor=_get(entry,'PropertyAccessor')
            for tag in ('0x39FE001F','0x39FE001E'):
                try:address=_text(accessor.GetProperty('http://schemas.microsoft.com/mapi/proptag/'+tag))
                except Exception:continue
                if valid_email(address):break
    if not valid_email(address):return None
    return {'account':address,'sender_name':' '.join(name.split())}


def running_outlook_accounts():
    """No Outlook launch, logon, mail creation or send. Return plain strings only."""
    if sys.platform!='win32':raise RuntimeError('Outlookからの取得はWindowsのクラシックOutlookで利用できます。')
    try:
        import pythoncom
        import win32com.client
    except ImportError as exc:
        raise RuntimeError('Outlookからの取得にはpywin32が必要です。requirements-build.txtの依存関係をインストールしてください。') from exc
    pythoncom.CoInitialize()
    outlook=None;accounts=None
    try:
        try:outlook=win32com.client.GetActiveObject('Outlook.Application')
        except Exception as exc:
            raise RuntimeError('起動中のクラシックOutlookを取得できません。Outlookを開き、このツールと同じWindowsユーザー・権限で実行してください。') from exc
        try:
            accounts=outlook.Session.Accounts;found=[];seen=set()
            for index in range(1,accounts.Count+1):
                try:identity=_account_identity(accounts.Item(index))
                except Exception:continue
                if identity and identity['account'].casefold() not in seen:
                    seen.add(identity['account'].casefold());found.append(identity)
        except Exception as exc:
            raise RuntimeError('Outlookのアカウント情報を取得できません。Outlookの起動状態を確認してください。') from exc
        if not found:raise RuntimeError('Outlookから有効なメールアドレスを取得できませんでした。接続するアカウントを手入力してください。')
        return found
    finally:
        accounts=None;outlook=None
        pythoncom.CoUninitialize()
