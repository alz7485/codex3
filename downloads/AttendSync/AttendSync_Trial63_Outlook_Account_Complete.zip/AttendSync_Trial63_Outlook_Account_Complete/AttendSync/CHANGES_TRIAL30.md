# Trial 30 変更点

- `main.py`: ファイル情報取得失敗を「処理結果として失敗1件」に計上し、件数監査で未報告と混同しないよう修正。
- `main.py`: キャッシュ再利用の直前にファイルが変化／statが失敗した経路でも処理済み件数と進捗を更新。失敗は引き続き `file_errors` に記録し、読込未完了を維持。
- `test_trial30_dynamic_failures.py`: PySide6未インストールでも、`ReadWorker.run` の実装をAST抽出して直接実行。破損XLSX・正常CSV・正常XLSX、二度目のキャッシュ利用、stat失敗注入で動的に検証。

## 検証制限

PySide6が検証環境にないため、Qtウィンドウ表示、ボタン操作、Excel COMジャンプ、印刷は未検証。実行ワーカーのロジックはQtのSignal/QThreadを軽量代替した上で駆動している。
