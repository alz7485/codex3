from pathlib import Path
import os
import sys
import tempfile

def application_dir():
    # PyInstaller onedir: executable is in dist/AttendSync/.
    # Source mode: directory containing this file.
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

def get_data_dir():
    portable = application_dir() / 'userdata'
    try:
        portable.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryFile(dir=portable) as probe:
            probe.write(b'ok');probe.flush()
        return portable
    except (OSError, PermissionError):
        fallback = Path(os.getenv('LOCALAPPDATA') or Path.home()) / 'AttendSync'
        try:
            fallback.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryFile(dir=fallback) as probe:
                probe.write(b'ok');probe.flush()
        except OSError as exc:
            raise OSError(f'設定の保存先に書き込めません。\n配布先：{portable}\n代替先：{fallback}\n{exc}') from exc
        return fallback
