# Trial41 起動の再測定

再開した同一環境で、旧Trial40とTrial41を交互に新規プロセスで各6回測定。最初の中央領域描画までの中央値はTrial40 **0.8645秒**、Trial41 **0.9580秒**（差 0.0935秒）。各ペアの実行順を入れ替え、並行テストを止めて測定。

別の連続6回測定ではTrial41中央値1.7241秒、最大2.3169秒。測定のばらつきが大きいため、差をWindows実機の性能差と断定しない。前の環境での約0.23秒と今回の数値も直接比較しない。

Linux・Qtオフスクリーン・ソース起動・一時標準設定。OSのディスクキャッシュは消去していない。Windows EXE、実設定、ウイルス対策、会社ネットワークでの起動は未検証。起動時の入力走査・読み込みスレッド開始・manualモジュール読み込みがないことは実プロセステストで確認。

原本：STARTUP_RESULTS_TRIAL41.json、STARTUP_BASELINE_TRIAL40_SAME_ENV.json、STARTUP_COMPARISON_TRIAL40_41.json。
再測定：python benchmark_startup.py --runs 6 --output STARTUP_RESULTS.json
比較：python benchmark_startup_comparison.py --baseline <旧版のAttendSyncフォルダ> --runs 6 --output STARTUP_COMPARISON.json
