"""Startup uses the device's calendar year/month for the closing-month workflow."""
import copy
from datetime import date
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import test_trial38_audit as fixture
import main
import startup_period
from engine import DEFAULT


class StartupPeriod43(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=fixture.Audit38.app if hasattr(fixture.Audit38,'app') else main.QApplication.instance() or main.QApplication([])

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name)
        paths=patch.multiple(main,CONFIG=self.base/'settings.json',MAP=self.base/'mapping.json',DB=self.base/'cache.sqlite3')
        paths.start();self.addCleanup(paths.stop)
        self.saved=copy.deepcopy(DEFAULT)
        self.saved.update(year=2020,month=8,future_extension={'keep':['custom']})
        main.CONFIG.write_text(json.dumps(self.saved),encoding='utf-8')
        self.original=main.CONFIG.read_bytes()

    def window(self,today):
        with patch.object(startup_period,'date') as clock:
            clock.today.return_value=today
            w=main.Window()
            clock.today.assert_called_once_with()
        self.addCleanup(w.close)
        return w

    def test_15th_16th_boundaries_for_every_month(self):
        for month in range(1,13):
            self.assertEqual(startup_period.current_attendance_month(date(2026,month,1)),(2026,month))
            self.assertEqual(startup_period.current_attendance_month(date(2026,month,15)),(2026,month))
            self.assertEqual(startup_period.current_attendance_month(date(2026,month,16)),(2026,month))

    def test_month_end_and_leap_year(self):
        for today,expected in [(date(2024,2,29),(2024,2)),(date(2026,2,28),(2026,2)),
                               (date(2026,9,30),(2026,9)),(date(2026,12,31),(2026,12)),
                               (date(2027,1,1),(2027,1)),(date(2027,1,15),(2027,1))]:
            self.assertEqual(startup_period.current_attendance_month(today),expected)

    def test_startup_overrides_stored_month_in_ui_and_runtime_config(self):
        for today,expected,days in [(date(2026,10,15),(2026,10),30),(date(2026,10,16),(2026,10),30),
                                    (date(2026,12,16),(2026,12),30),(date(2027,1,1),(2027,1),31),
                                    (date(2024,3,1),(2024,3),29)]:
            w=self.window(today)
            self.assertEqual((w.year.value(),w.month.value()),expected)
            self.assertEqual((w.cfg['year'],w.cfg['month']),expected)
            self.assertIn(f'（{days}日）',w.period_hint.text())
            self.assertEqual(w.cfg['future_extension'],self.saved['future_extension'])
            self.assertEqual(w.cfg['comparisons'],self.saved['comparisons'])
            self.assertEqual(main.CONFIG.read_bytes(),self.original)

    def test_first_start_without_settings_file(self):
        main.CONFIG.unlink()
        w=self.window(date(2026,10,16))
        self.assertEqual((w.year.value(),w.month.value()),(2026,10))
        self.assertFalse(main.CONFIG.exists())
        self.assertFalse(main.DB.exists())

    def test_manual_change_survives_until_next_start_and_is_used_by_worker(self):
        w=self.window(date(2026,11,16))
        w.year.setValue(2026);w.month.setValue(10)
        w.path.setText(str(Path(__file__).parent/'SampleData'))
        w.mapping={'10001':'S001'};main.save_json(main.MAP.with_name('employee_contacts.json'),{'version':1,'contacts':[],'employee_information_registered':True})
        with patch.object(main,'ReadWorker') as worker:
            worker.return_value.isRunning.return_value=False
            w.run_read()
            cfg=worker.call_args.args[1]
            self.assertEqual((cfg['year'],cfg['month']),(2026,10))
            worker.return_value.start.assert_called_once()
        w.worker=None
        self.assertEqual((w.year.value(),w.month.value()),(2026,10))
        reopened=self.window(date(2026,11,16))
        self.assertEqual((reopened.year.value(),reopened.month.value()),(2026,11))

    def test_date_is_read_once_and_does_not_replace_manual_selection(self):
        with patch.object(startup_period,'date') as clock:
            clock.today.side_effect=[date(2026,10,31),date(2026,11,1)]
            w=main.Window();self.addCleanup(w.close)
            w.month.setValue(8);w.update_period_hint();self.app.processEvents()
            self.assertEqual(w.month.value(),8)
            clock.today.assert_called_once_with()


if __name__=='__main__':unittest.main(verbosity=2)
