"""Native CSV drop events, automatic preview, and explicit commit/cancel."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import copy
import tempfile
import unittest
import sys
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import patch
from PySide6.QtCore import QMimeData, QPoint, QPointF, Qt, QUrl, QTimer
from PySide6.QtGui import QDragEnterEvent, QDragMoveEvent, QDropEvent
from PySide6.QtWidgets import QApplication, QComboBox, QLineEdit, QPushButton, QTableWidget
from PySide6.QtTest import QTest
import runtime_paths
_import_data = tempfile.TemporaryDirectory()
with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_data.name)):
    import main
from employee_information import show_employee_import_dialog
from employee_contacts import load_contacts, email_for
from engine import DEFAULT

APP = QApplication.instance() or QApplication([])
APP.setQuitOnLastWindowClosed(False)
EMPTY = {'version': 1, 'contacts': []}


class CsvDrop58(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        self.paths = patch.multiple(main, CONFIG=self.folder/'settings.json',
                                    MAP=self.folder/'staff_mapping.json', DB=self.folder/'cache.db')
        self.paths.start(); self.addCleanup(self.paths.stop)
        self.window = main.Window(); self.addCleanup(self.window.close)
        self.csv = self.folder/'社員 情報.CSV'
        self.csv.write_text('スタッフID,派遣元スタッフコード,氏名,D,E,F,G,H,I,メール\n'
                            'S01,0001,確認社員,,,,,,,one@example.com\n', encoding='utf-8-sig')
        self.errors = []

    def dispatch(self, target, urls=None, text=None):
        mime = QMimeData()
        if text is not None: mime.setText(text)
        else: mime.setUrls(urls or [QUrl.fromLocalFile(str(self.csv))])
        events = [QDragEnterEvent(QPoint(5, 5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier),
                  QDragMoveEvent(QPoint(5, 5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier),
                  QDropEvent(QPointF(5, 5), Qt.CopyAction|Qt.MoveAction, mime, Qt.LeftButton, Qt.NoModifier)]
        for event in events: APP.sendEvent(target, event)
        return events

    def button(self, dialog, text):
        return next(b for b in dialog.findChildren(QPushButton) if b.text() == text)

    def wizard(self, operate, contacts=None):
        def guarded():
            dialog = APP.activeModalWidget()
            try: operate(dialog)
            except Exception as exc: self.errors.append(exc); dialog.reject()
        QTimer.singleShot(0, guarded)
        result = show_employee_import_dialog(self.window, {}, copy.deepcopy(contacts or EMPTY), DEFAULT)
        self.assertFalse(self.errors, self.errors)
        return result

    def test_drop_over_dialog_fields_and_viewport_automatically_previews(self):
        def operate(dialog):
            table = dialog.findChild(QTableWidget, 'informationPreview')
            targets = [dialog, dialog.findChild(QLineEdit, 'informationCsvPath'),
                       dialog.findChild(QLineEdit, 'informationColumn_employee'), table.viewport()]
            for target in targets:
                events = self.dispatch(target)
                self.assertTrue(all(e.isAccepted() and e.dropAction() == Qt.CopyAction for e in events))
                APP.processEvents()
                self.assertEqual(table.rowCount(), 1)
                self.assertEqual(table.columnCount(), 5)
                self.assertNotIn('CSV行', [table.horizontalHeaderItem(i).text() for i in range(table.columnCount())])
                self.assertEqual(table.item(0, 1).text(), '0001')
                self.assertEqual(table.item(0, 0).text(), 'S01')
                self.assertEqual(table.item(0, 3).text(), 'one@example.com')
                self.assertTrue(self.button(dialog, '一覧に反映').isEnabled())
            self.button(dialog, '一覧に反映').click()
        result = self.wizard(operate)
        self.assertEqual(result['mapping'], {'0001': 'S01'})
        self.assertEqual(email_for(result['contacts'], '0001', 'S01'), 'one@example.com')
        self.assertFalse(main.MAP.exists())

    def test_invalid_drops_do_not_paste_into_columns_or_change_filename(self):
        bad = self.folder/'other.xlsx'; bad.write_text('invalid')
        directory = self.folder/'fake.csv'; directory.mkdir()
        invalid = [[QUrl.fromLocalFile(str(bad))], [QUrl.fromLocalFile(str(directory))],
                   [QUrl.fromLocalFile(str(self.csv))]*2, [QUrl('https://example.com/staff.csv')],
                   [QUrl.fromLocalFile(str(self.folder/'missing.csv'))]]
        def operate(dialog):
            field = dialog.findChild(QLineEdit, 'informationColumn_employee')
            filename = dialog.findChild(QLineEdit, 'informationCsvPath')
            for urls in invalid:
                self.assertFalse(any(e.isAccepted() for e in self.dispatch(field, urls)))
            self.assertFalse(any(e.isAccepted() for e in self.dispatch(field, text='unexpected')))
            APP.processEvents()
            self.assertEqual(field.text(), 'B'); self.assertEqual(filename.text(), '')
            self.assertFalse(self.button(dialog, '一覧に反映').isEnabled())
            dialog.reject()
        self.assertIsNone(self.wizard(operate))

    def test_drop_uses_current_role_and_preserves_saved_email(self):
        self.csv.write_text('date,type,x,staff,name\n20261001,0,,S02,別社員\n')
        contacts = {'version': 1, 'contacts': [{'employee': '0001', 'staff': 'S01',
                    'name': '確認社員', 'email': 'one@example.com'}]}
        def operate(dialog):
            dialog.findChild(QComboBox, 'informationCsvRole').setCurrentIndex(1)
            self.dispatch(dialog); APP.processEvents()
            table = dialog.findChild(QTableWidget, 'informationPreview')
            self.assertEqual(table.item(0, 0).text(), 'S02')
            self.assertEqual(table.item(0, 3).text(), '')
            self.button(dialog, '一覧に反映').click()
        result = self.wizard(operate, contacts)
        self.assertEqual(result['mapping'], {})
        self.assertEqual(email_for(result['contacts'], '0001', 'S01'), 'one@example.com')

    def test_drop_respects_saved_columns(self):
        self.csv.write_text('mail,name,staff,employee\none@example.com,確認社員,S01,0001\n')
        contacts = {**EMPTY, 'employee_import_settings': {'linking': {
                    'columns': {'email': 'A', 'name': 'B', 'staff': 'C', 'employee': 'D'}}}}
        def operate(dialog):
            self.dispatch(dialog); APP.processEvents()
            self.assertEqual(dialog.findChild(QLineEdit, 'informationColumn_employee').text(), 'D')
            self.button(dialog, '一覧に反映').click()
        result = self.wizard(operate, contacts)
        self.assertEqual(result['mapping'], {'0001': 'S01'})
        self.assertEqual(email_for(result['contacts'], '0001', 'S01'), 'one@example.com')

    def test_unreadable_drop_invalidates_previous_preview(self):
        def operate(dialog):
            self.dispatch(dialog); APP.processEvents()
            self.assertTrue(self.button(dialog, '一覧に反映').isEnabled())
            self.csv.write_bytes(b'\x81')
            with patch.object(main.QMessageBox, 'warning') as warning:
                self.dispatch(dialog); APP.processEvents()
                warning.assert_called_once()
            self.assertFalse(self.button(dialog, '一覧に反映').isEnabled())
            dialog.reject()
        self.assertIsNone(self.wizard(operate))

    def test_double_click_opens_original_csv_cell_without_visible_row_number(self):
        def operate(dialog):
            self.dispatch(dialog); APP.processEvents()
            table = dialog.findChild(QTableWidget, 'informationPreview')
            with patch('excel_jump.open_csv_cell') as opener:
                rect = table.visualItemRect(table.item(0, 3))
                QTest.mouseClick(table.viewport(), Qt.LeftButton, pos=rect.center())
                QTest.mouseDClick(table.viewport(), Qt.LeftButton, pos=rect.center())
                opener.assert_called_once()
                record, column = opener.call_args.args
                self.assertEqual(Path(record['file']), self.csv)
                self.assertEqual(record['row'], 2); self.assertEqual(column, 'J')
                self.assertEqual(record['file_size'], self.csv.stat().st_size)
                table.cellDoubleClicked.emit(0, 1)
                self.assertEqual(opener.call_args.args[1], 'B')
                table.cellDoubleClicked.emit(0, 4)
                self.assertEqual(opener.call_args.args[1], 'A')
            # A changed column invalidates the rows and prevents stale navigation.
            dialog.findChild(QLineEdit, 'informationColumn_email').setText('I')
            self.assertEqual(table.rowCount(), 0)
            with patch('excel_jump.open_csv_cell') as opener:
                table.cellDoubleClicked.emit(0, 3); opener.assert_not_called()
            dialog.reject()
        self.assertIsNone(self.wizard(operate))

    def test_csv_excel_navigation_reuses_existing_workbook_and_checks_updates(self):
        from excel_jump import open_csv_cell
        from test_trial31_excel_mock import Excel
        excel = Excel(self.csv, already_open=True)
        com = SimpleNamespace(GetActiveObject=lambda name: excel,
                              DispatchEx=lambda name: self.fail('Must reuse existing Excel'))
        pythoncom = SimpleNamespace(CoInitialize=lambda: None, CoUninitialize=lambda: None)
        stat = self.csv.stat()
        record = dict(file=str(self.csv), row=2, file_size=stat.st_size, file_mtime_ns=stat.st_mtime_ns)
        with patch.dict(sys.modules, {'pythoncom': pythoncom, 'win32com': SimpleNamespace(client=com),
                                    'win32com.client': com}), patch('excel_jump.sys.platform', 'win32'):
            result = open_csv_cell(record, 'J')
            self.assertEqual(result, (str(self.csv), 1, 'J2'))
            self.assertEqual(excel.wb.ws.selected, ['J2'])
            self.assertFalse(excel.wb.closed); self.assertFalse(excel.quit)
            with self.assertRaises(ValueError): open_csv_cell(record, 'XFE')
            self.csv.write_text('file changed')
            with self.assertRaisesRegex(RuntimeError, '再読込'): open_csv_cell(record, 'J')

    def editor_drop(self, save):
        def imported():
            dialog = APP.activeModalWidget()
            try:
                table = dialog.findChild(QTableWidget, 'informationPreview')
                self.assertEqual(table.rowCount(), 1)
                self.assertEqual(table.item(0, 1).text(), '0001')
                self.button(dialog, '一覧に反映').click()
            except Exception as exc: self.errors.append(exc); dialog.reject()
            QTimer.singleShot(0, finish)
        def finish():
            dialog = APP.activeModalWidget()
            try:
                self.assertEqual(dialog.findChild(QTableWidget, 'employeeIdTable').rowCount(), 1)
                self.assertFalse(main.MAP.exists())
                if save: self.button(dialog, '紐付けを保存').click()
                else: dialog.reject()
            except Exception as exc: self.errors.append(exc); dialog.reject()
        def operate():
            dialog = APP.activeModalWidget()
            try:
                events = self.dispatch(dialog.findChild(QTableWidget, 'employeeIdTable').viewport())
                self.assertTrue(all(e.isAccepted() for e in events))
                # The drop callback opens the import dialog on the next event turn.
                QTimer.singleShot(0, lambda: QTimer.singleShot(0, imported))
            except Exception as exc: self.errors.append(exc); dialog.reject()
        with patch.object(self.window, 'run_read'):
            QTimer.singleShot(0, operate); self.window.edit_map(); APP.processEvents()
        self.assertFalse(self.errors, self.errors)

    def test_editor_drop_then_apply_and_cancel_does_not_save(self):
        self.editor_drop(False)
        self.assertFalse(main.MAP.exists())
        self.assertFalse(main.MAP.with_name('employee_contacts.json').exists())
        self.assertEqual(self.window.mapping, {})

    def test_editor_drop_commits_only_after_explicit_save(self):
        self.editor_drop(True)
        self.assertEqual(self.window.mapping, {'0001': 'S01'})
        self.assertEqual(email_for(load_contacts(main.MAP.with_name('employee_contacts.json')),
                                   '0001', 'S01'), 'one@example.com')


if __name__ == '__main__': unittest.main(verbosity=2)
