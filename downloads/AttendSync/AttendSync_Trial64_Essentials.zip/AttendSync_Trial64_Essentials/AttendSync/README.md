# 勤怠チェッカー Trial64 必要ファイル版

Windows11 / Python3.11推奨のソース版。実行・ビルド用Python、アイコン、18ページ図解です。EXE・実データ・監査・テスト・サンプル・未使用の旧Graph実装は含みません。

PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

配布はdist\AttendSync全体。旧userdataはバックアップ後に引き継いでください。

最初に「社員情報」で社員CSVを選択・ドロップし「一覧に反映」→「社員情報を登録」。初期列はスタッフID=A、社員ID=B、氏名=C、メール=J。その後メインで勤怠を読み込みます。

メールはWindowsのクラシックOutlookをCOMで操作します。MicrosoftアプリID・テナントID・アプリ登録・ブラウザ認証は不要です。Outlookを起動して「設定」→「メール」→「起動中のOutlookから取得」。複数アカウントは選択し「設定を保存」で確定します。

メール作成画面で宛先と内容を確認し実行します。自動送信OFF（初期値）は指定アカウントの下書きフォルダへ保存。ONはOutlookへ送信要求。送信元不明時は中止し、結果不明時も自動再送しません。「送信要求済み」は配達完了ではなく、オフライン時には送信トレイに残ることがあります。

図解：Manual/index.html。接続：Manual/Outlook連携ガイド.html。全51スクリプト成功。Windows実機でのOutlook接続・実送信・EXEビルドは未検証です。
