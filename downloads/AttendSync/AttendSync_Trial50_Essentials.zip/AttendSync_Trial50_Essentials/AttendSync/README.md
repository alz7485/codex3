# AttendSync Trial50 必要ファイル版

実行・Windows EXEビルドに必要なソース、ICOアイコン、依存定義、操作マニュアル（画像・59ページPDF）を同梱。監査資料、テスト、ベンチマーク、プレビュー、サンプル帳票、過去の変更履歴は省略。

Windows 11 / Python 3.11 のPowerShellでこのフォルダへ移動:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

生成されたdist\AttendSyncフォルダ全体を配布。ビルド済みWindows EXEはこのZIPに含まれません。受取側にPythonは不要。Microsoft Excelへの移動には実Excelが必要。

既存userdataはバックアップ後に引き継ぎ。同姓同名の過去の対応は元社員番号・スタッフIDを確認し、必要なら社員ID管理で訂正してください。

今回の6修正は完全版と同一ソースです。既存40＋追加1の41テスト成功。Windows実機/実Excel/実プリンターは未検証。操作マニュアルはTrial49を継承。
