# 勤怠チェッカー Trial66 必要ファイル版

Pythonソース版です。ビルド済みWindows EXEは含みません。
Python 3.11/3.12と、Microsoft Excel・クラシックOutlookを用意します。
本版の自動試験はLinux/Python3.12.14で実施。Windows実機・実配送・EXEビルドは未検証です。

1. requirements.txtをインストールして `python main.py` で起動。
2. 最初に社員情報CSV（AスタッフID/B社員ID/C氏名/Jメール）を読み込み登録。
3. 勤怠フォルダと月度を指定して読み込み・照合。
4. 不一致を確認してメールを作成。設定でOutlookの送信元を取得します。アプリIDは不要。
5. 自動送信OFFは下書き保存、ONは送信要求です。

[図解操作ガイド](Manual/index.html) / [変更内容・旧履歴の制約](CHANGES_TRIAL66.md)

更新前はアプリを終了しuserdataをバックアップしてください。旧メール処理履歴は削除しないでください。
実行に必要なソース・アイコン・マニュアル・Windowsビルド用スクリプトだけを含みます。
テスト・監査報告・サンプル・監査設定は完全版に同梱しています。
