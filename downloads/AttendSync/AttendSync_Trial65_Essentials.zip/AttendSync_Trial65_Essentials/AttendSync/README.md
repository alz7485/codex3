# 勤怠チェッカー Trial65 必要ファイル版

Windows11 / Python3.11推奨のソース版です。実行・ビルド用Python、アイコン、18ページ図解のみ。EXE、実データ、テスト・監査証跡、サンプル、未使用の旧Graph実装は含みません。

PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

配布はdist\AttendSync全体。既存userdataはバックアップ後に引き継いでください。

最初に「社員情報」で社員CSVを選択・ドロップし「一覧に反映」→「社員情報を登録」。初期列はスタッフID=A、社員ID=B、氏名=C、メール=J。その後メインで勤怠を読み込みます。

メールは起動中のクラシックOutlookをCOMで操作します。MicrosoftアプリID・テナントID・ブラウザ認証は不要。「設定」→「メール」→「起動中のOutlookから取得」で送信元・表示名を入力し、保存します。自動送信OFF（初期値）は指定アカウントの下書き、ONはOutlookへの送信要求です。要求完了は配達完了ではありません。

6役の独立監査で9原因を修正し、別担当の最終監査と全52スクリプトが成功しました。旧版で表示名を変更済みの不透明な履歴ハッシュは完全に復元できないため、移行時はOutlookの下書き・送信済みも確認してください。

図解：Manual/index.html。Windows実機・実COM・実送信・EXEビルドは未検証です。
