"""Prepare employee-specific mismatch mail for classic Outlook COM."""
import sys,re,string
from email.utils import getaddresses
from employee_contacts import email_for,valid_email
DEFAULT_MAIL_SETTINGS={
 'always_to':'','always_cc':'','sender_name':'','name_suffix':'殿','signature':'',
 'auto_send':False,'client_id':'','tenant_id':'organizations','account':'',
 'subject':'【勤怠確認】{year}年{month}月度 {recipient_name}',
 'body':'{recipient_name}\n\n{year}年{month}月度の勤怠について、以下の不一致をご確認ください。\n\n{differences}\n\nご確認のうえ、必要な修正をお願いいたします。\n\n{sender_name}\n{signature}'}
TOKENS={'name','recipient_name','employee_id','staff_id','year','month','differences','sender_name','signature','count'}

def parsed_addresses(value):
    if not isinstance(value,str):raise ValueError('メールの宛先は文字列で指定してください。')
    normalized=re.sub(r'^[\s,]+|[\s,]+$','',value.replace(';',',').replace('\r','').replace('\n',','))
    if not normalized:return []
    parsed=getaddresses([normalized])
    if not any(address or display for display,address in parsed):raise ValueError('不正なメールアドレス：'+value)
    for display,address in parsed:
        if not address and not display:continue
        if not valid_email(address):raise ValueError('不正なメールアドレス：'+(address or display))
    return [(display,address) for display,address in parsed if address]

def addresses(value):
    result=[];seen=set()
    for display,address in parsed_addresses(value):
        if address.casefold() not in seen:result.append(address);seen.add(address.casefold())
    return result

def validate_mail_settings(value):
    if not isinstance(value,dict):raise ValueError('メール設定はオブジェクト形式で指定してください。')
    settings={**DEFAULT_MAIL_SETTINGS,**value}
    if not isinstance(settings['auto_send'],bool):raise ValueError('自動送信はtrueまたはfalseで指定してください。')
    for key in DEFAULT_MAIL_SETTINGS:
        if key=='auto_send':continue
        if not isinstance(settings[key],str):raise ValueError('メール設定の値は文字列で指定してください：'+key)
    for key in ('client_id','tenant_id','account'):settings[key]=settings[key].strip()
    if settings['account'] and not valid_email(settings['account']):raise ValueError('接続アカウントはメールアドレスで指定してください。')
    for key in ('sender_name','name_suffix'):
        if '\n' in settings[key] or '\r' in settings[key]:raise ValueError('差出人名と敬称は1行で指定してください。')
    addresses(settings['always_to']);addresses(settings['always_cc'])
    if '\n' in settings['subject'] or '\r' in settings['subject']:raise ValueError('件名は1行で指定してください。')
    if not settings['subject'].strip() or not settings['body'].strip():raise ValueError('メールの件名と本文を入力してください。')
    for key in ('subject','body'):
        try:
            for _,field,spec,conversion in string.Formatter().parse(settings[key]):
                if field is not None and (field not in TOKENS or spec or conversion):raise ValueError('未対応の差し込み項目：'+str(field))
        except ValueError as exc:raise ValueError(f'{key}: {exc}') from exc
    if not any(field=='differences' for _,field,_,_ in string.Formatter().parse(settings['body'])):raise ValueError('本文には {differences}（不一致内容）を含めてください。')
    return settings

def one_line(value):return ' '.join(str(value or '').split())

def build_mail_plans(rows,contacts,mapping,settings,period):
    settings=validate_mail_settings(settings);groups={}
    for row in rows:
        if row.get('status')=='不一致':groups.setdefault(str(row.get('employee','')),[]).append(row)
    plans=[]
    for eid,items in sorted(groups.items()):
        ids={str(r.get('staff','')).strip() for r in items};name=one_line(items[0].get('name',''));sid=next(iter(ids)) if len(ids)==1 else ''
        problem=''
        if not eid or len(ids)!=1 or not sid:problem='社員ID・スタッフIDを確認してください'
        elif str(mapping.get(eid,'')).strip()!=sid:problem='保存済みのID対応と照合結果が異なります'
        email=email_for(contacts,eid,sid) if not problem else ''
        if not problem and not valid_email(email):problem='社員メール未登録・形式不正'
        seen=set();lines=[]
        for row in sorted(items,key=lambda r:(str(r.get('date','')),str(r.get('field','')))):
            detail=(one_line(row.get('date')),one_line(row.get('field')),one_line(row.get('xlsx')),one_line(row.get('csv')))
            if detail in seen:continue
            seen.add(detail)
            day,field,xlsx,csv=detail
            lines.append(f'{day}  {field}\n  派遣元：{xlsx or "（空欄）"}\n  派遣先：{csv or "（空欄）"}')
        context=dict(name=name,recipient_name=name+settings['name_suffix'],employee_id=eid,staff_id=sid,year=period['year'],month=period['month'],differences='\n\n'.join(lines),sender_name=settings['sender_name'],signature=settings['signature'],count=len(lines))
        to=addresses(';'.join(([email] if email else [])+([settings['always_to']] if settings['always_to'].strip() else [])))
        recipient_names={address:one_line(display) for display,address in parsed_addresses(settings['always_to'])+parsed_addresses(settings['always_cc']) if address and display}
        if email and name:recipient_names[email]=name
        plans.append(dict(employee=eid,staff=sid,name=name,to=to,cc=addresses(settings['always_cc']),subject=settings['subject'].format_map(context),body=settings['body'].format_map(context),count=len(lines),problem=problem,recipient_names=recipient_names))
    return plans

def show_mail_dialog(parent,plans,settings,data_dir):
    from PySide6.QtCore import Qt,QThread,Signal
    from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QHeaderView,QTextEdit,QSplitter,QMessageBox,QCheckBox
    from ui_theme import button,refresh_button_icons
    from classic_outlook import process_classic_plans
    settings=validate_mail_settings(settings);worker=None;busy=False
    class Dialog(QDialog):
        def reject(self):
            if not busy and (worker is None or not worker.isRunning()):super().reject()
        def closeEvent(self,event):
            if busy or (worker is not None and worker.isRunning()):event.ignore()
            else:super().closeEvent(event)
    class Worker(QThread):
        completed=Signal(object);failed=Signal(str)
        def run(self):
            try:
                self.completed.emit(process_classic_plans(selected_plans,settings,data_dir))
            except Exception as exc:self.failed.emit(str(exc))
    dlg=Dialog(parent);dlg.setWindowTitle('メールを作成');dlg.resize(1080,740);dlg.setMinimumSize(960,620)
    root=QVBoxLayout(dlg);root.setContentsMargins(20,18,20,16)
    heading=QLabel('メールを作成');heading.setObjectName('pageTitle');root.addWidget(heading)
    eligible=sum(not p['problem'] for p in plans)
    mode='自動送信 ON：実行すると選択した社員へ送信します。' if settings['auto_send'] else '自動送信 OFF：Outlookの下書きに保存します。'
    root.addWidget(QLabel(f'表示中の不一致を社員ごとにまとめています。作成可能 {eligible}人 / 要確認 {len(plans)-eligible}人'))
    auto_toggle=QCheckBox('自動送信する（OFF：下書き保存）');auto_toggle.setObjectName('mailAutoSend');auto_toggle.setChecked(settings['auto_send']);root.addWidget(auto_toggle)
    info=QLabel(mode+' 送信元アカウント：'+(settings['account'] or '設定で指定してください'));info.setWordWrap(True);root.addWidget(info)
    split=QSplitter();table=QTableWidget(len(plans),4);table.setHorizontalHeaderLabels(['対象','氏名','不一致','状態']);table.verticalHeader().hide();table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);table.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch)
    preview=QTextEdit();preview.setReadOnly(True);split.addWidget(table);split.addWidget(preview);split.setSizes([360,660]);root.addWidget(split,1)
    for i,plan in enumerate(plans):
        check=QTableWidgetItem();check.setFlags(Qt.ItemIsEnabled|Qt.ItemIsUserCheckable if not plan['problem'] else Qt.NoItemFlags);check.setCheckState(Qt.Checked if not plan['problem'] else Qt.Unchecked);table.setItem(i,0,check)
        for col,value in [(1,plan['name']),(2,str(plan['count'])),(3,plan['problem'] or '未作成')]:
            item=QTableWidgetItem(value);item.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable);table.setItem(i,col,item)
    def show(index,*args):
        if 0<=index<len(plans):
            p=plans[index];preview.setPlainText('宛先：'+'; '.join(p['to'])+'\nCC：'+'; '.join(p['cc'])+'\n件名：'+p['subject']+'\n\n'+p['body'])
    table.currentCellChanged.connect(show);table.setCurrentCell(0,1)
    controls=QHBoxLayout();controls.addStretch();close=button('閉じる','x');create=button('選択したメールを送信' if settings['auto_send'] else 'Outlookの下書きを作成','mail','primary');create.setEnabled(eligible>0);controls.addWidget(close);controls.addWidget(create);root.addLayout(controls)
    selected=[];selected_plans=[]
    def unlock():
        nonlocal busy
        busy=False
        create.setEnabled(any(table.item(i,0).flags() & Qt.ItemIsUserCheckable for i in range(table.rowCount())))
        table.setEnabled(True);close.setEnabled(True);auto_toggle.setEnabled(True);info.setText(mode+' 送信元アカウント：'+(settings['account'] or '未設定'))
    def completed(outcomes):
        for (i,_),outcome in zip(selected,outcomes):
            table.item(i,3).setText(outcome['status'])
            if outcome['status']!='未処理':
                table.item(i,0).setCheckState(Qt.Unchecked);table.item(i,0).setFlags(Qt.NoItemFlags)
        errors=[o['error'] for o in outcomes if o.get('error')]
        if errors:QMessageBox.warning(dlg,'一部のメールを処理できません',errors[0]+'\n再実行前にOutlookの下書き・送信済みを確認してください。')
        else:QMessageBox.information(dlg,'処理が完了しました','\n'.join(f'{o["employee"]}: {o["status"]}' for o in outcomes))
    def failed(message):
        QMessageBox.warning(dlg,'メール処理に失敗',message)
    def make():
        nonlocal worker,selected,selected_plans,busy
        if busy or (worker is not None and worker.isRunning()):return
        selected=[(i,p) for i,p in enumerate(plans) if table.item(i,0).checkState()==Qt.Checked]
        if not selected:QMessageBox.information(dlg,'対象なし','対象の社員にチェックを入れてください。');return
        busy=True
        create.setEnabled(False);close.setEnabled(False);table.setEnabled(False);auto_toggle.setEnabled(False)
        info.setText(mode+' 処理中です。Outlookの確認画面が表示された場合は内容を確認してください。')
        worker=Worker(dlg);worker.completed.connect(completed);worker.failed.connect(failed);worker.finished.connect(unlock);selected_plans=[p for _,p in selected];worker.start()
    def change_mode(checked):
        nonlocal mode
        settings['auto_send']=checked
        mode='自動送信 ON：実行すると選択した社員へ送信します。' if checked else '自動送信 OFF：Outlookの下書きに保存します。'
        info.setText(mode+' 送信元アカウント：'+(settings['account'] or '未設定'))
        create.setText('選択したメールを送信' if checked else 'Outlookの下書きを作成')
    auto_toggle.toggled.connect(change_mode)
    create.clicked.connect(make);close.clicked.connect(dlg.reject);refresh_button_icons(dlg,getattr(parent,'is_dark',False))
    try:dlg.exec()
    finally:
        if worker is not None:worker.wait()
        dlg.deleteLater()
