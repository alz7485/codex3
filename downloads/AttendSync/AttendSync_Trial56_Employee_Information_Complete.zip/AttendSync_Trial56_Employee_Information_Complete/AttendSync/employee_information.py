"""Unified employee information: CSV purpose, ID/email plans, recoverable save."""
import csv,io,copy,os,json,base64,tempfile
from pathlib import Path
from collections import defaultdict
from openpyxl.utils.cell import column_index_from_string
from engine import save_json,load_json
from employee_contacts import load_contacts,valid_email,merged_contacts
from microsoft_mail import mail_lock

def source_key(path):return os.path.normcase(str(Path(path).expanduser().resolve()))

def load_information(path):
    data=load_contacts(path)
    names=data.get('employee_names',{})
    if not isinstance(names,dict) or not all(isinstance(k,str) and isinstance(v,str) for k,v in names.items()):raise ValueError('社員名の保存形式が不正です。')
    candidates=data.get('staff_candidates',[])
    if not isinstance(candidates,list) or not all(isinstance(r,dict) and all(isinstance(r.get(k),str) for k in ('employee','staff','name')) for r in candidates):raise ValueError('スタッフID候補の保存形式が不正です。')
    sources=data.get('csv_sources',{})
    if not isinstance(sources,dict) or not all(isinstance(k,str) and v in ('linking','attendance') for k,v in sources.items()):raise ValueError('CSV用途の保存形式が不正です。')
    imports=data.get('employee_import_settings',{})
    if not isinstance(imports,dict):raise ValueError('社員情報CSVの読込設定が不正です。')
    return data

def excluded_link_csv_paths(contacts_path):
    data=load_information(contacts_path)
    sources=data.get('csv_sources',{})
    if not isinstance(sources,dict):raise ValueError('CSV用途設定が不正です。社員情報を確認してください。')
    return {source_key(path) for path,role in sources.items() if role=='linking'}

def _restore(path,encoded):
    if encoded is None:
        if path.exists():path.unlink()
        return
    raw=base64.b64decode(encoded,validate=True)
    if path.exists() and path.read_bytes()==raw:return
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as stream:
            temporary=Path(stream.name);stream.write(raw);stream.flush();os.fsync(stream.fileno())
        temporary.replace(path)
    finally:
        if temporary and temporary.exists():temporary.unlink()

def _recover(mapping_path,contacts_path):
    journal=Path(mapping_path).with_name('employee_save_transaction.json')
    if not journal.exists():return
    snapshots=load_json(journal,{})
    if not isinstance(snapshots,dict) or set(snapshots)!={'mapping','contacts'}:raise ValueError('社員情報の保存回復データが不正です。')
    for key,path in [('contacts',Path(contacts_path)),('mapping',Path(mapping_path))]:_restore(path,snapshots[key])
    journal.unlink()

def recover_employee_save(mapping_path,contacts_path):
    if Path(mapping_path).with_name('employee_save_transaction.json').exists():
        with mail_lock(Path(mapping_path).parent):_recover(mapping_path,contacts_path)

def commit_employee_information(mapping_path,contacts_path,mapping,contacts,writer=save_json):
    mapping_path=Path(mapping_path);contacts_path=Path(contacts_path);journal=mapping_path.with_name('employee_save_transaction.json')
    with mail_lock(mapping_path.parent):
        _recover(mapping_path,contacts_path)
        snapshots={key:base64.b64encode(path.read_bytes()).decode('ascii') if path.exists() else None for key,path in [('mapping',mapping_path),('contacts',contacts_path)]}
        save_json(journal,snapshots)
        try:
            writer(contacts_path,contacts);writer(mapping_path,mapping);journal.unlink()
        except Exception:
            _recover(mapping_path,contacts_path)
            raise

def read_information_csv(path,role,columns,first_row=2,encoding='auto'):
    if role not in ('linking','attendance'):raise ValueError('CSVの用途を選択してください。')
    required=('employee','staff','name','email') if role=='linking' else ('staff','name')
    indices={}
    for key in ('employee','staff','name','email'):
        value=str(columns.get(key,'')).strip().upper()
        if role=='attendance' and key=='email':continue
        if not value:
            if key in required:raise ValueError(f'{key}の列を指定してください。')
            continue
        index=column_index_from_string(value)-1
        if not 0<=index<16384:raise ValueError('列はA～XFDで指定してください。')
        indices[key]=index
    if len(indices)!=len(set(indices.values())):raise ValueError('項目ごとに異なる列を指定してください。')
    if isinstance(first_row,bool) or not isinstance(first_row,int) or first_row<1:raise ValueError('開始行は1以上で指定してください。')
    raw=Path(path).read_bytes()
    if encoding=='auto':
        for enc in ('utf-8-sig','cp932'):
            try:text=raw.decode(enc);break
            except UnicodeDecodeError:continue
        else:raise ValueError('CSVはUTF-8またはCP932で保存してください。')
    else:text=raw.decode(encoding)
    rows=[]
    for line,record in enumerate(csv.reader(io.StringIO(text,newline='')),1):
        if line<first_row or not any(value.strip() for value in record):continue
        item={key:record[indices[key]].strip() if key in indices and indices[key]<len(record) else '' for key in ('employee','staff','name','email')}
        item['line']=line;rows.append(item)
    return rows

def plan_employee_import(rows,role,mapping,contacts):
    if role not in ('linking','attendance'):raise ValueError('CSVの用途が不正です。')
    new_mapping=copy.deepcopy(mapping);data=copy.deepcopy(contacts);pairs=defaultdict(set);owners=defaultdict(set);emails=defaultdict(set)
    unique=[];seen=set()
    for row in rows:
        signature=tuple(row.get(key,'') for key in ('employee','staff','name','email'))
        if signature in seen:continue
        seen.add(signature);unique.append(row)
        eid,sid=row['employee'],row['staff']
        if eid and sid:pairs[eid].add(sid);owners[sid].add(eid)
        if eid and sid and row['email']:emails[eid,sid].add(row['email'])
    results=[];names=data.setdefault('employee_names',{});candidates={r['staff']:dict(r) for r in data.get('staff_candidates',[]) if r.get('staff')}
    for row in unique:
        item=dict(row);eid,sid=row['employee'],row['staff'];status='';linked=False
        if sid:candidates[sid]={key:row[key] for key in ('employee','staff','name')}
        if not sid:status='スタッフID空欄'
        elif not eid:
            saved=[e for e,s in new_mapping.items() if str(s).strip()==sid]
            if role=='attendance' and len(saved)==1:eid=saved[0];linked=True;status='保存済みID一致'
            else:status='社員ID未指定・候補として保持'
        elif len(pairs[eid])>1 or len(owners[sid])>1:status='CSV内のID重複・競合'
        elif eid in new_mapping and str(new_mapping[eid]).strip() and str(new_mapping[eid]).strip()!=sid:status='既存スタッフIDと不一致'
        elif any(e!=eid and str(s).strip()==sid for e,s in new_mapping.items()):status='スタッフIDが別社員へ割当済み'
        else:
            new_mapping[eid]=sid;linked=True;status='ID一致' if mapping.get(eid)==sid else 'IDを紐付け'
        if eid and row['name']:names.setdefault(eid,row['name'])
        item['employee']=eid;item['matched']=False
        if linked and role=='linking':
            if len(emails[eid,sid])>1:status+='・メール競合'
            elif valid_email(row['email']):item['matched']=True;status+='・メール一致'
            else:status+='・メール空欄/不正'
        elif linked:status+='（メール変更なし）'
        item['status']=status;item['id_matched']=linked;results.append(item)
    if role=='linking':data=merged_contacts(data,results,data.get('import_settings',{}))
    data['employee_names']=names;data['staff_candidates']=list(candidates.values())
    return new_mapping,data,results

def show_employee_import_dialog(parent,mapping,contacts,cfg):
    from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QGridLayout,QGroupBox,QLabel,QLineEdit,QSpinBox,QComboBox,QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,QFileDialog,QMessageBox
    from ui_theme import button,refresh_button_icons
    dlg=QDialog(parent);dlg.setWindowTitle('社員情報を読み込む');dlg.resize(1080,730)
    root=QVBoxLayout(dlg);root.setContentsMargins(20,18,20,16);root.setSpacing(12)
    title=QLabel('社員情報を読み込む');title.setObjectName('pageTitle');root.addWidget(title)
    role=QComboBox();role.setObjectName('informationCsvRole');role.addItem('紐付け用CSV（ID・メールアドレス）','linking');role.addItem('勤怠用CSV（勤怠照合 兼 IDのみ紐付け）','attendance');root.addWidget(role)
    box=QGroupBox('CSVと列の指定');content=QVBoxLayout(box);root.addWidget(box)
    line=QHBoxLayout();filename=QLineEdit();filename.setObjectName('informationCsvPath');filename.setPlaceholderText('社員情報を読み込むCSVを選択');choose=button('CSVを選択','folder');line.addWidget(filename,1);line.addWidget(choose);content.addLayout(line)
    def browse():
        value,_=QFileDialog.getOpenFileName(dlg,'社員情報のCSVを選択','','CSV (*.csv)')
        if value:filename.setText(value)
    choose.clicked.connect(browse);grid=QGridLayout();fields={}
    for col,(key,title) in enumerate([('employee','社員ID列'),('staff','スタッフID列'),('name','名前列'),('email','メール列')]):
        edit=QLineEdit();edit.setObjectName('informationColumn_'+key);edit.setMaximumWidth(150);fields[key]=edit;grid.addWidget(QLabel(title),0,col);grid.addWidget(edit,1,col)
    content.addLayout(grid);options=QHBoxLayout();first=QSpinBox();first.setRange(1,1048576);first.setMaximumWidth(100);encoding=QComboBox();encoding.addItems(['auto','utf-8-sig','cp932'])
    options.addWidget(QLabel('開始行'));options.addWidget(first);options.addWidget(QLabel('文字コード'));options.addWidget(encoding);options.addStretch();check=button('照合して確認','check','primary');options.addWidget(check);content.addLayout(options)
    description=QLabel();description.setWordWrap(True);root.addWidget(description)
    summary=QLabel('列を指定して照合結果を確認してください。');root.addWidget(summary)
    table=QTableWidget(0,6);table.setObjectName('informationPreview');table.setHorizontalHeaderLabels(['CSV行','社員ID','スタッフID','名前','メール','照合結果']);table.setEditTriggers(QAbstractItemView.NoEditTriggers);table.verticalHeader().hide();table.setAlternatingRowColors(True);table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);table.horizontalHeader().setSectionResizeMode(4,QHeaderView.Stretch);root.addWidget(table,1)
    buttons=QHBoxLayout();buttons.addStretch();cancel=button('キャンセル','x');apply=button('一覧に反映','check','primary');apply.setEnabled(False);buttons.addWidget(cancel);buttons.addWidget(apply);root.addLayout(buttons)
    state={};result=None
    def invalidate(*args):state.clear();apply.setEnabled(False)
    def configure(*args):
        purpose=role.currentData();saved=contacts.get('employee_import_settings',{}).get(purpose,{})
        defaults={'employee':'A','staff':'B','name':'C','email':'D'} if purpose=='linking' else {'employee':'','staff':cfg.get('csv_columns',{}).get('staff','D'),'name':cfg.get('csv_columns',{}).get('name','E'),'email':''}
        for key,edit in fields.items():edit.setText(saved.get('columns',defaults).get(key,''));edit.setEnabled(key!='email' or purpose=='linking')
        first.setValue(saved.get('first_row',cfg.get('csv_first_row',2) if purpose=='attendance' else 2));encoding.setCurrentText(saved.get('encoding','auto'))
        description.setText('社員IDとスタッフIDの組を確認し、IDとメールをまとめて紐付けます。既存IDの競合は自動で上書きしません。' if purpose=='linking' else '勤怠データとしても使うCSVです。メールは変更しません。社員ID列がない場合は空欄にし、スタッフIDを候補として取り込みます。')
        invalidate()
    role.currentIndexChanged.connect(configure)
    for edit in [filename,*fields.values()]:edit.textChanged.connect(invalidate)
    first.valueChanged.connect(invalidate);encoding.currentTextChanged.connect(invalidate)
    def preview():
        invalidate()
        try:
            config={'columns':{k:e.text().strip().upper() for k,e in fields.items()},'first_row':first.value(),'encoding':encoding.currentText()};purpose=role.currentData()
            rows=read_information_csv(filename.text(),purpose,**config);new_mapping,data,results=plan_employee_import(rows,purpose,mapping,contacts)
            data.setdefault('csv_sources',{})[source_key(filename.text())]=purpose;data.setdefault('employee_import_settings',{})[purpose]=config
            state.update(mapping=new_mapping,contacts=data,results=results);table.setRowCount(len(results))
            for i,item in enumerate(results):
                for col,key in enumerate(['line','employee','staff','name','email','status']):table.setItem(i,col,QTableWidgetItem(str(item[key])))
            summary.setText(f'社員情報 {len(results)}件 / ID紐付け可能 {sum(r["id_matched"] for r in results)}件 / メール紐付け可能 {sum(r["matched"] for r in results)}件');apply.setEnabled(bool(results))
        except Exception as exc:QMessageBox.warning(dlg,'社員情報を読み込めません',str(exc))
    def accept():
        nonlocal result
        if state:result=state.copy();dlg.accept()
    check.clicked.connect(preview);apply.clicked.connect(accept);cancel.clicked.connect(dlg.reject);configure();refresh_button_icons(dlg,getattr(parent,'is_dark',False))
    try:dlg.exec();return result
    finally:dlg.deleteLater()

def validate_information_rows(selections):
    result={};seen=set()
    for i,(eid,sid,name,email) in enumerate(selections):
        if not eid and not sid and not email:continue
        if not eid:raise ValueError(f'{i+1}行目の社員IDが空欄です。')
        if eid in seen:raise ValueError('社員IDの重複：'+eid)
        seen.add(eid)
        if email and not sid:raise ValueError('メールを紐付けるスタッフIDを指定してください：'+eid)
        if sid:result[eid]=sid
    ids=list(result.values())
    if len(ids)!=len(set(ids)):raise ValueError('同じスタッフIDが複数の社員に割り当てられています。')
    return result

def contacts_for_mapping(contacts,mapping):
    data=copy.deepcopy(contacts);active=[];candidates={r['email']:dict(r) for r in data.get('unlinked_contacts',[])}
    for row in data['contacts']:
        if mapping.get(row['employee'])==row['staff']:active.append(row)
        elif valid_email(row['email']):candidates[row['email']]=row
    used={r['email'] for r in active};data['contacts']=active;data['unlinked_contacts']=[r for email,r in candidates.items() if email not in used]
    return data
