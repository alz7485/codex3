"""Offline manual, distribution, startup isolation and future JSON fields."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import copy,json,tempfile,unittest,sys,subprocess,struct
from pathlib import Path
from html.parser import HTMLParser
from unittest.mock import patch
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QDialog
import runtime_paths
_import_dir=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(_import_dir.name)):
 import main
import manual,build_onedir
from engine import load_json,save_json,DEFAULT

class DocumentLinks(HTMLParser):
 def __init__(self):super().__init__();self.ids=set();self.refs=[];self.images=[];self.headings=0
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.add(a['id'])
  if tag=='h2':self.headings+=1
  if tag=='a' and 'href' in a:self.refs.append(a['href'])
  if tag=='img' and a.get('src'):self.images.append((a.get('src'),a.get('alt')))

class Manual39(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='attendsync-manual-');self.addCleanup(self.tmp.cleanup);self.base=Path(self.tmp.name)
  self.paths=patch.multiple(main,CONFIG=self.base/'settings.json',MAP=self.base/'map.json',DB=self.base/'cache.db');self.paths.start();self.addCleanup(self.paths.stop)
  self.w=main.Window();self.w.show();self.app.processEvents();self.addCleanup(self.w.close)
 def test_button_opens_local_url_with_spaces_and_japanese(self):
  base=self.base/'資料 と アプリ';(base/'Manual').mkdir(parents=True);path=base/'Manual/index.html';path.write_text('<h1>操作ガイド</h1>')
  with patch.object(manual,'application_dir',return_value=base),patch.object(manual.QDesktopServices,'openUrl',return_value=True) as opener:
   self.w.btn_manual.click()
  opener.assert_called_once();url=opener.call_args.args[0];self.assertTrue(url.isLocalFile());self.assertEqual(Path(url.toLocalFile()),path.resolve())
 def test_f1_opens_same_manual(self):
  self.w.activateWindow();self.w.setFocus();self.app.processEvents()
  with patch.object(manual,'open_manual',return_value=True) as opener:
   QTest.keyClick(self.w,Qt.Key_F1);self.app.processEvents()
  opener.assert_called_once_with(self.w)
 def test_missing_manual_reports_error_without_starting_browser(self):
  with patch.object(manual,'application_dir',return_value=self.base),patch.object(manual.QDesktopServices,'openUrl') as opener,patch.object(manual.QMessageBox,'warning') as warning:
   self.assertFalse(self.w.open_manual())
  opener.assert_not_called();warning.assert_called_once();self.assertIn('Manual',warning.call_args.args[2])
 def test_browser_failure_keeps_application_usable(self):
  before=copy.deepcopy(self.w.cfg)
  with patch.object(manual.QDesktopServices,'openUrl',return_value=False),patch.object(manual.QMessageBox,'warning') as warning:self.assertFalse(self.w.open_manual())
  warning.assert_called_once();self.assertEqual(self.w.cfg,before);self.assertTrue(self.w.run_button.isEnabled())
 def test_browser_exception_is_reported(self):
  with patch.object(manual.QDesktopServices,'openUrl',side_effect=RuntimeError('no browser')),patch.object(manual.QMessageBox,'warning') as warning:self.assertFalse(self.w.open_manual())
  warning.assert_called_once()
 def test_manual_all_images_and_navigation_are_local_and_present(self):
  folder=Path(__file__).parent/'Manual';parser=DocumentLinks();parser.feed((folder/'index.html').read_text())
  self.assertEqual(parser.headings,19);self.assertEqual(len(parser.images),19)
  for ref in parser.refs:
   if ref.startswith('#'):self.assertIn(ref[1:],parser.ids)
   else:self.assertNotIn('://',ref);self.assertTrue((folder/ref).is_file(),ref)
  for src,alt in parser.images:
   self.assertTrue(alt);self.assertFalse(src.startswith(('http:','https:')))
   data=(folder/src).read_bytes();self.assertEqual(data[:8],b'\x89PNG\r\n\x1a\n');width,height=struct.unpack('>II',data[16:24]);self.assertGreater(width,400);self.assertGreater(height,300)
 def test_onedir_distribution_copies_complete_manual(self):
  output=self.base/'配布 フォルダ';output.mkdir()
  build_onedir.copy_manual(output);build_onedir.copy_manual(output)
  source=Path(__file__).parent/'Manual'
  for p in source.rglob('*'):
   if p.is_file():self.assertEqual((output/'Manual'/p.relative_to(source)).read_bytes(),p.read_bytes())
  with patch.object(manual,'application_dir',return_value=output),patch.object(manual.QDesktopServices,'openUrl',return_value=True) as opener:self.assertTrue(self.w.open_manual())
  self.assertEqual(Path(opener.call_args.args[0].toLocalFile()),(output/'Manual/index.html').resolve())
 def test_build_rejects_missing_manual(self):
  with patch.object(build_onedir,'ROOT',self.base):
   with self.assertRaises(SystemExit):build_onedir.copy_manual(self.base/'dist')
 def test_startup_does_not_import_manual_or_read_input_folder(self):
  script='''import sys,tempfile,json
from pathlib import Path
import runtime_paths
from PySide6.QtWidgets import QApplication
with tempfile.TemporaryDirectory() as t:
 runtime_paths.get_data_dir=lambda:Path(t)
 import main
 cfg=json.loads(json.dumps(main.DEFAULT));cfg['folder']=t
 (Path(t)/'settings.json').write_text(json.dumps(cfg))
 def denied(*a,**kw):raise AssertionError('Input read during startup')
 main.xlsx_read=denied;main.csv_read=denied;main.ReadWorker.start=denied
 app=QApplication([]);w=main.Window();w.show();app.processEvents()
 assert w.worker is None
 assert 'manual' not in sys.modules
 w.close()
 print('PASS no input scan / no manual import at startup')
'''
  result=subprocess.run([sys.executable,'-c',script],cwd=Path(__file__).parent,capture_output=True,text=True,timeout=15)
  self.assertEqual(result.returncode,0,result.stderr);self.assertIn('PASS',result.stdout)
 def test_future_columns_names_and_comparisons_persist_in_json(self):
  cfg=copy.deepcopy(DEFAULT);cfg['future_plugin']={'keep':'unknown'}
  d=main.SettingsDialog(self.w,cfg);self.addCleanup(d.close)
  xkey=d.add_source_field('xlsx_columns','未開示のExcel項目','V');ckey=d.add_source_field('csv_columns','未開示のCSV項目','O')
  d.add_compare(dict(name='後から追加した照合',xlsx=xkey,csv=ckey,type='text',enabled=True));d.accept();self.assertEqual(d.result(),QDialog.Accepted,d.error_label.text())
  save_json(main.CONFIG,d.value);stored=load_json(main.CONFIG,DEFAULT)
  self.assertEqual(stored['xlsx_columns'][xkey],'V');self.assertEqual(stored['csv_columns'][ckey],'O');self.assertEqual(stored['field_labels']['xlsx_columns'][xkey],'未開示のExcel項目')
  self.assertEqual(stored['comparisons'][-1]['xlsx'],xkey);self.assertEqual(stored['comparisons'][-1]['csv'],ckey);self.assertEqual(stored['future_plugin'],cfg['future_plugin'])
  reopened=main.SettingsDialog(self.w,stored);self.addCleanup(reopened.close);reopened.accept();self.assertEqual(reopened.value,stored)

if __name__=='__main__':unittest.main(verbosity=2)
