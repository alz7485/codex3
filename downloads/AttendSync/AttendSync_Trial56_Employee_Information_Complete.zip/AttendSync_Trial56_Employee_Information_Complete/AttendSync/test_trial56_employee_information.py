import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import copy,tempfile,json,base64,unittest
from pathlib import Path
from unittest.mock import patch
from employee_information import (read_information_csv,plan_employee_import,commit_employee_information,recover_employee_save,excluded_link_csv_paths,source_key,show_employee_import_dialog,contacts_for_mapping,validate_information_rows)
from employee_contacts import email_for,load_contacts,selected_email
from engine import DEFAULT,save_json
from PySide6.QtWidgets import QApplication,QLineEdit,QPushButton,QTableWidget,QComboBox,QCheckBox,QTabWidget
from PySide6.QtCore import QTimer
import runtime_paths
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):import main
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
EMPTY={'version':1,'contacts':[],'import_settings':{}}
class Information(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.folder=Path(self.tmp.name)
 def row(self,eid='0001',sid='S01',name='確認社員',email='one@example.com'):return dict(employee=eid,staff=sid,name=name,email=email,line=2)
 def source(self):
  path=self.folder/'社員.csv';path.write_text('社員,スタッフ,名前,メール\n0001,S01,確認社員,one@example.com\n',encoding='utf-8-sig');return path
 def test_link_csv_creates_both_id_and_mail(self):
  rows=read_information_csv(self.source(),'linking',{'employee':'A','staff':'B','name':'C','email':'D'})
  mapping,data,results=plan_employee_import(rows,'linking',{},EMPTY)
  self.assertEqual(mapping,{'0001':'S01'});self.assertEqual(email_for(data,'0001','S01'),'one@example.com');self.assertTrue(results[0]['id_matched'])
 def test_conflicting_existing_id_never_overwritten(self):
  mapping,data,results=plan_employee_import([self.row()],'linking',{'0001':'OTHER'},EMPTY)
  self.assertEqual(mapping,{'0001':'OTHER'});self.assertFalse(results[0]['matched']);self.assertFalse(data['contacts']);self.assertEqual(len(data['unlinked_contacts']),1)
 def test_duplicate_staff_or_employee_rejected(self):
  for rows in [[self.row(),self.row(sid='S02')],[self.row(),self.row(eid='0002')]]:
   mapping,data,results=plan_employee_import(rows,'linking',{},EMPTY);self.assertEqual(mapping,{});self.assertFalse(any(r['id_matched'] for r in results))
 def test_attendance_repeated_days_only_create_one_id_no_mail(self):
  rows=[self.row(),self.row()];mapping,data,results=plan_employee_import(rows,'attendance',{},EMPTY)
  self.assertEqual(mapping,{'0001':'S01'});self.assertEqual(data['contacts'],[]);self.assertEqual(len(results),1)
 def test_attendance_without_employee_id_is_manual_candidate(self):
  mapping,data,results=plan_employee_import([self.row(eid='',email='')],'attendance',{},EMPTY)
  self.assertEqual(mapping,{});self.assertEqual(data['staff_candidates'][0]['staff'],'S01');self.assertFalse(results[0]['id_matched'])
 def test_attendance_does_not_change_saved_mail(self):
  old={**EMPTY,'contacts':[{k:v for k,v in self.row().items() if k!='line'}]}
  mapping,data,_=plan_employee_import([self.row(email='different@example.com')],'attendance',{'0001':'S01'},old)
  self.assertEqual(email_for(data,'0001','S01'),'one@example.com')
 def test_two_file_save_failure_rolls_back_both(self):
  mp=self.folder/'staff_mapping.json';cp=self.folder/'employee_contacts.json';save_json(mp,{'old':'old'});save_json(cp,EMPTY);before=(mp.read_bytes(),cp.read_bytes())
  def writer(path,value):
   if path==mp:raise PermissionError('injected second write failure')
   save_json(path,value)
  with self.assertRaises(PermissionError):commit_employee_information(mp,cp,{'new':'new'},{**EMPTY,'contacts':[],'extra':'new'},writer)
  self.assertEqual((mp.read_bytes(),cp.read_bytes()),before);self.assertFalse((self.folder/'employee_save_transaction.json').exists())
 def test_crash_recovery_restores_saved_snapshot(self):
  mp=self.folder/'staff_mapping.json';cp=self.folder/'employee_contacts.json';save_json(mp,{'old':'old'});save_json(cp,EMPTY)
  old={key:base64.b64encode(path.read_bytes()).decode() for key,path in [('mapping',mp),('contacts',cp)]}
  save_json(self.folder/'employee_save_transaction.json',old);save_json(mp,{'wrong':'wrong'});save_json(cp,{**EMPTY,'wrong':1});recover_employee_save(mp,cp)
  self.assertEqual(json.loads(mp.read_text()),{'old':'old'});self.assertEqual(load_contacts(cp),EMPTY)
 def test_link_csv_excluded_from_attendance_reader(self):
  folder=self.folder/'input';folder.mkdir();daily=folder/'daily.csv';daily.write_text('date,calendar,x,staff,name,x,x,x,x,x,start,end,work,break\n20261001,0,,S01,TEST,,,,,,09:00,18:00,08:00,01:00\n')
  link=folder/'link.csv';link.write_text('employee,staff,name,email\nE1,S01,TEST,test@example.com\n')
  cp=self.folder/'employee_contacts.json';save_json(cp,{**EMPTY,'csv_sources':{source_key(link):'linking',source_key(daily):'attendance'}})
  self.assertEqual(excluded_link_csv_paths(cp),{source_key(link)})
  with patch.object(main,'DB',self.folder/'cache.sqlite'):
   worker=main.ReadWorker(folder,DEFAULT);results=[];worker.result.connect(lambda *args:results.append(args));worker.run()
  self.assertEqual(len(results[0][1]),1);self.assertEqual(results[0][3]['files_found'],1)
 def test_changed_id_releases_old_mail_to_candidates(self):
  data={**EMPTY,'contacts':[{k:v for k,v in self.row().items() if k!='line'}]};new=contacts_for_mapping(data,{'0001':'NEW'})
  self.assertEqual(new['contacts'],[]);self.assertEqual(new['unlinked_contacts'][0]['email'],'one@example.com')
 def test_import_dialog_stages_information_without_saving(self):
  errors=[];window=main.Window()
  def operate():
   dialog=APP.activeModalWidget()
   try:
    dialog.findChild(QLineEdit,'informationCsvPath').setText(str(self.source()));next(b for b in dialog.findChildren(QPushButton) if b.text()=='照合して確認').click();next(b for b in dialog.findChildren(QPushButton) if b.text()=='一覧に反映').click()
   except Exception as exc:errors.append(exc);dialog.reject()
  QTimer.singleShot(0,operate);result=show_employee_import_dialog(window,{},copy.deepcopy(EMPTY),DEFAULT)
  self.assertFalse(errors,errors);self.assertEqual(result['mapping'],{'0001':'S01'});self.assertEqual(email_for(result['contacts'],'0001','S01'),'one@example.com');self.assertFalse((self.folder/'staff_mapping.json').exists());window.close()
 def test_unified_editor_saves_new_id_and_email_together(self):
  with patch.multiple(main,CONFIG=self.folder/'settings.json',MAP=self.folder/'staff_mapping.json',DB=self.folder/'cache.sqlite'):
   window=main.Window();window.loaded_xdata={'0001':{'info':{'name':'確認社員'}}};errors=[]
   def operate():
    dialog=APP.activeModalWidget()
    try:
     self.assertFalse(dialog.findChildren(QTabWidget));self.assertEqual(dialog.findChild(QComboBox,'employeeFilter').currentData(),'all');table=dialog.findChild(QTableWidget,'employeeIdTable');self.assertEqual(table.columnCount(),4);table.cellWidget(0,2).setEditText('S01');table.cellWidget(0,3).setEditText('one@example.com');next(b for b in dialog.findChildren(QPushButton) if b.text()=='紐付けを保存').click()
    except Exception as exc:errors.append(exc);dialog.reject()
   with patch.object(window,'run_read'):
    QTimer.singleShot(0,operate);window.edit_map();APP.processEvents()
   self.assertFalse(errors,errors);self.assertEqual(window.mapping,{'0001':'S01'});self.assertEqual(email_for(load_contacts(self.folder/'employee_contacts.json'),'0001','S01'),'one@example.com');window.close()
 def test_cancel_after_import_does_not_write_mapping_or_contacts(self):
  with patch.multiple(main,CONFIG=self.folder/'settings.json',MAP=self.folder/'staff_mapping.json',DB=self.folder/'cache.sqlite'):
   window=main.Window();errors=[]
   def wizard():
    dialog=APP.activeModalWidget();dialog.findChild(QLineEdit,'informationCsvPath').setText(str(self.source()));next(b for b in dialog.findChildren(QPushButton) if b.text()=='照合して確認').click();next(b for b in dialog.findChildren(QPushButton) if b.text()=='一覧に反映').click()
   def editor():
    dialog=APP.activeModalWidget()
    try:
     QTimer.singleShot(0,wizard);next(b for b in dialog.findChildren(QPushButton) if b.text()=='社員情報を読み込む').click();table=dialog.findChild(QTableWidget,'employeeIdTable');self.assertEqual(table.rowCount(),1);self.assertEqual(selected_email(table.cellWidget(0,3)),'one@example.com')
    except Exception as exc:errors.append(exc)
    finally:dialog.reject()
   QTimer.singleShot(0,editor);window.edit_map();self.assertFalse(errors,errors);self.assertEqual(window.mapping,{});self.assertFalse(main.MAP.exists());self.assertFalse(main.MAP.with_name('employee_contacts.json').exists());window.close()
 def test_mode_can_be_changed_in_mail_creation_screen(self):
  from outlook_mail import show_mail_dialog
  from test_trial54_mail import Mail
  for initial in (False,True):
   fixture=Mail();settings=fixture.settings(initial);window=main.Window();calls=[];observed=[];attempts=[0]
   def transport(token,method,path,payload=None):calls.append(path);return {'_http_status':202} if path.endswith('/send') else {'id':'synthetic'}
   def auth(config,data_dir):observed.append(config['auto_send']);return 'synthetic-token'
   expected='送信受付済み' if not initial else '下書き保存済み'
   def finish():
    attempts[0]+=1;dialog=APP.activeModalWidget()
    if dialog.findChild(QTableWidget).item(0,3).text()==expected:dialog.reject();return
    if attempts[0]>100:dialog.reject();return
    QTimer.singleShot(20,finish)
   def operate():
    dialog=APP.activeModalWidget();dialog.findChild(QCheckBox,'mailAutoSend').setChecked(not initial);label='選択したメールを送信' if not initial else 'Outlookの下書きを作成';next(b for b in dialog.findChildren(QPushButton) if b.text()==label).click();QTimer.singleShot(20,finish)
   with tempfile.TemporaryDirectory() as folder,patch('microsoft_mail.authenticate',side_effect=auth),patch('microsoft_mail.graph_request',side_effect=transport),patch('PySide6.QtWidgets.QMessageBox.information'),patch('PySide6.QtWidgets.QMessageBox.warning'):
    QTimer.singleShot(0,operate);show_mail_dialog(window,[fixture.plans()[0]],settings,folder)
   self.assertEqual(observed,[not initial]);self.assertEqual(any(path.endswith('/send') for path in calls),not initial);self.assertEqual(settings['auto_send'],initial);window.close()
if __name__=='__main__':unittest.main(verbosity=2)
