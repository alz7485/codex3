from pathlib import Path
import os
import sys
import tempfile

def application_dir():
    # PyInstaller onedir: executable is in dist/AttendSync/.
    # Source mode: directory containing this file.
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

def get_data_dir():
    portable = application_dir() / 'userdata'
    try:
        portable.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryFile(dir=portable) as probe:
            probe.write(b'ok');probe.flush()
        return portable
    except (OSError, PermissionError):
        fallback = Path(os.getenv('LOCALAPPDATA') or Path.home()) / 'AttendSync'
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback
