from pathlib import Path
s=Path(__file__).with_name("main.py").read_text(encoding="utf-8")
assert "unlinked=button('すべて表示','users')" in s
assert "unlinked.setText('すべて表示' if showing_unlinked else '未紐づけを表示')" in s
assert "table.setRowHidden(i,showing_unlinked and bool(sid and sid!='未紐付け'))" in s
print("Trial27 toggle-label static test OK")
