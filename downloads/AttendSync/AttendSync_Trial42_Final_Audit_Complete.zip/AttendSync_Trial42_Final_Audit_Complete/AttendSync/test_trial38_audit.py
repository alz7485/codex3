"""Audit regressions: result settings, print period, extensions and detail semantics."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from PySide6.QtCore import QObject,Signal,QTimer,Qt
from PySide6.QtWidgets import QApplication,QDialog,QCheckBox,QTableWidget,QPushButton
import runtime_paths
_import_temp=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(_import_temp.name)):
 import main
from engine import DEFAULT,xlsx_read,csv_read,reconcile,validate_config

class WorkerSignal(QObject):
 result=Signal(object,object,object,object)
 def __init__(self,cfg):super().__init__();self.cfg=copy.deepcopy(cfg)
 def isInterruptionRequested(self):return False
 def isRunning(self):return False

class Audit38(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.app=QApplication.instance() or QApplication([])
  cls.xdata={};cls.cdata=[]
  for p in (Path(__file__).parent/'SampleData').glob('*.xlsx'):
   d=xlsx_read(p,DEFAULT);cls.xdata[d['info']['employee']]=d
  for p in (Path(__file__).parent/'SampleData').glob('*.csv'):cls.cdata+=csv_read(p,DEFAULT)['records']
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);p=Path(self.tmp.name)
  self.paths=patch.multiple(main,CONFIG=p/'settings.json',MAP=p/'mapping.json',DB=p/'cache.sqlite3');self.paths.start();self.addCleanup(self.paths.stop)
  self.w=main.Window();self.w.cfg=copy.deepcopy(DEFAULT);self.w.mapping={'10001':'S001','10002':'S002','10003':'S003','10004':'S004'}
  self.addCleanup(self.w.close)
 def load_results(self,worker=False):
  stats=dict(elapsed=0.1,cache_hits=0,parsed=6,files_found=6,files_completed=6)
  if worker:
   self.w.worker=WorkerSignal(self.w.cfg);self.w.worker.result.connect(self.w.read_done)
   return lambda:self.w.worker.result.emit(self.xdata,self.cdata,[],stats)
  self.w.read_done(self.xdata,self.cdata,[],stats)
 def test_print_uses_completed_period_after_controls_change(self):
  self.load_results();self.w.year.setValue(2027);self.w.month.setValue(1)
  with patch.object(main,'print_html') as printer:self.w.print_list(preview=True)
  self.assertIn('2026年10月度',printer.call_args.args[1]);self.assertNotIn('2027年1月度',printer.call_args.args[1])
 def test_excel_jump_uses_columns_from_completed_read(self):
  self.load_results();self.w.cfg['xlsx_columns']['work']='V'
  row=next(r for r in self.w.results if r['xlsx_key']=='work')
  with patch.object(main,'open_source_cell') as jump:self.w.open_excel_source(row['xrecord'],'work')
  self.assertEqual(jump.call_args.args[1],'T')
 def test_detail_uses_completed_comparisons_not_pending_settings(self):
  self.load_results();self.w.cfg['comparisons'][0]['name']='次の読み込み用';self.w.table.selectRow(0)
  with patch.object(main,'DetailDialog') as dialog:
   dialog.return_value.exec.return_value=QDialog.Rejected;self.w.open_detail()
  cfg=dialog.call_args.args[2]
  self.assertEqual(cfg['comparisons'][0]['name'],'始業時刻');self.assertEqual(self.w.cfg['comparisons'][0]['name'],'次の読み込み用')
 def test_completion_reconciles_with_worker_settings_snapshot(self):
  emit=self.load_results(worker=True)
  self.w.cfg['xlsx_columns']['extra']='V';self.w.cfg['csv_columns']['extra']='O'
  self.w.cfg['comparisons'].append(dict(name='次回の追加項目',xlsx='extra',csv='extra',type='text',enabled=True))
  emit()
  self.assertEqual(len(self.w.results),360)
  self.assertFalse(any(r['field']=='次回の追加項目' for r in self.w.results))
  self.assertEqual(self.w.cfg['comparisons'][-1]['name'],'次回の追加項目')
 def edit_detail_visibility(self,detail):
  errors=[]
  def accept():
   try:
    dialog=self.app.activeModalWidget();checks=dialog.findChildren(QCheckBox);self.assertTrue(checks);checks[0].setChecked(False);dialog.accept()
   except Exception as e:errors.append(e);self.app.activeModalWidget().reject()
  QTimer.singleShot(0,accept);detail.edit_visible_fields();self.assertFalse(errors,errors)
 def test_detail_visibility_save_preserves_unknown_keys_and_pending_settings(self):
  self.load_results();cfg=copy.deepcopy(self.w.cfg);cfg['detail_visible_fields']=['start|start','plugin|future'];self.w.cfg['detail_visible_fields']=list(cfg['detail_visible_fields'])
  detail=main.DetailDialog(self.w,self.w.results[0],cfg);self.addCleanup(detail.close)
  self.w.cfg['xlsx_columns']['start']='AA';self.w.cfg['plugin_extension']={'keep':17}
  self.edit_detail_visibility(detail)
  saved=json.loads(main.CONFIG.read_text())
  self.assertIn('plugin|future',saved['detail_visible_fields']);self.assertEqual(saved['xlsx_columns']['start'],'AA');self.assertEqual(saved['plugin_extension'],{'keep':17})
  self.assertIn('plugin|future',self.w.cfg['detail_visible_fields'])
 def test_enabled_comparison_controls_detail_label_and_format(self):
  cfg=copy.deepcopy(DEFAULT);cfg['comparisons'].append(dict(name='休憩の原値',xlsx='break_total',csv='break_total',type='text',enabled=True))
  x=copy.deepcopy(self.xdata);c=copy.deepcopy(self.cdata)
  x['10001']['records'][0]['values']['break_total']=0
  day=x['10001']['records'][0]['date'];next(r for r in c if r['staff']=='S001' and r['date']==day)['values']['break_total']='0:00'
  self.w.results,_=reconcile(x,c,self.w.mapping,cfg)
  row=next(r for r in self.w.results if r['employee']=='10001' and r['date']==day and r['field']=='休憩の原値')
  detail=main.DetailDialog(self.w,row,cfg);self.addCleanup(detail.close)
  i=next(i for i,f in enumerate(detail.detail_fields) if f[1:]==('break_total','break_total'))
  self.assertEqual(detail.detail_table.item(i,0).text(),'休憩の原値');self.assertEqual(detail.detail_table.item(i,1).text(),'0');self.assertTrue(detail.printflags[i])
 def test_multiple_enabled_comparisons_do_not_hide_mismatch(self):
  cfg=copy.deepcopy(DEFAULT);cfg['comparisons'][3]['enabled']=True;cfg['comparisons'].append(dict(name='休憩の原値',xlsx='break_total',csv='break_total',type='text',enabled=True))
  x=copy.deepcopy(self.xdata);c=copy.deepcopy(self.cdata)
  x['10001']['records'][0]['values']['break_total']=0
  day=x['10001']['records'][0]['date'];next(r for r in c if r['staff']=='S001' and r['date']==day)['values']['break_total']='0:00'
  self.w.results,_=reconcile(x,c,self.w.mapping,cfg)
  row=next(r for r in self.w.results if r['field']=='休憩の原値' and r['status']=='不一致')
  detail=main.DetailDialog(self.w,row,cfg);self.addCleanup(detail.close)
  i=next(i for i,f in enumerate(detail.detail_fields) if f[1:]==('break_total','break_total'))
  self.assertTrue(detail.printflags[i])
 def test_mapping_displays_name_from_info_for_employee_without_records(self):
  self.w.loaded_xdata={'10001':{'info':{'name':'空行の社員'},'records':[]}};self.w.mapping={'10001':'S001'};errors=[]
  def inspect():
   dialog=self.app.activeModalWidget()
   try:
    table=dialog.findChild(QTableWidget);self.assertEqual(table.item(0,1).text(),'空行の社員')
   except Exception as e:errors.append(e)
   finally:dialog.reject()
  QTimer.singleShot(0,inspect);self.w.edit_map();self.assertFalse(errors,errors)
 def test_cancelled_read_keeps_previous_period_and_source_columns(self):
  self.load_results();old=list(self.w.results)
  self.w.cfg['year']=2027;self.w.cfg['month']=1;self.w.cfg['xlsx_columns']['work']='V'
  self.w.worker=WorkerSignal(self.w.cfg);self.w.worker.result.connect(self.w.read_done)
  self.w.worker.result.emit({},[],[],{'cancelled':True})
  self.assertEqual(self.w.results,old);cfg=self.w.result_config()
  self.assertEqual((cfg['year'],cfg['month'],cfg['xlsx_columns']['work']),(2026,10,'T'))
 def test_null_detail_visibility_remains_show_all(self):
  self.load_results();self.w.cfg['detail_visible_fields']=None
  cfg=self.w.result_config();detail=main.DetailDialog(self.w,self.w.results[0],cfg);self.addCleanup(detail.close)
  self.assertTrue(all(not detail.detail_table.isRowHidden(i) for i in range(detail.detail_table.rowCount())))
 def test_failed_settings_write_does_not_replace_active_config(self):
  original=copy.deepcopy(self.w.cfg);updated=copy.deepcopy(original);updated['data_first_row']=12
  with patch.object(main,'SettingsDialog') as dialog,patch.object(main,'save_json',side_effect=PermissionError('read only')),patch.object(main.QMessageBox,'warning') as warning:
   dialog.return_value.exec.return_value=QDialog.Accepted;dialog.return_value.value=updated;self.w.edit_settings()
  self.assertEqual(self.w.cfg,original);warning.assert_called_once()
 def test_failed_detail_write_does_not_change_visibility_or_pending_config(self):
  self.load_results();cfg=self.w.result_config();detail=main.DetailDialog(self.w,self.w.results[0],cfg);self.addCleanup(detail.close)
  original=copy.deepcopy(self.w.cfg)
  with patch.object(main,'save_json',side_effect=PermissionError('read only')),patch.object(main.QMessageBox,'warning') as warning:self.edit_detail_visibility(detail)
  self.assertEqual(self.w.cfg,original);self.assertEqual(detail.cfg,cfg);warning.assert_called_once()
 def test_renamed_source_label_survives_selection_of_comparison_result(self):
  self.load_results();cfg=self.w.result_config();cfg['field_labels']={'xlsx_columns':{'start':'出勤の時刻'}}
  row=next(r for r in self.w.results if r['field']=='始業時刻')
  detail=main.DetailDialog(self.w,row,cfg);self.addCleanup(detail.close)
  i=next(i for i,f in enumerate(detail.detail_fields) if f[1:]==('start','start'))
  self.assertEqual(detail.detail_table.item(i,0).text(),'出勤の時刻')
 def test_real_excel_duration_over_24_hours_survives_cache_and_comparison(self):
  from datetime import timedelta
  from openpyxl import load_workbook
  import csv
  source=Path(self.xdata['10001']['records'][0]['file']);target=Path(self.tmp.name)/'duration.xlsx'
  book=load_workbook(source);ws=book['10月'];r=self.xdata['10001']['records'][0];ws[f'T{r["row"]}']=timedelta(hours=26);ws[f'T{r["row"]}'].number_format='[h]:mm';book.save(target);book.close()
  cfg=copy.deepcopy(DEFAULT)
  for entry in cfg['comparisons']:entry['enabled']=entry['xlsx']=='work'
  packet=xlsx_read(target,cfg);packet=json.loads(json.dumps(packet))
  csvpath=Path(self.tmp.name)/'duration.csv'
  with csvpath.open('w',encoding='utf-8',newline='') as f:
   writer=csv.writer(f);writer.writerow(['header']*14);values=['']*14;values[0]=r['date'].replace('-','');values[3]='S001';values[12]='26:00';writer.writerow(values)
  records=csv_read(csvpath,cfg)['records'];rows,_=reconcile({'10001':packet},records,{'10001':'S001'},cfg)
  comparison=next(row for row in rows if row['field']=='実働時間')
  self.assertEqual(comparison['status'],'一致');self.assertEqual(comparison['xlsx'],'26:00')
 def test_list_and_detail_print_tables_use_available_paper_width(self):
  from printing import make_document
  from PySide6.QtGui import QTextTable,QTextLength
  self.load_results();detail=main.DetailDialog(self.w,self.w.results[0],self.w.result_config());self.addCleanup(detail.close)
  for print_action in (lambda:self.w.print_list(preview=True),lambda:detail.do_print(preview=True)):
   with patch.object(main,'print_html') as printer:print_action()
   document=make_document(printer.call_args.args[1]);tables=[f for f in document.rootFrame().childFrames() if isinstance(f,QTextTable)]
   self.assertTrue(tables)
   self.assertEqual(tables[0].format().width().type(),QTextLength.PercentageLength);self.assertEqual(tables[0].format().width().rawValue(),100)
 def test_runtime_rejects_layout_outside_excel_bounds_and_missing_required_keys(self):
  for change in [lambda c:c['xlsx_columns'].update(start='XFE'),lambda c:c['info_cells'].update(employee='XFD1048577'),lambda c:c.update(data_last_row=1048577),lambda c:c['xlsx_columns'].pop('day'),lambda c:c['csv_columns'].update(staff='')]:
   with self.subTest(change=change):
    cfg=copy.deepcopy(DEFAULT);change(cfg);self.assertTrue(validate_config(cfg),cfg)

if __name__=='__main__':unittest.main(verbosity=2)
