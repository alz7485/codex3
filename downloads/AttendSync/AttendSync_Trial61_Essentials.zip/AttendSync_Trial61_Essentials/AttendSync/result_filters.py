"""Display-only filtering of missing CSV records for absent calendar months."""
from datetime import date, timedelta
from pathlib import Path


def iso_day(value):
    if not isinstance(value, str) or len(value) != 10:
        return None
    try:
        parsed = date.fromisoformat(value)
    except ValueError:
        return None
    return parsed if parsed.isoformat() == value else None


def csv_month_coverage(records, failures=(), warnings=()):
    # A broken CSV is not evidence that the file for that month is absent.
    if any(Path(str(item.get('file', ''))).suffix.casefold() == '.csv' for item in failures):
        return None
    for item in warnings:
        if (Path(str(item.get('file', ''))).suffix.casefold() == '.csv'
                and any(reason in str(item.get('reason', ''))
                        for reason in ('日付不正', 'IDまたは日付が空欄'))):
            return None
    return frozenset(day.strftime('%Y-%m') for record in records
                     if (day := iso_day(record.get('date'))) is not None)


def missing_csv_months(months, cfg):
    if not months:
        return frozenset()
    try:
        end = date(int(cfg['year']), int(cfg['month']), 15)
        start = (end.replace(day=1) - timedelta(days=1)).replace(day=16)
    except (KeyError, TypeError, ValueError, OverflowError):
        return frozenset()
    period_months = {start.strftime('%Y-%m'), end.strftime('%Y-%m')}
    # Keep review notices if none of the input months belongs to this period.
    return frozenset(period_months - months) if period_months & months else frozenset()


def is_missing_month_csv_gap(row, absent_months, cfg):
    if (not absent_months or row.get('status') != '要確認'
            or row.get('field') not in ('CSV記録なし', '期間整合性：CSV記録なし')
            or row.get('crecord') is not None):
        return False
    if (row.get('xrecord') or {}).get('invalid_fields'):
        return False
    day = iso_day(row.get('date'))
    if day is None or day.strftime('%Y-%m') not in absent_months:
        return False
    end = date(int(cfg['year']), int(cfg['month']), 15)
    start = (end.replace(day=1) - timedelta(days=1)).replace(day=16)
    return start <= day <= end
