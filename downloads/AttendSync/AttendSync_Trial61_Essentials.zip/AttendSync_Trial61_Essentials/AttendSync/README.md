# 勤怠チェッカー Trial61 必要ファイル版

実行・ビルド用ソース、アイコン、18ページ図解です。社員・勤怠の実データ、テスト・監査・サンプル、ビルド済みEXEは含みません。

Windows11 / Python3.11推奨。PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe build_onedir.py
```

ビルド後はdist\AttendSync全体を配布。旧userdataはバックアップ後に引き継ぎます。

最初に「社員情報」でCSVを選択・ドロップし「一覧に反映」→「社員情報を登録」で確定。その後、メインで勤怠を読み込みます。社員情報CSVの初期列はスタッフID=A、社員ID=B、氏名=C、メール=J。保存済み列指定は維持します。

「CSVが無い月度分は非表示」は初期ONです。前月または当月のCSVに記録がなければ、その年月のCSV記録なしによる要確認を一覧から隠します。OFFで全件へ戻せます。月内の個人別欠落・入力異常などは残し、全数と診断は維持します。印刷は表示中の一覧を対象にします。

図解：Manual/index.html。メール初回接続：Manual/Microsoft連携ガイド.html。メール自動送信の初期値はOFF。全48スクリプト成功。Windows EXE・実Excel・実Microsoft365認証と送信は未検証です。
