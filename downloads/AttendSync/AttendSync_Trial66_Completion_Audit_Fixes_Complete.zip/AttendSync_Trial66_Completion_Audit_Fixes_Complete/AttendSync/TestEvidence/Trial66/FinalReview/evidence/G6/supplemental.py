import json, re, sys, tempfile, sqlite3, unittest
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
from unittest.mock import patch
import probe
from PySide6.QtCore import Qt, QTimer
from engine import Cache

E = Path(__file__).parent
ROOT = probe.ROOT
OBS = {}

class Supplemental(unittest.TestCase):
    def test_queued_finished_worker_signals_after_save(self):
        p = probe.Probe('test_04_actual_save_resets_summary')
        p.setUp()
        try:
            payload = p.read()
            worker = probe.main.ReadWorker(p.src, p.cfg, True)
            p.win.worker = worker
            worker.progress.connect(p.win.on_progress, Qt.ConnectionType.QueuedConnection)
            worker.result.connect(p.win.read_done, Qt.ConnectionType.QueuedConnection)
            worker.progress.emit(2, 2, 'late synthetic completion')
            worker.result.emit(*payload)
            p.save_dialog()
            status = p.win.status.text()
            probe.APP.processEvents()
            self.assertFalse(worker.isRunning())
            self.assertFalse(worker.isInterruptionRequested())
            self.assertTrue(worker.results_invalidated)
            self.assertEqual(p.win.status.text(), status)
            self.assertEqual(p.win.progress.value(), 0)
            self.assertFalse(p.win.results)
            OBS['late_queued_signals'] = {'status': status, 'progress': 0, 'results': 0}
        finally:
            p.doCleanups()

    def test_readable_schema_bad_table_page(self):
        with tempfile.TemporaryDirectory(dir=E) as t:
            path = Path(t) / 'derived.sqlite3'
            c = Cache(path)
            c.db.execute('INSERT INTO cache VALUES(?,?,?)', ('synthetic', 'signature', 'x' * 20000))
            c.db.commit()
            rootpage = c.db.execute("SELECT rootpage FROM sqlite_master WHERE name='cache'").fetchone()[0]
            pagesize = c.db.execute('PRAGMA page_size').fetchone()[0]
            c.close()
            raw = bytearray(path.read_bytes())
            raw[(rootpage - 1) * pagesize] = 0
            path.write_bytes(raw)
            cx = sqlite3.connect(path)
            self.assertEqual(cx.execute("SELECT name FROM sqlite_master WHERE name='cache'").fetchone(), ('cache',))
            cx.close()
            recovered = Cache(path)
            self.assertEqual(recovered.db.execute('PRAGMA quick_check').fetchone(), ('ok',))
            self.assertEqual(recovered.db.execute('SELECT count(*) FROM cache').fetchone(), (0,))
            notice = recovered.recovery_notice
            recovered.close()
            backups = list(Path(t).glob('*.corrupt-*'))
            self.assertEqual(len(backups), 1)
            self.assertEqual(backups[0].read_bytes(), bytes(raw))
            OBS['interior_corruption'] = {'schema_readable': True, 'backup_exact': True, 'notice': notice}

    def test_manual_links_text_and_evidence_entry(self):
        class Parser(HTMLParser):
            def __init__(self):
                super().__init__(); self.refs=[]; self.ids=set(); self.sections=0
            def handle_starttag(self, tag, attrs):
                attrs=dict(attrs)
                if tag=='section': self.sections+=1
                if 'id' in attrs:self.ids.add(attrs['id'])
                for k in ['href','src']:
                    if k in attrs:self.refs.append(attrs[k])
        htmlpath=ROOT/'Manual/index.html'; parser=Parser(); source=htmlpath.read_text(); parser.feed(source)
        local=0
        for ref in parser.refs:
            url=urlsplit(ref)
            if url.scheme or url.netloc:continue
            if url.path:self.assertTrue((htmlpath.parent/unquote(url.path)).is_file(),ref);local+=1
            if not url.path and url.fragment:self.assertIn(url.fragment,parser.ids)
        pages=json.loads((ROOT/'Manual/guide_pages.json').read_text())
        self.assertEqual(len(pages),18);self.assertEqual(parser.sections,18)
        pdf=(E/'manual_pdf.txt').read_text()
        # Poppler extracts ReportLab's Japanese CID underscore as U+0332.
        compact=lambda x:re.sub(r'\s+','',x.replace('\u0332','_'))
        for _,title,subtitle,notes in pages:
            self.assertIn(compact(title),compact(pdf))
            for _,_,label,description in notes:
                self.assertIn(compact(description),compact(pdf))
        phrase='値（文字列完全一致）'
        self.assertIn(phrase,source);self.assertIn(phrase,pdf);self.assertNotIn('数値',pdf)
        for name in ['VALIDATION_TRIAL66.md','TestEvidence/Trial66/README.md','TestEvidence/Trial66/Regression/README.txt','TestEvidence/Trial66/FinalReview/README.txt']:
            self.assertTrue((ROOT/name).is_file())
        OBS['manual']={'sections':18,'local_refs_checked':local,'all_descriptions_in_pdf':True,'html_pdf_string_comparison':True,'final_materials':'README placeholders, pending parent packaging'}

    def test_actual_source_main_eventloop(self):
        with tempfile.TemporaryDirectory(dir=E) as t:
            data=Path(t)
            with patch.multiple(probe.main,CONFIG=data/'settings.json',MAP=data/'staff_mapping.json',DB=data/'attendance_cache.sqlite3'):
                QTimer.singleShot(300,probe.APP.quit)
                code=probe.main.main()
                self.assertEqual(code,0)
                windows=[w for w in probe.APP.topLevelWidgets() if isinstance(w,probe.main.Window)]
                self.assertTrue(windows)
                for w in windows:w.close()
                OBS['source_startup']={'main_returncode':code,'visible_windows_created':len(windows),'external_io':False}

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Supplemental))
    (E/'supplemental_results.json').write_text(json.dumps(OBS,ensure_ascii=False,indent=2))
    probe.TEMP.cleanup()
    sys.exit(not result.wasSuccessful())
