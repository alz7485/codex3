import os,sys,time,json,resource,copy,csv,hashlib,ast,threading
from pathlib import Path
from datetime import date,timedelta
from unittest.mock import patch
E=Path(__file__).resolve().parent
S=E.parent.parent/'copies/G4'
sys.path.insert(0,str(S))
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
state=E/('state_'+sys.argv[1]+'_'+str(time.time_ns()));state.mkdir(exist_ok=True)
import runtime_paths
runtime_paths.get_data_dir=lambda:state
from PySide6.QtWidgets import QApplication,QTableWidget,QComboBox,QPushButton,QLineEdit
from PySide6.QtCore import QTimer
import main
from engine import DEFAULT,save_json,reconcile
from employee_information import plan_employee_import,read_information_csv
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
def emit(**kw):
 print(json.dumps(dict(kw,rss_peak_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,loadavg=os.getloadavg()),ensure_ascii=False),flush=True)
def digest(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()
def contacts(n):
 return {'version':1,'contacts':[dict(employee=f'E{i:06}',staff=f'S{i:06}',name=f'Synthetic{i:06}',email=f'e{i}@example.invalid') for i in range(n)],'employee_names':{f'E{i:06}':f'Synthetic{i:06}' for i in range(n)},'staff_candidates':[dict(employee=f'E{i:06}',staff=f'S{i:06}',name=f'Synthetic{i:06}') for i in range(n)],'employee_information_registered':True}
def window(n):
 save_json(main.MAP,{f'E{i:06}':f'S{i:06}' for i in range(n)});save_json(main.MAP.with_name('employee_contacts.json'),contacts(n))
 with patch.object(main,'current_attendance_month',return_value=(2026,10)):w=main.Window()
 w.show();APP.processEvents();return w
def heartbeat():
 last=[time.perf_counter()];gaps=[];t=QTimer();t.setInterval(5)
 def beat():now=time.perf_counter();gaps.append(now-last[0]);last[0]=now
 t.timeout.connect(beat);t.start();return t,gaps,last
def editor():
 w=window(600);timer,gaps,last=heartbeat();errors=[];start=time.perf_counter();baseline=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 def inspect():
  d=APP.activeModalWidget()
  try:
   table=d.findChild(QTableWidget,'employeeIdTable');counts=[table.cellWidget(i,j).count() for i in range(600) for j in (2,3)]
   assert table.rowCount()==600 and sum(counts)==2400
   assert all(table.cellWidget(i,3).currentData()==f'e{i}@example.invalid' for i in range(600))
   emit(case='CA07_editor600',rows=table.rowCount(),all_options=sum(counts),mail_options=sum(table.cellWidget(i,3).count() for i in range(600)),max_options=max(counts),open_seconds=time.perf_counter()-start,heartbeat_gap=max([time.perf_counter()-last[0],*gaps]),rss_baseline_kib=baseline)
  except Exception as ex:errors.append(repr(ex))
  finally:d.reject()
 QTimer.singleShot(0,inspect);w.edit_map();APP.processEvents();timer.stop();w.close();assert not errors,errors
def imports():
 from employee_information import show_employee_import_dialog
 n=6000;rows=[dict(employee=f'E{i:06}',staff=f'S{i:06}',name=f'Synthetic{i:06}',email=f'e{i}@example.invalid') for i in range(n)]
 p=E/'employees6000.csv'
 with p.open('w',newline='') as f:
  out=csv.writer(f);out.writerow(['staff','employee','name','','','','','','','email'])
  for r in rows:out.writerow([r['staff'],r['employee'],r['name'],'','','','','','',r['email']])
 start=time.perf_counter();parsed=read_information_csv(p,'linking',columns=dict(staff='A',employee='B',name='C',email='J'),first_row=2,encoding='auto');parse_time=time.perf_counter()-start
 start=time.perf_counter();new=plan_employee_import(parsed,'linking',{},dict(contacts=[],unlinked_contacts=[]));elapsed=time.perf_counter()-start
 old=Path('/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/employee_information.py')
 tree=ast.parse(old.read_text());node=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='plan_employee_import')
 import employee_information as ei
 namespace=dict(ei.__dict__);exec(compile(ast.Module(body=[node],type_ignores=[]),str(old),'exec'),namespace)
 start=time.perf_counter();legacy=namespace['plan_employee_import'](parsed,'linking',{},dict(contacts=[],unlinked_contacts=[]));legacy_time=time.perf_counter()-start
 assert new==legacy and len(new[0])==n
 emit(case='CA08_plan6000',parse_seconds=parse_time,plan_seconds=elapsed,legacy_seconds=legacy_time,result_equal=True,result_digest=digest(new),mapped=len(new[0]))
 # Neighbouring conflict/name/duplicate behaviour must remain byte-equivalent.
 edge=parsed[:3]+[dict(parsed[0]),{**parsed[0],'name':'Other name'},{**parsed[1],'employee':'Different'},{**parsed[2],'email':'other@example.invalid'},dict(employee='',staff='orphan',name='Only Staff',email='')]
 mapping={'Existing':'busy','E000000':'old'}
 a=plan_employee_import(edge,'linking',mapping,contacts(1));b=namespace['plan_employee_import'](edge,'linking',mapping,contacts(1));assert a==b
 emit(case='CA08_conflict_equivalence',equal=True,unique_rows=len(a[2]),digest=digest(a))
 w=window(1);timer,gaps,last=heartbeat();errors=[];started=time.perf_counter();seen=[False]
 def inspect():
  d=APP.activeModalWidget();table=d.findChild(QTableWidget,'informationPreview') if d else None
  if table and table.rowCount():
   try:assert table.rowCount()==6000;seen[0]=True;emit(case='CA08_actual_dialog6000',rows=table.rowCount(),max_heartbeat_gap=max([time.perf_counter()-last[0],*gaps]),elapsed_with_debounce=time.perf_counter()-started)
   except Exception as ex:errors.append(repr(ex))
   finally:d.reject()
 poll=QTimer();poll.timeout.connect(inspect);poll.start(10);QTimer.singleShot(10000,lambda:APP.activeModalWidget().reject() if APP.activeModalWidget() else None)
 show_employee_import_dialog(w,{},dict(contacts=[],unlinked_contacts=[]),copy.deepcopy(DEFAULT),str(p));timer.stop();poll.stop();w.close();assert seen[0] and not errors,errors
def fixtures(n):
 from openpyxl import Workbook
 folder=E/'input120';folder.mkdir(exist_ok=True)
 if not (folder/'E000119.xlsx').exists():
  for i in range(n):
   wb=Workbook();s=wb.active;s.title='10月';s['A1']='2026年10月度';s['N1']=f'E{i:06}';s['U1']=f'Synthetic{i:06}'
   for j in range(30):
    d=date(2026,9,16)+timedelta(days=j)
    for col,val in [('A',d.month),('B',d.day),('G','09:00'),('H','18:00'),('T','08:00')]:s[f'{col}{j+9}']=val
   wb.save(folder/f'E{i:06}.xlsx');wb.close()
  with (folder/'attendance.csv').open('w',newline='') as f:
   out=csv.writer(f);out.writerow(['header']*14)
   for i in range(n):
    for j in range(30):
     d=date(2026,9,16)+timedelta(days=j);row=['']*14;row[0]=d.strftime('%Y%m%d');row[3]=f'S{i:06}';row[4]=f'Synthetic{i:06}';row[10:14]=['09:00','18:00','08:00','01:00'];out.writerow(row)
 return folder
def worker():
 n=120;folder=fixtures(n);cfg=copy.deepcopy(DEFAULT);cfg.update(year=2026,month=10,data_last_row=38);mapping={f'E{i:06}':f'S{i:06}' for i in range(n)}
 def read(phase,workers=4,full=False,config=None,delay_cancel=None):
  use=copy.deepcopy(config or cfg);use['read_workers']=workers;w=main.ReadWorker(folder,use,full);out=[];w.result.connect(lambda *x:out.append(x));start=time.perf_counter();cancel_at=[None];timer,gaps,last=heartbeat()
  w.start()
  if delay_cancel is not None:
   def cancel():cancel_at[0]=time.perf_counter();w.cancel()
   QTimer.singleShot(delay_cancel,cancel)
  limit=time.monotonic()+30
  while w.isRunning() and time.monotonic()<limit:APP.processEvents();time.sleep(.001)
  assert not w.isRunning(),'worker timeout';APP.processEvents();timer.stop();assert len(out)==1
  a,b,issues,stats=out[0];assert 'fatal_error' not in stats,stats
  rowdigest=None;tally=None
  if not stats.get('cancelled'):
   result=reconcile(a,b,mapping,use)[0];rowdigest=digest(sorted((r['employee'],r['date'],r['field'],r['status'],r.get('xlsx'),r.get('csv')) for r in result));tally=dict(__import__('collections').Counter(r['status'] for r in result))
  emit(case='ReadWorker',phase=phase,workers=workers,seconds=time.perf_counter()-start,stats=stats,tally=tally,result_digest=rowdigest,heartbeat_gap=max(gaps,default=0),cancel_join_seconds=None if cancel_at[0] is None else time.perf_counter()-cancel_at[0])
  return out[0],rowdigest
 baseline=[]
 for workers in (1,4,8):
  main.DB=state/f'worker{workers}.sqlite3';a,d=read('cold',workers);b,e=read('warm',workers);assert a[3]['parsed']==121 and b[3]['cache_hits']==121 and d==e;baseline.append(d)
 assert len(set(baseline))==1
 # Schema-readable B-tree corruption: prove new quick_check recovery through ReadWorker.
 import sqlite3
 db=main.DB;con=sqlite3.connect(db);pagesize=con.execute('PRAGMA page_size').fetchone()[0];root=con.execute("SELECT rootpage FROM sqlite_master WHERE name='cache'").fetchone()[0];con.close()
 broken=bytearray(db.read_bytes());broken[(root-1)*pagesize]=255;db.write_bytes(broken)
 before_sha=hashlib.sha256(db.read_bytes()).hexdigest()
 con=sqlite3.connect(db);assert con.execute("SELECT name FROM sqlite_master WHERE name='cache'").fetchone()==('cache',);con.close()
 recovered,rd=read('quick_check_recovery',8)
 assert recovered[3]['parsed']==121 and rd==baseline[0] and any('退避' in w['reason'] for w in recovered[3]['read_warnings'])
 backups=list(db.parent.glob(db.name+'.corrupt-*'));assert len(backups)==1 and hashlib.sha256(backups[0].read_bytes()).hexdigest()==before_sha
 warm,wd=read('quick_check_recovery_warm',8);assert warm[3]['cache_hits']==121 and wd==rd
 emit(case='quick_check_backup',schema_readable=True,backup_hash_preserved=True,rootpage=root,page_size=pagesize)
 # Same size/timestamp content replacement invalidates exactly the CSV.
 p=folder/'attendance.csv';original=p.read_bytes();st=p.stat();p.write_bytes(original.replace(b'09:00',b'10:00'));os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns))
 a,d=read('preserved_metadata_change',8);assert a[3]['parsed']==1 and a[3]['cache_hits']==120
 b,e=read('full_after_change',4,True);assert d==e
 p.write_bytes(original);os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns))
 a,d=read('restore',4);assert d==baseline[0]
 changed=copy.deepcopy(cfg);changed['month']=11;a,d=read('month_change',4,config=changed);assert a[3]['parsed']==120 and a[3]['cache_hits']==1
 a,d=read('cancel',4,True,delay_cancel=25);assert a[3].get('cancelled')
 b,e=read('after_cancel',4);assert e==baseline[0]
 emit(case='input_size',files=121,bytes=sum(p.stat().st_size for p in folder.iterdir()))
if __name__=='__main__':globals()[sys.argv[1]]()
