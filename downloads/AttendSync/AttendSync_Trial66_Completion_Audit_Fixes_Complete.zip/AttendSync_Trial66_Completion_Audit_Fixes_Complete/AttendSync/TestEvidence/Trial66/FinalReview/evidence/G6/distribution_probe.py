import sys,ast,platform,json,subprocess,importlib.metadata,tempfile,re
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/workspace/attendsync-fix66/audit-v2/copies/G6');EVID=Path(__file__).parent;sys.path.insert(0,str(ROOT))
import build_onedir,runtime_paths
result={'environment':{'os':platform.platform(),'python':sys.version,'packages':{name:importlib.metadata.version(name) for name in ['PySide6','openpyxl']}},'missing_validation_reference':not (ROOT/'VALIDATION_TRIAL66.md').is_file()}
try:build_onedir.main()
except SystemExit as e:result['linux_build_refusal']=str(e)
else:raise AssertionError('non-Windows build must refuse')
with tempfile.TemporaryDirectory(dir=EVID) as temp:
 p=Path(temp);portable=p/'app';portable.mkdir();local=p/'local';local.mkdir()
 with patch.object(runtime_paths,'application_dir',return_value=portable):assert runtime_paths.get_data_dir()==portable/'userdata'
 real=runtime_paths.tempfile.TemporaryFile
 def probe(*args,**kwargs):
  if Path(kwargs.get('dir',''))==portable/'userdata':raise PermissionError('synthetic portable deny')
  return real(*args,**kwargs)
 with patch.object(runtime_paths,'application_dir',return_value=portable),patch.dict('os.environ',{'LOCALAPPDATA':str(local)}),patch.object(runtime_paths.tempfile,'TemporaryFile',side_effect=probe):assert runtime_paths.get_data_dir()==local/'AttendSync'
 out=p/'manual_copy';build_onedir.copy_manual(out)
 assert {str(f.relative_to(ROOT/'Manual')):f.read_bytes() for f in (ROOT/'Manual').rglob('*') if f.is_file()}=={str(f.relative_to(out/'Manual')):f.read_bytes() for f in (out/'Manual').rglob('*') if f.is_file()}
 result['path_and_manual_copy']={'portable':True,'synthetic_denied_fallback':True,'manual_files':len([f for f in (out/'Manual').rglob('*') if f.is_file()])}
 # Only inspect build subprocess command; do not invoke a builder.
 with patch.object(build_onedir.sys,'platform','win32'),patch.dict(sys.modules,{'PyInstaller':object()}),patch.object(build_onedir.subprocess,'run') as run,patch.object(build_onedir,'ROOT',p):
  (p/'Manual').mkdir();(p/'Manual'/'index.html').write_text('synthetic');(p/'AttendSync.ico').write_bytes(b'synthetic icon');(p/'dist'/'AttendSync').mkdir(parents=True)
  build_onedir.main();args=run.call_args.args[0];assert '--onedir' in args;assert '--hidden-import' in args;result['build_command_mock']={'args':args,'cwd':str(run.call_args.kwargs['cwd']),'performed_windows_build':False}
# All current local application imports resolve without external optional COM/auth modules at startup.
appfiles=[x for x in ROOT.glob('*.py') if not x.name.startswith('test') and x.name not in ['build_onedir.py']]
imports=set()
for f in appfiles:
 tree=ast.parse(f.read_text(encoding='utf-8-sig'))
 for node in ast.walk(tree):
  if isinstance(node,ast.Import):imports.update(a.name.split('.')[0] for a in node.names)
  elif isinstance(node,ast.ImportFrom) and node.module:imports.add(node.module.split('.')[0])
result['nonstdlib_imports']=sorted(x for x in imports if x not in sys.stdlib_module_names and not (ROOT/(x+'.py')).is_file())
from engine import DEFAULT,reconcile
cfg=json.loads(json.dumps(DEFAULT));cfg.update(year=2026,month=10,comparisons=[dict(name='G6 value',xlsx='value',csv='value',type='number',enabled=True)])
results=[]
for av,bv in [('1','1.0'),('BAD','BAD')]:
 x=dict(date='2026-10-01',employee='E',name='Synthetic',values={'value':av},invalid_fields=[]);c=dict(date='2026-10-01',staff='S',name='Synthetic',values={'value':bv},invalid_fields=[],missing_fields=[])
 rows,issues=reconcile({'E':{'info':{'employee':'E','name':'Synthetic'},'records':[x]}},[c],{'E':'S'},cfg);r=[r for r in rows if r['date']=='2026-10-01' and r['field']=='G6 value'];assert len(r)==1;results.append({'a':av,'b':bv,'status':r[0]['status']})
assert [r['status'] for r in results]==['不一致','一致'];result['CA10_number_comparisons']=results
result['audit_files']={x:(ROOT/x).is_file() for x in ['AGENTS.md','.codex/audit.toml','.codex/config.toml','docs/audit/PROTOCOL.md','docs/audit/REPORT_TEMPLATE.md','scripts/audit_control.py']};assert all(result['audit_files'].values())
(EVID/'distribution_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
