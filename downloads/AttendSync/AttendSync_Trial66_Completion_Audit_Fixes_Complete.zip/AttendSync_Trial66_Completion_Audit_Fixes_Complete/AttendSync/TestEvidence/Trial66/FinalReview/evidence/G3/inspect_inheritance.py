from pathlib import Path
import ast,json,hashlib,shutil
ROOT=Path('/workspace/attendsync-fix66/audit-v2');EV=ROOT/'evidence/G3';OLD=Path('/workspace/attendsync-fix66/audit');NEW=ROOT/'copies/G3'
unchanged=[]
for p in ['settings_dialog.py','outlook_mail.py','employee_information.py','employee_contacts.py','csv_drop.py','manual.py','printing.py','result_filters.py','START_HERE.txt','EXE化手順.txt',*[str(p.relative_to(NEW)) for p in (NEW/'Manual').rglob('*') if p.is_file()]]:
 a=(OLD/'snapshot'/p).read_bytes();b=(NEW/p).read_bytes();assert a==b,p;unchanged.append({'file':p,'sha256':hashlib.sha256(b).hexdigest()})
def window_methods(path):
 tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Window');return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a=window_methods(OLD/'snapshot/main.py');b=window_methods(NEW/'main.py');changed=[n for n in b if a.get(n)!=b[n]];assert changed==['on_progress'],changed
source=OLD/'evidence/G3';inherit=EV/'inherited';inherit.mkdir(exist_ok=True)
files=['probe_ui.py','probe_ui.log','ui_results.json','probe_adjacent.py','probe_adjacent.log','adjacent_results.json','hash_before.json','hash_after.json','focus_account.png','focus_body.png','after_save_reset.png','manual_pdf.txt','pdfinfo.txt','pdf_compare_page10.png','probe_ui_initial_harness_error.py','probe_ui_initial_harness_error.log','ui_results_initial_harness_error.json','probe_adjacent_initial.py','probe_adjacent_initial.log','adjacent_results_initial.json']
evidence=[]
for name in files:
 p=source/name;dest=inherit/name;shutil.copyfile(p,dest);evidence.append(dict(file=name,source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
ui=json.loads((source/'ui_results.json').read_text());adj=json.loads((source/'adjacent_results.json').read_text())['tests'];assert all(t['status']=='PASS' for t in ui+adj)
result=dict(unchanged_files=unchanged,window_methods_changed=changed,window_methods_unchanged=[n for n in b if n not in changed],inherited_evidence=evidence,inherited_ui_condition_groups=len(ui),inherited_adjacent_condition_groups=len(adj),reexecuted=False,prior_entry_missing_record_preserved=True,prior_harness_failures_preserved=True)
(EV/'inheritance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['unchanged_files','window_methods_unchanged','inherited_evidence']},ensure_ascii=False,indent=2));print('unchanged_files',len(unchanged),'unchanged_window_methods',len(b)-1)
