# Inherited same-role fixture, retargeted only to final snapshot; old evidence remains unchanged.
"""G5 independent synthetic postfix audit; no network, real COM or credentials."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import sys,json,csv,copy,hashlib,sqlite3,tempfile,unittest,platform
from pathlib import Path
from datetime import date,timedelta
from collections import Counter
from types import SimpleNamespace as NS
from unittest.mock import patch
SOURCE=Path('/workspace/attendsync-fix66/audit-v2/copies/G5')
EVIDENCE=Path(__file__).parent
sys.path.insert(0,str(SOURCE))
import runtime_paths
IMPORT=tempfile.TemporaryDirectory(dir=EVIDENCE)
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):
    import main
from PySide6.QtWidgets import QApplication
from openpyxl import Workbook
from engine import DEFAULT,Cache,reconcile,save_json,csv_read
from stable_read import file_signature,parse_stable_file
from outlook_mail import DEFAULT_MAIL_SETTINGS,build_mail_plans
from classic_outlook import process_classic_plans
from employee_information import plan_employee_import,contacts_for_mapping
from employee_contacts import email_for,validate_contacts
APP=QApplication.instance() or QApplication([])
observations=[]
def note(case,**data):observations.append(dict(case=case,**data))
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()

class Recipients:
    def __init__(self):self.items=[]
    def Add(self,address):
        recipient=NS(address=address,Type=0);self.items.append(recipient);return recipient
    def ResolveAll(self):return True
class Message:
    def __init__(self,owner):self.owner=owner;self.Recipients=Recipients();self.EntryID=''
    def Save(self):self.EntryID='synthetic-id';self.owner.events.append('Save')
    def Send(self):self.owner.events.append('Send')
class Items:
    def __init__(self,owner):self.owner=owner
    def Add(self,kind):
        assert kind=='IPM.Note'
        message=Message(self.owner);self.owner.messages.append(message);self.owner.events.append('Add');return message
class Outlook:
    def __init__(self):
        self.events=[];self.messages=[]
        account=NS(SmtpAddress='operator@example.invalid',DisplayName='Synthetic Operator')
        account.DeliveryStore=NS(GetDefaultFolder=lambda kind:NS(Items=Items(self)))
        self.Session=NS(Accounts=NS(Count=1,Item=lambda index:account))

class AuditG5(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=EVIDENCE);self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.inputs=self.root/'inputs';self.inputs.mkdir()
        self.state=self.root/'state';self.state.mkdir()
        self.db=self.state/'cache.sqlite3'
        patcher=patch.object(main,'DB',self.db);patcher.start();self.addCleanup(patcher.stop)
        self.cfg=copy.deepcopy(DEFAULT);self.cfg.update(year=2026,month=10,data_last_row=38)
        self.xlsx=self.inputs/'employee.xlsx';self.csv=self.inputs/'attendance.csv'
        book=Workbook();sheet=book.active;sheet.title='10月'
        sheet['A1']='2026年10月度';sheet['N1']='0001';sheet['U1']='同じ名前'
        for offset in range(30):
            day=date(2026,9,16)+timedelta(days=offset);row=9+offset
            for col,value in [('A',day.month),('B',day.day),('G','09:00'),('H','18:00'),('T','08:00')]:sheet[f'{col}{row}']=value
        book.save(self.xlsx);book.close();self.write_csv()
    def write_csv(self,short=False):
        with self.csv.open('w',newline='',encoding='utf-8-sig') as stream:
            writer=csv.writer(stream);writer.writerow(['header']*14)
            for offset in range(30):
                day=date(2026,9,16)+timedelta(days=offset)
                row=['']*14;row[0]=day.strftime('%Y%m%d');row[3]='0007';row[4]='同じ名前';row[10:14]=['09:00','18:00','08:00','01:00']
                writer.writerow(row[:5] if short else row)
    def read(self,full=False):
        out=[];worker=main.ReadWorker(self.inputs,self.cfg,full);worker.result.connect(lambda *args:out.append(args));worker.run()
        self.assertEqual(len(out),1);self.assertNotIn('fatal_error',out[0][3]);return out[0]
    def tally(self,result):return dict(Counter(r['status'] for r in reconcile(result[0],result[1],{'0001':'0007'},self.cfg)[0]))
    def history(self,path):return json.loads((path/'mail_processing_history.json').read_text())
    def settings(self,auto=False):return {**DEFAULT_MAIL_SETTINGS,'account':'operator@example.invalid','auto_send':auto}
    def mail_plan(self,settings=None):
        settings=settings or self.settings()
        settings={**settings,'always_to':'Fixed <fixed@example.invalid>; Extra <extra@example.invalid>','always_cc':'Alpha <alpha@example.invalid>; Beta <beta@example.invalid>'}
        rows=[dict(employee='0001',staff='0007',name='同じ名前',status='不一致',date='2026-09-16',field='始業',xlsx='09:00',csv='10:00')]
        contacts={'version':1,'contacts':[dict(employee='0001',staff='0007',name='同じ名前',email='employee@example.invalid')]}
        return build_mail_plans(rows,contacts,{'0001':'0007'},settings,{'year':2026,'month':10})[0]
    def test_01_worker_same_metadata_replacement(self):
        initial=self.read();self.assertEqual(self.tally(initial),{'一致':90})
        cached=self.read();self.assertEqual(cached[3]['cache_hits'],2)
        old=self.csv.stat();self.csv.write_bytes(self.csv.read_bytes().replace(b'09:00',b'10:00'));os.utime(self.csv,ns=(old.st_atime_ns,old.st_mtime_ns))
        changed=self.read();fresh=self.read(True)
        self.assertEqual(changed[3]['parsed'],1);self.assertEqual(changed[3]['cache_hits'],1)
        self.assertEqual(self.tally(changed),{'一致':60,'不一致':30});self.assertEqual(self.tally(changed),self.tally(fresh))
        note('CA-01 same-size+mtime replacement',before=self.tally(initial),after=self.tally(changed),normal_stats=changed[3],full=self.tally(fresh))
    def test_02_worker_mutation_during_parse_is_not_cached(self):
        real=main.csv_read
        def mutate(path,cfg):
            packet=real(path,cfg);old=path.stat();path.write_bytes(path.read_bytes().replace(b'09:00',b'10:00'));os.utime(path,ns=(old.st_atime_ns,old.st_mtime_ns));return packet
        with patch.object(main,'csv_read',mutate):result=self.read()
        self.assertFalse(result[1]);self.assertTrue(result[3]['file_errors']);self.assertIn('更新',result[3]['file_errors'][0]['reason'])
        with sqlite3.connect(self.db) as db:self.assertEqual(db.execute('SELECT count(*) FROM cache WHERE path=?',(str(self.csv),)).fetchone()[0],0)
        recovered=self.read();self.assertEqual(self.tally(recovered),{'一致':60,'不一致':30})
        note('CA-01 mutation during parser',errors=result[3]['file_errors'],recovered=self.tally(recovered))
    def test_03_public_cache_and_stable_parser(self):
        path=self.root/'plain';path.write_text('AAA');cache=Cache(self.root/'public.sqlite3');self.addCleanup(cache.close)
        parser=lambda p:{'value':p.read_text()}
        self.assertFalse(cache.parse(path,'tag',parser)[1]);self.assertTrue(cache.parse(path,'tag',parser)[1]);old=path.stat()
        path.write_text('BBB');os.utime(path,ns=(old.st_atime_ns,old.st_mtime_ns));self.assertEqual(cache.parse(path,'tag',parser),({'value':'BBB'},False))
        def mutate(p,cfg):
            old=p.stat();p.write_text('CCC');os.utime(p,ns=(old.st_atime_ns,old.st_mtime_ns));return {'records':[]}
        self.assertIn('error',parse_stable_file(mutate,path,{}))
        note('CA-01 public Cache and stable parser',result='content replacement invalidates; parser mutation rejected')
    def test_04_cache_required_metadata_each_reparses(self):
        self.read();checks=[]
        for path,keys in ((self.xlsx,['file','row','sheet','invalid_fields']),(self.csv,['file','row','invalid_fields','missing_fields'])):
            for key in keys:
                with self.subTest(path=path.name,key=key):
                    with sqlite3.connect(self.db) as db:
                        packet=json.loads(db.execute('SELECT data FROM cache WHERE path=?',(str(path),)).fetchone()[0]);del packet['records'][0][key]
                        db.execute('UPDATE cache SET data=? WHERE path=?',(json.dumps(packet),str(path)))
                    result=self.read();self.assertEqual(result[3]['parsed'],1);self.assertEqual(result[3]['cache_hits'],1);self.assertEqual(self.tally(result),{'一致':90})
                    checks.append(path.suffix+':'+key)
        with sqlite3.connect(self.db) as db:
            packet=json.loads(db.execute('SELECT data FROM cache WHERE path=?',(str(self.xlsx),)).fetchone()[0]);del packet['period_unverified'];db.execute('UPDATE cache SET data=? WHERE path=?',(json.dumps(packet),str(self.xlsx)))
        self.assertEqual(self.read()[3]['parsed'],1)
        note('CA-05 metadata deletion injection',reparsed=checks+['.xlsx:period_unverified'])
    def test_05_normal_short_csv_missing_values_remain_review(self):
        self.write_csv(short=True);first=self.read();second=self.read()
        # 30 days * (3 missing-column diagnostic rows + 3 comparison slots).
        self.assertEqual(self.tally(first),{'要確認':180});self.assertEqual(self.tally(first),self.tally(second));self.assertEqual(second[3]['cache_hits'],2)
        self.assertTrue(all(row['missing_fields'] for row in first[1]))
        with sqlite3.connect(self.db) as db:
            packet=json.loads(db.execute('SELECT data FROM cache WHERE path=?',(str(self.csv),)).fetchone()[0])
            for row in packet['records']:del row['missing_fields']
            db.execute('UPDATE cache SET data=? WHERE path=?',(json.dumps(packet),str(self.csv)))
        repaired=self.read();self.assertEqual(repaired[3]['parsed'],1);self.assertEqual(self.tally(repaired),{'要確認':180})
        note('CA-05 normal parser and missing flag injection',normal=self.tally(first),cached=self.tally(second),reparsed=self.tally(repaired))
    def test_06_normal_parser_cache_contract(self):
        first=self.read();second=self.read()
        self.assertEqual(self.tally(first),self.tally(second));self.assertEqual(second[3]['cache_hits'],2)
        self.assertTrue(main.ReadWorker._valid_cached_packet(first[0]['0001'],True,self.cfg))
        self.assertTrue(main.ReadWorker._valid_cached_packet({'records':first[1]},False,self.cfg))
        note('CA-05 normal parser packet accepted',first=self.tally(first),cached=self.tally(second))
    def test_07_mail_equivalent_order_case_display_both_modes(self):
        for auto in (False,True):
            with self.subTest(auto=auto):
                path=self.root/str(auto);path.mkdir();outlook=Outlook();settings=self.settings(auto);plan=self.mail_plan(settings)
                process_classic_plans([plan],settings,path,outlook)
                changed={**plan,'to':[a.upper() for a in reversed(plan['to'])],'cc':[a.upper() for a in reversed(plan['cc'])],'recipient_names':{'employee@example.invalid':'別表示名'}}
                result=process_classic_plans([changed],settings,path,outlook)
                self.assertEqual(len(outlook.messages),1);self.assertIn('同内容',result[0]['status'])
                self.assertEqual([(r.address,r.Type) for r in outlook.messages[0].Recipients.items],[(a,1) for a in plan['to']]+[(a,2) for a in plan['cc']])
                self.assertEqual(outlook.events.count('Send'),int(auto));note('CA-02 equivalent identity',auto=auto,events=outlook.events,status=result[0]['status'])
    def test_08_distinct_notifications_remain_distinct(self):
        plan=self.mail_plan();settings=self.settings();path=self.root/'mail';path.mkdir();outlook=Outlook()
        variants=[plan,{**plan,'body':plan['body']+' new month'},{**plan,'subject':'Changed subject'},{**plan,'to':plan['to']+['additional@example.invalid']},{**plan,'to':plan['cc'],'cc':plan['to']}]
        for variant in variants:process_classic_plans([variant],settings,path,outlook)
        process_classic_plans([plan],{**settings,'auto_send':True},path,outlook)
        self.assertEqual(len(outlook.messages),6);self.assertEqual(outlook.events.count('Send'),1)
        note('CA-02 meaningful differences',created=6,variations=['baseline','body','subject','recipient addition','To/CC roles','mode'])
    def test_09_old_com_v2_com_graph_history_aliases(self):
        from mail_state import mail_payload
        plan=self.mail_plan();settings=self.settings();payload=mail_payload(plan);actual=mail_payload({**plan,'recipient_names':{}});checks=[]
        for kind in ('COMv2','COM','Graph'):
            for state in ('draft','sent','sending'):
                with self.subTest(kind=kind,state=state):
                    path=self.root/(kind+state);path.mkdir();outlook=Outlook()
                    elements=([settings['account'],'classic_outlook_v2',False,'0001','0007',actual] if kind=='COMv2' else [settings['account'],'classic_outlook',False,'0001','0007',payload] if kind=='COM' else [settings['account'],settings['client_id'],settings['tenant_id'],False,'0001','0007',payload])
                    oldkey=digest(elements);save_json(path/'mail_processing_history.json',{oldkey:{'employee':'0001','staff':'0007','status':state}})
                    first=process_classic_plans([plan],settings,path,outlook)
                    second=process_classic_plans([{**plan,'to':list(reversed(plan['to'])),'cc':list(reversed(plan['cc']))}],settings,path,outlook)
                    ledger=self.history(path);self.assertEqual(len(ledger),2);self.assertEqual(first[0]['status'],second[0]['status']);self.assertFalse(outlook.messages);self.assertEqual({x['status'] for x in ledger.values()},{state})
                    checks.append(kind+':'+state)
        note('CA-02 legacy history migration',blocked_and_aliased=checks)
    def test_10_new_history_never_stores_body(self):
        path=self.root/'mail';path.mkdir();outlook=Outlook();plan={**self.mail_plan(),'body':'UNIQUE_PRIVATE_BODY_MARKER_66 勤怠詳細','subject':'PRIVATE_SUBJECT_MARKER'}
        process_classic_plans([plan],self.settings(),path,outlook)
        raw=(path/'mail_processing_history.json').read_text();ledger=json.loads(raw)
        self.assertNotIn(plan['body'],raw);self.assertNotIn(plan['subject'],raw);record=next(iter(ledger.values()));self.assertNotIn('body',record);self.assertRegex(record['identity_hash'],r'^[a-f0-9]{64}$')
        note('CA-02 new ledger privacy',record_keys=sorted(record),body_stored=False,subject_stored=False)
    def test_11_sender_validation_stops_creation(self):
        path=self.root/'mail';path.mkdir();outlook=Outlook()
        with self.assertRaises(ValueError):process_classic_plans([self.mail_plan()],{**self.settings(),'account':'absent@example.invalid'},path,outlook)
        self.assertFalse(outlook.messages);self.assertFalse((path/'mail_processing_history.json').exists())
        note('security sender boundary',result='unknown account rejected before creation/history')
    def test_12_employee_id_email_conflict_boundaries(self):
        base=dict(employee='0001',staff='0007',name='同じ名前',email='first@example.invalid')
        cases=[('same staff two employees',[base,{**base,'employee':'0002'}],{},False,False),('same employee two staff',[base,{**base,'staff':'0008'}],{},False,False),('saved staff owner',[base],{'other':'0007'},False,False),('saved employee different staff',[base],{'0001':'9999'},False,False),('email conflict',[base,{**base,'email':'second@example.invalid'}],{},True,False),('duplicate identical',[base,dict(base)],{},True,True),('missing employee',[{**base,'employee':''}],{},False,False),('missing staff',[{**base,'staff':''}],{},False,False)]
        results=[]
        for label,rows,mapping,idok,emailok in cases:
            with self.subTest(label=label):
                new,data,found=plan_employee_import(rows,'linking',mapping,{'version':1,'contacts':[]})
                self.assertTrue(all(r['id_matched']==idok for r in found));self.assertTrue(all(r['matched']==emailok for r in found));self.assertEqual(bool(email_for(data,'0001','0007')),emailok)
                results.append(dict(label=label,statuses=[r['status'] for r in found]))
        note('employee dependency conflict policy',results=results)
    def test_13_both_ids_and_mapping_change_remove_active_email(self):
        contacts={'version':1,'contacts':[dict(employee='0001',staff='0007',name='同じ名前',email='first@example.invalid')]}
        self.assertEqual(email_for(contacts,'0001','0007'),'first@example.invalid');self.assertEqual(email_for(contacts,'0001','0008'),'');self.assertEqual(email_for(contacts,'0002','0007'),'')
        changed=contacts_for_mapping(contacts,{'0001':'0008'});self.assertFalse(changed['contacts']);self.assertEqual(changed['unlinked_contacts'][0]['email'],'first@example.invalid')
        with self.assertRaises(ValueError):validate_contacts({**contacts,'contacts':contacts['contacts']*2})
        note('employee dependency pair identity',result='no single-ID/name fallback; reassignment moves old email to candidate; duplicate pair rejected')

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(AuditG5)
    runner=unittest.TextTestRunner(verbosity=2);result=runner.run(suite)
    record=dict(source=str(SOURCE),python=sys.version,platform=platform.platform(),methods=result.testsRun,failures=len(result.failures),errors=len(result.errors),observations=observations)
    (EVIDENCE/'results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2,default=str))
    sys.exit(0 if result.wasSuccessful() else 1)
