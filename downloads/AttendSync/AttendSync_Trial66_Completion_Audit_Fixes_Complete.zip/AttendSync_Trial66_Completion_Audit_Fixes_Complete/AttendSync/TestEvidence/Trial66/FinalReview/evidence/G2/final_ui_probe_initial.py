"""Actual Window/QThread checks; held parser, failures, page corruption, retry."""
from final_probe import *

f = fixture('window_final')
root = f['root']
engine.save_json(root/'settings.json',f['cfg'])
engine.save_json(root/'staff_mapping.json',{'E1':'S1'})
engine.save_json(root/'employee_contacts.json',{'version':1,'contacts':[{'employee':'E1','staff':'S1','name':'Synthetic','email':'synthetic@example.invalid'}],'employee_information_registered':True})
observed = []

def record(label, window, **extra):
    entry = {'label':label,'status':window.status.text(),'rows':len(window.results),'run_enabled':window.run_button.isEnabled(),'full_enabled':window.full_button.isEnabled(),'diagnostics':copy.deepcopy(window.read_diagnostics),**extra}
    observed.append(entry)
    print(json.dumps(entry,ensure_ascii=False),flush=True)

def finished(window):
    deadline = time.monotonic()+8
    while window.worker.isRunning() and time.monotonic()<deadline:
        APP.processEvents()
        time.sleep(.005)
    assert window.worker.wait(2000)
    for _ in range(4): APP.processEvents()
    assert window.run_button.isEnabled() and window.full_button.isEnabled()

with patch.multiple(main,DATA_DIR=root,CONFIG=root/'settings.json',MAP=root/'staff_mapping.json',DB=f['db']), patch.object(main,'current_attendance_month',return_value=(2026,10)):
    window = main.Window()
    window.cfg = copy.deepcopy(f['cfg'])
    window.mapping = {'E1':'S1'}
    window.path.setText(str(f['folder']))
    window.year.setValue(2026)
    window.month.setValue(10)
    before = sources(f)
    try:
        entered, release = threading.Event(), threading.Event()
        active = []
        real_csv = main.csv_read
        def held(*args):
            active.append(True)
            entered.set()
            try:
                assert release.wait(6)
                return real_csv(*args)
            finally: active.pop()
        with patch.object(main,'csv_read',held):
            window.run_read()
            worker = window.worker
            assert entered.wait(3)
            window.run_read()
            assert window.worker is worker
            assert not window.run_button.isEnabled() and not window.full_button.isEnabled()
            release.set()
            finished(window)
        baseline = copy.deepcopy(window.results)
        baseline_cfg = copy.deepcopy(window.results_cfg)
        assert baseline
        record('normal_and_double_start',window,one_worker=True)

        entered.clear();release.clear()
        with patch.object(main,'csv_read',held):
            window.run_read(True)
            assert entered.wait(3)
            window.stop_read()
            release.set()
            finished(window)
        assert not active and window.results == baseline and window.results_cfg == baseline_cfg
        assert '中止' in window.status.text()
        record('cancel_preserves_previous',window,no_orphan_parser=True)
        window.run_read();finished(window)
        assert window.results == baseline
        record('retry_after_cancel',window)

        cache_factory = main.Cache
        def failure_factory(path):
            cache = cache_factory(path)
            if str(path) != ':memory:':cache.db = DBProxy(cache.db,'commit')
            return cache
        with patch.object(main,'Cache',failure_factory):
            window.run_read(True);finished(window)
        assert window.results == baseline and window.results_cfg == baseline_cfg
        assert any('保存に失敗' in d['reason'] for d in window.read_diagnostics['warnings'])
        record('save_failure_retains_import_and_warns',window)
        window.run_read();finished(window)
        assert window.results == baseline
        record('retry_after_save_failure',window)

        raw, detail = corrupt_bytes(f,'table')
        for label,full in [('page_normal_recovery',False),('page_full_followup',True),('page_next_normal',False)]:
            window.run_read(full);finished(window)
            assert window.results == baseline and '失敗' not in window.status.text()
            backups = list(root.glob('*.corrupt-*'))
            assert len(backups)==1 and backups[0].read_bytes()==raw
            record(label,window,quarantines=1)
        assert sources(f)==before
        # SELECT-stage transient failure remains explicit and preserves the previous UI result.
        def select_factory(path):
            cache=cache_factory(path)
            if str(path)!=':memory:':cache.db=DBProxy(cache.db,'SELECT')
            return cache
        with patch.object(main,'Cache',select_factory):
            window.run_read();finished(window)
        assert window.results==baseline and window.results_cfg==baseline_cfg and '失敗' in window.status.text()
        record('select_failure_preserves_previous',window)
        window.run_read();finished(window)
        assert window.results==baseline and '失敗' not in window.status.text()
        record('retry_after_select_failure',window)
    finally:
        if window.worker is not None and window.worker.isRunning():
            window.worker.cancel();window.worker.wait(7000)
        window.worker=None
        window.close()
        APP.processEvents()

(OUT/'final_ui_results.json').write_text(json.dumps({'target':str(BASE/'copies/G2'),'observations':observed,'phases':len(observed),'sources_unchanged':True},ensure_ascii=False,indent=2))
print('PASS actual Window/QThread; phases',len(observed),flush=True)
