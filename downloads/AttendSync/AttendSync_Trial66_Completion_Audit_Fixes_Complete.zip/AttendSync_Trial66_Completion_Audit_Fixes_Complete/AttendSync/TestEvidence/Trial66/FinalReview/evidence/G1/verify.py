from pathlib import Path
import hashlib,json

ROOT=Path('/workspace/attendsync-fix66/audit-v2')
E=ROOT/'evidence/G1'
manifest=json.loads((ROOT/'manifest.json').read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def check(root):
    actual={str(p.relative_to(root)):digest(p) for p in root.rglob('*') if p.is_file()}
    return dict(count=len(actual),missing=sorted(manifest.keys()-actual.keys()),
                extra=sorted(actual.keys()-manifest.keys()),
                changed=sorted(k for k in actual.keys()&manifest.keys() if actual[k]!=manifest[k]))
before=json.loads((E/'before.json').read_text())
old_root=Path('/workspace/attendsync-fix66/audit')
old_actual={str(p.relative_to(old_root)):digest(p) for p in (old_root/'evidence/G1').rglob('*') if p.is_file()}
old_expected=before['old_evidence_sha256']
result=dict(snapshot=check(ROOT/'snapshot'),copy=check(ROOT/'copies/G1'),
            manifest_unchanged=digest(ROOT/'manifest.json')==before['manifest_sha256'],
            old_evidence_unchanged=old_actual==old_expected,old_evidence_files=len(old_actual))
(E/'after.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
assert result['manifest_unchanged'] and result['old_evidence_unchanged']
assert all(not result[k][v] for k in ('snapshot','copy') for v in ('missing','extra','changed'))
