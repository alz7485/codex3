"""Additional independent history migration boundaries, synthetic transport only."""
import json,unittest,sys,tempfile
from pathlib import Path
import probe
from probe import Outlook,digest
from classic_outlook import process_classic_plans
from microsoft_mail import process_graph_plans
from outlook_mail import DEFAULT_MAIL_SETTINGS,build_mail_plans
from mail_state import mail_payload
from engine import save_json
outcomes=[]
class LegacySupplement(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=probe.EVIDENCE);self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.plan=dict(employee='0001',staff='0007',name='Synthetic',subject='Subject',body='Private synthetic details',to=['employee@example.invalid','fixed@example.invalid'],cc=['alpha@example.invalid','beta@example.invalid'],problem='',recipient_names={'alpha@example.invalid':'Alpha'})
    def settings(self,auto):return {**DEFAULT_MAIL_SETTINGS,'account':'operator@example.invalid','auto_send':auto}
    def test_actual_graph_mock_transport_then_com_migration(self):
        checks=[]
        for auto in (False,True):
            path=self.root/str(auto);path.mkdir();settings=self.settings(auto);calls=[]
            def transport(method,route,payload=None):
                calls.append([method,route]);return {'id':'old-synthetic-graph-id','_http_status':202}
            prior=process_graph_plans([self.plan],settings,path,transport)
            outlook=Outlook();first=process_classic_plans([self.plan],settings,path,outlook)
            second=process_classic_plans([{**self.plan,'cc':list(reversed(self.plan['cc']))}],settings,path,outlook)
            self.assertFalse(outlook.messages);self.assertEqual(first[0]['status'],second[0]['status']);self.assertEqual(len(json.loads((path/'mail_processing_history.json').read_text())),2)
            checks.append(dict(auto=auto,transport_calls=calls,prior=prior,status=first[0]['status']))
        outcomes.append(dict(case='actual Graph producer mock transport migration both modes',checks=checks))
    def test_old_com_formats_realistic_modes(self):
        checks=[]
        for version in ('classic_outlook_v2','classic_outlook'):
            for auto in (False,True):
                path=self.root/(version+str(auto));path.mkdir();settings=self.settings(auto)
                payload=mail_payload({**self.plan,'recipient_names':{}}) if version.endswith('v2') else mail_payload(self.plan)
                key=digest([settings['account'],version,auto,'0001','0007',payload]);save_json(path/'mail_processing_history.json',{key:{'status':'sent' if auto else 'draft'}})
                outlook=Outlook();status=process_classic_plans([self.plan],settings,path,outlook)
                equivalent={**self.plan,'to':[x.upper() for x in reversed(self.plan['to'])],'recipient_names':{}}
                self.assertEqual(status,process_classic_plans([equivalent],settings,path,outlook));self.assertFalse(outlook.messages)
                checks.append(version+':'+str(auto))
        outcomes.append(dict(case='old COM modes',blocked_and_aliased=checks))
    def test_documented_hash_only_unknown_order_limitation(self):
        path=self.root/'unknown-order';path.mkdir();settings=self.settings(False)
        old_key=digest([settings['account'],'classic_outlook_v2',False,'0001','0007',mail_payload({**self.plan,'recipient_names':{}})])
        save_json(path/'mail_processing_history.json',{old_key:{'employee':'0001','status':'draft'}})
        changed={**self.plan,'cc':list(reversed(self.plan['cc']))};outlook=Outlook()
        process_classic_plans([changed],settings,path,outlook)
        self.assertEqual(len(outlook.messages),1)
        process_classic_plans([self.plan],settings,path,outlook);self.assertEqual(len(outlook.messages),1)
        outcomes.append(dict(case='documented old hash-only unknown order limit',first_reordered_plan_created=1,later_v3_repeat_created=0,classification='existing information-loss migration limitation; not a new accepted-fix defect'))
    def test_build_plans_with_equivalent_settings(self):
        path=self.root/'builder';path.mkdir();settings={**self.settings(True),'always_to':'Fixed <fixed@example.invalid>; Other <other@example.invalid>','always_cc':'Alpha <alpha@example.invalid>; Beta <beta@example.invalid>'}
        rows=[dict(employee='0001',staff='0007',name='Employee',status='不一致',date='2026-09-16',field='始業',xlsx='09:00',csv='10:00')]
        contacts={'contacts':[dict(employee='0001',staff='0007',name='Employee',email='employee@example.invalid')]}
        first=build_mail_plans(rows,contacts,{'0001':'0007'},settings,{'year':2026,'month':10})[0]
        changed={**settings,'always_to':'Renamed <OTHER@EXAMPLE.INVALID>, Caption <FIXED@EXAMPLE.INVALID>','always_cc':'B <BETA@EXAMPLE.INVALID>, A <ALPHA@EXAMPLE.INVALID>'}
        second=build_mail_plans(rows,contacts,{'0001':'0007'},changed,{'year':2026,'month':10})[0]
        outlook=Outlook();process_classic_plans([first],settings,path,outlook);result=process_classic_plans([second],changed,path,outlook)
        self.assertEqual(len(outlook.messages),1);self.assertEqual(outlook.events.count('Send'),1);self.assertIn('同内容',result[0]['status'])
        outcomes.append(dict(case='real builder equivalent settings punctuation/case/caption/order',created=1,send=1))
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(LegacySupplement))
    (probe.EVIDENCE/'legacy-supplement-results.json').write_text(json.dumps(dict(methods=result.testsRun,failures=len(result.failures),errors=len(result.errors),observations=outcomes),ensure_ascii=False,indent=2))
    sys.exit(0 if result.wasSuccessful() else 1)
