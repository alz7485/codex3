# Trial66 最終修正後・独立統括監査

**完成判定：条件付き可（固定ソース版、下記の検証範囲）。** 元CA-01〜CA-11、および初回修正後監査のG1-01/G2-01は、元反例と今回の境界試験の範囲で解消確認。再現継続・新規副作用の確定不具合は検出しなかった。検証済みのローカル合成入力・模擬外部連携でこの版を使う判断であり、Windows実機・実配送・EXEの完成保証ではない。

**公開用パッケージの完成・公開成功は未判定。** 監査時点はプレリリースで、固定snapshotのRegression/FinalReviewにはREADMEのみ。親が本報告と最終回帰証跡を同梱し、最終ZIPのCRC・安全な展開・manifest・コード一致を検査する後続工程が残る。

## 対象・基準・独立性

- 実行ID：`fix66-final-coordinator-20261019`。モード：修正後監査、別担当による統括。AGENTS、PROTOCOL、REPORT_TEMPLATE、audit_coordinator.toml、.codex/audit.tomlを適用。
- 対象：`/workspace/attendsync-fix66/audit-v2/snapshot`、Trial66固定ソース1200ファイル。manifest SHA256：`e4be27e2890fa82f662d389f55b6aea9a6cea65b001df6b5d32d27dd2075dc4d`。
- 基準：Trial65完成監査のFINAL_AUDIT/summary、元ZIP SHA256 `ce08b2a9ae0ca840879e9de795f56c5b54a9c717b8116e06c1b9ed97e4add0b2`。基準ソースは `/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync`。
- 基準1159ファイルと最終1200ファイルを直接SHA比較：追加41・変更18・削除0（合計59差分）。実行時Pythonの変更は9モジュール。`evidence/coordinator/baseline_delta.json`。初回差分は`audit-v2/initial_changes.patch`（元のchanged_filesは`../audit/changed_files.json`）、追加境界差分は`round2_changes.json`。BRIEFの旧差分名を対象不明と解さず、実ファイルと直接比較で固定した。
- 採用仕様：BRIEFと元確定指摘の受入条件を優先。To/CC役割別の同一性、新履歴での再作成抑止と照合可能な旧履歴の移行、保存成功後の未照合化、numberの文字列完全一致。任意提案を必須条件へ追加しない。
- 6グループの初回報告確定後に全件と主要証跡を読了。専門役の今回初回結論は相互未参照、同役の旧証跡の継承あり。統括は全報告を比較する役であり、初回専門監査とは独立性の意味が異なる。別担当統括として自作6メソッドを専用コピーで実行し、多数決で判定していない。
- 環境：Linux 6.18.55 x86_64/glibc2.41、Python3.12.14、PySide6 6.12.0、openpyxl3.1.5。Pythonは`/workspace/attendsync-audit/venv/bin/python`、Qt offscreen、bytecode無効、プロセスtimeout。cloud-environment-runtimeスキルを読んで環境状態のみ確認。通信・認証情報参照・依存追加なし。
- gitは明示禁止のため未使用。原本保護は開始/終了時のmanifest全件照合で確認した。実通信、実COM、実認証、実配送、製品・既存試験・設定変更、追加spawnは行っていない。

## 分野別の実施と証拠

全6グループ・12担当分野を実施済み。初回確定報告は6件であり、「12専門役を別々に起動した完成監査」とは数えない。報告と主要ログ/JSONのSHAは`evidence/coordinator/inputs_sha256.json`、`evidence_index.json`。

| グループ | 分野・重点 | 今回の実行単位（相互に合算しない） | 証拠・制約 |
|---|---|---|---|
| G1 | 仕様/構造、保存とworker・結果/出力スナップショット | 独自1スクリプト・8 unittestメソッド | `reports/G1.md`、`evidence/G1/final_probe.log`、`observations.json`。実Qt/QThread・実社員保存、出力境界はmock |
| G2 | 不具合/破壊的試験、packet・破損復旧・保存/取消 | 独自2スクリプト、40条件と10 UI観測段階 | `reports/G2.md`、`evidence/G2/final_probe_results.json`、`final_ui_results.json`。初回ハーネス失敗は別保存 |
| G3 | UI/改善、フォーカス・文書・出力範囲 | 今回独自1スクリプト・4条件群。旧14+4群は再実行に計上しない | `reports/G3.md`、`evidence/G3/final_results.json`、`inheritance.json`。34ファイル/29メソッド同一性と比較関数ASTを確認して旧証拠を限定継承 |
| G4 | 性能/自動化、600人編集・6000人取込・121ファイル | 独自3コード・5プロセス実行。読込フェーズ/観測行は別単位 | `reports/G4.md`、`evidence/G4/commands.json`、`observations.json`。Linux共有環境の実測をWindows保証に転用しない |
| G5 | データ/安全性、内容指紋・通知・履歴・ID対 | 独自3スクリプト・19 unittestメソッド | `reports/G5.md`、`evidence/G5/results.json`、`legacy-supplement-results.json`、`final-delta-results.json`。外部連携は模擬 |
| G6 | 配布/懐疑的独立反証、全CA・起動・文書/ビルド境界 | 独自4 Pythonスクリプト。うち2本13 unittestメソッド、他2本は条件試験 | `reports/G6.md`、`evidence/G6/observations.json`、`supplemental_results.json`、`mail_results.json`、`distribution_results.json`。実ZIP/Windowsビルドは未実施 |

## 元指摘と追加指摘の解消対応

重大度は元の統合確定値。現在の未解決件数ではない。旧source IDの統合はTrial65 summaryに従い保持する。再現コマンド/入力/期待値は各確定報告、統括の短い再現は後述の`probe.py`を参照。

| ID・元重大度 | 根本原因・期待 | 今回の実際/解消確認と根拠 | 範囲・制約 |
|---|---|---|---|
| CA-01 P2（DI-01/SK-01） | statのみの識別。内容差替えで再解析すべき | **解消確認・実行済み**。`stable_read.py:3,19`、`main.py:114,160`。G5/G6実ReadWorkerで同サイズ同mtime差替え→該当のみ解析、normal/full同結果。統括test01でも11:00へ更新・解析中差替えを拒否 | 通常保存全順列/ネットワーク共有/変更後に完全復元する競合等を保証しない |
| CA-02 P2（SEC-01/AUTO-01） | 受信者順序・表記が通知キーを変える。同役割の等価宛先で再作成すべきでない | **解消確認・模擬実行済み、照合可能な旧履歴まで**。`mail_state.py:4`、`classic_outlook.py:85-137`。G5/G6と統括test05/06で大小文字・表示名・順序変更の追加0、本文/宛先追加/To-CC役割等の正当変更は別通知。照合可能なCOMv2/COM/Graphは移行し追加0 | 実Send/配送未確認。旧ハッシュのみで元順序不明の場合はG5-R01として下記に残す |
| CA-03 P2（ARCH-01） | 社員保存成功後に古いworker結果が復活。無効化世代を拒否すべき | **解消確認・実Qt再現済み**。`main.py:1195,1205,1300`。G1の解析待機中保存・完了通知待機中保存とも結果0を維持し、再読込では新S2。保存失敗は旧結果/workerを保持。統括test04も旧queued result拒否 | 統括は無効化関数境界、実保存はG1/G3/G6の証拠を採用。自然競合全順列は未検証 |
| CA-04 P2（SK-02） | 結果消去後の指標/全数一致が残る。未照合へ戻すべき | **解消確認・実UI済み**。`main.py:1205`。G1/G6で90一致表示→同一登録保存後に結果/全数/指標/診断/進捗を初期化し出力無効、再読込90一致へ復帰。統括test04は指標0/結果設定Noneも確認 | CA-03と入口は同じでもworker不在の初期化漏れは別原因として保持 |
| CA-05 P2（ARCH-02/DI-02） | 不完全packetの契約欠落。該当entryだけ再解析すべき | **解消確認・故障注入済み**。`main.py:59-86,125`。G2の欠落/型不正17条件、G5/G6の出典/欠損フラグ欠落で再解析・正常entryはhit。統括test02でも短いCSVのmissing_fieldsを消して再解析、要確認情報と次回hitを保持 | 自然発生頻度は未確認。全値の意味的改竄検出を保証しない |
| CA-06 P2（BUG-01/DST-01） | 派生DB破損でfull前にfatal。原破損を保全し再生成/一時cacheで解析すべき | **解消確認・故障注入済み**。`engine.py:380-409`、`main.py:93`。G2/G6の非SQLite bytes・退避拒否・通常/full、非破損readonly/full/busyの区別を確認。統括test03はtable/index破損各normal/fullから完全再解析→次回normal hitを確認 | 電断/実容量枯渇/Windowsロック/全破損形態は未検証。SELECT等すべてのDB障害を自動回復する仕様とは認定しない |
| CA-07 P2（PERF-01） | 編集構築途中の使用済集合による候補増殖。不要な全社員複製を抑えるべき | **解消確認・実UI計測済み**。`main.py:1116,1145`。G4の完全登録600人は2400候補、メール1200、1コンボ最大2。元182100増殖なし。G6も2400。全割当を先に求める構造を統括静的確認 | G4で約1.737秒停止/RSS高水位約317MiBは残る。時間上限仕様なし、任意改善へ分離。未割当多数/1000人以上未検証 |
| CA-08 P2（PERF-02） | 取込の全件逆走査。出力を保って大規模停止を抑えるべき | **解消確認・実関数/GUI計測済み**。`employee_information.py:123`。G4の6000人計画0.02975秒、GUI最大停止約0.122秒。旧関数との全結果/境界一致と所有者/氏名集合前計算を統括確認。G6も6000件・競合拒否 | 6000人超/全競合組合せ/Windows速度は未検証。旧版比較は限定AST抽出で、厳密な旧製品全体比較ではない |
| CA-09 P3（UIUX-001） | 設定エラーで原因外の本文へ誘導。原因controlへ移動すべき | **解消確認・実Qt証拠継承＋現ソース確認**。`outlook_mail.py:29-55`、`settings_dialog.py:447,549`。G3旧8条件のfocus/scroll/保存拒否は同一ソース。G6現版4条件でもcontrol同一。統括はfield→control伝達を静的確認 | Windows DPI/IME/支援技術未検証 |
| CA-10 P3（SPEC-001） | 数値同値と誤解する文書。現UI/実装の文字列完全一致へ揃えるべき | **解消確認・実比較/文書照合済み**。`Manual/guide_pages.json:242`、HTML/PDF、`engine.py:446`。G1の1対1.0不一致/BAD対BAD一致、G3の18頁144説明文節一致、G6 PDF10頁画像/抽出を採用 | 数値同値比較を未実装不具合へ追加しない。全頁組版目視/Windows印刷未検証 |
| CA-11 P3（DIST-01） | 入口の旧Trial/頁数。現版へ揃えるべき | **解消確認・現ファイル再検査済み**。`START_HERE.txt:1`、`EXE化手順.txt:1`、VALIDATION/TestEvidence入口。G3/G6でTrial66/18頁、HTML参照/内部anchorに欠落なし。統括も56属性=38ファイル参照+18内部anchorと確認 | Regression/FinalReview内容と最終ZIP検査は後続工程。入口存在と証跡完成を混同しない |
| G1-01 P3 | 無効化済み・停止済みworkerのqueued progressが保存案内を上書き | **解消確認・実Qt再現済み**。`main.py:1290-1298`のinvalidated検査。G1 test03（worker停止/割込falseをassert）、G3/G5/G6、統括test04で進捗0/保存案内維持、新worker50%は反映 | CA-03と同じ世代境界の隣接症状として関連付け、元11件へ加算しない |
| G2-01 P2 | schema可読のB-tree破損を見逃しfull後normalがfatal | **解消確認・故障注入済み**。`engine.py:389` quick_check。G2/G5/G6と統括test03でtable/index各頁の元bytes退避→再解析→full→normal hit。元勤怠不変 | CA-06の検出範囲不足という同根境界へ統合、別の残存CAを追加しない |

今回の再現継続・新規副作用の確定IDはなし。未解決確定件数は **P0=0、P1=0、P2=0、P3=0**。これは列挙した条件で確認した結果で、全入力/環境に不具合が存在しない宣言ではない。

## 重複・矛盾・旧失敗の裁定

- **重大度の相違**：G6表のCA-01/02「元P1」は誤記。元FINAL_AUDIT冒頭とsummaryの各findingはともにP2、全11件はP2=8/P3=3、P0/P1=0。統括は元統合値を採用し、G6初回原文は保持。`evidence/coordinator/cross_review.json`。
- **参照件数56対38**：G3はhref/src属性総数、G6は非空pathのローカルファイル参照数。統括が現HTMLを解析し56=38+内部anchor18と再確認。欠落0で矛盾なし。
- **CSV要確認90対180**：G5旧初回は監査側の期待値誤り。短いCSVでは診断行90＋比較枠90、実際180。G2の小さいfixtureにおける6行等とは入力規模も異なる。同じ結果件数と扱わず、missing_fields保存/再解析と偽一致なしを採用する。製品や既存テストの期待値を監査で緩めていない。
- **保存失敗警告**：G2初回GUIハーネスはCOMMIT故障がfullのDELETEにも及び、保存失敗を期待した段階へ到達しない誤設定。`final_ui_probe_initial.py/.log`を保持し、限定注入後の10段階成功を採用。初回終了1を消去せず今回成功へ加算しない。
- **旧queued検査**：G1旧単独assertは再読込後に進捗0を要求していた。旧所見は再読込前の観測で裏付ける一方、今回はG1 final test03の再読込前assertと統括test04で裁定した。誤時点assertの終了1を製品残存不具合にしない。
- G3旧fixture型/未存在属性、G6 PDF抽出のunderscore/U+0332表現差は監査ハーネス/抽出比較の失敗。旧ログと正規化後のログを分離保存。G3の旧証拠は同一性確認した範囲だけ継承し、今回再実行と数えない。
- 性能は同じ条件/測定単位で判断する。G4の600人停止約1.7秒、G6約1.8秒は共有Linux上の別実行で不一致ではない。8 workerが1 workerより高速という主張は採用しない。
- CA-01は入力同一性、CA-05はpacket契約、CA-06はDB構造破損で別原因。CA-03/04も世代受理と表示初期化という別原因。相互の修正だけで他IDが解消したと扱わない。

## 統括の独立試験と回帰証跡

統括の専用コピーは`copies/coordinator`、追加コード/合成入力/ログは`evidence/coordinator`のみ。既存試験を改変・全数再実行せず、重要反例を短い自作で再構成した。

| 対象版 | 試験/条件 | コマンド | 終了code・結果 | 証拠 |
|---|---|---|---|---|
| Trial66固定1200件 | SHA256→copytree→SHA256 | 指定Pythonのhashlib | 0、両1200件一致 | `before.json` |
| Trial66専用copy | 内容変更/packet/破損table・index/queued通知/新旧メール履歴 | `PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen timeout 60 /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-fix66/audit-v2/evidence/coordinator/probe.py` | **0、6 unittestメソッド成功**、0.451秒、failure/error 0 | `probe.py`、`probe.log`、`results.json` |
| 同copy | 監査設定/編成の補助検査 | `python -B scripts/audit_control.py check`、`plan --mode postfix`（各timeout20） | 各0、status ok/6グループ12分野 | `audit_config_check.log`、`audit_plan.log`。実監査の代用にしない |
| 原本・copy | 全件/余分ファイル、報告・基準入力の保持 | 指定Pythonのhashlib | 0、各1200件、変更/追加/欠落0、入力SHA保持 | `after.json`、`inputs_sha256.json` |
| 親の最終回帰（別copy） | 全53スクリプト、新規Trial66は13メソッド | 親のresults.json/各logを統括が読取照合 | **53/53成功**、fail/timeout0。ログ記載unittest合計324（新規13を含む） | `../evidence/regression/summary.json`、`results.json`、各log。統括照合は`evidence/coordinator/regression_review.json` |

統括は独自1スクリプト・6メソッド・再実行0。table/index×normal/fullは1メソッド内の4 subTestであり別メソッドに加算しない。親の53スクリプト、324メソッド、各役の独自条件/継承/再実行を合算した総件数は作らない。親の新規13とG6の独自13は別の集合。Fontconfigの書込先警告は生ログに保持し、Qt処理の成功を実描画品質の保証にしない。

## 確定不具合から分離する残存リスク・未完工程

### G5-R01：旧ハッシュ履歴の情報喪失

- 分野：履歴移行。影響はP2相当、確度：合成再現済み。今回の新規確定不具合/元11件の再現継続には数えない。
- 根拠：`classic_outlook.py:101-106`、`CHANGES_TRIAL66.md:19`、G5 legacy_supplement、統括test06。
- 条件/手順：元順序不明の旧COMv2ハッシュとdraftのみ保存→初回にCC順逆転したplanで実行（模擬Outlook）。期待は情報欠損を完全復元と主張せず制約として扱うこと。実際は1件模擬作成、その後のv3等価実行は追加0。
- 影響/提案：旧通知が存在すれば初回の重複作成余地。userdata/履歴を事前バックアップし、旧条件不明の再実行前にOutlookの下書き・送信済みを確認する。任意の移行支援UIは必須に追加しない。実配送/未知の全旧形式は未検証。

### CA-R01：元CSVをExcelで開く際の式評価

- 分野：安全性。元の暫定P2・確定件数外。確度：静的根拠/模擬Open到達まで、**実害未検証**。
- 条件：未信頼CSVの攻撃式＋元ファイルを開く操作＋Windows Excel/組織設定の許可。通常のアプリ解析で式評価することや、通信/漏えい/コマンド実行の実害を認定しない。
- 元証拠を維持し今回の確定11件の修正対象外とする。実Excel確認は未実施。信頼できる入力を用いる注意と別途の許可された実機評価を検討する。

### G6-PRE-01：公開前の資料/ZIP検査待ち

- 分野：配布資料、確度：実ファイル静的確認。重大度は製品不具合として未認定。
- `VALIDATION_TRIAL66.md`と`TestEvidence/Trial66`入口は存在するが、固定snapshotのRegression/FinalReviewはREADMEのみ。最終回帰自体の親ログは存在し53/53を確認したが、当該公開用パッケージへの同梱完成とは別。
- 親が最終証跡を追加し、最終ZIPのCRC・危険path/リンク/重複等の安全検査・manifest・展開後コード一致を実施する。外部公開可用性/受領側起動は今回未検証。これらの将来工程を成功扱いしない。

### その他の環境・入力制約

Windows11/Python3.11、実pywin32/Outlook/Excel、認証、配送完了、EXE生成/受領側起動、プリンタ、DPI/IME/支援技術は未実施。実ACL/ロック/容量枯渇/電断、ネットワーク共有、複数プロセス、全キャッシュ破損、巨大cacheでのquick_check費用、6000人超・未割当候補多数・長期連続運用・全月/全書式は未検証。内容の全画像/過去ログでの秘密ゼロ、CVE外部照合、公開後可用性も保証しない。取消は実行中parserの終了待ちであり、合成入力の約27msを巨大ファイルへ一般化しない。

## 任意改善（完成阻害から分離）

| 提案 | 効果/規模・依存 | リスク・検証 |
|---|---|---|
| 社員編集候補の共有/遅延生成またはQt model/delegate | 600行生成の停止/メモリをさらに削減、中規模 | 手入力/検索/ID対/取消/保存保持を600/1000人で比較 |
| 入口版名・頁数・参照の配布時自動照合 | 文書更新漏れの予防、小規模 | 過去履歴を誤検出しない対象限定、HTML/PDF/manifest照合 |
| 1と1.0の文字列比較例 | 設定の誤解を削減、小規模 | 共通生成データと実reconcileの例を一致させる |
| 任意の性能ログ/旧履歴移行支援 | 再現/運用確認の省力化、小〜中規模 | 個人情報を保存しない設計、履歴/再作成抑止の回帰 |

## 保全と最終判断

開始/終了とも原本snapshot・統括専用copy各1200件が固定manifestに全一致、追加/欠落/変更0。6初回報告と元基準入力のSHAも保持。専門役の前後照合も全件一致を報告し、統括は各証跡を照合した。製品・既存試験・設定・依存・原本・配布物の修正なし。

**未解決の確定製品ID：なし。完成判定：固定ソース版は条件付き可。** 条件は、上記検証範囲と実機未検証を明示し、旧条件不明の履歴再実行前に確認すること。実害未確認CA-R01、情報喪失制約G5-R01、公開前工程G6-PRE-01は残る。**公開用パッケージの完成/公開成功は本監査の結論に含めない。** 必要な次工程は親による最終証跡同梱・最終ZIP検査、続いて許可されたWindows実受入である。
