import probe as p
import time
from pathlib import Path
w=p.window(2)
worker=p.main.ReadWorker(p.E/'automation_inputs',p.copy.deepcopy(p.DEFAULT),False)
w.worker=worker
worker.progress.connect(w.on_progress)
worker.start()
limit=time.monotonic()+10
while worker.isRunning() and time.monotonic()<limit:
 p.APP.processEvents();time.sleep(.002)
assert not worker.isRunning()
p.APP.processEvents()
w.invalidate_results()
before=(w.status.text(),w.progress.value(),w.total_check.text())
assert worker.results_invalidated and not worker.isInterruptionRequested()
worker.progress.emit(999,999,'synthetic queued progress after thread exit')
p.APP.processEvents()
after=(w.status.text(),w.progress.value(),w.total_check.text())
assert before==after and after[1]==0
p.emit(case='late_progress_after_exit',ignored=before==after,interruption_flag=worker.isInterruptionRequested(),results_invalidated=worker.results_invalidated,status=after[0],progress=after[1])
w.close();p.APP.processEvents()
