"""New final-snapshot delta checks. Synthetic local files and Qt signals only."""
import json,sqlite3,unittest
from unittest.mock import patch
from PySide6.QtCore import Qt
import probe
from probe import main,APP,AuditG5,note

class FinalDelta(AuditG5):
    def test_delta_corrupt_btree_recovery(self):
        checks=[]
        for object_name in ('cache','sqlite_autoindex_cache_1'):
            for full in (False,True):
                with self.subTest(object=object_name,full=full):
                    self.read()
                    with sqlite3.connect(self.db) as db:
                        page_size=db.execute('PRAGMA page_size').fetchone()[0]
                        root=db.execute('SELECT rootpage FROM sqlite_master WHERE name=?',(object_name,)).fetchone()[0]
                    damaged=bytearray(self.db.read_bytes());damaged[(root-1)*page_size]=0
                    self.db.write_bytes(damaged)
                    # Schema remains readable: failure is in the data/index page.
                    with sqlite3.connect(self.db) as db:
                        self.assertEqual(db.execute('SELECT rootpage FROM sqlite_master WHERE name=?',(object_name,)).fetchone()[0],root)
                    result=self.read(full)
                    self.assertEqual(result[3]['parsed'],2)
                    self.assertEqual(self.tally(result),{'一致':90})
                    self.assertTrue(any('再作成' in w['reason'] for w in result[3]['read_warnings']))
                    self.assertTrue(any(p.read_bytes()==damaged for p in self.state.glob('cache.sqlite3.corrupt-*')))
                    self.assertEqual(self.read()[3]['cache_hits'],2)
                    checks.append(dict(object=object_name,full=full,parsed=2,subsequent_cache_hits=2))
        note('final delta quick_check corrupted Btree table/index',checks=checks)

    def test_delta_queued_progress_generation_boundary(self):
        with patch.multiple(main,CONFIG=self.state/'settings.json',MAP=self.state/'staff_mapping.json'),patch.object(main,'current_attendance_month',return_value=(2026,10)):
            win=main.Window()
            try:
                old=main.ReadWorker(self.inputs,self.cfg);win.worker=old
                old.progress.connect(win.on_progress,Qt.QueuedConnection)
                old.progress.emit(2,2,'stale completion')
                win.invalidate_results();APP.processEvents()
                self.assertTrue(old.results_invalidated)
                self.assertEqual(win.progress.value(),0)
                self.assertIn('社員情報を保存',win.status.text())
                self.assertFalse(win.results)
                current=main.ReadWorker(self.inputs,self.cfg);win.worker=current
                current.progress.connect(win.on_progress,Qt.QueuedConnection)
                current.progress.emit(1,2,'new generation');APP.processEvents()
                self.assertEqual(win.progress.value(),50)
                self.assertIn('new generation',win.status.text())
                old.progress.emit(2,2,'old sender');APP.processEvents()
                self.assertEqual(win.progress.value(),50)
                self.assertIn('new generation',win.status.text())
                note('final delta queued progress',invalidated_progress=0,current_progress=50,old_sender_rejected=True,results=[])
            finally:
                win.worker=None;win.close();APP.processEvents()

if __name__=='__main__':
    suite=unittest.TestSuite(FinalDelta(name) for name in ('test_delta_corrupt_btree_recovery','test_delta_queued_progress_generation_boundary'))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    (probe.EVIDENCE/'final-delta-results.json').write_text(json.dumps(dict(methods=result.testsRun,failures=len(result.failures),errors=len(result.errors),observations=probe.observations),ensure_ascii=False,indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
