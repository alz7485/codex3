import sys,json,hashlib,tempfile,copy
from pathlib import Path
from types import SimpleNamespace as N
sys.path.insert(0,'/workspace/attendsync-fix66/audit/copies/G6')
from engine import save_json
from classic_outlook import process_classic_plans
from outlook_mail import DEFAULT_MAIL_SETTINGS,build_mail_plans
from mail_state import mail_payload
class List:
 def __init__(self,x):self.x=x;self.Count=len(x)
 def Item(self,i):return self.x[i-1]
class Recipients:
 def __init__(self):self.all=[]
 def Add(self,a):r=N(address=a,Type=0);self.all.append(r);return r
 def ResolveAll(self):return True
class Message:
 def __init__(self,app):self.app=app;self.Recipients=Recipients();self.EntryID=''
 def Save(self):self.EntryID='synthetic';self.app.saves+=1
 def Send(self):self.app.sends+=1
class App:
 def __init__(self):
  self.created=[];self.saves=0;self.sends=0
  class Items:
   def Add(_,kind):m=Message(self);self.created.append(m);return m
  self.account=N(SmtpAddress='operator@example.invalid',DisplayName='G6 synthetic',DeliveryStore=N(GetDefaultFolder=lambda n:N(Items=Items())))
  self.Session=N(Accounts=List([self.account]))
def settings(auto=False):return {**DEFAULT_MAIL_SETTINGS,'account':'operator@example.invalid','auto_send':auto,'always_to':'One <one@example.invalid>; Two <two@example.invalid>','always_cc':'CC1 <cc1@example.invalid>; CC2 <cc2@example.invalid>'}
rows=[dict(employee='E',staff='S',name='Synthetic',status='不一致',date='2026-10-01',field='Start',xlsx='09:00',csv='10:00')]
contacts={'contacts':[dict(employee='E',staff='S',name='Synthetic',email='person@example.invalid')]}
def plan(s):return build_mail_plans(rows,contacts,{'E':'S'},s,{'year':2026,'month':10})[0]
obs={}
for auto in [False,True]:
 with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
  s=settings(auto);p=plan(s);a=App();out1=process_classic_plans([p],s,t,a)
  s2={**s,'account':'OPERATOR@EXAMPLE.INVALID','always_to':'Changed <TWO@EXAMPLE.INVALID>; Renamed <ONE@EXAMPLE.INVALID>','always_cc':'CC2 <CC2@EXAMPLE.INVALID>, CC1 <CC1@EXAMPLE.INVALID>'};p2=plan(s2);out2=process_classic_plans([p2,p],s2,t,a);assert len(a.created)==1,(auto,len(a.created),out2)
  for changed in [{**p,'body':p['body']+' changed'},{**p,'to':p['to']+['extra@example.invalid']},{**p,'to':p['cc'],'cc':p['to']}]:process_classic_plans([changed],s,t,a)
  assert len(a.created)==4
  raw=(Path(t)/'mail_processing_history.json').read_text();assert p['body'] not in raw
  obs[str(auto)]={'messages':len(a.created),'saves':a.saves,'send_requests':a.sends,'repeat_outcomes':out2}
for backend in ['classic_outlook_v2','classic_outlook','graph']:
 with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
  s=settings();p=plan(s);payload=mail_payload({**p,'recipient_names':{}}) if backend=='classic_outlook_v2' else mail_payload(p)
  old=[s['account'],backend,False,'E','S',payload] if backend!='graph' else [s['account'],s['client_id'],s['tenant_id'],False,'E','S',payload]
  key=hashlib.sha256(json.dumps(old,ensure_ascii=False,sort_keys=True).encode()).hexdigest();save_json(Path(t)/'mail_processing_history.json',{key:{'employee':'E','status':'draft'}});a=App();process_classic_plans([p],s,t,a);p['cc'].reverse();p['to'].reverse();process_classic_plans([p],s,t,a);assert not a.created
  obs['migration_'+backend]={'created':0,'history_keys':len(json.loads((Path(t)/'mail_processing_history.json').read_text()))}
Path(__file__).with_name('mail_results.json').write_text(json.dumps(obs,ensure_ascii=False,indent=2));print(json.dumps(obs,ensure_ascii=False,indent=2))
