import os,sys,json,copy,time,hashlib,traceback,socket
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
sys.path.insert(0,'/workspace/attendsync-fix66/audit/copies/G3')
ROOT=Path('/workspace/attendsync-fix66/audit/evidence/G3')
STATE=ROOT/'state';STATE.mkdir(exist_ok=True)
import runtime_paths
with patch.object(runtime_paths,'get_data_dir',return_value=STATE):import main
from engine import DEFAULT,save_json
from PySide6.QtWidgets import QApplication,QDialog,QTableWidget,QPushButton,QLineEdit,QComboBox,QLabel,QScrollArea
from PySide6.QtCore import Qt,QTimer,QMimeData,QPoint,QPointF,QUrl
from PySide6.QtGui import QDragEnterEvent,QDropEvent
from settings_dialog import SettingsDialog
import employee_information,outlook_mail,manual
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
socket.create_connection=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('network prohibited'))
main.CONFIG=STATE/'settings.json';main.MAP=STATE/'staff_mapping.json';main.DB=STATE/'cache.sqlite3'
RESULTS=[]
def record(name,fn):
    start=time.perf_counter()
    try:details=fn();RESULTS.append(dict(name=name,status='PASS',seconds=time.perf_counter()-start,details=details))
    except Exception:RESULTS.append(dict(name=name,status='FAIL',seconds=time.perf_counter()-start,error=traceback.format_exc()))
    (ROOT/'ui_results.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2))
def setup(mapping=None,extra=False):
    mapping=mapping or {'E1':'S1','E2':'S2'}
    contacts={'version':1,'contacts':[dict(employee=e,staff=s,name='Name'+e,email=e.lower()+'@example.invalid') for e,s in mapping.items()], 'employee_information_registered':True}
    if extra:contacts.update(staff_candidates=[dict(staff='S3',name='Third')],unlinked_contacts=[dict(employee='E3',staff='S3',name='Third',email='free@example.invalid')])
    save_json(main.MAP,mapping);save_json(main.MAP.with_name('employee_contacts.json'),contacts)
    return contacts
setup()
with patch.object(main,'current_attendance_month',return_value=(2026,10)):W=main.Window()
W.show();APP.processEvents()
def digest():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (main.MAP,main.MAP.with_name('employee_contacts.json'))}
def button(dialog,text):return next(b for b in dialog.findChildren(QPushButton) if b.text()==text)
def editor(action):
    errors=[];details=[]
    def act():
        d=APP.activeModalWidget()
        try:details.append(action(d))
        except Exception:errors.append(traceback.format_exc())
        finally:
            if d.isVisible():d.reject()
    QTimer.singleShot(0,act);W.edit_map();APP.processEvents()
    assert not errors,errors
    return details[0]
def focus_case(key,value):
    d=SettingsDialog(W,copy.deepcopy(DEFAULT));d.resize(d.minimumWidth(),d.minimumHeight());d.show();APP.processEvents()
    c=d.mail_controls[key]
    c.setPlainText(value) if hasattr(c,'setPlainText') else c.setText(value)
    d.tabs.setCurrentIndex(0);d.accept();APP.processEvents()
    f=APP.focusWidget();assert f is c or c.isAncestorOf(f),(key,f)
    assert d.error_label.isVisible() and d.isVisible()
    area=c.parentWidget()
    while area and not isinstance(area,QScrollArea):area=area.parentWidget()
    mapped=c.mapTo(area.viewport(),QPoint(0,0));assert mapped.y()<area.viewport().height() and mapped.y()+c.height()>0
    result=dict(key=key,focus=f.metaObject().className(),tab=d.tabs.currentIndex(),error=d.error_label.text(),control_y=mapped.y(),viewport_h=area.viewport().height(),size=[d.width(),d.height()])
    if key in ('account','body'):d.grab().save(str(ROOT/('focus_'+key+'.png')))
    d.reject();d.deleteLater();APP.processEvents();return result
for key,value in [('account','bad'),('always_to','bad'),('always_cc','bad'),('subject',''),('subject','{unknown}'),('body',''),('body','no differences'),('body','{unknown}')]:
    record('focus_'+key+'_'+str(len(RESULTS)),lambda k=key,v=value:focus_case(k,v))
def linear():
    n=600;W.mapping={f'E{i:04}':f'S{i:04}' for i in range(n)};setup(W.mapping)
    start=time.perf_counter()
    def inspect(d):
        t=d.findChild(QTableWidget,'employeeIdTable');assert t.rowCount()==n
        counts=[sum(t.cellWidget(i,j).count() for i in range(n)) for j in (2,3)]
        assert counts==[2*n,2*n],counts
        return dict(rows=n,staff_items=counts[0],mail_items=counts[1])
    result=editor(inspect);result['open_seconds']=time.perf_counter()-start;return result
record('employee_600_linear',linear)
def cancel_and_search():
    setup(extra=True);W.mapping={'E1':'S1','E2':'S2'};before=digest()
    def act(d):
        t=d.findChild(QTableWidget,'employeeIdTable');s=next(x for x in d.findChildren(QLineEdit) if x.placeholderText()=='社員ID・氏名・メールで検索')
        mail=t.cellWidget(0,3);staff=t.cellWidget(0,2)
        assert mail.findData('e1@example.invalid')>=0 and mail.findData('free@example.invalid')>=0
        assert mail.findData('e2@example.invalid')<0
        assert staff.findData('S3')>=0
        s.setText('E2');assert [i for i in range(2) if not t.isRowHidden(i)]==[1]
        s.setText('NAMEE1');assert [i for i in range(2) if not t.isRowHidden(i)]==[0]
        s.setText('e2@example.invalid');assert [i for i in range(2) if not t.isRowHidden(i)]==[1]
        s.clear();staff.setEditText('Manual-ID');staff.lineEdit().editingFinished.emit();mail.setEditText('manual@example.invalid')
        mail.lineEdit().editingFinished.emit();assert main.selected_staff_id(staff)=='Manual-ID'
        from employee_contacts import selected_email
        assert selected_email(mail)=='manual@example.invalid'
        button(d,'キャンセル').click();return dict(searches=3,manual_staff=main.selected_staff_id(staff),manual_email=selected_email(mail))
    result=editor(act);assert digest()==before;assert W.mapping=={'E1':'S1','E2':'S2'};return result
record('employee_candidates_search_manual_cancel',cancel_and_search)
def save_reset():
    setup(extra=True);W.mapping={'E1':'S1','E2':'S2'}
    W.results=[{'status':'不一致'}];W.visible=list(W.results);W.loaded_xdata={'E1':{}};W.loaded_cdata=[{}];W.results_cfg=copy.deepcopy(DEFAULT)
    W.comparison_summary={'old':1};W.read_diagnostics={'failures':[{}],'warnings':[],'other':[]};W.issues=['old'];W.total_check.setText('全数一致')
    for m in W.metric_values.values():m.setText('9')
    def act(d):
        t=d.findChild(QTableWidget,'employeeIdTable');t.cellWidget(0,2).setEditText('S3');t.cellWidget(0,2).lineEdit().editingFinished.emit();t.cellWidget(0,3).setEditText('typed@example.invalid')
        with patch.object(main.QMessageBox,'question',return_value=main.QMessageBox.Yes):button(d,'社員情報を登録').click()
        assert not d.isVisible();return {'mapping':W.mapping}
    result=editor(act)
    assert W.mapping=={'E1':'S3','E2':'S2'};assert not W.results and not W.visible and W.results_cfg is None
    assert W.comparison_summary is None and not W.loaded_xdata and not W.loaded_cdata and not W.issues
    assert W.read_diagnostics=={'failures':[],'warnings':[],'other':[]}
    assert all(m.text()=='0' for m in W.metric_values.values())
    assert not W.mail_button.isEnabled() and not W.print_button.isEnabled() and not W.preview_button.isEnabled()
    assert '全数一致' not in W.total_check.text()
    saved=json.loads(main.MAP.with_name('employee_contacts.json').read_text());assert any(r['employee']=='E1' and r['email']=='typed@example.invalid' for r in saved['contacts'])
    W.grab().save(str(ROOT/'after_save_reset.png'));result.update(status=W.status.text(),total=W.total_check.text());return result
record('employee_save_and_uncompared_reset',save_reset)
def drop_cancel():
    setup(extra=True);W.mapping={'E1':'S1','E2':'S2'};before=digest();path=ROOT/'drop.csv';path.write_text('A,B,C,D,E,F,G,H,I,J\nS3,E3,Third,,,,,,,free@example.invalid\n')
    calls=[]
    def fake(*args,**kw):calls.append(kw.get('initial_path'));return None
    def act(d):
        t=d.findChild(QTableWidget,'employeeIdTable');target=t.cellWidget(0,3).lineEdit();mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(str(path))])
        enter=QDragEnterEvent(QPoint(5,5),Qt.CopyAction,mime,Qt.LeftButton,Qt.NoModifier);APP.sendEvent(target,enter);assert enter.isAccepted()
        drop=QDropEvent(QPointF(5,5),Qt.CopyAction,mime,Qt.LeftButton,Qt.NoModifier);APP.sendEvent(target,drop);assert drop.isAccepted();APP.processEvents()
        assert calls==[str(path)],calls;assert t.rowCount()==2
        button(d,'キャンセル').click();return dict(callbacks=calls)
    with patch.object(employee_information,'show_employee_import_dialog',side_effect=fake):result=editor(act)
    assert digest()==before;return result
record('csv_drop_child_and_import_cancel',drop_cancel)
def ranges():
    setup();W.mapping={'E1':'S1','E2':'S2'};cfg=copy.deepcopy(DEFAULT);cfg.update(year=2026,month=10);W.cfg=copy.deepcopy(cfg);W.results_cfg=copy.deepcopy(cfg)
    def row(status,eid,date):return dict(status=status,employee=eid,staff='S'+eid[1:],name='Name'+eid,date=date,field='開始',xlsx='09:00',csv='10:00',xlsx_key='start',csv_key='start')
    W.results=[row('不一致','E1','2026-09-16'),row('不一致','E2','2026-10-01'),row('一致','E1','2026-10-02'),row('要確認','E2','2026-10-03')];W.result_csv_months={'2026-09','2026-10'}
    W.hide_missing_csv_months.setChecked(False);W.search.clear();W.select_filter('不一致のみ');assert len(W.visible)==3
    W.search.setText('E1');assert len(W.visible)==1
    html=[];mails=[]
    with patch.object(main,'print_html',side_effect=lambda *a,**k:html.append(a[1])),patch.object(outlook_mail,'show_mail_dialog',side_effect=lambda *a,**k:mails.extend(a[1])):
        W.print_list();W.compose_mail()
    assert len(html)==1 and 'E1' in html[0] and 'E2' not in html[0]
    assert len(mails)==1 and mails[0]['employee']=='E1' and not mails[0]['problem'],mails
    assert len(W.results)==4
    W.search.clear();W.select_filter('すべて');assert len(W.visible)==4
    W.select_filter('一致のみ');assert len(W.visible)==1 and not W.mail_button.isEnabled() and W.print_button.isEnabled()
    return dict(source_rows=len(W.results),filtered_print_rows=1,mail_employees=[p['employee'] for p in mails],all_rows=4,match_rows=1)
record('visible_print_mail_ranges',ranges)
def manual_entry():
    opened=[]
    with patch.object(manual,'application_dir',return_value=Path('/workspace/attendsync-fix66/audit/copies/G3')),patch.object(manual.QDesktopServices,'openUrl',side_effect=lambda url:opened.append(url.toLocalFile()) or True):
        W.btn_manual.click();W.manual_action.trigger()
    assert len(opened)==2 and all(p.endswith('Manual/index.html') for p in opened)
    return {'entries':opened,'shortcut':W.manual_action.shortcut().toString()}
record('manual_button_and_F1_action',manual_entry)
W.close();APP.processEvents()
print(json.dumps(RESULTS,ensure_ascii=False,indent=2))
sys.exit(any(r['status']!='PASS' for r in RESULTS))
