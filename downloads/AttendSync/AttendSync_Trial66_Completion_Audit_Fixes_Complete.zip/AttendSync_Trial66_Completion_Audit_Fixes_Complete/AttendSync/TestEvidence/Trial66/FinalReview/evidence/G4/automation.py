import probe as p
import copy,time,json,threading,csv
from pathlib import Path
from unittest.mock import patch
from datetime import date,timedelta
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QTableWidget,QPushButton
from openpyxl import Workbook
from engine import DEFAULT,save_json
from classic_outlook import process_classic_plans
from outlook_mail import DEFAULT_MAIL_SETTINGS,build_mail_plans
from test_trial64_classic_mail import Outlook,Message
main=p.main;APP=p.APP;E=p.E
folder=E/'automation_inputs';folder.mkdir(exist_ok=True)
for i in range(2):
 wb=Workbook();s=wb.active;s.title='10月';s['A1']='2026年10月度';s['N1']=f'E{i:06}';s['U1']=f'Synthetic{i:06}'
 for j in range(30):
  d=date(2026,9,16)+timedelta(days=j)
  for c,v in [('A',d.month),('B',d.day),('G','09:00'),('H','18:00'),('T','08:00')]:s[f'{c}{j+9}']=v
 wb.save(folder/f'E{i}.xlsx');wb.close()
with (folder/'a.csv').open('w',newline='') as f:
 out=csv.writer(f);out.writerow(['header']*14)
 for i in range(2):
  for j in range(30):
   d=date(2026,9,16)+timedelta(days=j);r=['']*14;r[0]=d.strftime('%Y%m%d');r[3]=f'S{i:06}';r[4]=f'Synthetic{i:06}';r[10:14]=['10:00','18:00','08:00','01:00'];out.writerow(r)
w=p.window(2);cfg=copy.deepcopy(DEFAULT);cfg.update(year=2026,month=10,data_last_row=38,folder=str(folder));w.cfg=cfg;w.path.setText(str(folder));w.year.setValue(2026);w.month.setValue(10)
def pump_until(predicate,seconds=8):
 until=time.monotonic()+seconds
 while not predicate() and time.monotonic()<until:APP.processEvents();time.sleep(.002)
 assert predicate(),'timeout';APP.processEvents()
def launch(full=False):
 w.run_read(full);assert w.worker is not None;pump_until(lambda:not w.worker.isRunning());APP.processEvents()
launch();assert len(w.results)==180 and sum(r['status']=='不一致' for r in w.results)==60 and w.results_cfg['month']==10
# UI target change leaves the previous completed snapshot attributed to October.
w.month.setValue(11);assert w.result_config()['month']==10
settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com'}
plans=build_mail_plans(w.visible,p.contacts(2),w.mapping,settings,w.result_config());assert len(plans)==2
p.emit(case='month_snapshot',control_month=w.month.value(),result_month=w.result_config()['month'],mail_subjects=[r['subject'] for r in plans],rows=len(w.results))
w.month.setValue(10)
entered=threading.Event();release=threading.Event();real=main.xlsx_read
def held(*args):entered.set();assert release.wait(5);return real(*args)
errors=[]
with patch.object(main,'xlsx_read',held):
 w.run_read(True);old_worker=w.worker;pump_until(entered.is_set)
 def save():
  d=APP.activeModalWidget()
  try:
   t=d.findChild(QTableWidget,'employeeIdTable');t.cellWidget(0,2).setEditText('REPLACED')
   next(b for b in d.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
  except Exception as ex:errors.append(repr(ex));d.reject()
 with patch.object(main.QMessageBox,'question',return_value=main.QMessageBox.Yes):
  QTimer.singleShot(0,save);w.edit_map()
 assert not errors,errors
 assert old_worker.results_invalidated and old_worker.isInterruptionRequested()
 requested_at_save=old_worker.isInterruptionRequested()
 assert not w.results and not w.visible and w.comparison_summary is None and w.results_cfg is None
 assert not w.mail_button.isEnabled() and not w.print_button.isEnabled()
 assert all(v.text()=='0' for v in w.metric_values.values())
 release.set();pump_until(lambda:not old_worker.isRunning());assert not w.results and w.mapping['E000000']=='REPLACED'
 p.emit(case='registration_replacement',interruption_requested_at_save=requested_at_save,interruption_flag_after_thread_exit=old_worker.isInterruptionRequested(),late_result_rejected=not bool(w.results),mapping=w.mapping,summary=w.total_check.text(),metrics={k:v.text() for k,v in w.metric_values.items()})
launch();assert w.results and w.results_cfg['month']==10 and w.run_button.isEnabled()
p.emit(case='registration_rerun',result_rows=len(w.results),mapping=w.mapping,result_month=w.results_cfg['month'],run_enabled=w.run_button.isEnabled())
w.close();APP.processEvents()
# Partial batch: first completed, second's Save outcome ambiguous, third unprocessed.
maildir=p.state/'mail_partial';maildir.mkdir(exist_ok=True);outlook=Outlook(maildir)
mailplans=[dict(employee=f'E{i}',staff=f'S{i}',to=[f'e{i}@example.invalid','fixed@example.invalid'],cc=['a@example.invalid','b@example.invalid'],subject='2026/10 notification',body=f'October differences {i}',problem='') for i in range(3)]
original_save=Message.Save
def second_fails(self):
 if self.Subject=='2026/10 notification' and self.Body.endswith(' 1'):raise OSError('synthetic ambiguous Save failure')
 return original_save(self)
with patch.object(Message,'Save',second_fails):first=process_classic_plans(mailplans,settings,maildir,outlook)
assert len(outlook.messages)==2 and first[1].get('error') and first[2]['status']=='未処理'
reordered=[{**r,'to':[a.upper() for a in reversed(r['to'])],'cc':list(reversed(r['cc']))} for r in mailplans]
second=process_classic_plans(reordered,settings,maildir,outlook)
assert len(outlook.messages)==3 and second[0]['status']=='同内容の下書き保存済み' and '再実行を停止' in second[1]['status'] and second[2]['status']=='下書き保存済み'
third=process_classic_plans(reordered,settings,maildir,outlook);assert len(outlook.messages)==3
nextmonth=[{**r,'subject':'2026/11 notification','body':r['body'].replace('October','November')} for r in reordered]
fourth=process_classic_plans(nextmonth,settings,maildir,outlook);assert len(outlook.messages)==6
ledger=json.loads((maildir/'mail_processing_history.json').read_text());assert all('body' not in x for x in ledger.values())
p.emit(case='mail_partial_resume',initial=first,resume=second,repeat=third,next_month=fourth,created_messages=len(outlook.messages),ledger_records=len(ledger),body_stored=False)
