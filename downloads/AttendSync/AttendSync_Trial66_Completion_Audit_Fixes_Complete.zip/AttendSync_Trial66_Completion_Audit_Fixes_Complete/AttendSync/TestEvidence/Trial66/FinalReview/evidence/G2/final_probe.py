"""Final-snapshot G2 probes. Synthetic inputs and SQLite faults only.

New harness; old evidence is read-only. Each case records observations explicitly.
"""
import os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import sys, json, copy, sqlite3, hashlib, platform, traceback, threading, time
from pathlib import Path
from collections import Counter
from unittest.mock import patch

BASE = Path('/workspace/attendsync-fix66/audit-v2')
OUT = BASE / 'evidence/G2'
DATA = OUT / 'synthetic_final'
DATA.mkdir(exist_ok=True)
sys.path.insert(0, str(BASE / 'copies/G2'))
import runtime_paths
with patch.object(runtime_paths, 'get_data_dir', return_value=DATA):
    import main
import engine
from openpyxl import Workbook
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication
APP = QApplication.instance() or QApplication([])
CONNECT = sqlite3.connect
RESULTS = []

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fixture(name):
    root = DATA / name
    root.mkdir()
    folder = root / 'inputs'
    folder.mkdir()
    cfg = copy.deepcopy(engine.DEFAULT)
    cfg.update(year=2026, month=10, data_first_row=9, data_last_row=9)
    wb = Workbook()
    sheet = wb.active
    sheet.title = '10月'
    for cell, value in {'A1':'2026年10月度','N1':'E1','U1':'Synthetic','A9':9,'B9':16,'G9':'09:00','H9':'18:00','T9':'08:00'}.items():
        sheet[cell] = value
    xp = folder / 'employee.xlsx'
    wb.save(xp)
    wb.close()
    cp = folder / 'attendance.csv'
    cp.write_text('header\n20260916,,,S1,Synthetic,,,,,,09:00,18:00,08:00,01:00\n')
    return {'root':root, 'folder':folder, 'cfg':cfg, 'xlsx':xp, 'csv':cp, 'db':root/'cache.sqlite3'}

def read(f, full=False):
    out = []
    with patch.object(main, 'DB', f['db']):
        w = main.ReadWorker(f['folder'], f['cfg'], full)
        w.result.connect(lambda *args: out.append(args), Qt.ConnectionType.DirectConnection)
        w.run()
    assert len(out) == 1
    return out[0]

def valid(f, result):
    assert 'fatal_error' not in result[3], result[3]
    assert not result[3]['cancelled'] and not result[3]['file_errors'], result[3]
    tally = Counter(row['status'] for row in engine.reconcile(result[0], result[1], {'E1':'S1'}, f['cfg'])[0])
    assert tally == {'一致':3}, tally
    return result[3]

def sources(f):
    return {k:digest(f[k]) for k in ('xlsx','csv')}

def case(name, fn, *args):
    try:
        detail = fn(*args)
        result = {'name':name, 'status':'PASS', 'detail':detail}
    except Exception:
        result = {'name':name, 'status':'FAIL', 'detail':traceback.format_exc()}
    RESULTS.append(result)
    print(json.dumps(result, ensure_ascii=False), flush=True)

def metadata(kind, key, bad=False):
    f = fixture('metadata_'+kind+'_'+key+('_bad' if bad else ''))
    valid(f, read(f))
    before = sources(f)
    with CONNECT(f['db']) as db:
        packet = json.loads(db.execute('SELECT data FROM cache WHERE path=?',(str(f[kind]),)).fetchone()[0])
        target = packet if key in ('info','period_unverified') else packet['records'][0]
        if bad:
            target[key] = {'row':True,'values':{},'sheet':'','missing_fields':None,'invalid_fields':['unknown'],'period_unverified':'false'}[key]
        else:
            del target[key]
        db.execute('UPDATE cache SET data=? WHERE path=?',(json.dumps(packet),str(f[kind])))
    first = valid(f, read(f))
    assert (first['parsed'], first['cache_hits']) == (1,1), first
    retry = valid(f, read(f))
    assert retry['cache_hits'] == 2 and sources(f) == before
    return {'parsed':first['parsed'], 'unaffected_hit':first['cache_hits'], 'next_hits':retry['cache_hits'], 'sources_unchanged':True}

def missing_columns():
    f = fixture('missing_columns')
    f['csv'].write_text('header\n20260916,,,S1,Synthetic\n')
    initial = read(f)
    expected = Counter(r['status'] for r in engine.reconcile(initial[0],initial[1],{'E1':'S1'},f['cfg'])[0])
    assert expected == {'要確認':6}, expected
    with CONNECT(f['db']) as db:
        packet = json.loads(db.execute('SELECT data FROM cache WHERE path=?',(str(f['csv']),)).fetchone()[0])
        del packet['records'][0]['missing_fields']
        db.execute('UPDATE cache SET data=? WHERE path=?',(json.dumps(packet),str(f['csv'])))
    after = read(f)
    actual = Counter(r['status'] for r in engine.reconcile(after[0],after[1],{'E1':'S1'},f['cfg'])[0])
    assert actual == expected and after[3]['parsed'] == 1
    return {'before':expected,'after':actual,'reparsed':after[3]['parsed']}

def corrupt_bytes(f, kind):
    if kind == 'header':
        raw = b'G2 final synthetic non-SQLite bytes'
        f['db'].write_bytes(raw)
        return raw, {'kind':kind}
    with CONNECT(f['db']) as db:
        page_size = db.execute('PRAGMA page_size').fetchone()[0]
        name = 'cache' if kind == 'table' else 'sqlite_autoindex_cache_1'
        root_page = db.execute('SELECT rootpage FROM sqlite_master WHERE name=?',(name,)).fetchone()[0]
    raw = bytearray(f['db'].read_bytes())
    offset = (root_page-1)*page_size
    old = raw[offset]
    raw[offset] = 0
    f['db'].write_bytes(raw)
    # Demonstrate schema remains readable before production quick_check runs.
    with CONNECT(f['db']) as db:
        schema_readable = bool(db.execute('SELECT name FROM sqlite_master').fetchall())
        try:
            check = db.execute('PRAGMA quick_check(1)').fetchone()
        except sqlite3.DatabaseError as exc:
            check = {'error':str(exc), 'code':getattr(exc,'sqlite_errorcode',None)}
    return bytes(raw), {'kind':kind,'page_size':page_size,'root_page':root_page,'offset':offset,'original_type':old,'schema_readable':schema_readable,'precheck':check}

def corruption(kind, initial_full):
    f = fixture('corrupt_'+kind+'_'+str(initial_full))
    valid(f, read(f))
    before = sources(f)
    raw, detail = corrupt_bytes(f, kind)
    observations = []
    for label, full in [('first',initial_full),('full',True),('next_normal',False)]:
        r = read(f, full)
        stats = valid(f, r)
        backups = list(f['root'].glob('*.corrupt-*'))
        assert len(backups) == 1 and backups[0].read_bytes() == raw
        assert stats['parsed'] == (0 if label=='next_normal' else 2), stats
        if label == 'first': assert stats['read_warnings'], stats
        observations.append({'label':label,'full':full,'stats':stats,'quarantines':len(backups)})
    with CONNECT(f['db']) as db:
        assert db.execute('PRAGMA quick_check(1)').fetchone() == ('ok',)
    assert sources(f) == before
    return {**detail, 'corrupt_sha256':hashlib.sha256(raw).hexdigest(),'observations':observations,'sources_unchanged':True}

def quarantine_denied(full):
    f = fixture('quarantine_denied_'+str(full))
    valid(f, read(f))
    raw, info = corrupt_bytes(f,'table')
    real_replace = Path.replace
    def denied(path, target):
        if path == f['db']: raise PermissionError('G2 injected quarantine denial')
        return real_replace(path, target)
    with patch.object(Path, 'replace', denied):
        stats = valid(f, read(f,full))
    assert stats['parsed'] == 2 and stats['read_warnings']
    assert f['db'].read_bytes() == raw and not list(f['root'].glob('*.corrupt-*'))
    recovered = valid(f, read(f))
    assert recovered['parsed'] == 2 and len(list(f['root'].glob('*.corrupt-*'))) == 1
    assert valid(f,read(f))['cache_hits'] == 2
    return {'denied_original_preserved':True,'memory_stats':stats,'retry_recovered':True}

class DBProxy:
    def __init__(self, db, stage, code=None):
        self.db, self.stage, self.code = db, stage, code
    def fail(self):
        exc = sqlite3.OperationalError('G2 injected '+self.stage)
        if self.code is not None: exc.sqlite_errorcode = self.code
        raise exc
    def execute(self, sql, *args):
        if self.stage=='check' and sql.startswith('PRAGMA quick_check'): self.fail()
        if self.stage in ('INSERT','DELETE','SELECT') and sql.startswith(self.stage): self.fail()
        if self.stage=='non_ok' and sql.startswith('PRAGMA quick_check'):
            class Cursor:
                def fetchone(self): return ('G2 synthetic integrity error',)
            return Cursor()
        return self.db.execute(sql,*args)
    def commit(self):
        if self.stage=='commit': self.fail()
        return self.db.commit()
    def rollback(self): return self.db.rollback()
    def close(self): return self.db.close()

def noncorrupt_failure(stage, code):
    f = fixture('noncorrupt_'+stage+'_'+str(code))
    valid(f,read(f))
    before = f['db'].read_bytes()
    def connect(path,*args,**kwargs):
        if str(path)==':memory:': return CONNECT(path,*args,**kwargs)
        if stage=='open':
            exc=sqlite3.OperationalError('G2 injected open failure');exc.sqlite_errorcode=code
            raise exc
        return DBProxy(CONNECT(path,*args,**kwargs),'check',code)
    with patch.object(engine.sqlite3,'connect',connect):
        stats = valid(f,read(f))
    assert stats['parsed']==2 and stats['read_warnings']
    assert f['db'].read_bytes()==before and not list(f['root'].glob('*.corrupt-*'))
    assert valid(f,read(f))['cache_hits']==2
    return {'sqlite_code':code,'fallback_stats':stats,'db_bytes_preserved':True,'no_quarantine':True,'retry_hits':2}

def explicit_non_ok():
    f=fixture('explicit_non_ok');valid(f,read(f));before=f['db'].read_bytes();calls=[]
    def connect(path,*args,**kwargs):
        db=CONNECT(path,*args,**kwargs)
        calls.append(str(path))
        return DBProxy(db,'non_ok') if len(calls)==1 else db
    with patch.object(engine.sqlite3,'connect',connect):stats=valid(f,read(f))
    backups=list(f['root'].glob('*.corrupt-*'))
    assert len(backups)==1 and backups[0].read_bytes()==before and stats['parsed']==2
    assert valid(f,read(f))['cache_hits']==2
    return {'non_ok_return_detected':True,'backup_preserved':True,'next_hits':2}

def save_failure(stage):
    f=fixture('save_failure_'+stage)
    factory=main.Cache
    def wrapped(path):
        cache=factory(path)
        if str(path)!=':memory:':cache.db=DBProxy(cache.db,stage)
        return cache
    with patch.object(main,'Cache',wrapped): r=read(f,stage=='DELETE')
    if stage=='SELECT':
        assert r[3].get('fatal_error') and not r[0] and not r[1]
    else:
        stats=valid(f,r);assert stats['read_warnings'],stats
        with CONNECT(f['db']) as db:assert db.execute('SELECT count(*) FROM cache').fetchone()[0]==0
    retry=valid(f,read(f));assert retry['parsed']==2
    assert valid(f,read(f))['cache_hits']==2
    return {'initial_stats':r[3],'retry_parsed':retry['parsed'],'next_hits':2}

def atomic_save(stage):
    root=DATA/('atomic_'+stage);root.mkdir();path=root/'settings.json'
    engine.save_json(path,{'previous':1});before=path.read_bytes()
    if stage=='create':ctx=patch.object(engine.tempfile,'NamedTemporaryFile',side_effect=PermissionError('G2 create denied'))
    elif stage=='write':ctx=patch.object(engine.json,'dump',side_effect=OSError(28,'G2 disk full'))
    elif stage=='fsync':ctx=patch.object(engine.os,'fsync',side_effect=OSError(28,'G2 disk full'))
    else:ctx=patch.object(Path,'replace',side_effect=PermissionError('G2 replace denied'))
    try:
        with ctx:engine.save_json(path,{'replacement':2})
        raise AssertionError('fault not propagated')
    except OSError:pass
    assert path.read_bytes()==before and sorted(p.name for p in root.iterdir())==['settings.json']
    engine.save_json(path,{'retry':3});assert engine.load_json(path,{})=={'retry':3}
    return {'previous_preserved':True,'temp_removed':True,'retry_saved':True}

if __name__=='__main__':
    for kind,keys in [('xlsx',['file','sheet','row','invalid_fields','period_unverified','info']),('csv',['file','row','invalid_fields','missing_fields'])]:
        for key in keys:case('CA05_missing_'+kind+'_'+key,metadata,kind,key)
    for kind,key in [('xlsx','row'),('xlsx','sheet'),('xlsx','values'),('xlsx','period_unverified'),('csv','missing_fields'),('csv','invalid_fields')]:
        case('CA05_type_'+kind+'_'+key,metadata,kind,key,True)
    case('CA05_missing_columns',missing_columns)
    for kind in ('header','table','index'):
        for full in (False,True):case('CA06_'+kind+'_'+str(full),corruption,kind,full)
    for full in (False,True):case('CA06_quarantine_denied_'+str(full),quarantine_denied,full)
    for stage in ('open','check'):
        for code in (sqlite3.SQLITE_READONLY,sqlite3.SQLITE_FULL,sqlite3.SQLITE_BUSY):
            case('CA06_noncorrupt_'+stage+'_'+str(code),noncorrupt_failure,stage,code)
    case('CA06_quick_check_non_ok_return',explicit_non_ok)
    for stage in ('INSERT','commit','DELETE','SELECT'):case('save_failure_'+stage,save_failure,stage)
    for stage in ('create','write','fsync','replace'):case('atomic_save_'+stage,atomic_save,stage)
    report={'target':str(BASE/'copies/G2'),'python':sys.version,'platform':platform.platform(),'cases':len(RESULTS),'passed':sum(r['status']=='PASS' for r in RESULTS),'failed':sum(r['status']=='FAIL' for r in RESULTS),'results':RESULTS}
    (OUT/'final_probe_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print('SUMMARY',report['cases'],report['passed'],report['failed'],flush=True)
    sys.exit(bool(report['failed']))
