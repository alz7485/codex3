"""Independent final-source cross-review; synthetic local files and mock Outlook only."""
import copy, csv, hashlib, json, os, sqlite3, sys, unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch

BASE = Path('/workspace/attendsync-fix66/audit-v2')
EVIDENCE = BASE / 'evidence/coordinator'
SOURCE = BASE / 'copies/coordinator'
sys.path.insert(0, str(SOURCE))
import runtime_paths
RUNTIME = EVIDENCE / 'runtime'
RUNTIME.mkdir()
with patch.object(runtime_paths, 'get_data_dir', return_value=RUNTIME):
    import main
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication
from engine import DEFAULT, Cache, save_json
from stable_read import file_signature, parse_stable_file
from outlook_mail import DEFAULT_MAIL_SETTINGS
from classic_outlook import process_classic_plans
from mail_state import mail_payload
APP = QApplication.instance() or QApplication([])
OBS = {}

class Recipients:
    def Add(self, address): return NS(Type=0)
    def ResolveAll(self): return True

class FakeMessage:
    def __init__(self, app):
        self.app = app
        self.Recipients = Recipients()
        self.EntryID = ''
    def Save(self): self.EntryID = 'coordinator-synthetic'; self.app.saves += 1
    def Send(self): self.app.sends += 1

class FakeOutlook:
    def __init__(self):
        self.messages = []; self.saves = self.sends = 0
        def add(kind):
            assert kind == 'IPM.Note'
            message = FakeMessage(self); self.messages.append(message); return message
        account = NS(SmtpAddress='operator@example.invalid', DisplayName='Synthetic',
                     DeliveryStore=NS(GetDefaultFolder=lambda kind: NS(Items=NS(Add=add))))
        self.Session = NS(Accounts=NS(Count=1, Item=lambda index: account))

class CoordinatorProbe(unittest.TestCase):
    def setUp(self):
        self.root = EVIDENCE / self._testMethodName; self.root.mkdir()
        self.inputs = self.root / 'inputs'; self.inputs.mkdir()
        self.db = self.root / 'cache.sqlite3'
        self.cfg = copy.deepcopy(DEFAULT); self.cfg.update(year=2026, month=10)
        self.csv = self.inputs / 'synthetic.csv'; self.write_csv()
        patcher = patch.object(main, 'DB', self.db)
        patcher.start(); self.addCleanup(patcher.stop)
    def write_csv(self, short=False):
        row = ['20261001', '', '', 'S1', 'Synthetic', '', '', '', '', '', '09:00', '18:00', '08:00', '01:00']
        with self.csv.open('w', encoding='utf-8-sig', newline='') as stream:
            writer = csv.writer(stream); writer.writerow(['header'] * 14); writer.writerow(row[:5] if short else row)
    def read(self, full=False):
        out = []; worker = main.ReadWorker(self.inputs, self.cfg, full)
        worker.result.connect(lambda *args: out.append(args)); worker.run()
        self.assertEqual(len(out), 1); self.assertNotIn('fatal_error', out[0][3])
        return out[0]
    def settings(self, auto=False):
        return {**DEFAULT_MAIL_SETTINGS, 'account':'operator@example.invalid', 'auto_send':auto}
    def plan(self):
        return dict(employee='E1', staff='S1', to=['a@example.invalid','b@example.invalid'],
                    cc=['c@example.invalid','d@example.invalid'], subject='Synthetic subject marker',
                    body='Synthetic body marker coordinator', recipient_names={'a@example.invalid':'Alpha'})
    def process(self, plan, settings, root, app):
        with patch('classic_outlook.running_outlook', side_effect=AssertionError('real COM forbidden')):
            return process_classic_plans([plan], settings, root, app)
    def legacy_key(self, backend, plan, settings):
        payload = mail_payload({**plan,'recipient_names':{}}) if backend == 'classic_outlook_v2' else mail_payload(plan)
        prefix = [settings['account'].casefold(), backend] if backend != 'graph' else [settings['account'].casefold(),settings['client_id'],settings['tenant_id']]
        return hashlib.sha256(json.dumps(prefix+[settings['auto_send'],plan['employee'],plan['staff'],payload], ensure_ascii=False, sort_keys=True).encode()).hexdigest()

    def test01_content_and_midparse_change(self):
        self.assertEqual(self.read()[3]['parsed'], 1)
        self.assertEqual(self.read()[3]['cache_hits'], 1)
        old = self.csv.stat(); signature = file_signature(self.csv)
        self.csv.write_bytes(self.csv.read_bytes().replace(b'09:00', b'11:00'))
        os.utime(self.csv, ns=(old.st_atime_ns,old.st_mtime_ns))
        self.assertEqual(self.csv.stat().st_size, old.st_size)
        self.assertNotEqual(file_signature(self.csv), signature)
        normal = self.read(); full = self.read(True)
        self.assertEqual(normal[3]['parsed'], 1); self.assertEqual(normal[1], full[1])
        self.assertEqual(normal[1][0]['values']['start'], '11:00')
        def changing_parser(path, cfg):
            st=path.stat();path.write_bytes(path.read_bytes().replace(b'11:00',b'12:00'))
            os.utime(path, ns=(st.st_atime_ns,st.st_mtime_ns));return {'records':[]}
        changed = parse_stable_file(changing_parser, self.csv, self.cfg)
        self.assertIn('error', changed)
        OBS['CA01'] = dict(same_size_mtime_reparsed=True, normal_equals_full=True, midparse_rejected=True)

    def test02_missing_metadata_reparsed(self):
        self.write_csv(short=True)
        initial = self.read(); self.assertTrue(initial[1][0]['missing_fields'])
        self.assertEqual(self.read()[3]['cache_hits'], 1)
        with sqlite3.connect(self.db) as db:
            packet = json.loads(db.execute('SELECT data FROM cache').fetchone()[0])
            packet['records'][0].pop('missing_fields')
            self.assertFalse(main.ReadWorker._valid_cached_packet(packet, False, self.cfg))
            db.execute('UPDATE cache SET data=?', (json.dumps(packet),)); db.commit()
        repaired = self.read()
        self.assertEqual(repaired[3]['parsed'], 1)
        self.assertEqual(repaired[1], initial[1]); self.assertEqual(self.read()[3]['cache_hits'], 1)
        OBS['CA05'] = dict(missing_fields_preserved=repaired[1][0]['missing_fields'], reparsed=1, next_hits=1)

    def test03_readable_schema_corruption_full_normal(self):
        checks=[]
        for obj in ('cache','sqlite_autoindex_cache_1'):
            for full in (False, True):
                with self.subTest(object=obj, full=full):
                    self.read()
                    with sqlite3.connect(self.db) as db:
                        page_size=db.execute('PRAGMA page_size').fetchone()[0]
                        page=db.execute('SELECT rootpage FROM sqlite_master WHERE name=?',(obj,)).fetchone()[0]
                    damaged=bytearray(self.db.read_bytes()); damaged[(page-1)*page_size]=0; self.db.write_bytes(damaged)
                    with sqlite3.connect(self.db) as db:
                        self.assertEqual(db.execute('SELECT rootpage FROM sqlite_master WHERE name=?',(obj,)).fetchone()[0],page)
                    result=self.read(full); self.assertEqual(result[3]['parsed'],1)
                    self.assertTrue(any(p.read_bytes()==damaged for p in self.root.glob('cache.sqlite3.corrupt-*')))
                    self.assertTrue(result[3]['read_warnings'])
                    self.assertEqual(self.read(True)[3]['parsed'],1)
                    self.assertEqual(self.read()[3]['cache_hits'],1)
                    checks.append(dict(object=obj,full=full,backup_exact=True,next_normal_hits=1))
        OBS['CA06_G2_01']=checks

    def test04_queued_invalidated_and_new_sender(self):
        with patch.multiple(main, CONFIG=self.root/'settings.json', MAP=self.root/'mapping.json'), patch.object(main,'current_attendance_month',return_value=(2026,10)):
            win=main.Window()
            try:
                old=main.ReadWorker(self.inputs,self.cfg);win.worker=old
                old.progress.connect(win.on_progress,Qt.QueuedConnection)
                old.result.connect(win.read_done,Qt.QueuedConnection)
                old.progress.emit(1,1,'obsolete');old.result.emit({},[],[],{})
                win.invalidate_results();expected=win.status.text();APP.processEvents()
                self.assertFalse(old.isRunning());self.assertFalse(old.isInterruptionRequested())
                self.assertTrue(old.results_invalidated);self.assertEqual(win.progress.value(),0)
                self.assertEqual(win.status.text(),expected);self.assertEqual(win.results,[])
                self.assertIsNone(win.results_cfg);self.assertIsNone(win.comparison_summary)
                self.assertTrue(all(v.text()=='0' for v in win.metric_values.values()))
                new=main.ReadWorker(self.inputs,self.cfg);win.worker=new
                new.progress.connect(win.on_progress,Qt.QueuedConnection)
                new.progress.emit(1,2,'current');APP.processEvents();self.assertEqual(win.progress.value(),50)
                old.progress.emit(1,1,'obsolete again');APP.processEvents()
                self.assertEqual(win.progress.value(),50);self.assertIn('current',win.status.text())
                OBS['CA03_CA04_G1_01']=dict(invalidated_progress=0,current_progress=50,old_result_rejected=True,metrics_zero=True)
            finally:
                win.worker=None;win.close();APP.processEvents()

    def test05_mail_equivalence_and_meaningful_change(self):
        checks=[]
        for auto in (False,True):
            root=self.root/str(auto);root.mkdir();app=FakeOutlook();settings=self.settings(auto);p=self.plan()
            self.process(p,settings,root,app)
            equivalent={**p,'to':[a.upper() for a in reversed(p['to'])], 'cc':list(reversed(p['cc'])), 'recipient_names':{}}
            self.process(equivalent,{**settings,'account':'OPERATOR@EXAMPLE.INVALID'},root,app)
            self.assertEqual(len(app.messages),1)
            for changed in ({**p,'body':p['body']+' changed'}, {**p,'to':p['to']+['extra@example.invalid']}, {**p,'to':p['cc'],'cc':p['to']}):
                self.process(changed,settings,root,app)
            self.assertEqual(len(app.messages),4);self.assertEqual(app.sends,4 if auto else 0)
            ledger=json.loads((root/'mail_processing_history.json').read_text())
            self.assertTrue(all('body' not in record and 'subject' not in record for record in ledger.values()))
            checks.append(dict(auto_send=auto,created=4,send_requests=app.sends,equivalent_repeat_created=0))
        OBS['CA02_new_identity']=checks

    def test06_legacy_known_and_unknown_order(self):
        checks=[]
        for backend in ('classic_outlook_v2','classic_outlook','graph'):
            root=self.root/backend;root.mkdir();settings=self.settings();p=self.plan();app=FakeOutlook()
            key=self.legacy_key(backend,p,settings)
            save_json(root/'mail_processing_history.json',{key:{'status':'draft'}})
            self.process(p,settings,root,app)
            self.process({**p,'to':list(reversed(p['to'])),'cc':list(reversed(p['cc']))},settings,root,app)
            self.assertEqual(len(app.messages),0)
            checks.append(dict(backend=backend,created=0,history_keys=len(json.loads((root/'mail_processing_history.json').read_text()))))
        root=self.root/'unknown-order';root.mkdir();p=self.plan();settings=self.settings();app=FakeOutlook()
        save_json(root/'mail_processing_history.json',{self.legacy_key('classic_outlook_v2',p,settings):{'status':'draft'}})
        changed={**p,'cc':list(reversed(p['cc']))}
        self.process(changed,settings,root,app);self.process(p,settings,root,app)
        self.assertEqual(len(app.messages),1)
        OBS['CA02_legacy']=dict(known=checks,unknown_order_first_created=1,v3_repeat_created=0,classification='documented information-loss limitation')

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CoordinatorProbe))
    (EVIDENCE/'results.json').write_text(json.dumps(dict(methods=result.testsRun,failures=len(result.failures),errors=len(result.errors),observations=OBS),ensure_ascii=False,indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
