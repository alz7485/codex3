# Final G1 dedicated harness. Synthetic fixtures inherited from own prior G1; no old script is executed.
import os,sys,copy,csv,json,time,threading,unittest
from pathlib import Path
from unittest.mock import patch
from datetime import date,timedelta
ROOT=Path('/workspace/attendsync-fix66/audit-v2'); E=ROOT/'evidence/G1'
sys.path.insert(0,str(ROOT/'copies/G1'))
import runtime_paths
(E/'runtime').mkdir(exist_ok=True)
with patch.object(runtime_paths,'get_data_dir',return_value=E/'runtime'):
 import main
from engine import DEFAULT,save_json,reconcile
from outlook_mail import DEFAULT_MAIL_SETTINGS
from PySide6.QtWidgets import QApplication,QPushButton,QTableWidget,QMessageBox
from PySide6.QtCore import QTimer
from PySide6.QtTest import QTest
from openpyxl import Workbook
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
OBS={}
def until(pred,sec=6):
 end=time.monotonic()+sec
 while not pred():
  if time.monotonic()>end:raise AssertionError('deadline')
  APP.processEvents();QTest.qWait(5)
 APP.processEvents()
class Audit(unittest.TestCase):
 def setUp(self):
  self.root=E/self._testMethodName;self.root.mkdir(exist_ok=True);self.folder=self.root/'inputs';self.folder.mkdir(exist_ok=True)
  self.paths=patch.multiple(main,DATA_DIR=self.root,CONFIG=self.root/'settings.json',MAP=self.root/'mapping.json',DB=self.root/'cache.sqlite3');self.paths.start();self.addCleanup(self.paths.stop)
  self.cfg=copy.deepcopy(DEFAULT);self.cfg.update(year=2026,month=10,data_last_row=38)
  wb=Workbook();s=wb.active;s.title='10月';s['A1']='2026年10月度';s['N1']='E1';s['U1']='Synthetic'
  self.rows=[]
  for i in range(30):
   d=date(2026,9,16)+timedelta(days=i);n=i+9
   for col,val in [('A',d.month),('B',d.day),('G','09:00'),('H','18:00'),('T','08:00')]:s[f'{col}{n}']=val
   r=['']*14;r[0]=d.strftime('%Y%m%d');r[3]='S1';r[4]='Synthetic';r[10:14]=['09:00','18:00','08:00','01:00'];self.rows.append(r)
  wb.save(self.folder/'source.xlsx');wb.close();self.csv_write()
  save_json(main.MAP,{'E1':'S1'});save_json(main.MAP.with_name('employee_contacts.json'),dict(version=1,contacts=[dict(employee='E1',staff='S1',name='Synthetic',email='one@example.invalid')],employee_names={'E1':'Synthetic'},staff_candidates=[dict(employee='',staff='S2',name='Other')],employee_information_registered=True))
  with patch.object(main,'current_attendance_month',return_value=(2026,10)):self.w=main.Window()
  self.w.cfg=copy.deepcopy(self.cfg);self.w.path.setText(str(self.folder));self.w.year.setValue(2026);self.w.month.setValue(10);self.addCleanup(self.close)
 def close(self):
  if self.w.worker and self.w.worker.isRunning():self.w.worker.cancel();self.w.worker.wait(6000)
  self.w.worker=None;self.w.close();APP.processEvents()
 def csv_write(self):
  with (self.folder/'source.csv').open('w',newline='') as f:
   wr=csv.writer(f);wr.writerow(['header']*14);wr.writerows(self.rows)
 def read(self):
  self.w.run_read(full=True);worker=self.w.worker;self.assertIsNotNone(worker);until(lambda:not worker.isRunning());until(self.w.run_button.isEnabled);return worker
 def save_dialog(self,staff=None,reject=False):
  errors=[]
  def action():
   dlg=APP.activeModalWidget()
   try:
    if reject:dlg.reject();return
    table=dlg.findChild(QTableWidget,'employeeIdTable')
    if staff:table.cellWidget(0,2).setEditText(staff)
    next(b for b in dlg.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
   except BaseException as ex:errors.append(repr(ex));dlg.reject()
  with patch.object(QMessageBox,'question',return_value=QMessageBox.Yes):QTimer.singleShot(0,action);self.w.edit_map()
  self.assertFalse(errors,errors);APP.processEvents()
 def state(self):
  w=self.w
  return dict(results=len(w.results),visible=len(w.visible),metrics={k:v.text() for k,v in w.metric_values.items()},formula=w.total_formula.text(),check=w.total_check.text(),diagnostics=w.read_diagnostics,log=w.log_history,progress=w.progress.value(),status=w.status.text(),mail=w.mail_button.isEnabled(),print=w.print_button.isEnabled(),preview=w.preview_button.isEnabled(),cfg=w.results_cfg,months=w.result_csv_months,summary=w.comparison_summary,hidden=w.hidden_csv_month_rows_count)
 def assert_clear(self):
  st=self.state();self.assertEqual(st['results'],0);self.assertEqual(st['visible'],0);self.assertTrue(all(v=='0' for v in st['metrics'].values()));self.assertNotIn('全数一致',st['check']);self.assertIsNone(st['summary']);self.assertIsNone(st['cfg']);self.assertIsNone(st['months']);self.assertEqual(st['hidden'],0);self.assertFalse(st['log']);self.assertEqual(st['diagnostics'],dict(failures=[],warnings=[],other=[]));self.assertFalse(st['mail']);self.assertFalse(st['print']);self.assertFalse(st['preview']);return st
 def test_01_save_reset_and_reread(self):
  self.read();self.assertEqual(len(self.w.results),90);self.assertIn('全数一致',self.w.total_check.text());self.w.read_diagnostics={'failures':[{'file':'old','reason':'old'}],'warnings':[],'other':['old']};self.w.issues=['old'];self.w.set_log_history(['old']);self.save_dialog();OBS['normal_reset']=self.assert_clear();self.assertEqual(self.w.progress.value(),0)
  self.read();self.assertIn('全数一致',self.w.total_check.text());OBS['reread_rows']=len(self.w.results)
 def test_02_inflight_save(self):
  self.read();entered=threading.Event();release=threading.Event();real=main.parse_stable_file
  def held(*args):
   entered.set()
   if not release.wait(6):raise AssertionError('release deadline')
   return real(*args)
  with patch.object(main,'parse_stable_file',held):
   self.w.run_read(full=True);worker=self.w.worker;until(entered.is_set)
   try:self.save_dialog('S2');self.assertTrue(worker.isInterruptionRequested());self.assertTrue(worker.results_invalidated)
   finally:release.set();until(lambda:not worker.isRunning());until(self.w.run_button.isEnabled)
  OBS['inflight_reset']=self.assert_clear();self.assertEqual(self.w.progress.value(),0);self.assertIn('読み込んでください',self.w.status.text());self.read();self.assertTrue(self.w.results);self.assertTrue(all(r['staff']=='S2' for r in self.w.results));OBS['new_mapping_reread']=self.state()
 def test_03_completion_queued_during_save(self):
  self.read();entered=threading.Event();release=threading.Event();real=main.parse_stable_file;commit=main.__dict__.get('commit_employee_information')
  import employee_information
  actual_commit=employee_information.commit_employee_information
  def held(*args):
   entered.set()
   if not release.wait(6):raise AssertionError('release deadline')
   return real(*args)
  def delayed_commit(*args,**kw):
   release.set();self.assertTrue(self.w.worker.wait(5000));return actual_commit(*args,**kw)
  with patch.object(main,'parse_stable_file',held):
   self.w.run_read(full=True);worker=self.w.worker;until(entered.is_set)
   try:
    with patch.object(employee_information,'commit_employee_information',delayed_commit):self.save_dialog('S2')
   finally:release.set();until(lambda:not worker.isRunning());until(self.w.run_button.isEnabled)
  st=self.assert_clear();OBS['completion_queued']=dict(st,worker_running=worker.isRunning(),interruption=worker.isInterruptionRequested(),invalidated=worker.results_invalidated)
  # Assert the invalidated generation before the next read starts.
  self.assertFalse(worker.isRunning());self.assertFalse(worker.isInterruptionRequested());self.assertTrue(worker.results_invalidated)
  self.assertEqual(st['progress'],0);self.assertIn('社員情報を保存',st['status']);self.assertIn('読み込んでください',st['status'])
  self.assertTrue(self.w.run_button.isEnabled());self.assertTrue(self.w.full_button.isEnabled());self.assertFalse(self.w.stop_button.isEnabled())
  print('QUEUED_PROGRESS',json.dumps(OBS['completion_queued'],ensure_ascii=False))
  self.read();self.assertTrue(self.w.results);self.assertTrue(all(r['staff']=='S2' for r in self.w.results))
 def test_04_cancel_and_reject_preserve(self):
  self.read();before=copy.deepcopy(self.w.results);summary=copy.deepcopy(self.w.comparison_summary);self.save_dialog(reject=True);self.assertEqual(self.w.results,before);self.assertEqual(self.w.comparison_summary,summary)
  entered=threading.Event();release=threading.Event();real=main.parse_stable_file
  def held(*args):entered.set();release.wait(6);return real(*args)
  with patch.object(main,'parse_stable_file',held):
   self.w.run_read(full=True);old=self.w.worker;until(entered.is_set);self.w.stop_read();self.w.run_read();self.assertIs(self.w.worker,old);release.set();until(lambda:not old.isRunning());until(self.w.run_button.isEnabled)
  self.assertEqual(self.w.results,before);self.assertEqual(self.w.comparison_summary,summary);OBS['ordinary_cancel']=self.w.status.text()
 def test_05_pending_settings_display_print_mail(self):
  self.rows[0][10]='10:00';self.csv_write();self.read();self.assertEqual(sum(r['status']=='不一致' for r in self.w.results),1);before=copy.deepcopy(self.w.comparison_summary);snapshot=copy.deepcopy(self.w.results_cfg)
  self.w.cfg['year']=2027;self.w.cfg['month']=1;self.w.cfg['xlsx_columns']['start']='AA';self.w.cfg['detail_visible_fields']=['start'];self.w.cfg['mail_settings']={**DEFAULT_MAIL_SETTINGS,'subject':'{name} {year}/{month}'};self.w.show_results()
  self.assertEqual(self.w.results_cfg,snapshot);self.assertEqual(self.w.comparison_summary,before)
  cfg=self.w.result_config();self.assertEqual(cfg['year'],2026);self.assertEqual(cfg['xlsx_columns']['start'],snapshot['xlsx_columns']['start']);self.assertEqual(cfg['detail_visible_fields'],['start'])
  with patch.object(main,'print_html') as printer:self.w.print_list(preview=True)
  self.assertTrue(printer.call_args.kwargs['preview']);html=printer.call_args.args[1];self.assertIn('2026年10月度',html);self.assertIn('/ 1件',html)
  import outlook_mail
  with patch.object(outlook_mail,'show_mail_dialog') as dialog:self.w.compose_mail()
  plans=dialog.call_args.args[1];self.assertEqual(len(plans),1);self.assertEqual(plans[0]['staff'],'S1');self.assertIn('2026/10',plans[0]['subject']);OBS['snapshot_outputs']=dict(print_old_period=True,mail_subject=plans[0]['subject'],visible=len(self.w.visible),total=before['expected'])
  with patch.object(main,'print_html') as printer:self.w.print_list()
  self.assertFalse(printer.call_args.kwargs['preview'])
  self.w.select_filter('すべて');self.assertEqual(len(self.w.visible),90);self.assertEqual(self.w.comparison_summary,before);self.w.search.setText('nonexistent');self.assertFalse(self.w.visible);self.assertFalse(self.w.mail_button.isEnabled());self.assertFalse(self.w.print_button.isEnabled());self.assertEqual(self.w.comparison_summary,before)
  self.save_dialog();self.assert_clear()
 def test_06_number_text_contract(self):
  self.read();x=copy.deepcopy(self.w.loaded_xdata);c=copy.deepcopy(self.w.loaded_cdata);cfg=copy.deepcopy(self.cfg);cfg['comparisons']=[dict(name='value',xlsx='start',csv='start',type='number',enabled=True)]
  x['E1']['records'][0]['values']['start']='1';c[0]['values']['start']='1.0';r,_=reconcile(x,c,{'E1':'S1'},cfg);self.assertEqual(r[0]['status'],'不一致')
  x['E1']['records'][0]['values']['start']='BAD';c[0]['values']['start']='BAD';r,_=reconcile(x,c,{'E1':'S1'},cfg);self.assertEqual(r[0]['status'],'一致')
  text=(ROOT/'copies/G1/Manual/guide_pages.json').read_text();self.assertIn('値（文字列完全一致）',text);OBS['number_contract']={'1_vs_1.0':'不一致','BAD_vs_BAD':'一致','guide':'文字列完全一致'}
 def test_07_failed_save_preserves_results(self):
  self.read();before=copy.deepcopy(self.w.results);summary=copy.deepcopy(self.w.comparison_summary)
  files={p:p.read_bytes() for p in (main.MAP,main.MAP.with_name('employee_contacts.json'))}
  import employee_information
  def warning(*args):APP.activeModalWidget().reject()
  with patch.object(employee_information,'commit_employee_information',side_effect=OSError('synthetic save refusal')),patch.object(QMessageBox,'warning',side_effect=warning):self.save_dialog('S2')
  self.assertEqual(self.w.results,before);self.assertEqual(self.w.comparison_summary,summary);self.assertEqual(self.w.mapping,{'E1':'S1'})
  for p,data in files.items():self.assertEqual(p.read_bytes(),data)
  self.assertIn('全数一致',self.w.total_check.text());OBS['failed_save']=self.state()
 def test_08_failed_save_during_active_worker(self):
  self.read();entered=threading.Event();release=threading.Event();real=main.parse_stable_file
  import employee_information
  def held(*args):
   entered.set()
   if not release.wait(6):raise AssertionError('release deadline')
   return real(*args)
  def warning(*args):APP.activeModalWidget().reject()
  with patch.object(main,'parse_stable_file',held):
   self.w.run_read(full=True);worker=self.w.worker;until(entered.is_set)
   try:
    with patch.object(employee_information,'commit_employee_information',side_effect=OSError('synthetic save refusal')),patch.object(QMessageBox,'warning',side_effect=warning):self.save_dialog('S2')
    self.assertFalse(getattr(worker,'results_invalidated',False));self.assertFalse(worker.isInterruptionRequested());self.assertEqual(self.w.mapping,{'E1':'S1'})
   finally:release.set();until(lambda:not worker.isRunning());until(self.w.run_button.isEnabled)
  self.assertEqual(len(self.w.results),90);self.assertTrue(all(r['staff']=='S1' for r in self.w.results));self.assertIn('全数一致',self.w.total_check.text());OBS['failed_active_save']=self.state()
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Audit))
 (E/'observations.json').write_text(json.dumps(OBS,ensure_ascii=False,indent=2,default=list))
 sys.exit(not result.wasSuccessful())
