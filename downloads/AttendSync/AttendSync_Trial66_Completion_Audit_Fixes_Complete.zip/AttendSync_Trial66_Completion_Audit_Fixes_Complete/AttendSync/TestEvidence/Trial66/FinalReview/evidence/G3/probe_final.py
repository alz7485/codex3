import os,sys,json,copy,time,traceback,platform,socket,re,html,subprocess
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
SRC=Path('/workspace/attendsync-fix66/audit-v2/copies/G3');EV=Path('/workspace/attendsync-fix66/audit-v2/evidence/G3');STATE=EV/'state';STATE.mkdir(exist_ok=True);sys.path.insert(0,str(SRC))
socket.create_connection=lambda *a,**k:(_ for _ in ()).throw(AssertionError('network prohibited'))
import runtime_paths
with patch.object(runtime_paths,'get_data_dir',return_value=STATE):import main
from engine import DEFAULT,save_json
from PySide6.QtWidgets import QApplication,QTableWidget,QPushButton
from PySide6.QtCore import Qt,QTimer
import PySide6,openpyxl,manual
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
main.MAP=STATE/'mapping.json';main.DB=STATE/'cache.sqlite3';main.CONFIG=STATE/'settings.json'
MAPPING={'E1':'S1'};save_json(main.MAP,MAPPING);save_json(main.MAP.with_name('employee_contacts.json'),{'version':1,'contacts':[dict(employee='E1',staff='S1',name='Synthetic',email='one@example.invalid')],'employee_information_registered':True})
with patch.object(main,'current_attendance_month',return_value=(2026,10)):W=main.Window()
W.show();APP.processEvents();OUT=[]
def run(name,fn):
 t=time.perf_counter()
 try:OUT.append(dict(name=name,status='PASS',details=fn(),seconds=time.perf_counter()-t))
 except Exception:OUT.append(dict(name=name,status='FAIL',error=traceback.format_exc(),seconds=time.perf_counter()-t))
 (EV/'final_results.json').write_text(json.dumps(dict(environment=dict(python=sys.version,platform=platform.platform(),pyside6=PySide6.__version__,openpyxl=openpyxl.__version__),tests=OUT),ensure_ascii=False,indent=2))
def snapshot():return dict(status=W.status.text(),progress=W.progress.value(),rows=len(W.results),visible=len(W.visible),mail=W.mail_button.isEnabled(),print=W.print_button.isEnabled(),preview=W.preview_button.isEnabled(),total=W.total_check.text())
def queued_save():
 worker=main.ReadWorker(STATE,copy.deepcopy(DEFAULT));W.worker=worker
 worker.progress.connect(W.on_progress,Qt.QueuedConnection);worker.result.connect(W.read_done,Qt.QueuedConnection)
 W.status.setText('old read in progress');W.progress.setValue(75);W.results=[dict(status='不一致')];W.visible=list(W.results)
 errors=[];after=[]
 def action():
  d=APP.activeModalWidget()
  try:
   assert d.findChild(QTableWidget,'employeeIdTable').rowCount()==1
   worker.progress.emit(2,2,'queued before save')
   next(b for b in d.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
   assert worker.results_invalidated
   after.append(snapshot())
   worker.progress.emit(2,2,'queued after save')
   worker.result.emit({},[],[],{'files':2,'parsed':2,'cache_hits':0,'file_errors':[],'read_warnings':[]})
  except Exception:errors.append(traceback.format_exc());d.reject()
 QTimer.singleShot(0,action);W.edit_map();APP.processEvents();assert not errors,errors
 expected=after[0];actual=snapshot();assert actual==expected,(expected,actual)
 assert actual['progress']==0 and not actual['rows'] and not actual['mail'] and not actual['print'] and not actual['preview']
 assert '社員情報を保存' in actual['status'] and '全数一致' not in actual['total']
 W.grab().save(str(EV/'queued_save_state.png'));W.worker=None
 return dict(worker_running=False,signals=['queued progress before real save','queued progress after real save','queued result after real save'],before_delivery=expected,after_delivery=actual)
run('real_employee_save_rejects_queued_progress_and_result',queued_save)
def fresh_progress():
 worker=main.ReadWorker(STATE,copy.deepcopy(DEFAULT));W.worker=worker;worker.progress.connect(W.on_progress,Qt.QueuedConnection)
 worker.progress.emit(1,2,'new synthetic read');APP.processEvents();assert W.progress.value()==50 and 'new synthetic read' in W.status.text()
 expected=(W.progress.value(),W.status.text())
 other=main.ReadWorker(STATE,copy.deepcopy(DEFAULT));other.progress.connect(W.on_progress,Qt.QueuedConnection);other.progress.emit(2,2,'unrelated');APP.processEvents();assert expected==(W.progress.value(),W.status.text())
 W.worker=None;return dict(current_worker_progress=expected,unrelated_sender_ignored=True)
run('fresh_worker_progress_updates_and_unrelated_worker_ignored',fresh_progress)
def documents():
 pdf=SRC/'Manual/操作マニュアル.pdf';info=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=True);(EV/'pdfinfo_final.txt').write_text(info.stdout)
 subprocess.run(['pdftotext','-layout',str(pdf),str(EV/'manual_pdf_final.txt')],check=True,capture_output=True)
 assert re.search(r'Pages:\s+18\b',info.stdout)
 pages=json.loads((SRC/'Manual/guide_pages.json').read_text());assert len(pages)==18
 raw=(SRC/'Manual/index.html').read_text();h=html.unescape(re.sub('<[^>]+>',' ',raw));p=(EV/'manual_pdf_final.txt').read_text();norm=lambda s:re.sub(r'\s+','',s.replace('\u0332','_'))
 captions=[s for page in pages for s in [page[1],page[2],*[s for pin in page[3] for s in pin[2:]]]]
 missing=[s for s in captions if norm(s) not in norm(h) or norm(s) not in norm(p)];assert not missing,missing
 assert '値（文字列完全一致）' in h and norm('値（文字列完全一致）') in norm(p)
 links=re.findall(r'(?:href|src)="([^"]+)"',raw);bad=[s for s in links if not s.startswith(('#','http:','https:')) and not (SRC/'Manual'/html.unescape(s)).exists()];assert not bad,bad
 for name in ['START_HERE.txt','EXE化手順.txt']:assert 'Trial66' in (SRC/name).read_text().splitlines()[0]
 assert '18ページ' in (SRC/'START_HERE.txt').read_text()
 required=['VALIDATION_TRIAL66.md','TestEvidence/Trial66/README.md','TestEvidence/Trial66/Regression/README.txt','TestEvidence/Trial66/FinalReview/README.txt']
 assert all((SRC/name).is_file() for name in required)
 validation=(SRC/required[0]).read_text();assert 'Windows' in validation and '未検証' in validation
 entries={d:[str(p.relative_to(SRC)) for p in (SRC/'TestEvidence/Trial66'/d).iterdir()] for d in ['Regression','FinalReview']}
 return dict(pdf_pages=18,caption_segments=len(captions),all_segments_match_html_and_pdf=True,html_link_attributes=len(links),missing_links=bad,required_entries=required,pending_prerelease_entries=entries,real_windows_delivery_claimed=False)
run('current_html_pdf_and_new_validation_evidence_entries',documents)
def entry():
 paths=[]
 with patch.object(manual,'application_dir',return_value=SRC),patch.object(manual.QDesktopServices,'openUrl',side_effect=lambda u:paths.append(u.toLocalFile()) or True):
  W.btn_manual.click();W.manual_action.trigger()
 assert paths==[str(SRC/'Manual/index.html')]*2 and W.manual_action.shortcut().toString()=='F1'
 return dict(opened_paths=paths,shortcut='F1')
run('current_manual_button_and_F1_entry',entry)
W.worker=None;W.close();APP.processEvents();print(json.dumps(OUT,ensure_ascii=False,indent=2));sys.exit(any(t['status']!='PASS' for t in OUT))
