import os,sys,json,copy,re,html,traceback,platform
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
SRC=Path('/workspace/attendsync-fix66/audit/copies/G3');ROOT=Path('/workspace/attendsync-fix66/audit/evidence/G3');sys.path.insert(0,str(SRC))
STATE=ROOT/'adjacent_state';STATE.mkdir(exist_ok=True)
import runtime_paths
with patch.object(runtime_paths,'get_data_dir',return_value=STATE):import main
from engine import DEFAULT,save_json,reconcile
from PySide6.QtWidgets import QApplication,QTableWidget,QPushButton,QLineEdit
from PySide6.QtCore import QTimer,Qt,QPointF,QMimeData,QUrl
from PySide6.QtGui import QDropEvent
import employee_information
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
main.MAP=STATE/'mapping.json';main.DB=STATE/'cache.sqlite3';main.CONFIG=STATE/'settings.json'
mapping={'E1':'S1'};contacts={'version':1,'contacts':[dict(employee='E1',staff='S1',name='One',email='one@example.invalid')],'employee_information_registered':True}
save_json(main.MAP,mapping);save_json(main.MAP.with_name('employee_contacts.json'),contacts)
with patch.object(main,'current_attendance_month',return_value=(2026,10)):W=main.Window()
OUT=[]
def check(name,fn):
    try:OUT.append(dict(name=name,status='PASS',details=fn()))
    except Exception:OUT.append(dict(name=name,status='FAIL',error=traceback.format_exc()))
def btn(d,text):return next(b for b in d.findChildren(QPushButton) if b.text()==text)
def imports():
    path=ROOT/'real_import.csv';path.write_text('A,B,C,D,E,F,G,H,I,J\nS2,E2,Two,,,,,,,two@example.invalid\n')
    before=main.MAP.read_bytes(),main.MAP.with_name('employee_contacts.json').read_bytes();errors=[];observed=[]
    def outer_action():
        outer=APP.activeModalWidget()
        def nested_action():
            inner=APP.activeModalWidget()
            try:
                t=inner.findChild(QTableWidget,'informationPreview');assert t.rowCount()==1
                assert t.item(0,0).text()=='S2' and t.item(0,1).text()=='E2'
                assert btn(inner,'一覧に反映').isEnabled();btn(inner,'一覧に反映').click()
            except Exception:errors.append(traceback.format_exc());inner.reject()
        try:
            QTimer.singleShot(50,nested_action)
            with patch.object(employee_information.QFileDialog if hasattr(employee_information,'QFileDialog') else main.QFileDialog,'getOpenFileName',return_value=(str(path),'')):
                # Actual import dialog receives file via local drop routing on outer dialog.
                from csv_drop import CsvDropHandler
                handler=next(x for x in outer.children() if isinstance(x,CsvDropHandler))
                handler.deliver(str(path))
            t=outer.findChild(QTableWidget,'employeeIdTable');assert t.rowCount()==2
            observed.extend(t.item(i,0).text() for i in range(2));btn(outer,'キャンセル').click()
        except Exception:errors.append(traceback.format_exc());outer.reject()
    QTimer.singleShot(0,outer_action);W.edit_map();APP.processEvents();assert not errors,errors
    assert (main.MAP.read_bytes(),main.MAP.with_name('employee_contacts.json').read_bytes())==before
    assert W.mapping==mapping
    return dict(provisional_employees=observed,cancel_preserves_files=True)
check('real_import_apply_then_outer_cancel',imports)
def folder_drop():
    edit=W.folder;original=edit.text();mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(str(ROOT/'real_import.csv'))]);e=QDropEvent(QPointF(1,1),Qt.CopyAction,mime,Qt.LeftButton,Qt.NoModifier);edit.dropEvent(e);assert edit.text()==original and not e.isAccepted()
    mime2=QMimeData();mime2.setUrls([QUrl.fromLocalFile(str(ROOT))]);e2=QDropEvent(QPointF(1,1),Qt.CopyAction,mime2,Qt.LeftButton,Qt.NoModifier);edit.dropEvent(e2);assert edit.text()==str(ROOT) and e2.isAccepted()
    return dict(csv_ignored=True,folder_accepted=True)
check('attendance_folder_drop_rejects_csv',folder_drop)
def documents():
    pages=json.loads((SRC/'Manual/guide_pages.json').read_text());raw=(SRC/'Manual/index.html').read_text();h=html.unescape(re.sub('<[^>]+>',' ',raw));pdf=(ROOT/'manual_pdf.txt').read_text()
    norm=lambda x:re.sub(r'\s+','',x)
    missing=[]
    for i,p in enumerate(pages,1):
        for text in [p[1],p[2],*[s for pin in p[3] for s in pin[2:]]]:
            if norm(text) not in norm(h) or norm(text) not in norm(pdf):missing.append([i,text])
    assert len(pages)==18 and not missing,missing
    phrase='時刻・時間・文字列・値（文字列完全一致）の用途を合わせます。';assert phrase in h and norm(phrase) in norm(pdf)
    links=re.findall(r'(?:href|src)="([^"]+)"',raw);bad=[v for v in links if not v.startswith(('#','https:','http:')) and not (SRC/'Manual'/html.unescape(v)).exists()];assert not bad,bad
    for name in ('START_HERE.txt','EXE化手順.txt'):assert (SRC/name).read_text().splitlines()[0].find('Trial66')>=0
    assert '18ページ' in (SRC/'START_HERE.txt').read_text()
    return dict(page_count=len(pages),all_captions_match=True,html_local_links=len(links),html_missing_links=bad,validation_entry_exists=(SRC/'VALIDATION_TRIAL66.md').exists(),evidence_entry_files=[str(p.relative_to(SRC)) for p in (SRC/'TestEvidence/Trial66').iterdir()])
check('html_pdf_json_and_entry_documents',documents)
def semantics():
    cfg=copy.deepcopy(DEFAULT);cfg['comparisons']=[dict(name='Value',xlsx='start',csv='start',type='number',enabled=True)]
    statuses=[]
    for a,b in [('1','1.0'),('BAD','BAD')]:
        x=dict(date='2026-10-01',employee='E1',name='One',values={'start':a},invalid_fields=[])
        c=dict(date='2026-10-01',staff='S1',name='One',values={'start':b},invalid_fields=[],missing_fields=[])
        rows,_=reconcile({'E1':dict(info=dict(employee='E1',name='One'),records=[x])},[c],mapping,cfg);statuses.append(rows[0]['status'])
    assert statuses==['不一致','一致'],statuses
    return dict(inputs=[['1','1.0'],['BAD','BAD']],statuses=statuses)
check('number_documented_exact_string_comparison',semantics)
W.close();APP.processEvents()
result=dict(environment=dict(python=sys.version,platform=platform.platform()),tests=OUT);(ROOT/'adjacent_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(any(t['status']!='PASS' for t in OUT))
