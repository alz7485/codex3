import os,sys,json,hashlib,copy,csv,sqlite3,tempfile,time,threading,traceback,unittest,subprocess,ast
from pathlib import Path
from datetime import date,timedelta
from unittest.mock import patch
ROOT=Path('/workspace/attendsync-fix66/audit-v2/copies/G6');EVID=Path(__file__).parent
sys.path.insert(0,str(ROOT));os.environ['QT_QPA_PLATFORM']='offscreen'
import runtime_paths
TEMP=tempfile.TemporaryDirectory(dir=EVID);DATA=Path(TEMP.name)/'userdata';DATA.mkdir()
with patch.object(runtime_paths,'get_data_dir',return_value=DATA):import main
from engine import DEFAULT,save_json,reconcile
from openpyxl import Workbook
from PySide6.QtWidgets import QApplication,QTableWidget,QPushButton
from PySide6.QtCore import QTimer
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
OBS={}
class Probe(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(dir=EVID);self.addCleanup(self.t.cleanup);self.p=Path(self.t.name);self.d=self.p/'userdata';self.d.mkdir();self.src=self.p/'input';self.src.mkdir()
  self.paths=patch.multiple(main,CONFIG=self.d/'settings.json',MAP=self.d/'staff_mapping.json',DB=self.d/'attendance_cache.sqlite3');self.paths.start();self.addCleanup(self.paths.stop)
  self.cfg=copy.deepcopy(DEFAULT);self.cfg.update(year=2026,month=10,data_last_row=38)
  save_json(main.CONFIG,{**self.cfg,'future_extension':{'retain':['alpha',1]}});save_json(main.MAP,{'G6E':'G6S'})
  save_json(self.d/'employee_contacts.json',{'version':1,'contacts':[dict(employee='G6E',staff='G6S',name='Audit Synthetic',email='u@example.invalid')],'employee_information_registered':True})
  w=Workbook();s=w.active;s.title='10月';s['A1']='2026年10月度';s['N1']='G6E';s['U1']='Audit Synthetic'
  self.c=self.src/'a.csv'
  with self.c.open('w',newline='') as f:
   writer=csv.writer(f);writer.writerow(['h']*14)
   for n in range(30):
    dt=date(2026,9,16)+timedelta(days=n);r=n+9
    for col,value in [('A',dt.month),('B',dt.day),('G','09:00'),('H','18:00'),('T','08:00')]:s[f'{col}{r}']=value
    row=['']*14;row[0]=dt.strftime('%Y%m%d');row[3]='G6S';row[4]='Audit Synthetic';row[10:14]=['09:00','18:00','08:00','01:00'];writer.writerow(row)
  w.save(self.src/'b.xlsx');w.close();self.win=main.Window();self.win.cfg=copy.deepcopy(self.cfg);self.addCleanup(self.close)
 def close(self):
  if self.win.worker and self.win.worker.isRunning():self.win.worker.cancel();self.win.worker.wait(8000)
  self.win.worker=None;self.win.close();APP.processEvents()
 def read(self,ui=False,full=False):
  worker=main.ReadWorker(self.src,self.cfg,full);out=[];worker.result.connect(lambda *a:out.append(a))
  if ui:self.win.worker=worker;worker.result.connect(self.win.read_done)
  worker.run();assert len(out)==1;assert not out[0][3].get('fatal_error'),out[0][3];return out[0]
 def save_dialog(self,new_staff=None):
  errors=[]
  def action():
   d=APP.activeModalWidget()
   try:
    if new_staff:d.findChild(QTableWidget,'employeeIdTable').cellWidget(0,2).setEditText(new_staff)
    next(b for b in d.findChildren(QPushButton) if b.text()=='社員情報を登録').click()
   except Exception as e:errors.append(repr(e));d.reject()
  QTimer.singleShot(0,action);self.win.edit_map();assert not errors,errors
 def test_01_replacement_full_agrees(self):
  self.read(ui=True);self.assertIn('全数一致',self.win.total_check.text());self.assertEqual(self.read()[3]['cache_hits'],2)
  st=self.c.stat();self.c.write_bytes(self.c.read_bytes().replace(b'09:00',b'11:00'));os.utime(self.c,ns=(st.st_atime_ns,st.st_mtime_ns));a=self.read(ui=True);b=self.read(full=True)
  from collections import Counter
  counts=lambda r:dict(Counter(x['status'] for x in reconcile(r[0],r[1],{'G6E':'G6S'},self.cfg)[0]))
  self.assertEqual(counts(a),{'不一致':30,'一致':60});self.assertEqual(counts(a),counts(b));self.assertIn('全数一致に未達',self.win.total_check.text());OBS['CA01']={'cached_replacement':counts(a),'parsed':a[3]['parsed']}
 def test_03_stale_completion_rejected(self):
  entered=threading.Event();release=threading.Event();real=main.xlsx_read
  def delayed(*a):entered.set();assert release.wait(8);return real(*a)
  with patch.object(main,'xlsx_read',delayed):
   worker=main.ReadWorker(self.src,self.cfg,True);self.win.worker=worker;worker.result.connect(self.win.read_done);worker.start()
   try:
    deadline=time.monotonic()+6
    while not entered.is_set() and time.monotonic()<deadline:APP.processEvents();time.sleep(.005)
    assert entered.is_set();self.save_dialog('G6S2');assert worker.isInterruptionRequested()
   finally:release.set();worker.wait(8000);APP.processEvents()
  self.assertFalse(self.win.results);self.assertNotIn('全数一致',self.win.total_check.text());self.assertEqual(self.win.mapping,{'G6E':'G6S2'});OBS['CA03']='late worker rejected after actual employee save'
 def test_04_actual_save_resets_summary(self):
  self.read(ui=True);self.assertIn('全数一致',self.win.total_check.text());self.save_dialog();self.assertFalse(self.win.results);self.assertIsNone(self.win.comparison_summary);self.assertTrue(all(v.text()=='0' for v in self.win.metric_values.values()));self.assertNotIn('全数一致',self.win.total_check.text());self.assertFalse(self.win.mail_button.isEnabled());self.assertFalse(self.win.print_button.isEnabled());self.read(ui=True);self.assertIn('全数一致',self.win.total_check.text())
 def test_05_missing_source_and_flags_reparsed(self):
  self.read();db=main.DB
  failures=[]
  for filename,field in [('a.csv','missing_fields'),('b.xlsx','sheet'),('a.csv','file')]:
   with sqlite3.connect(db) as cx:
    packet=json.loads(cx.execute('SELECT data FROM cache WHERE path=?',(str(self.src/filename),)).fetchone()[0]);del packet['records'][0][field];cx.execute('UPDATE cache SET data=? WHERE path=?',(json.dumps(packet),str(self.src/filename)))
   r=self.read();failures.append(r[3]['parsed']);self.assertEqual(r[3]['parsed'],1)
  OBS['CA05']={'single_entry_reparses':failures}
 def test_06_corrupt_and_unavailable_quarantine(self):
  self.read();main.DB.write_bytes(b'G6 synthetic corrupt SQLite')
  with patch.object(Path,'replace',side_effect=PermissionError('synthetic quarantine denied')):r=self.read(full=True)
  self.assertEqual(r[3]['parsed'],2);self.assertTrue(any('利用できない' in w['reason'] for w in r[3]['read_warnings']));self.assertEqual(main.DB.read_bytes(),b'G6 synthetic corrupt SQLite')
  r=self.read(full=True);self.assertEqual(r[3]['parsed'],2);backups=list(self.d.glob('*.corrupt-*'));self.assertEqual(len(backups),1);self.assertEqual(backups[0].read_bytes(),b'G6 synthetic corrupt SQLite');OBS['CA06']='in-memory fallback plus preserved quarantine recovery'
 def test_07_editor600(self):
  n=600;m={f'E{i}':f'S{i}' for i in range(n)};self.win.mapping=m;save_json(main.MAP,m);save_json(self.d/'employee_contacts.json',{'version':1,'contacts':[dict(employee=e,staff=s,name=e,email=f'{e}@example.invalid') for e,s in m.items()],'employee_information_registered':True});seen={}
  def inspect():
   d=APP.activeModalWidget();t=d.findChild(QTableWidget,'employeeIdTable');seen.update(rows=t.rowCount(),candidates=sum(t.cellWidget(i,c).count() for i in range(n) for c in [2,3]));d.reject()
  QTimer.singleShot(0,inspect);start=time.perf_counter();self.win.edit_map();seen['seconds']=time.perf_counter()-start;self.assertEqual(seen['candidates'],2400);OBS['CA07']=seen
 def test_08_import6000_and_conflict(self):
  from employee_information import plan_employee_import
  rows=[dict(employee=f'E{i}',staff=f'S{i}',name=f'P{i}',email=f'u{i}@example.invalid') for i in range(6000)];start=time.perf_counter();m,_,r=plan_employee_import(rows,'linking',{},dict(contacts=[],unlinked_contacts=[]));elapsed=time.perf_counter()-start;self.assertEqual(len(m),6000);self.assertTrue(all(x['matched'] for x in r));m,_,r=plan_employee_import([rows[0],{**rows[0],'employee':'Other'}],'linking',{},dict(contacts=[],unlinked_contacts=[]));self.assertFalse(m);self.assertTrue(all(not x['id_matched'] for x in r));OBS['CA08']={'rows':6000,'seconds':elapsed,'conflict_rejected':True}
 def test_09_correct_error_controls(self):
  from settings_dialog import SettingsDialog,SettingsError
  for key,value in [('account','bad'),('always_to','bad'),('always_cc','bad'),('subject','')]:
   d=SettingsDialog(self.win,self.cfg)
   try:
    c=d.mail_controls[key];c.setText(value)
    with self.assertRaises(SettingsError) as got:d._collect_config()
    self.assertIs(got.exception.control,c)
   finally:d.reject();d.deleteLater()
 def test_userdata_roundtrip(self):
  self.assertEqual(self.win.mapping,{'G6E':'G6S'});self.assertEqual(self.win.cfg,self.cfg)
  from engine import read_config,load_json
  cfg=read_config(load_json(main.CONFIG,{}));self.assertEqual(cfg['future_extension'],{'retain':['alpha',1]});self.save_dialog();saved=load_json(main.MAP,{});self.assertEqual(saved,{'G6E':'G6S'});OBS['migration']='synthetic existing settings/mapping/contacts loaded; unknown setting retained'

if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Probe));(EVID/'observations.json').write_text(json.dumps(OBS,ensure_ascii=False,indent=2));TEMP.cleanup();sys.exit(not result.wasSuccessful())
