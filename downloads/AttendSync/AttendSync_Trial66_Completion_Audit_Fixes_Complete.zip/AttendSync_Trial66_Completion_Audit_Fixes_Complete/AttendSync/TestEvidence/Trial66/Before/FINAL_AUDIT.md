# AttendSync Trial65 完成監査・統括最終報告

**完成判定：不可。** 必須の二重処理防止が、同じ宛先の並び替えだけで破れます（CA-02）。社員情報保存後の結果無効化と全数一致表示にも再現済みの不整合があります（CA-03/04）。この固定版を、依頼された全受入条件を満たす完成品として扱うことはできません。修正は実施していません。

確定指摘は根本原因で統合して **11件：P0=0、P1=0、P2=8、P3=3**。このうちCA-05/06は合成キャッシュへの故障注入条件であり、正常運用での自然発生を確認した件数ではありません。Excel式の実害未確認リスクCA-R01と任意改善提案は、この件数に含めません。既存回帰は親の52スクリプト中52成功ですが、独立反例を打ち消しません。

判定はPROTOCOLの「必須仕様不適合」によります。P2をP1に引き上げたり、Windows未検証だけを確定不具合とした判断ではありません。「条件付き可」は検証範囲に阻害要因がない場合の区分であり、現状には適用しません。未検証は残りますが、確定した不適合があるため全体を判定保留にする必要もありません。

## 対象・採用基準・独立性

- 実行ID `complete-Trial65-20261018`、完成監査、第13役 audit_coordinator。基準版比較を伴う修正後監査ではありません。
- 固定完全版ZIP SHA256 `ce08b2a9ae0ca840879e9de795f56c5b54a9c717b8116e06c1b9ed97e4add0b2`。配布マニフェスト1162件＝AttendSync source1159件＋ZIP直下案内3件。マニフェスト自身を含むZIPエントリは1163。欠損差ではありません。
- 採用仕様はBRIEFのユーザー承認要求、現行COM仕様と現行文書。旧GraphアプリID要件、将来の派遣元CSV対応、未承認の削除/退職方針や新機能を必須化していません。
- AGENTS、役TOML、PROTOCOL、REPORT_TEMPLATE、BRIEF/run、orchestration、PARENT_CHECKS、manifest_scope、preservation、12初回報告を読みました。初回報告確定後に統括専任として全件を比較し、多数決ではなくコード・ログ・自作反例で裁定しました。
- 専門役はfork_turns=none、他役未読で初回結論を確定。利用上限の中断では7報告を保持し、残5役は新しい担当へ同役証跡のみ継承。継承前任との完全な独立再監査とは数えません。未実行を成功へ算入していません。
- Linux/Python3.12.14、既設venv、PySide6 6.12.0/openpyxl3.1.5。Qt offscreen、bytecode禁止、各実行timeout。専用copies/audit_coordinatorの無変更製品を読み、合成データ・追加コードはevidence/audit_coordinatorだけへ保存。実COM/送信/認証/外部通信/依存追加/git/追加spawnは実施していません。

## 全12分野の実施状況

| 分野 | 状態・独立初回報告 | 実施した主要経路 | 統合所見 | 件数の単位 |
|---|---|---|---|---|
| 仕様整合性 | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_specification.md) | 登録先行・ID/列/CP932・実Worker・年月/表示/メール | CA-10 | 12独自メソッド、既存3本/36メソッド |
| バグ・例外 | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_bugs.md) | 実Worker・キャッシュ破損・取消・GUI・模擬メール障害 | CA-06 | 独自2本（unittest9＋連続GUI） |
| UI・UX | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_uiux.md) | 実QtのCSV drop/保存/範囲/ON-OFF・最小幅・PDF | CA-09 | 独自15グループ、PDF第2ページ描画 |
| パフォーマンス | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_performance.md) | 600社員勤怠・600人編集・6000人取込・取消 | CA-07/08 | 独自測定21プロセス＋既存2本 |
| アーキテクチャ | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_architecture.md) | 設定snapshot・実QThread世代・保存取引・契約・COM寿命 | CA-03/05 | 独自2本/9メソッド、既存6固有本 |
| データ整合性 | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_data_integrity.md) | 両ID・式/空欄/0・秒/年月・欠月/欠損・保存/復旧 | CA-01/05 | 独自40チェック＋8チェック＋故障1シナリオ、既存4本 |
| セキュリティ | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_security.md) | 宛先/本文・履歴・式CSVのOpen到達・限定秘密署名 | CA-02、CA-R01 | 独自最終15メソッド、既存2本/31メソッド |
| 配布・環境 | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_distribution.md) | 両ZIP/共通コード・依存/資産・必要版起動・社員サンプル | CA-11 | 再開独自2本＋既存2本。実ビルド未実施 |
| 自動化・省力化 | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_automation.md) | 2月反復/取消再開・社員差替え・部分失敗・重複 | CA-02 | 機能11条件＋保護2条件。既存113メソッド＋assert1本 |
| 破壊的テスト | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_destructive.md) | 保存/journal/lock・故障/部分失敗・不明状態抑止 | CA-06 | 独自27条件再実行＋追加7。過去実行を加算せず |
| 改善提案・新機能 | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_improvements.md) | 2社員30日実操作・登録/範囲/模擬復帰 | 確定なし、任意3提案 | 独自2本。W01–08とM01を内訳表示 |
| 懐疑的独立監査 | 完了・[初回報告](/workspace/codex3/audit-runs/complete-Trial65-20261018/reports/audit_skeptic.md) | 実Worker/UI/キャッシュ・隠し式0・取消・模擬メール | CA-01/04 | 独自2本、最終12＋4条件 |

すべて実施済みですが、各役の未検証を解消した意味ではありません。Windows連携・ビルドは12役全体でも実機未実施です。各役の既存試験は相互重複があるので総計へ加算しません。詳細な実行失敗・中断・再実行は各初回報告を保持しています。

## 根本原因ごとの確定指摘

以下の再現はすべて固定Trial65です。CA-01〜06の重要論点は統括の自作probeで実行再検証し、CA-07/09/11も短い補助試験で確認しました。CA-08/10は元役の具体ログと独立した静的経路確認を採用し、同じ全数試験を再実行していません。

### CA-01 同一サイズ・更新日時の差替えで古い勤怠を一致判定

- 重大度／確度：**P2／再現済み**。元ID：DI-01, SK-01。
- 根拠：[main.py:51](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:51)、[main.py:110](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:110)、[main.py:156](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:156)。証拠：[observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/observations.json)、[probe_results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_data_integrity/probe_results.json)、[results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_skeptic/reproduce_2/results.json)。
- 前提・手順：前回読込後、CSVの09:00を10:00へ同長置換しmtime_nsを保持。実ReadWorker→reconcile。
- 期待／実際・影響：現行入力は始業30件不一致であるべき。通常読込はcache_hits=2で90件一致、fullは60一致/30不一致。必要な通知も一覧へ出ない。
- 改善案（未実装）：内容指紋を再利用条件へ追加し費用を測定。差替え・復元後は完全再読み込みを暫定回避とする。
- 検証限界・反証：Windowsの同期・復元による自然発生頻度は未検証。通常mtime更新の対照はキャッシュ1件/解析1件となり正常。一般的な保存すべての障害ではない。

### CA-02 等価な宛先の並び替え・表記変更が二重処理防止を通過

- 重大度／確度：**P2／再現済み**。元ID：SEC-01, AUTO-01。
- 根拠：[classic_outlook.py:99](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/classic_outlook.py:99)、[mail_state.py:4](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/mail_state.py:4)、[outlook_mail.py:23](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/outlook_mail.py:23)。証拠：[observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/observations.json)、[probe_results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_security/probe_results.json)、[resume_results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_automation/resume_results.json)。
- 前提・手順：同一社員・送信元・件名・本文・受信者集合・送信ONで処理後、必須CCの順だけ変更して再実行。通常build_mail_plansと永続履歴を使用。
- 期待／実際・影響：同じ配送先への同内容は既処理として停止すべき。統括模擬Sendは2回。完全同一プラン再実行は停止。専門役はドメイン大小文字変更でも再現。無操作送信、別宛先漏えい、実配送は主張しない。
- 改善案（未実装）：指紋用To/CCを役割別に正規化・整列し、既存履歴との互換照合を設計。表示順と実送信順は保持してよい。暫定的には既処理通知の宛先整理後再実行を避ける。
- 検証限界・反証：COMは独自インメモリ模擬。Windows/Outlookでの実配送と全UIクリック列は未検証。受信者追加や本文変更による正当な別通知とは区別する。

### CA-03 社員情報保存による結果無効化を進行中workerが上書き

- 重大度／確度：**P2／再現済み**。元ID：ARCH-01。
- 根拠：[main.py:1178](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:1178)、[main.py:1268](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:1268)、[main.py:1328](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:1328)。証拠：[observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/observations.json)、[boundary_probe.log](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_architecture/boundary_probe.log)。
- 前提・手順：実ReadWorkerのXLSX解析をEventで待機し、実社員UIでE1→S1をE1→S2へ保存後に解析を解放。
- 期待／実際・影響：再読込要求を出して結果を消したなら保存前のworker完了を拒否すべき。割込Falseの旧workerから、新mappingと開始時cfgを使う30行が再表示。今回の結果は要確認で、誤送信・偽一致は確認しない。
- 改善案（未実装）：登録保存時に実行世代を更新して古い完了を拒否。開始時mapping/除外パスも実行コンテキストへ保持するか、読込中の保存を制御。
- 検証限界・反証：待機のみモックでQThreadとQt保存は実行。複数プロセス、完了が先の順序は未検証。暫定回避は読込終了後に登録して再読込。

### CA-04 結果クリア後も集計カード・全数一致が残る

- 重大度／確度：**P2／再現済み**。元ID：SK-02。
- 根拠：[main.py:1180](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:1180)、[main.py:995](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:995)。証拠：[observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/observations.json)、[stale_summary.png](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_skeptic/reproduce_2/stale_summary.png)。
- 前提・手順：90件全数一致を実表示後、社員情報UIで内容を変えず登録保存。
- 期待／実際・影響：結果無効化時に集計も未照合へ戻すべき。results=0・再読込要求なのに一致90/全数90・全数一致が残る。確認完了の誤認を招く。元役では印刷/メール無効を確認しており、旧結果の配送を意味しない。
- 改善案（未実装）：結果・指標・全数式・診断・進捗を共通の無効化処理で初期化。保存後に再読込し、再読込前の全数一致を信用しない。
- 検証限界・反証：Qt offscreenで再現。Windows描画・支援技術は未検証。CA-03と操作入口は同じだが、本件はworker不在でも起きる表示初期化漏れのため別ID。

### CA-05 不完全なキャッシュpacketを正常受入する契約の欠落

- 重大度／確度：**P2／再現済み**。元ID：ARCH-02, DI-02。
- 根拠：[main.py:59](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:59)、[main.py:80](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:80)、[main.py:471](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:471)、[engine.py:475](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/engine.py:475)。証拠：[observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/observations.json)、[supplement_observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/supplement_observations.json)、[cache_metadata_results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_data_integrity/cache_metadata_results.json)、[boundary_probe.log](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_architecture/boundary_probe.log)。
- 前提・手順：故障注入限定。現行署名の合成SQLite JSONから出典file/sheet/row、またはCSV missing_fieldsを削除。
- 期待／実際・影響：必須情報を欠くpacketは失効して再解析すべき。出典欠落でもcacheヒットし詳細UIでKeyError(file)（統括再現）。DI-02は列不足の要確認が3項目の空欄一致へ変わりfullで要確認へ復帰。
- 改善案（未実装）：ソース別packet形式版・出典・欠損/異常フラグを必須契約として共通検証。不正エントリだけ失効。詳細UIにも最終診断表示。完全再読込が回避策。
- 検証限界・反証：正常な現行パーサがこの欠損を自然生成することは未確認。故障時の防御不足を確定し、通常CSV列不足処理の欠陥や自然な誤一致頻度は認定しない。内容指紋CA-01だけでは直らない。

### CA-06 SQLite本体破損を完全再読み込みで回復できない

- 重大度／確度：**P2／再現済み**。元ID：BUG-01, DST-01。
- 根拠：[main.py:89](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:89)、[main.py:93](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:93)、[engine.py:381](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/engine.py:381)、[main.py:780](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:780)。証拠：[observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/observations.json)、[probe_ui_state_recheck.log](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_bugs/probe_ui_state_recheck.log)、[resume_extra_results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_destructive/resume_extra_results.json)。
- 前提・手順：故障注入限定。正常な合成入力の読込後、派生DBだけ非SQLiteバイト列に置換しfull=True。
- 期待／実際・影響：キャッシュを使わず再解析する操作は派生DB破損から回復すべき。full分岐前にDB初期化でfatal=file is not a database、解析0。合成DB除去後は同じ入力で2ファイル解析。GUIは失敗を明示して前回結果を保持。
- 改善案（未実装）：破損DBを安全に隔離・再生成するかキャッシュなしで続行。権限/容量等と区別し回復操作を提示。現状回避はアプリを閉じキャッシュだけ退避後再読込。
- 検証限界・反証：実ディスク障害の自然発生、Windowsロック、SQLite全破損形態は未検証。勤怠原本消失・成功誤表示を認定しない。

### CA-07 登録済み社員編集でメール候補が二次的に増殖

- 重大度／確度：**P2／再現済み**。元ID：PERF-01。
- 根拠：[main.py:1108](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:1108)、[main.py:1114](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:1114)、[main.py:1133](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/main.py:1133)。証拠：[editor_600_repeat.jsonl](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_performance/editor_600_repeat.jsonl)、[supplement_observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/supplement_observations.json)。
- 前提・手順：全員一意なID・メールを登録した600人の実Window.edit_map。
- 期待／実際・影響：不要な候補複製を避け画面応答を保つべき。元役の600人は182100候補、GUI停止3.35秒、RSS約397MiB。統括の60/120人でも候補2010/7620がn(n−1)/2+4nに一致し、作成途中の使用済集合が原因と確認。
- 改善案（未実装）：全割当を先に集計し候補を共有/遅延生成。モデルとデリゲートを検討。
- 検証限界・反証：P2は数百人規模での条件付き操作停止。人数上限/秒数の受入仕様は未指定で、600人未満のすべてで不適合とはしない。Windowsと1000人以上、改善後効果は未検証。

### CA-08 社員取込計画の全件再走査が大規模CSVでGUI停止

- 重大度／確度：**P2／再現済み**。元ID：PERF-02。
- 根拠：[employee_information.py:142](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/employee_information.py:142)、[employee_information.py:146](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/employee_information.py:146)、[employee_information.py:221](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/employee_information.py:221)。証拠：[07_employee_gui_n_6000.jsonl](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_performance/07_employee_gui_n_6000.jsonl)、[06_employees_n_6000.jsonl](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_performance/06_employees_n_6000.jsonl)。
- 前提・手順：一意な6000社員のA/B/C/J CSVを実取込ダイアログでプレビュー。
- 期待／実際・影響：取込中にも中止/再描画を保つべき。元役の実GUIは2.590秒タイマー停止、CSV解析自体0.0108秒に対し計画関数2.7708秒。統括は各行のnew_mapping逆走査とunique再走査がGUI同期経路にあることを確認。
- 改善案（未実装）：スタッフ逆引き・pair氏名集合を前計算。計画処理をworker化するなら設定スナップショット/取消を管理。
- 検証限界・反証：性能ログと静的経路で採用し、統括は6000人測定を重複再実行していない。明示人数上限なし、500/1000人でも同じ停止とは主張しない。共有Linux負荷、Windows実測、改善効果は未検証。

### CA-09 メール設定エラーの修正誘導が本文へ向く

- 重大度／確度：**P3／再現済み**。元ID：UIUX-001。
- 根拠：[settings_dialog.py:549](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/settings_dialog.py:549)、[settings_dialog.py:447](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/settings_dialog.py:447)。証拠：[supplement_observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/supplement_observations.json)、[extra_results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_uiux/extra_results.json)。
- 前提・手順：設定メールのアカウント/To/CCをbad、または件名を空欄にして保存。
- 期待／実際・影響：原因欄に誘導すべき。検証は保存を拒否するが本文へフォーカスする。統括も不正アカウントのSettingsError.controlがbodyであることを確認。誤保存/誤送信は認定しない。
- 改善案（未実装）：検証例外に項目キーを持たせ対応controlへ誘導。
- 検証限界・反証：元役は実Qt最小サイズで4条件再現。WindowsのDPI/IME/支援技術は未検証。

### CA-10 マニュアルの数値という説明が文字列比較と不整合

- 重大度／確度：**P3／再現済み**。元ID：SPEC-001。
- 根拠：[Manual/index.html:3](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/Manual/index.html:3)、[settings_dialog.py:30](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/settings_dialog.py:30)、[engine.py:484](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/engine.py:484)。証拠：[boundary_observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_specification/boundary_observations.json)、[boundary.log](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_specification/boundary.log)。
- 前提・手順：比較形式numberで1と1.0、BADとBADを比較。
- 期待／実際・影響：マニュアルをUIの値（文字列として比較）へ揃えるべき。実装は前者不一致/後者一致で現UIどおり。数値同値比較の未実装を必須仕様不適合とはしない。
- 改善案（未実装）：図解を文字列完全一致の説明と短い表記差の例へ変更。
- 検証限界・反証：統括はHTML/UI/engineの定義を静的確認。PDF/画像中の同文言全数は未検証。

### CA-11 完全版の入口資料に旧Trial番号とPDFページ数

- 重大度／確度：**P3／再現済み**。元ID：DIST-01。
- 根拠：[START_HERE.txt:1](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/START_HERE.txt:1)、[START_HERE.txt:22](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/START_HERE.txt:22)、[EXE化手順.txt:1](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/EXE化手順.txt:1)。証拠：[supplement_observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/supplement_observations.json)、[resume_document_data.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_distribution/resume_document_data.json)。
- 前提・手順：固定完全版のSTART_HERE/EXE化手順を入口として読む。
- 期待／実際・影響：現行Trial65/18ページへ揃えるべき。Trial49/Trial46、PDF59ページとの記載が残る。統括も先頭の旧版番号を直接照合。現行ビルド主要コマンドの不整合や起動不能とはしない。
- 改善案（未実装）：入口版名・参照先・ページ数を現行化し配布時に自動照合。
- 検証限界・反証：必要版にはこの2資料なし。全過去資料やWindowsビルド成否をこの指摘に含めない。

## 重複対応と矛盾の裁定

| 元の指摘ID | 統合ID | 裁定・根本原因 |
|---|---|---|
| DI-01 / SK-01 | CA-01 | 入力内容を検証しないstat署名。同じ原因・異なる独立証拠を保持 |
| SEC-01 / AUTO-01 | CA-02 | 受信者順序/表記を意味的同一性へ正規化せず指紋化 |
| ARCH-01 | CA-03 | 登録保存と進行workerの世代境界がない |
| SK-02 | CA-04 | 結果破棄時の集計初期化漏れ。CA-03はworkerあり、本件はなしでも起きる |
| ARCH-02 / DI-02 | CA-05 | 利用先が必須とする出典/異常性メタデータがキャッシュ受入契約から漏れる。症状2種は保持 |
| BUG-01 / DST-01 | CA-06 | full分岐前に既存SQLite依存。JSON packet欠損CA-05とは故障層が異なる |
| PERF-01 / PERF-02 | CA-07 / CA-08 | 前者は候補の保持増殖、後者は計画中の反復走査。別経路・別修正のため2件 |
| UIUX-001 / SPEC-001 / DIST-01 | CA-09 / CA-10 / CA-11 | それぞれ別の入力誘導・比較説明・配布入口の問題 |
| SEC-02 | CA-R01 | Open到達の静的/模擬根拠のみ。実害未確認のリスクとして確定件数外 |
| IMP-F01/02/03 | 任意提案 | 未承認の追加機能。確定不具合に数えない |

- 「通常の変更ではキャッシュ失効」はCA-01を否定しません。統括対照でもmtime更新なら解析し、mtime保持の差替えだけ旧結果を再利用しました。故障注入packet欠落CA-05とも原因を分けます。
- 登録保存の結果0件を確認したAUTO/IMPの正常試験は、未検査だった集計カードCA-04や読込中保存CA-03の反証ではありません。統括が両境界を独立再現しました。
- 完全一致の重複抑止、部分失敗の不明状態停止は成立しますが、意味的に同じ宛先順変更は別キーになるためCA-02が残ります。「宛先追加後の正当な別通知」と混同しません。
- 列不足の通常パーサは要確認を返します。CA-05の偽一致はフラグを故障注入で除いた場合だけ。正常入力の主要判定全体を否定する根拠にはしません。
- number形式は現UIが文字列比較と明示します。数値同値を期待した初回仮説は棄却し、文書表現CA-10のみ採用しました。CSVの合成日付形式修正、ハーネスの表現型/同期/API引数ミス、保存先差替えによる既存試験干渉は製品不具合から除外しました。
- source1159対ZIP1162は、manifest_scopeにより直下案内3件と確認。配布欠損の疑いは棄却しました。完全/必要版の共通実行Python19本は一致し、共通47ファイルの差はREADMEのみ。旧Graphは現起動経路に入りません。
- UIマニュアルの旧フッターと、完全版で現行入口を旧版として案内するCA-11を区別。前者は実操作不適合が示されず任意改善に留めます。

## 実害未確認のリスクと任意改善

**CA-R01（元SEC-02、P2暫定・静的根拠あり）**：外部提供者が数式を混入した社員CSVを、利用者がダブルクリックでExcelへ渡す条件。`excel_jump.py`は通常OpenにReadOnly/UpdateLinks=0等を指定しますがテキスト取込は指定しません。読込だけではアプリは式評価しません。Excelの保護・組織ポリシーに依存し、通信・漏えい・コマンド実行は未再現です。これは確定実害として件数へ入れません。
根拠：[employee_information.py:232](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/employee_information.py:232)、[excel_jump.py:58](/workspace/codex3/audit-runs/complete-Trial65-20261018/snapshot/AttendSync_Trial65_Independent_Audit_Complete/AttendSync/excel_jump.py:58)、[probe_results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_security/probe_results.json)。改善候補はアプリ内原文表示または安全なテキスト表示で、元CSV/既存Excelの設定を黙って変えない方針。実機で安全に式評価条件を確認する余地を残します。

任意提案は、社員CSV追加更新/空欄メール維持を保存前に説明するIMP-F01、不足月理由を全数内訳へ結ぶIMP-F02、読取専用履歴・手動復帰案内IMP-F03、Windows受入記録、依存/配布差分の固定、照合処理のGUI外移動、協調取消です。新機能の効果・工数は未検証で、未依頼機能の欠如を完成阻害としません。詳細は改善役と各専門初回報告の提案表に残します。

## 試験記録と保護確認

| 実施主体・対象 | コマンド/条件 | 終了コード・結果 | 証拠 |
|---|---|---|---|
| 親・固定Trial65専用コピー | `python -B evidence/parent_regression/run_existing.py`（製品venvで個別実行、各60秒） | 52本/52成功、失敗/timeout0。unittest出力311は全ケース総数ではない | [results.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/parent_regression/results.json)、[summary.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/parent_regression/summary.json) |
| 統括・開始保護 | `python -B evidence/audit_coordinator/setup.py` | 0。protected264、source/copy各1159、ZIP、12初回報告一致 | [before.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/before.json) |
| 統括・短い独立反例 | `PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen timeout 35s /workspace/attendsync-audit/venv/bin/python /workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/probe.py` | 0。主要6論点＋通常保存対照の観測成立。不具合が存在するassertの成功を含む | [probe.log](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/probe.log)、[probe.exit](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/probe.exit)、[observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/observations.json) |
| 統括・補助反証 | 同じ環境変数、`timeout 25s /workspace/attendsync-audit/venv/bin/python /workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/supplement.py` | 0。60/120人候補数、packet不足受理、設定エラーcontrol、旧入口版を確認 | [supplement.log](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/supplement.log)、[supplement.exit](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/supplement.exit)、[supplement_observations.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/supplement_observations.json) |
| 統括・終了保護 | `python -B /workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/verify_final.py` | 0。終了ハッシュの詳細は証拠へ記録 | [after.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/after.json) |

統括は独自試験2本（最終実行各1、先行ハーネス失敗各1）、保護/集約用スクリプトを別記します。メソッド・assertion・再実行を合算した架空の総試験件数は作りません。probe初回はDetailDialogの引数順、supplement初回はSettingsDialogの親引数を誤ってTypeError（各終了1）。自作ハーネスだけ訂正し、初回スクリプト・ログ・exitをinitial名で保持、製品/既存テストは一切変更していません。Fontconfig書込警告はありましたが最終観測は取得できました。

初回報告12件のハッシュは親のpreservation記録と統括開始/終了で比較。原本264ファイルとsnapshot1159、専用コピー1159、ZIPも照合し、変更を検出しませんでした。統括はgitコマンドを実行していません。初期git状態保持は親のpreservation記録であり、統括終了後の最終git状態は親が追加照合する記録として区別します。
保護根拠：[preservation.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/preservation.json)、[before.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/before.json)、[after.json](/workspace/codex3/audit-runs/complete-Trial65-20261018/evidence/audit_coordinator/after.json)。試験前後に製品ファイルを復元・書換えする操作はしていません。

## 残存リスク・次に必要な確認

- Windows11/Python3.11の実起動、PyInstaller実ビルド、Pythonなし受領PCでのonedir起動、pywin32凍結、実Excelの再計算/元セル移動、クラシックOutlookの起動中取得・アカウント/受信者解決・COM権限、実保存/配送、msvcrtロック/ACL/共有/長いパスは未検証。Linux模擬から成功を推定しません。送信要求と配送完了も区別します。
- GitHubリモート実体/可用性/CVE照合は外部通信禁止で未検証。ローカル両ZIP/サイドカー/マニフェストと実コード同一性のみ確認済みです。
- 電断/ハードウェア容量障害/fsync耐久性、無期限I/OやCOM停止、全旧履歴の復元、全月・全式/書式・文字コード・DPI/IME、長期大規模運用は網羅していません。旧ハッシュだけに失われたメール内容は復元できると保証しません。
- 秘密署名・配布データ棚卸で代表的な運用userdata/認証物は未検出ですが、全画像/PDF/過去ログ中の個人情報や秘密ゼロを保証しません。
- 当面は通常保存以外の復旧/差替え後にfull再読込、読込終了後の社員更新、保存後の再読込、既処理通知の宛先表記整理後の再実行回避が必要です。これは受入不適合の修正確認を代替しません。

未解決確定ID：**CA-01〜CA-11**。実害未確認：**CA-R01**。完成判定は**不可**で固定します。まずCA-02/03/04とキャッシュ境界を是正する別依頼を受けた後に、元反例→隣接条件→既存回帰を確認し、さらにWindowsの実受入証拠を揃える必要があります。**今回の監査では原本・製品・既存テスト・設定・依存・配布物の修正、コミット、公開、実送信を行っていません。**
