from pathlib import Path
import json,html
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.utils import ImageReader
ROOT=Path(__file__).resolve().parents[2]/'Manual'
pages=json.loads((ROOT/'guide_pages.json').read_text())
pages=json.loads(json.dumps(pages,ensure_ascii=False).replace('数値','値（文字列完全一致）'))
(ROOT/'guide_pages.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
W,H=A4;c=canvas.Canvas(str(ROOT/'操作マニュアル.pdf'),pagesize=A4);c.setTitle('勤怠チェッカー 画面でわかる操作ガイド');c.setAuthor('勤怠チェッカー')
def wrap(text,width,size):
 out=[];line=''
 for ch in text:
  if pdfmetrics.stringWidth(line+ch,'HeiseiKakuGo-W5',size)>width:out.append(line);line=ch
  else:line+=ch
 if line:out.append(line)
 return out
sections=[]
for idx,(image,title,subtitle,notes) in enumerate(pages,1):
 c.bookmarkPage(image);c.addOutlineEntry(title,image,0)
 c.setFillColorRGB(.12,.18,.27);c.setFont('HeiseiKakuGo-W5',20);c.drawString(30,H-45,title)
 c.setFont('HeiseiKakuGo-W5',11);c.drawString(30,H-69,subtitle)
 path=ROOT/'images'/f'{image}.png';reader=ImageReader(str(path));iw,ih=reader.getSize();scale=min((W-60)/iw,420/ih);sw,sh=iw*scale,ih*scale;left=(W-sw)/2;bottom=H-92-sh
 c.drawImage(reader,left,bottom,width=sw,height=sh)
 for n,(x,y,label,description) in enumerate(notes,1):
  px,py=left+x*sw,bottom+(1-y)*sh
  c.setFillColorRGB(.15,.28,.53);c.circle(px,py,10,fill=1,stroke=0);c.setFillColorRGB(1,1,1);c.setFont('Helvetica-Bold',11);c.drawCentredString(px,py-4,str(n))
 y=bottom-31
 for n,(_,_,label,description) in enumerate(notes,1):
  c.setFillColorRGB(.12,.18,.27);c.setFont('HeiseiKakuGo-W5',13);c.drawString(32,y,f'{n}  {label}');y-=21;c.setFont('HeiseiKakuGo-W5',11)
  for line in wrap(description,W-80,11):c.drawString(48,y,line);y-=17
  y-=12
 assert y>45,(title,y)
 c.setFillColorRGB(.4,.44,.5);c.setFont('HeiseiKakuGo-W5',8);c.drawString(30,24,'画面例：Trial64 ／ 説明：Trial66');c.drawRightString(W-30,24,f'{idx} / {len(pages)}');c.showPage()
 pins=''.join(f'<span class="pin" style="left:{x*100}%;top:{y*100}%">{n}</span>' for n,(x,y,_,_) in enumerate(notes,1))
 tips=''.join(f'<li><strong>{html.escape(label)}</strong><p>{html.escape(desc)}</p></li>' for _,_,label,desc in notes)
 sections.append(f'<section id="{image}"><h2>{html.escape(title)}</h2><p class="lead">{html.escape(subtitle)}</p><figure><a href="images/{image}.png" target="_blank"><img src="images/{image}.png" alt="{html.escape(title)}の実画面"></a>{pins}</figure><ol>{tips}</ol><footer>{idx} / {len(pages)} · 画面例：Trial64・説明：Trial66</footer></section>')
c.save()
nav=''.join(f'<a href="#{p[0]}">{html.escape(p[1])}</a>' for p in pages)
(ROOT/'index.html').write_text('''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>勤怠チェッカー 操作ガイド</title><style>
*{box-sizing:border-box}body{margin:0;color:#202b3b;background:#f3f5f8;font-family:system-ui,sans-serif;line-height:1.6}header,main{max-width:1000px;margin:auto;padding:24px}h1{font-size:28px}nav{display:flex;flex-wrap:wrap;gap:8px}a{color:#244a80}nav a,.pdf{padding:7px 12px;background:white;border:1px solid #cbd4df;border-radius:5px;text-decoration:none}section{background:white;padding:24px;margin-bottom:24px;border:1px solid #d5dce5;border-radius:8px;scroll-margin:16px}h2{font-size:23px;margin:0 0 8px}.lead{margin-top:0}figure{position:relative;margin:18px 0}img{display:block;width:100%;height:auto}.pin{position:absolute;transform:translate(-50%,-50%);border-radius:50%;width:28px;height:28px;background:#264880;color:white;text-align:center;line-height:28px;font-weight:700;border:2px solid white;pointer-events:none}ol{padding-left:26px}li{padding-left:5px;margin-bottom:14px}li p{margin:3px 0}footer{color:#6a7482;font-size:12px;border-top:1px solid #ddd;padding-top:12px}@media(max-width:600px){header,main{padding:12px}section{padding:14px}.pin{width:22px;height:22px;line-height:18px;font-size:12px}h2{font-size:20px}}@media print{header{display:none}main{padding:0}section{break-after:page;border:0;margin:0;padding:0}a{color:inherit}}
</style><header><h1>勤怠チェッカー 操作ガイド</h1><p>画面の番号と説明を順に見るだけで操作できます。図をクリックすると拡大表示します。</p><p><a class="pdf" href="操作マニュアル.pdf">PDFで読む（18ページ）</a></p><p><a class="pdf" href="Outlook連携ガイド.html">Outlook連携の設定</a></p><nav>'''+nav+'</nav></header><main>'+''.join(sections)+'</main></html>')
print('Generated 18-page illustrated PDF and offline HTML')
