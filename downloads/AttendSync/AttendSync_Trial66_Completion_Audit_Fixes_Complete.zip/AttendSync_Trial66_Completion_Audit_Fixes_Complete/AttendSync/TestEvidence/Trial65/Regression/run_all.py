from pathlib import Path
import subprocess, os, json, time
root=Path('/workspace/attendsync-audit/trial65-validation/test_copy')
out=root.parent
results=[]
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1')
for test in sorted(root.glob('test_*.py')):
 start=time.monotonic()
 try:
  p=subprocess.run(['/workspace/attendsync-audit/venv/bin/python',str(test)],cwd=root,env=env,capture_output=True,text=True,timeout=45)
  code=p.returncode;log=p.stdout+p.stderr
 except subprocess.TimeoutExpired as e:
  code=124;log=str(e)
 (out/(test.stem+'.log')).write_text(log)
 item=dict(script=test.name,returncode=code,seconds=round(time.monotonic()-start,2),log=test.stem+'.log')
 results.append(item)
 (out/'existing_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print(test.name,code,flush=True)
print('TOTAL',len(results),'PASS',sum(r['returncode']==0 for r in results),flush=True)
