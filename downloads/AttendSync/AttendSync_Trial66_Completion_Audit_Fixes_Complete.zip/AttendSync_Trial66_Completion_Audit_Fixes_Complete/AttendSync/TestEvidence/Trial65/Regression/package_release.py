from pathlib import Path
import json,shutil,hashlib,zipfile
base=Path('/workspace/attendsync-audit');full=base/'AttendSync_Trial65_Independent_Audit_Complete';app=full/'AttendSync';out=base/'trial65-validation';audit=base/'trial65-audit';dest=Path('/workspace/codex3/downloads/AttendSync')
results=json.loads((out/'existing_results.json').read_text());assert len(results)==52 and all(r['returncode']==0 for r in results)
changes='''# Trial65 サブエージェント監査・修正版

破壊、誤操作、欠損データ、誤判定、設定変更、Outlook COMの6役で独立監査し、別担当で最終監査しました。重複を除く9原因を修正しました。

1. **回復データの意味検証**：Base64構文だけでなくUTF-8・JSON・mapping/社員情報の構造を全件検証してから復旧します。不正なら原本2ファイルとジャーナルを保持します。
2. **欠損キャッシュの誤一致**：設定上の全値キー・型、XLSXの年月検証状態を確認し、欠損キャッシュは原本を再解析します。
3. **clock形式変更とキャッシュ**：XLSXの隠し数式0抽出に使うclockキー集合をキャッシュ署名へ含めます。ON/OFFだけなら再解析不要ですが、clock/duration変更は正しく再解析します。
4. **省略設定の既定値**：開始行・終了行・文字コード等を省略した旧設定/詳細JSONで読込が停止しないよう、既定値補完を統一しました。
5. **秒差を表示**：9:00:01と9:00:02の不一致を、一覧・印刷・メールで区別できます。秒が0なら従来の9:00表示を維持します。
6. **対象年月を推測しない**：YYYY年M月度、度なし/空白付き、YYYY/MM・YYYY-MMを確認し、別年/月なら拒否します。年月が空欄・不明な社員は要確認として通常照合を保留し、誤った全数一致にしません。
7. **メールの残り社員を続行**：一部社員を処理後、スレッド終了を確認して残りを操作できるようにしました。途中失敗時は未処理だけ続行でき、処理済み・結果不明行は再処理しません。
8. **表示名変更による重複処理**：COMで使用しない宛先表示名を新しい重複指紋から除外。照合可能な旧COM/Graph履歴を新指紋へ引き継ぎます。
9. **空の必須Toで社員宛先消失**：空の追加Toを連結せず、区切り文字の末尾/先頭を処理します。非空の入力を解析できない場合は、宛先なしとして黙殺せずエラーにします。

クラシックOutlookのCOM連携を維持し、MicrosoftアプリIDは不要です。18ページ図解と社員情報の事前登録、欠月表示切替など既存機能も維持しています。

## 履歴移行の制約

旧版のハッシュしか残っておらず、移行前に宛先表示名を既に変更していた場合、過去の表示名は復元できないため旧履歴を必ず照合できるとは限りません。新指紋への引継ぎ後の名称変更は重複処理を防ぎます。旧版からの切替時はOutlookの下書き・送信済みと処理履歴を確認してください。

Windows向けPythonソース版です。Windows実機・実COM接続・実送信・EXEビルドは未検証です。
'''
validation='''# Trial65 検証結果

- 全52テストスクリプト成功。新規回帰1本・12テストを追加。旧AST試験の依存関数と正常キャッシュfixtureを新しい検証仕様へ追従し、故障注入の期待条件は維持しました。
- 破壊・故障注入：20/20本と追加49条件成功。保存・復旧の各段階、キャッシュ破損、中止/終了、古いworker通知を確認。
- 誤操作：実Qtで22条件成功。社員情報CSVドロップ・取消・検索等に加え、メールの順次処理、全完了、失敗後の未処理続行を確認。
- 欠損：独立10/10本、実ReadWorker/キャッシュ経路と30日分の対象年月プローブ成功。
- 誤判定：独立4本成功、1,212月度・19,392アサーション、実XLSX20ケース、表示/印刷/メール36組、追加28境界を確認。
- 設定・移行：独立15/15本と実データで省略設定6条件成功。未知拡張と元cfgの保持、失敗/取消も確認。
- Outlook COM：独立13/13本、旧COM/Graph履歴の18組移行・別表示名・空To・区切り付き宛先・不正宛先を確認。
- 別担当の独立最終監査：統合8/8本成功。各担当の元の失敗は修正前証跡として保持し、成功件数へ混在させていません。
- 完全版はTestEvidence/Trial65に各役の報告・合成再現・修正前後ログ・全回帰結果を同梱。AUDIT_TRIAL65.mdに集約しました。
- 必要ファイル版と完全版の実行用ソースは同一（必要版は未使用の旧Graph実装を除外）。ZIPのCRCと全ファイルSHA256マニフェストを検査。

環境：Linux / Python3.12.14 / PySide6 / Qt offscreen。COM/Graphは模擬オブジェクト・関数だけを使い、実データ・実認証・実メール送信は使用していません。Windows実機のOutlook接続・配送・EXEビルドは未検証です。旧履歴の復元限界はCHANGES_TRIAL65.mdと独立最終報告に明記しています。
'''
report='''# Trial65 集約・最終監査

6役の独立テストで見つかった指摘を原因ごとにまとめ、9件を修正しました。各担当の再試験、別担当の最終監査8本、全52回帰スクリプトが成功しました。

Windows実機・実COM・実送信は未検証です。旧ハッシュしかなく移行前に宛先表示名が変更されている場合の履歴照合には制約があります。以下の最終監査報告に詳細を記載しています。

'''+(audit/'final/report.md').read_text()
for name,content in [('CHANGES_TRIAL65.md',changes),('VALIDATION_TRIAL65.md',validation),('AUDIT_TRIAL65.md',report)]:
 (app/name).write_text(content);(dest/name).write_text(content)
p=app/'README.md';p.write_text('''# 勤怠チェッカー Trial65

6役のサブエージェントと独立最終監査で確認した9原因を修正しました。キャッシュ・対象年月・復旧・設定省略・秒表示・メールの続行/重複/宛先処理を改善しています。

全52スクリプト成功。CHANGES_TRIAL65.md / VALIDATION_TRIAL65.md / AUDIT_TRIAL65.md参照。クラシックOutlookのCOM連携を維持し、アプリIDは不要です。図解はManual/index.html（18ページ）。Windows実機・実送信・EXEビルドは未検証のソース版です。

旧履歴ハッシュの照合限界は変更内容と監査報告に記載しています。

以下は過去版の説明です。

'''+p.read_text())
(full/'CODEX_START_HERE.txt').write_text('最新版Trial65。6役の独立監査＋別の最終監査で9原因修正、全52スクリプト成功。CHANGES_TRIAL65.md / VALIDATION_TRIAL65.md / AUDIT_TRIAL65.md / TestEvidence/Trial65参照。次版Trial66。\nクラシックOutlook COM連携。アプリID不要。未知の対象年月は要確認で照合を保留。旧履歴ハッシュの制約を監査報告で確認。派遣元CSVの勤怠読込は未実装。\n')
(full/'CODEX_NEXT_TASKS.txt').write_text('次版Trial66。Windows実機でOutlookのアカウント取得/送信元/下書き/送信を確認。実配送・EXEビルドは未検証。COM移行前の変更済み表示名を旧ハッシュだけから復元できない制約あり。\n')
with (full/'CODEX_HANDOFF_SPEC.txt').open('a') as f:f.write('\n\n【Trial65：現在の修正と監査】\n'+changes+'\n'+validation)
evidence=app/'TestEvidence/Trial65';evidence.mkdir(exist_ok=True);shutil.copytree(audit,evidence/'Independent',dirs_exist_ok=True)
reg=evidence/'Regression';reg.mkdir(exist_ok=True)
for p in out.iterdir():
 if p.is_file() and p.suffix in ('.log','.json','.py'):shutil.copy2(p,reg/p.name)
for p in full.rglob('__pycache__'):shutil.rmtree(p)
assert not list(full.rglob('userdata'))
essential=base/'AttendSync_Trial65_Essentials';runtime=essential/'AttendSync';runtime.mkdir(parents=True)
for p in app.glob('*.py'):
 if not p.name.startswith(('test_','benchmark_')) and p.name!='microsoft_mail.py':shutil.copy2(p,runtime/p.name)
for p in app.glob('requirements*.txt'):shutil.copy2(p,runtime/p.name)
shutil.copy2(app/'AttendSync.ico',runtime/'AttendSync.ico');shutil.copytree(app/'Manual',runtime/'Manual')
(runtime/'README.md').write_text('''# 勤怠チェッカー Trial65 必要ファイル版

Windows11 / Python3.11推奨のソース版です。実行・ビルド用Python、アイコン、18ページ図解のみ。EXE、実データ、テスト・監査証跡、サンプル、未使用の旧Graph実装は含みません。

PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\\.venv\\Scripts\\python.exe -m pip install -r requirements-build.txt
.\\.venv\\Scripts\\python.exe main.py
.\\.venv\\Scripts\\python.exe build_onedir.py
```

配布はdist\\AttendSync全体。既存userdataはバックアップ後に引き継いでください。

最初に「社員情報」で社員CSVを選択・ドロップし「一覧に反映」→「社員情報を登録」。初期列はスタッフID=A、社員ID=B、氏名=C、メール=J。その後メインで勤怠を読み込みます。

メールは起動中のクラシックOutlookをCOMで操作します。MicrosoftアプリID・テナントID・ブラウザ認証は不要。「設定」→「メール」→「起動中のOutlookから取得」で送信元・表示名を入力し、保存します。自動送信OFF（初期値）は指定アカウントの下書き、ONはOutlookへの送信要求です。要求完了は配達完了ではありません。

6役の独立監査で9原因を修正し、別担当の最終監査と全52スクリプトが成功しました。旧版で表示名を変更済みの不透明な履歴ハッシュは完全に復元できないため、移行時はOutlookの下書き・送信済みも確認してください。

図解：Manual/index.html。Windows実機・実COM・実送信・EXEビルドは未検証です。
''')
for p in runtime.glob('*.py'):assert p.read_bytes()==(app/p.name).read_bytes()
checks=[]
for root in (full,essential):
 manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and p.name!='MANIFEST_SHA256.json'}
 (root/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));path=dest/(root.name+'.zip')
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,root.name+'/'+p.relative_to(root).as_posix())
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for name,digest in manifest.items():assert hashlib.sha256(z.read(root.name+'/'+name)).hexdigest()==digest
 sha=hashlib.sha256(path.read_bytes()).hexdigest();path.with_suffix('.zip.sha256').write_text(sha+'  '+path.name+'\n');checks.append(dict(file=path.name,bytes=path.stat().st_size,sha256=sha,crc='OK',manifest='OK'))
(out/'package_check.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
p=dest/'README.md';p.write_text('''# 勤怠チェッカー Trial65 — サブエージェント監査・修正版

- [必要ファイル版ZIP](https://github.com/alz7485/codex3/raw/refs/heads/main/downloads/AttendSync/AttendSync_Trial65_Essentials.zip)
- [完全版ZIP（監査証跡・テスト付き）](https://github.com/alz7485/codex3/raw/refs/heads/main/downloads/AttendSync/AttendSync_Trial65_Independent_Audit_Complete.zip)
- [集約・最終監査報告](AUDIT_TRIAL65.md) / [変更内容](CHANGES_TRIAL65.md) / [検証](VALIDATION_TRIAL65.md)
- [社員登録サンプルCSV](AttendSync_Employee_Registration_Sample.csv) / [説明付きZIP](AttendSync_Employee_Registration_Sample.zip)

6役で独立監査し9原因を修正。各担当の再試験、別担当の最終監査、全52本の回帰試験が成功しました。キャッシュ/対象年月/復旧/省略設定/秒表示/メールの続行・重複・宛先処理を修正。クラシックOutlook COM連携でアプリID不要です。旧ハッシュの移行制約は監査報告を参照。Windows実機・実送信・EXEビルドは未検証のソース版です。

以下は過去版の説明です。

'''+p.read_text())
