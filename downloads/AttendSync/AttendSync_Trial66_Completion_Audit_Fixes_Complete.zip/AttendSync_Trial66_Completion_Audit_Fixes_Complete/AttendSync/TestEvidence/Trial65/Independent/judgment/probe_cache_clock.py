import os,sys,copy,tempfile,json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from xml.etree import ElementTree as ET
sys.path.insert(0,os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync'))
from engine import DEFAULT,xlsx_read,reconcile,Cache
from cache_tags import parser_tag
from openpyxl import Workbook
NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'input.xlsx';wb=Workbook();ws=wb.active;ws.title='10月'
 for c,v in {'A1':'2026年10月度','N1':'E1','U1':'テスト社員','A9':10,'B9':1,'V9':'=0'}.items():ws[c]=v
 ws['V9'].number_format='h:mm;;';wb.save(p);wb.close()
 with ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
 sh=ET.fromstring(parts['xl/worksheets/sheet1.xml']);cell=next(c for c in sh.iter(NS+'c') if c.get('r')=='V9');cell.find(NS+'v').text='0';parts['xl/worksheets/sheet1.xml']=ET.tostring(sh)
 with ZipFile(p,'w',ZIP_DEFLATED) as z:
  for n,b in parts.items():z.writestr(n,b)
 cfg=copy.deepcopy(DEFAULT);cfg['xlsx_columns']['extra']='V';cfg['csv_columns']['extra']='O';cfg['comparisons']=[dict(name='追加項目',xlsx='extra',csv='extra',type='duration',enabled=True)]
 cache=Cache(Path(td)/'cache.db');old,hit=cache.parse(p,parser_tag(cfg,'xlsx'),lambda path:xlsx_read(path,cfg))
 cfg['comparisons'][0]['type']='clock'
 cached,hit=cache.parse(p,parser_tag(cfg,'xlsx'),lambda path:xlsx_read(path,cfg));fresh=xlsx_read(p,cfg)
 csv=[dict(staff='S1',name='テスト社員',date='2026-10-01',values={'extra':''},file='test.csv',row=2)]
 def result(packet):return reconcile({'E1':packet},csv,{'E1':'S1'},cfg)[0][0]['status']
 print(json.dumps(dict(cache_hit=hit,cached_value=cached['records'][0]['values']['extra'],fresh_value=fresh['records'][0]['values']['extra'],cached_status=result(cached),fresh_status=result(fresh)),ensure_ascii=False,indent=2))
 assert result(cached)==result(fresh),'照合形式変更後に旧パースキャッシュが残り、同じ入力の判定が異なります'
