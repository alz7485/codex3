"""Independent synthetic Outlook model; never imports pywin32 or connects externally."""
import os,sys,json,tempfile,unittest,copy,hashlib
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
ROOT=os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync')
sys.path.insert(0,ROOT)
from classic_outlook import process_classic_plans
from outlook_mail import DEFAULT_MAIL_SETTINGS,build_mail_plans,addresses
from mail_state import mail_payload

class Collection:
 def __init__(self,values):self.values=values;self.Count=len(values)
 def Item(self,i):return self.values[i-1]
class Recipients:
 def __init__(self,app):self.app=app;self.values=[]
 def Add(self,address):
  if self.app.fail=='recipient':raise RuntimeError('recipient COM failure')
  obj=NS(address=address,Type=0);self.values.append(obj);return obj
 def ResolveAll(self):return True
class Message:
 def __init__(self,app):self.app=app;self.Recipients=Recipients(app);self.EntryID='';self.SendUsingAccount=None
 def Save(self):
  self.app.saved+=1
  if self.app.fail!='empty_id':self.EntryID='synthetic-id'
 def Send(self):self.app.sent.append((self.Subject,self.Body,[(r.address,r.Type) for r in self.Recipients.values]))
class Items:
 def __init__(self,app):self.app=app
 def Add(self,_):self.app.created+=1;return Message(self.app)
class Store:
 def __init__(self,app):self.app=app
 def GetDefaultFolder(self,n):
  if self.app.fail=='folder':raise RuntimeError('folder inaccessible')
  assert n==16
  return NS(Items=Items(self.app))
class App:
 def __init__(self):
  self.created=0;self.saved=0;self.sent=[];self.fail=None
  self.account=NS(SmtpAddress='operator@example.com',DisplayName='Operator',DeliveryStore=Store(self))
  self.Session=NS(Accounts=Collection([self.account]))

def plan():return dict(employee='E1',staff='S1',name='Employee',to=['employee@example.com'],cc=['cc@example.com'],subject='Same subject',body='Same body',problem='',recipient_names={'employee@example.com':'Employee','cc@example.com':'CC name old'})
class IndependentCOMAudit(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.path=Path(self.tmp.name)
  self.app=App();self.settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com','auto_send':True}
 def run_mail(self,p=None):return process_classic_plans([plan() if p is None else p],self.settings,self.path,self.app)
 def test_unused_recipient_display_name_must_not_resend_identical_com_mail(self):
  self.run_mail();changed=plan();changed['recipient_names']['cc@example.com']='CC name new';self.run_mail(changed)
  self.assertEqual(len(self.app.sent),1,'Only unused Graph metadata changed, but identical actual COM mail was resent')
 def test_real_plan_builder_cc_name_only_change_must_not_resend(self):
  rows=[dict(employee='E1',staff='S1',name='Employee',date='2026-10-01',field='始業',xlsx='9:00',csv='9:05',status='不一致')]
  contacts={'contacts':[dict(employee='E1',staff='S1',name='Employee',email='employee@example.com')]}
  self.settings['always_to']='fixed@example.com'
  self.settings['always_cc']='Old CC Name <cc@example.com>'
  old=build_mail_plans(rows,contacts,{'E1':'S1'},self.settings,{'year':2026,'month':10})[0]
  self.settings['always_cc']='New CC Name <cc@example.com>'
  new=build_mail_plans(rows,contacts,{'E1':'S1'},self.settings,{'year':2026,'month':10})[0]
  for k in ('to','cc','subject','body'):self.assertEqual(old[k],new[k])
  self.assertNotEqual(old['recipient_names'],new['recipient_names'])
  self.run_mail(old);self.run_mail(new)
  self.assertEqual(self.app.sent[0],self.app.sent[-1])
  self.assertEqual(len(self.app.sent),1,'Changing only a configured CC display name must not duplicate identical COM mail')
 def test_default_empty_mandatory_to_keeps_employee_recipient(self):
  rows=[dict(employee='E1',staff='S1',name='Employee',date='2026-10-01',field='始業',xlsx='9:00',csv='9:05',status='不一致')]
  contacts={'contacts':[dict(employee='E1',staff='S1',name='Employee',email='employee@example.com')]}
  p=build_mail_plans(rows,contacts,{'E1':'S1'},self.settings,{'year':2026,'month':10})[0]
  self.assertEqual(p['to'],['employee@example.com'],'Default empty always_to must retain employee email')
 def test_empty_entry_id_stops_send_and_retry(self):
  self.app.fail='empty_id';result=self.run_mail();self.assertTrue(result[0].get('error'));self.assertEqual(self.app.sent,[])
  self.app.fail=None;self.run_mail();self.assertEqual(self.app.created,1);self.assertEqual(self.app.sent,[])
 def test_folder_failure_and_recipient_failure_retain_uncertain_history(self):
  for failure in ('folder','recipient'):
   with self.subTest(failure=failure),tempfile.TemporaryDirectory() as t:
    app=App();app.fail=failure;result=process_classic_plans([plan()],self.settings,t,app)
    self.assertTrue(result[0].get('error'));app.fail=None;process_classic_plans([plan()],self.settings,t,app)
    self.assertEqual(app.sent,[]);self.assertLessEqual(app.created,1)
 def test_sender_case_variation_does_not_resend(self):
  self.run_mail();self.settings['account']='OPERATOR@EXAMPLE.COM';self.run_mail();self.assertEqual(len(self.app.sent),1)
 def test_unknown_status_record_blocks_without_outlook_creation(self):
  self.run_mail();path=self.path/'mail_processing_history.json';ledger=json.loads(path.read_text());next(iter(ledger.values()))['status']='unrecognized-future-status';path.write_text(json.dumps(ledger))
  result=self.run_mail();self.assertEqual(self.app.created,1);self.assertIn('再実行を停止',result[0]['status'])
 def test_duplicate_plans_same_batch_send_once(self):
  process_classic_plans([plan(),plan()],self.settings,self.path,self.app);self.assertEqual(len(self.app.sent),1)
 def test_independent_workdirs_have_no_cross_account_side_effect(self):
  self.run_mail()
  with tempfile.TemporaryDirectory() as t:process_classic_plans([plan()],self.settings,t,self.app)
  self.assertEqual(len(self.app.sent),2)
 def test_old_com_and_graph_history_migrate_then_display_name_change_stays_blocked(self):
  for backend in ('old_com','graph'):
   for record in ({'employee':'E1','status':'sent'},{'employee':'E1','status':'draft'},{'employee':'E1','status':'sending'},None,{},False,[],0,''):
    with self.subTest(backend=backend,record=record),tempfile.TemporaryDirectory() as t:
     p=plan();settings={**self.settings,'client_id':'old-client','tenant_id':'old-tenant'}
     prefix=[settings['account'].casefold(),'classic_outlook'] if backend=='old_com' else [settings['account'].casefold(),settings['client_id'],settings['tenant_id']]
     key=hashlib.sha256(json.dumps(prefix+[settings['auto_send'],p['employee'],p['staff'],mail_payload(p)],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
     path=Path(t)/'mail_processing_history.json';path.write_text(json.dumps({key:record}));app=App()
     result=process_classic_plans([p],settings,t,app);self.assertFalse(app.created);self.assertEqual(len(json.loads(path.read_text())),2)
     p['recipient_names']['cc@example.com']='New display name after v2 migration'
     result=process_classic_plans([p],settings,t,app);self.assertFalse(app.created);self.assertFalse(app.sent)
     if isinstance(record,dict) and record.get('status')=='sent':self.assertIn('送信処理済み',result[0]['status'])
     elif isinstance(record,dict) and record.get('status')=='draft':self.assertIn('下書き保存済み',result[0]['status'])
     else:self.assertIn('再実行を停止',result[0]['status'])
 def test_optional_boundary_delimiters_preserve_recipient(self):
  for value in ('employee@example.com;','employee@example.com,','; employee@example.com; ', ',employee@example.com,','Employee Name <employee@example.com>;','Employee Name <employee@example.com>,'):
   with self.subTest(value=value):self.assertEqual(addresses(value),['employee@example.com'])
 def test_nonempty_input_empty_parser_result_is_rejected(self):
  for result in ([],[('','')],[('',''),('','')]):
   with self.subTest(result=result),patch('outlook_mail.getaddresses',return_value=result):
    with self.assertRaises(ValueError):addresses('employee@example.com')
 def test_actual_malformed_input_rejected_and_empty_setting_remains_allowed(self):
  with self.assertRaises(ValueError):addresses('alice@example.com <bob@example.com>')
  self.assertEqual(addresses(''),[])
  self.assertEqual(addresses(' ; , '),[])

if __name__=='__main__':unittest.main(verbosity=2)
