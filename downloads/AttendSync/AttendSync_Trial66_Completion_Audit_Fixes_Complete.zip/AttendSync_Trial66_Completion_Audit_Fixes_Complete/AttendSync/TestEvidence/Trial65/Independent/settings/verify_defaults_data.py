import os,sys,copy,tempfile,csv,json
from pathlib import Path
from datetime import time,timedelta
from unittest.mock import patch
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
ROOT=Path(os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial65_Independent_Audit_Complete/AttendSync'))
sys.path.insert(0,str(ROOT))
from engine import DEFAULT,csv_read,xlsx_read,read_config
from settings_dialog import SettingsDialog
from cache_tags import parser_tag
from openpyxl import Workbook
import runtime_paths
with tempfile.TemporaryDirectory() as tmp:
 base=Path(tmp);inputs=base/'input';inputs.mkdir()
 with patch.object(runtime_paths,'get_data_dir',return_value=base):import main
 book=Workbook();ws=book.active;ws.title='10月'
 for key,value in {'A1':'2026年10月度','N1':'E1','P1':'合成所属','U1':'合成社員','A9':10,'B9':1,'E9':'勤務','F9':1,'G9':time(9),'H9':time(18),'T9':timedelta(hours=8)}.items():ws[key]=value
 xp=inputs/'synthetic.xlsx';book.save(xp);book.close()
 cp=inputs/'synthetic.csv'
 with cp.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['date','calendar','unused','staff','name','f','g','h','i','j','start','end','work','break']);w.writerow(['20261001','0','','S1','合成社員','','','','','','09:00','18:00','08:00','01:00'])
 for key in ('year','month','data_first_row','data_last_row','csv_first_row','csv_encoding'):
  cfg=copy.deepcopy(DEFAULT);cfg['future_extension']={'nested':[1,2,'保持']};cfg.pop(key);before=copy.deepcopy(cfg)
  SettingsDialog.validate_json_config(cfg)
  normalized=read_config(cfg)
  assert normalized[key]==DEFAULT[key]
  for kind in ('xlsx','csv'):assert parser_tag(cfg,kind)==parser_tag(normalized,kind)
  assert len(csv_read(cp,cfg)['records'])==1
  packet=xlsx_read(xp,cfg);assert not packet.get('error'),packet
  assert len(packet['records'])==1,packet
  rows=[]
  with patch.object(main,'DB',base/(key+'.sqlite')):
   worker=main.ReadWorker(inputs,cfg);worker.result.connect(lambda *args:rows.append(args));worker.run()
  assert not rows[0][3].get('fatal_error'),rows[0][3]
  assert len(rows[0][1])==1,rows[0]
  assert cfg==before,'input mutated'
  assert worker.cfg['future_extension']==before['future_extension']
  print('PASS omitted',key,'direct CSV/XLSX + worker + identical cache tags + extension preservation + immutable input')
