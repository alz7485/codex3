# Trial65 誤判定・集計 独立監査

対象: Trial64 Classic Outlook COM (本体変更なし)。合成データ・TemporaryDirectory と offscreen Qt を使用。実メール、認証、ネットワーク、Git 操作なし。

## 確認済み問題

### J65-1 P2: 追加項目の照合形式変更時に旧XLSX解析キャッシュが使われる

- 条件: 追加列 V の数式 `=0`、保存済み計算結果0、表示形式 `h:mm;;`。追加項目を時間(duration)として一度読込み、その後時刻(clock)へ変更して再読込。
- 期待: 現在の設定で直接解析した結果とキャッシュ経由の結果が一致し、表示上空欄の数式0が空欄CSVと一致。
- 実際: parser_tag は同一のため旧パケット再使用。旧値 `00:00:00` は不一致、現在設定での直接解析は null で一致。
- 箇所: engine.xlsx_read の clock_keys が comparisons の xlsx/type に依存。cache_tags.parser_tag の XLSX_KEYS がその依存を持たない。
- 証拠: probe_cache_clock.py / probe_cache_clock.log。
- 修正案: enabled ON/OFF ではキャッシュタグを変えず、解析に影響する clock xlsx キー集合をタグへ含める。もしくは比較設定に依存しない解析へ統一。

### J65-2 P2/P3: 秒を含む不一致でUI・メールの表示値が同じになる

- 条件: XLSX 9:00:01、CSV 9:00:02。
- 期待: 不一致理由となった秒が表示され、受信者が修正対象を識別できる。
- 実際: 正しく不一致だが、表示値が両方9:00で、メール本文も「派遣元：9:00 / 派遣先：9:00」となる。
- 箇所: engine.display_time が分に round する一方、compare_time は秒を比較する。
- 証拠: probe_seconds.py / probe_seconds.log。
- 修正案: 分単位入力の表示は維持し、非0秒のみ秒を表示。

## 成功した独立検証

`audit_suite.py` 4テスト全成功（audit_suite.log）。既存テストの再実行ではなく、期待値を標準 calendar/date と現在の表示対象から独立生成。

1. 2000～2100年・全1,212月。前月16日～当月15日の正しい日数、照合スロット期待値、CSV有月/月なし判定、期間前後・始終日。19,392 assertions。
2. 実際の合成XLSX 20ケース（2000/2004/2024/2096/2100年、1/2/3/12月）。世紀年・閏日・年越しで期間外行は読込注意、期間内は過不足なく3項目全一致、集計欠損0、coverage complete。
3. CSV欠損月フィルタが不正時刻 abc/48:00/9:60/負数/真偽値/NaN/Infinity を隠さない。
4. QtメインUIで欠損月ON/OFF/ON×3表示モード×4検索の36組。表示行モデル、印刷行数、メール有効状態、社員別メール計画・件数、全結果と集計不変を照合。後から月度を変更してもメール件名は読み込んだ2026年10月度のまま。実際のCOM処理は一切呼ばずダイアログ境界をMock。

## 再実行

```sh
QT_QPA_PLATFORM=offscreen /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/judgment/audit_suite.py
/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/judgment/probe_cache_clock.py
/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/judgment/probe_seconds.py
```

修正コピーでの再確認は `ATTENDSYNC_SOURCE_ROOT=/.../AttendSync` を指定。2つのprobeは現在失敗する回帰assertを含むため、修正後は終了コード0になる。

実機Windows、Excel/Outlook実接続・印刷機・実メール配達は本監査対象外。

## Trial65 修正版での再監査

対象: `/workspace/attendsync-audit/AttendSync_Trial65_Independent_Audit_Complete/AttendSync`。同じスクリプトを `ATTENDSYNC_SOURCE_ROOT` だけ切り替えて実行。本体変更なし。

- J65-1: **修正確認**。照合形式変更後に cache_hit=false。キャッシュ経由・直接解析とも値null、判定一致。`probe_cache_clock_trial65.log`。
- J65-2: **修正確認**。双方の表示が9:00:01 / 9:00:02となり、生成メール本文でも差が残る。`probe_seconds_trial65.log`。
- 独立4テスト再成功。全1,212月の19,392 assertions、実XLSX20ケース、UI表示・印刷・メール対象36組を再確認。`audit_suite_trial65.log`。
- 追加境界確認: 時刻0/24/47時、秒59、時間999時、数値由来の小数秒、照合ON/OFFでタグ不変・clockからduration変更でタグ変更。対象年月不明（空欄・不明・和暦）は全行要確認、既知の日本語・YYYY-MM・YYYY/MMは正しく照合、前年は明示エラー。`verify65_boundaries.py` / `verify65_boundaries.log`。

本担当の2件はともに修正済み。追加の回帰不具合は認めません。実機Outlook/Excel接続・配達は未検証です。
