# 独立監査：クラシック Outlook COM

対象：Trial64 / classic_outlook.py, outlook_mail.py, mail_state.py。ソース変更、ネットワーク、認証、実 COM、実メールは一切行っていない。

## 確定した不具合 1（P2）

必須 CC の表示名だけを変更すると、同じ送信元、To、CC、件名、本文のメールが再送される。

期待：実際に作成する COM メールの内容が変わらない場合、処理履歴で同内容の再送を防ぐ。

実際：必須 CC を `Old CC Name <cc@example.com>` から `New CC Name <cc@example.com>` に変更した場合、`build_mail_plans` の `recipient_names` だけが変化する。COM はこの表示名を設定せず、アドレスと Type だけで Recipients を生成する。一方で履歴キーは Graph 用 `mail_payload` の表示名を含むため別メール扱いとなり、Send が 2 回呼ばれる。

箇所：classic_outlook.py:98-102（履歴キー）、115-117（実 Recipient）。outlook_mail.py の recipient_names 構築も経由する UI 設定と同じ再現テストを用意した。

証拠：probe.py の `test_real_plan_builder_cc_name_only_change_must_not_resend` と `test_unused_recipient_display_name_must_not_resend_identical_com_mail`。当初の probe.log は 6 成功・1 failure・1 error。error は下記の不具合 2 によるものだった。最初の報告で両方を同一原因の失敗と集計した点を訂正する。現行テストは必須 To も設定して、不具合 1 の確認を不具合 2 から分離している。

提案：COM が実際に使用する内容を基に新しい指紋を生成し、Trial64 指紋および旧 Graph 指紋の移行照合を残す。旧履歴はハッシュしか保存していないため、旧版で作られたメールの表示名を既に変更した場合まで過去の実内容を復元して照合することはできない。移行制約として扱う。

## 確定した不具合 2（P2、Python 現行版での互換性）

必須 To が初期値の空欄のままだと、社員の登録メールがあるにもかかわらず build_mail_plans が `to=[]`, `problem=''` を返す。処理ボタンで「宛先未登録」の例外になる。

原因：社員メールと空の always_to をセミコロン結合して末尾 `;` が発生し、addresses がこれを末尾 `,` に変換する。監査環境の Python 3.12.14 の email.utils.getaddresses(strict=True) は末尾カンマを含む `employee@example.com,` を `[('', '')]` と判定する。addresses はこの解析失敗を空欄として黙殺する。試験は Python 3.12.14 であり、以前の Python 各マイクロ版でも同じかは未検証。

期待：空の必須 To は社員メールに影響しない。非空の宛先文字列が解析できない場合は設定エラーとして表示する。

箇所：outlook_mail.py addresses と build_mail_plans の `to=addresses(';'.join(...))`。

証拠：probe.py `test_default_empty_mandatory_to_keeps_employee_recipient`。一次修正版で `[] != ['employee@example.com']` の失敗を確認し、修正後は成功した。

## 独立の合成 COM テスト結果（最終修正版）

Trial65 一次修正版は拡張 10 テスト中 9 成功、1 失敗（上記の不具合 2）だった。その後、空の必須 To を社員メールと結合しない処理、先頭末尾の区切り文字除去、非空入力に対する全空解析結果の明示エラー化が反映された。

最終修正版は拡張 **13 テストすべて成功**。probe65.log は最終修正版の結果。既存 Trial64 の 17 テストとは異なる合成モデルを独立作成し、本体ソースは変更していない。確定した 2 件とも修正を独立に確認した。

- 同一バッチの同一プラン重複は Send 1 回。
- 送信元大文字小文字だけ変更は再送しない。
- EntryID を取得できない場合は送信せず、再実行も停止。
- Drafts フォルダ取得と Recipient 追加の障害は処理履歴を保持し、再実行しても送信しない。
- 未知の履歴 status は外部操作前に再実行停止。
- 独立したデータフォルダ間の履歴は分離される。したがって重複防止範囲は同じデータフォルダ内である。
- 旧 COM と旧 Graph の履歴を現在の v2 へ移行し、その後表示名を変えても外部操作しない。sent/draft/sending/None/{}/False/[]/0/空文字の 9 通り × 2 形式の 18 組を確認。
- 社員メールのある状態で必須 To が空でも社員宛先が保持される。
- 末尾の `;` / `,`、先頭の区切り、表示名付きの末尾区切りの 6 通りで宛先を保持。
- 非空宛先で解析結果が [] / [('', '')] / [('', ''), ('', '')] となる場合は黙殺せず ValueError。
- 現行 Python の実パーサーで解析不能な `alice@example.com <bob@example.com>` は明示エラー。空欄の設定値は [] として許可。

## COM モデル・実機検証の限界

Account.DeliveryStore.GetDefaultFolder(16)、Items.Add('IPM.Note')、SendUsingAccount 設定、Recipient.Type の 1/2、Save 後 EntryID、Send は Outlook オブジェクトモデルに沿った呼び出しであり、静的確認で明白なモデル誤りは発見していない。CoInitialize/CoUninitialize を送信スレッド内で行う構成で、COM オブジェクトを UI に返していない。

ResolveAll の実際のアドレス帳解決、Outlook の操作確認ダイアログ、接続断・オフライン時のキュー挙動、Exchange の代理送信権限、送信要求後の実配送、Windows 環境での COM 接続は未検証。Send の成功を「送信要求済み」と表記する現在の実装は実配送を保証していないため整合する。これらを確定不具合として数えていない。

## 実行方法

`/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/outlook/probe.py`

修正版を検証する際は `ATTENDSYNC_SOURCE_ROOT` に対象 AttendSync ディレクトリを指定できる。
