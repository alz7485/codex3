import sys,os,copy,json
sys.path.insert(0,os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync'))
from engine import DEFAULT,reconcile
from outlook_mail import build_mail_plans
cfg=copy.deepcopy(DEFAULT);cfg['comparisons']=cfg['comparisons'][:1]
x={'E1':{'info':{'name':'テスト社員'},'records':[dict(date='2026-10-01',name='テスト社員',values={'start':'9:00:01'})]}}
c=[dict(date='2026-10-01',name='テスト社員',staff='S1',values={'start':'9:00:02'})]
rows,issues=reconcile(x,c,{'E1':'S1'},cfg)
plans=build_mail_plans(rows,{'contacts':[dict(employee='E1',staff='S1',name='テスト社員',email='one@example.com')]},{'E1':'S1'},{},cfg)
print(json.dumps(dict(status=rows[0]['status'],displayed_xlsx=rows[0]['xlsx'],displayed_csv=rows[0]['csv'],mail_body=plans[0]['body']),ensure_ascii=False,indent=2))
assert rows[0]['xlsx']!=rows[0]['csv'],'秒が異なる不一致が同じ9:00としてUI/メール表示されます'
