import copy,sys,tempfile
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync')
sys.path.insert(0,str(ROOT))
from engine import DEFAULT
from settings_dialog import SettingsDialog
import runtime_paths
with tempfile.TemporaryDirectory() as tmp:
 with patch.object(runtime_paths,'get_data_dir',return_value=Path(tmp)):import main
 for missing in ('csv_encoding','csv_first_row','data_first_row','data_last_row','codes'):
  cfg=copy.deepcopy(DEFAULT);cfg.pop(missing)
  try:SettingsDialog.validate_json_config(cfg)
  except Exception as e:print(missing,'VALIDATION_REJECT',repr(e));continue
  rows=[]
  worker=main.ReadWorker(tmp,cfg);worker.result.connect(lambda *args:rows.append(args));worker.run()
  print(missing,'VALIDATION_ACCEPT','RESULT',rows[0][3].get('fatal_error'))
