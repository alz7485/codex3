import os,sys,copy,tempfile,json
from pathlib import Path
sys.path.insert(0,os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial65_Independent_Audit_Complete/AttendSync'))
from engine import DEFAULT,display_time,xlsx_read,reconcile
from cache_tags import parser_tag
from openpyxl import Workbook
checks=0
for kind,value,expected in [('clock','0:00','0:00'),('clock','23:59:59','23:59:59'),('clock','24:00','0:00'),('clock','47:59:59','23:59:59'),('duration','24:00','24:00'),('duration','999:59:59','999:59:59'),('clock',((9*3600)+.25)/86400,'9:00:00.25'),('duration',((26*3600)+.125)/86400,'26:00:00.125')]:
 actual=display_time(value,kind);assert actual==expected,(value,actual,expected);checks+=1
cfg=copy.deepcopy(DEFAULT);cfg['xlsx_columns']['extra']='V';cfg['csv_columns']['extra']='O';cfg['comparisons'].append(dict(name='追加',xlsx='extra',csv='extra',type='clock',enabled=True))
a=parser_tag(cfg,'xlsx');cfg['comparisons'][-1]['enabled']=False;assert a==parser_tag(cfg,'xlsx');checks+=1
cfg['comparisons'][-1]['type']='duration';assert a!=parser_tag(cfg,'xlsx');checks+=1
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'unknown_period.xlsx'
 for period in ['', '不明', '令和8年10月度','2026-10','2026/10','2026年10月度','2026年10月','2025年10月度']:
  wb=Workbook();ws=wb.active;ws.title='10月'
  for key,value in [('A1',period),('N1','E1'),('U1','合成社員'),('A9',10),('B9',1),('G9','9:00')]:ws[key]=value
  wb.save(p);wb.close();packet=xlsx_read(p,DEFAULT)
  if period=='2025年10月度':assert 'error' in packet;checks+=1;continue
  rows,issues=reconcile({'E1':packet},[dict(date='2026-10-01',staff='S1',name='合成社員',values=dict(start='9:00'))],{'E1':'S1'},DEFAULT)
  unknown=period in ('','不明','令和8年10月度')
  assert packet['period_unverified']==unknown,(period,packet);checks+=1
  if unknown:assert all(row['status']=='要確認' for row in rows);assert any('対象年月' in row['field'] for row in rows);checks+=2
  else:assert any(row.get('comparison_index')==0 and row['status']=='一致' for row in rows);checks+=1
print(json.dumps(dict(independent_boundary_assertions=checks,result='PASS'),ensure_ascii=False))
