# 一般ユーザー誤操作・変な使用の独立監査（Trial64）

対象: `AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync`。本体無変更。
実行環境: Linux / Python 3.12 / PySide6、`QT_QPA_PLATFORM=offscreen`。
社員・CSV・保存ファイルは TemporaryDirectory の合成データのみ。Outlook処理は mock に差し替え、実送信・認証・ネットワークアクセスなし。

## 結果

17条件を実Qtダイアログで実行し、16条件通過・1件の不具合を確認。

### UI-01: 一部社員のメール処理後、残り社員を同じ画面で処理できない（P2）

1. 2人分のメール作成画面を開く。
2. 2人目のチェックを外し、1人目の「Outlookの下書きを作成」を実行。
3. 1人目が「下書き保存済み」となった後、2人目をチェックする。

期待: 未作成の2人目を同じ画面で処理できる。
実際: 2人目は「未作成」のまま、作成ボタンが無効のまま残り実行不可。画面を閉じて開き直す必要がある。
1人目を2回処理する挙動は発生していない。

原因箇所: `outlook_mail.py:110` の `unlock()` が実行ボタンを戻さず、`:112` の `completed()` でも再有効化しない。`:124` で実行時に無効化されたまま。
修正時は QThread の実行終了前に再実行可能にしないよう、`finished` を用いた状態解放も検討する。

最小再現コードは `probe_ui.py` の `partial_mail()`。再現コマンド:

```sh
/workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/misuse/probe_ui.py
```

結果: `results.json` / `results.log`。

## 通過した条件

- 対象なしでメール作成を押しても処理workerなし。
- メール処理中の画面取消・自動送信切替を抑止。
- メール作成ボタン連打で重複処理なし。
- 社員情報を検索中に追加しても新しい行が見える。
- 社員ID・スタッフID・メールを編集後キャンセルしても保存ファイル不変。
- スタッフID重複を警告し、画面継続・保存ファイル不変。
- 不正なメールを警告し、画面継続・保存ファイル不変。
- 社員ID空欄を警告し、画面継続・保存ファイル不変。
- 社員ID変更保存で旧IDが幽霊社員として残らない。
- 検索で1人に絞り込んだ状態で保存しても非表示社員が失われない。
- CSVパスの高速切替では最後のCSVだけが反映される。
- 表示済みCSVパス変更後、古いプレビューの即時反映を抑止。
- 自動プレビュー待ち中に取消しても後から取り込まれない。

## 制限

Windowsでの実際のドラッグ操作・Outlook接続・COM処理はこの監査の対象外。合成データとQtイベントでUI操作を検証した。

## Trial65 修正後再監査

対象: `/workspace/attendsync-audit/AttendSync_Trial65_Independent_Audit_Complete/AttendSync`。
既存17条件に5条件を追加し、**22条件すべて通過**。

- UI-01 再現操作で、残る未作成社員の実行ボタンが再び有効になる。
- 1人目を処理した後、2人目を同じ画面から処理可能。mock呼出しは `[["E1"], ["E2"]]` の2回で重複なし。
- 最初の実行が `E1:処理不明 / E2:未処理` を返す場合、E1は選択禁止のまま、E2のみ選択可能に残る。
- 未処理だけ継続するとmock呼出しは `[["E1", "E2"], ["E2"]]`。処理不明のE1を再実行しない。
- 残り全員を処理し終えると実行ボタンが無効になる。
- 処理中の連打・画面取消・自動送信切替の抑止も維持。

再現コマンド:

```sh
ATTENDSYNC_SOURCE_ROOT=/workspace/attendsync-audit/AttendSync_Trial65_Independent_Audit_Complete/AttendSync /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/misuse/probe_ui.py
```

修正前結果は `baseline_results.json` / `baseline_results.log`、修正後は `recheck_trial65.json` / `recheck_trial65.log` に保持。未解決の確認済み不具合はなし。
