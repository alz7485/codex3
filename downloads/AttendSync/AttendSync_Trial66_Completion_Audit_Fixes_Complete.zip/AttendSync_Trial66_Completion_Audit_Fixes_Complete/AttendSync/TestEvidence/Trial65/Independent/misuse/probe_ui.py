"""Independent synthetic UI misuse probes; never invokes Outlook/network."""
import os,sys,tempfile,json,copy
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
SOURCE=Path(os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync'))
sys.path.insert(0,str(SOURCE))
from PySide6.QtWidgets import QApplication,QPushButton,QTableWidget,QCheckBox,QLineEdit,QComboBox
from PySide6.QtCore import QTimer,Qt,QMimeData,QPointF,QUrl
from PySide6.QtGui import QDropEvent,QDragEnterEvent
import runtime_paths
BOOT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(BOOT.name)):
 import main
from engine import save_json,DEFAULT
from outlook_mail import show_mail_dialog
from test_trial54_mail import Mail
from employee_information import show_employee_import_dialog
from employee_contacts import selected_email
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
RESULTS=[]
def record(name,passed,**details):
 item={'name':name,'passed':bool(passed),**details};RESULTS.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
def btn(dialog,text):return next(b for b in dialog.findChildren(QPushButton) if b.text()==text)
def finish_dialog(predicate,callback,attempt=0):
 d=APP.activeModalWidget()
 if predicate(d):
  callback(d);d.reject();return
 if attempt>100:record('worker timeout',False);d.reject();return
 QTimer.singleShot(10,lambda:finish_dialog(predicate,callback,attempt+1))
def partial_mail():
 fixture=Mail();window=main.Window();calls=[]
 def process(plans,settings,data_dir):
  calls.append([p['employee'] for p in plans]);return [{'employee':p['employee'],'status':'下書き保存済み'} for p in plans]
 def start():
  d=APP.activeModalWidget();t=d.findChild(QTableWidget);t.item(1,0).setCheckState(Qt.Unchecked);btn(d,'Outlookの下書きを作成').click()
  def done(d):
   t=d.findChild(QTableWidget);create=btn(d,'Outlookの下書きを作成');t.item(1,0).setCheckState(Qt.Checked)
   record('partial-mail remaining employee can execute',create.isEnabled(),button_enabled=create.isEnabled(),calls=calls,remaining_status=t.item(1,3).text())
  QTimer.singleShot(10,lambda:finish_dialog(lambda d:d.findChild(QTableWidget).item(0,3).text()=='下書き保存済み',done))
 with tempfile.TemporaryDirectory() as tmp,patch('classic_outlook.process_classic_plans',side_effect=process),patch('PySide6.QtWidgets.QMessageBox.information'),patch('PySide6.QtWidgets.QMessageBox.warning'):
  QTimer.singleShot(0,start);show_mail_dialog(window,fixture.plans(),fixture.settings(),tmp)
 window.close();APP.processEvents()
def mail_busy_and_none():
 import threading
 fixture=Mail();window=main.Window();calls=[];gate=threading.Event()
 def process(plans,settings,data_dir):
  calls.append([p['employee'] for p in plans]);gate.wait(2);return [{'employee':p['employee'],'status':'下書き保存済み'} for p in plans]
 def start():
  d=APP.activeModalWidget();t=d.findChild(QTableWidget);create=btn(d,'Outlookの下書きを作成')
  for i in range(t.rowCount()):t.item(i,0).setCheckState(Qt.Unchecked)
  create.click();record('no selected mail makes no worker',not calls and create.isEnabled())
  t.item(0,0).setCheckState(Qt.Checked);create.click();create.click()
  d.reject()
  record('busy mail blocks close and toggle',d.isVisible() and not d.findChild(QCheckBox,'mailAutoSend').isEnabled() and not create.isEnabled())
  gate.set()
  def done(d):record('rapid create clicks do not duplicate',calls==[['E1']],calls=calls)
  QTimer.singleShot(10,lambda:finish_dialog(lambda d:d.findChild(QTableWidget).item(0,3).text()=='下書き保存済み',done))
 with tempfile.TemporaryDirectory() as tmp,patch('classic_outlook.process_classic_plans',side_effect=process),patch('PySide6.QtWidgets.QMessageBox.information'),patch('PySide6.QtWidgets.QMessageBox.warning'):
  QTimer.singleShot(0,start);show_mail_dialog(window,fixture.plans(),fixture.settings(),tmp)
 window.close();APP.processEvents()
def sequential_mail(early_failure=False):
 fixture=Mail();window=main.Window();calls=[];steps=[0]
 def process(plans,settings,data_dir):
  calls.append([p['employee'] for p in plans])
  if early_failure and len(calls)==1:
   return [{'employee':plans[0]['employee'],'status':'処理不明','error':'synthetic failure'},{'employee':plans[1]['employee'],'status':'未処理'}]
  return [{'employee':p['employee'],'status':'下書き保存済み'} for p in plans]
 def wait_finished():
  steps[0]+=1;d=APP.activeModalWidget();t=d.findChild(QTableWidget);create=btn(d,'Outlookの下書きを作成')
  if steps[0]>200:record('sequential timeout',False);d.reject();return
  if len(calls)==1 and create.isEnabled() and t.isEnabled():
   if early_failure:
    record('failure leaves only unprocessed row checkable',not bool(t.item(0,0).flags() & Qt.ItemIsUserCheckable) and bool(t.item(1,0).flags() & Qt.ItemIsUserCheckable),states=[t.item(i,3).text() for i in range(2)])
   t.item(1,0).setCheckState(Qt.Checked);create.click()
  elif len(calls)==2 and t.item(1,3).text()=='下書き保存済み' and t.isEnabled():
   record('continue unprocessed after failure' if early_failure else 'two employees processed sequentially',calls==([['E1','E2'],['E2']] if early_failure else [['E1'],['E2']]),calls=calls)
   record('all completed disables create '+str(early_failure),not create.isEnabled());d.reject();return
  QTimer.singleShot(10,wait_finished)
 def start():
  d=APP.activeModalWidget();t=d.findChild(QTableWidget)
  if not early_failure:t.item(1,0).setCheckState(Qt.Unchecked)
  btn(d,'Outlookの下書きを作成').click();QTimer.singleShot(10,wait_finished)
 with tempfile.TemporaryDirectory() as tmp,patch('classic_outlook.process_classic_plans',side_effect=process),patch('PySide6.QtWidgets.QMessageBox.information'),patch('PySide6.QtWidgets.QMessageBox.warning'):
  QTimer.singleShot(0,start);show_mail_dialog(window,fixture.plans(),fixture.settings(),tmp)
 window.close();APP.processEvents()
def editor_case(kind):
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp)
  with patch.multiple(main,CONFIG=root/'settings.json',MAP=root/'staff_mapping.json',DB=root/'cache.sqlite'):
   save_json(main.MAP,{'E1':'S1','E2':'S2'});contacts={'version':1,'contacts':[{'employee':'E1','staff':'S1','name':'社員一','email':'one@example.com'},{'employee':'E2','staff':'S2','name':'社員二','email':'two@example.com'}],'employee_names':{'E1':'社員一','E2':'社員二'},'employee_information_registered':True,'staff_candidates':[{'employee':'E1','staff':'S1','name':'社員一'},{'employee':'E2','staff':'S2','name':'社員二'}]};save_json(root/'employee_contacts.json',contacts)
   before=(main.MAP.read_bytes(),(root/'employee_contacts.json').read_bytes());w=main.Window();warnings=[]
   def operate():
    d=APP.activeModalWidget();t=d.findChild(QTableWidget,'employeeIdTable');search=next(e for e in d.findChildren(QLineEdit) if e.placeholderText()=='社員ID・氏名・メールで検索')
    try:
     if kind=='add search':
      search.setText('不存在');btn(d,'社員番号を追加').click();record(kind,search.text()=='' and not t.isRowHidden(2),rows=t.rowCount(),search=search.text(),hidden=t.isRowHidden(2));d.reject()
     elif kind=='cancel edits':
      t.item(0,0).setText('CHANGED');t.cellWidget(0,2).setEditText('NEW');t.cellWidget(0,3).setEditText('new@example.com');d.reject()
     elif kind=='duplicate staff':
      t.cellWidget(1,2).setEditText('S1');t.cellWidget(1,3).setEditText('');btn(d,'社員情報を登録').click();record(kind,bool(warnings) and d.isVisible(),warnings=warnings);d.reject()
     elif kind=='invalid email':
      t.cellWidget(0,3).setEditText('broken');btn(d,'社員情報を登録').click();record(kind,bool(warnings) and d.isVisible(),warnings=warnings);d.reject()
     elif kind=='blank id':
      t.item(0,0).setText('');btn(d,'社員情報を登録').click();record(kind,bool(warnings) and d.isVisible(),warnings=warnings);d.reject()
     elif kind=='change id':
      t.item(0,0).setText('E3');btn(d,'社員情報を登録').click()
     elif kind=='filter save':
      search.setText('社員一');btn(d,'社員情報を登録').click()
    except BaseException as exc:record(kind,False,error=repr(exc));d.reject()
   with patch('PySide6.QtWidgets.QMessageBox.warning',side_effect=lambda p,title,msg,*a:warnings.append(msg)),patch('PySide6.QtWidgets.QMessageBox.question',return_value=main.QMessageBox.Yes):
    QTimer.singleShot(0,operate);w.edit_map();APP.processEvents()
   after=(main.MAP.read_bytes(),(root/'employee_contacts.json').read_bytes())
   if kind=='cancel edits':record(kind,before==after)
   if kind in ('duplicate staff','invalid email','blank id'):record(kind+' preserves files',before==after)
   if kind=='filter save':record(kind,set(w.mapping)=={'E1','E2'},mapping=w.mapping)
   if kind=='change id':
    data=json.loads(after[1]);record(kind,set(data['employee_names'])=={'E2','E3'} and w.mapping=={'E2':'S2','E3':'S1'},mapping=w.mapping,names=data['employee_names'])
   w.close();APP.processEvents()
def import_case(kind):
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp);a=root/'a.csv';b=root/'b.csv'
  a.write_text('staff,employee,name,d,e,f,g,h,i,email\nS1,E1,社員一,,,,,,,one@example.com\n',encoding='utf-8-sig')
  b.write_text('staff,employee,name,d,e,f,g,h,i,email\nS2,E2,社員二,,,,,,,two@example.com\n',encoding='utf-8-sig')
  w=main.Window()
  def operate():
   d=APP.activeModalWidget();path=d.findChild(QLineEdit,'informationCsvPath');t=d.findChild(QTableWidget,'informationPreview')
   try:
    if kind=='rapid CSV switching':
     path.setText(str(a));path.setText(str(b));from PySide6.QtTest import QTest;QTest.qWait(320);record(kind,t.rowCount()==1 and t.item(0,1).text()=='E2',rows=t.rowCount(),employee=t.item(0,1).text() if t.rowCount() else None);btn(d,'一覧に反映').click()
    elif kind=='invalidate preview immediately':
     path.setText(str(a));from PySide6.QtTest import QTest;QTest.qWait(320);path.setText(str(root/'missing.csv'));record(kind,not btn(d,'一覧に反映').isEnabled() and t.rowCount()==0);d.reject()
    elif kind=='cancel pending preview':path.setText(str(a));d.reject()
   except BaseException as exc:record(kind,False,error=repr(exc));d.reject()
  QTimer.singleShot(0,operate);result=show_employee_import_dialog(w,{}, {'version':1,'contacts':[]},copy.deepcopy(DEFAULT))
  if kind=='cancel pending preview':
   from PySide6.QtTest import QTest
   QTest.qWait(350);record(kind,result is None)
  w.close();APP.processEvents()
partial_mail()
mail_busy_and_none()
if 'Trial65' in str(SOURCE):
 sequential_mail()
 sequential_mail(early_failure=True)
for kind in ['add search','cancel edits','duplicate staff','invalid email','blank id','change id','filter save']:editor_case(kind)
for kind in ['rapid CSV switching','invalidate preview immediately','cancel pending preview']:import_case(kind)
Path(__file__).with_name('results.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2))
