"""Independent integration acceptance checks, synthetic files and COM only."""
import os,sys,copy,json,base64,tempfile,hashlib,unittest
from pathlib import Path
from datetime import time
from openpyxl import Workbook
ROOT=Path(os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial65_Independent_Audit_Complete/AttendSync'))
sys.path.insert(0,str(ROOT));sys.path.insert(1,'/workspace/attendsync-audit/trial65-audit/outlook')
from engine import DEFAULT,xlsx_read,reconcile,display_time,save_json,read_config
from employee_information import recover_employee_save
from classic_outlook import process_classic_plans
from outlook_mail import DEFAULT_MAIL_SETTINGS,build_mail_plans,addresses
from mail_state import mail_payload
from cache_tags import parser_tag
from result_filters import is_missing_month_csv_gap
from probe import App,plan

class Acceptance(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
 def workbook(self,header):
  p=self.root/'one.xlsx';w=Workbook();s=w.active;s.title='10月'
  for cell,value in {'A1':header,'N1':'E1','U1':'Synthetic','A9':10,'B9':1,'G9':time(9,0,1),'H9':time(18),'T9':'8:00'}.items():s[cell]=value
  w.save(p);w.close();return p
 def test_unknown_period_survives_cache_serialization_and_filter(self):
  raw=xlsx_read(self.workbook('対象月未確定'),DEFAULT)
  packet=json.loads(json.dumps(raw));self.assertTrue(packet['period_unverified'])
  csv=[dict(staff='S1',name='Synthetic',date='2026-10-01',values={'start':'9:00:01','end':'18:00','work':'8:00'})]
  rows,issues=reconcile({'E1':packet},csv,{'E1':'S1'},DEFAULT)
  self.assertTrue(rows);self.assertTrue(issues);self.assertTrue(all(r['status']=='要確認' for r in rows))
  self.assertFalse(any(is_missing_month_csv_gap(r,{'2026-10'},DEFAULT) for r in rows))
 def test_period_known_variants_and_wrong_year(self):
  for header in ('2026年10月','2026 年 10 月度','2026-10','2026/10'):
   with self.subTest(header=header):
    raw=xlsx_read(self.workbook(header),DEFAULT);self.assertFalse(raw.get('error'));self.assertIs(raw['period_unverified'],False)
  for header in ('2025年10月','2025 年 10 月度','2025-10','2025/10'):
   with self.subTest(header=header):self.assertIn('不一致',xlsx_read(self.workbook(header),DEFAULT)['error'])
 def test_recovery_valid_extension_preserved_and_invalid_metadata_atomic(self):
  mp=self.root/'staff_mapping.json';cp=self.root/'employee_contacts.json';jp=self.root/'employee_save_transaction.json'
  old={'version':1,'contacts':[],'employee_names':{'E1':'Synthetic'},'future':{'nested':[1,{'preserve':True}]}}
  oldmapping={'E1':'S1'}
  for invalid in ([],None,{'linking':[]}):
   damaged={**old,'employee_import_settings':invalid};mp.write_text('{"current":"map"}');cp.write_text('{"current":"contacts"}')
   originals=(mp.read_bytes(),cp.read_bytes())
   save_json(jp,dict(mapping=base64.b64encode(json.dumps(oldmapping).encode()).decode(),contacts=base64.b64encode(json.dumps(damaged).encode()).decode()))
   with self.assertRaises(ValueError):recover_employee_save(mp,cp)
   self.assertEqual((mp.read_bytes(),cp.read_bytes()),originals);self.assertTrue(jp.exists())
  save_json(jp,dict(mapping=base64.b64encode(json.dumps(oldmapping).encode()).decode(),contacts=base64.b64encode(json.dumps(old).encode()).decode()))
  recover_employee_save(mp,cp);self.assertEqual(json.loads(cp.read_text()),old);self.assertEqual(json.loads(mp.read_text()),oldmapping);self.assertFalse(jp.exists())
 def test_parser_tag_ignores_only_non_parsing_settings(self):
  cfg=copy.deepcopy(DEFAULT);a=parser_tag(cfg,'xlsx')
  cfg['comparisons'][0]['enabled']=False;cfg['mail']={'account':'one@example.com'};self.assertEqual(parser_tag(cfg,'xlsx'),a)
  cfg['comparisons'].append(dict(name='Other clock',xlsx='break_total',csv='break_total',type='clock',enabled=False))
  self.assertNotEqual(parser_tag(cfg,'xlsx'),a)
  original=copy.deepcopy(cfg)
  for key in ('year','month','data_first_row','data_last_row','csv_first_row','csv_encoding'):
   p=copy.deepcopy(cfg);p.pop(key);self.assertEqual(parser_tag(p,'xlsx'),parser_tag(read_config(p),'xlsx'))
  self.assertEqual(cfg,original)
 def test_seconds_in_both_sources_remain_explainable(self):
  packet=xlsx_read(self.workbook('2026年10月度'),DEFAULT)
  csv=[dict(staff='S1',name='Synthetic',date='2026-10-01',values={'start':'9:00:02','end':'18:00','work':'8:00'})]
  rows,_=reconcile({'E1':packet},csv,{'E1':'S1'},DEFAULT)
  r=next(r for r in rows if r['field']=='始業時刻');self.assertEqual(r['status'],'不一致');self.assertEqual((r['xlsx'],r['csv']),('9:00:01','9:00:02'))
  settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com'};contact={'contacts':[dict(employee='E1',staff='S1',name='Synthetic',email='person@example.com')]}
  mail=build_mail_plans(rows,contact,{'E1':'S1'},settings,{'year':2026,'month':10})[0]
  self.assertEqual(mail['to'],['person@example.com']);self.assertIn('9:00:01',mail['body']);self.assertIn('9:00:02',mail['body'])
 def test_old_history_aliases_block_even_after_later_name_change(self):
  settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com','auto_send':True}
  for backend in ('com','graph'):
   with self.subTest(backend=backend),tempfile.TemporaryDirectory() as td:
    p=plan();payload=mail_payload(p)
    identity=[settings['account'].casefold(),'classic_outlook',True,'E1','S1',payload] if backend=='com' else [settings['account'].casefold(),settings['client_id'],settings['tenant_id'],True,'E1','S1',payload]
    key=hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True).encode()).hexdigest();path=Path(td)/'mail_processing_history.json';save_json(path,{key:{'employee':'E1','status':'sent','id':'historic'}})
    app=App();process_classic_plans([p],settings,td,app);self.assertEqual(app.created,0)
    p['recipient_names']={'cc@example.com':'Changed Later'};process_classic_plans([p],settings,td,app);self.assertEqual(app.created,0)
    ledger=json.loads(path.read_text());self.assertIn(key,ledger);self.assertEqual(len(ledger),2)
 def test_com_actual_content_change_is_new_but_ignored_name_is_not(self):
  settings={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com','auto_send':True};app=App();p=plan()
  process_classic_plans([p],settings,self.root,app)
  p['recipient_names']={'cc@example.com':'Changed'};process_classic_plans([p],settings,self.root,app);self.assertEqual(len(app.sent),1)
  p['body']='Corrected mismatch content';process_classic_plans([p],settings,self.root,app);self.assertEqual(len(app.sent),2)
 def test_to_address_boundaries_do_not_silently_drop_employee(self):
  for raw in ('employee@example.com','employee@example.com;',';employee@example.com','employee@example.com,','Employee <employee@example.com>','Employee <employee@example.com>;'):
   with self.subTest(raw=raw):self.assertEqual(addresses(raw),['employee@example.com'])
  for raw in ('not an email','broken@'):
   with self.subTest(raw=raw),self.assertRaises(ValueError):addresses(raw)

if __name__=='__main__':unittest.main(verbosity=2)
