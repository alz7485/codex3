# Trial65 独立監査: 破壊・故障注入役

対象: `AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync`（読み取り専用）。
実施環境: Linux / Python 3.12 / PySide6 offscreen。実行時の入力・設定・社員・キャッシュはすべて TemporaryDirectory 内に生成。実Outlook・認証・メール送信・ネットワーク・git操作なし。

## 結果

`audit_faults.py`: 20本、17成功、3失敗。失敗は以下の独立した2原因（復旧データ2パターン、キャッシュ1パターン）。`probe_confirmed.py` はその実害を表示する最小再現。

### D65-1 [P2] Base64として正しい壊れた回復データが社員データを書き換え、回復記録も消す

場所: `employee_information.py:56-70`、特に65-69。

期待: すべての回復スナップショットの構造・内容を検証し、不正なら社員ID対応・メール対応・回復記録をいずれも変更せず停止する。

実際: mappingスナップショットがBase64として正しければ、中身が空bytes、`not JSON`、JSON配列`[]`、JSON `null`でも、例外なしでそのbytesを正常な `staff_mapping.json` に上書きする。contactsスナップショットがnullなら正常な `employee_contacts.json` を削除し、その後journalも削除する。次の起動でmappingのJSON読込が失敗し、journalから復旧することもできなくなる。

最小条件:

```python
save_json(journal, {'mapping': base64.b64encode(b'not JSON').decode(), 'contacts': None})
recover_employee_save(mapping_path, contacts_path)
```

結果: mapping=`b'not JSON'`、contacts消失、journal消失。`probe_confirmed.log` に4パターン記録。

提案: Base64全件decode後、実ファイルを変更する前にUTF-8 JSON内容と各保存ファイルの必須root型/必要schemaを全件検証する。未知のmetadataを破棄しない。`None`は「元ファイル無し」の正当な復旧表現として維持する。

### D65-2 [P2] キャッシュ内のvalues項目欠損が本来の不一致を全件一致へ変える

場所: `main.py:59-78` の `_valid_cached_packet`、キャッシュ再利用は111-113。

期待: 元ファイルに対応する項目を欠いたキャッシュは再解析し、元CSVの非空欄時刻が照合に反映される。

実際: recordの `values={}` を有効キャッシュとして受け入れる。元CSVが始業09:00・終業18:00・実働08:00で派遣元XLSXが3項目空欄の場合、初回は3不一致だが、キャッシュrecordのvaluesのみ空dictへ破損させると次回はcache hit1/再解析0で3一致になる。元CSVは一切変更していない。

最小条件: 正常なキャッシュ作成 → SQLite `cache.data` JSONの最初のrecord.valuesだけを`{}`に変更 → 再読み込み → 同じ空欄XLSXと照合。

提案: 実際の列設定に対応するvalues項目の存在・schemaを検証するか、解析packetの完全性を確認する仕組みを導入する。不正なキャッシュは使い捨てて元ファイルを再解析する。

## 成功した故障条件

1. save_jsonがJSONを途中まで書いてディスクフル相当の例外を出しても既存ファイル維持・tmp清掃。
2. save_jsonの置換拒否でも既存ファイル維持・tmp清掃。
3. journal保存失敗前後で社員2ファイルを変更しない。
4. contacts書込が途中で失敗しても2ファイルをrollback。
5. mapping書込が途中で失敗しても2ファイルをrollback。
6. contacts成功・mapping前にクラッシュ相当のKeyboardInterruptでもjournalを残し、次回復旧で元へ戻る。
7. 元の2ファイルが存在しない場合、同クラッシュ後の復旧で両方の不在を復元する。
8. 復旧の2ファイル目だけ置換拒否でもjournalを残し、次回再試行で両方復元する。
9. 正常commit後にjournal unlinkだけ拒否されてもrollbackし、復旧を再試行できる。
10. 同時の2つ目commitをOSロックで拒否し、1つ目の2ファイルが同一世代になる。
11. 無効Base64・数値・bool・配列・dictのsnapshotを実ファイル変更前に拒否。
12. キャッシュJSON文法破損を再解析する。
13. キャッシュroot配列を再解析する。
14. SQLite全体破損をfatal診断し、入力・社員ファイルを変更しない。
15. キャッシュINSERTディスクフル相当でも解析結果を保持し、警告する。
16. 実QThread解析実行中の終了: Noは続行、Yesは中止してparser終了までwindowを閉じない。中止待ちの二重closeは再質問しない。終了後にparser活動0。
17. 現worker以外からのprogress/result/finishedを拒否し、表示・結果・ボタン状態を変えない。

## 実行

```sh
QT_QPA_PLATFORM=offscreen /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/destructive/audit_faults.py
QT_QPA_PLATFORM=offscreen /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/destructive/probe_confirmed.py
```

修正版の再試験は `ATTENDSYNC_SOURCE_ROOT=/path/to/revised/AttendSync` を追加する（audit_faults.py対応）。

## 限界

Windows実機、強制電源断、NTFS固有のファイル排他、実Outlook接続は未検証。クラッシュは処理途中にKeyboardInterruptを投入して再起動時の回復経路を検証した。Qtのfontconfig警告はLinux実行環境のフォントキャッシュ制約であり、本テスト結果に影響しない。

## Trial65修正版の再監査

対象を `AttendSync_Trial65_Independent_Audit_Complete/AttendSync` に切り替え、`audit_faults.py` の20本を変更せず再実行した結果、**20/20成功**。D65-1、D65-2の再現テストは成功へ変わり、既存の17成功条件も維持した。ログ: `audit_faults_trial65.log`、機械可読結果: `results_trial65.json`。

さらに `recheck_extra65.py` で、mapping/contacts双方の空bytes・非JSON・不正UTF-8・誤root・誤version・連絡先schema破損・読込設定schema破損を検証。すべて元の社員2ファイルを一切変更せずjournalを残して拒否した。CSV/XLSX双方のキャッシュについて正常shapeを受け入れ、values内の複合型や設定項目1つずつの欠損をすべて拒否することも確認。追加試験は `recheck_extra65.log` に実行条件数と結果を記録した。追加の不具合は検出しなかった。
