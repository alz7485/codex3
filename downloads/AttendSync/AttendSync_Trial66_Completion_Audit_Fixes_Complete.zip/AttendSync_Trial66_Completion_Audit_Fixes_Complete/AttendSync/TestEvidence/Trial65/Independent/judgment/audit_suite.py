import os,sys,copy,tempfile,unittest,calendar,html,json
from datetime import date,timedelta
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
sys.path.insert(0,os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync'))
from engine import DEFAULT,reconcile,comparison_totals,coverage_report,xlsx_read
from result_filters import csv_month_coverage,missing_csv_months,is_missing_month_csv_gap
from outlook_mail import build_mail_plans
from openpyxl import Workbook
import test_trial38_audit as fixture
import main

class Judgment(unittest.TestCase):
 def test_full_101year_calendar_oracle_filter_and_totals(self):
  checks=0
  for y in range(2000,2101):
   for m in range(1,13):
    cfg=copy.deepcopy(DEFAULT);cfg.update(year=y,month=m)
    pm,py=(12,y-1) if m==1 else (m-1,y)
    expected_days=calendar.monthrange(py,pm)[1]
    xd={'E1':{'info':{'name':'合成社員'},'records':[]}}
    totals=comparison_totals(xd,[],cfg)
    self.assertEqual(totals['days'],expected_days);self.assertEqual(totals['expected'],expected_days*3);checks+=2
    start=date(py,pm,16);end=date(y,m,15)
    for present,absent in [(f'{y:04}-{m:02}',f'{py:04}-{pm:02}'),(f'{py:04}-{pm:02}',f'{y:04}-{m:02}')]:
     found=missing_csv_months({present},cfg);self.assertEqual(found,{absent});checks+=1
     for dt in [start-timedelta(days=1),start,start+timedelta(days=1),end-timedelta(days=1),end,end+timedelta(days=1)]:
      row=dict(status='要確認',field='CSV記録なし',date=dt.isoformat(),crecord=None)
      self.assertEqual(is_missing_month_csv_gap(row,found,cfg),start<=dt<=end and dt.strftime('%Y-%m')==absent);checks+=1
  print('calendar independent assertions:',checks)
 def test_actual_xlsx_parser_period_days_leap_and_year_boundary(self):
  with tempfile.TemporaryDirectory() as td:
   for y in [2000,2004,2024,2096,2100]:
    for m in [1,2,3,12]:
     cfg=copy.deepcopy(DEFAULT);cfg.update(year=y,month=m)
     pm,py=(12,y-1) if m==1 else (m-1,y)
     start=date(py,pm,16);end=date(y,m,15)
     days=[start+timedelta(days=i) for i in range((end-start).days+1)]
     book=Workbook();ws=book.active;ws.title=f'{m}月';ws['A1']=f'{y}年{m}月度';ws['N1']='E1';ws['U1']='合成社員'
     for r,dt in enumerate([start-timedelta(days=1),*days,end+timedelta(days=1)],9):
      ws[f'A{r}']=dt.month;ws[f'B{r}']=dt.day;ws[f'G{r}']='9:00';ws[f'H{r}']='18:00';ws[f'T{r}']='8:00'
     p=Path(td)/f'{y}-{m}.xlsx';book.save(p);book.close();packet=xlsx_read(p,cfg)
     self.assertEqual([r['date'] for r in packet['records']],[d.isoformat() for d in days]);self.assertEqual(len(packet['warnings']),2)
     csv=[dict(staff='S1',name='合成社員',date=d.isoformat(),values=dict(start='9:00',end='18:00',work='8:00')) for d in days]
     rows,issues=reconcile({'E1':packet},csv,{'E1':'S1'},cfg)
     self.assertFalse(issues);self.assertEqual(len(rows),len(days)*3);self.assertEqual({r['status'] for r in rows},{'一致'})
     total=comparison_totals({'E1':packet},rows,cfg)
     self.assertEqual(total['matched'],len(days)*3);self.assertEqual(total['missing'],0)
     self.assertTrue(coverage_report({'E1':packet},csv,{'E1':'S1'},cfg)['complete'])
 def test_malformed_times_preserved_when_month_absent(self):
  cfg=copy.deepcopy(DEFAULT);absent={'2026-09'}
  for value in ['abc','48:00','9:60',-1,True,float('nan'),float('inf')]:
   row=dict(status='要確認',field='CSV記録なし',date='2026-09-16',crecord=None,xrecord={'values':dict(start=value)})
   self.assertFalse(is_missing_month_csv_gap(row,absent,cfg),repr(value))

class ViewScope(unittest.TestCase):
 setUpClass=classmethod(fixture.Audit38.setUpClass.__func__)
 setUp=fixture.Audit38.setUp
 def test_mail_print_search_checkbox_and_pending_period_scope(self):
  contacts={'version':1,'contacts':[dict(employee=e,staff=s,name='合成社員',email=f'user{i}@example.com') for i,(e,s) in enumerate(self.w.mapping.items())]}
  data=[r for r in self.cdata if r['date'].startswith('2026-10')]
  self.w.read_done(copy.deepcopy(self.xdata),copy.deepcopy(data),[],dict(elapsed=.1,cache_hits=0,parsed=5,files_found=5,files_completed=5))
  raw=copy.deepcopy(self.w.results);totals=copy.deepcopy(self.w.comparison_summary)
  for enabled in [True,False,True]:
   self.w.hide_missing_csv_months.setChecked(enabled)
   for mode in ['すべて','不一致のみ','一致のみ']:
    self.w.select_filter(mode)
    for search in ['','10001','10002','存在しない社員']:
     self.w.search.setText(search)
     expected=[r for r in raw if (not enabled or not(r['field']=='CSV記録なし' and r['date'].startswith('2026-09'))) and (mode=='すべて' or (r['status']=='一致' if mode=='一致のみ' else r['status']!='一致')) and (not search or search in r['employee'] or search in r['name'])]
     self.assertEqual(self.w.visible,expected);self.assertEqual(self.w.model.rowCount(),len(expected))
     self.assertEqual(self.w.mail_button.isEnabled(),any(r['status']=='不一致' for r in expected))
     with patch.object(main,'print_html') as printed,patch.object(main.QMessageBox,'information'):
      self.w.print_list(preview=True)
     if expected:self.assertEqual(printed.call_args.args[1].count('<tr>'),len(expected)+1)
     else:printed.assert_not_called()
     with patch('employee_contacts.load_contacts',return_value=contacts),patch('employee_information.recover_employee_save'),patch('outlook_mail.show_mail_dialog') as composed,patch.object(main.QMessageBox,'information'):
      self.w.compose_mail()
     plans=build_mail_plans(expected,contacts,self.w.mapping,{},self.w.result_config())
     if plans:
      self.assertEqual(composed.call_args.args[1],plans)
      self.assertEqual(sum(p['count'] for p in plans),len({(r['employee'],r['date'],r['field'],r['xlsx'],r['csv']) for r in expected if r['status']=='不一致'}))
     else:composed.assert_not_called()
     self.assertEqual(self.w.results,raw);self.assertEqual(self.w.comparison_summary,totals)
  self.w.year.setValue(2027);self.w.month.setValue(1);self.w.cfg.update(year=2027,month=1);self.w.search.clear();self.w.select_filter('不一致のみ')
  with patch('employee_contacts.load_contacts',return_value=contacts),patch('employee_information.recover_employee_save'),patch('outlook_mail.show_mail_dialog') as composed:
   self.w.compose_mail()
  self.assertTrue(all('2026年10月度' in p['subject'] for p in composed.call_args.args[1]))

if __name__=='__main__':unittest.main(verbosity=2)
