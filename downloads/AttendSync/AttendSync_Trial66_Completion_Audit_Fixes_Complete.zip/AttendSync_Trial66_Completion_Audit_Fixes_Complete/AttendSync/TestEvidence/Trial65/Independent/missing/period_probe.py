from probe import *
from openpyxl import Workbook
from datetime import date,timedelta
for period in ['2025年10月度','2025年10月','2025 年 10 月度','2025/10','',None]:
 with tempfile.TemporaryDirectory() as t:
  p=Path(t)/'wrong_year.xlsx';w=Workbook();s=w.active;s.title='10月';s['A1']=period;s['N1']='E1';s['U1']='Name'
  cdata=[]
  for n in range(30):
   d=date(2026,9,16)+timedelta(days=n);row=n+9;s.cell(row,1,d.month);s.cell(row,2,d.day);s.cell(row,7,'9:00');s.cell(row,8,'18:00');s.cell(row,20,'8:00')
   cdata.append({'staff':'S1','name':'Name','date':d.isoformat(),'values':{'start':'9:00','end':'18:00','work':'8:00'}})
  w.save(p);w.close();packet=xlsx_read(p,DEFAULT)
  result={'period_header':period,'error':packet.get('error'),'warnings':packet.get('warnings')}
  if 'error' not in packet:
   rows,issues=reconcile({'E1':packet},cdata,{'E1':'S1'},DEFAULT);result.update(matches=sum(r['status']=='一致' for r in rows),reviews=sum(r['status']=='要確認' for r in rows),issues=issues)
  print(json.dumps(result,ensure_ascii=False))
