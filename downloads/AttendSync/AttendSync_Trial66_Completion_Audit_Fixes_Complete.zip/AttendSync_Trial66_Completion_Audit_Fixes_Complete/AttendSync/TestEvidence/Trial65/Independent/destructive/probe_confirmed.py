import os,sys,tempfile,json,base64,copy,sqlite3
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
ROOT=Path('/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync')
sys.path.insert(0,str(ROOT))
from engine import DEFAULT,save_json,reconcile
from employee_information import recover_employee_save
import runtime_paths
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):
 import main
from PySide6.QtWidgets import QApplication
APP=QApplication.instance() or QApplication([])

def recovery():
 for payload in (b'',b'not JSON',b'[]',b'null'):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);mp=p/'staff_mapping.json';cp=p/'employee_contacts.json';jp=p/'employee_save_transaction.json'
   mp.write_text('{"E1":"S1"}');cp.write_text('{"version":1,"contacts":[]}')
   before=mp.read_bytes(),cp.read_bytes()
   save_json(jp,{'mapping':base64.b64encode(payload).decode(),'contacts':None})
   error=None
   try:recover_employee_save(mp,cp)
   except Exception as exc:error=type(exc).__name__+': '+str(exc)
   print('RECOVERY',repr(payload),'error=',error,'mapping=',mp.read_bytes(),'contacts_exists=',cp.exists(),'journal_exists=',jp.exists(),flush=True)
   assert error is None and mp.read_bytes()==payload and not cp.exists() and not jp.exists()

def cache():
 with tempfile.TemporaryDirectory() as t:
  p=Path(t);folder=p/'input';folder.mkdir();source=folder/'attendance.csv'
  source.write_text('date,calendar,x,staff,name,x,x,x,x,x,start,end,work,break\n20261001,0,,S1,Name,,,,,,09:00,18:00,08:00,01:00\n')
  def run():
   result=[]
   with patch.object(main,'DB',p/'cache.sqlite'):
    w=main.ReadWorker(folder,copy.deepcopy(DEFAULT));w.result.connect(lambda *a:result.append(a));w.run()
   return result[0]
  cold=run();db=sqlite3.connect(p/'cache.sqlite');path,sig,raw=db.execute('select * from cache').fetchone();packet=json.loads(raw)
  packet['records'][0]['values']={}
  print('CACHE validator accepts missing fields=',main.ReadWorker._valid_cached_packet(packet,False))
  db.execute('update cache set data=?',(json.dumps(packet),));db.commit();db.close();warm=run()
  x={'E1':{'info':{'name':'Name'},'records':[{'employee':'E1','date':'2026-10-01','name':'Name','values':{'start':None,'end':None,'work':None}}]}}
  for label,result in [('cold',cold),('corrupt cache',warm)]:
   rows=reconcile(x,result[1],{'E1':'S1'},copy.deepcopy(DEFAULT))[0]
   print(label,'stats=',result[3], 'rows=',[(r['field'],r['status'],r.get('csv')) for r in rows])
recovery();cache()
