from probe import *
with tempfile.TemporaryDirectory() as t:
 root=Path(t);folder=root/'inputs';folder.mkdir();data=root/'data';data.mkdir()
 p=csvfile(folder,{10:'9:00',11:'18:00',12:'8:00'})
 packet=csv_read(p,DEFAULT);packet['records'][0]['values']={}
 import sqlite3
 db=sqlite3.connect(data/'attendance_cache.sqlite3');db.execute('CREATE TABLE cache (path TEXT PRIMARY KEY,sig TEXT,data TEXT)')
 st=p.stat();sig=f'{st.st_size}:{st.st_mtime_ns}:{parser_tag(DEFAULT,"csv")}'
 db.execute('INSERT INTO cache VALUES(?,?,?)',(str(p),sig,json.dumps(packet)));db.commit();db.close()
 worker=main.ReadWorker(folder,DEFAULT);out=[];worker.result.connect(lambda *args:out.append(args))
 with patch.object(main,'DB',data/'attendance_cache.sqlite3'):worker.run()
 xdata,cdata,issues,stats=out[0]
 x={'date':'2026-10-01','employee':'E1','name':'Name','values':{'start':None,'end':None,'work':None}}
 rows,_=reconcile({'E1':{'info':{'name':'Name'},'records':[x]}},cdata,{'E1':'S1'},DEFAULT)
 print(json.dumps({'cache_hits':stats['cache_hits'],'parsed':stats['parsed'],'source_times':['9:00','18:00','8:00'],'loaded_values':cdata[0]['values'],'result_statuses':[r['status'] for r in rows]},ensure_ascii=False,indent=2))
