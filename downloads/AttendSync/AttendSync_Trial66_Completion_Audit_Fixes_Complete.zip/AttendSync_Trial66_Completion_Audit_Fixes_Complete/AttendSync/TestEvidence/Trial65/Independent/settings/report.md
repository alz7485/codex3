# Trial65 独立監査：設定変更・旧データ移行

対象：Trial64 Classic Outlook COM Complete。監査担当は本体を変更していません。すべて合成CSV・JSONと TemporaryDirectory、Qt offscreen で実施しました。実Outlook・実メール・認証・ネットワークは使用していません。

## 判定

独立テスト15メソッド。13メソッド成功、2メソッド失敗（4サブケース＋GUI経由の計5失敗）。失敗は以下の **同一原因1件** に集約します。

### S65-01：省略が許可される設定項目で勤怠読込全体が停止（P2）

- 対象項目：`csv_encoding`、`csv_first_row`、`data_first_row`、`data_last_row`。
- 操作：既定設定からいずれか1項目を省略した旧形式設定を読み込む。設定バリデータは受理する。GUIでも詳細JSONに反映して「設定を保存」できる。
- 期待：バリデータやフォームで表示される既定値 `auto` / `2` / `9` / `100` を読み込みに使用する。
- 実際：`cache_tags.parser_tag` の `cfg[key]` が KeyError。`ReadWorker` は `fatal_error` として読込全体を中止する。入力フォルダに依存せず、CSVのみのフォルダでもXLSXの範囲省略によって失敗する。
- GUIで範囲3項目を省略したJSONを反映→保存した場合も、`_collect_config` が既定表示の省略項目を保存しないため、直後の読み込みが同様に失敗する。
- 箇所：`settings_dialog.py:validate_json_config` / `_collect_config`、`cache_tags.py:parser_tag`、`main.py:ReadWorker`、`engine.py:csv_read` / `xlsx_read`。
- 根本対策：省略項目は変更前の設定を壊さず、一貫して既定値を補完してからタグ計算・解析・照合に使用する。タグだけ直してもパーサの直接参照が残るため不十分。
- 再現：

```sh
QT_QPA_PLATFORM=offscreen /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/settings/probe_legacy.py
QT_QPA_PLATFORM=offscreen /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/settings/audit_settings.py
```

## 成功した独立確認

- 社員情報CSVを任意の列C/D/A/B・開始行3で指定し、CP932 / UTF-8 BOMを明示および自動判定して、先頭ゼロ付きの両IDと日本語氏名を維持。
- 誤った文字コードは読み込みエラーとなり、元CSVは変更しない。
- 旧社員情報・旧メール取込設定と未知の拡張情報を維持。明示登録のない旧メール情報だけでは勤怠開始を許可せず、旧社員情報CSVの登録記録があるものは互換判定する。
- COM設定画面で旧client_id・tenant_idの入力欄は存在しない。旧値と未知のメール/全体拡張情報は保存後も保持し、元cfgを変更しない。
- 起動中Outlook情報取得の失敗・複数アカウント選択の取消で、既存の送信元入力と名称を維持し、ボタンを再有効化。
- 設定保存でPermissionErrorを注入すると、現在の設定・前回結果・結果の読込設定スナップショット・ファイル状態を維持。
- 設定保存成功後は新しいメール設定を反映し、表示中結果のCSV列と開始行は旧読込設定を維持。
- 設定画面取消は設定とファイルを変更しない。
- CSV列・開始行・文字コードの変更は解析キャッシュキーを更新。メール設定の変更はキーを変更しない。
- 不正な詳細JSONは入力フォーム・元設定を変更せず拒否。
- 社員CSVプレビュー後に開始行や氏名列を変更すると、古い一覧と反映許可を即座に消去し、タイマー後に新設定の行と氏名へ更新。
- CSV取込画面の取消は、以前の列指定・開始行・文字コード・社員情報を保持。

ログ：`results.log`。テスト：`audit_settings.py`。修正版は `ATTENDSYNC_SOURCE_ROOT` を指定して同じテストを実行できます。

## Trial65修正版の独立再試験

対象：`AttendSync_Trial65_Independent_Audit_Complete/AttendSync`。

- 同じ15テストメソッドを変更せず再実行し、**15/15成功**。既知の4省略項目の直接読込と、GUIの詳細JSON→入力欄に反映→設定保存経路の失敗も解消した。
- 修正コードを確認し、`engine.read_config` の省略可能scalar項目の既定値補完が `ReadWorker` 初期化、キャッシュタグ、CSV/XLSX直接解析に共通して適用されることを確認。
- 追加の実データ検証として、合成社員1名分のCSVとXLSXを作成し、`year` / `month` / `data_first_row` / `data_last_row` / `csv_first_row` / `csv_encoding` をそれぞれ省略して、直接解析・ワーカー読込・補完後とのキャッシュタグ一致・未知の入れ子拡張保持・元入力cfg不変を確認。**6/6条件成功**。
- 本担当の指摘 S65-01 は解消。新規の未解決所見なし。

再試験コマンド：

```sh
ATTENDSYNC_SOURCE_ROOT=/workspace/attendsync-audit/AttendSync_Trial65_Independent_Audit_Complete/AttendSync QT_QPA_PLATFORM=offscreen /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/settings/audit_settings.py
QT_QPA_PLATFORM=offscreen /workspace/attendsync-audit/venv/bin/python /workspace/attendsync-audit/trial65-audit/settings/verify_defaults_data.py
```

証拠：`results_trial65.log`、`verify_defaults_data.py`、`verify_defaults_data.log`。
