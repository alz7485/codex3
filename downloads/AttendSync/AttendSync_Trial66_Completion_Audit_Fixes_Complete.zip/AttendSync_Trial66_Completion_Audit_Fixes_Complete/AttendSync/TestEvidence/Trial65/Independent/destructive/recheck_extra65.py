import os,sys,tempfile,copy,json,base64
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
sys.path.insert(0,'/workspace/attendsync-audit/AttendSync_Trial65_Independent_Audit_Complete/AttendSync')
import runtime_paths
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):import main
from employee_information import recover_employee_save
from engine import DEFAULT,save_json
cases=0
for field,payloads in [('mapping',[b'',b'null',b'[]',b'not JSON',b'\xff',b'{"E1":3}',b'{"": "S1"}']),('contacts',[b'',b'null',b'[]',b'not JSON',b'\xff',b'{"version":2,"contacts":[]}',b'{"version":1,"contacts":[{}]}',b'{"version":1,"contacts":[],"employee_import_settings":{"linking":[]}}'])]:
 for payload in payloads:
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);mp=p/'staff_mapping.json';cp=p/'employee_contacts.json';jp=p/'employee_save_transaction.json'
   save_json(mp,{'E1':'S1'});save_json(cp,{'version':1,'contacts':[]});before=(mp.read_bytes(),cp.read_bytes())
   journal={'mapping':None,'contacts':None};journal[field]=base64.b64encode(payload).decode();save_json(jp,journal)
   try:recover_employee_save(mp,cp)
   except ValueError:pass
   else:raise AssertionError((field,payload,'not rejected'))
   assert (mp.read_bytes(),cp.read_bytes())==before and jp.exists(),(field,payload,'files changed')
   cases+=1
for is_xlsx in (False,True):
 keys=DEFAULT['xlsx_columns' if is_xlsx else 'csv_columns']
 r={'date':'2026-10-01','employee':'E1','staff':'S1','name':'Name','values':{k:None for k in keys},'invalid_fields':[],'missing_fields':[]}
 packet={'info':{'employee':'E1'},'period_unverified':False,'records':[r],'warnings':[]}
 assert main.ReadWorker._valid_cached_packet(packet,is_xlsx)
 cases+=1
 for bad in ([],{},[None],{'unexpected':'nested'}):
  new=copy.deepcopy(packet);new['records'][0]['values']['start']=bad
  assert not main.ReadWorker._valid_cached_packet(new,is_xlsx),(is_xlsx,bad)
  cases+=1
 for key in keys:
  new=copy.deepcopy(packet);del new['records'][0]['values'][key]
  assert not main.ReadWorker._valid_cached_packet(new,is_xlsx),(is_xlsx,key)
  cases+=1
print(f'PASS: {cases} additional semantic-recovery/cache-shape cases, no live-file mutation')
