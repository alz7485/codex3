"""Independent Trial65 settings/migration audit; synthetic local data only."""
import os,sys,copy,json,csv,io,tempfile,unittest
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
from unittest.mock import patch
ROOT=Path(os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync'))
sys.path.insert(0,str(ROOT))
from PySide6.QtWidgets import QApplication,QWidget,QDialog,QLineEdit,QPushButton,QTableWidget,QSpinBox,QComboBox
from PySide6.QtCore import QTimer
from PySide6.QtTest import QTest
from engine import DEFAULT,save_json
from settings_dialog import SettingsDialog,SettingsError
from employee_information import read_information_csv,show_employee_import_dialog,load_information,registration_is_ready
from cache_tags import parser_tag
import runtime_paths
IMPORT_TMP=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT_TMP.name)):import main
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)
EMPTY={'version':1,'contacts':[],'import_settings':{}}

class AcceptedDialog:
 proposed=None
 def __init__(self,parent,cfg):self.value=copy.deepcopy(self.proposed)
 def exec(self):return QDialog.Accepted
 def deleteLater(self):pass

class Settings65(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.path=Path(self.tmp.name)
  self.parent=QWidget();self.parent.is_dark=False;self.widgets=[]
  self.addCleanup(self.cleanup)
 def cleanup(self):
  for w in reversed(self.widgets):w.close();w.deleteLater()
  self.parent.close();self.parent.deleteLater();APP.processEvents()
 def dialog(self,cfg=None):
  d=SettingsDialog(self.parent,copy.deepcopy(DEFAULT) if cfg is None else cfg);self.widgets.append(d);return d
 def window(self):
  changes={'CONFIG':self.path/'settings.json','MAP':self.path/'staff_mapping.json','DB':self.path/'cache.sqlite','DATA_DIR':self.path}
  p=patch.multiple(main,**changes);p.start();self.addCleanup(p.stop)
  w=main.Window();self.widgets.append(w);return w
 def source(self,encoding='utf-8-sig'):
  p=self.path/'employees.csv';p.write_text('header,header,header,header,header\nignored,ignored,ignored,ignored,ignored\n山田 太郎,one@example.com,00001,00100,x\n佐藤 花子,two@example.com,00002,00200,x\n',encoding=encoding);return p
 def test_accepted_optional_legacy_defaults_can_read(self):
  for missing in ('csv_encoding','csv_first_row','data_first_row','data_last_row'):
   with self.subTest(missing=missing):
    cfg=copy.deepcopy(DEFAULT);cfg.pop(missing);SettingsDialog.validate_json_config(cfg)
    rows=[];worker=main.ReadWorker(self.path,cfg);worker.result.connect(lambda *args:rows.append(args));worker.run()
    self.assertNotIn('fatal_error',rows[0][3],rows[0][3].get('fatal_error'))
 def test_optional_defaults_are_usable_after_ui_json_save(self):
  cfg=copy.deepcopy(DEFAULT)
  for key in ('csv_first_row','data_first_row','data_last_row'):cfg.pop(key)
  d=self.dialog();d.advanced.setPlainText(json.dumps(cfg));self.assertTrue(d.apply_json_to_form(),d.error_label.text());d.accept();self.assertEqual(d.result(),QDialog.Accepted)
  rows=[];worker=main.ReadWorker(self.path,d.value);worker.result.connect(lambda *args:rows.append(args));worker.run()
  self.assertNotIn('fatal_error',rows[0][3],rows[0][3].get('fatal_error'))
 def test_employee_columns_first_row_all_encodings(self):
  for encoding in ('utf-8-sig','cp932'):
   p=self.source(encoding)
   for chosen in ('auto',encoding):
    rows=read_information_csv(p,'linking',{'employee':'C','staff':'D','name':'A','email':'B'},3,chosen)
    self.assertEqual(len(rows),2);self.assertEqual(rows[0]['employee'],'00001');self.assertEqual(rows[0]['staff'],'00100');self.assertEqual(rows[0]['name'],'山田 太郎');self.assertEqual(rows[0]['line'],3)
 def test_wrong_encoding_rejects_without_editing_file(self):
  p=self.source('cp932');before=p.read_bytes()
  with self.assertRaises(UnicodeDecodeError):read_information_csv(p,'linking',{'employee':'C','staff':'D','name':'A','email':'B'},3,'utf-8-sig')
  self.assertEqual(p.read_bytes(),before)
 def test_legacy_contacts_and_extension_metadata_roundtrip(self):
  legacy={**EMPTY,'contacts':[{'employee':'00001','staff':'00100','name':'旧社員','email':'one@example.com'}], 'import_settings':{'columns':{'employee':'C','staff':'D','name':'A','email':'B'},'future':{'keep':[1,2]}}, 'future_employee':{'keep':True}}
  p=self.path/'contacts.json';save_json(p,legacy);loaded=load_information(p)
  self.assertEqual(loaded,legacy);self.assertFalse(registration_is_ready(loaded,{'00001':'00100'}))
  loaded['csv_sources']={str(self.source()):'linking'}
  self.assertTrue(registration_is_ready(loaded,{'00001':'00100'}));self.assertEqual(loaded['future_employee'],{'keep':True})
 def test_com_settings_keep_graph_and_future_extensions(self):
  cfg=copy.deepcopy(DEFAULT);cfg['mail_settings']={'client_id':'old-client','tenant_id':'old-tenant','account':'operator@example.com','auto_send':True,'custom_extension':{'nested':['keep',3]}}
  cfg['future_settings']={'keep':42};before=copy.deepcopy(cfg);d=self.dialog(cfg)
  self.assertNotIn('client_id',d.mail_controls);self.assertNotIn('tenant_id',d.mail_controls)
  d.mail_controls['account'].setText('new@example.com');d.accept();self.assertEqual(d.result(),QDialog.Accepted,d.error_label.text())
  self.assertEqual(d.value['mail_settings']['client_id'],'old-client');self.assertEqual(d.value['mail_settings']['tenant_id'],'old-tenant');self.assertEqual(d.value['mail_settings']['custom_extension'],{'nested':['keep',3]});self.assertEqual(d.value['future_settings'],{'keep':42});self.assertEqual(cfg,before)
 def test_outlook_account_retrieval_failure_keeps_inputs(self):
  d=self.dialog();d.mail_controls['account'].setText('old@example.com');d.mail_controls['sender_name'].setText('旧名称')
  with patch('classic_outlook.running_outlook_accounts',side_effect=RuntimeError('synthetic COM failure')),patch('PySide6.QtWidgets.QMessageBox.warning') as warning:d._read_outlook_account()
  self.assertEqual(d.mail_controls['account'].text(),'old@example.com');self.assertEqual(d.mail_controls['sender_name'].text(),'旧名称');self.assertTrue(d.outlook_account_button.isEnabled());warning.assert_called_once()
 def test_outlook_account_cancel_keeps_inputs(self):
  d=self.dialog();d.mail_controls['account'].setText('old@example.com')
  accounts=[{'account':'one@example.com','sender_name':'One'},{'account':'two@example.com','sender_name':'Two'}]
  with patch('classic_outlook.running_outlook_accounts',return_value=accounts),patch('settings_dialog.QInputDialog.getItem',return_value=('',False)):d._read_outlook_account()
  self.assertEqual(d.mail_controls['account'].text(),'old@example.com');self.assertTrue(d.outlook_account_button.isEnabled())
 def test_settings_save_failure_keeps_current_results_and_config(self):
  w=self.window();before=copy.deepcopy(w.cfg);w.results_cfg=copy.deepcopy(w.cfg);w.results=[{'sentinel':'old result'}];w.visible=list(w.results);results=w.results
  AcceptedDialog.proposed=copy.deepcopy(w.cfg);AcceptedDialog.proposed['csv_columns']['start']='Z';AcceptedDialog.proposed['mail_settings']={'account':'new@example.com'}
  with patch.object(main,'SettingsDialog',AcceptedDialog),patch.object(main,'save_json',side_effect=PermissionError('synthetic denied')),patch.object(main.QMessageBox,'warning') as warning:w.edit_settings()
  self.assertEqual(w.cfg,before);self.assertIs(w.results,results);self.assertEqual(w.result_config()['csv_columns']['start'],before['csv_columns']['start']);self.assertFalse(main.CONFIG.exists());warning.assert_called_once()
 def test_settings_save_keeps_result_source_snapshot_but_updates_mail(self):
  w=self.window();w.results_cfg=copy.deepcopy(w.cfg);before=copy.deepcopy(w.results_cfg)
  AcceptedDialog.proposed=copy.deepcopy(w.cfg);AcceptedDialog.proposed['csv_columns']['start']='Z';AcceptedDialog.proposed['csv_first_row']=7;AcceptedDialog.proposed['mail_settings']={'account':'new@example.com'}
  with patch.object(main,'SettingsDialog',AcceptedDialog):w.edit_settings()
  self.assertEqual(w.cfg['csv_columns']['start'],'Z');self.assertEqual(w.cfg['mail_settings']['account'],'new@example.com');self.assertEqual(w.result_config()['csv_columns'],before['csv_columns']);self.assertEqual(w.result_config()['csv_first_row'],before['csv_first_row']);self.assertEqual(json.loads(main.CONFIG.read_text())['csv_first_row'],7)
 def test_settings_cancel_does_not_write_or_mutate(self):
  w=self.window();before=copy.deepcopy(w.cfg)
  with patch.object(SettingsDialog,'exec',return_value=QDialog.Rejected):w.edit_settings()
  self.assertEqual(w.cfg,before);self.assertFalse(main.CONFIG.exists())
 def test_parser_cache_keys_track_read_settings_not_mail(self):
  cfg=copy.deepcopy(DEFAULT);base=parser_tag(cfg,'csv')
  for key,value in (('csv_first_row',4),('csv_encoding','cp932')):
   c=copy.deepcopy(cfg);c[key]=value;self.assertNotEqual(parser_tag(c,'csv'),base)
  c=copy.deepcopy(cfg);c['csv_columns']['staff']='J';self.assertNotEqual(parser_tag(c,'csv'),base)
  c=copy.deepcopy(cfg);c['mail_settings']={'account':'operator@example.com','auto_send':True};self.assertEqual(parser_tag(c,'csv'),base)
 def test_invalid_json_application_is_atomic(self):
  d=self.dialog();before=copy.deepcopy(d._base);inputs=[(s,k,e.text()) for s,k,e in d.entries]
  for change in ({'csv_first_row':0},{'csv_columns':[]},{'mail_settings':{'auto_send':'false'}},{'data_last_row':1}):
   cfg=copy.deepcopy(DEFAULT);cfg.update(change);d.advanced.setPlainText(json.dumps(cfg));self.assertFalse(d.apply_json_to_form());self.assertEqual(d._base,before);self.assertEqual([(s,k,e.text()) for s,k,e in d.entries],inputs)
 def test_employee_preview_change_clears_stale_rows_before_reread(self):
  p=self.path/'employees.csv';p.write_text('staff,employee,name,other,email\nS1,E1,山田,別名,one@example.com\nS2,E2,佐藤,別名2,two@example.com\n',encoding='utf-8-sig')
  contacts=copy.deepcopy(EMPTY);contacts['employee_import_settings']={'linking':{'columns':{'staff':'A','employee':'B','name':'C','email':'E'},'first_row':2,'encoding':'auto'}};before=copy.deepcopy(contacts);errors=[]
  def operate():
   dlg=APP.activeModalWidget()
   try:
    apply=next(b for b in dlg.findChildren(QPushButton) if b.text()=='一覧に反映');table=dlg.findChild(QTableWidget,'informationPreview')
    dlg.findChild(QLineEdit,'informationCsvPath').setText(str(p));QTest.qWait(320);self.assertEqual(table.rowCount(),2);self.assertTrue(apply.isEnabled())
    dlg.findChild(QSpinBox,'informationFirstRow').setValue(3);self.assertEqual(table.rowCount(),0);self.assertFalse(apply.isEnabled());QTest.qWait(320);self.assertEqual(table.rowCount(),1);self.assertEqual(table.item(0,1).text(),'E2')
    dlg.findChild(QLineEdit,'informationColumn_name').setText('D');self.assertEqual(table.rowCount(),0);self.assertFalse(apply.isEnabled());QTest.qWait(320);self.assertEqual(table.item(0,2).text(),'別名2');apply.click()
   except Exception as exc:errors.append(exc);dlg.reject()
  QTimer.singleShot(0,operate);result=show_employee_import_dialog(self.parent,{},contacts,copy.deepcopy(DEFAULT));self.assertFalse(errors,errors);self.assertEqual(result['mapping'],{'E2':'S2'});self.assertEqual(result['contacts']['employee_import_settings']['linking']['first_row'],3);self.assertEqual(contacts,before)
 def test_employee_import_cancel_keeps_original_settings_and_contacts(self):
  contacts=copy.deepcopy(EMPTY);contacts['employee_import_settings']={'linking':{'columns':{'staff':'D','employee':'C','name':'A','email':'B'},'first_row':3,'encoding':'cp932'}};before=copy.deepcopy(contacts);p=self.source('cp932');errors=[]
  def operate():
   dlg=APP.activeModalWidget()
   try:
    self.assertEqual(dlg.findChild(QLineEdit,'informationColumn_staff').text(),'D');self.assertEqual(dlg.findChild(QSpinBox,'informationFirstRow').value(),3);self.assertEqual(dlg.findChild(QComboBox,'informationEncoding').currentText(),'cp932');dlg.findChild(QLineEdit,'informationCsvPath').setText(str(p));QTest.qWait(320);self.assertEqual(dlg.findChild(QTableWidget,'informationPreview').rowCount(),2);dlg.reject()
   except Exception as exc:errors.append(exc);dlg.reject()
  QTimer.singleShot(0,operate);result=show_employee_import_dialog(self.parent,{},contacts,copy.deepcopy(DEFAULT));self.assertIsNone(result);self.assertFalse(errors,errors);self.assertEqual(contacts,before)

if __name__=='__main__':unittest.main(verbosity=2)
