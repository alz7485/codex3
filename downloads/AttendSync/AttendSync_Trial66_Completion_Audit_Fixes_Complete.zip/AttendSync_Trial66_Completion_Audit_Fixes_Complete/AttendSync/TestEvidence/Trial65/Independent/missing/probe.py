import os,sys,copy,tempfile,json,csv,unittest
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from xml.etree import ElementTree as ET
SOURCE=Path(os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync'))
sys.path.insert(0,str(SOURCE));os.environ['QT_QPA_PLATFORM']='offscreen'
from engine import DEFAULT,xlsx_read,csv_read,reconcile,Cache
from cache_tags import parser_tag
from employee_information import read_information_csv,plan_employee_import
from unittest.mock import patch
import runtime_paths
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):import main
NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
def workbook(root,fields):
 from openpyxl import Workbook
 p=root/'input.xlsx';w=Workbook();s=w.active;s.title='10月'
 for key,value in {'A1':'2026年10月度','N1':'E1','U1':'Name','A9':10,'B9':1,**fields}.items():s[key]=value
 if 'M9' in fields:s['M9'].number_format='h:mm;;'
 w.save(p);w.close();return p

def cache_formula(p,column,value='0'):
 with ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
 sheet=ET.fromstring(parts['xl/worksheets/sheet1.xml']);cell=next(c for c in sheet.iter(NS+'c') if c.get('r')==column+'9');cell.set('t','n');cell.find(NS+'v').text=value
 parts['xl/worksheets/sheet1.xml']=ET.tostring(sheet)
 with ZipFile(p,'w',ZIP_DEFLATED) as z:
  for n,data in parts.items():z.writestr(n,data)

def csvfile(root,changes=None,length=14,name='attendance.csv'):
 row=['']*length;row[0]='20261001';row[3]='S1';row[4]='Name'
 for index,value in (changes or {}).items():row[index]=value
 p=root/name
 with p.open('w',newline='') as f:
  writer=csv.writer(f);writer.writerow(['header']);writer.writerow(row)
 return p

class Boundary(unittest.TestCase):
 def test_custom_clock_comparison_cache_consistency(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);p=workbook(root,{'M9':'=0'});cache_formula(p,'M')
   cfg=copy.deepcopy(DEFAULT);db=Cache(root/'cache.sqlite3')
   first,_=db.parse(p,parser_tag(cfg,'xlsx'),lambda p:xlsx_read(p,cfg))
   # User adds a clock comparison on an additional XLSX field after first loading.
   cfg['comparisons']=[{'name':'Custom clock','xlsx':'break_total','csv':'start','type':'clock','enabled':True}]
   cached,hit=db.parse(p,parser_tag(cfg,'xlsx'),lambda p:xlsx_read(p,cfg));fresh=xlsx_read(p,cfg)
   c=csv_read(csvfile(root),cfg)['records']
   old_rows,_=reconcile({'E1':cached},c,{'E1':'S1'},cfg);new_rows,_=reconcile({'E1':fresh},c,{'E1':'S1'},cfg)
   print('CUSTOM_CLOCK',{'cache_hit':hit,'cached_value':str(cached['records'][0]['values']['break_total']),'fresh_value':str(fresh['records'][0]['values']['break_total']),'cached_status':old_rows[0]['status'],'fresh_status':new_rows[0]['status']})
   db.close();self.assertEqual(old_rows[0]['status'],new_rows[0]['status'])
 def test_incomplete_values_cache_is_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);p=csvfile(root,{10:'9:00',11:'18:00',12:'8:00'})
   packet=csv_read(p,DEFAULT);packet['records'][0]['values']={}
   accepted=main.ReadWorker._valid_cached_packet(packet,False)
   x={'date':'2026-10-01','employee':'E1','name':'Name','values':{'start':None,'end':None,'work':None}}
   rows,_=reconcile({'E1':{'info':{'name':'Name'},'records':[x]}},packet['records'],{'E1':'S1'},DEFAULT)
   print('INCOMPLETE_VALUES',{'cache_accepted':accepted,'statuses':[r['status'] for r in rows]})
   self.assertFalse(accepted)
 def test_invalid_csv_values_are_preserved_as_review(self):
  bad=['-1:00','48:00','999:99','not-a-time','TRUE','nan','1e309','9:60','9:00:60','=TIME(9,0,0)']
  for v in bad:
   with self.subTest(value=v),tempfile.TemporaryDirectory() as t:
    p=csvfile(Path(t),{10:v});packet=csv_read(p,DEFAULT)
    self.assertEqual(len(packet['records']),1);self.assertIn('start',packet['records'][0]['invalid_fields']);self.assertTrue(packet['warnings'])
 def test_csv_bad_dates_never_produce_records(self):
  for v in ['20260229','20261301','20261000','2026-10-01','2026101','20261001.0','２０２６１００１','20261001\x00']:
   with self.subTest(value=v),tempfile.TemporaryDirectory() as t:
    packet=csv_read(csvfile(Path(t),{0:v}),DEFAULT);self.assertFalse(packet['records']);self.assertTrue(packet['warnings'])
 def test_real_empty_present_and_missing_columns_distinguished(self):
  for n in [5,10,11,12,13,14]:
   with self.subTest(length=n),tempfile.TemporaryDirectory() as t:
    r=csv_read(csvfile(Path(t),length=n),DEFAULT)['records'][0]
    for key,index in [('start',10),('end',11),('work',12),('break_total',13)]:self.assertEqual(key in r['missing_fields'],index>=n)
 def test_missing_identity_and_nonempty_rows_warn(self):
  for change in [{0:''},{3:''},{0:'',3:''}]:
   with self.subTest(change=change),tempfile.TemporaryDirectory() as t:
    packet=csv_read(csvfile(Path(t),change),DEFAULT);self.assertFalse(packet['records']);self.assertTrue(packet['warnings'])
 def test_employee_csv_short_and_empty_rows_do_not_match_mail(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'employees.csv';p.write_text('a,b,c,d,e,f,g,h,i,j\nS1,E1,Name\n\n,S2,BlankStaff,,,,,,,person@example.com\n',encoding='utf-8')
   rows=read_information_csv(p,'linking',{'staff':'A','employee':'B','name':'C','email':'J'});mapping,data,results=plan_employee_import(rows,'linking',{}, {'version':1,'contacts':[]})
   self.assertEqual(mapping,{'E1':'S1'});self.assertFalse(any(r['matched'] for r in results));self.assertFalse(data['contacts'])
 def test_csv_oversized_field_fails_without_partial_result(self):
  with tempfile.TemporaryDirectory() as t:
   p=csvfile(Path(t),{4:'x'*150000})
   with self.assertRaises(csv.Error):csv_read(p,DEFAULT)
 def test_empty_and_formula_missing_caches_not_blank_matches(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);p=workbook(root,{'G9':'=IF(1,"",0)'})
   x=xlsx_read(p,DEFAULT);c=csv_read(csvfile(root),DEFAULT)['records'];rows,_=reconcile({'E1':x},c,{'E1':'S1'},DEFAULT)
   self.assertIn('start',x['records'][0]['invalid_fields']);self.assertTrue(any('計算結果なし' in r['field'] for r in rows));self.assertFalse(any(r['field']=='始業時刻' and r['status']=='一致' for r in rows))
 def test_unreadable_or_wrong_period_never_passes_silently(self):
  for period in ['2025年10月','2025 年 10 月度','2025/10','',None]:
   with self.subTest(period=period),tempfile.TemporaryDirectory() as t:
    p=workbook(Path(t),{'A1':period,'G9':'9:00','H9':'18:00','T9':'8:00'})
    packet=xlsx_read(p,DEFAULT)
    self.assertTrue(packet.get('error') or packet.get('warnings'),repr(period))
if __name__=='__main__':unittest.main(verbosity=2)
