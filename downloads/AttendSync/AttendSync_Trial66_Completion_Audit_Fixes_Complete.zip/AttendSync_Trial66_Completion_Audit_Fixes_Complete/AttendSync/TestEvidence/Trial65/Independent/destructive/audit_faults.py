"""Trial65 independent destructive audit against immutable Trial64.
Only synthetic TemporaryDirectory data. No network/Outlook/authentication.
"""
import os,sys,tempfile,json,base64,copy,sqlite3,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
SOURCE=Path(os.environ.get('ATTENDSYNC_SOURCE_ROOT','/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync'))
sys.path.insert(0,str(SOURCE))
import engine,employee_information as info,runtime_paths
from engine import DEFAULT,save_json,reconcile
IMPORT=tempfile.TemporaryDirectory()
with patch.object(runtime_paths,'get_data_dir',return_value=Path(IMPORT.name)):import main
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import QObject,Signal
from PySide6.QtTest import QTest
APP=QApplication.instance() or QApplication([]);APP.setQuitOnLastWindowClosed(False)

def until(predicate,seconds=8):
 stop=time.monotonic()+seconds
 while not predicate():
  if time.monotonic()>stop:raise AssertionError('Qt condition timeout')
  APP.processEvents();QTest.qWait(5)
 APP.processEvents()

class Faults(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.mp=self.root/'staff_mapping.json';self.cp=self.root/'employee_contacts.json';self.jp=self.root/'employee_save_transaction.json'
  self.empty={'version':1,'contacts':[]};self.oldmap={'E1':'S1'}
  save_json(self.mp,self.oldmap);save_json(self.cp,self.empty);self.before=(self.mp.read_bytes(),self.cp.read_bytes())
 def unchanged(self):self.assertEqual((self.mp.read_bytes(),self.cp.read_bytes()),self.before)
 def runworker(self,full=False):
  out=[]
  with patch.object(main,'DB',self.root/'cache.sqlite'):
   worker=main.ReadWorker(self.folder,copy.deepcopy(DEFAULT),full);worker.result.connect(lambda *a:out.append(a));worker.run()
  self.assertEqual(len(out),1);return out[0]
 def input(self):
  self.folder=self.root/'input';self.folder.mkdir()
  (self.folder/'attendance.csv').write_text('date,calendar,x,staff,name,x,x,x,x,x,start,end,work,break\n20261001,0,,S1,Name,,,,,,09:00,18:00,08:00,01:00\n')
 def test_atomic_json_dump_partial_write_failure(self):
  def fail(value,stream,**kw):stream.write('{partial');raise OSError('injected disk full')
  with patch.object(engine.json,'dump',side_effect=fail),self.assertRaises(OSError):save_json(self.mp,{'new':1})
  self.unchanged();self.assertFalse(list(self.root.glob('*.tmp')))
 def test_atomic_json_replace_failure(self):
  original=Path.replace
  def fail(path,target):
   if Path(target)==self.mp:raise PermissionError('injected readonly target')
   return original(path,target)
  with patch.object(Path,'replace',fail),self.assertRaises(PermissionError):save_json(self.mp,{'new':1})
  self.unchanged();self.assertFalse(list(self.root.glob('*.tmp')))
 def test_journal_write_failure_changes_neither_live_file(self):
  def fail(path,value):raise OSError('injected journal disk full')
  with patch.object(info,'save_json',side_effect=fail),self.assertRaises(OSError):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},self.empty)
  self.unchanged();self.assertFalse(self.jp.exists())
 def test_first_writer_partial_failure_rolls_back(self):
  def writer(path,value):path.write_bytes(b'partial');raise OSError('injected first write')
  with self.assertRaises(OSError):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},self.empty,writer)
  self.unchanged();self.assertFalse(self.jp.exists())
 def test_second_writer_partial_failure_rolls_back(self):
  def writer(path,value):
   if path==self.mp:path.write_bytes(b'partial');raise OSError('injected second write')
   save_json(path,value)
  with self.assertRaises(OSError):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},{**self.empty,'new':True},writer)
  self.unchanged();self.assertFalse(self.jp.exists())
 def test_crash_between_writes_is_recovered_next_start(self):
  def writer(path,value):
   if path==self.mp:raise KeyboardInterrupt('simulated process crash')
   save_json(path,value)
  with self.assertRaises(KeyboardInterrupt):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},{**self.empty,'new':True},writer)
  self.assertTrue(self.jp.exists());info.recover_employee_save(self.mp,self.cp);self.unchanged();self.assertFalse(self.jp.exists())
 def test_crash_with_originally_absent_files_restores_absence(self):
  self.mp.unlink();self.cp.unlink()
  def writer(path,value):
   if path==self.mp:raise KeyboardInterrupt('simulated crash')
   save_json(path,value)
  with self.assertRaises(KeyboardInterrupt):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},self.empty,writer)
  info.recover_employee_save(self.mp,self.cp);self.assertFalse(self.mp.exists());self.assertFalse(self.cp.exists());self.assertFalse(self.jp.exists())
 def test_recovery_retry_after_restore_write_failure(self):
  snapshots={key:base64.b64encode(path.read_bytes()).decode() for key,path in [('mapping',self.mp),('contacts',self.cp)]}
  save_json(self.jp,snapshots);self.mp.write_bytes(b'partial map');self.cp.write_bytes(b'partial contacts');original=Path.replace
  def fail(path,target):
   if Path(target)==self.mp:raise PermissionError('mapping busy')
   return original(path,target)
  with patch.object(Path,'replace',fail),self.assertRaises(PermissionError):info.recover_employee_save(self.mp,self.cp)
  self.assertTrue(self.jp.exists());info.recover_employee_save(self.mp,self.cp);self.unchanged();self.assertFalse(self.jp.exists())
 def test_journal_unlink_failure_rolls_back_and_keeps_recoverable_journal(self):
  original=Path.unlink
  def fail(path,*args,**kwargs):
   if path==self.jp:raise PermissionError('journal busy')
   return original(path,*args,**kwargs)
  with patch.object(Path,'unlink',fail),self.assertRaises(PermissionError):info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},{**self.empty,'new':True})
  self.unchanged();self.assertTrue(self.jp.exists());info.recover_employee_save(self.mp,self.cp);self.unchanged()
 def test_invalid_base64_and_snapshot_types_never_modify_live_files(self):
  for value in ('!not base64!',5,False,[],{}):
   with self.subTest(value=value):
    save_json(self.jp,{'mapping':value,'contacts':None})
    with self.assertRaises(ValueError):info.recover_employee_save(self.mp,self.cp)
    self.unchanged();self.assertTrue(self.jp.exists())
 def test_valid_base64_invalid_json_must_never_modify_live_files(self):
  save_json(self.jp,{'mapping':base64.b64encode(b'not JSON').decode(),'contacts':None})
  with self.assertRaises(ValueError):info.recover_employee_save(self.mp,self.cp)
  self.unchanged();self.assertTrue(self.jp.exists())
 def test_valid_base64_wrong_json_root_must_never_modify_live_files(self):
  save_json(self.jp,{'mapping':base64.b64encode(b'[]').decode(),'contacts':None})
  with self.assertRaises(ValueError):info.recover_employee_save(self.mp,self.cp)
  self.unchanged();self.assertTrue(self.jp.exists())
 def test_concurrent_commit_cannot_cross_two_file_transaction(self):
  entered=threading.Event();release=threading.Event();errors=[]
  def writer(path,value):
   if path==self.cp:entered.set();self.assertTrue(release.wait(5))
   save_json(path,value)
  def run():
   try:info.commit_employee_information(self.mp,self.cp,{'E2':'S2'},{**self.empty,'new':True},writer)
   except BaseException as e:errors.append(e)
  thread=threading.Thread(target=run);thread.start();self.assertTrue(entered.wait(5))
  try:
   with self.assertRaisesRegex(RuntimeError,'別のメール処理'):info.commit_employee_information(self.mp,self.cp,{'E3':'S3'},self.empty)
  finally:release.set();thread.join(5)
  self.assertFalse(thread.is_alive());self.assertFalse(errors);self.assertEqual(json.loads(self.mp.read_text()),{'E2':'S2'});self.assertEqual(json.loads(self.cp.read_text())['new'],True)
 def test_invalid_json_cached_packet_is_discarded_and_reparsed(self):
  self.input();self.runworker();db=sqlite3.connect(self.root/'cache.sqlite');db.execute('update cache set data=?',('{broken',));db.commit();db.close();out=self.runworker()
  self.assertEqual(out[3]['parsed'],1);self.assertEqual(out[3]['cache_hits'],0);self.assertEqual(len(out[1]),1)
 def test_invalid_root_cached_packet_is_discarded_and_reparsed(self):
  self.input();self.runworker();db=sqlite3.connect(self.root/'cache.sqlite');db.execute('update cache set data=?',('[]',));db.commit();db.close();out=self.runworker()
  self.assertEqual(out[3]['parsed'],1);self.assertEqual(out[3]['cache_hits'],0);self.assertEqual(len(out[1]),1)
 def test_cached_values_missing_required_columns_must_reparse(self):
  self.input();self.runworker();db=sqlite3.connect(self.root/'cache.sqlite');raw=db.execute('select data from cache').fetchone()[0];packet=json.loads(raw);packet['records'][0]['values']={};db.execute('update cache set data=?',(json.dumps(packet),));db.commit();db.close();out=self.runworker()
  self.assertEqual(out[3]['parsed'],1);self.assertEqual(out[3]['cache_hits'],0);self.assertEqual(out[1][0]['values']['start'],'09:00')
 def test_corrupt_sqlite_reports_fatal_without_source_or_employee_writes(self):
  self.input();cache=self.root/'cache.sqlite';cache.write_bytes(b'not SQLite');before=(self.folder/'attendance.csv').read_bytes();out=self.runworker()
  self.assertTrue(out[3]['fatal_error']);self.assertEqual(out[1],[]);self.assertEqual((self.folder/'attendance.csv').read_bytes(),before);self.unchanged()
 def test_cache_insert_failure_retains_parsed_source_and_diagnoses(self):
  self.input();real=engine.Cache
  class DBProxy:
   def __init__(self,db):self.db=db
   def execute(self,sql,args=()):
    if sql.startswith('INSERT'):raise sqlite3.OperationalError('injected disk full')
    return self.db.execute(sql,args)
   def __getattr__(self,name):return getattr(self.db,name)
  class BadCache(real):
   def __init__(self,path):super().__init__(path);self.db=DBProxy(self.db)
  with patch.object(main,'Cache',BadCache):out=self.runworker()
  self.assertEqual(len(out[1]),1);self.assertFalse(out[3]['file_errors']);self.assertIn('キャッシュ保存に失敗',out[3]['read_warnings'][0]['reason']);self.unchanged()
 def test_closing_running_worker_is_delayed_until_parser_exits(self):
  self.input();(self.folder/'placeholder.xlsx').write_bytes(b'not an xlsx, cancellation prevents absorption');entered=threading.Event();release=threading.Event();active=[0];real=main.parse_stable_file
  def delayed(*args):
   active[0]+=1;entered.set()
   try:self.assertTrue(release.wait(5));return real(*args)
   finally:active[0]-=1
  with patch.multiple(main,CONFIG=self.root/'settings.json',MAP=self.mp,DB=self.root/'cache.sqlite'),patch.object(main,'parse_stable_file',side_effect=delayed):
   save_json(self.cp,{**self.empty,'employee_information_registered':True});w=main.Window();w.cfg=copy.deepcopy(DEFAULT);w.path.setText(str(self.folder));w.year.setValue(2026);w.month.setValue(10);w.show();APP.processEvents()
   try:
    w.run_read();until(entered.is_set);worker=w.worker
    with patch.object(QMessageBox,'question',return_value=QMessageBox.No) as question:w.close();self.assertTrue(w.isVisible());self.assertFalse(worker.isInterruptionRequested());self.assertEqual(question.call_count,1)
    with patch.object(QMessageBox,'question',return_value=QMessageBox.Yes) as question:
     w.close();w.close();self.assertTrue(w.isVisible());self.assertTrue(worker.isInterruptionRequested());self.assertEqual(question.call_count,1)
    release.set();until(lambda:not worker.isRunning());until(lambda:not w.isVisible());self.assertEqual(active[0],0)
   finally:
    release.set()
    if w.worker and w.worker.isRunning():w.worker.cancel();w.worker.wait(6000)
    w.close();APP.processEvents()
 def test_stale_progress_result_and_finished_do_not_touch_current_window(self):
  class Emitter(QObject):
   progress=Signal(int,int,str);result=Signal(object,object,object,object);finished=Signal()
  with patch.multiple(main,CONFIG=self.root/'settings.json',MAP=self.mp,DB=self.root/'cache.sqlite'):
   w=main.Window();old=Emitter();current=Emitter();w.worker=current;w.run_button.setEnabled(False);w.full_button.setEnabled(False);w.stop_button.setEnabled(True)
   old.progress.connect(w.on_progress);old.result.connect(w.read_done);old.finished.connect(w.worker_finished)
   before=(w.status.text(),list(w.results),w.progress.value(),w.run_button.isEnabled(),w.full_button.isEnabled(),w.stop_button.isEnabled())
   old.progress.emit(1,1,'stale');old.result.emit({},[],[],{'fatal_error':'stale'});old.finished.emit();APP.processEvents()
   self.assertEqual((w.status.text(),w.results,w.progress.value(),w.run_button.isEnabled(),w.full_button.isEnabled(),w.stop_button.isEnabled()),before);w.worker=None;w.close()

if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Faults);result=unittest.TextTestRunner(verbosity=2).run(suite)
 summary={'source':str(SOURCE),'tests_run':result.testsRun,'passed':result.testsRun-len(result.failures)-len(result.errors),'failures':[(str(t),detail) for t,detail in result.failures],'errors':[(str(t),detail) for t,detail in result.errors]}
 Path(__file__).with_name('results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
 sys.exit(not result.wasSuccessful())
