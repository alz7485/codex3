import sys,copy,json,tempfile
from pathlib import Path
from unittest.mock import patch
root=Path('/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync');sys.path.insert(0,str(root))
from PySide6.QtWidgets import QApplication,QWidget
from PySide6.QtCore import QTimer
from engine import DEFAULT
from settings_dialog import SettingsDialog
from ui_theme import apply_theme
from outlook_mail import DEFAULT_MAIL_SETTINGS,show_mail_dialog
app=QApplication([]);parent=QWidget();parent.is_dark=False;apply_theme(app,False)
cfg=copy.deepcopy(DEFAULT);cfg['mail_settings']={**DEFAULT_MAIL_SETTINGS,'account':'operator@example.com','sender_name':'勤怠担当','always_cc':'support@example.com'}
d=SettingsDialog(parent,cfg);d.tabs.setCurrentIndex(3);d.show();app.processEvents()
d.grab().save(str(root/'Manual/images/17-mail-settings-top.png'));d.grab().save(str(Path(__file__).parent/'classic-outlook-settings.png'))
checks=[]
for dark in (False,True):
 apply_theme(app,dark);parent.is_dark=dark
 for width,height in ((1060,780),(780,580)):
  d.resize(width,height);app.processEvents();area=d.tabs.currentWidget()
  checks.append({'dark':dark,'width':width,'horizontal_scroll_max':area.horizontalScrollBar().maximum()});assert area.horizontalScrollBar().maximum()==0
apply_theme(app,False);parent.is_dark=False;d.resize(1060,780);app.processEvents();area=d.tabs.currentWidget();area.verticalScrollBar().setValue(area.verticalScrollBar().maximum());app.processEvents();d.grab().save(str(root/'Manual/images/18-mail-settings-body.png'));d.close()
plan={'employee':'10001','staff':'S001','name':'確認用 太郎','to':['employee10001@example.invalid'],'cc':['support@example.invalid'],'subject':'勤怠確認','body':'確認用 太郎殿\n\n派遣元：9:00\n派遣先：9:05','count':1,'problem':''}
def capture():
 dialog=app.activeModalWidget();app.processEvents();dialog.grab().save(str(root/'Manual/images/16-mail-preview.png'));dialog.reject()
with tempfile.TemporaryDirectory() as t:
 QTimer.singleShot(0,capture);show_mail_dialog(parent,[plan],cfg['mail_settings'],t)
Path(__file__).with_name('capture_check.json').write_text(json.dumps(checks,indent=2));parent.close();app.processEvents();print('Settings/preview screenshots and four layout checks OK; no COM/Graph calls')
