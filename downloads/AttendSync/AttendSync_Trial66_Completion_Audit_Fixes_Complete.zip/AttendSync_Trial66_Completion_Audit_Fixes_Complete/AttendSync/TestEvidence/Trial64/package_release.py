from pathlib import Path
import json,shutil,hashlib,zipfile
base=Path('/workspace/attendsync-audit');full=base/'AttendSync_Trial64_Classic_Outlook_COM_Complete';app=full/'AttendSync';out=base/'trial64-validation';dest=Path('/workspace/codex3/downloads/AttendSync')
results=json.loads((out/'existing_results.json').read_text());assert len(results)==51 and all(r['returncode']==0 for r in results)
changes='''# Trial64 クラシックOutlookのCOM連携へ切替

前版はアカウント取得のみCOM、メール作成・送信はMicrosoft Graph経由でした。本版はメール作成・送信もCOM経由とし、MicrosoftアプリID・テナントID・アプリ登録・ブラウザでのサインインを不要にしました。

1. クラシックOutlookを起動します。
2. 「設定」→「メール」→「起動中のOutlookから取得」で送信元・表示名を入力します。複数アカウントは選択し「設定を保存」で確定します。
3. 勤怠照合後の「メールを作成」で社員ごとの宛先・CC・本文・対象を確認します。
4. 自動送信OFF（初期値）なら、選択したアカウントの下書きフォルダへ保存します。ONなら、下書き保存後に同じアカウントでOutlookへ送信を要求します。作成画面のON/OFF切替も維持します。

送信元をOutlookで一意に確認できない場合は中止し、既定の別アカウントへ切り替えて送信しません。宛先をOutlookで解決できない場合も送信しません。

処理履歴とOSロックで同内容の再作成・再送信を防止します。結果不明の送信は自動再試行せず、以降の社員は未処理として止めます。旧Graph版の送信元・アプリID等の履歴用設定が残っている場合は、その履歴も確認して重複を防ぎます。旧設定は移行のため保持しますが、COMの認証や送信には使用しません。

「送信要求済み」はOutlookへの要求完了で、配達完了ではありません。オフラインでは送信トレイに残る場合があります。Outlookの確認画面が出た場合は内容を確認してください。

設定画面のアプリID・テナントID欄を削除し、依存関係とビルドからmsalを外しました。18ページ図解とOutlook連携ガイドを更新しています。新しいOutlookは本版の対象外です。Windows向けのPythonソース版でEXEは同梱していません。
'''
validation='''# Trial64 検証結果

全51テストスクリプトが成功しました。前版の50本（メール実行画面の期待動作をCOMへ更新）に、新規17テストを追加しました。

- 指定アカウントの下書きフォルダ・SendUsingAccountの固定、To/CC、件名・本文、下書きのみと保存→送信要求の順序。
- 空のアプリIDでも処理でき、未使用の旧ID値を変更しても同内容の重複を防ぐこと。
- 不明/重複送信元、送信元設定拒否、保存時の送信元変化、宛先解決失敗で送信しないこと。
- 下書き保存障害・曖昧な送信失敗・送信後の履歴書込障害、履歴の偽値/不正構造、OSロック、旧Graph履歴からの移行重複防止。
- 実Qtのメール作成画面からCOM処理用ワーカーを呼び、今回の自動送信設定を引き継ぐこと（処理関数は代替）。
- アカウント取得・選択・設定保存・未知JSON保持、勤怠CSV/XLSX・欠月表示・社員情報・集計・印刷など既存試験。
- ライト/ダークと通常/最小幅の4条件でメール設定に横スクロールが不要なこと、18ページの図解・画像とローカルリンク。
- 必要ファイル版と完全版で実行用ソースの内容が同じこと（必要版は未使用の旧Graph実装を除外）。ZIP CRCと全ファイルSHA256。

環境: Linux / Python3.12 / PySide6 / Qt offscreen。Outlookは合成COMオブジェクト、旧Graphは代替APIで試験しました。Windows実機でのOutlook接続・実送信・EXEビルドは未検証です。実メールは送信していません。
'''
for name,content in [('CHANGES_TRIAL64.md',changes),('VALIDATION_TRIAL64.md',validation)]:
 (app/name).write_text(content);(dest/name).write_text(content)
p=app/'README.md';p.write_text('''# 勤怠チェッカー Trial64

メール作成・送信をクラシックOutlookのCOM経由へ切り替えました。MicrosoftアプリID・テナントID・アプリ登録・ブラウザ認証は不要です。

Outlookを開き「設定」→「メール」→「起動中のOutlookから取得」で送信元を設定します。自動送信OFFはそのアカウントの下書き保存、ONはOutlookへ送信要求。送信元が不明なら中止し、同内容や結果不明のメールを自動再送しません。

全51スクリプト成功。CHANGES_TRIAL64.md / VALIDATION_TRIAL64.mdを参照。図解：Manual/index.html、接続：Manual/Outlook連携ガイド.html。Windows実機の接続・実送信・EXEビルドは未検証。Windows向けソース版です。

以下は過去版の説明です。旧版のMicrosoftアプリ登録の手順は本版には不要です。

'''+p.read_text())
(full/'CODEX_START_HERE.txt').write_text('最新版Trial64。メール作成/送信をクラシックOutlook COMへ切替。アプリID/テナントID/ブラウザ認証不要。指定アカウントDraftsとSendUsingAccount、曖昧な結果の再送防止を確認。全51スクリプト成功。CHANGES_TRIAL64.md / VALIDATION_TRIAL64.md / TestEvidence/Trial64参照。次版Trial65。\n派遣元CSVの勤怠読込は未実装で社員情報CSVとは別。\n')
(full/'CODEX_NEXT_TASKS.txt').write_text('次版Trial65。Windows実機のクラシックOutlook COM接続・下書き・送信元指定の確認とEXEビルドが未検証。MicrosoftアプリIDは不要。送信の不明結果は再試行しない。送信要求は配達完了ではない。\n')
with (full/'CODEX_HANDOFF_SPEC.txt').open('a') as f:f.write('\n\n【Trial64：現在の追加仕様】\n'+changes+'\n'+validation)
evidence=app/'TestEvidence/Trial64';evidence.mkdir(exist_ok=True)
for p in out.iterdir():
 if p.is_file() and p.suffix in ('.log','.json','.py','.png'):shutil.copy2(p,evidence/p.name)
shutil.copy2(out/'classic-outlook-settings.png',dest/'Trial64_Classic_Outlook_Settings.png');shutil.copy2(app/'Manual/操作マニュアル.pdf',dest/'AttendSync_Trial64_図解操作ガイド.pdf')
for p in full.rglob('__pycache__'):shutil.rmtree(p)
assert not list(full.rglob('userdata'))
essential=base/'AttendSync_Trial64_Essentials';runtime=essential/'AttendSync';runtime.mkdir(parents=True)
for p in app.glob('*.py'):
 if not p.name.startswith(('test_','benchmark_')) and p.name!='microsoft_mail.py':shutil.copy2(p,runtime/p.name)
for p in app.glob('requirements*.txt'):shutil.copy2(p,runtime/p.name)
shutil.copy2(app/'AttendSync.ico',runtime/'AttendSync.ico');shutil.copytree(app/'Manual',runtime/'Manual')
(runtime/'README.md').write_text('''# 勤怠チェッカー Trial64 必要ファイル版

Windows11 / Python3.11推奨のソース版。実行・ビルド用Python、アイコン、18ページ図解です。EXE・実データ・監査・テスト・サンプル・未使用の旧Graph実装は含みません。

PowerShellでこのフォルダから実行します。

```powershell
py -3.11 -m venv .venv
.\\.venv\\Scripts\\python.exe -m pip install -r requirements-build.txt
.\\.venv\\Scripts\\python.exe main.py
.\\.venv\\Scripts\\python.exe build_onedir.py
```

配布はdist\\AttendSync全体。旧userdataはバックアップ後に引き継いでください。

最初に「社員情報」で社員CSVを選択・ドロップし「一覧に反映」→「社員情報を登録」。初期列はスタッフID=A、社員ID=B、氏名=C、メール=J。その後メインで勤怠を読み込みます。

メールはWindowsのクラシックOutlookをCOMで操作します。MicrosoftアプリID・テナントID・アプリ登録・ブラウザ認証は不要です。Outlookを起動して「設定」→「メール」→「起動中のOutlookから取得」。複数アカウントは選択し「設定を保存」で確定します。

メール作成画面で宛先と内容を確認し実行します。自動送信OFF（初期値）は指定アカウントの下書きフォルダへ保存。ONはOutlookへ送信要求。送信元不明時は中止し、結果不明時も自動再送しません。「送信要求済み」は配達完了ではなく、オフライン時には送信トレイに残ることがあります。

図解：Manual/index.html。接続：Manual/Outlook連携ガイド.html。全51スクリプト成功。Windows実機でのOutlook接続・実送信・EXEビルドは未検証です。
''')
for p in runtime.glob('*.py'):assert p.read_bytes()==(app/p.name).read_bytes()
checks=[]
for root in (full,essential):
 manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and p.name!='MANIFEST_SHA256.json'}
 (root/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));path=dest/(root.name+'.zip')
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,root.name+'/'+p.relative_to(root).as_posix())
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for name,digest in manifest.items():assert hashlib.sha256(z.read(root.name+'/'+name)).hexdigest()==digest
 sha=hashlib.sha256(path.read_bytes()).hexdigest();path.with_suffix('.zip.sha256').write_text(sha+'  '+path.name+'\n');checks.append(dict(file=path.name,bytes=path.stat().st_size,sha256=sha,crc='OK',manifest='OK'))
(out/'package_check.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
p=dest/'README.md';p.write_text('''# 勤怠チェッカー Trial64 — クラシックOutlook COM連携

- [必要ファイル版ZIP](https://github.com/alz7485/codex3/raw/refs/heads/main/downloads/AttendSync/AttendSync_Trial64_Essentials.zip)
- [完全版ZIP](https://github.com/alz7485/codex3/raw/refs/heads/main/downloads/AttendSync/AttendSync_Trial64_Classic_Outlook_COM_Complete.zip)
- [メール設定の画面](Trial64_Classic_Outlook_Settings.png) / [変更内容](CHANGES_TRIAL64.md) / [検証](VALIDATION_TRIAL64.md) / [図解18ページ](AttendSync_Trial64_図解操作ガイド.pdf)
- [社員登録サンプルCSV](AttendSync_Employee_Registration_Sample.csv) / [説明付きZIP](AttendSync_Employee_Registration_Sample.zip)

アカウント取得だけでなくメール作成・送信もCOMに切替。MicrosoftアプリID・テナントID・アプリ登録・ブラウザ認証は不要です。自動送信OFFは指定アカウントの下書き、ONはOutlookへ送信要求。全51本成功。Windows実機の接続・実送信・EXEビルドは未検証です。ソース版でEXEは未同梱。

以下は過去版の説明です。旧版のMicrosoftアプリ登録は本版には不要です。

'''+p.read_text())
