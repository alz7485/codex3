from pathlib import Path
import json,html
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.utils import ImageReader
ROOT=Path('/workspace/attendsync-audit/AttendSync_Trial64_Classic_Outlook_COM_Complete/AttendSync/Manual')
# One page per view. Only XLSX settings use two pages.
pages=[
('01-main','メイン画面：読み込む','毎月の作業は、ここから始めます。',[(.90,.11,'フォルダを選ぶ','派遣元XLSXと派遣先CSVを同じフォルダに入れ、選択します。画面へのドロップでも指定できます。'),(.17,.16,'対象月度を確認','年月と対象期間を確認します。起動時はPCの日付の月度です。'),(.91,.16,'読み込み・照合','クリックして開始。やり直すときは「完全再読み込み」、止めるときは「中止」です。')]),
('02-results','メイン画面：結果を見る','不一致と要確認を確認してから、作業を終えます。',[(.48,.24,'件数を確認','対象社員・一致・不一致・要確認と、全数の内訳を確認します。未照合が残っていないかも見ます。'),(.14,.41,'絞り込む','「不一致のみ」「一致のみ」「すべて」を切り替えます。社員番号・氏名で検索できます。'),(.48,.50,'行を開く','ダブルクリックで詳細。右クリックから元Excelへ移動できます。印刷は表示中の一覧が対象です。')]),
('03-id','社員ID管理','社員番号とスタッフIDを対応させます。',[(.39,.25,'社員を確認','未紐付けの社員を確認します。同姓同名は自動で確定しません。'),(.75,.30,'スタッフIDを選ぶ','候補から選択、または直接入力。社員番号と本人の所属を確認します。'),(.84,.95,'紐付けを保存','同じ社員番号・スタッフIDを重複させず保存。保存後は再読み込みして結果を確認します。')]),
('04-detail','全項目の対比表','1人・1日の記録を並べて確認します。',[(.45,.23,'元の値を見る','派遣元XLSXと派遣先CSVの値を横に並べて確認します。'),(.84,.38,'判定を見る','不一致・要確認の項目を確認。空欄や入力形式にも注意します。'),(.66,.94,'Excel・印刷へ','元Excelで記録を確認できます。詳細の印刷・プレビューは表示項目を使います。')]),
('05-xlsx','設定：派遣元XLSX（1/2）','速度・行範囲・セルと列を設定します。',[(.20,.26,'読み込み速度','通常は4。不安定な共有フォルダでは1〜2に下げます。'),(.26,.39,'開始行・終了行','日別データの範囲を指定。見出しは含めません。'),(.51,.67,'セル・列を指定','社員番号などはセル（例：N1）、日別項目は列（例：G）。「設定を保存」で確定します。')]),
('06-xlsx-month','設定：派遣元XLSX（2/2）','下へスクロールして月度のシート名を確認します。',[(.50,.37,'日別データの列','帳票に合わせて列を指定。追加・改名・削除のボタンで項目を管理できます。'),(.49,.73,'月度ごとのシート名','1〜12月度の実際のシート名を入力。10月度は9/16〜10/15です。'),(.90,.95,'設定を保存','変更後は再読み込みして、対象期間と結果を確認します。')]),
('07-csv','設定：派遣先CSV','CSVの列とデータ開始行を合わせます。',[(.46,.34,'列記号を設定','日付・スタッフID・氏名・時刻などの列を実CSVに合わせます。'),(.21,.68,'開始行・文字コード','見出しが1行なら開始行は2。文字化けする場合は文字コードを確認します。'),(.89,.95,'設定を保存','CSVは対象期間を含むものを用意。必要な月のファイルが揃っているか確認します。')]),
('08-compare','設定：照合項目','どの項目を、どの方法で比較するかを決めます。',[(.15,.31,'照合をON/OFF','比較したい項目だけ有効にします。詳細画面の表示選択とは別です。'),(.51,.40,'比較元と形式を選ぶ','XLSX列とCSV列を組み合わせます。時刻・時間・文字列・数値の用途を合わせます。'),(.89,.95,'保存して再読み込み','休憩などを追加すると照合対象数も変わります。結果の全数を確認します。')]),
('09-codes','設定：勤怠区分の名称','区分コードの表示名を合わせます。',[(.26,.30,'区分コードを見る','帳票で使っているコードを確認します。'),(.66,.42,'表示名を入力','出勤・休暇など、実際の運用に合わせた名称を入力します。'),(.89,.95,'設定を保存','表記を保存して再読み込み。未知のコードがないか結果を確認します。')]),
('10-detail-settings','設定：詳細に表示する項目','詳細画面と詳細印刷の表示を選びます。',[(.36,.30,'チェックで表示選択','必要な項目をチェック。非表示にしても、その項目の照合ON/OFFは変わりません。'),(.23,.55,'まとめて切り替える','「すべて表示」「すべて非表示」で一括変更できます。'),(.89,.95,'設定を保存','詳細画面を開き直して確認します。通常は下の互換設定・JSONを開く必要はありません。')]),
('11-json','設定：詳細JSON','通常の入力欄で足りない設定だけ編集します。',[(.50,.66,'変更前にコピー','編集前のJSONを控えておきます。通常の列変更は入力欄で行えます。'),(.13,.84,'入力欄に反映','JSONを変更したら「JSONを入力欄に反映」を押します。エラーが出たら保存せず戻します。'),(.89,.95,'設定を保存','入力欄の内容を確認して保存。テーマ変更は保存後すぐ反映します。')]),
('12-diagnostics','読み込み診断','読み込めないファイルや注意事項を確認します。',[(.25,.20,'分類を切り替える','「読み込み失敗」「読み込み注意」「その他のログ」を切り替えます。'),(.48,.44,'ファイルと理由を見る','問題のファイルを修正して再読み込み。キャッシュ保存の注意と元ファイルの失敗は区別します。'),(.88,.13,'診断を保存','問い合わせるときは診断テキストを保存します。結果と一緒に確認できます。')]),
('13-logs','ログ一覧','操作と処理の履歴を確認します。',[(.43,.35,'履歴を見る','メイン画面は最新1行。ここでは全体を確認できます。'),(.67,.95,'コピー・保存','「すべてコピー」「テキスト保存」で内容を取り出します。'),(.94,.95,'閉じる','確認後はメイン画面に戻り、修正や再読み込みを行います。')]),
('14-print','印刷プレビュー','表示中の内容を確認してから印刷します。',[(.43,.08,'ページを操作','上のツールで拡大・ページ移動・印刷設定を操作します。'),(.48,.44,'印刷内容を見る','一覧は絞り込み中の行だけが対象。社員名・日付・値を確認します。'),(.87,.08,'印刷またはPDF保存','印刷画面でプリンターを選びます。PDF保存はPDF対応プリンターを選択します。')]),
]
pages[2]=('03-id','社員ID対応','社員番号とスタッフIDを対応付けます。',[(.64,.36,'スタッフIDを選択','候補を選ぶか直接入力します。同じ社員番号・スタッフIDを重複させないよう確認します。'),(.89,.95,'紐付けを保存','IDを変更したら先に保存します。保存後は勤怠の照合結果も再確認します。'),(.18,.17,'メール管理へ','メールアドレスの取込と編集は「メール管理」タブで行います。')])
pages.insert(3,('03b-email-management','メール管理','CSV取込・未紐付けの確認・メール保存をここで行います。',[(.89,.24,'メールCSVを取り込む','列記号を指定して取込。保存済みの社員IDとスタッフIDが両方一致する行だけ自動で紐付けます。'),(.68,.51,'候補選択・直接入力','未紐付け候補をプルダウンから選択、またはメールを直接入力。検索と「未紐付けのみ」で対象を探せます。'),(.81,.95,'メールを保存','メールの変更を保存。CSVのIDと異なる候補を選んだ場合は割当先を確認します。')]))
pages.insert(4,('15-email-import','メールCSV取込','見出し名に依存せず、列記号で指定します。',[(.17,.33,'CSVと4列を指定','社員ID・スタッフID・名前・メールの列をA、B…で指定。見出し1行なら開始行は2です。'),(.89,.41,'照合して確認','両ID一致のみ自動紐付け。ID重複・空欄・不一致を確認し、名前だけでは照合しません。'),(.91,.96,'取込結果を保存','自動紐付けと有効な未紐付け候補を保存。戻った画面で未紐付けを選択・直接入力できます。')]))
pages.insert(2,('16-mail-preview','メールを作成','表示中の不一致を社員ごとにまとめて確認します。',[(.035,.25,'対象社員を選ぶ','チェックのある社員が処理対象です。メール未登録は社員ID管理で登録してください。'),(.69,.31,'宛先・CC・本文を確認','社員ごとの宛先と不一致だけを表示します。必須のTo/CCと文面は設定のメールタブで変更できます。'),(.88,.95,'下書き保存または送信','自動送信OFFなら下書き保存、ONなら選択した社員へ送信します。初回は設定したMicrosoftアカウントへブラウザでサインインします。')]))
pages.insert(13,('17-mail-settings-top','設定：メール（1/2）','Microsoft 365接続と宛先を設定します。',[(.24,.25,'自動送信を切り替える','OFFは下書き保存。ONはメール作成画面で実行すると送信します。読み込みだけでメールは送信されません。'),(.50,.40,'Microsoftアカウント接続','送信アカウント・アプリID・テナントIDを入力。初回登録はMicrosoft連携ガイドの手順で行います。'),(.53,.72,'必須To/CC・名前','全メールに入れるTo/CC、本文中の差出人名と宛名の敬称を設定します。複数のメールは ; 区切りで指定します。')]))
pages.insert(14,('18-mail-settings-body','設定：メール（2/2）','件名・本文・署名を編集します。',[(.49,.24,'件名を設定','{name}や{year}、{month}を差し込みできます。社員ごとの氏名・対象月度へ置き換わります。'),(.49,.49,'本文と不一致内容','{differences}を入れた位置へ、対象社員の不一致だけを貼り付けます。{recipient_name}は氏名と敬称です。'),(.48,.77,'署名・保存','署名を入力し、本文に{signature}を配置。「設定を保存」で確定すると次のメール作成から反映します。')]))
pages=[p for p in pages if p[0]!='03b-email-management']
replacements={
'03-id':('03-id','社員情報','社員ID・スタッフID・メールアドレスを同じ一覧で管理します。',[(.89,.16,'社員情報を読み込む','用途を選び、列を指定してCSVを読み込みます。検索と未紐付けの絞り込みで対象を探せます。'),(.66,.37,'IDとメールを編集','スタッフIDとメールは候補から選ぶか直接入力。IDが変わった行はメールの割当先も確認します。'),(.92,.95,'まとめて保存','「紐付けを保存」でIDとメールを同時に保存。キャンセルなら取込・編集を破棄します。')]),
'15-email-import':('15-email-import','社員情報：紐付け用CSV','社員ID・スタッフID・名前・メールをまとめて取り込みます。',[(.49,.12,'紐付け用CSVを選ぶ','スタッフIDはA列、社員ID（派遣元スタッフコード）はB列、氏名はC列、メールはJ列です。変更済みの列設定は保持します。'),(.90,.38,'照合して確認','両IDの組を確認して新しい対応を作ります。既存IDとの衝突や重複は自動で上書きしません。'),(.92,.95,'一覧に反映','ここでは仮の変更です。戻った一覧で未紐付けを確認し「紐付けを保存」で確定します。')]),
'16-mail-preview':('16-mail-preview','メールを作成','表示中の不一致を社員ごとにまとめて確認します。',[(.035,.25,'対象社員を選ぶ','チェックのある社員が対象です。メール未登録の社員は「社員情報」で登録してください。'),(.69,.31,'宛先・CC・本文を確認','対象社員の不一致を確認。必須To/CCと文面は設定のメールタブで変更できます。'),(.50,.16,'今回の自動送信を切り替える','OFFは下書き保存、ONは送信です。この画面の切替は今回だけで、設定の初期値は変えません。確認後に下の実行ボタンを押します。')]),
}
pages=[replacements.get(p[0],p) for p in pages]
idx=next(i for i,p in enumerate(pages) if p[0]=='15-email-import')
pages.insert(idx+1,('15b-attendance-information','社員情報：勤怠用CSV','勤怠照合に使うCSVから、IDだけを紐付けます。',[(.49,.12,'勤怠用CSVを選ぶ','スタッフIDと名前の列を指定。社員ID列がある場合だけ、その列も指定します。メールは変更しません。'),(.90,.38,'照合して確認','日別の同じIDは1件にまとめます。社員ID列がなければ候補へ追加し、名前だけで自動確定しません。'),(.92,.95,'一覧で対応を確認','一覧へ反映し、未紐付けのスタッフIDを候補から選ぶか直接入力。「紐付けを保存」で確定します。')]))
final_pages={
'03-id':('03-id','社員情報','IDとメールを同じ一覧で管理します。',[(.44,.52,'CSVをドロップ','この画面へCSVをドロップすると、読込画面で自動確認します。「社員情報を読み込む」からファイル選択もできます。'),(.66,.37,'IDとメールを編集','候補から選ぶか直接入力。検索とID未紐付け／メール未紐付けで対象を絞り込めます。'),(.92,.95,'まとめて保存','「紐付けを保存」で確定。キャンセルなら、取込と編集を破棄します。')]),
'15-email-import':('15-email-import','社員情報：紐付け用CSV','CSVをドロップし、IDとメールを確認します。',[(.46,.15,'CSVをドロップ','初期列はスタッフID=A、社員ID（派遣元スタッフコード）=B、氏名=C、メール=J。保存済みの列指定は保持します。'),(.52,.67,'確認一覧をダブルクリック','元CSVをExcelで開き、選んだ行と列へ移動します。CSVが更新されていたら再読込してください。'),(.92,.95,'一覧に反映して保存','確認後は「一覧に反映」。戻った社員情報で「紐付けを保存」すると確定します。')]),
'15b-attendance-information':('15b-attendance-information','社員情報：勤怠用CSV','勤怠用CSVから、IDだけを紐付けます。',[(.31,.30,'勤怠用CSVを選ぶ','スタッフIDと氏名の列を指定。社員ID列がなければ空欄にします。メールは変更しません。'),(.52,.67,'CSVと候補を確認','用途を選んでからCSVをドロップ。行をダブルクリックすると元CSVへ移動します。社員IDなしは候補から手動で紐付けます。'),(.92,.95,'一覧に反映して保存','一覧に反映し、IDの対応を確認。「紐付けを保存」で確定します。')]),
}
pages=[final_pages.get(p[0],p) for p in pages]
pages=[p for p in pages if p[0]!='15b-attendance-information']
registration_pages={
'03-id':('03-id','最初に社員情報を登録','勤怠を読む前に、社員ID・スタッフID・メールを登録します。',[(.44,.52,'社員情報CSVをドロップ','CSVをドロップするか「社員情報を読み込む」を押します。勤怠データからIDの紐付けは行いません。'),(.66,.37,'社員情報を確認','氏名・ID・メールを確認。未紐付けのIDやメールは候補選択または直接入力で修正します。'),(.92,.95,'社員情報を登録','このボタンで確定。登録後にメイン画面から勤怠を読み込みます。キャンセルなら仮の取込を破棄します。')]),
'15-email-import':('15-email-import','社員情報CSVを読み込む','ドラッグまたはCSV選択だけで、自動的に一覧を表示します。',[(.46,.15,'CSVをドロップ・選択','スタッフID=A、社員ID（派遣元スタッフコード）=B、氏名=C、メール=J。保存済みの列指定は保持します。'),(.52,.56,'列と内容を確認','列や文字コードを変更すると自動で読み直します。行をダブルクリックすると元CSVの対応セルをExcelで開きます。'),(.92,.95,'一覧に反映して登録','「一覧に反映」で社員情報画面へ戻り「社員情報を登録」で確定。登録済み社員情報を使って勤怠をチェックします。')]),
'01-main':('01-main','勤怠を読み込む','社員情報を登録してから、毎月の勤怠を読み込みます。',[(.90,.11,'勤怠フォルダを選ぶ','派遣元XLSXと派遣先CSVのフォルダを指定します。社員情報CSVは社員情報画面で登録します。'),(.17,.16,'対象月度を確認','年月と対象期間を確認。起動時はPCの日付の月度です。'),(.91,.16,'読み込み・照合','社員情報がない場合は「勤怠チェックを行う前に社員情報を登録してください」と表示し、社員情報画面を開きます。')]),
}
pages=[registration_pages.get(p[0],p) for p in pages]
first_ids=['03-id','15-email-import'];pages=[next(p for p in pages if p[0]==key) for key in first_ids]+[p for p in pages if p[0] not in first_ids]
pages=[('02-results','勤怠の結果を見る','CSVのない月度分を非表示にして、不一致を確認できます。',[(.48,.24,'全体の件数を見る','全数と要確認の件数は元の結果です。チェックボックスは一覧の表示だけを切り替えます。'),(.40,.44,'CSVのない月度分を非表示','初期状態はON。前月CSVがなければ前月の「CSV記録なし」を隠します。OFFにすると再読込なしで戻せます。同じ月の個人別欠落は残します。'),(.48,.62,'不一致を確認する','ダブルクリックで詳細。印刷は表示中の一覧が対象です。下の表示件数にはCSVなしで非表示にした件数と年月も表示します。')]) if p[0]=='02-results' else p for p in pages]
pages=[('17-mail-settings-top','設定：メール（1/2）','クラシックOutlookからアカウントを取得できます。',[(.29,.40,'Outlookから取得','WindowsでクラシックOutlookを開き「起動中のOutlookから取得」。複数のアカウントがあれば選択し、メールアドレスと表示名を反映します。'),(.51,.47,'接続・送信モードを確認','MicrosoftアプリID・テナントIDは別に設定します。下書き・送信はMicrosoft Graph経由で、初回サインインが必要です。自動送信の初期値はOFFです。'),(.53,.74,'宛先と名前を保存','必須To/CCと本文用の差出人名、敬称を確認。「設定を保存」で確定。取得だけでメール作成・送信はしません。')]) if p[0]=='17-mail-settings-top' else p for p in pages]
pages=[('17-mail-settings-top','設定：メール（1/2）','クラシックOutlookを開いて、送信元を設定します。',[(.28,.37,'送信元を取得','「起動中のOutlookから取得」でアドレス・表示名を反映。複数アカウントがあれば選びます。アプリID・テナントID・ブラウザ認証は不要です。'),(.25,.25,'送信モードを選ぶ','初期OFFは下書き保存。ONはメール作成画面から実行するとOutlookへ送信を要求します。読み込みだけで送信されません。'),(.52,.65,'宛先と名前を保存','必須To/CC・差出人名・敬称を確認し「設定を保存」。指定した送信元を確認できない場合は処理を中止します。')]) if p[0]=='17-mail-settings-top' else p for p in pages]
(ROOT/'guide_pages.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
W,H=A4;c=canvas.Canvas(str(ROOT/'操作マニュアル.pdf'),pagesize=A4);c.setTitle('勤怠チェッカー 画面でわかる操作ガイド');c.setAuthor('勤怠チェッカー')
def wrap(text,width,size):
 out=[];line=''
 for ch in text:
  if pdfmetrics.stringWidth(line+ch,'HeiseiKakuGo-W5',size)>width:out.append(line);line=ch
  else:line+=ch
 if line:out.append(line)
 return out
sections=[]
for idx,(image,title,subtitle,notes) in enumerate(pages,1):
 c.bookmarkPage(image);c.addOutlineEntry(title,image,0)
 c.setFillColorRGB(.12,.18,.27);c.setFont('HeiseiKakuGo-W5',20);c.drawString(30,H-45,title)
 c.setFont('HeiseiKakuGo-W5',11);c.drawString(30,H-69,subtitle)
 path=ROOT/'images'/f'{image}.png';reader=ImageReader(str(path));iw,ih=reader.getSize();scale=min((W-60)/iw,420/ih);sw,sh=iw*scale,ih*scale;left=(W-sw)/2;bottom=H-92-sh
 c.drawImage(reader,left,bottom,width=sw,height=sh)
 for n,(x,y,label,description) in enumerate(notes,1):
  px,py=left+x*sw,bottom+(1-y)*sh
  c.setFillColorRGB(.15,.28,.53);c.circle(px,py,10,fill=1,stroke=0);c.setFillColorRGB(1,1,1);c.setFont('Helvetica-Bold',11);c.drawCentredString(px,py-4,str(n))
 y=bottom-31
 for n,(_,_,label,description) in enumerate(notes,1):
  c.setFillColorRGB(.12,.18,.27);c.setFont('HeiseiKakuGo-W5',13);c.drawString(32,y,f'{n}  {label}');y-=21;c.setFont('HeiseiKakuGo-W5',11)
  for line in wrap(description,W-80,11):c.drawString(48,y,line);y-=17
  y-=12
 assert y>45,(title,y)
 c.setFillColorRGB(.4,.44,.5);c.setFont('HeiseiKakuGo-W5',8);c.drawString(30,24,'勤怠チェッカー Trial61 ｜ 確認用データによる画面例');c.drawRightString(W-30,24,f'{idx} / {len(pages)}');c.showPage()
 pins=''.join(f'<span class="pin" style="left:{x*100}%;top:{y*100}%">{n}</span>' for n,(x,y,_,_) in enumerate(notes,1))
 tips=''.join(f'<li><strong>{html.escape(label)}</strong><p>{html.escape(desc)}</p></li>' for _,_,label,desc in notes)
 sections.append(f'<section id="{image}"><h2>{html.escape(title)}</h2><p class="lead">{html.escape(subtitle)}</p><figure><a href="images/{image}.png" target="_blank"><img src="images/{image}.png" alt="{html.escape(title)}の実画面"></a>{pins}</figure><ol>{tips}</ol><footer>{idx} / {len(pages)} · Trial64の実画面・確認用データ</footer></section>')
c.save()
nav=''.join(f'<a href="#{p[0]}">{html.escape(p[1])}</a>' for p in pages)
(ROOT/'index.html').write_text('''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>勤怠チェッカー 操作ガイド</title><style>
*{box-sizing:border-box}body{margin:0;color:#202b3b;background:#f3f5f8;font-family:system-ui,sans-serif;line-height:1.6}header,main{max-width:1000px;margin:auto;padding:24px}h1{font-size:28px}nav{display:flex;flex-wrap:wrap;gap:8px}a{color:#244a80}nav a,.pdf{padding:7px 12px;background:white;border:1px solid #cbd4df;border-radius:5px;text-decoration:none}section{background:white;padding:24px;margin-bottom:24px;border:1px solid #d5dce5;border-radius:8px;scroll-margin:16px}h2{font-size:23px;margin:0 0 8px}.lead{margin-top:0}figure{position:relative;margin:18px 0}img{display:block;width:100%;height:auto}.pin{position:absolute;transform:translate(-50%,-50%);border-radius:50%;width:28px;height:28px;background:#264880;color:white;text-align:center;line-height:28px;font-weight:700;border:2px solid white;pointer-events:none}ol{padding-left:26px}li{padding-left:5px;margin-bottom:14px}li p{margin:3px 0}footer{color:#6a7482;font-size:12px;border-top:1px solid #ddd;padding-top:12px}@media(max-width:600px){header,main{padding:12px}section{padding:14px}.pin{width:22px;height:22px;line-height:18px;font-size:12px}h2{font-size:20px}}@media print{header{display:none}main{padding:0}section{break-after:page;border:0;margin:0;padding:0}a{color:inherit}}
</style><header><h1>勤怠チェッカー 操作ガイド</h1><p>画面の番号と説明を順に見るだけで操作できます。図をクリックすると拡大表示します。</p><p><a class="pdf" href="操作マニュアル.pdf">PDFで読む（18ページ）</a></p><p><a class="pdf" href="Outlook連携ガイド.html">初回のMicrosoft連携設定</a></p><nav>'''+nav+'</nav></header><main>'+''.join(sections)+'</main></html>')
print('Generated 18-page illustrated PDF and offline HTML')
