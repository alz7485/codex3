"""Column-based contact CSV import. Match the saved employee/staff pair only."""
import csv, io, re
from pathlib import Path
from collections import Counter
from openpyxl.utils.cell import column_index_from_string
from engine import load_json, save_json
DEFAULT_COLUMNS={'employee':'A','staff':'B','name':'C','email':'D'}

def load_contacts(path):
    return validate_contacts(load_json(path,{'version':1,'contacts':[],'import_settings':{}}))

def validate_contacts(value):
    if not isinstance(value,dict) or value.get('version')!=1 or not isinstance(value.get('contacts'),list) or not isinstance(value.get('import_settings',{}),dict):
        raise ValueError('メール対応ファイルの形式が不正です。バックアップを確認してください。')
    if not isinstance(value.get('unlinked_contacts',[]),list):raise ValueError('未紐付けメールの形式が不正です。')
    for candidate in value.get('unlinked_contacts',[]):
        if not isinstance(candidate,dict) or not all(isinstance(candidate.get(k),str) for k in DEFAULT_COLUMNS):raise ValueError('未紐付けメールの形式が不正です。')
    seen=set()
    for item in value['contacts']:
        if not isinstance(item,dict) or not all(isinstance(item.get(k),str) for k in ('employee','staff','name','email')):
            raise ValueError('メール対応データの形式が不正です。')
        pair=(item['employee'],item['staff'])
        if pair in seen:raise ValueError('メール対応データのIDが重複しています。')
        seen.add(pair)
    return value

def email_for(data,employee,staff):
    return next((r['email'] for r in data['contacts'] if r['employee']==employee and r['staff']==staff),'')

def read_contact_csv(path,columns,first_row=2,encoding='auto'):
    indices={k:column_index_from_string(str(columns[k]).strip().upper())-1 for k in DEFAULT_COLUMNS}
    if any(v<0 or v>=16384 for v in indices.values()) or len(set(indices.values()))!=4:
        raise ValueError('4項目に異なる有効な列記号を指定してください。')
    if isinstance(first_row,bool) or not isinstance(first_row,int) or first_row<1:raise ValueError('開始行は1以上の整数で指定してください。')
    raw=Path(path).read_bytes()
    if encoding=='auto':
        for candidate in ('utf-8-sig','cp932'):
            try:text=raw.decode(candidate);break
            except UnicodeDecodeError:continue
        else:raise ValueError('CSVの文字コードを判定できません。UTF-8またはCP932で保存してください。')
    else:text=raw.decode(encoding)
    rows=[]
    for n,row in enumerate(csv.reader(io.StringIO(text,newline='')),1):
        if n<first_row or not any(cell.strip() for cell in row):continue
        values={k:row[i].strip() if i<len(row) else '' for k,i in indices.items()}
        rows.append(dict(values,line=n))
    return rows

def match_contacts(rows,mapping):
    employees=Counter(r['employee'] for r in rows if r['employee'])
    staff=Counter(r['staff'] for r in rows if r['staff'])
    saved_staff=Counter(str(v).strip() for v in mapping.values() if str(v).strip())
    results=[]
    for r in rows:
        item=dict(r);eid,sid,email=r['employee'],r['staff'],r['email']
        if not eid or not sid:reason='ID空欄'
        elif employees[eid]>1 or staff[sid]>1:reason='CSV内のID重複'
        elif eid not in mapping:reason='社員ID未登録'
        elif str(mapping[eid]).strip()!=sid:reason='スタッフID不一致'
        elif saved_staff[sid]!=1:reason='保存済みスタッフID重複'
        elif not re.fullmatch(r'[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+',email):reason='メール空欄・形式不正'
        else:reason='両ID一致'
        item['status']=reason;item['matched']=reason=='両ID一致';results.append(item)
    return results

def merged_contacts(old,results,settings):
    data={**old,'import_settings':settings}
    by_pair={(r['employee'],r['staff']):dict(r) for r in old['contacts']}
    for item in results:
        if item['matched']:
            by_pair[item['employee'],item['staff']]={k:item[k] for k in DEFAULT_COLUMNS}
    data['contacts']=list(by_pair.values())
    candidates={r['email']:dict(r) for r in old.get('unlinked_contacts',[]) if isinstance(r,dict) and r.get('email')}
    for item in results:
        if not item['matched'] and valid_email(item['email']):candidates[item['email']]={k:item[k] for k in DEFAULT_COLUMNS}
    used={r['email'] for r in data['contacts']}
    data['unlinked_contacts']=[r for email,r in candidates.items() if email not in used]
    return data


def valid_email(value):
    return bool(re.fullmatch(r'[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+',value))

def selected_email(combo):
    text=combo.currentText().strip();index=combo.currentIndex()
    return str(combo.itemData(index) or '').strip() if index>=0 and text==combo.itemText(index).strip() else text

def save_manual_contacts(old,mapping,selections):
    data={**old};pairs={(r['employee'],r['staff']):dict(r) for r in old['contacts']}
    candidates={r['email']:r for r in old.get('unlinked_contacts',[])}
    nonempty=[row[3] for row in selections if row[3]]
    if len(nonempty)!=len(set(nonempty)):raise ValueError('同じメールが複数の社員に選択されています。')
    for eid,sid,name,email in selections:
        if not eid or not sid or mapping.get(eid)!=sid:
            if email:raise ValueError('先に社員IDとスタッフIDの紐付けを保存してください：'+eid)
            continue
        if email and not valid_email(email):raise ValueError('メールアドレスの形式が不正です：'+eid)
        if email:pairs[eid,sid]={'employee':eid,'staff':sid,'name':name,'email':email}
        else:
            removed=pairs.pop((eid,sid),None)
            if removed:candidates[removed['email']]=removed
    data['contacts']=list(pairs.values());used={r['email'] for r in data['contacts']}
    data['unlinked_contacts']=[r for email,r in candidates.items() if email not in used]
    return data


def import_contacts_dialog(parent,mapping,path):
    from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QLineEdit,QSpinBox,QComboBox,QFileDialog,QTableWidget,QTableWidgetItem,QHeaderView,QLabel,QMessageBox,QGroupBox,QGridLayout)
    from ui_theme import button,refresh_button_icons
    def label(text,role):
        widget=QLabel(text);widget.setObjectName(role);return widget
    old=load_contacts(path);settings=old.get('import_settings',{})
    dlg=QDialog(parent);dlg.setWindowTitle('メールCSV取込');dlg.resize(1000,700);dlg.setMinimumSize(900,620)
    layout=QVBoxLayout(dlg);layout.setContentsMargins(20,18,20,16);layout.setSpacing(12)
    layout.addWidget(label('メールCSV取込','pageTitle'))
    layout.addWidget(label('列を指定して照合し、取込結果を確認して保存します。','muted'))
    settings_box=QGroupBox('CSVと読み込み設定');settings_layout=QVBoxLayout(settings_box);settings_layout.setContentsMargins(14,18,14,14);settings_layout.setSpacing(12)
    layout.addWidget(settings_box)
    file_row=QHBoxLayout();filename=QLineEdit();filename.setPlaceholderText('メールアドレス一覧のCSV');choose=button('CSVを選択','folder')
    def browse():
        selected,_=QFileDialog.getOpenFileName(dlg,'メールCSVを選択','','CSV (*.csv)')
        if selected:filename.setText(selected)
    choose.clicked.connect(browse);file_row.addWidget(filename,1);file_row.addWidget(choose);settings_layout.addLayout(file_row)
    grid=QGridLayout();grid.setHorizontalSpacing(16);fields={}
    for col,(key,title) in enumerate([('employee','社員ID列'),('staff','スタッフID列'),('name','名前列'),('email','メール列')]):
        edit=QLineEdit(settings.get('columns',{}).get(key,DEFAULT_COLUMNS[key]));edit.setMaximumWidth(150);edit.setAccessibleName(title);fields[key]=edit
        grid.addWidget(label(title,'fieldHint'),0,col);grid.addWidget(edit,1,col);grid.setColumnStretch(col,1)
    settings_layout.addLayout(grid)
    options=QHBoxLayout();first=QSpinBox();first.setRange(1,1048576);first.setMaximumWidth(110);first.setValue(settings.get('first_row',2))
    encoding=QComboBox();encoding.addItems(['auto','utf-8-sig','cp932']);encoding.setMaximumWidth(150);encoding.setCurrentText(settings.get('encoding','auto'))
    options.addWidget(label('開始行','fieldHint'));options.addWidget(first);options.addSpacing(12);options.addWidget(label('文字コード','fieldHint'));options.addWidget(encoding);options.addStretch()
    check=button('照合して確認','check','primary');options.addWidget(check);settings_layout.addLayout(options)
    summary=QLabel('列はA、B、C…で指定します。見出しが1行ある場合、開始行は2です。');layout.addWidget(summary)
    table=QTableWidget(0,6);table.setHorizontalHeaderLabels(['CSV行','社員ID','スタッフID','名前','メールアドレス','照合結果']);table.verticalHeader().hide();table.setAlternatingRowColors(True);table.verticalHeader().setDefaultSectionSize(38);table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
    for col,width in [(0,65),(1,110),(2,130),(3,145),(5,165)]:table.setColumnWidth(col,width)
    table.horizontalHeader().setSectionResizeMode(4,QHeaderView.Stretch)
    from PySide6.QtWidgets import QAbstractItemView
    table.setEditTriggers(QAbstractItemView.NoEditTriggers);layout.addWidget(table,1)
    controls=QHBoxLayout();cancel=button('キャンセル','x');save=button('取込結果を保存','save','primary');save.setEnabled(False);controls.addStretch();controls.addWidget(cancel);controls.addWidget(save);layout.addLayout(controls)
    state={};result=None
    def invalidate(*args):state.clear();save.setEnabled(False)
    filename.textChanged.connect(invalidate);first.valueChanged.connect(invalidate);encoding.currentTextChanged.connect(invalidate)
    for edit in fields.values():edit.textChanged.connect(invalidate)
    def preview():
        invalidate()
        try:
            config={'columns':{k:edit.text().strip().upper() for k,edit in fields.items()},'first_row':first.value(),'encoding':encoding.currentText()}
            rows=read_contact_csv(filename.text(),**config);matches=match_contacts(rows,mapping)
            state.update(results=matches,settings=config);table.setRowCount(len(matches))
            for n,item in enumerate(matches):
                for col,key in enumerate(['line','employee','staff','name','email','status']):table.setItem(n,col,QTableWidgetItem(str(item[key])))
            count=sum(r['matched'] for r in matches);summary.setText(f'自動紐付け：{count}件 / 未紐付け：{len(matches)-count}件。有効なメールは未紐付け候補としても保存します。');save.setEnabled(any(valid_email(r['email']) for r in matches))
        except Exception as exc:QMessageBox.warning(dlg,'CSVを取り込めません',str(exc))
    def accept():
        nonlocal result
        try:
            updated=merged_contacts(old,state['results'],state['settings']);save_json(path,updated);result=updated;dlg.accept()
        except Exception as exc:QMessageBox.warning(dlg,'メール保存に失敗',str(exc))
    check.clicked.connect(preview);save.clicked.connect(accept);cancel.clicked.connect(dlg.reject)
    refresh_button_icons(dlg,getattr(parent,'is_dark',False))
    try:dlg.exec();return result
    finally:dlg.deleteLater()
