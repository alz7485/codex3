"""Delegated Microsoft Graph draft/send operations for the new Outlook mailbox."""
import json,hashlib,os,tempfile
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from urllib.parse import quote
from engine import load_json,save_json
from employee_contacts import valid_email
from mail_state import mail_lock,mail_payload as graph_payload

def _validate_graph_settings(settings):
    from outlook_mail import validate_mail_settings
    import uuid
    settings=validate_mail_settings(settings)
    if settings['client_id']:
        try:uuid.UUID(settings['client_id'])
        except ValueError:raise ValueError('MicrosoftアプリIDはUUID形式で指定してください。')
    if settings['tenant_id'] not in ('organizations','common','consumers'):
        try:uuid.UUID(settings['tenant_id'])
        except ValueError:raise ValueError('テナントIDはUUIDまたはorganizations/common/consumersで指定してください。')
    return settings

def graph_request(token,method,path,payload=None):
    if not path.startswith('/me'):raise ValueError('Microsoft Graphの要求先が不正です。')
    data=json.dumps(payload,ensure_ascii=False).encode('utf-8') if payload is not None else None
    request=Request('https://graph.microsoft.com/v1.0'+path,data=data,method=method,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    try:
        with urlopen(request,timeout=30) as response:
            raw=response.read();result=json.loads(raw) if raw else {};result['_http_status']=response.status;return result
    except HTTPError as exc:
        try:code=json.loads(exc.read()).get('error',{}).get('code','')
        except Exception:code=''
        raise RuntimeError(f'Microsoft Graphの処理に失敗（HTTP {exc.code} {code}）。アカウントと権限を確認してください。') from exc

def _cache_path(settings,data_dir):
    identity=json.dumps([settings['client_id'],settings['tenant_id'],settings['account'].casefold()])
    return Path(data_dir)/('microsoft_auth_'+hashlib.sha256(identity.encode()).hexdigest()[:24]+'.bin')

def authenticate(settings,data_dir):
    from outlook_mail import validate_mail_settings
    settings=_validate_graph_settings(settings)
    if not settings['client_id'] or not valid_email(settings['account']):
        raise ValueError('設定→メールでMicrosoftアプリID、テナントID、接続するアカウントを指定してください。初回設定は同梱のMicrosoft連携ガイドを参照してください。')
    try:import msal
    except ImportError as exc:raise RuntimeError('Microsoft連携にはmsalが必要です。requirements-build.txtからビルドしてください。') from exc
    cache=msal.SerializableTokenCache();path=_cache_path(settings,data_dir)
    # Never store reusable Microsoft credentials in plaintext.
    import sys
    persistent=sys.platform=='win32'
    if persistent:
        import win32crypt
        if path.exists():
            try:cache.deserialize(win32crypt.CryptUnprotectData(path.read_bytes(),None,None,None,0)[1].decode('utf-8'))
            except Exception as exc:raise RuntimeError('Microsoft認証情報を復元できません。別PCの認証キャッシュをコピーせず、このPCで接続し直してください。') from exc
    app=msal.PublicClientApplication(settings['client_id'],authority='https://login.microsoftonline.com/'+settings['tenant_id'],token_cache=cache)
    scopes=['User.Read','Mail.ReadWrite']+(['Mail.Send'] if settings['auto_send'] else [])
    accounts=app.get_accounts(username=settings['account'])
    result=app.acquire_token_silent(scopes,account=accounts[0]) if len(accounts)==1 else None
    if not result or 'access_token' not in result:
        result=app.acquire_token_interactive(scopes=scopes,login_hint=settings['account'],timeout=120)
    if not result or 'access_token' not in result:
        raise RuntimeError('Microsoftアカウントに接続できませんでした。ブラウザのサインインとアプリの権限設定を確認してください。')
    profile=graph_request(result['access_token'],'GET','/me?$select=userPrincipalName,mail')
    identities={str(profile.get(key,'') or '').casefold() for key in ('userPrincipalName','mail')}
    if settings['account'].casefold() not in identities:raise RuntimeError('接続したMicrosoftアカウントが設定と異なります。指定したアカウントでサインインしてください。')
    if persistent and cache.has_state_changed:
        path.parent.mkdir(parents=True,exist_ok=True);temporary=None
        try:
            encrypted=win32crypt.CryptProtectData(cache.serialize().encode('utf-8'),'Attendance checker',None,None,None,0)
            with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as stream:
                temporary=Path(stream.name);stream.write(encrypted);stream.flush();os.fsync(stream.fileno())
            temporary.replace(path)
        finally:
            if temporary and temporary.exists():temporary.unlink()
    return result['access_token']

def _process_graph_plans(plans,settings,data_dir,transport):
    """Create first, optionally send. No retry after ambiguous network failures."""
    from outlook_mail import validate_mail_settings
    settings=_validate_graph_settings(settings)
    for plan in plans:
        if plan.get('problem') or not plan.get('to'):raise ValueError('宛先未登録の社員が含まれています。')
        if any(not valid_email(address) for address in plan['to']+plan['cc']):raise ValueError('宛先の形式が不正です。')
        if '\r' in plan['subject'] or '\n' in plan['subject']:raise ValueError('件名は1行で指定してください。')
    path=Path(data_dir)/'mail_processing_history.json';ledger=load_json(path,{})
    if not isinstance(ledger,dict):raise ValueError('メール処理履歴が不正です。送信済みメールを確認してください。')
    outcomes=[]
    for index,plan in enumerate(plans):
        key=hashlib.sha256(json.dumps([settings['account'].casefold(),settings['client_id'],settings['tenant_id'],settings['auto_send'],plan['employee'],plan['staff'],graph_payload(plan)],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
        previous=ledger.get(key)
        if key in ledger:
            status=previous.get('status','') if isinstance(previous,dict) else ''
            outcomes.append({'employee':plan['employee'],'status':'同内容の送信受付済み' if status=='sent' else '同内容の下書き保存済み' if status=='draft' else '処理状況要確認（再実行を停止）'})
            continue
        record={'employee':plan['employee'],'status':'creating'};ledger[key]=record
        try:
            save_json(path,ledger) # Persist BEFORE an operation that might succeed remotely.
            created=transport('POST','/me/messages',graph_payload(plan));identifier=created.get('id')
            if not isinstance(identifier,str) or not identifier:raise RuntimeError('作成した下書きIDを確認できません。Outlookを確認してください。')
            record.update(id=identifier,status='created');save_json(path,ledger)
            if settings['auto_send']:
                record['status']='sending';save_json(path,ledger)
                response=transport('POST','/me/messages/'+quote(identifier,safe='')+'/send',None)
                if response.get('_http_status',202)!=202:raise RuntimeError('送信受付を確認できません。Outlookを確認してください。')
                record['status']='sent';status='送信受付済み'
            else:record['status']='draft';status='下書き保存済み'
            save_json(path,ledger);outcomes.append({'employee':plan['employee'],'status':status})
        except Exception as exc:
            outcomes.append({'employee':plan['employee'],'status':'処理失敗・Outlookを確認','error':str(exc)})
            outcomes.extend({'employee':p['employee'],'status':'未処理'} for p in plans[index+1:]);break
    return outcomes


def process_graph_plans(plans,settings,data_dir,transport):
    with mail_lock(data_dir):return _process_graph_plans(plans,settings,data_dir,transport)
