"""Completion audit: failed persistence must not commit UI state or hide results."""
import os,sys
if os.environ.get('ATTENDSYNC_AUDIT_BASELINE'):sys.path.insert(0,os.environ['ATTENDSYNC_AUDIT_BASELINE'])
import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication,QDialog,QTableWidget,QComboBox,QPushButton
import test_trial38_audit as fixture
import main
from engine import DEFAULT
from settings_dialog import SettingsDialog,SettingsError

class CompletionAudit(unittest.TestCase):
 setUpClass=classmethod(fixture.Audit38.setUpClass.__func__)
 setUp=fixture.Audit38.setUp
 load_results=fixture.Audit38.load_results
 def test_failed_theme_save_preserves_config_and_visual_state(self):
  old=copy.deepcopy(self.w.cfg);dark=self.w.is_dark;text=self.w.btn_theme.text()
  with patch.object(main,'save_json',side_effect=PermissionError('read-only')),patch.object(main.QMessageBox,'warning') as warn:
   self.w.toggle_theme()
  self.assertEqual(self.w.cfg,old);self.assertEqual(self.w.is_dark,dark);self.assertEqual(self.w.btn_theme.text(),text);warn.assert_called_once()
 def test_failed_read_settings_save_does_not_start_worker_or_commit(self):
  old=copy.deepcopy(self.w.cfg);self.w.path.setText(str(Path(fixture.__file__).parent/'SampleData'));self.w.year.setValue(2027)
  with patch.object(main,'save_json',side_effect=PermissionError('read-only')),patch.object(main.QMessageBox,'warning') as warn,patch.object(main,'ReadWorker') as worker:
   self.w.run_read()
  self.assertEqual(self.w.cfg,old);worker.assert_not_called();warn.assert_called_once();self.assertTrue(self.w.run_button.isEnabled());self.assertFalse(self.w.stop_button.isEnabled())
 def test_directory_permission_error_is_reported(self):
  old=copy.deepcopy(self.w.cfg);self.w.path.setText(str(Path(fixture.__file__).parent/'SampleData'))
  with patch.object(Path,'iterdir',side_effect=PermissionError('access denied')),patch.object(main.QMessageBox,'warning') as warn:
   self.w.run_read()
  warn.assert_called_once();self.assertEqual(old,self.w.cfg);self.assertIsNone(self.w.worker)
 def test_blank_folder_does_not_scan_working_directory(self):
  self.w.path.setText('')
  with patch.object(Path,'iterdir') as scan,patch.object(main.QMessageBox,'warning') as warn:self.w.run_read()
  scan.assert_not_called();warn.assert_called_once()
 def test_failed_manual_mapping_save_preserves_previous_assignments(self):
  old=dict(self.w.mapping);errors=[]
  def operate():
   try:
    dialog=self.app.activeModalWidget();table=dialog.findChild(QTableWidget,'employeeIdTable');combo=table.cellWidget(0,2)
    combo.setEditText('replacement');button=next(b for b in dialog.findChildren(QPushButton) if b.text()=='紐付けを保存');button.click();self.assertEqual(self.w.mapping,old);self.assertTrue(dialog.isVisible());dialog.reject()
   except Exception as exc:errors.append(exc);self.app.activeModalWidget().reject()
  with patch.object(main,'save_json',side_effect=PermissionError('read-only')),patch.object(main.QMessageBox,'warning') as warn:
   QTimer.singleShot(0,operate);self.w.edit_map()
  self.assertFalse(errors,errors);self.assertEqual(self.w.mapping,old);warn.assert_called_once()
 def test_failed_automatic_mapping_save_still_finishes_with_review(self):
  self.w.mapping={}
  with patch.object(main,'save_json',side_effect=PermissionError('read-only')),patch.object(main,'MappingDialog') as dialog:
   dialog.return_value.exec.return_value=QDialog.Rejected;self.load_results()
  self.assertEqual(self.w.mapping,{});self.assertTrue(self.w.results);self.assertTrue(any('保存失敗' in item for item in self.w.issues));self.assertTrue(any(r['status']=='要確認' for r in self.w.results));self.assertIn('未完了',self.w.status.text())
 def test_failed_mapping_dialog_save_preserves_previous_mapping(self):
  self.w.mapping={'10001':'S001'}
  def propose(x,c,m):return [('10002','candidate',['S002'])]
  with patch.object(main,'candidates',side_effect=propose),patch.object(main,'MappingDialog') as dialog,patch.object(main,'save_json',side_effect=PermissionError('read-only')),patch.object(main.QMessageBox,'warning') as warn:
   dialog.return_value.exec.return_value=QDialog.Accepted;dialog.return_value.mapping={'10001':'S001','10002':'S002'};self.load_results()
  self.assertEqual(self.w.mapping,{'10001':'S001'});self.assertTrue(self.w.results);warn.assert_called_once()
 def test_unsafe_json_values_rejected_without_overwriting_extensions(self):
  base=copy.deepcopy(DEFAULT);base['future_plugin']={'keep':[1,2]};dialog=SettingsDialog(self.w,base);self.addCleanup(dialog.close)
  cases=[('folder',None),('folder',[]),('year',None),('year',True),('year',2026.5),('year',1999),('month',13),('month','10'),('theme',[]),('theme','unknown')]
  for key,value in cases:
   with self.subTest(key=key,value=value):
    invalid=copy.deepcopy(base);invalid[key]=value
    dialog.advanced.setPlainText(json.dumps(invalid));self.assertFalse(dialog.apply_json_to_form());self.assertEqual(dialog._base,base)
  dialog.advanced.setPlainText(json.dumps(base));self.assertTrue(dialog.apply_json_to_form());self.assertEqual(dialog._collect_config()['future_plugin'],base['future_plugin'])

if __name__=='__main__':unittest.main(verbosity=2)
