"""Open the exact original XLSX cell only on direct user request (Windows / Excel)."""
from pathlib import Path
import sys
import re

def source_cell_for(record,column):
    if not record or not record.get('file') or not record.get('sheet'):
        raise ValueError('元XLSXの場所が記録されていません')
    if not re.fullmatch(r'[A-Za-z]{1,3}',str(column)):
        raise ValueError(f'不正な列指定: {column}')
    try:
        row=int(record['row'])
    except (ValueError,TypeError,KeyError) as ex:
        raise ValueError('元XLSXの行番号が不正です') from ex
    if not (1<=row<=1048576):raise ValueError('行番号が範囲外です')
    sheet=str(record['sheet'])
    if not sheet.strip():raise ValueError('元XLSXのシート名が空です')
    return Path(record['file']).resolve(),sheet,f'{column.upper()}{row}'

def open_source_cell(record,column):
    if sys.platform!='win32':raise RuntimeError('Excel連携はWindows専用です')
    path,sheet,cell=source_cell_for(record,column)
    if not path.is_file():raise FileNotFoundError(f'元ファイルが見つかりません: {path}')
    stat=path.stat()
    if ('file_size' in record and stat.st_size!=record['file_size']) or ('file_mtime_ns' in record and stat.st_mtime_ns!=record['file_mtime_ns']):
        raise RuntimeError('元XLSXが読み込み後に更新されています。再照合してからセルを開いてください。')
    try:
        import pythoncom
        import win32com.client
    except ImportError as ex:
        raise RuntimeError('Excel連携には pywin32 が必要です。requirements-build.txt から再ビルドしてください') from ex
    pythoncom.CoInitialize()
    created_excel=False
    opened_here=None
    excel=None
    try:
        try:
            excel=win32com.client.GetActiveObject('Excel.Application')
        except Exception:
            excel=win32com.client.DispatchEx('Excel.Application')
            created_excel=True
        target=None
        for wb in excel.Workbooks:
            if str(wb.FullName).casefold()==str(path).casefold():
                target=wb;break
        if target is None:
            target=excel.Workbooks.Open(str(path),UpdateLinks=0,ReadOnly=True,IgnoreReadOnlyRecommended=True)
            opened_here=target
        try:
            ws=target.Worksheets(sheet)
        except Exception as ex:
            raise RuntimeError(f'指定したシート「{sheet}」が見つかりません。再照合してください。') from ex
        excel.Visible=True
        excel.WindowState=-4143 # xlNormal
        target.Activate();ws.Activate()
        ws.Range(cell).Select()
        excel.ActiveWindow.ScrollRow=max(1,int(record['row'])-8)
        try:
            import win32gui,win32con
            hwnd=int(excel.Hwnd)
            win32gui.ShowWindow(hwnd,win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(hwnd)
        except Exception:
            pass  # Windows may prohibit foreground focus transfer
        return str(path),sheet,cell
    except Exception:
        # Only clean up resources created by this call; never close an existing user's workbook.
        if opened_here is not None:
            try:opened_here.Close(SaveChanges=False)
            except Exception:pass
        if created_excel and excel is not None:
            try:excel.Quit()
            except Exception:pass
        raise
    finally:
        pythoncom.CoUninitialize()
