from pathlib import Path
s=Path(__file__).with_name("main.py").read_text(encoding="utf-8")
assert "unlinked=button('すべて表示','users')" in s
assert "unlinked.setText('すべて表示' if showing_unlinked else '未紐づけを表示')" in s
# Row filtering is checked with real widgets in test_trial43_mapping_default.py
# and test_trial44_audit.py; avoid fixing this check to one expression spelling.
print("Trial27 toggle-label static test OK")
