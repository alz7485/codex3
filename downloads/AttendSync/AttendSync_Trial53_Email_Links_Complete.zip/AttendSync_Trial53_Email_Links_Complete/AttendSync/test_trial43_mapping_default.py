"""Opening ID management chooses the useful default without changing mappings."""
import copy
import unittest
from unittest.mock import patch
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QTableWidget,QPushButton
import test_trial38_audit as fixture
import main


class MappingDefault43(unittest.TestCase):
    setUpClass=classmethod(fixture.Audit38.setUpClass.__func__)
    setUp=fixture.Audit38.setUp

    def inspect_dialog(self,expected,only_unlinked):
        errors=[];before=copy.deepcopy(self.w.mapping)
        def inspect():
            dialog=self.app.activeModalWidget()
            try:
                table=dialog.findChild(QTableWidget)
                toggle=next(b for b in dialog.findChildren(QPushButton) if b.text() in ('すべて表示','未紐づけを表示'))
                visible={table.item(i,0).text() for i in range(table.rowCount()) if not table.isRowHidden(i)}
                self.assertEqual(visible,set(expected))
                self.assertEqual(toggle.isChecked(),only_unlinked)
                self.assertEqual(toggle.text(),'すべて表示' if only_unlinked else '未紐づけを表示')
            except Exception as exc:errors.append(exc)
            finally:dialog.reject()
        QTimer.singleShot(0,inspect);self.w.edit_map()
        self.assertFalse(errors,errors);self.assertEqual(self.w.mapping,before)

    def test_partial_mapping_opens_unlinked_only(self):
        self.w.loaded_xdata={'A':{'name':'社員A'},'B':{'name':'社員B'}}
        self.w.mapping={'B':'S2'}
        self.inspect_dialog({'A'},True)

    def test_fully_mapped_opens_all(self):
        self.w.loaded_xdata={'A':{'name':'社員A'},'B':{'name':'社員B'}}
        self.w.mapping={'A':'S1','B':'S2'}
        self.inspect_dialog({'A','B'},False)

    def test_saved_mapping_without_reading_opens_all(self):
        self.w.loaded_xdata={};self.w.mapping={'A':'S1','B':'S2'}
        self.inspect_dialog({'A','B'},False)

    def test_empty_mapping_with_loaded_employees_shows_unlinked(self):
        self.w.loaded_xdata={'A':{'name':'社員A'}};self.w.mapping={}
        self.inspect_dialog({'A'},True)

    def test_no_employees_chooses_all_mode(self):
        self.w.loaded_xdata={};self.w.mapping={}
        self.inspect_dialog(set(),False)

    def test_blank_saved_id_is_unlinked(self):
        self.w.loaded_xdata={'A':{'name':'社員A'},'B':{'name':'社員B'}}
        self.w.mapping={'A':'','B':'S2'}
        self.inspect_dialog({'A'},True)

    def test_manual_toggle_still_switches_between_modes(self):
        self.w.loaded_xdata={'A':{'name':'社員A'},'B':{'name':'社員B'}}
        self.w.mapping={'A':'S1','B':'S2'};errors=[]
        def inspect():
            dialog=self.app.activeModalWidget()
            try:
                table=dialog.findChild(QTableWidget)
                toggle=next(b for b in dialog.findChildren(QPushButton) if b.text()=='未紐づけを表示')
                toggle.click();self.assertTrue(all(table.isRowHidden(i) for i in range(table.rowCount())))
                toggle.click();self.assertTrue(all(not table.isRowHidden(i) for i in range(table.rowCount())))
            except Exception as exc:errors.append(exc)
            finally:dialog.reject()
        QTimer.singleShot(0,inspect);self.w.edit_map();self.assertFalse(errors,errors)


if __name__=='__main__':unittest.main(verbosity=2)
