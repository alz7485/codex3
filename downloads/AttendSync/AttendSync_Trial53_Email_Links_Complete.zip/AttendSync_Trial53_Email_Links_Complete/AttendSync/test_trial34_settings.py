"""Real Qt regressions for settings editing, compatibility and compact layout.

Run ``python -m unittest -v test_trial34_settings``.  Qt uses the offscreen
platform by default; importing the application cannot touch real user settings.
These checks exercise widget edits and save/reopen behavior rather than source
text or copies of the settings implementation.
"""
from __future__ import annotations

import copy
import csv
from datetime import timedelta
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

try:
    from PySide6.QtCore import QCoreApplication, QEvent, QPoint, QRect, QSize, Qt
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import (
        QAbstractSpinBox, QApplication, QCheckBox, QComboBox, QDialog, QGroupBox,
        QLabel, QLineEdit, QPushButton, QScrollArea, QSpinBox, QWidget,
    )
except ModuleNotFoundError as exc:
    if exc.name != 'PySide6':
        raise
    QT_AVAILABLE = False
else:
    QT_AVAILABLE = True
    import runtime_paths
    _import_directory = tempfile.TemporaryDirectory(prefix='attendsync-settings-import-')
    with patch.object(runtime_paths, 'get_data_dir', return_value=Path(_import_directory.name)):
        import main
    from ui_theme import apply_theme


@unittest.skipUnless(QT_AVAILABLE, 'PySide6 is required for real settings checks')
class Trial34Settings(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.default_snapshot = copy.deepcopy(main.DEFAULT)
        self.parent = QWidget()
        self.parent.is_dark = False
        self.parent.results = []
        self.dialogs = []
        self.input_snapshots = []
        self.applied_theme = None
        self.addCleanup(self.clean_up)

    def clean_up(self):
        for dialog in reversed(self.dialogs):
            dialog.close()
            dialog.deleteLater()
        self.parent.close()
        self.parent.deleteLater()
        self.app.processEvents()
        QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
        self.assertEqual(main.DEFAULT, self.default_snapshot, 'Editing settings mutated engine defaults')
        for cfg, original in self.input_snapshots:
            self.assertEqual(cfg, original, 'The input configuration changed before the caller saved it')

    def settle(self):
        self.app.processEvents()
        self.app.processEvents()

    def dialog(self, cfg=None, dark=False):
        cfg = copy.deepcopy(main.DEFAULT) if cfg is None else cfg
        self.input_snapshots.append((cfg, copy.deepcopy(cfg)))
        self.parent.is_dark = dark
        if self.applied_theme != dark:
            apply_theme(self.app, dark)
            self.applied_theme = dark
        dialog = main.SettingsDialog(self.parent, cfg)
        self.dialogs.append(dialog)
        dialog.resize(780, 580)
        dialog.show()
        self.settle()
        return dialog

    @staticmethod
    def entry(dialog, source, field):
        return next(edit for key, name, edit in dialog.entries if key == source and name == field)

    def save(self, dialog):
        # A modal warning here would hang both automated checks and the user
        # workflow. Validation must stay in the dialog and reveal the field.
        with patch.object(main.QMessageBox, 'warning') as warning:
            dialog.accept()
        self.settle()
        warning.assert_not_called()
        self.assertEqual(dialog.result(), QDialog.Accepted, dialog.error_label.text())
        self.assertIsInstance(dialog.value, dict)
        return dialog.value

    def assert_invalid(self, dialog, expected_control=None):
        with patch.object(main.QMessageBox, 'warning') as warning:
            dialog.accept()
        self.settle()
        warning.assert_not_called()
        self.assertEqual(dialog.result(), QDialog.Rejected)
        self.assertTrue(dialog.isVisible())
        self.assertTrue(dialog.error_label.isVisible())
        self.assertTrue(dialog.error_label.text().strip(), 'Validation must explain what needs fixing')
        if expected_control is not None:
            self.assertTrue(expected_control.isVisible(), 'Validation must reveal the affected section')
            focused = self.app.focusWidget()
            self.assertIsNotNone(focused, 'Validation must focus a control that can be corrected')
            self.assertTrue(focused == expected_control or expected_control.isAncestorOf(focused),
                            f'Validation focused {focused}, expected {expected_control}')

    def test_unchanged_default_roundtrip_preserves_key_presence(self):
        cfg = copy.deepcopy(main.DEFAULT)
        for _ in range(2):
            cfg = self.save(self.dialog(cfg))
            self.assertEqual(cfg, main.DEFAULT)
            self.assertNotIn('detail_visible_fields', cfg)
            self.assertNotIn('field_labels', cfg)
            self.assertNotIn('read_workers', cfg)

    def test_cancel_discards_all_typed_edits(self):
        cfg = copy.deepcopy(main.DEFAULT)
        dialog = self.dialog(cfg)
        self.entry(dialog, 'xlsx_columns', 'start').setText('AA')
        dialog.csv_first.setValue(8)
        dialog.first.setValue(17)
        dialog.compares.cellWidget(0, 0).setChecked(False)
        next(iter(dialog.detail_checks.values())).setChecked(False)
        dialog.advanced.setPlainText('{ broken JSON')
        cancel = next(button for button in dialog.findChildren(QPushButton)
                      if button.text() == 'キャンセル')
        QTest.mouseClick(cancel, Qt.LeftButton)
        self.assertEqual(dialog.result(), QDialog.Rejected)
        self.assertEqual(cfg, main.DEFAULT)

    def test_column_and_cell_edits_are_normalized_and_reopen(self):
        dialog = self.dialog()
        self.entry(dialog, 'xlsx_columns', 'start').setText(' aa ')
        self.entry(dialog, 'info_cells', 'employee').setText(' xfd1048576 ')
        dialog.schedule_cols['end'].setText(' ac ')
        saved = self.save(dialog)
        self.assertEqual(saved['xlsx_columns']['start'], 'AA')
        self.assertEqual(saved['info_cells']['employee'], 'XFD1048576')
        self.assertEqual(saved['xlsx_schedule']['end'], 'AC')
        reopened = self.dialog(saved)
        self.assertEqual(self.entry(reopened, 'xlsx_columns', 'start').text(), 'AA')
        self.assertEqual(self.entry(reopened, 'info_cells', 'employee').text(), 'XFD1048576')

    def test_optional_columns_can_be_empty_while_required_columns_cannot(self):
        dialog = self.dialog()
        self.entry(dialog, 'xlsx_columns', 'ot').clear()
        self.entry(dialog, 'csv_columns', 'break_total').clear()
        saved = self.save(dialog)
        self.assertEqual(saved['xlsx_columns']['ot'], '')
        self.assertEqual(saved['csv_columns']['break_total'], '')
        for source, field in (('xlsx_columns', 'day'), ('csv_columns', 'date'),
                              ('csv_columns', 'staff'), ('xlsx_columns', 'start')):
            with self.subTest(source=source, field=field):
                invalid = self.dialog()
                control = self.entry(invalid, source, field)
                control.clear()
                self.assert_invalid(invalid, control)

    def test_unknown_config_and_comparison_metadata_survive(self):
        cfg = copy.deepcopy(main.DEFAULT)
        cfg['extension'] = {'nested': ['keep', 17]}
        cfg['comparisons'][0]['external_identifier'] = 'legacy-start'
        cfg['xlsx_schedule']['review_note'] = 'existing extension'
        cfg['xlsx_schedule']['rows']['99'] = 11
        cfg['detail_visible_fields'] = ['start|start', 'external|field']
        saved = self.save(self.dialog(cfg))
        self.assertEqual(saved, cfg)

    def test_detail_visibility_is_independent_of_comparison_switches(self):
        dialog = self.dialog()
        self.assertTrue(dialog.detail_checks['start|start'].isChecked())
        dialog.detail_checks['start|start'].setChecked(False)
        self.assertTrue(dialog.compares.cellWidget(0, 0).isChecked())
        dialog.compares.cellWidget(1, 0).setChecked(False)
        self.assertTrue(dialog.detail_checks['end|end'].isChecked())
        saved = self.save(dialog)
        self.assertNotIn('start|start', saved['detail_visible_fields'])
        self.assertIn('end|end', saved['detail_visible_fields'])
        self.assertTrue(saved['comparisons'][0]['enabled'])
        self.assertFalse(saved['comparisons'][1]['enabled'])
        row = dict(date='2026-10-01', name='設定確認', employee='10001', staff='S10001')
        detail = main.DetailDialog(self.parent, row, saved)
        self.dialogs.append(detail)
        start_index = next(i for i, field in enumerate(detail.detail_fields) if field[1] == 'start')
        end_index = next(i for i, field in enumerate(detail.detail_fields) if field[1] == 'end')
        self.assertTrue(detail.detail_table.isRowHidden(start_index))
        self.assertFalse(detail.detail_table.isRowHidden(end_index))

    def test_source_combos_expose_semantic_labels_and_save_selected_keys(self):
        dialog = self.dialog()
        for column in (2, 3):
            self.assertFalse(dialog.compares.isColumnHidden(column))
            combo = dialog.compares.cellWidget(0, column)
            self.assertIsInstance(combo, QComboBox)
            self.assertEqual(combo.currentData(), 'start')
            self.assertIn(main.NAMES['start'], combo.currentText())
            target = combo.findData('end')
            self.assertGreaterEqual(target, 0)
            combo.setCurrentIndex(target)
        saved = self.save(dialog)
        self.assertEqual(saved['comparisons'][0]['xlsx'], 'end')
        self.assertEqual(saved['comparisons'][0]['csv'], 'end')

    def test_custom_fields_and_renames_keep_comparison_identity_on_reopen(self):
        dialog = self.dialog()
        xkey = dialog.add_source_field('xlsx_columns', '追加の実働', 'AA')
        ckey = dialog.add_source_field('csv_columns', '追加の実働', 'AC')
        self.assertIsInstance(xkey, str)
        self.assertIsInstance(ckey, str)
        self.assertTrue(xkey)
        self.assertTrue(ckey)
        dialog.add_compare(dict(name='追加の実働照合', xlsx=xkey, csv=ckey,
                                type='duration', enabled=True, external_identifier='custom-pair'))
        row = dialog.compares.rowCount() - 1
        self.assertEqual(dialog.compares.cellWidget(row, 2).currentData(), xkey)
        self.assertEqual(dialog.compares.cellWidget(row, 3).currentData(), ckey)
        self.assertTrue(dialog.rename_source_field('xlsx_columns', xkey, '追加残業時間'))
        self.assertEqual(dialog.compares.cellWidget(row, 2).currentData(), xkey)
        self.assertIn('追加残業時間', dialog.compares.cellWidget(row, 2).currentText())
        saved = self.save(dialog)
        self.assertEqual(saved['xlsx_columns'][xkey], 'AA')
        self.assertEqual(saved['csv_columns'][ckey], 'AC')
        self.assertIn('field_labels', saved)
        self.assertEqual(saved['comparisons'][-1]['xlsx'], xkey)
        self.assertEqual(saved['comparisons'][-1]['csv'], ckey)
        self.assertEqual(saved['comparisons'][-1]['external_identifier'], 'custom-pair')
        reopened = self.dialog(saved)
        self.assertIn('追加残業時間', reopened.compares.cellWidget(row, 2).currentText())
        self.assertEqual(self.save(reopened), saved)

    def test_remove_field_blocks_required_and_referenced_fields(self):
        dialog = self.dialog()
        self.assertFalse(dialog.remove_source_field('xlsx_columns', 'day'))
        self.assertFalse(dialog.remove_source_field('csv_columns', 'staff'))
        self.assertFalse(dialog.remove_source_field('xlsx_columns', 'start'))
        # Disabled comparisons still hold a reference and must not be orphaned.
        self.assertFalse(dialog.remove_source_field('csv_columns', 'break_total'))
        key = dialog.add_source_field('xlsx_columns', '未使用項目', 'AB')
        self.assertTrue(dialog.remove_source_field('xlsx_columns', key))
        saved = self.save(dialog)
        self.assertNotIn(key, saved['xlsx_columns'])
        self.assertEqual(saved['xlsx_columns']['day'], 'B')
        self.assertEqual(saved['csv_columns']['staff'], 'D')

    def test_existing_optional_none_column_is_preserved_without_edit(self):
        cfg = copy.deepcopy(main.DEFAULT)
        cfg['xlsx_columns']['ot'] = None
        saved = self.save(self.dialog(cfg))
        self.assertIsNone(saved['xlsx_columns']['ot'])
        self.assertEqual(saved, cfg)

    def test_source_only_custom_fields_reach_detail_table_without_comparison(self):
        dialog = self.dialog()
        xkey = dialog.add_source_field('xlsx_columns', '追加XLSX項目', 'AA', key='extra_xlsx')
        ckey = dialog.add_source_field('csv_columns', '追加CSV項目', 'AB', key='extra_csv')
        saved = self.save(dialog)
        self.assertEqual(saved['comparisons'], main.DEFAULT['comparisons'])
        row = dict(date='2026-10-01', name='設定確認', employee='10001', staff='S10001',
                   xrecord=dict(values={xkey: 'XLSXの追加値'}, file='book.xlsx', sheet='10月', row=10),
                   crecord=dict(values={ckey: 'CSVの追加値'}, file='staff.csv', row=2))
        detail = main.DetailDialog(self.parent, row, saved)
        self.dialogs.append(detail)
        xrow = next(i for i, field in enumerate(detail.detail_fields) if field[1] == xkey)
        crow = next(i for i, field in enumerate(detail.detail_fields) if field[2] == ckey)
        self.assertEqual(detail.detail_table.item(xrow, 0).text(), '追加XLSX項目')
        self.assertEqual(detail.detail_table.item(crow, 0).text(), '追加CSV項目')
        self.assertEqual(detail.detail_table.item(xrow, 1).text(), 'XLSXの追加値')
        self.assertEqual(detail.detail_table.item(crow, 2).text(), 'CSVの追加値')
        self.assertEqual(detail.detail_table.item(xrow, 3).text(), '参照のみ')
        self.assertEqual(detail.detail_table.item(crow, 3).text(), '参照のみ')
        reopened = self.dialog(saved)
        self.assertIn(detail.field_key(detail.detail_fields[xrow]), reopened.detail_checks)
        self.assertIn(detail.field_key(detail.detail_fields[crow]), reopened.detail_checks)

    def test_custom_column_edits_are_used_by_real_excel_csv_reconciliation(self):
        from openpyxl import Workbook
        import engine

        cfg = copy.deepcopy(main.DEFAULT)
        for comparison in cfg['comparisons']:
            comparison['enabled'] = False
        dialog = self.dialog(cfg)
        xkey = dialog.add_source_field('xlsx_columns', '追加XLSX時間', 'V')
        ckey = dialog.add_source_field('csv_columns', '追加CSV時間', 'O')
        dialog.add_compare(dict(name='追加時間の照合', xlsx=xkey, csv=ckey,
                                type='duration', enabled=True))
        saved = self.save(dialog)
        reopened = self.dialog(saved)
        self.assertEqual(self.entry(reopened, 'xlsx_columns', xkey).text(), 'V')
        self.assertEqual(self.entry(reopened, 'csv_columns', ckey).text(), 'O')
        saved = self.save(reopened)

        with tempfile.TemporaryDirectory(prefix='attendsync-custom-columns-') as directory:
            workbook_path = Path(directory) / '10001.xlsx'
            csv_path = Path(directory) / 'attendance.csv'
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = '10月'
            for address, value in {'A1': '2026年10月度', 'N1': '10001', 'P1': '検証部門',
                                   'U1': '設定確認', 'A9': 10, 'B9': 1}.items():
                sheet[address] = value
            # Exercise both Excel duration representations: a formatted
            # timedelta in V and a day fraction in the replacement W column.
            sheet['V9'] = timedelta(hours=2)
            sheet['V9'].number_format = '[h]:mm'
            sheet['W9'] = 3 / 24
            workbook.save(workbook_path)
            workbook.close()
            csv_row = [''] * 16
            for index, value in {0: '20261001', 3: 'S10001', 4: '設定確認',
                                 14: '2:30', 15: '3:00'}.items():
                csv_row[index] = value
            with csv_path.open('w', encoding='utf-8-sig', newline='') as stream:
                writer = csv.writer(stream)
                writer.writerow([f'見出し{index + 1}' for index in range(16)])
                writer.writerow(csv_row)

            def read_and_compare(configuration):
                xpacket = engine.xlsx_read(workbook_path, configuration)
                cpacket = engine.csv_read(csv_path, configuration)
                self.assertNotIn('error', xpacket)
                self.assertEqual(xpacket['warnings'], [])
                self.assertEqual(cpacket['warnings'], [])
                self.assertEqual(len(xpacket['records']), 1)
                self.assertEqual(len(cpacket['records']), 1)
                self.assertIn(xkey, xpacket['records'][0]['values'])
                self.assertIn(ckey, cpacket['records'][0]['values'])
                results, issues = engine.reconcile({'10001': xpacket}, cpacket['records'],
                                                  {'10001': 'S10001'}, configuration)
                self.assertEqual(issues, [])
                self.assertEqual(len(results), 1)
                self.assertEqual(results[0]['xlsx_key'], xkey)
                self.assertEqual(results[0]['csv_key'], ckey)
                self.assertEqual(results[0]['date'], '2026-10-01')
                return results[0]

            first = read_and_compare(saved)
            self.assertEqual(first['field'], '追加時間の照合')
            self.assertEqual(first['xlsx'], '2:00')
            self.assertEqual(first['csv'], '2:30')
            self.assertEqual(first['status'], '不一致')

            changed = self.dialog(saved)
            self.assertTrue(changed.rename_source_field('xlsx_columns', xkey, '追加残業時間'))
            self.assertTrue(changed.rename_source_field('csv_columns', ckey, '派遣先の追加残業'))
            self.entry(changed, 'xlsx_columns', xkey).setText('W')
            self.entry(changed, 'csv_columns', ckey).setText('P')
            changed.compares.item(changed.compares.rowCount() - 1, 1).setText('追加残業時間の照合')
            updated = self.save(changed)
            final = self.dialog(updated)
            self.assertEqual(final.compares.cellWidget(final.compares.rowCount() - 1, 2).currentData(), xkey)
            self.assertEqual(final.compares.cellWidget(final.compares.rowCount() - 1, 3).currentData(), ckey)
            updated = self.save(final)
            second = read_and_compare(updated)
            self.assertEqual(second['field'], '追加残業時間の照合')
            self.assertEqual(second['xlsx'], '3:00')
            self.assertEqual(second['csv'], '3:00')
            self.assertEqual(second['status'], '一致')

    def test_excel_bounds_are_validated_and_errors_reveal_the_control(self):
        cases = [('xlsx_columns', 'start', 'XFE'), ('xlsx_columns', 'start', 'A1'),
                 ('info_cells', 'employee', 'A1048577'), ('info_cells', 'employee', 'XFE1'),
                 ('info_cells', 'employee', 'A0')]
        for source, field, value in cases:
            with self.subTest(source=source, field=field, value=value):
                dialog = self.dialog()
                control = self.entry(dialog, source, field)
                control.setText(value)
                # Deliberately leave the invalid field on a hidden page.
                dialog.tabs.setCurrentIndex(1)
                self.assert_invalid(dialog, control)
                control.setText(main.DEFAULT[source][field])
                self.save(dialog)

    def test_inverted_attendance_rows_and_invalid_schedule_rows_block_save(self):
        dialog = self.dialog()
        dialog.first.setValue(60)
        dialog.last.setValue(59)
        self.assert_invalid(dialog)
        dialog.last.setValue(60)
        self.save(dialog)
        for value in ('0', '-1', 'abc', '1048577'):
            with self.subTest(value=value):
                invalid = self.dialog()
                control = invalid.schedule_rows['1']
                control.setText(value)
                self.assert_invalid(invalid, control)

    def test_duplicate_codes_and_comparison_names_block_save(self):
        dialog = self.dialog()
        dialog.add_code('1', '重複名称')
        self.assert_invalid(dialog, dialog.codes)
        dialog = self.dialog()
        dialog.compares.item(1, 1).setText(dialog.compares.item(0, 1).text())
        self.assert_invalid(dialog, dialog.compares)

    def test_legacy_format_is_not_silently_rewritten(self):
        cfg = copy.deepcopy(main.DEFAULT)
        cfg['comparisons'][0]['type'] = 'legacy-text'
        dialog = self.dialog(cfg)
        self.assertEqual(dialog.compares.cellWidget(0, 4).currentData(), 'legacy-text')
        self.assertEqual(self.save(dialog), cfg)

    def test_json_requires_explicit_apply_and_does_not_overwrite_typed_controls(self):
        dialog = self.dialog()
        if not dialog.advanced.isVisible():
            QTest.mouseClick(dialog.advanced_toggle, Qt.LeftButton)
        changed = copy.deepcopy(main.DEFAULT)
        changed['xlsx_columns']['start'] = 'Z'
        changed['extension'] = {'configured_in_json': True}
        dialog.advanced.setPlainText(json.dumps(changed, ensure_ascii=False))
        self.assert_invalid(dialog)
        QTest.mouseClick(dialog.advanced_apply, Qt.LeftButton)
        self.settle()
        self.assertEqual(self.entry(dialog, 'xlsx_columns', 'start').text(), 'Z')
        self.entry(dialog, 'xlsx_columns', 'start').setText('AA')
        saved = self.save(dialog)
        self.assertEqual(saved['xlsx_columns']['start'], 'AA')
        self.assertEqual(saved['extension'], {'configured_in_json': True})

    def test_malformed_json_reports_inline_and_leaves_controls_unchanged(self):
        for value in ('{ not valid json', '[]'):
            with self.subTest(value=value):
                dialog = self.dialog()
                if not dialog.advanced.isVisible():
                    QTest.mouseClick(dialog.advanced_toggle, Qt.LeftButton)
                dialog.advanced.setPlainText(value)
                self.assert_invalid(dialog, dialog.advanced)
                self.assertEqual(self.entry(dialog, 'xlsx_columns', 'start').text(), 'G')
                with patch.object(main.QMessageBox, 'warning') as warning:
                    QTest.mouseClick(dialog.advanced_apply, Qt.LeftButton)
                warning.assert_not_called()
                self.assertTrue(dialog.error_label.text().strip())
                self.assertEqual(dialog.result(), QDialog.Rejected)

    def test_malformed_nested_json_is_rejected_before_any_form_changes(self):
        changes = [dict(xlsx_columns=[]), dict(xlsx_columns={'day': 'B'}),
                   dict(info_cells={'employee': 'XFE1'}), dict(data_first_row=True),
                   dict(sheet_names=[]), dict(codes={'1': []}),
                   dict(comparisons=[None]), dict(field_labels={'xlsx_columns': []}),
                   dict(detail_visible_fields=[None]), dict(xlsx_schedule={'rows': []})]
        for changed in changes:
            with self.subTest(changed=changed):
                dialog = self.dialog()
                self.entry(dialog, 'xlsx_columns', 'start').setText('AA')
                dialog.csv_first.setValue(7)
                before_entries = [(s, key, edit.text()) for s, key, edit in dialog.entries]
                before_comparisons = copy.deepcopy(dialog._comparison_values())
                before_base = copy.deepcopy(dialog._base)
                candidate = copy.deepcopy(main.DEFAULT)
                candidate.update(changed)
                dialog.advanced.setPlainText(json.dumps(candidate, ensure_ascii=False))
                self.assertFalse(dialog.apply_json_to_form())
                self.settle()
                self.assertTrue(dialog.error_label.isVisible())
                self.assertTrue(dialog.advanced.isVisible())
                self.assertEqual(dialog._base, before_base)
                self.assertEqual([(s, key, edit.text()) for s, key, edit in dialog.entries], before_entries)
                self.assertEqual(dialog._comparison_values(), before_comparisons)
                self.assertEqual(dialog.csv_first.value(), 7)

    def test_comparison_renames_and_source_changes_refresh_detail_choices(self):
        dialog = self.dialog()
        dialog.detail_checks['start|start'].setChecked(False)
        dialog.compares.item(0, 1).setText('出勤時刻')
        self.settle()
        self.assertEqual(dialog.detail_checks['start|start'].text(), '出勤時刻')
        self.assertFalse(dialog.detail_checks['start|start'].isChecked())
        csv_source = dialog.compares.cellWidget(0, 3)
        csv_source.setCurrentIndex(csv_source.findData('end'))
        self.settle()
        self.assertIn('start|end', dialog.detail_checks)
        self.assertEqual(dialog.detail_checks['start|end'].text(), '出勤時刻')
        self.assertFalse(dialog.detail_checks['start|start'].isChecked())
        saved = self.save(dialog)
        self.assertEqual(saved['comparisons'][0]['name'], '出勤時刻')
        self.assertEqual(saved['comparisons'][0]['xlsx'], 'start')
        self.assertEqual(saved['comparisons'][0]['csv'], 'end')
        self.assertNotIn('start|start', saved['detail_visible_fields'])

    def test_renamed_builtin_field_caption_reaches_detail_table(self):
        dialog = self.dialog()
        self.assertTrue(dialog.rename_source_field('xlsx_columns', 'start', '出勤の時刻'))
        self.assertEqual(dialog.detail_checks['start|start'].text(), '出勤の時刻')
        saved = self.save(dialog)
        self.assertEqual(saved['comparisons'][0]['xlsx'], 'start')
        row = dict(date='2026-10-01', name='設定確認', employee='10001', staff='S10001')
        detail = main.DetailDialog(self.parent, row, saved)
        self.dialogs.append(detail)
        index = next(i for i, field in enumerate(detail.detail_fields) if field[1:] == ('start', 'start'))
        self.assertEqual(detail.detail_table.item(index, 0).text(), '出勤の時刻')

    def test_text_and_legacy_number_values_are_not_formatted_as_excel_time(self):
        for kind in ('text', 'number'):
            with self.subTest(kind=kind):
                dialog = self.dialog()
                xkey = dialog.add_source_field('xlsx_columns', '追加値', 'AA', key='extra_value')
                ckey = dialog.add_source_field('csv_columns', '追加値', 'AB', key='extra_value')
                dialog.add_compare(dict(name='追加値の照合', xlsx=xkey, csv=ckey, type=kind, enabled=True))
                saved = self.save(dialog)
                row = dict(date='2026-10-01', name='設定確認', employee='10001', staff='S10001',
                           xrecord=dict(values={xkey: '2'}, file='book.xlsx', sheet='10月', row=10),
                           crecord=dict(values={ckey: '2'}, file='staff.csv', row=2))
                detail = main.DetailDialog(self.parent, row, saved)
                self.dialogs.append(detail)
                index = next(i for i, field in enumerate(detail.detail_fields) if field[1:] == (xkey, ckey))
                self.assertEqual(detail.detail_table.item(index, 1).text(), '2')
                self.assertEqual(detail.detail_table.item(index, 2).text(), '2')

    def test_custom_text_comparisons_preserve_zero_false_and_missing_values(self):
        import engine

        for kind in ('text', 'number'):
            cfg = copy.deepcopy(main.DEFAULT)
            for comparison in cfg['comparisons']:
                comparison['enabled'] = False
            dialog = self.dialog(cfg)
            xkey = dialog.add_source_field('xlsx_columns', '追加値', 'V')
            ckey = dialog.add_source_field('csv_columns', '追加値', 'O')
            dialog.add_compare(dict(name='追加値の照合', xlsx=xkey, csv=ckey,
                                    type=kind, enabled=True))
            saved = self.save(dialog)
            cases = [(0, '', '不一致', '0'), (0, '0', '一致', '0'),
                     (False, '', '不一致', 'False'), (False, 'False', '一致', 'False'),
                     (None, '', '一致', '')]
            for xvalue, csvvalue, status, display in cases:
                with self.subTest(kind=kind, xvalue=xvalue, csvvalue=csvvalue):
                    xrecord = dict(date='2026-10-01', name='設定確認', employee='10001',
                                   values={xkey: xvalue}, file='book.xlsx', sheet='10月', row=9)
                    crecord = dict(date='2026-10-01', name='設定確認', staff='S10001',
                                   values={ckey: csvvalue}, file='staff.csv', row=2, invalid_fields=[])
                    packet = dict(info={'name': '設定確認'}, records=[xrecord])
                    rows, issues = engine.reconcile({'10001': packet}, [crecord],
                                                   {'10001': 'S10001'}, saved)
                    self.assertEqual(issues, [])
                    self.assertEqual(len(rows), 1)
                    self.assertEqual(rows[0]['status'], status)
                    self.assertEqual(rows[0]['xlsx'], display)
                    self.assertEqual(rows[0]['csv'], csvvalue)
                    detail = main.DetailDialog(self.parent, rows[0], saved)
                    self.dialogs.append(detail)
                    index = next(i for i, field in enumerate(detail.detail_fields)
                                 if field[1:] == (xkey, ckey))
                    self.assertEqual(detail.detail_table.item(index, 1).text(), display)
                    self.assertEqual(detail.detail_table.item(index, 2).text(), csvvalue)

    def test_month_sheet_extension_metadata_is_preserved(self):
        cfg = copy.deepcopy(main.DEFAULT)
        cfg['sheet_names']['extension_notes'] = {'template_revision': 7}
        dialog = self.dialog(cfg)
        dialog.sheet_edits['10'].setText('10月勤務表')
        saved = self.save(dialog)
        self.assertEqual(saved['sheet_names']['extension_notes'], {'template_revision': 7})
        self.assertEqual(saved['sheet_names']['10'], '10月勤務表')

    def test_added_basic_information_cell_cannot_be_empty(self):
        dialog = self.dialog()
        key = dialog.add_source_field('info_cells', '部門コード', 'V1')
        control = self.entry(dialog, 'info_cells', key)
        control.clear()
        self.assert_invalid(dialog, control)
        control.setText('W1')
        self.assertEqual(self.save(dialog)['info_cells'][key], 'W1')

    @staticmethod
    def leaf_controls(container):
        controls = []
        for control in container.findChildren(QWidget):
            if not control.isVisible() or not isinstance(
                    control, (QLabel, QLineEdit, QSpinBox, QComboBox, QCheckBox)):
                continue
            if isinstance(control, QLineEdit) and isinstance(control.parentWidget(), QAbstractSpinBox):
                continue
            controls.append(control)
        return controls

    def assert_group_geometry(self, dialog):
        # Fields below a scroll viewport remain valid; test their owning card
        # instead of wrongly treating clipping by the viewport as overflow.
        for group in dialog.findChildren(QGroupBox):
            if not group.isVisible():
                continue
            controls = self.leaf_controls(group)
            rectangles = [(control, QRect(control.mapTo(group, QPoint()), control.size()))
                          for control in controls]
            for control, rect in rectangles:
                self.assertTrue(group.rect().contains(rect),
                                f'{group.title()}: {type(control).__name__} overflows {rect.getRect()}')
                self.assertGreater(rect.width(), 0)
                self.assertGreater(rect.height(), 0)
            for index, (control, rect) in enumerate(rectangles):
                for other, other_rect in rectangles[index + 1:]:
                    if control.isAncestorOf(other) or other.isAncestorOf(control):
                        continue
                    self.assertFalse(rect.intersects(other_rect),
                                     f'{group.title()}: {type(control).__name__} overlaps '
                                     f'{type(other).__name__}: {rect.getRect()} / {other_rect.getRect()}')

    def test_three_tabs_and_navigation_fit_minimum_size_in_both_themes(self):
        for dark in (False, True):
            with self.subTest(dark=dark):
                dialog = self.dialog(dark=dark)
                self.assertEqual(dialog.size(), QSize(780, 580))
                self.assertEqual(dialog.tabs.count(), 3)
                self.assertEqual(list(dialog.read_navigation), ['xlsx', 'csv'])
                xlsx_page=dialog.read_stack.widget(0)
                for control in [*dialog.sheet_edits.values(), dialog.first, dialog.last, dialog.workers]:
                    self.assertTrue(xlsx_page.isAncestorOf(control), 'XLSXの月度・読み込み設定が別ページにあります')
                self.assertTrue(dialog.findChildren(QScrollArea))
                self.assertTrue(all(edit.maximumWidth() <= 88 for _, _, edit in dialog.entries))
                self.assertFalse(dialog.advanced.isVisible(), 'Raw JSON should be folded initially')
                for index, navigation in ((0, dialog.read_navigation), (1, dialog.compare_navigation)):
                    dialog.tabs.setCurrentIndex(index)
                    for name, button in navigation.items():
                        QTest.mouseClick(button, Qt.LeftButton)
                        self.settle()
                        self.assertTrue(button.isChecked(), name)
                        self.assertEqual(sum(item.isChecked() for item in navigation.values()), 1)
                        self.assert_group_geometry(dialog)
                dialog.tabs.setCurrentIndex(2)
                self.settle()
                self.assert_group_geometry(dialog)
                for button in dialog.findChildren(QPushButton):
                    if button.isVisible() and button.text() in ('キャンセル', '設定を保存'):
                        rect = QRect(button.mapTo(dialog, QPoint()), button.size())
                        self.assertTrue(dialog.rect().contains(rect), button.text())

    def test_more_than_six_custom_fields_keep_compact_navigation_and_card_layout(self):
        dialog = self.dialog()
        for source in ('xlsx_columns', 'csv_columns'):
            for index in range(8):
                self.assertTrue(dialog.add_source_field(source, f'追加時間{index + 1}', f'A{chr(65 + index)}'))
        for name in ('xlsx', 'csv'):
            QTest.mouseClick(dialog.read_navigation[name], Qt.LeftButton)
            self.settle()
            self.assertEqual(dialog.size(), QSize(780, 580))
            self.assert_group_geometry(dialog)
        self.assertTrue(all(edit.maximumWidth() <= 88 for _, _, edit in dialog.entries))
        saved = self.save(dialog)
        self.assertEqual(len(saved['xlsx_columns']), len(main.DEFAULT['xlsx_columns']) + 8)
        self.assertEqual(len(saved['csv_columns']), len(main.DEFAULT['csv_columns']) + 8)
        self.assertEqual(self.save(self.dialog(saved)), saved)


if __name__ == '__main__':
    unittest.main()
