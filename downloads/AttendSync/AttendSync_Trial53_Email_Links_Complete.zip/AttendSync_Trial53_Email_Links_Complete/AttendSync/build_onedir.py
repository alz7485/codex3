"""Windowsで実行: python build_onedir.py
PyInstallerのonedir成果物を dist/AttendSync に出力。
"""
from pathlib import Path
import subprocess
import sys
import shutil

ROOT = Path(__file__).resolve().parent
APPNAME = 'AttendSync'

def copy_manual(output):
    manual=ROOT/'Manual'
    if not (manual/'index.html').is_file():
        raise SystemExit('操作マニュアルがありません。Manualフォルダを含む完全ソースを使用してください。')
    shutil.copytree(manual,Path(output)/'Manual',dirs_exist_ok=True)


def main():
    if sys.platform != 'win32':
        raise SystemExit('EXEはWindows環境でビルドしてください。')
    if not (ROOT/'Manual'/'index.html').is_file():
        raise SystemExit('操作マニュアルがありません。Manualフォルダを確認してください。')
    try:
        import PyInstaller  # noqa: F401
    except ImportError:
        raise SystemExit('PyInstallerがありません。python -m pip install -r requirements-build.txt')
    args = [sys.executable, '-m', 'PyInstaller',
        '--noconfirm', '--clean', '--onedir', '--windowed',
        '--name', APPNAME,
        '--distpath', str(ROOT/'dist'), '--workpath', str(ROOT/'build'),
        '--specpath', str(ROOT),
        '--collect-submodules', 'openpyxl',
        '--hidden-import', 'PySide6.QtSvg',
        '--icon', str(ROOT/'AttendSync.ico'),
        str(ROOT/'main.py')]
    print('ビルド開始:', ' '.join(args), flush=True)
    subprocess.run(args, cwd=ROOT, check=True)
    output=ROOT/'dist'/APPNAME
    copy_manual(output)
    sample=ROOT/'SampleData'
    if sample.exists():
        shutil.copytree(sample, output/'SampleData', dirs_exist_ok=True)
    shutil.copy2(ROOT/'AttendSync.ico', output/'AttendSync.ico')
    (output/'userdata').mkdir(exist_ok=True)
    print('完成:', output/'AttendSync.exe')
    print('dist/AttendSync フォルダ全体を配布してください。')

if __name__ == '__main__':
    main()
