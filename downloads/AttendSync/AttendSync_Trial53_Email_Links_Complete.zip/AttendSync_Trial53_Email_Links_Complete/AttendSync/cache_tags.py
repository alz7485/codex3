"""Versioned cache signatures for parser-dependent settings.
Changes to the extraction rules must never reuse a packet parsed with old rules.
"""
import hashlib
import json

PARSER_VERSION = 'trial52-hidden-formula-zero-clock-v5'
XLSX_KEYS = ('year','month','xlsx_columns','info_cells','sheet_names','data_first_row','data_last_row','codes')
CSV_KEYS = ('csv_columns','csv_first_row','csv_encoding')

def parser_tag(cfg, filetype):
    if filetype not in ('xlsx','csv'):
        raise ValueError('Unsupported cache filetype: '+str(filetype))
    keys = XLSX_KEYS if filetype=='xlsx' else CSV_KEYS
    payload = {'parser_version':PARSER_VERSION, 'filetype':filetype,
               'settings':{key:cfg[key] for key in keys}}
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',',':'))
    return hashlib.sha256(canonical.encode('utf-8')).hexdigest()
