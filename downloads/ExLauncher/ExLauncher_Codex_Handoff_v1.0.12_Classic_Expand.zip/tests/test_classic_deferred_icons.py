"""Classic first-open must not synchronously query native file icons."""
import unittest
from unittest.mock import patch
from PySide6.QtGui import QIcon, QPixmap, QColor
from PySide6.QtTest import QTest
import test_performance_regressions as perf
import classic_main as classic


class ClassicIconTests(unittest.TestCase):
    write_preset = perf.LauncherTests.write_preset
    write_settings = perf.LauncherTests.write_settings
    window = perf.LauncherTests.window

    def setUp(self):
        perf.LauncherTests.setUp(self)
        pix = QPixmap(16, 16)
        pix.fill(QColor('magenta'))
        self.icon = QIcon(pix)

    def launcher(self, duplicate=False):
        self.write_preset(dict(self.data, categories=[{'name': 'Files', 'items': [
            {'name': f'File {i}', 'type': 'file', 'path': str(self.file if duplicate else self.root/f'{i}.txt')}
            for i in range(20)]}]))
        return self.window(classic.MainWindow)

    def test_open_is_immediate_then_native_icons_update_and_cache(self):
        window = self.launcher(True)
        with patch.object(window.file_icon_provider, 'icon', return_value=self.icon) as native:
            window.main_item_clicked(window.list_widget.item(0))
            native.assert_not_called()
            self.assertEqual(window.list_widget.count(), 21)
            QTest.qWait(50)
            self.assertEqual(native.call_count, 1)
            for i in range(1, 21):
                row = window.list_widget.itemWidget(window.list_widget.item(i))
                self.assertEqual(row.icon_label.pixmap().toImage().pixelColor(7, 7), QColor('magenta'))
            window.main_item_clicked(window.list_widget.item(0))
            window.main_item_clicked(window.list_widget.item(0))
            QTest.qWait(30)
            self.assertEqual(native.call_count, 1)

    def test_collapse_and_rebuild_cancel_stale_rows(self):
        window = self.launcher()
        with patch.object(window.file_icon_provider, 'icon', return_value=self.icon) as native:
            window.main_item_clicked(window.list_widget.item(0))
            window.main_item_clicked(window.list_widget.item(0))
            window._load_next_icon()
            native.assert_not_called()
            window.main_item_clicked(window.list_widget.item(0))
            window.data['categories'][0]['items'] = [{'name': 'New', 'type': 'folder', 'path': str(self.root/'new')}]
            window.refresh_main_list()
            window._load_next_icon()
            self.assertEqual(native.call_count, 1)
            self.assertEqual(native.call_args.args[0].filePath(), str(self.root/'new'))

    def test_refresh_path_hide_resume_failure_and_shutdown(self):
        window = self.launcher()
        window.expanded = {0}
        with patch.object(window.file_icon_provider, 'icon', side_effect=OSError('synthetic')) as native:
            window.refresh_main_list()
            native.assert_not_called()
            window.hide()
            self.assertFalse(window._icon_timer.isActive())
            window._load_next_icon()
            native.assert_not_called()
            window.show()
            window._load_next_icon()
            self.assertEqual(native.call_count, 1)
            row = window.list_widget.itemWidget(window.list_widget.item(1))
            self.assertFalse(row.icon_label.pixmap().isNull())
            window.shutdown_for_switch()
            self.assertFalse(window._icon_timer.isActive())
            self.assertFalse(window._pending_icons)


if __name__ == '__main__':
    unittest.main()
