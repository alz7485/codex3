# -*- coding: utf-8 -*-
"""
ExLauncher
PySide6 / Windows
想定配置:
    C:\\Tools\\PythonTool\\ExLauncher\\
        main.py
        setting.json
        登録情報\
            *.json
"""

import json
import os
import subprocess
import sys
import webbrowser
from pathlib import Path
import copy
import weakref
from shiboken6 import isValid

from PySide6.QtCore import Qt, QPoint, QSize, QFileInfo, Signal, QMimeData, QTimer
from PySide6.QtGui import (
    QPainter, QFont, QAction, QIcon, QPixmap, QColor, QPen, QKeySequence, QShortcut
)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QListWidget, QListWidgetItem, QComboBox, QSpinBox,
    QCheckBox, QRadioButton, QDialogButtonBox, QMessageBox,
    QLineEdit, QTextEdit, QMenu, QSystemTrayIcon, QStyle,
    QAbstractItemView, QFileIconProvider, QSizePolicy, QButtonGroup, QGridLayout, QFrame
)

from app_runtime import (
    SingleInstanceController,
    app_dir,
    get_app_icon,
    restart_via_dispatcher as _restart_app,
)
from file_dialogs import select_files, select_folders
from modern_animation import ANIMATION_SPEED_OPTIONS, normalized_speed
from quick_search import QuickSearchDialog
import exlauncher_storage as storage
from exlauncher_storage import DataFileError, save_transaction, validate_preset_name
from data_recovery import prepare_data, StartupCancelled

# ============================================================
# パス
# ============================================================

# .py実行時はmain.pyの場所、PyInstaller等でexe化した場合はexeの場所を基準にする。
# これにより setting.json / 登録情報 が一時展開フォルダへ保存されるのを防ぐ。
APP_DIR = app_dir(__file__)

PRESET_DIR = APP_DIR / "登録情報"
SETTING_FILE = APP_DIR / "setting.json"

DEFAULT_SETTING = {
    "pin": False,
    "drag_bar_position": "right",
    "allow_multiple_expand": True,
    "current_preset": "",
    "ui_style": "Classic",
    "animation_speed": "normal",
}

THEMES = {
    # Light → Dark → Blue → Green → Warm → Red/Pink → Purple の順。
    "Light": {"control":"#ffffff","category":"#eef2f6","window":"#dfe5eb","border":"#9aa6b2","text":"#33404d","bar":"#1f2933"},
    "Pearl": {"control":"#ffffff","category":"#f3f1ee","window":"#e6e1dc","border":"#aaa19a","text":"#4b4540","bar":"#38312d"},
    "Ice": {"control":"#ffffff","category":"#e7f3f7","window":"#d1e4ea","border":"#8aa5ae","text":"#354f57","bar":"#20373e"},
    "Slate": {"control":"#f8fafc","category":"#e1e7ed","window":"#c8d0d8","border":"#7c8996","text":"#39434d","bar":"#202830"},
    "Silver": {"control":"#f5f6f7","category":"#dfe3e6","window":"#c8cdd1","border":"#81898f","text":"#3c4247","bar":"#292f34"},
    "High Contrast Light": {"control":"#ffffff","category":"#eeeeee","window":"#d8d8d8","border":"#555555","text":"#111111","bar":"#000000"},
    "Dark": {"control":"#3a3f45","category":"#32373d","window":"#292e34","border":"#20252a","text":"#f0f3f5","bar":"#111417"},
    "Dark Gray": {"control":"#464646","category":"#3b3b3b","window":"#303030","border":"#232323","text":"#f2f2f2","bar":"#161616"},
    "Graphite": {"control":"#50545a","category":"#44484e","window":"#383c42","border":"#24272b","text":"#f5f5f5","bar":"#15171a"},
    "Charcoal": {"control":"#41474b","category":"#363c40","window":"#2c3135","border":"#1c2023","text":"#eef2f4","bar":"#101315"},
    "Carbon": {"control":"#373b40","category":"#2e3237","window":"#25292e","border":"#191d21","text":"#f4f6f8","bar":"#0e1114"},
    "High Contrast Dark": {"control":"#2f2f2f","category":"#242424","window":"#181818","border":"#ffffff","text":"#ffffff","bar":"#000000"},
    "Midnight": {"control":"#333d53","category":"#293349","window":"#20293b","border":"#171e2b","text":"#f5f7ff","bar":"#0d111b"},
    "Navy": {"control":"#3a465a","category":"#303b4d","window":"#263142","border":"#1a2433","text":"#f2f5fb","bar":"#101827"},
    "Blue": {"control":"#f7fbff","category":"#dcecff","window":"#bfd7f2","border":"#6f99c5","text":"#24486b","bar":"#16324a"},
    "Ocean": {"control":"#f5fbff","category":"#d5eaf5","window":"#b3d2e2","border":"#5f8da5","text":"#28516a","bar":"#123246"},
    "Sky": {"control":"#fbfdff","category":"#e0effb","window":"#c3dced","border":"#7297b1","text":"#31526a","bar":"#183548"},
    "Cyan": {"control":"#f7ffff","category":"#d7f1f6","window":"#b7dfe8","border":"#6095a1","text":"#28545e","bar":"#12343c"},
    "Aqua": {"control":"#f6ffff","category":"#d8f2ef","window":"#b7ded9","border":"#61958e","text":"#28554f","bar":"#113630"},
    "Teal": {"control":"#f8ffff","category":"#dcefed","window":"#bfdbd8","border":"#6e9995","text":"#315b57","bar":"#173b38"},
    "Turquoise": {"control":"#f5fffd","category":"#d4f0e9","window":"#b2dcd1","border":"#5f9687","text":"#28584d","bar":"#11382f"},
    "Emerald": {"control":"#f7fff9","category":"#d9f0e1","window":"#b8dbc4","border":"#649477","text":"#2d5c3e","bar":"#153a25"},
    "Green": {"control":"#fbfffb","category":"#e0f1e0","window":"#c3dec3","border":"#789d78","text":"#365b36","bar":"#1d3820"},
    "Forest": {"control":"#3f5146","category":"#34463b","window":"#293a31","border":"#1a2820","text":"#eef7f0","bar":"#101b14"},
    "Mint": {"control":"#fbfffd","category":"#def3e8","window":"#c0dfd0","border":"#729b85","text":"#355c48","bar":"#19392a"},
    "Lime": {"control":"#fdfff5","category":"#e8f3cd","window":"#cfdfa6","border":"#849a54","text":"#4e6127","bar":"#2c3b15"},
    "Olive": {"control":"#fdfdf6","category":"#ecebd2","window":"#d7d4ad","border":"#8c8959","text":"#56542c","bar":"#313019"},
    "Gold": {"control":"#fffdf5","category":"#f3e8c4","window":"#dfca8e","border":"#a0873d","text":"#66531b","bar":"#3e310d"},
    "Amber": {"control":"#fffdf3","category":"#f4ebc7","window":"#dfd093","border":"#9e8a3e","text":"#63551e","bar":"#3d3410"},
    "Orange": {"control":"#fffaf4","category":"#f3e1c9","window":"#dfc49f","border":"#a77b44","text":"#68471f","bar":"#422a10"},
    "Coral": {"control":"#fff9f6","category":"#f5ddd2","window":"#e3bfae","border":"#aa7460","text":"#6b3d2e","bar":"#452219"},
    "Coffee": {"control":"#fdfaf7","category":"#eadfd5","window":"#d0bca9","border":"#8f725a","text":"#5b4432","bar":"#352419"},
    "Sepia": {"control":"#fffdf7","category":"#eee7d5","window":"#d8cdb2","border":"#8d8061","text":"#554d39","bar":"#302b1e"},
    "Red": {"control":"#fffafa","category":"#f4dddd","window":"#dfbfc0","border":"#a26f70","text":"#6a3334","bar":"#431d1e"},
    "Wine": {"control":"#544047","category":"#48343b","window":"#3b2930","border":"#271a1f","text":"#fff3f6","bar":"#180e12"},
    "Rose": {"control":"#fffafa","category":"#f5e0e7","window":"#e4c3cf","border":"#a77888","text":"#633b49","bar":"#3f202a"},
    "Sakura": {"control":"#fffdfd","category":"#f8e7ec","window":"#eccfd8","border":"#ad7f8d","text":"#68424e","bar":"#44252e"},
    "Magenta": {"control":"#fff8fe","category":"#f1d8ec","window":"#ddb6d5","border":"#a36897","text":"#67345e","bar":"#421d3b"},
    "Purple": {"control":"#fcf9ff","category":"#eadff6","window":"#d3c0e6","border":"#9275ae","text":"#4b3262","bar":"#2d1c3c"},
    "Violet": {"control":"#fbf9ff","category":"#e5dff5","window":"#cbc0e3","border":"#8575aa","text":"#453765","bar":"#28203e"},
    "Lavender": {"control":"#fefcff","category":"#eee6f7","window":"#d9cbe8","border":"#927fab","text":"#524166","bar":"#30233f"},
}




def restart_via_dispatcher():
    _restart_app(APP_DIR)


# ============================================================
# JSON
# ============================================================

def save_json(path, data):
    storage.save_json(path, data)


def load_json(path, default):
    return storage.load_json(path, default)


def ensure_files():
    """共通設定と最低1つのプリセットをアプリ本体の横へ必ず用意する。"""
    PRESET_DIR.mkdir(parents=True, exist_ok=True)
    storage.recover_pending(APP_DIR)
    storage.recover_pending(PRESET_DIR)

    # 旧版で setting.json に保存していた theme / ui_width は、
    # 各プリセットJSONへ一度だけ移行する。
    settings = load_json(SETTING_FILE, {}) if SETTING_FILE.exists() else {}
    original_settings = settings.copy()
    legacy_width = int(settings.pop("ui_width", 200) or 200)
    legacy_theme = settings.pop("theme", "Dark Gray") or "Dark Gray"

    for key, value in DEFAULT_SETTING.items():
        settings.setdefault(key, value)

    preset_files = list(PRESET_DIR.glob("*.json"))

    if not preset_files:
        preset_path = PRESET_DIR / "date.json"
        save_json(
            preset_path,
            {
                "ui_width": 200,
                "theme": "Dark Gray",
                "categories": [
                    {"name": "新規カテゴリ", "items": []}
                ]
            }
        )
        preset_files = [preset_path]
        settings["current_preset"] = preset_path.name

    # 既存プリセットには旧共通値を引き継ぐ。
    loaded = [(path, load_json(path, {"categories": []})) for path in preset_files]
    for preset_path, data in loaded:
        changed = False

        if "ui_width" not in data:
            data["ui_width"] = legacy_width
            changed = True
        if "theme" not in data:
            data["theme"] = legacy_theme if legacy_theme in THEMES else "Dark Gray"
            changed = True
        if "categories" not in data:
            data["categories"] = []
            changed = True

        if changed:
            save_json(preset_path, data)

    # theme / ui_width を除いた共通設定だけ保存する。
    if not SETTING_FILE.exists() or settings != original_settings:
        save_json(SETTING_FILE, settings)



def unique_name(existing, base):
    if base not in existing:
        return base

    n = 2
    while f"{base}_{n}" in existing:
        n += 1

    return f"{base}_{n}"


# ============================================================
# テーマ
# ============================================================

def theme_style(theme_name):
    t = THEMES.get(theme_name, THEMES["Dark Gray"])

    return f"""
    QWidget {{
        background: {t["window"]};
        color: {t["text"]};
    }}

    QLabel {{
        background: {t["window"]};
        color: {t["text"]};
        border: none;
    }}

    QListWidget, QListView, QTreeView, QTableView,
    QLineEdit, QTextEdit, QComboBox, QSpinBox {{
        background: {t["control"]};
        color: {t["text"]};
        border: 1px solid {t["border"]};
    }}

    /* チェックボックス本体を入力欄のような枠で囲まない。
       indicator はQt/Windows標準描画を残して視認性を優先する。 */
    QCheckBox {{
        background: transparent;
        color: {t["text"]};
        border: none;
        spacing: 7px;
        padding-left: 2px;
    }}

    QCheckBox::indicator {{
        width: 17px;
        height: 17px;
    }}

    QListWidget::item:selected, QListView::item:selected, QTreeView::item:selected {{
        background: {t["category"]};
        color: {t["text"]};
    }}

    QListWidget::item, QListView::item, QTreeView::item {{
        color: {t["text"]};
    }}

    QHeaderView::section {{
        background: {t["category"]};
        color: {t["text"]};
        border: none;
        border-right: 1px solid {t["border"]};
        border-bottom: 1px solid {t["border"]};
        padding: 3px 5px;
    }}

    QPushButton {{
        background: {t["control"]};
        color: {t["text"]};
        border: 1px solid {t["border"]};
        padding: 1px 5px;
    }}

    QPushButton:hover {{
        background: {t["category"]};
    }}

    /* 排他的トグルなどのON状態は、テーマに関係なく明確に判別できるよう
       最も濃いbar色を使用する。 */
    QPushButton:checked {{
        background: {t["bar"]};
        color: #ffffff;
        border: 2px solid {t["text"]};
        font-weight: 700;
    }}

    QPushButton:checked:hover {{
        background: {t["bar"]};
        color: #ffffff;
    }}

    QComboBox {{
        padding-left: 6px;
    }}

    QComboBox QAbstractItemView {{
        background: {t["control"]};
        color: {t["text"]};
        selection-background-color: {t["category"]};
    }}

    QPushButton, QComboBox, QListWidget, QListView, QTreeView, QTableView,
    QLineEdit, QTextEdit, QSpinBox {{
        border-radius: 2px;
    }}
    """



# ============================================================
# メインUI 行ウィジェット
# ============================================================

class ElidedLabel(QLabel):
    """幅に収まらない文字列を右側 ... で省略表示するラベル。"""

    def __init__(self, text="", parent=None):
        super().__init__(parent)
        self._full_text = text
        self.setToolTip(text)
        self.setMinimumWidth(0)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

    def setFullText(self, text):
        self._full_text = text or ""
        self.setToolTip(self._full_text)
        self._update_elided()

    def fullText(self):
        return self._full_text

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_elided()

    def showEvent(self, event):
        super().showEvent(event)
        self._update_elided()

    def _update_elided(self):
        width = max(0, self.contentsRect().width())
        text = self.fontMetrics().elidedText(
            self._full_text, Qt.TextElideMode.ElideRight, width
        )
        QLabel.setText(self, text)


class MainRowWidget(QFrame):
    CATEGORY_HEIGHT = 26
    ITEM_HEIGHT = 24

    def __init__(
        self,
        row_type,
        text,
        theme,
        icon=None,
        expanded=False,
        icon_text=None,
        parent=None
    ):
        super().__init__(parent)

        self.row_type = row_type
        self.theme_name = theme

        # setItemWidget上でもQListWidget側がクリックを処理できるようにする。
        self.setAttribute(
            Qt.WidgetAttribute.WA_TransparentForMouseEvents,
            True
        )

        t = THEMES.get(theme, THEMES["Dark Gray"])

        if row_type == "category":
            background = t["category"]
            height = self.CATEGORY_HEIGHT
            left_margin = 4
        else:
            background = t["control"]
            height = self.ITEM_HEIGHT
            left_margin = 15

        self.setFixedHeight(height)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setObjectName(
            "categoryRow" if row_type == "category" else "itemRow"
        )

        # setItemWidgetの各行自身に背景色と枠線を直接指定。
        # QListWidget本体のスタイルに依存しないようにする。
        self.setStyleSheet(
            f"""
            QFrame#{self.objectName()} {{
                background-color: {background};
                border: 1px solid {t['border']};
                border-radius: 2px;
            }}
            QFrame#{self.objectName()} QLabel {{
                background-color: transparent;
                border: none;
                color: {t['text']};
            }}
            """
        )

        layout = QHBoxLayout(self)
        layout.setContentsMargins(left_margin, 0, 4, 0)
        layout.setSpacing(4)

        if row_type != "category":
            self.icon_label = QLabel()
            self.icon_label.setFixedSize(18, 18)
            self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

            if icon_text is not None:
                self.icon_label.setText(icon_text)
            elif icon is not None and not icon.isNull():
                self.icon_label.setPixmap(icon.pixmap(QSize(16, 16)))

            layout.addWidget(self.icon_label)

        self.text_label = ElidedLabel(text)
        self.text_label.setAlignment(
            Qt.AlignmentFlag.AlignVCenter |
            Qt.AlignmentFlag.AlignLeft
        )

        # メインUIのカテゴリ名だけ太字にする。
        if row_type == "category":
            font = self.text_label.font()
            font.setBold(True)
            self.text_label.setFont(font)

        layout.addWidget(self.text_label, 1)


# ============================================================
# 名前編集
# ============================================================

class NameDialog(QDialog):

    def __init__(self, title, name="", parent=None):
        super().__init__(parent)

        self.setWindowTitle(title)
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        self.resize(350, 120)

        self.edit = QLineEdit(name)
        self.edit.selectAll()

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )

        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("名前"))
        layout.addWidget(self.edit)
        layout.addWidget(buttons)

    def value(self):
        return self.edit.text().strip()


# ============================================================
# アイテム編集
# ============================================================

class ItemEditDialog(QDialog):

    def __init__(self, item, parent=None):
        super().__init__(parent)

        self.original = dict(item)

        self.setWindowTitle("アイテム編集")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        item_type = item.get("type")
        self.resize(520, 310 if item_type == "text" else 155)
        self.setMinimumWidth(460)

        self.name_edit = QLineEdit(item.get("name", ""))
        self.path_edit = QLineEdit(item.get("path", ""))
        self.url_edit = QLineEdit(item.get("url", ""))

        # 定型文は必ずプレーンテキストとして読み込む。
        # QTextEdit(text) / setText() は内容を自動判定するため、
        # 保存済みの改行が編集画面で空白へ変換される場合がある。
        self.text_edit = QTextEdit()
        self.text_edit.setAcceptRichText(False)
        self.text_edit.setPlainText(item.get("text", ""))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 10)
        layout.setSpacing(7)

        layout.addWidget(QLabel("名前"))
        layout.addWidget(self.name_edit)

        if item_type in ("file", "folder"):
            layout.addWidget(QLabel("パス"))
            layout.addWidget(self.path_edit)

        elif item_type == "web":
            layout.addWidget(QLabel("Webページ"))
            layout.addWidget(self.url_edit)

        elif item_type == "text":
            layout.addWidget(QLabel("定型文"))
            layout.addWidget(self.text_edit)
            self.text_edit.setMinimumHeight(150)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )

        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout.addWidget(buttons)

    def value(self):
        result = dict(self.original)

        result["name"] = self.name_edit.text().strip()

        if result.get("type") in ("file", "folder"):
            result["path"] = self.path_edit.text()

        elif result.get("type") == "web":
            result["url"] = self.url_edit.text()

        elif result.get("type") == "text":
            result["text"] = self.text_edit.toPlainText()

        return result


# ============================================================
# 登録管理用リスト
# ============================================================

class RegistrationList(QListWidget):

    dragStarted = Signal(object)
    crossDropped = Signal(object, object, QPoint)

    def __init__(self, owner, kind):
        super().__init__()

        self.owner = owner
        self.kind = kind

        self.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection
        )

        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        # 同一リスト内の並べ替えと、別リストへの移動の両方を許可する。
        self.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)

        self.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )

    def mousePressEvent(self, event):
        # 空白部をクリックしても現在の選択を解除しない。
        if event.button() == Qt.MouseButton.LeftButton and self.itemAt(event.position().toPoint()) is None:
            event.accept()
            return
        super().mousePressEvent(event)

    def startDrag(self, supportedActions):
        self.dragStarted.emit(self)
        super().startDrag(Qt.DropAction.MoveAction)

    def dragEnterEvent(self, event):
        source = event.source()

        # Windows Explorer等からファイル/フォルダをアイテムリストへ直接D&D。
        if self.kind == "item" and event.mimeData().hasUrls():
            event.acceptProposedAction()
            return

        if source is self:
            event.acceptProposedAction()
            return

        if (
            isinstance(source, RegistrationList)
            and (
                (source.kind == "item" and self.kind == "category")
                or (source.kind == "category" and self.kind == "preset")
            )
        ):
            event.setDropAction(Qt.DropAction.MoveAction)
            event.accept()
            return

        event.ignore()

    def dragMoveEvent(self, event):
        source = event.source()

        if self.kind == "item" and event.mimeData().hasUrls():
            event.acceptProposedAction()
            return

        if source is self:
            event.acceptProposedAction()
            return

        if (
            isinstance(source, RegistrationList)
            and (
                (source.kind == "item" and self.kind == "category")
                or (source.kind == "category" and self.kind == "preset")
            )
        ):
            event.setDropAction(Qt.DropAction.MoveAction)
            event.accept()
            return

        event.ignore()

    def dropEvent(self, event):
        source = event.source()

        # 外部ファイル/フォルダ。
        if self.kind == "item" and event.mimeData().hasUrls() and not isinstance(source, RegistrationList):
            paths = []
            for url in event.mimeData().urls():
                if url.isLocalFile():
                    paths.append(url.toLocalFile())
            if paths:
                self.owner.external_paths_dropped(paths)
                event.acceptProposedAction()
                return

        if source is not None and source is not self:
            self.crossDropped.emit(source, self, event.position().toPoint())
            self.owner.drag_source = None
            event.setDropAction(Qt.DropAction.MoveAction)
            event.accept()
            return

        super().dropEvent(event)
        self.owner.internal_reordered(self)
        self.owner.drag_source = None



# ============================================================
# 設定ダイアログ
# ============================================================

class SettingsDialog(QDialog):

    ROW_H = 28

    def __init__(self, settings, parent=None):
        super().__init__(parent)

        self.setWindowTitle("設定")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)

        self.width_spin = QSpinBox()
        self.width_spin.setRange(160, 1200)
        self.width_spin.setValue(int(settings.get("ui_width", 200)))

        self.multi_check = QCheckBox("複数カテゴリの展開を許可")
        self.multi_check.setChecked(bool(settings.get("allow_multiple_expand", True)))

        self.pin_check = QCheckBox("起動後もメインUIを表示したままにする（ピン）")
        self.pin_check.setChecked(bool(settings.get("pin", False)))

        self.animation_combo = QComboBox()
        for label, value in ANIMATION_SPEED_OPTIONS:
            self.animation_combo.addItem(label, value)
        animation_index = self.animation_combo.findData(
            normalized_speed(settings.get("animation_speed", "normal"))
        )
        self.animation_combo.setCurrentIndex(max(0, animation_index))

        # 左右はラジオボタンではなく、排他的なトグルボタンにする。
        self.left_button = QPushButton("左")
        self.right_button = QPushButton("右")
        self.left_button.setToolTip("ドラッグバーをメインUIの左側に配置")
        self.right_button.setToolTip("ドラッグバーをメインUIの右側に配置")
        self.left_button.setCheckable(True)
        self.right_button.setCheckable(True)
        self.position_group = QButtonGroup(self)
        self.position_group.setExclusive(True)
        self.position_group.addButton(self.left_button)
        self.position_group.addButton(self.right_button)
        if settings.get("drag_bar_position") == "left":
            self.left_button.setChecked(True)
        else:
            self.right_button.setChecked(True)

        self.theme_combo = QComboBox()
        # Classicテーマの一覧にも、テーマ名の左側へ配色サンプルを表示する。
        # 既存テーマ自体の色・保存仕様は変更しない。
        for theme_name, colors in THEMES.items():
            pix = QPixmap(42, 16)
            pix.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pix)
            sample_colors = (
                colors.get("bar", "#000000"),
                colors.get("window", "#808080"),
                colors.get("category", "#a0a0a0"),
                colors.get("control", "#ffffff"),
            )
            segment_w = pix.width() / len(sample_colors)
            for i, color in enumerate(sample_colors):
                x1 = round(i * segment_w)
                x2 = round((i + 1) * segment_w)
                painter.fillRect(x1, 0, x2 - x1, pix.height(), QColor(color))
            painter.setPen(QColor(colors.get("border", "#666666")))
            painter.drawRect(0, 0, pix.width() - 1, pix.height() - 1)
            painter.end()
            self.theme_combo.addItem(QIcon(pix), theme_name)
        self.theme_combo.setIconSize(QSize(42, 16))
        self.theme_combo.setCurrentText(settings.get("theme", "Dark Gray"))
        self.theme_combo.currentTextChanged.connect(self.preview_theme)

        # UIスタイル。Classic本体では設定値を保存し、
        # Modern側/起動ディスパッチャから同じsetting.jsonを参照できるようにする。
        self.ui_style_combo = QComboBox()
        self.ui_style_combo.addItems(["Classic", "Modern"])
        self.ui_style_combo.setCurrentText(settings.get("ui_style", "Classic"))

        # 各入力行の縦幅を統一。
        for w in (self.width_spin, self.multi_check, self.pin_check,
                  self.left_button, self.right_button, self.theme_combo,
                  self.ui_style_combo, self.animation_combo):
            w.setFixedHeight(self.ROW_H)

        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(5)
        grid.setColumnStretch(1, 1)

        width_label = QLabel("メインUI横幅")
        pos_label = QLabel("ドラッグエリアの配置")
        theme_label = QLabel("カラーテーマ")
        animation_label = QLabel("Modernアニメーション")
        ui_style_label = QLabel("UIスタイル")
        for lab in (width_label, pos_label, theme_label, animation_label, ui_style_label):
            lab.setFixedHeight(self.ROW_H)
            lab.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)

        grid.addWidget(width_label, 0, 0)
        grid.addWidget(self.width_spin, 0, 1)
        grid.addWidget(self.multi_check, 1, 0, 1, 2)
        grid.addWidget(self.pin_check, 2, 0, 1, 2)
        grid.addWidget(pos_label, 3, 0)

        pos_box = QWidget()
        pos_layout = QHBoxLayout(pos_box)
        pos_layout.setContentsMargins(0, 0, 0, 0)
        pos_layout.setSpacing(4)
        pos_layout.addWidget(self.left_button)
        pos_layout.addWidget(self.right_button)
        grid.addWidget(pos_box, 3, 1)

        grid.addWidget(animation_label, 4, 0)
        grid.addWidget(self.animation_combo, 4, 1)

        grid.addWidget(theme_label, 5, 0)
        grid.addWidget(self.theme_combo, 5, 1)

        grid.addWidget(ui_style_label, 6, 0)
        grid.addWidget(self.ui_style_combo, 6, 1)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.setFixedHeight(self.ROW_H)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(7)
        layout.addLayout(grid)
        layout.addWidget(buttons)

        self.preview_theme(self.theme_combo.currentText())
        self.adjustSize()
        self.setFixedSize(self.sizeHint())

    def preview_theme(self, theme):
        self.setStyleSheet(theme_style(theme))

    def values(self):
        return {
            "ui_width": self.width_spin.value(),
            "allow_multiple_expand": self.multi_check.isChecked(),
            "pin": self.pin_check.isChecked(),
            "drag_bar_position": "left" if self.left_button.isChecked() else "right",
            "animation_speed": self.animation_combo.currentData(),
            "theme": self.theme_combo.currentText(),
            "ui_style": self.ui_style_combo.currentText(),
        }


# ============================================================
# 登録ダイアログ
# ============================================================

class RegistrationDialog(QDialog):

    def __init__(self, main_window):
        super().__init__(main_window)

        self.main = main_window
        self.drag_source = None
        self.drag_context = {}

        self.setWindowTitle(
            "プリセット・カテゴリ・アイテム管理"
        )
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        self.resize(1050, 650)

        # ----------------------------------------
        # リスト
        # ----------------------------------------

        self.preset_list = RegistrationList(
            self, "preset"
        )

        self.category_list = RegistrationList(
            self, "category"
        )

        self.item_list = RegistrationList(
            self, "item"
        )

        for widget in (
            self.preset_list,
            self.category_list,
            self.item_list
        ):
            widget.dragStarted.connect(
                self.set_drag_source
            )
            widget.crossDropped.connect(
                self.cross_drop
            )

            widget.setContextMenuPolicy(
                Qt.ContextMenuPolicy.CustomContextMenu
            )
            widget.customContextMenuRequested.connect(
                self.context_menu
            )

        self.preset_list.itemSelectionChanged.connect(
            self.preset_selection_changed
        )

        self.category_list.itemSelectionChanged.connect(
            self.category_selection_changed
        )

        # ----------------------------------------
        # プリセット
        # ----------------------------------------

        self.preset_add = QPushButton("+📚")
        self.preset_delete = QPushButton("🗑️")
        self.preset_add.setToolTip("プリセットを追加")
        self.preset_delete.setToolTip("選択したプリセットを削除")

        self.preset_add.clicked.connect(
            self.add_preset
        )
        self.preset_delete.clicked.connect(
            self.delete_presets
        )

        # ----------------------------------------
        # カテゴリ
        # ----------------------------------------

        self.category_add = QPushButton("+📗")
        self.category_delete = QPushButton("🗑️")
        self.category_add.setToolTip("カテゴリを追加")
        self.category_delete.setToolTip("選択したカテゴリを削除")

        self.category_add.clicked.connect(
            self.add_category
        )
        self.category_delete.clicked.connect(
            self.delete_categories
        )

        # ----------------------------------------
        # アイテム
        # ----------------------------------------

        self.file_add = QPushButton("+📃")
        self.folder_add = QPushButton("+📁")
        self.text_add = QPushButton("+📋")
        self.web_add = QPushButton("+🌎")
        self.separator_add = QPushButton("🔖")
        self.item_delete = QPushButton("🗑️")
        self.file_add.setToolTip("ファイルを追加")
        self.folder_add.setToolTip("フォルダを追加")
        self.text_add.setToolTip("クリップボード用テキストを追加")
        self.web_add.setToolTip("Webページを追加")
        self.separator_add.setToolTip("仕切りを追加")
        self.item_delete.setToolTip("選択したアイテムを削除")

        self.file_add.clicked.connect(
            self.add_file
        )
        self.folder_add.clicked.connect(
            self.add_folder
        )
        self.text_add.clicked.connect(
            self.add_text
        )
        self.web_add.clicked.connect(
            self.add_web
        )
        self.separator_add.clicked.connect(
            self.add_separator
        )
        self.item_delete.clicked.connect(
            self.delete_items
        )

        # ----------------------------------------
        # 3分割
        # ----------------------------------------

        columns = QHBoxLayout()

        columns.addLayout(
            self.make_column(
                "プリセット",
                [
                    self.preset_add,
                    self.preset_delete
                ],
                self.preset_list
            ),
            1
        )

        columns.addLayout(
            self.make_column(
                "カテゴリ",
                [
                    self.category_add,
                    self.category_delete
                ],
                self.category_list
            ),
            1
        )

        columns.addLayout(
            self.make_column(
                "アイテム",
                [
                    self.file_add,
                    self.folder_add,
                    self.text_add,
                    self.web_add,
                    self.separator_add,
                    self.item_delete
                ],
                self.item_list
            ),
            2
        )

        layout = QVBoxLayout(self)
        layout.addLayout(columns)

        self.reload_presets()

    def make_column(self, title, buttons, list_widget):
        layout = QVBoxLayout()

        header = QHBoxLayout()

        label = QLabel(title)
        label.setFixedHeight(24)
        # 管理UIの見出しラベルはウィンドウ背景と同じ。
        label.setStyleSheet("background: transparent; border: none;")
        header.addWidget(label)

        for button in buttons:
            button.setFixedHeight(24)
            header.addWidget(button)

        header.addStretch()

        layout.addLayout(header)
        layout.addWidget(list_widget)

        return layout

    # ========================================================
    # 共通
    # ========================================================

    def set_drag_source(self, widget):
        self.drag_source = widget
        self.drag_context = {"kind": widget.kind}

        # ドラッグ開始時点の親・選択インデックスを保存する。
        # ドロップ先へマウスを移動したときにselectionが変わっても、
        # 移動元を見失わないようにするため。
        if widget is self.item_list:
            preset_path = self.current_preset_path()
            category_index = self.current_category_index()
            self.drag_context.update({
                "preset_path": str(preset_path) if preset_path else "",
                "category_index": category_index,
                "indices": sorted(
                    [i.data(Qt.ItemDataRole.UserRole) for i in self.item_list.selectedItems()]
                ),
            })

        elif widget is self.category_list:
            preset_path = self.current_preset_path()
            self.drag_context.update({
                "preset_path": str(preset_path) if preset_path else "",
                "indices": sorted(
                    [i.data(Qt.ItemDataRole.UserRole) for i in self.category_list.selectedItems()]
                ),
            })

    def selected_preset_items(self):
        return self.preset_list.selectedItems()

    def selected_category_items(self):
        return self.category_list.selectedItems()

    def selected_item_items(self):
        return self.item_list.selectedItems()

    def current_preset_path(self):
        selected = self.selected_preset_items()

        if len(selected) != 1:
            return None

        return Path(
            selected[0].data(Qt.ItemDataRole.UserRole)
        )

    def current_category_index(self):
        selected = self.selected_category_items()

        if len(selected) != 1:
            return None

        return selected[0].data(Qt.ItemDataRole.UserRole)

    def load_current_preset(self):
        path = self.current_preset_path()

        if not path:
            return {"categories": []}

        data = load_json(
            path,
            {"categories": []}
        )

        data.setdefault("categories", [])

        return data

    def save_current_preset(self, data):
        path = self.current_preset_path()

        if path:
            save_json(path, data)

    # ========================================================
    # プリセット
    # ========================================================

    def reload_presets(self):
        ensure_files()
        current = self.main.settings.get(
            "current_preset", ""
        )

        self.preset_list.clear()

        files = sorted(
            PRESET_DIR.glob("*.json"),
            key=lambda x: x.name.lower()
        )

        target_row = -1

        for row, path in enumerate(files):
            item = QListWidgetItem(path.stem)

            item.setData(
                Qt.ItemDataRole.UserRole,
                str(path)
            )

            self.preset_list.addItem(item)

            if (
                current and
                Path(current).name == path.name
            ):
                target_row = row

        if self.preset_list.count():
            if target_row < 0:
                target_row = 0

            self.preset_list.setCurrentRow(
                target_row
            )

        else:
            self.category_list.clear()
            self.item_list.clear()

        self.refresh_categories()

    def preset_selection_changed(self):
        selected = self.preset_list.selectedItems()

        if len(selected) != 1:
            self.category_list.clear()
            self.item_list.clear()
            return

        path = Path(
            selected[0].data(Qt.ItemDataRole.UserRole)
        )

        self.main.settings["current_preset"] = path.name
        save_json(
            SETTING_FILE,
            self.main.settings
        )

        self.refresh_categories()

    def add_preset(self):
        names = [
            p.stem
            for p in PRESET_DIR.glob("*.json")
        ]

        name = unique_name(
            names,
            "新規プリセット"
        )

        path = PRESET_DIR / f"{name}.json"

        # プリセット新規作成時はデフォルト構造。
        save_json(
            path,
            {
                "ui_width": int(self.main.data.get("ui_width", 200)),
                "theme": self.main.data.get("theme", "Dark Gray"),
                "categories": [
                    {"name": "新規カテゴリ", "items": []}
                ]
            }
        )

        self.reload_presets()

        for row in range(
            self.preset_list.count()
        ):
            item = self.preset_list.item(row)

            if item.data(Qt.ItemDataRole.UserRole) == str(path):
                self.preset_list.setCurrentRow(row)
                break

    def delete_presets(self):
        selected = self.preset_list.selectedItems()

        if not selected:
            return

        answer = QMessageBox.question(
            self,
            "確認",
            f"{len(selected)}個のプリセットを削除しますか？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if answer != QMessageBox.StandardButton.Yes:
            return

        for item in selected:
            try:
                Path(
                    item.data(Qt.ItemDataRole.UserRole)
                ).unlink()
            except Exception:
                pass

        self.reload_presets()

    # ========================================================
    # カテゴリ
    # ========================================================

    def refresh_categories(self):
        self.category_list.clear()
        self.item_list.clear()

        selected = self.preset_list.selectedItems()

        if len(selected) != 1:
            return

        data = self.load_current_preset()

        for index, category in enumerate(
            data.get("categories", [])
        ):
            item = QListWidgetItem(
                category.get(
                    "name",
                    "名称未設定"
                )
            )

            item.setData(
                Qt.ItemDataRole.UserRole,
                index
            )

            self.category_list.addItem(item)

        if self.category_list.count() > 0:
            self.category_list.setCurrentRow(0)
        else:
            self.refresh_items()

    def category_selection_changed(self):
        selected = self.category_list.selectedItems()

        if len(selected) != 1:
            self.item_list.clear()
            return

        self.refresh_items()

    def add_category(self):
        if len(self.preset_list.selectedItems()) != 1:
            return

        data = self.load_current_preset()

        names = [
            c.get("name", "")
            for c in data["categories"]
        ]

        data["categories"].append(
            {
                "name": unique_name(
                    names,
                    "新しいカテゴリ"
                ),
                "items": []
            }
        )

        self.save_current_preset(data)

        self.refresh_categories()

        self.category_list.setCurrentRow(
            self.category_list.count() - 1
        )

    def delete_categories(self):
        selected = self.category_list.selectedItems()

        if not selected:
            return

        answer = QMessageBox.question(
            self,
            "確認",
            f"{len(selected)}個のカテゴリを削除しますか？\n"
            "カテゴリ内のアイテムも削除されます。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if answer != QMessageBox.StandardButton.Yes:
            return

        data = self.load_current_preset()

        indices = sorted(
            [
                item.data(Qt.ItemDataRole.UserRole)
                for item in selected
            ],
            reverse=True
        )

        for index in indices:
            if 0 <= index < len(
                data["categories"]
            ):
                data["categories"].pop(index)

        self.save_current_preset(data)

        self.refresh_categories()

    # ========================================================
    # アイテム
    # ========================================================

    def refresh_items(self):
        self.item_list.clear()

        selected_preset = (
            self.preset_list.selectedItems()
        )
        selected_category = (
            self.category_list.selectedItems()
        )

        # 複数選択時は子リストを表示しない。
        if len(selected_preset) != 1:
            return

        if len(selected_category) != 1:
            return

        data = self.load_current_preset()

        category_index = (
            selected_category[0].data(
                Qt.ItemDataRole.UserRole
            )
        )

        categories = data.get(
            "categories",
            []
        )

        if not (
            0 <= category_index <
            len(categories)
        ):
            return

        items = categories[
            category_index
        ].get("items", [])

        for index, obj in enumerate(items):
            name = obj.get("name", "")
            item_type = obj.get("type")

            if item_type == "separator":
                if name:
                    text = f"──── {name} ────"
                else:
                    text = "────────────"

            else:
                text = name

            widget_item = QListWidgetItem(text)

            widget_item.setData(
                Qt.ItemDataRole.UserRole,
                index
            )

            self.item_list.addItem(
                widget_item
            )

        # アイテムが存在する場合は必ず何か1件を選択状態にする。
        if self.item_list.count() > 0 and not self.item_list.selectedItems():
            self.item_list.setCurrentRow(0)

    def add_item(self, obj):
        if len(self.preset_list.selectedItems()) != 1:
            return

        if len(self.category_list.selectedItems()) != 1:
            return

        data = self.load_current_preset()

        category_index = (
            self.category_list.selectedItems()[0]
            .data(Qt.ItemDataRole.UserRole)
        )

        categories = data["categories"]

        if not (
            0 <= category_index <
            len(categories)
        ):
            return

        categories[
            category_index
        ].setdefault("items", []).append(obj)

        self.save_current_preset(data)
        self.refresh_items()

    def external_paths_dropped(self, paths):
        """Explorer等から直接ドロップされたファイル/フォルダを登録する。"""
        if len(self.preset_list.selectedItems()) != 1:
            return
        if len(self.category_list.selectedItems()) != 1:
            return

        data = self.load_current_preset()
        category_index = self.current_category_index()
        if category_index is None or not (0 <= category_index < len(data.get("categories", []))):
            return

        items = data["categories"][category_index].setdefault("items", [])
        changed = False
        for raw in paths:
            path = Path(raw)
            if path.is_dir():
                items.append({"name": path.name, "type": "folder", "path": str(path)})
                changed = True
            elif path.is_file():
                items.append({"name": path.name, "type": "file", "path": str(path)})
                changed = True

        if changed:
            self.save_current_preset(data)
            self.refresh_items()

    def add_file(self):
        self.external_paths_dropped(
            select_files(self, "ファイルを追加")
        )

    def add_folder(self):
        self.external_paths_dropped(
            select_folders(self, "フォルダを追加")
        )

    def add_text(self):
        dlg = ItemEditDialog(
            {
                "name": "新しい定型文",
                "type": "text",
                "text": ""
            },
            self
        )

        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.add_item(dlg.value())

    def add_web(self):
        dlg = ItemEditDialog(
            {
                "name": "新しいWebページ",
                "type": "web",
                "url": ""
            },
            self
        )

        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.add_item(dlg.value())

    def add_separator(self):
        self.add_item(
            {
                "name": "",
                "type": "separator"
            }
        )

    def delete_items(self):
        selected = self.item_list.selectedItems()

        if not selected:
            return

        data = self.load_current_preset()

        selected_categories = (
            self.category_list.selectedItems()
        )

        if len(selected_categories) != 1:
            return

        category_index = (
            selected_categories[0]
            .data(Qt.ItemDataRole.UserRole)
        )

        items = data["categories"][
            category_index
        ].setdefault("items", [])

        indices = sorted(
            [
                item.data(Qt.ItemDataRole.UserRole)
                for item in selected
            ],
            reverse=True
        )

        for index in indices:
            if 0 <= index < len(items):
                items.pop(index)

        self.save_current_preset(data)
        self.refresh_items()

    # ========================================================
    # 内部並べ替え
    # ========================================================

    def internal_reordered(self, widget):
        if widget is self.preset_list:
            self.reorder_presets()
            return

        if widget is self.category_list:
            self.reorder_categories()
            return

        if widget is self.item_list:
            self.reorder_items()
            return

    def reorder_presets(self):
        """
        ファイルシステム上のJSONファイルには通常の順序がないため、
        プリセットリストについては別途 setting.json に順序を持たせず、
        JSONファイル名自体を並べ替え順として扱う方式ではなく、
        現在の仕様上「表示順」はファイル名順。

        ただし、ユーザーがドラッグした場合に名前だけ変えず
        内容も追随する必要があるため、ここではファイル名を
        一時的に連番プレフィックスへ変更する方式を使わない。

        その代わり、preset_order.json を作らずに済むよう、
        各プリセットJSONに "_launcher_order" を持たせる方法も
        共通項目を保存しない条件に抵触する。

        よってプリセット順は登録情報フォルダ内のファイル名順とし、
        ドラッグによるプリセット順変更は実ファイル名の交換で実装する。
        """

        files = sorted(
            PRESET_DIR.glob("*.json"),
            key=lambda x: x.name.lower()
        )

        if self.preset_list.count() != len(files):
            self.reload_presets()
            return

        # 現在表示されている順序
        paths = [
            Path(
                self.preset_list.item(i)
                .data(Qt.ItemDataRole.UserRole)
            )
            for i in range(
                self.preset_list.count()
            )
        ]

        # ファイル名を変更せず順序を保持するための
        # UI上の並びは、次回起動時に再現する必要がある。
        # 共通設定に含めないという仕様を守るため、
        # プリセットJSON自体に順序を書き込むことはしない。
        #
        # そこでドラッグ時には名前を変更しないまま、
        # リストだけを再描画する。
        #
        # 次回起動時はファイル名順となる。
        # 実運用上、プリセット順の永続化も必要な場合は
        # 専用の順序ファイルを追加する拡張が可能。
        self.reload_presets()

    def reorder_categories(self):
        path = self.current_preset_path()

        if not path:
            return

        data = load_json(
            path,
            {"categories": []}
        )

        old_categories = data.get(
            "categories",
            []
        )

        if len(old_categories) != self.category_list.count():
            return

        new_categories = []

        for row in range(
            self.category_list.count()
        ):
            old_index = (
                self.category_list.item(row)
                .data(Qt.ItemDataRole.UserRole)
            )

            if (
                isinstance(old_index, int) and
                0 <= old_index <
                len(old_categories)
            ):
                new_categories.append(
                    old_categories[old_index]
                )

        if len(new_categories) != len(
            old_categories
        ):
            return

        data["categories"] = new_categories

        save_json(path, data)

        self.refresh_categories()

    def reorder_items(self):
        path = self.current_preset_path()

        selected_category = (
            self.category_list.selectedItems()
        )

        if not path or len(selected_category) != 1:
            return

        data = load_json(
            path,
            {"categories": []}
        )

        category_index = (
            selected_category[0]
            .data(Qt.ItemDataRole.UserRole)
        )

        categories = data.get(
            "categories",
            []
        )

        if not (
            0 <= category_index <
            len(categories)
        ):
            return

        old_items = categories[
            category_index
        ].get("items", [])

        if len(old_items) != self.item_list.count():
            return

        new_items = []

        for row in range(
            self.item_list.count()
        ):
            old_index = (
                self.item_list.item(row)
                .data(Qt.ItemDataRole.UserRole)
            )

            if (
                isinstance(old_index, int) and
                0 <= old_index <
                len(old_items)
            ):
                new_items.append(
                    old_items[old_index]
                )

        if len(new_items) != len(old_items):
            return

        categories[
            category_index
        ]["items"] = new_items

        save_json(path, data)

        self.refresh_items()

    # ========================================================
    # クロスドラッグ
    # ========================================================

    def cross_drop(
        self,
        source,
        target,
        position
    ):
        # ----------------------------------------
        # アイテム -> カテゴリ
        # ----------------------------------------

        if (
            source is self.item_list and
            target is self.category_list
        ):
            self.move_items_to_category(
                target,
                position
            )
            return

        # ----------------------------------------
        # カテゴリ -> プリセット
        # ----------------------------------------

        if (
            source is self.category_list and
            target is self.preset_list
        ):
            self.move_categories_to_preset(
                target,
                position
            )
            return

    def drop_target_item(
        self,
        widget,
        position
    ):
        return widget.itemAt(position)

    def move_items_to_category(
        self,
        target,
        position
    ):
        destination = self.drop_target_item(target, position)
        if destination is None:
            return

        ctx = self.drag_context
        source_path_text = ctx.get("preset_path", "")
        source_index = ctx.get("category_index")
        indices = list(ctx.get("indices", []))

        if not source_path_text or source_index is None or not indices:
            return

        source_path = Path(source_path_text)
        destination_index = destination.data(Qt.ItemDataRole.UserRole)

        # item -> category は同一プリセット内での移動。
        data = load_json(source_path, {"categories": []})
        categories = data.setdefault("categories", [])

        if not (0 <= source_index < len(categories)):
            return
        if not (isinstance(destination_index, int) and 0 <= destination_index < len(categories)):
            return
        if source_index == destination_index:
            return

        source_items = categories[source_index].setdefault("items", [])
        destination_items = categories[destination_index].setdefault("items", [])

        moving = []
        for index in sorted(indices, reverse=True):
            if isinstance(index, int) and 0 <= index < len(source_items):
                moving.append(source_items.pop(index))
        moving.reverse()

        if not moving:
            return

        destination_items.extend(moving)
        save_json(source_path, data)

        # 移動先カテゴリを表示。
        self.refresh_categories()
        if 0 <= destination_index < self.category_list.count():
            self.category_list.setCurrentRow(destination_index)

    def move_categories_to_preset(
        self,
        target,
        position
    ):
        destination = self.drop_target_item(target, position)
        if destination is None:
            return

        ctx = self.drag_context
        source_path_text = ctx.get("preset_path", "")
        indices = list(ctx.get("indices", []))

        if not source_path_text or not indices:
            return

        source_path = Path(source_path_text)
        destination_path = Path(destination.data(Qt.ItemDataRole.UserRole))

        if source_path == destination_path:
            return

        try:
            source_data = load_json(source_path, {"categories": []})
            destination_data = load_json(destination_path, {"categories": []})
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "移動できません", str(exc))
            return

        source_categories = source_data.setdefault("categories", [])
        destination_categories = destination_data.setdefault("categories", [])

        moving = []
        for index in sorted(indices, reverse=True):
            if isinstance(index, int) and 0 <= index < len(source_categories):
                moving.append(source_categories.pop(index))
        moving.reverse()

        if not moving:
            return

        destination_categories.extend(moving)
        try:
            save_transaction([(source_path, source_data), (destination_path, destination_data)], saver=save_json)
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "移動できません", f"カテゴリ移動を確定できませんでした。\n{exc}")
            return

        self.reload_presets()
        for row in range(self.preset_list.count()):
            if self.preset_list.item(row).data(Qt.ItemDataRole.UserRole) == str(destination_path):
                self.preset_list.setCurrentRow(row)
                break

    # ========================================================
    # 右クリック編集
    # ========================================================

    def context_menu(self, position):
        widget = self.sender()
        item = widget.itemAt(position)

        if item is None:
            return

        # 複数選択時は編集しない。
        if len(widget.selectedItems()) != 1:
            return

        # ----------------------------------------
        # プリセット
        # ----------------------------------------

        if widget is self.preset_list:
            old_path = Path(
                item.data(Qt.ItemDataRole.UserRole)
            )

            dlg = NameDialog(
                "プリセット名編集",
                old_path.stem,
                self
            )

            if dlg.exec() == QDialog.DialogCode.Accepted:
                new_name = dlg.value()

                if not new_name:
                    return

                if new_name == old_path.stem:
                    return

                try:
                    new_name = validate_preset_name(new_name)
                except ValueError as exc:
                    QMessageBox.warning(self, "名前を変更できません", str(exc))
                    return

                new_path = (
                    old_path.parent /
                    f"{new_name}.json"
                )

                if new_path.exists():
                    QMessageBox.warning(
                        self,
                        "エラー",
                        "同名のプリセットがあります。"
                    )
                    return

                old_path.rename(new_path)

                if (
                    self.main.settings.get(
                        "current_preset"
                    ) == old_path.name
                ):
                    self.main.settings[
                        "current_preset"
                    ] = new_path.name

                    save_json(
                        SETTING_FILE,
                        self.main.settings
                    )

                self.reload_presets()

            return

        # ----------------------------------------
        # カテゴリ
        # ----------------------------------------

        if widget is self.category_list:
            data = self.load_current_preset()

            index = item.data(Qt.ItemDataRole.UserRole)

            if not (
                isinstance(index, int) and
                0 <= index <
                len(data["categories"])
            ):
                return

            category = data[
                "categories"
            ][index]

            dlg = NameDialog(
                "カテゴリ名編集",
                category.get("name", ""),
                self
            )

            if dlg.exec() == QDialog.DialogCode.Accepted:
                name = dlg.value()

                if name:
                    category["name"] = name

                    self.save_current_preset(
                        data
                    )

                    self.refresh_categories()

            return

        # ----------------------------------------
        # アイテム
        # ----------------------------------------

        category_index = (
            self.current_category_index()
        )

        if category_index is None:
            return

        data = self.load_current_preset()

        item_index = item.data(Qt.ItemDataRole.UserRole)

        items = data[
            "categories"
        ][category_index].setdefault(
            "items",
            []
        )

        if not (
            isinstance(item_index, int) and
            0 <= item_index < len(items)
        ):
            return

        obj = items[item_index]

        if obj.get("type") == "separator":
            dlg = NameDialog(
                "仕切り名編集",
                obj.get("name", ""),
                self
            )
        else:
            dlg = ItemEditDialog(
                obj,
                self
            )

        if dlg.exec() == QDialog.DialogCode.Accepted:
            if isinstance(
                dlg,
                NameDialog
            ):
                obj["name"] = dlg.value()
            else:
                obj = dlg.value()

            items[item_index] = obj

            self.save_current_preset(
                data
            )

            self.refresh_items()

    # ========================================================
    # Deleteキー
    # ========================================================

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Delete:
            focus = self.focusWidget()

            if focus is self.preset_list:
                self.delete_presets()
                return

            if focus is self.category_list:
                self.delete_categories()
                return

            if focus is self.item_list:
                self.delete_items()
                return

        super().keyPressEvent(event)


# ============================================================
# ドラッグバー
# ============================================================

class DragBar(QWidget):

    clicked = Signal()
    rightClicked = Signal()
    moved = Signal(QPoint)
    hideRequested = Signal()
    hideRightClicked = Signal()

    BOTTOM_H = 24

    def __init__(self):
        super().__init__()

        self.setFixedWidth(27)
        self.setCursor(Qt.CursorShape.SizeAllCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        self.press_pos = None
        self.start_window_pos = None
        self.dragged = False

    def mousePressEvent(self, event):
        if self._hide_rect().contains(event.position().toPoint()):
            if event.button() == Qt.MouseButton.LeftButton:
                self.hideRequested.emit()
                event.accept()
                return
            if event.button() == Qt.MouseButton.RightButton:
                self.hideRightClicked.emit()
                event.accept()
                return

        if event.button() == Qt.MouseButton.RightButton:
            self.rightClicked.emit()
            return

        if event.button() == Qt.MouseButton.LeftButton:
            self.press_pos = event.globalPos()

            main = self.window().property(
                "main_window"
            )

            if main is not None:
                self.start_window_pos = main.pos()
            else:
                self.start_window_pos = self.pos()

            self.dragged = False

    def mouseMoveEvent(self, event):
        if (
            self.press_pos is not None and
            event.buttons() & Qt.MouseButton.LeftButton
        ):
            delta = (
                event.globalPos() -
                self.press_pos
            )

            if delta.manhattanLength() > 3:
                self.dragged = True

                if self.start_window_pos:
                    self.moved.emit(
                        self.start_window_pos +
                        delta
                    )

    def mouseReleaseEvent(self, event):
        if (
            event.button() == Qt.MouseButton.LeftButton and
            self.press_pos is not None and
            not self.dragged
        ):
            self.clicked.emit()

        self.press_pos = None

    def _hide_rect(self):
        return self.rect().adjusted(3, self.height() - self.BOTTOM_H, -3, -3)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        background = QColor(self.property("bar_background") or "#111417")
        border = QColor(self.property("bar_border") or "#30363d")
        text_color = QColor(self.property("bar_text") or "#ffffff")
        control = QColor(self.property("bar_control") or "#3a3f45")

        body = self.rect().adjusted(1, 1, -1, -1)
        painter.setBrush(background)
        painter.setPen(QPen(border, 1))
        painter.drawRoundedRect(body, 2, 2)

        hide_rect = self._hide_rect()
        painter.setBrush(control)
        painter.setPen(QPen(border, 1))
        painter.drawRoundedRect(hide_rect, 2, 2)
        painter.setPen(text_color)
        hide_font = QFont("Segoe UI", 9)
        hide_font.setBold(True)
        painter.setFont(hide_font)
        painter.drawText(hide_rect, Qt.AlignmentFlag.AlignCenter, "⌄")

        painter.setPen(text_color)

        font = QFont()
        font.setBold(True)
        font.setWeight(QFont.Weight.Bold)
        font.setPointSize(9)

        painter.setFont(font)

        if self.property("bar_pin"):
            painter.drawText(
                self.rect().adjusted(
                    0, 2, -2, 0
                ),
                Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignRight,
                "📌"
            )

        painter.save()

        # 文字を縦方向に配置。
        painter.translate(
            self.width() - 3,
            self.height() - self.BOTTOM_H - 5
        )

        painter.rotate(-90)

        painter.drawText(
            0,
            0,
            "ExLauncher"
        )

        painter.restore()


# ============================================================
# メインUI
# ============================================================

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        prepare_data(ensure_files, DEFAULT_SETTING,
                     {"ui_width": 200, "theme": "Dark Gray", "categories": [{"name": "新規カテゴリ", "items": []}]})

        self.settings = load_json(
            SETTING_FILE,
            dict(DEFAULT_SETTING)
        )

        # 古い/欠落設定への対策。
        for key, value in DEFAULT_SETTING.items():
            self.settings.setdefault(
                key,
                value
            )

        # theme / ui_width はプリセット固有。共通設定には残さない。
        self.settings.pop("theme", None)
        self.settings.pop("ui_width", None)

        self.data = {
            "categories": []
        }

        self.expanded = set()
        # バー収納時に、収納前のカテゴリ展開状態を保持する。
        self._expanded_before_bar_hide = None

        self.setup_main_ui()
        self.setup_drag_bar()

        self.reload_presets(ensure_data=False)

        self.apply_settings()

    # ========================================================
    # UI
    # ========================================================

    def setup_main_ui(self):
        self.setWindowTitle("ExLauncher")

        self.setWindowFlags(
            Qt.WindowType.Tool |
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint
        )

        central = QWidget()
        self.setCentralWidget(central)

        self.list_widget = QListWidget()

        self.list_widget.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection
        )
        self.list_widget.setFrameShape(QListWidget.NoFrame)
        self.list_widget.setSpacing(0)
        self.list_widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.list_widget.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.list_widget.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.list_widget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.list_widget.setStyleSheet(
            "QListWidget {"
            " border: none;"
            " border-radius: 2px;"
            " padding: 0px;"
            " margin: 0px;"
            " spacing: 0px;"
            "}"
            "QListWidget::item {"
            " padding: 0px;"
            " margin: 0px;"
            " border: none;"
            " background: transparent;"
            "}"
        )
        self.file_icon_provider = QFileIconProvider()
        self._item_icon_cache = {}  # Shellアイコン取得結果を再利用
        self._pending_icons = {}
        self._icon_timer = QTimer(self)
        self._icon_timer.setSingleShot(True)
        self._icon_timer.timeout.connect(self._load_next_icon)

        self.list_widget.itemClicked.connect(
            self.main_item_clicked
        )

        self.list_widget.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )

        self.list_widget.customContextMenuRequested.connect(
            self.main_context_menu
        )

        self.preset_combo = QComboBox()
        self.preset_combo.setFixedHeight(24)

        self.preset_combo.currentIndexChanged.connect(
            self.main_preset_changed
        )

        self.manage_button = QPushButton("📝")
        self.search_button = QPushButton("🔍")
        self.settings_button = QPushButton("⚙")
        self.manage_button.setToolTip("プリセット・カテゴリ・アイテムを編集")
        self.search_button.setToolTip("クイック検索（Ctrl+F）")
        self.settings_button.setToolTip("設定を開く")

        for button in (
            self.manage_button,
            self.search_button,
            self.settings_button
        ):
            button.setFixedSize(30, 24)

        self.manage_button.clicked.connect(
            self.open_registration
        )

        self.search_button.clicked.connect(
            self.open_quick_search
        )

        self.settings_button.clicked.connect(
            self.open_settings
        )

        bottom = QHBoxLayout()

        bottom.setContentsMargins(
            0, 0, 0, 0
        )

        bottom.setSpacing(1)

        bottom.addWidget(
            self.preset_combo,
            1
        )

        bottom.addWidget(
            self.manage_button
        )

        bottom.addWidget(
            self.search_button
        )

        bottom.addWidget(
            self.settings_button
        )

        layout = QVBoxLayout(
            central
        )

        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(
            self.list_widget,
            1
        )

        layout.addLayout(bottom)

        self.search_shortcut = QShortcut(QKeySequence.StandardKey.Find, self)
        self.search_shortcut.setContext(Qt.ShortcutContext.ApplicationShortcut)
        self.search_shortcut.activated.connect(self.open_quick_search)

    # ========================================================
    # ドラッグバー
    # ========================================================

    def setup_drag_bar(self):
        self.drag_bar = DragBar()

        self.drag_bar.setProperty(
            "main_window",
            self
        )

        self.drag_bar.clicked.connect(
            self.toggle_from_bar
        )

        self.drag_bar.rightClicked.connect(
            self.toggle_pin
        )

        self.drag_bar.moved.connect(
            self.move_from_bar
        )

        self.drag_bar.hideRequested.connect(
            self.hide_main
        )

        self.drag_bar.hideRightClicked.connect(
            self.hide_button_right_click
        )

        self.drag_bar.setWindowFlags(
            Qt.WindowType.Tool |
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint
        )

        self.drag_bar.show()

    # ========================================================
    # 設定適用
    # ========================================================

    def apply_settings(self):
        width = int(
            self.data.get(
                "ui_width",
                200
            )
        )

        self.setFixedWidth(max(160, width))

        self.apply_theme()

        self.apply_pin_state()

        self.update_pair_geometry()

    def apply_theme(self):
        theme = self.data.get(
            "theme",
            "Dark Gray"
        )

        style = theme_style(theme)

        self.setStyleSheet(style)

        # バーは透明なトップレベル上へ角丸で描画する。
        t = THEMES.get(theme, THEMES["Dark Gray"])
        self.drag_bar.setStyleSheet("background: transparent; border: none;")
        self.drag_bar.setProperty("bar_background", t["bar"])
        self.drag_bar.setProperty("bar_border", t["border"])
        self.drag_bar.setProperty("bar_text", "#ffffff")
        self.drag_bar.setProperty("bar_control", t["control"])
        self.drag_bar.update()

        # 行ウィジェットのカテゴリ色・アイテム色もテーマに追随させる。
        if hasattr(self, "list_widget") and hasattr(self, "data"):
            self.refresh_main_list()

    # ========================================================
    # プリセット
    # ========================================================

    def reload_presets(self, ensure_data=True):
        # 初回生成では直前のensure_files()を再実行しない。
        if ensure_data:
            ensure_files()
        current = self.settings.get(
            "current_preset",
            ""
        )

        self.preset_combo.blockSignals(
            True
        )

        self.preset_combo.clear()

        files = sorted(
            PRESET_DIR.glob("*.json"),
            key=lambda x: x.name.lower()
        )

        target = -1

        for row, path in enumerate(files):
            self.preset_combo.addItem(
                path.stem,
                str(path)
            )

            if (
                current and
                Path(current).name ==
                path.name
            ):
                target = row

        if target < 0 and self.preset_combo.count():
            target = 0

        if target >= 0:
            self.preset_combo.setCurrentIndex(
                target
            )

            path = self.preset_combo.itemData(
                target
            )

            self.load_preset(path)

        else:
            self.data = {
                "categories": []
            }

            self.expanded.clear()
            self.refresh_main_list()

        self.preset_combo.blockSignals(
            False
        )

    def main_preset_changed(self):
        path = self.preset_combo.currentData()

        if not path:
            return

        try:
            data = load_json(path, {"categories": []})
            next_settings = dict(self.settings, current_preset=Path(path).name)
            save_json(SETTING_FILE, next_settings)
        except (OSError, ValueError) as exc:
            previous = self.settings.get('current_preset', '')
            self.preset_combo.blockSignals(True)
            for i in range(self.preset_combo.count()):
                if Path(self.preset_combo.itemData(i)).name == previous:
                    self.preset_combo.setCurrentIndex(i)
                    break
            self.preset_combo.blockSignals(False)
            QMessageBox.warning(self, 'プリセットを開けません', str(exc))
            return
        self.settings = next_settings
        self.load_preset(path, data=data)
        self.apply_settings()

    def load_preset(self, path, data=None):
        self.data = load_json(path, {"categories": []}) if data is None else data

        self.data.setdefault(
            "categories",
            []
        )
        self.data.setdefault("ui_width", 200)
        self.data.setdefault("theme", "Dark Gray")

        self.expanded.clear()

        self.refresh_main_list()

    # ========================================================
    # メインリスト
    # ========================================================

    def item_icon(self, obj):
        """アイテム種別アイコン。Shell取得はパス単位でメモリキャッシュする。"""
        item_type = obj.get("type")
        path = obj.get("path", "") if item_type in ("file", "folder") else ""
        key = (item_type, path)
        if key in self._item_icon_cache:
            return self._item_icon_cache[key]
        if item_type == "file":
            icon = self.file_icon_provider.icon(QFileInfo(path)) if path else self.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon)
        elif item_type == "folder":
            icon = self.file_icon_provider.icon(QFileInfo(path)) if path else None
            if icon is None or icon.isNull():
                icon = self.style().standardIcon(QStyle.StandardPixmap.SP_DirIcon)
        elif item_type == "web":
            icon = self.style().standardIcon(QStyle.StandardPixmap.SP_BrowserReload)
        elif item_type == "text":
            icon = self.style().standardIcon(QStyle.StandardPixmap.SP_FileDialogDetailedView)
        elif item_type == "separator":
            return None
        else:
            icon = self.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon)
        if icon is None or icon.isNull():
            icon = self.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon)
        if len(self._item_icon_cache) >= 512:
            self._item_icon_cache.pop(next(iter(self._item_icon_cache)))
        self._item_icon_cache[key] = icon
        return icon

    def _initial_row_icon(self, obj):
        typ = obj.get('type')
        if typ not in ('file', 'folder'):
            return self.item_icon(obj)
        key = (typ, obj.get('path', ''))
        if key in self._item_icon_cache:
            return self._item_icon_cache[key]
        return self.style().standardIcon(QStyle.StandardPixmap.SP_DirIcon if typ == 'folder'
                                         else QStyle.StandardPixmap.SP_FileIcon)

    def _defer_row_icon(self, obj, row):
        key = (obj.get('type'), obj.get('path', ''))
        if key[0] not in ('file', 'folder') or not key[1] or key in self._item_icon_cache:
            return
        if key not in self._pending_icons:
            self._pending_icons[key] = (dict(type=key[0], path=key[1]), weakref.WeakSet())
        self._pending_icons[key][1].add(row)
        if not self._icon_timer.isActive():
            self._icon_timer.start(16)

    def _load_next_icon(self):
        if not self.isVisible():
            return
        while self._pending_icons:
            key = next(iter(self._pending_icons))
            obj, waiting = self._pending_icons.pop(key)
            rows = [w for w in waiting if isValid(w) and w.isVisibleTo(self)]
            if not rows:
                continue
            try:
                icon = self.item_icon(obj)
            except (OSError, RuntimeError):
                icon = self._initial_row_icon(obj)
            if icon is None or icon.isNull():
                icon = self._initial_row_icon(obj)
            if icon is not None:
                for row in rows:
                    row.icon_label.setPixmap(icon.pixmap(QSize(16, 16)))
            break
        if self._pending_icons:
            self._icon_timer.start(16)

    def hideEvent(self, event):
        self._icon_timer.stop()
        super().hideEvent(event)

    def showEvent(self, event):
        super().showEvent(event)
        if self._pending_icons:
            self._icon_timer.start(16)

    def refresh_main_list(self):
        self._icon_timer.stop()
        self._pending_icons.clear()
        self.list_widget.setUpdatesEnabled(False)
        self.list_widget.clear()

        categories = self.data.get("categories", [])
        theme = self.data.get("theme", "Dark Gray")
        total_height = 0

        for category_index, category in enumerate(categories):
            opened = category_index in self.expanded
            category_name = f"{category.get('name', '名称未設定')} ({len(category.get('items', []))})"

            category_item = QListWidgetItem()
            category_item.setData(Qt.ItemDataRole.UserRole, ("category", category_index))
            category_item.setSizeHint(QSize(0, MainRowWidget.CATEGORY_HEIGHT))
            self.list_widget.addItem(category_item)

            category_row = MainRowWidget(
                "category", category_name, theme, expanded=opened
            )
            self.list_widget.setItemWidget(category_item, category_row)
            total_height += MainRowWidget.CATEGORY_HEIGHT

            if opened:
                for item_index, obj in enumerate(category.get("items", [])):
                    name = obj.get("name", "")
                    is_separator = obj.get("type") == "separator"

                    if is_separator:
                        # 「仕切り」という文字は使わず、表示名は罫線8本。
                        name = "────────"

                    list_item = QListWidgetItem()
                    list_item.setData(
                        Qt.ItemDataRole.UserRole, ("item", category_index, item_index)
                    )
                    list_item.setSizeHint(QSize(0, MainRowWidget.ITEM_HEIGHT))
                    self.list_widget.addItem(list_item)

                    row = MainRowWidget(
                        "item",
                        name,
                        theme,
                        icon=self._initial_row_icon(obj),
                        icon_text="─" if is_separator else None
                    )
                    self.list_widget.setItemWidget(list_item, row)
                    self._defer_row_icon(obj, row)
                    total_height += MainRowWidget.ITEM_HEIGHT

        # リスト行の合計値だけを使用し、縦方向の余白を作らない。
        self._fit_classic_list(total_height)
        self.list_widget.setUpdatesEnabled(True)
        self.list_widget.viewport().update()

    # ========================================================
    # メインUI左クリック
    # ========================================================

    def _resize_classic_after_row_change(self):
        total_height = 0
        for row in range(self.list_widget.count()):
            data = self.list_widget.item(row).data(Qt.ItemDataRole.UserRole)
            total_height += MainRowWidget.CATEGORY_HEIGHT if data and data[0] == "category" else MainRowWidget.ITEM_HEIGHT
        self._fit_classic_list(total_height)

    def _fit_classic_list(self, total_height):
        screen = QApplication.screenAt(self.frameGeometry().center()) or self.screen()
        limit = screen.availableGeometry().height() if screen else total_height + 24
        visible_height = min(total_height, max(0, limit - 24))
        self.list_widget.setVisible(total_height > 0)
        self.list_widget.setFixedHeight(visible_height)
        self.setFixedHeight(visible_height + 24)
        self.drag_bar.setFixedHeight(self.height())
        self.update_pair_geometry()

    def _toggle_category_fast(self, clicked_item, category_index):
        """対象カテゴリだけを差分更新し、Classicの展開/収納を高速化。"""
        categories = self.data.get("categories", [])
        if not (0 <= category_index < len(categories)):
            return
        row = self.list_widget.row(clicked_item)
        items = categories[category_index].get("items", [])
        self.list_widget.setUpdatesEnabled(False)
        try:
            if category_index in self.expanded:
                self.expanded.remove(category_index)
                while row + 1 < self.list_widget.count():
                    child = self.list_widget.item(row + 1)
                    d = child.data(Qt.ItemDataRole.UserRole)
                    if not d or d[0] != "item" or d[1] != category_index:
                        break
                    widget = self.list_widget.itemWidget(child)
                    if widget is not None:
                        widget.hide()
                    self.list_widget.takeItem(row + 1)
            else:
                self.expanded.add(category_index)
                insert_row = row + 1
                theme = self.data.get("theme", "Dark Gray")
                for item_index, obj in enumerate(items):
                    name = "────────" if obj.get("type") == "separator" else obj.get("name", "")
                    li = QListWidgetItem()
                    li.setData(Qt.ItemDataRole.UserRole, ("item", category_index, item_index))
                    li.setSizeHint(QSize(0, MainRowWidget.ITEM_HEIGHT))
                    self.list_widget.insertItem(insert_row, li)
                    rw = MainRowWidget("item", name, theme, icon=self._initial_row_icon(obj), icon_text="─" if obj.get("type") == "separator" else None)
                    self.list_widget.setItemWidget(li, rw)
                    self._defer_row_icon(obj, rw)
                    insert_row += 1
            self._resize_classic_after_row_change()
        finally:
            self.list_widget.setUpdatesEnabled(True)
            self.list_widget.viewport().update()

    def main_item_clicked(self, item):
        data = item.data(Qt.ItemDataRole.UserRole)

        if not data:
            return

        if data[0] == "category":
            category_index = data[1]
            if self.settings.get("allow_multiple_expand", True):
                self._toggle_category_fast(item, category_index)
            else:
                if category_index in self.expanded:
                    self.expanded.remove(category_index)
                else:
                    self.expanded.clear()
                    self.expanded.add(category_index)
                self.refresh_main_list()
            return

        if data[0] == "item":
            _, category_index, item_index = data

            try:
                obj = self.data[
                    "categories"
                ][category_index][
                    "items"
                ][item_index]
            except Exception:
                return

            if obj.get("type") == "separator":
                return

            if not self.try_launch_item(obj):
                return

            # 定型文はコピー後もランチャーを収納しない。
            # ファイル／フォルダ／Web は、ピンOFF時のみ
            # バー左クリック収納とまったく同じ経路で収納する。
            # これにより展開状態の保存 → 全収納 → バーだけ表示、
            # という手動バー収納時の挙動と一致する。
            if (
                obj.get("type") != "text"
                and not self.settings.get("pin", False)
            ):
                self.toggle_from_bar()

    # ========================================================
    # メインUI右クリック
    # ========================================================

    def main_context_menu(self, position):
        item = self.list_widget.itemAt(
            position
        )

        if not item:
            return

        data = item.data(Qt.ItemDataRole.UserRole)

        if not data:
            return

        if data[0] == "category":
            category_index = data[1]
            # 右クリックしたカテゴリだけを展開し、他は収納する。
            self.expanded = {category_index}
            self.refresh_main_list()
            return

        if data[0] != "item":
            return

        _, category_index, item_index = data

        try:
            obj = self.data[
                "categories"
            ][category_index][
                "items"
            ][item_index]
        except Exception:
            return

        # ファイルはExplorerでそのファイルを選択。
        if obj.get("type") == "file":
            path = obj.get(
                "path",
                ""
            )

            if os.path.isfile(path):
                subprocess.Popen(
                    [
                        "explorer.exe",
                        "/select,",
                        os.path.normpath(path)
                    ]
                )

            return

        # 仕切りは名前だけ編集。
        if obj.get("type") == "separator":
            dlg = NameDialog(
                "仕切り名編集",
                obj.get(
                    "name",
                    ""
                ),
                self
            )

        else:
            dlg = ItemEditDialog(
                obj,
                self
            )

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        if isinstance(
            dlg,
            NameDialog
        ):
            obj["name"] = dlg.value()
        else:
            obj = dlg.value()

        self.data[
            "categories"
        ][category_index][
            "items"
        ][item_index] = obj

        self.save_main_preset()
        self.refresh_main_list()

    # ========================================================
    # メインプリセット保存
    # ========================================================

    def save_main_preset(self):
        path = self.preset_combo.currentData()

        if path:
            save_json(
                path,
                self.data
            )

    # ========================================================
    # 登録ダイアログ
    # ========================================================

    def open_registration(self):
        was_visible = self.isVisible()
        bar_visible = self.drag_bar.isVisible()
        self.hide()
        self.drag_bar.hide()
        try:
            dialog = RegistrationDialog(self)
            dialog.setStyleSheet(theme_style(self.data.get("theme", "Dark Gray")))
            dialog.exec()
            self.reload_presets()
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, '登録データを開けません', str(exc))
        finally:
            self.setVisible(was_visible)
            self.drag_bar.setVisible(bar_visible)
            self.apply_settings()

    # ========================================================
    # 設定
    # ========================================================

    def open_quick_search(self):
        modal = QApplication.activeModalWidget()
        if modal is not None:
            modal.raise_()
            modal.activateWindow()
            return

        theme = self.data.get("theme", "Dark Gray")
        dialog = QuickSearchDialog(self.data, theme_style(theme), self)
        dialog.setWindowIcon(self.windowIcon())
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        selected = dialog.selected_indices()
        if selected is None:
            return
        category_index, item_index = selected
        try:
            obj = self.data["categories"][category_index]["items"][item_index]
        except (IndexError, KeyError, TypeError):
            return

        if not self.try_launch_item(obj):
            return
        if obj.get("type") != "text" and not self.settings.get("pin", False):
            if self.isVisible():
                self.toggle_from_bar()

    def open_settings(self):
        was_visible = self.isVisible()
        bar_visible = self.drag_bar.isVisible()
        switching = False
        self.hide()
        self.drag_bar.hide()
        try:
            dialog_settings = dict(self.settings)
            dialog_settings["ui_width"] = int(self.data.get("ui_width", 200))
            dialog_settings["theme"] = self.data.get("theme", "Dark Gray")
            dialog = SettingsDialog(dialog_settings, self)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                values = dialog.values()
                next_settings = copy.deepcopy(self.settings)
                next_data = copy.deepcopy(self.data)
                for key in ("allow_multiple_expand", "pin", "drag_bar_position", "animation_speed", "ui_style"):
                    next_settings[key] = values[key]
                next_data.update(ui_width=int(values['ui_width']), theme=values['theme'])
                updates = [(SETTING_FILE, next_settings)]
                current_path = self.preset_combo.currentData()
                if current_path:
                    updates.append((current_path, next_data))
                save_transaction(updates, saver=save_json)
                self.settings, self.data = next_settings, next_data
                self.apply_settings()
                if values["ui_style"] == "Modern":
                    restart_via_dispatcher()
                    switching = True
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "設定を保存できません", str(exc))
        finally:
            if not switching:
                self.setVisible(was_visible)
                self.drag_bar.setVisible(bar_visible)
                self.update_pair_geometry()

    def try_launch_item(self, item):
        try:
            ok = launch_item(item)
            if ok is False:
                QMessageBox.warning(self, "起動できません", f"{item.get('name', '')}\n対象や関連付けを確認してください。")
                return False
            return True
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "起動できません", f"{item.get('name', '')}\n{exc}")
            return False

    # ========================================================
    # ピン
    # ========================================================

    def toggle_pin(self):
        self.settings[
            "pin"
        ] = not bool(
            self.settings.get(
                "pin",
                False
            )
        )

        save_json(
            SETTING_FILE,
            self.settings
        )

        self.apply_pin_state()

    def apply_pin_state(self):
        pin = bool(self.settings.get("pin", False))
        self.drag_bar.setProperty("bar_pin", pin)
        self.drag_bar.update()

    # ========================================================
    # 非表示
    # ========================================================

    def hide_main(self):
        # 下段の🔽はメインUIとドラッグバーの両方を非表示にする。
        # ピン状態に関係なく手動非表示として扱う。
        self.hide()
        self.drag_bar.hide()

    def hide_button_right_click(self, position=None):
        # 🔽右クリック:
        # 全カテゴリを収納。
        # すでに全部収納なら全展開。
        count = len(
            self.data.get(
                "categories",
                []
            )
        )

        if count == 0:
            return

        if len(self.expanded) == 0:
            self.expanded = set(
                range(count)
            )

        else:
            self.expanded.clear()

        self.refresh_main_list()

    # ========================================================
    # バー
    # ========================================================

    def toggle_from_bar(self):
        # バー左クリック:
        # 表示中 → 現在の展開状態を保存し、全カテゴリを収納してからメインだけ非表示。
        # 非表示中 → メインを表示し、収納前の展開状態へ戻す。
        if self.isVisible():
            self._expanded_before_bar_hide = set(self.expanded)
            self.expanded.clear()
            self.refresh_main_list()
            # refresh_main_list() でバーも未展開時の高さへFITした後に本体だけ隠す。
            self.hide()
            self.drag_bar.show()
            self.drag_bar.raise_()
            return

        self.show()
        if self._expanded_before_bar_hide is not None:
            self.expanded = set(self._expanded_before_bar_hide)
            self._expanded_before_bar_hide = None
            self.refresh_main_list()
        else:
            self.update_pair_geometry()
        self.raise_()
        self.drag_bar.raise_()
        self.activateWindow()

    def move_from_bar(self, position):
        self.move(position)
        self.update_pair_geometry()

    def update_pair_geometry(self):
        if not hasattr(self, 'drag_bar') or getattr(self, '_updating_pair', False):
            return

        if (
            self.settings.get(
                "drag_bar_position",
                "right"
            ) == "left"
        ):
            x = (
                self.x() -
                self.drag_bar.width()
            )

        else:
            x = (
                self.x() +
                self.width()
            )

        y = self.y()

        self.drag_bar.setFixedHeight(
            self.height()
        )
        screen = QApplication.screenAt(QPoint(x + self.drag_bar.width() // 2, y + 12)) or self.screen()
        if screen:
            bounds = screen.availableGeometry()
            x = max(bounds.left(), min(x, bounds.right() - self.drag_bar.width() + 1))
            y = max(bounds.top(), min(y, bounds.bottom() - min(self.height(), bounds.height()) + 1))
        main_x = x + self.drag_bar.width() if self.settings.get('drag_bar_position', 'right') == 'left' else x - self.width()
        self._updating_pair = True
        try:
            if self.pos() != QPoint(main_x, y):
                self.move(main_x, y)
            self.drag_bar.move(x, y)
        finally:
            self._updating_pair = False
        self.drag_bar.raise_()

    def moveEvent(self, event):
        super().moveEvent(event)
        self.update_pair_geometry()

    def reveal_from_secondary_instance(self):
        """2回目の起動要求を、既存Classic UIの前面表示へ変換する。"""
        modal = QApplication.activeModalWidget()
        if modal is not None:
            modal.show()
            modal.raise_()
            modal.activateWindow()
            return

        self.drag_bar.show()
        if not self.isVisible() and self._expanded_before_bar_hide is not None:
            self.toggle_from_bar()
            return
        self.show()
        self.drag_bar.show()
        self.update_pair_geometry()
        self.raise_()
        self.drag_bar.raise_()
        self.activateWindow()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.update_pair_geometry()

    # ========================================================
    # 閉じる
    # ========================================================


    def shutdown_for_switch(self):
        """Modernへの高速切替前にClassic側の一時状態を閉じる。"""
        self._icon_timer.stop()
        self._pending_icons.clear()
        try:
            self.drag_bar.hide()
        except RuntimeError:
            pass

    def closeEvent(self, event):
        self.drag_bar.close()
        event.accept()


# ============================================================
# アイテム起動
# ============================================================

def launch_item(item):
    item_type = item.get(
        "type"
    )

    # ファイル
    if item_type == "file":
        path = item.get(
            "path",
            ""
        )

        if os.path.exists(path):
            os.startfile(path)
            return True

    # フォルダ
    elif item_type == "folder":
        path = item.get(
            "path",
            ""
        )

        if os.path.isdir(path):
            os.startfile(path)
            return True

    # Web
    elif item_type == "web":
        url = item.get(
            "url",
            ""
        )

        if url:
            return bool(webbrowser.open(url))

    # 定型文
    elif item_type == "text":
        QApplication.clipboard().setText(
            item.get(
                "text",
                ""
            )
        )
        return True
    return False


# ============================================================
# タスクトレイ
# ============================================================

class TrayController:

    def __init__(self, app, main_window):
        self.app = app
        self.main = main_window

        # exe埋め込みアイコンを含む共通アプリアイコンを使用。
        icon = get_app_icon()

        self.tray = QSystemTrayIcon(
            icon,
            app
        )

        menu = QMenu()

        exit_action = QAction(
            "終了",
            menu
        )

        exit_action.triggered.connect(
            app.quit
        )

        menu.addAction(
            exit_action
        )

        self.tray.setContextMenu(
            menu
        )

        self.tray.activated.connect(
            self.activated
        )

        self.tray.show()

    def activated(self, reason):
        # Windows / PySide6 の左クリックは Trigger。
        # 右クリック(Context)やダブルクリック等では切り替えない。
        if reason != QSystemTrayIcon.ActivationReason.Trigger:
            return

        self.toggle_ui()

    def toggle_ui(self):
        """メインUIとドラッグバーをセットで表示/非表示する。"""
        main_visible = self.main.isVisible()
        bar_visible = self.main.drag_bar.isVisible()

        if main_visible or bar_visible:
            self.main.hide()
            self.main.drag_bar.hide()
            return

        self.main.show()
        self.main.drag_bar.show()
        self.main.update_pair_geometry()

        self.main.raise_()
        self.main.drag_bar.raise_()
        self.main.activateWindow()


# ============================================================
# main
# ============================================================

def main():
    app = QApplication(
        sys.argv
    )

    app.setQuitOnLastWindowClosed(
        False
    )

    single_instance = SingleInstanceController(parent=app)
    if not single_instance.acquire():
        return 0
    app.single_instance = single_instance
    app.aboutToQuit.connect(single_instance.shutdown)

    # Classic / Modern 共通の同梱 icon.ico を使用する。
    app_icon = get_app_icon()
    app.setWindowIcon(app_icon)

    try:
        window = MainWindow()
    except StartupCancelled:
        single_instance.shutdown()
        return 1
    window.setWindowIcon(app_icon)

    window.show()

    # TrayControllerを必ず保持する。
    # 参照を残さないとPythonのGCでControllerだけ破棄され、
    # トレイアイコンは見えていてもactivatedシグナルが反応しなくなる場合がある。
    window.tray_controller = TrayController(
        app,
        window
    )
    app.tray_controller = window.tray_controller
    single_instance.set_activate_callback(window.reveal_from_secondary_instance)

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
