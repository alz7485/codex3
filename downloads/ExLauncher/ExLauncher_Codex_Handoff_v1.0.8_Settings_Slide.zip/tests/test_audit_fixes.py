"""Audit regression tests: synthetic data, injected I/O faults and Qt offscreen."""
import base64
import copy
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import test_performance_regressions as perf
from PySide6.QtCore import QPoint, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QAbstractItemView, QDialog, QMessageBox

import classic_main as classic
import modern_main as modern
import exlauncher_common as common
import exlauncher_storage as storage
from data_recovery import prepare_data, StartupCancelled
from scripts import build_onedir


class AuditFixTests(unittest.TestCase):
    write_preset = perf.LauncherTests.write_preset
    write_settings = perf.LauncherTests.write_settings
    window = perf.LauncherTests.window

    def setUp(self):
        perf.LauncherTests.setUp(self)
        warning = patch.object(QMessageBox, 'warning', return_value=QMessageBox.StandardButton.Ok)
        self.warning = warning.start()
        self.addCleanup(warning.stop)

    def ensure(self, mode):
        return classic.ensure_files() if mode == 'Classic' else common.ensure_files(self.root)

    def test_bom_valid_unselected_preset_is_preserved(self):
        self.data['future'] = {'日本語': [1, 2, 3]}
        self.write_preset(self.data, 'unselected.json')
        path = self.presets / 'unselected.json'
        path.write_bytes(b'\xef\xbb\xbf' + path.read_bytes())
        before = path.read_bytes()
        for mode in ('Classic', 'Modern'):
            with self.subTest(mode=mode):
                self.ensure(mode)
                self.assertEqual(path.read_bytes(), before)
                self.assertEqual(storage.load_json(path, {})['future'], self.data['future'])

    def test_invalid_json_and_shapes_are_never_overwritten(self):
        cases = [
            ('test.json', b'{"categories":['),
            ('test.json', b'{"categories":null}'),
            ('test.json', b'{"categories":[null]}'),
            ('test.json', b'{"categories":[{"items":null}]}'),
            ('test.json', b'{"categories":[{"items":[null]}]}'),
            ('test.json', b'{"categories":[],"ui_width":"abc"}'),
            ('setting.json', b'null'), ('setting.json', b'[]'),
        ]
        for mode in ('Classic', 'Modern'):
            for name, raw in cases:
                with self.subTest(mode=mode, raw=raw):
                    self.write_settings()
                    self.write_preset(self.data)
                    path = self.root / name if name == 'setting.json' else self.presets / name
                    path.write_bytes(raw)
                    before = {p: p.read_bytes() for p in (self.root / 'setting.json', self.presets / 'test.json')}
                    with self.assertRaises(storage.DataFileError):
                        self.ensure(mode)
                    for p, content in before.items():
                        self.assertEqual(p.read_bytes(), content)

    def test_explicit_reset_keeps_exact_backup_and_unknown_bytes(self):
        path = self.presets / 'broken.json'
        raw = b'\xef\xbb\xbf{"important":"unfinished'
        path.write_bytes(raw)
        backup = storage.backup_and_reset(path, self.data)
        self.assertEqual(backup.read_bytes(), raw)
        self.assertEqual(storage.load_json(path, {}), self.data)

    def test_save_refuses_to_replace_existing_unreadable_data(self):
        path = self.presets / 'broken.json'
        path.write_bytes(b'{"categories":[')
        with self.assertRaises(storage.DataFileError):
            storage.save_json(path, self.data)
        self.assertEqual(path.read_bytes(), b'{"categories":[')

    def test_corrupt_preset_selection_retains_current_data_and_selection(self):
        target = self.presets / 'other.json'
        for cls in (classic.MainWindow, modern.ModernWindow):
            with self.subTest(cls=cls.__name__):
                self.write_preset(self.data, target.name)
                window = self.window(cls)
                current = window.preset_combo.currentData()
                old = copy.deepcopy(window.data)
                target.write_bytes(b'null')
                index = window.preset_combo.findData(str(target))
                window.preset_combo.setCurrentIndex(index)
                perf.drain()
                self.assertEqual(window.preset_combo.currentData(), current)
                self.assertEqual(window.data, old)
                self.assertEqual(target.read_bytes(), b'null')
                if cls is classic.MainWindow:
                    window.open_registration()
                    self.assertTrue(window.isVisible())
                    self.assertTrue(window.drag_bar.isVisible())
                    self.assertEqual(target.read_bytes(), b'null')

    def test_recovery_dialog_cancel_keeps_data_and_reset_requires_selection(self):
        path = self.presets / 'broken.json'
        raw = b'null'
        path.write_bytes(raw)
        def cancel(box):
            next(b for b in box.buttons() if '保持して終了' in b.text()).click()
            return box.result()
        with patch.object(QMessageBox, 'exec', cancel):
            with self.assertRaises(StartupCancelled):
                prepare_data(lambda: self.ensure('Classic'), self.settings, self.data)
        self.assertEqual(path.read_bytes(), raw)
        self.assertFalse(list(self.presets.glob('*.bak')))
        def reset(box):
            next(b for b in box.buttons() if 'バックアップして初期化' in b.text()).click()
            return box.result()
        with patch.object(QMessageBox, 'exec', reset):
            prepare_data(lambda: self.ensure('Modern'), self.settings, self.data)
        backups = list(self.presets.glob('broken.json.*.bak'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), raw)
        self.assertEqual(storage.load_json(path, {}), self.data)

    def test_multi_file_failure_restores_bytes_and_successful_retry_once(self):
        source = self.presets / 'test.json'
        target = self.presets / 'other.json'
        self.write_preset(dict(self.data, categories=[]), target.name)
        before = {p: p.read_bytes() for p in (source, target)}
        original_replace = os.replace
        def fail_target(src, dst):
            if Path(dst) == target:
                raise PermissionError('destination locked')
            return original_replace(src, dst)
        updates = [(source, dict(self.data, categories=[])), (target, self.data)]
        with patch.object(storage.os, 'replace', side_effect=fail_target):
            with self.assertRaises(PermissionError):
                storage.save_transaction(updates)
        for p, content in before.items():
            self.assertEqual(p.read_bytes(), content)
        storage.save_transaction(updates)
        self.assertEqual(storage.load_json(target, {})['categories'], self.data['categories'])
        self.assertEqual(storage.load_json(source, {})['categories'], [])
        self.assertFalse((self.presets / storage.JOURNAL).exists())

    def interrupted_transaction(self):
        source = self.presets / 'test.json'
        target = self.presets / 'other.json'
        self.write_preset(dict(self.data, categories=[]), target.name)
        before = {p: p.read_bytes() for p in (source, target)}
        calls = []
        def interrupted(path, data):
            if calls:
                raise SystemExit('simulated process termination')
            calls.append(path)
            storage.save_json(path, data)
        with self.assertRaises(SystemExit):
            storage.save_transaction([(source, dict(self.data, categories=[])), (target, self.data)], saver=interrupted)
        self.assertNotEqual(source.read_bytes(), before[source])
        return source, target, before

    def test_restart_recovers_interrupted_transaction_before_loading(self):
        for mode in ('Classic', 'Modern'):
            with self.subTest(mode=mode):
                source, target, before = self.interrupted_transaction()
                self.ensure(mode)
                for path, content in before.items():
                    self.assertEqual(path.read_bytes(), content)

    def test_recovery_failure_preserves_journal_and_blocks_migration(self):
        source, target, before = self.interrupted_transaction()
        original_replace = os.replace
        def denied(src, dst):
            if Path(dst) == source:
                raise PermissionError('source still locked')
            return original_replace(src, dst)
        with patch.object(storage.os, 'replace', side_effect=denied):
            with self.assertRaises(storage.DataFileError):
                self.ensure('Modern')
        self.assertTrue((self.presets / storage.JOURNAL).exists())
        self.assertEqual(target.read_bytes(), before[target])
        self.ensure('Modern')
        self.assertEqual(source.read_bytes(), before[source])

    def test_recovery_journal_cannot_write_outside_directory(self):
        outside = self.root / 'outside.json'
        outside.write_bytes(b'keep')
        journal = self.presets / storage.JOURNAL
        journal.write_text(json.dumps({'version': 1, 'state': 'pending', 'files': [
            {'path': '../outside.json', 'before': base64.b64encode(b'delete').decode()}]}))
        with self.assertRaises(storage.DataFileError):
            storage.recover_pending(self.presets)
        self.assertEqual(outside.read_bytes(), b'keep')
        self.assertTrue(journal.exists())

    def test_external_edits_after_interruption_are_preserved_and_reported(self):
        source, target, before = self.interrupted_transaction()
        external = dict(self.data, external_change='keep this change')
        self.write_preset(external)
        changed = source.read_bytes()
        with self.assertRaises(storage.DataFileError):
            self.ensure('Modern')
        self.assertEqual(source.read_bytes(), changed)
        self.assertEqual(target.read_bytes(), before[target])
        self.assertTrue((self.presets / storage.JOURNAL).exists())

    def test_new_transaction_does_not_apply_stale_data_after_recovery(self):
        source, target, before = self.interrupted_transaction()
        with self.assertRaises(storage.DataFileError):
            storage.save_transaction([(source, dict(self.data, categories=[])), (target, self.data)])
        for path, content in before.items():
            self.assertEqual(path.read_bytes(), content)

    def test_committed_journal_cleanup_failure_never_rolls_back_success(self):
        source = self.presets / 'test.json'
        target = self.presets / 'other.json'
        self.write_preset(dict(self.data, categories=[]), target.name)
        real_unlink = Path.unlink
        def locked(path, *args, **kwargs):
            if path.name == storage.JOURNAL:
                raise PermissionError('journal cleanup denied')
            return real_unlink(path, *args, **kwargs)
        with patch.object(Path, 'unlink', locked):
            storage.save_transaction([(source, dict(self.data, categories=[])), (target, self.data)])
        self.assertTrue((self.presets / storage.JOURNAL).exists())
        self.ensure('Classic')
        self.assertEqual(storage.load_json(target, {})['categories'], self.data['categories'])
        self.assertEqual(storage.load_json(source, {})['categories'], [])

    def test_classic_move_failure_and_retry_do_not_lose_category(self):
        target_path = self.presets / 'other.json'
        self.write_preset(dict(self.data, categories=[]), target_path.name)
        window = self.window(classic.MainWindow)
        dialog = classic.RegistrationDialog(window)
        self.addCleanup(dialog.deleteLater)
        source_path = self.presets / 'test.json'
        dialog.drag_context = {'preset_path': str(source_path), 'indices': [0]}
        target = next(dialog.preset_list.item(i) for i in range(dialog.preset_list.count())
                      if dialog.preset_list.item(i).data(Qt.ItemDataRole.UserRole) == str(target_path))
        original_save = classic.save_json
        def denied(path, data):
            if Path(path) == target_path:
                raise PermissionError('target locked')
            original_save(path, data)
        before = {p: p.read_bytes() for p in (source_path, target_path)}
        with patch.object(dialog, 'drop_target_item', return_value=target):
            with patch.object(classic, 'save_json', side_effect=denied):
                dialog.move_categories_to_preset(dialog.preset_list, QPoint())
            for p, content in before.items():
                self.assertEqual(p.read_bytes(), content)
            self.warning.assert_called()
            dialog.move_categories_to_preset(dialog.preset_list, QPoint())
        self.assertEqual(len(storage.load_json(target_path, {})['categories']), 1)
        self.assertEqual(len(storage.load_json(source_path, {})['categories']), 2)

    def test_modern_move_source_failure_keeps_memory_disk_and_retry_consistent(self):
        target = self.presets / 'other.json'
        self.write_preset(dict(self.data, categories=[]), target.name)
        window = self.window()
        window.toggle_edit_mode()
        source = self.presets / 'test.json'
        before = {p: p.read_bytes() for p in (source, target)}
        original_save = modern.save_preset
        def denied(path, data):
            if Path(path) == source:
                raise PermissionError('source locked')
            original_save(path, data)
        old_memory = copy.deepcopy(window.data)
        with patch.object(modern, 'save_preset', side_effect=denied):
            window.move_category_to_preset(0, target)
        for p, content in before.items():
            self.assertEqual(p.read_bytes(), content)
        self.assertEqual(window.data, old_memory)
        window.move_category_to_preset(0, target)
        self.assertEqual(len(storage.load_json(target, {})['categories']), 1)
        self.assertEqual(len(window.data['categories']), 2)
        self.assertEqual(window.data, storage.load_json(source, {}))

    def test_settings_failure_restores_visibility_memory_and_both_files(self):
        for cls, module in ((classic.MainWindow, classic), (modern.ModernWindow, modern)):
            for fail_name in ('setting.json', 'test.json'):
                with self.subTest(cls=cls.__name__, fail_name=fail_name):
                    window = self.window(cls)
                    window.drag_bar.show()
                    original_save = module.save_json
                    before_settings, before_data = copy.deepcopy(window.settings), copy.deepcopy(window.data)
                    paths = (self.root / 'setting.json', self.presets / 'test.json')
                    before = {p: p.read_bytes() for p in paths}
                    def denied(path, data):
                        if Path(path).name == fail_name:
                            raise PermissionError('settings save denied')
                        original_save(path, data)
                    values = dict(window.settings, ui_width=600, theme='Dark Gray', modern_theme='Dark Gray')
                    with patch.object(module.SettingsDialog, 'exec', return_value=QDialog.DialogCode.Accepted), \
                         patch.object(module.SettingsDialog, 'values', return_value=values), \
                         patch.object(module, 'save_json', side_effect=denied):
                        window.open_settings()
                        if module is modern:
                            window._settings_dialog.accept()
                            perf.finish_transition(window)
                    self.assertTrue(window.isVisible())
                    self.assertTrue(window.drag_bar.isVisible())
                    self.assertTrue(window.drag_bar.isEnabled())
                    self.assertEqual(window.settings, before_settings)
                    self.assertEqual(window.data, before_data)
                    for p, content in before.items():
                        self.assertEqual(p.read_bytes(), content)

    def test_classic_bar_remains_accessible_after_drag_and_width_change(self):
        window = self.window(classic.MainWindow)
        for side in ('left', 'right'):
            window.settings['drag_bar_position'] = side
            window.move_from_bar(QPoint(10000, 10000))
            bounds = window.screen().availableGeometry()
            self.assertTrue(bounds.contains(window.drag_bar.frameGeometry()))
            window.setFixedWidth(600)
            window.update_pair_geometry()
            self.assertTrue(bounds.contains(window.drag_bar.frameGeometry()))
            expected = window.x() - window.drag_bar.width() if side == 'left' else window.x() + window.width()
            self.assertEqual(window.drag_bar.x(), expected)

    def test_settings_success_commits_both_files_and_clamps_wider_bar(self):
        for cls, module in ((classic.MainWindow, classic), (modern.ModernWindow, modern)):
            with self.subTest(cls=cls.__name__):
                window = self.window(cls)
                window.move(570, 50)
                values = dict(window.settings, ui_width=600, theme='Dark Gray', modern_theme='Dark Gray',
                              ui_style='Classic' if cls is classic.MainWindow else 'Modern')
                with patch.object(module.SettingsDialog, 'exec', return_value=QDialog.DialogCode.Accepted), \
                     patch.object(module.SettingsDialog, 'values', return_value=values):
                    window.open_settings()
                    if module is modern:
                        window._settings_dialog.accept()
                        perf.finish_transition(window)
                self.assertEqual(storage.load_json(self.presets / 'test.json', {})['ui_width'], 600)
                self.assertEqual(storage.load_json(self.root / 'setting.json', {})['ui_style'], values['ui_style'])
                self.assertTrue(window.screen().availableGeometry().contains(window.drag_bar.frameGeometry()))
                self.assertTrue(window.isVisible())

    def test_modern_long_edit_list_last_menu_and_add_button_are_accessible(self):
        self.write_preset(dict(self.data, categories=[{'name': 'long', 'items': [
            {'name': f'item{i}', 'type': 'text', 'text': f'text{i}'} for i in range(60)]}]))
        window = self.window()
        window.toggle_edit_mode()
        scroll = window.category_scroll
        window.category_panels[0].set_expanded(True, False)
        window.adjust_window_height()
        perf.drain()
        scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum())
        perf.drain()
        button = window.category_panels[0].rows[-1].menu_btn
        center = button.mapTo(scroll.viewport(), button.rect().center())
        self.assertTrue(scroll.viewport().rect().contains(center))
        with patch.object(window, 'item_menu') as menu:
            QTest.mouseClick(button, Qt.MouseButton.LeftButton)
            menu.assert_called_once_with(0, 59)
        bounds = window.screen().availableGeometry()
        self.assertTrue(bounds.contains(window.add_category_btn.mapToGlobal(window.add_category_btn.rect().center())))

    def test_classic_counts_remain_correct_and_json_names_are_unchanged(self):
        before = (self.presets / 'test.json').read_bytes()
        window = self.window(classic.MainWindow)
        labels = [window.list_widget.itemWidget(window.list_widget.item(i)).findChild(classic.ElidedLabel).toolTip()
                  for i in range(window.list_widget.count())]
        self.assertIn('文書 (3)', labels)
        self.assertIn('空カテゴリ (0)', labels)
        self.assertEqual((self.presets / 'test.json').read_bytes(), before)

    def test_both_long_lists_allow_last_item_click_and_keep_controls_on_screen(self):
        data = dict(self.data, categories=[{'name': 'long', 'items': [
            {'name': f'item{i}', 'type': 'text', 'text': f'text{i}'} for i in range(60)]}])
        self.write_preset(data)
        for cls in (classic.MainWindow, modern.ModernWindow):
            with self.subTest(cls=cls.__name__):
                window = self.window(cls)
                window.move(100, 80)
                if cls is classic.MainWindow:
                    window.expanded = {0}
                    window.refresh_main_list()
                    last = window.list_widget.item(window.list_widget.count() - 1)
                    window.list_widget.scrollToItem(last, QAbstractItemView.ScrollHint.PositionAtBottom)
                    perf.drain()
                    rect = window.list_widget.visualItemRect(last)
                    self.assertTrue(window.list_widget.viewport().rect().contains(rect.center()))
                    QTest.mouseClick(window.list_widget.viewport(), Qt.MouseButton.LeftButton, pos=rect.center())
                    control = window.settings_button
                else:
                    window.category_panels[0].set_expanded(True, False)
                    window.adjust_window_height()
                    perf.drain()
                    scroll = window.category_scroll
                    scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum())
                    perf.drain()
                    row = window.category_panels[0].rows[-1]
                    center = row.mapTo(scroll.viewport(), row.rect().center())
                    self.assertTrue(scroll.viewport().rect().contains(center))
                    QTest.mouseClick(row, Qt.MouseButton.LeftButton, pos=row.rect().center())
                    control = window.settings_btn
                self.assertEqual(perf.APP.clipboard().text(), 'text59')
                bounds = window.screen().availableGeometry()
                self.assertLessEqual(window.height(), bounds.height())
                self.assertTrue(bounds.contains(control.mapToGlobal(control.rect().center())))

    def test_classic_invalid_rename_is_rejected_without_moving_file(self):
        window = self.window(classic.MainWindow)
        dialog = classic.RegistrationDialog(window)
        self.addCleanup(dialog.deleteLater)
        item = dialog.preset_list.item(0)
        dialog.preset_list.setCurrentItem(item)
        for name in ('../escaped', 'C:\\escaped', 'CON', 'name.', '..'):
            with self.subTest(name=name):
                fake = SimpleNamespace(exec=lambda: QDialog.DialogCode.Accepted, value=lambda: name)
                with patch.object(dialog, 'sender', return_value=dialog.preset_list), \
                     patch.object(dialog.preset_list, 'itemAt', return_value=item), \
                     patch.object(classic, 'NameDialog', return_value=fake):
                    dialog.context_menu(QPoint())
                self.assertTrue((self.presets / 'test.json').exists())
                self.assertFalse((self.root / 'escaped.json').exists())

    def test_browser_false_and_shell_exception_do_not_hide_and_show_reason(self):
        for cls in (classic.MainWindow, modern.ModernWindow):
            window = self.window(cls)
            with self.subTest(cls=cls.__name__):
                with patch.object(common.webbrowser, 'open', return_value=False):
                    if cls is classic.MainWindow:
                        self.assertFalse(window.try_launch_item(self.data['categories'][1]['items'][0]))
                    else:
                        window.activate_item(1, 0)
                    self.assertTrue(window.isVisible())
                with patch.object(os, 'startfile', side_effect=OSError('no association'), create=True):
                    if cls is classic.MainWindow:
                        self.assertFalse(window.try_launch_item(self.data['categories'][0]['items'][0]))
                    else:
                        window.activate_item(0, 0)
                    self.assertTrue(window.isVisible())
                self.assertGreaterEqual(self.warning.call_count, 2)

    def test_hide_button_cancels_all_transition_phases_and_allows_reveal(self):
        def wait_for(predicate):
            for _ in range(400):
                perf.drain()
                if predicate():
                    return
                QTest.qWait(5)
            self.fail('transition phase was not reached')
        for phase in ('hide_vertical', 'hide_horizontal', 'show_horizontal', 'show_vertical', 'edit_in', 'edit_out'):
            with self.subTest(phase=phase):
                window = self.window()
                window.category_panels[0].set_expanded(True, False)
                window.adjust_window_height()
                if phase == 'edit_out':
                    window.toggle_edit_mode()
                if phase.startswith('show'):
                    window.toggle_from_bar()
                    perf.finish_transition(window)
                window.settings['animation_speed'] = 'normal'
                for panel in window.category_panels:
                    panel.set_animation_speed('normal')
                if phase.startswith('edit'):
                    window.toggle_edit_mode()
                else:
                    window.toggle_from_bar()
                if phase == 'hide_horizontal':
                    wait_for(lambda: window._slide_animation is not None)
                elif phase == 'show_vertical':
                    wait_for(lambda: window._bar_phase_fit)
                self.assertTrue(window._slide_animating)
                QTest.mouseClick(window.drag_bar, Qt.MouseButton.LeftButton,
                                 pos=QPoint(window.drag_bar.width() // 2, window.drag_bar.height() - 12))
                self.assertFalse(window.isVisible())
                self.assertFalse(window.drag_bar.isVisible())
                QTest.qWait(700)
                perf.drain()
                self.assertFalse(window.isVisible())
                self.assertFalse(window.drag_bar.isVisible())
                self.assertFalse(window._slide_animating)
                self.assertEqual(window._snapshot_proxies, [])
                window.reveal_from_secondary_instance()
                self.assertTrue(window.isVisible())
                self.assertTrue(window.drag_bar.isVisible())


class SafeBuildTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'icon.ico').write_bytes(b'synthetic icon')
        (self.root / 'main.py').write_text('print("synthetic build test")', encoding='utf-8')
        self.target = self.root / 'dist' / 'ExLauncher'
        (self.target / '登録情報').mkdir(parents=True)
        (self.target / 'ExLauncher.exe').write_bytes(b'old exe')
        (self.target / 'setting.json').write_bytes(b'original settings')
        (self.target / '登録情報' / 'user.json').write_bytes(b'important preset')
        (self.target / 'custom.txt').write_bytes(b'unknown user file')
        self.before = {str(p.relative_to(self.target)): p.read_bytes() for p in self.target.rglob('*') if p.is_file()}

    def fake_build(self, args, **kwargs):
        output = Path(args[args.index('--distpath') + 1]) / 'ExLauncher'
        output.mkdir(parents=True)
        (output / 'ExLauncher.exe').write_bytes(b'new exe')
        if os.name != 'nt':
            (output / 'ExLauncher').write_bytes(b'new executable')

    def test_success_keeps_user_data_and_full_previous_installation(self):
        with patch.object(build_onedir.subprocess, 'run', side_effect=self.fake_build):
            build_onedir.build(self.root)
        self.assertEqual((self.target / 'ExLauncher.exe').read_bytes(), b'new exe')
        self.assertEqual((self.target / 'setting.json').read_bytes(), b'original settings')
        self.assertEqual((self.target / '登録情報' / 'user.json').read_bytes(), b'important preset')
        backup, = list(self.target.parent.glob('ExLauncher.previous-*'))
        for name, content in self.before.items():
            self.assertEqual((backup / name).read_bytes(), content)

    def test_build_failure_never_deletes_existing_output(self):
        with patch.object(build_onedir.subprocess, 'run', side_effect=subprocess.CalledProcessError(1, 'synthetic')):
            with self.assertRaises(subprocess.CalledProcessError):
                build_onedir.build(self.root)
        for name, content in self.before.items():
            self.assertEqual((self.target / name).read_bytes(), content)

    def test_missing_icon_stops_before_build_and_output_changes(self):
        (self.root / 'icon.ico').unlink()
        with patch.object(build_onedir.subprocess, 'run') as build:
            with self.assertRaises(FileNotFoundError):
                build_onedir.build(self.root)
        build.assert_not_called()
        for name, content in self.before.items():
            self.assertEqual((self.target / name).read_bytes(), content)

    def test_publication_failure_restores_previous_installation(self):
        staged = self.root / 'new'
        staged.mkdir()
        (staged / 'ExLauncher.exe').write_bytes(b'new')
        real_rename = Path.rename
        def denied(path, target):
            if path == staged:
                raise PermissionError('output locked')
            return real_rename(path, target)
        with patch.object(Path, 'rename', denied):
            with self.assertRaises(PermissionError):
                build_onedir.publish(staged, self.target)
        for name, content in self.before.items():
            self.assertEqual((self.target / name).read_bytes(), content)


if __name__ == '__main__':
    unittest.main()
