"""Bar-attached settings: real Qt interactions with temporary data only."""
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from PySide6.QtCore import QPoint, QRect, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QDialogButtonBox
from shiboken6 import isValid

import test_performance_regressions as perf
import modern_main as modern
from modern_animation import BAR_SLIDE_DURATION_MS, CATEGORY_DURATION_MS, scaled_duration


class SettingsSlideTests(unittest.TestCase):
    write_preset = perf.LauncherTests.write_preset
    write_settings = perf.LauncherTests.write_settings
    window = perf.LauncherTests.window

    def setUp(self):
        perf.LauncherTests.setUp(self)

    def wait_for(self, predicate):
        for _ in range(400):
            perf.drain()
            if predicate():
                return
            QTest.qWait(5)
        self.fail('Settings transition did not reach the requested state')

    def files(self):
        return {p: p.read_bytes() for p in (self.root / 'setting.json', self.presets / 'test.json')}

    def assert_attached(self, window):
        dlg = window._settings_dialog
        self.assertTrue(dlg.isVisible())
        self.assertFalse(window.isVisible())
        self.assertEqual(window.drag_bar.height(), dlg.height())
        self.assertEqual(window.drag_bar.y(), dlg.y())
        if window._settings_side == 'left':
            self.assertEqual(window.drag_bar.x() + window.drag_bar.width(), dlg.x())
        else:
            self.assertEqual(dlg.x() + dlg.width(), window.drag_bar.x())

    def test_open_close_stage_order_and_shared_duration_on_both_sides(self):
        for side, speed in (('left', 'fast'), ('right', 'normal')):
            with self.subTest(side=side, speed=speed):
                window = self.window()
                window.settings.update(drag_bar_position=side, animation_speed=speed)
                window.apply_settings()
                window.move_from_bar(QPoint(400, 80))
                window.category_panels[0].set_expanded(True, False)
                window.adjust_window_height()
                rows = window.category_panels[0].rows[:]
                horizontal = []
                original = window._animate_clipped_horizontal

                def observe(pix, pos, hiding, duration, finished, **kwargs):
                    horizontal.append((window._settings_phase, hiding, duration,
                                       window.drag_bar.height(), pos, pix.size(), kwargs))
                    original(pix, pos, hiding, duration, finished, **kwargs)

                with patch.object(window, '_animate_clipped_horizontal', side_effect=observe):
                    QTest.mouseClick(window.settings_btn, Qt.MouseButton.LeftButton)
                    self.assertEqual(window._settings_phase, 'categories_hide')
                    self.assertTrue(window.category_panels[0]._animating)
                    self.wait_for(lambda: window._settings_phase == 'bar_resize')
                    self.assertFalse(window.isVisible())
                    self.assertFalse(window._settings_dialog.isVisible())
                    self.assertTrue(all(not p.expanded for p in window.category_panels))
                    self.assertEqual(window._slide_animation.duration(), scaled_duration(CATEGORY_DURATION_MS, speed))
                    self.wait_for(lambda: window._settings_phase == 'settings_show')
                    self.assertEqual(window._slide_animation.duration(), scaled_duration(BAR_SLIDE_DURATION_MS, speed))
                    perf.finish_transition(window)
                    self.assert_attached(window)
                    self.assertEqual(window._snapshot_proxies, [])
                    button = window._settings_dialog.buttons.button(QDialogButtonBox.StandardButton.Cancel)
                    QTest.mouseClick(button, Qt.MouseButton.LeftButton)
                    perf.finish_transition(window)
                self.assertEqual([(x[0], x[1]) for x in horizontal], [
                    ('categories_hide', True), ('settings_show', False),
                    ('settings_hide', True), (None, False)])
                self.assertEqual(horizontal[1][2], BAR_SLIDE_DURATION_MS)
                self.assertEqual(horizontal[1][3], horizontal[1][5].height())
                self.assertTrue(window.isVisible())
                self.assertEqual([p.expanded for p in window.category_panels], [True, False, False])
                self.assertEqual(window.category_panels[0].rows, rows)
                self.assertEqual(window.drag_bar.height(), window.height())

    def test_none_is_immediate_and_cancel_never_saves_or_builds_closed_rows(self):
        window = self.window()
        before = self.files()
        with patch.object(window, 'item_icon') as icons, patch.object(modern.SettingsDialog, 'exec') as nested:
            window.open_settings()
            self.assertEqual(window._settings_phase, 'shown')
            self.assertFalse(window._slide_animating)
            self.assert_attached(window)
            dlg = window._settings_dialog
            dlg.width_spin.setValue(600)
            dlg.theme.setCurrentText('Navy')
            window.open_settings()
            self.assertIs(window._settings_dialog, dlg)
            QTest.keyClick(dlg, Qt.Key.Key_Escape)
            self.assertIsNone(window._settings_dialog)
            self.assertTrue(window.isVisible())
            self.assertFalse(window._slide_animating)
            self.assertTrue(all(not p.rows for p in window.category_panels))
            icons.assert_not_called()
            nested.assert_not_called()
        self.assertEqual(self.files(), before)

    def test_real_ok_saves_theme_width_side_speed_and_retains_category_identity(self):
        window = self.window()
        window.category_panels[1].set_expanded(True, False)
        window.open_settings()
        dlg = window._settings_dialog
        dlg.width_spin.setValue(600)
        dlg.theme.setCurrentText('Navy')
        dlg.position.setCurrentText('left')
        dlg.animation_speed.setCurrentIndex(dlg.animation_speed.findData('fast'))
        dlg.ui_style.setCurrentText('Modern')
        with patch.object(window, '_animate_clipped_horizontal', wraps=window._animate_clipped_horizontal) as slide:
            QTest.mouseClick(dlg.buttons.button(QDialogButtonBox.StandardButton.Ok), Qt.MouseButton.LeftButton)
            self.assertEqual(slide.call_args_list[0].kwargs['side'], 'right')
            perf.finish_transition(window)
        saved = json.loads((self.root / 'setting.json').read_text())
        self.assertEqual((saved['drag_bar_position'], saved['animation_speed']), ('left', 'fast'))
        self.assertEqual(window.data['modern_theme'], 'Navy')
        self.assertEqual(window.width(), 540)
        self.assertEqual(json.loads((self.presets / 'test.json').read_text())['ui_width'], 600)
        self.assertTrue(window.isVisible())
        window.rebuild_categories()
        self.assertEqual([p.expanded for p in window.category_panels], [False, True, False])
        self.assertEqual(window.drag_bar.x() + window.drag_bar.width(), window.x())

    def test_drag_keeps_settings_attached_and_secondary_instance_keeps_them_front(self):
        window = self.window()
        for side in ('left', 'right'):
            window.settings['drag_bar_position'] = side
            window.apply_settings()
            window.open_settings()
            dlg = window._settings_dialog
            for pos in (QPoint(500, 100), QPoint(-1000, -1000), QPoint(10000, 10000)):
                window.move_from_bar(pos)
                self.assert_attached(window)
                bounds = window.drag_bar.screen().availableGeometry()
                self.assertTrue(bounds.contains(dlg.frameGeometry()))
                self.assertTrue(bounds.contains(window.drag_bar.frameGeometry()))
            window.reveal_from_secondary_instance()
            self.assert_attached(window)
            with patch.object(modern, 'QuickSearchDialog') as search:
                window.open_quick_search()
                search.assert_not_called()
            window.toggle_edit_mode()
            self.assertFalse(window.edit_mode)
            window.toggle_from_bar()
            self.assertIsNone(window._settings_dialog)
            self.assertTrue(window.isVisible())

    def test_small_screen_scrolls_form_and_keeps_buttons_visible(self):
        window = self.window()
        screen = SimpleNamespace(availableGeometry=lambda: QRect(0, 0, 700, 230))
        with patch.object(window.drag_bar, 'screen', return_value=screen):
            window.open_settings()
            dlg = window._settings_dialog
            perf.drain()
            self.assertEqual(dlg.height(), 230)
            self.assertEqual(window.drag_bar.height(), 230)
            self.assertGreater(dlg.form_scroll.verticalScrollBar().maximum(), 0)
            button = dlg.buttons.button(QDialogButtonBox.StandardButton.Cancel)
            self.assertTrue(dlg.rect().contains(button.mapTo(dlg, button.rect().center())))
            QTest.mouseClick(button, Qt.MouseButton.LeftButton)

    def test_hide_cancels_every_settings_phase_without_late_reappearance(self):
        for phase in ('categories_hide', 'bar_resize', 'settings_show', 'shown',
                      'settings_hide', 'bar_restore'):
            with self.subTest(phase=phase):
                window = self.window()
                window.settings['animation_speed'] = 'fast'
                window.apply_settings()
                window.category_panels[0].set_expanded(True, False)
                before = self.files()
                window.open_settings()
                dlg = window._settings_dialog
                if phase in ('settings_hide', 'bar_restore'):
                    self.wait_for(lambda: window._settings_phase == 'shown')
                    dlg.reject()
                self.wait_for(lambda: window._settings_phase == phase)
                window.hide_main()
                QTest.qWait(250)
                perf.drain()
                self.assertFalse(window.isVisible())
                self.assertFalse(window.drag_bar.isVisible())
                self.assertTrue(not isValid(dlg) or not dlg.isVisible())
                self.assertIsNone(window._settings_dialog)
                self.assertFalse(window._slide_animating)
                self.assertEqual(window._snapshot_proxies, [])
                self.assertEqual(self.files(), before)
                window.reveal_from_secondary_instance()
                self.assertTrue(window.isVisible())
                self.assertEqual([p.expanded for p in window.category_panels], [True, False, False])

    def test_shutdown_discards_settings_and_snapshots(self):
        window = self.window()
        window.settings['animation_speed'] = 'slow'
        window.open_settings()
        self.wait_for(lambda: window._settings_phase == 'settings_show')
        dlg = window._settings_dialog
        window.shutdown_for_switch()
        QTest.qWait(400)
        perf.drain()
        self.assertIsNone(window._settings_dialog)
        self.assertFalse(window._slide_animating)
        self.assertEqual(window._snapshot_proxies, [])
        self.assertFalse(isValid(dlg))

    def test_saved_values_survive_hide_during_closing_animation(self):
        window = self.window()
        window.open_settings()
        dlg = window._settings_dialog
        dlg.width_spin.setValue(600)
        dlg.ui_style.setCurrentText('Modern')
        dlg.animation_speed.setCurrentIndex(dlg.animation_speed.findData('slow'))
        dlg.accept()
        self.assertEqual(window._settings_phase, 'settings_hide')
        window.hide_main()
        QTest.qWait(400)
        window.reveal_from_secondary_instance()
        self.assertTrue(window.isVisible())
        self.assertEqual(window.width(), 540)
        self.assertEqual(window.data['ui_width'], 600)
        self.assertEqual(json.loads((self.presets / 'test.json').read_text())['ui_width'], 600)

    def test_classic_switch_waits_until_settings_have_closed(self):
        window = self.window()
        window.open_settings()
        dlg = window._settings_dialog
        dlg.ui_style.setCurrentText('Classic')
        dlg.animation_speed.setCurrentIndex(dlg.animation_speed.findData('fast'))
        with patch.object(modern, 'restart_via_dispatcher') as restart:
            dlg.accept()
            restart.assert_not_called()
            perf.finish_transition(window)
            restart.assert_called_once_with()
            self.assertIsNone(window._settings_dialog)
            self.assertFalse(window.isVisible())


if __name__ == '__main__':
    unittest.main()
