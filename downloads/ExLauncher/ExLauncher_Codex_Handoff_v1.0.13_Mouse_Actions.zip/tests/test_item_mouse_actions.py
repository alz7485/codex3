"""File items: right click edits; middle click reveals, with no external execution."""
import os
import unittest
from unittest.mock import patch
from PySide6.QtCore import Qt,QPoint
from PySide6.QtGui import QContextMenuEvent
from PySide6.QtWidgets import QApplication,QDialog
from PySide6.QtTest import QTest
import test_performance_regressions as perf
import classic_main as classic
import modern_main as modern


class MouseActionTests(unittest.TestCase):
    write_preset=perf.LauncherTests.write_preset
    write_settings=perf.LauncherTests.write_settings
    window=perf.LauncherTests.window

    def setUp(self):
        perf.LauncherTests.setUp(self)

    def open_rows(self, module):
        window=self.window(classic.MainWindow if module is classic else modern.ModernWindow)
        if module is classic:
            window.expanded={0};window.refresh_main_list()
        else:
            window.category_panels[0].set_expanded(True,False)
        perf.drain()
        return window

    def click(self,window,module,index,button):
        if module is classic:
            viewport=window.list_widget.viewport()
            point=window.list_widget.visualItemRect(window.list_widget.item(index+1)).center()
            if button==Qt.MouseButton.RightButton:
                # Deliver the native context-menu event to the actual viewport.
                event=QContextMenuEvent(QContextMenuEvent.Reason.Mouse,point,viewport.mapToGlobal(point))
                QApplication.sendEvent(viewport,event)
            else:
                QTest.mouseClick(viewport,button,pos=point)
        else:
            QTest.mouseClick(window.category_panels[0].rows[index].text_label,button)

    def test_file_right_click_opens_editor_and_saves_without_revealing(self):
        for module in (classic,modern):
            with self.subTest(module=module.__name__):
                window=self.open_rows(module)
                replacement=dict(window.data['categories'][0]['items'][0],name='Renamed app')
                with patch.object(module,'ItemEditDialog') as dialog,patch.object(module.subprocess,'Popen') as reveal:
                    dialog.return_value.exec.return_value=QDialog.DialogCode.Accepted
                    dialog.return_value.value.return_value=replacement
                    self.click(window,module,0,Qt.MouseButton.RightButton)
                    dialog.assert_called_once()
                    self.assertEqual(dialog.call_args.args[0]['path'],str(self.file))
                    reveal.assert_not_called()
                self.assertEqual(window.data['categories'][0]['items'][0],replacement)
                self.assertTrue(self.file.exists())
                # Restore for the next independent module's setup.
                self.write_preset(self.data)

    def test_file_middle_click_reveals_without_editing_or_launching(self):
        for module in (classic,modern):
            with self.subTest(module=module.__name__):
                window=self.open_rows(module)
                with patch.object(module.subprocess,'Popen') as reveal,patch.object(module,'ItemEditDialog') as dialog,patch.object(module,'launch_item') as launch:
                    self.click(window,module,0,Qt.MouseButton.MiddleButton)
                    reveal.assert_called_once_with(['explorer.exe','/select,',os.path.normpath(str(self.file))])
                    dialog.assert_not_called();launch.assert_not_called()

    def test_virtual_scrolled_last_file_has_same_mouse_actions(self):
        items=[{'type':'file','name':f'App {i}','path':str(self.file)} for i in range(201)]
        self.write_preset(dict(self.data,categories=[{'name':'Apps','items':items}]))
        window=self.open_rows(modern)
        view=window.category_panels[0].virtual_list
        view.scrollToBottom();perf.drain()
        point=view.visualRect(view.model().index(200)).center()
        with patch.object(modern.subprocess,'Popen') as reveal,patch.object(modern,'ItemEditDialog') as dialog:
            dialog.return_value.exec.return_value=QDialog.DialogCode.Rejected
            QTest.mouseClick(view.viewport(),Qt.MouseButton.RightButton,pos=point)
            self.assertEqual(dialog.call_args.args[0]['name'],'App 200')
            reveal.assert_not_called()
            QTest.mouseClick(view.viewport(),Qt.MouseButton.MiddleButton,pos=point)
            reveal.assert_called_once_with(['explorer.exe','/select,',os.path.normpath(str(self.file))])

    def test_middle_click_ignores_nonfiles_missing_files_and_modern_edit_mode(self):
        for module in (classic,modern):
            with self.subTest(module=module.__name__):
                window=self.open_rows(module)
                with patch.object(module.subprocess,'Popen') as reveal,patch.object(module,'ItemEditDialog') as dialog:
                    for index in (1,2):
                        self.click(window,module,index,Qt.MouseButton.MiddleButton)
                    window.data['categories'][0]['items'][0]['path']=str(self.root/'missing.exe')
                    self.click(window,module,0,Qt.MouseButton.MiddleButton)
                    if module is modern:
                        window.data['categories'][0]['items'][0]['path']=str(self.file)
                        window.toggle_edit_mode()
                        self.click(window,module,0,Qt.MouseButton.MiddleButton)
                    reveal.assert_not_called();dialog.assert_not_called()


if __name__=='__main__':unittest.main()
