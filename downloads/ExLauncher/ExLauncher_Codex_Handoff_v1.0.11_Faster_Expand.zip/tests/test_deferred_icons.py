"""Opening categories must not wait for OS file-icon lookup."""
import gc
import weakref
from unittest.mock import patch
import unittest

from PySide6.QtGui import QIcon, QPixmap, QColor
from PySide6.QtTest import QTest
from shiboken6 import isValid

import test_performance_regressions as perf


class DeferredIconTests(unittest.TestCase):
    write_preset = perf.LauncherTests.write_preset
    write_settings = perf.LauncherTests.write_settings
    window = perf.LauncherTests.window

    def setUp(self):
        perf.LauncherTests.setUp(self)
        pix = QPixmap(16, 16)
        pix.fill(QColor('magenta'))
        self.icon = QIcon(pix)

    def files(self, count, duplicate=False):
        return [{'type': 'file', 'name': f'Long_name_{i}_' * 8,
                 'path': str(self.file if duplicate else self.root / f'file_{i}.txt')}
                for i in range(count)]

    def make_window(self, count=10, duplicate=False):
        items = self.files(count, duplicate)
        self.write_preset(dict(self.data, categories=[{'name': 'Files', 'items': items}]))
        return self.window()

    def test_first_open_never_resolves_icons_before_or_during_animation(self):
        window = self.make_window(50)
        panel = window.category_panels[0]
        panel.set_animation_speed('normal')
        with patch.object(window.file_icons, 'icon', return_value=self.icon) as native:
            panel.set_expanded(True, True)
            self.assertTrue(panel._animating)
            native.assert_not_called()
            window._load_next_item_icon()
            native.assert_not_called()
            # A real animation completes before native icon processing begins.
            while panel._animating:
                QTest.qWait(5)
            native.assert_not_called()
            window._load_next_item_icon()
            self.assertEqual(native.call_count, 1)
            self.assertEqual(len(panel.rows), 50)
            self.assertEqual(panel.rows[0].icon_label.pixmap().toImage().pixelColor(7, 7), QColor('magenta'))

    def test_duplicate_paths_resolve_once_and_reopening_uses_cache(self):
        window = self.make_window(10, duplicate=True)
        panel = window.category_panels[0]
        with patch.object(window.file_icons, 'icon', return_value=self.icon) as native:
            panel.set_expanded(True, False)
            native.assert_not_called()
            QTest.qWait(50)
            self.assertEqual(native.call_count, 1)
            self.assertTrue(all(r.icon_label.pixmap().toImage().pixelColor(7, 7) == QColor('magenta')
                                for r in panel.rows))
            panel.set_expanded(False, False)
            panel.set_expanded(True, False)
            QTest.qWait(30)
            self.assertEqual(native.call_count, 1)

    def test_collapse_skips_pending_icons_and_reopen_requeues_them(self):
        window = self.make_window()
        panel = window.category_panels[0]
        with patch.object(window.file_icons, 'icon', return_value=self.icon) as native:
            panel.set_expanded(True, False)
            panel.set_expanded(False, False)
            window._load_next_item_icon()
            native.assert_not_called()
            self.assertFalse(window._pending_item_icons)
            panel.set_expanded(True, False)
            window._load_next_item_icon()
            self.assertEqual(native.call_count, 1)

    def test_rebuild_cancels_old_requests_and_updates_only_new_rows(self):
        window = self.make_window()
        panel = window.category_panels[0]
        panel.set_expanded(True, False)
        old = panel.rows[0]
        window.data['categories'][0]['items'] = [
            {'type': 'folder', 'name': 'new folder', 'path': str(self.root / 'new')}]
        with patch.object(window.file_icons, 'icon', return_value=self.icon) as native:
            window.rebuild_categories()
            perf.drain()
            self.assertFalse(isValid(old))
            window._load_next_item_icon()
            self.assertEqual(native.call_count, 1)
            self.assertEqual(native.call_args.args[0].filePath(), str(self.root / 'new'))
            self.assertEqual(window.category_panels[0].rows[0].text_label.text(), 'new folder')

    def test_hide_pauses_and_secondary_reveal_resumes_without_old_callbacks(self):
        window = self.make_window(10, duplicate=True)
        panel = window.category_panels[0]
        with patch.object(window.file_icons, 'icon', return_value=self.icon) as native:
            panel.set_expanded(True, False)
            window.hide_main()
            self.assertFalse(window._item_icon_timer.isActive())
            window._load_next_item_icon()
            native.assert_not_called()
            window.reveal_from_secondary_instance()
            QTest.qWait(50)
            self.assertEqual(native.call_count, 1)
            window.shutdown_for_switch()
            self.assertFalse(window._item_icon_timer.isActive())
            self.assertFalse(window._pending_item_icons)
            window._load_next_item_icon()
            self.assertEqual(native.call_count, 1)

    def test_virtual_list_paints_without_native_lookup_then_refreshes_visible_icons(self):
        window = self.make_window(201)
        panel = window.category_panels[0]
        with patch.object(window.file_icons, 'icon', return_value=self.icon) as native:
            panel.set_expanded(True, False)
            perf.drain()
            view = panel.virtual_list
            view.viewport().grab()
            native.assert_not_called()
            self.assertTrue(window._pending_item_icons)
            self.assertLess(len(window._pending_item_icons), 201)
            window._load_next_item_icon()
            self.assertEqual(native.call_count, 1)
            self.assertEqual(len(window._item_icon_cache), 1)
            view.scrollToBottom()
            perf.drain()
            view.viewport().grab()
            self.assertIn(('file', str(self.root / 'file_200.txt')), window._pending_item_icons)
            self.assertEqual(native.call_count, 1)

    def test_null_icon_is_cached_as_fallback_and_does_not_retry(self):
        window = self.make_window(10, duplicate=True)
        with patch.object(window.file_icons, 'icon', return_value=QIcon()) as native:
            panel = window.category_panels[0]
            panel.set_expanded(True, False)
            window._load_next_item_icon()
            self.assertFalse(panel.rows[0].icon_label.pixmap().isNull())
            panel.set_expanded(False, False)
            panel.set_expanded(True, False)
            QTest.qWait(30)
            self.assertEqual(native.call_count, 1)

    def test_queue_does_not_keep_removed_row_objects_alive(self):
        window = self.make_window()
        panel = window.category_panels[0]
        panel.set_expanded(True, False)
        reference = weakref.ref(panel.rows[0])
        # Pending consumers hold weak references. Rebuild must release old requests.
        window.data['categories'] = []
        window.rebuild_categories()
        del panel
        perf.drain()
        gc.collect()
        self.assertTrue(reference() is None or not isValid(reference()))
        self.assertFalse(window._pending_item_icons)

    def test_icon_error_keeps_fallback_and_continues_remaining_requests(self):
        window = self.make_window(2)
        panel = window.category_panels[0]
        with patch.object(window.file_icons, 'icon', side_effect=[OSError('synthetic'), self.icon]) as native:
            panel.set_expanded(True, False)
            window._load_next_item_icon()
            self.assertFalse(panel.rows[0].icon_label.pixmap().isNull())
            window._load_next_item_icon()
            self.assertEqual(native.call_count, 2)
            self.assertEqual(panel.rows[1].icon_label.pixmap().toImage().pixelColor(7, 7), QColor('magenta'))
            panel.set_expanded(False, False)
            panel.set_expanded(True, False)
            QTest.qWait(30)
            self.assertEqual(native.call_count, 2)


if __name__ == '__main__':
    unittest.main()
