"""Prepare a project venv, build in isolation, and retain portable data."""
import argparse
from datetime import datetime
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

DEPENDENCIES = {'PySide6': '6.8.3', 'PyInstaller': '6.11.1'}


def environment_python(root):
    return Path(root) / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def check_dependencies(python):
    code = (
        'import importlib.metadata as m; import PyInstaller; from PySide6 import QtCore; '
        f'assert all(m.version(k) == v for k, v in {DEPENDENCIES!r}.items())'
    )
    result = subprocess.run([str(python), '-c', code], capture_output=True,
                            text=True, encoding='utf-8', errors='replace')
    return result.returncode == 0, result.stdout + result.stderr


def prepare_environment(root):
    root = Path(root).resolve()
    requirements = root / 'requirements-build.txt'
    if not requirements.is_file():
        raise FileNotFoundError(f'Missing build requirements: {requirements}')
    python = environment_python(root)
    if not python.is_file():
        if not (3, 10) <= sys.version_info[:2] < (3, 14):
            raise RuntimeError('Use Python 3.10-3.13 (recommended: 3.11 or 3.12).')
        print(f'Creating project environment: {python.parent.parent}', flush=True)
        subprocess.run([sys.executable, '-m', 'venv', str(root / '.venv')], cwd=root, check=True)
    ready, _ = check_dependencies(python)
    if not ready:
        print('Installing PySide6 and PyInstaller into the project environment...', flush=True)
        subprocess.run([str(python), '-m', 'ensurepip', '--upgrade'], cwd=root, check=True)
        subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check',
                        '-r', str(requirements)], cwd=root, check=True)
        ready, details = check_dependencies(python)
        if not ready:
            raise RuntimeError(f'Build dependencies could not be loaded:\n{details}')
    print(f'Environment ready: {python}', flush=True)
    return python


def publish(staged, target):
    staged, target = Path(staged), Path(target)
    backup = None
    if target.exists():
        if not target.is_dir():
            raise ValueError(f'Output is not a directory: {target}')
        # All old files remain in the backup, including unknown user files.
        if (target / '登録情報').exists():
            shutil.copytree(target / '登録情報', staged / '登録情報', dirs_exist_ok=True)
        for pattern in ('setting.json', 'setting.json.*.bak', '.exlauncher-transaction.json'):
            for data_file in target.glob(pattern):
                shutil.copy2(data_file, staged / data_file.name)
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
        backup = target.with_name(f'{target.name}.previous-{stamp}')
        target.rename(backup)
    try:
        staged.rename(target)
    except OSError:
        if backup is not None:
            backup.rename(target)
        raise
    return backup


def build(root):
    root = Path(root).resolve()
    if not (root / 'icon.ico').is_file():
        raise FileNotFoundError('Put icon.ico next to build_onedir.bat, then run it again.')
    if not (root / 'main.py').is_file():
        raise FileNotFoundError('Extract the complete source ZIP; main.py is missing.')
    dist = root / 'dist'
    dist.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.exlauncher-build-', dir=dist) as temp:
        staging = Path(temp)
        subprocess.run([
            sys.executable, '-m', 'PyInstaller', '--clean', '--noconfirm', '--onedir', '--noconsole',
            '--icon', str(root / 'icon.ico'), '--add-data', f'{root / "icon.ico"}{os.pathsep}.',
            '--name', 'ExLauncher',
            '--distpath', str(staging / 'dist'), '--workpath', str(staging / 'build'),
            '--specpath', str(staging), str(root / 'main.py'),
        ], cwd=root, check=True)
        staged = staging / 'dist' / 'ExLauncher'
        executable = 'ExLauncher.exe' if os.name == 'nt' else 'ExLauncher'
        if not (staged / executable).is_file():
            raise FileNotFoundError(f'Build did not produce {executable}; existing output was retained.')
        backup = publish(staged, dist / 'ExLauncher')
    if backup:
        print(f'Previous installation retained: {backup}')


def main(argv=None, root=None):
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--setup-only', action='store_true', help='Prepare .venv for VS Code/F5 without building.')
    group.add_argument('--build-only', action='store_true', help='Build with the current prepared interpreter.')
    args = parser.parse_args(argv)
    root = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    try:
        if args.build_only:
            ready, details = check_dependencies(sys.executable)
            if not ready:
                raise RuntimeError('Run the environment setup task first, or run build_onedir.bat.\n' + details)
            build(root)
        else:
            python = prepare_environment(root)
            if not args.setup_only:
                subprocess.run([str(python), '-u', str(root / 'scripts/build_onedir.py'), '--build-only'],
                               cwd=root, check=True)
        return 0
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
        print(f'Build failed: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
