"""Synthetic Qt benchmark; never reads or changes real launcher settings.

QT_QPA_PLATFORM=offscreen python scripts/benchmark.py --source /path/to/source
Run each source in a separate process with the same Qt/Python environment.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import statistics
import sys
import tempfile
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--categories", type=int, default=20)
    parser.add_argument("--items-per-category", type=int, default=50)
    parser.add_argument("--presets", type=int, default=20)
    args = parser.parse_args()
    sys.path.insert(0, str(args.source.resolve()))

    from PySide6.QtCore import QCoreApplication, QEvent
    from PySide6.QtWidgets import QApplication
    app = QApplication([])
    app.setQuitOnLastWindowClosed(False)
    import classic_main as classic
    import modern_main as modern
    from quick_search import QuickSearchDialog

    results = {}

    def measure(name, fn):
        start = time.perf_counter()
        value = fn()
        results.setdefault(name, []).append((time.perf_counter() - start) * 1000)
        return value

    def drain():
        app.processEvents()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)

    with tempfile.TemporaryDirectory(prefix="exlauncher-bench-") as directory:
        root = Path(directory)
        preset_dir = root / "登録情報"
        preset_dir.mkdir()
        sample = root / "sample.txt"
        sample.write_text("benchmark", encoding="utf-8")
        data = {"ui_width": 220, "theme": "Dark Gray", "categories": [
            {"name": f"カテゴリ {ci}", "items": [
                {"name": f"項目 {ci}-{ii}", "type": "file", "path": str(sample)}
                for ii in range(args.items_per_category)
            ]} for ci in range(args.categories)
        ]}
        for pi in range(args.presets):
            (preset_dir / f"preset{pi:03}.json").write_text(
                json.dumps(data, ensure_ascii=False), encoding="utf-8")
        for module in (classic, modern):
            module.APP_DIR = root
            module.PRESET_DIR = preset_dir
            module.SETTING_FILE = root / "setting.json"
        for _ in range(args.repeats):
            (root / "setting.json").write_text(json.dumps({
                "current_preset": "preset000.json", "ui_style": "Modern",
                "pin": False, "drag_bar_position": "right",
                "allow_multiple_expand": True, "animation_speed": "none",
            }), encoding="utf-8")
            for name, cls in (("classic", classic.MainWindow), ("modern", modern.ModernWindow)):
                def construct():
                    window = cls()
                    window.show()
                    app.processEvents()
                    return window
                window = measure(name + "_construct_show_ms", construct)
                if name == "modern":
                    results.setdefault("modern_initial_rows", []).append(
                        sum(len(panel.rows) for panel in window.category_panels))
                    measure("modern_first_expand_ms",
                            lambda: window.category_panels[0].set_expanded(True, False))
                    measure("modern_rebuild_ms", window.rebuild_categories)
                    measure("modern_apply_settings_ms", window.apply_settings)
                    measure("modern_enter_edit_ms", window.toggle_edit_mode)
                    measure("modern_exit_edit_ms", window.toggle_edit_mode)
                window.shutdown_for_switch()
                window.drag_bar.hide()
                window.drag_bar.deleteLater()
                window.hide()
                window.deleteLater()
                drain()

            dialog = measure("search_construct_ms", lambda: QuickSearchDialog(data))
            for query in ("項目 1", "項目 1-2", "カテゴリ 19", "", "sample"):
                measure("search_filter_ms", lambda query=query: dialog._refresh(query))
            dialog.deleteLater()
            drain()
    print(json.dumps({
        "source": str(args.source.resolve()),
        "repeats": args.repeats,
        "categories": args.categories,
        "items_per_category": args.items_per_category,
        "presets": args.presets,
        "median": {key: round(statistics.median(values), 3) for key, values in results.items()},
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
