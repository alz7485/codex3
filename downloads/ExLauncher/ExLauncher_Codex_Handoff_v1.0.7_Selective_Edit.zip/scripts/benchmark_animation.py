"""Measure simultaneous category animation work with temporary synthetic data.

QT_QPA_PLATFORM=offscreen python scripts/benchmark_animation.py --source SOURCE
Compare versions in separate, sequential processes with the same Python/Qt.
These counts and CPU timings do not measure Windows display smoothness or FPS.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import statistics
import sys
import tempfile
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--counts", default="1,10,20")
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--items-per-category", type=int, default=3)
    args = parser.parse_args()
    counts = [int(n) for n in args.counts.split(",")]
    if args.repeats < 1 or args.items_per_category < 1 or not counts or min(counts) < 1:
        parser.error("counts, repeats and items-per-category must be positive")
    sys.path.insert(0, str(args.source.resolve()))

    from PySide6.QtCore import QCoreApplication, QEvent
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication
    import modern_main as modern

    app = QApplication([])
    app.setQuitOnLastWindowClosed(False)
    original = modern.ModernWindow.adjust_window_height
    sample = None

    def measured_adjust(window):
        if sample is None:
            return original(window)
        sample["height_adjustments"] += 1
        sample["panel_height_reads"] += len(window.category_panels)
        start = time.perf_counter()
        try:
            return original(window)
        finally:
            sample["height_adjustment_ms"] += (time.perf_counter() - start) * 1000

    modern.ModernWindow.adjust_window_height = measured_adjust
    results = []
    with tempfile.TemporaryDirectory(prefix="exlauncher-animation-") as directory:
        root = Path(directory)
        presets = root / "登録情報"
        presets.mkdir()
        modern.APP_DIR = root
        modern.PRESET_DIR = presets
        modern.SETTING_FILE = root / "setting.json"
        for count in counts:
            modern.SETTING_FILE.write_text(json.dumps({
                "current_preset": "test.json", "ui_style": "Modern",
                "animation_speed": "normal", "allow_multiple_expand": True,
                "pin": False, "drag_bar_position": "right",
            }), encoding="utf-8")
            (presets / "test.json").write_text(json.dumps({
                "theme": "Dark Gray", "ui_width": 200, "categories": [
                    {"name": str(ci), "items": [
                        {"type": "text", "name": "Test", "text": "Test"}
                        for _ in range(args.items_per_category)
                    ]} for ci in range(count)
                ],
            }), encoding="utf-8")
            window = modern.ModernWindow()
            window.show()
            # Exclude first-use row creation, startup fitting and theme setup.
            for panel in window.category_panels:
                if hasattr(panel, "_ensure_rows"):
                    panel._ensure_rows()
            QTest.qWait(300)
            measurements = {"expand": [], "collapse": []}
            for _ in range(args.repeats):
                for action in ("expand", "collapse"):
                    sample = {"height_adjustments": 0, "panel_height_reads": 0,
                              "height_adjustment_ms": 0.0}
                    marks = {}

                    def finished():
                        marks["last_finished"] = time.perf_counter()

                    for panel in window.category_panels:
                        panel.set_expanded(action == "expand", True)
                        panel._animation.finished.connect(finished)

                    def ready():
                        marks["ready"] = time.perf_counter()

                    window._wait_category_animations(ready)
                    QTest.qWait(300)
                    app.processEvents()
                    assert not any(p._animating for p in window.category_panels)
                    assert all(p.expanded == (action == "expand") for p in window.category_panels)
                    assert "ready" in marks and "last_finished" in marks
                    sample["handoff_delay_ms"] = max(0.0, (marks["ready"] - marks["last_finished"]) * 1000)
                    measurements[action].append(sample)
                    sample = None
            results.append({
                "categories": count,
                "median": {action: {
                    key: round(statistics.median(s[key] for s in samples), 3)
                    for key in samples[0]
                } for action, samples in measurements.items()},
            })
            window.shutdown_for_switch()
            window.drag_bar.hide()
            window.drag_bar.deleteLater()
            window.hide()
            window.deleteLater()
            app.processEvents()
            QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    print(json.dumps({
        "source": str(args.source.resolve()), "repeats": args.repeats,
        "items_per_category": args.items_per_category, "animation_speed": "normal",
        "results": results,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
