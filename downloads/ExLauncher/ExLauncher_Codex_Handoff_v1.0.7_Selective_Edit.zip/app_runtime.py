# -*- coding: utf-8 -*-
"""ExLauncher の起動・再起動・共通アイコン処理。"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from PySide6.QtCore import QFileInfo, QObject, QTimer
from PySide6.QtGui import QIcon
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import QApplication, QFileIconProvider, QStyle


class SingleInstanceController(QObject):
    """二重起動を防ぎ、2回目の起動を既存画面の表示要求へ変換する。"""

    def __init__(self, name: str = "ExLauncher.SingleInstance.v1", parent=None):
        super().__init__(parent)
        self.name = name
        self.server = QLocalServer(self)
        self._activate_callback = None

    def acquire(self) -> bool:
        if self._notify_existing():
            return False

        # 異常終了で残ったソケット名だけを除去して待受を開始する。
        QLocalServer.removeServer(self.name)
        if self.server.listen(self.name):
            self.server.newConnection.connect(self._receive_requests)
            return True

        # 同時起動競合で相手が先にlistenした場合は、もう一度通知する。
        self._notify_existing(timeout_ms=400)
        return False

    def set_activate_callback(self, callback) -> None:
        self._activate_callback = callback

    def shutdown(self) -> None:
        if self.server.isListening():
            self.server.close()
            QLocalServer.removeServer(self.name)

    def _notify_existing(self, timeout_ms: int = 250) -> bool:
        socket = QLocalSocket()
        socket.connectToServer(self.name)
        if not socket.waitForConnected(timeout_ms):
            return False
        socket.write(b"SHOW")
        socket.flush()
        socket.waitForBytesWritten(timeout_ms)
        socket.disconnectFromServer()
        return True

    def _receive_requests(self) -> None:
        while self.server.hasPendingConnections():
            socket = self.server.nextPendingConnection()
            if socket is not None:
                socket.readAll()
                socket.disconnectFromServer()
                socket.deleteLater()
        if self._activate_callback is not None:
            QTimer.singleShot(0, self._activate_callback)


def app_dir(module_file: str | None = None) -> Path:
    """設定や登録情報を置く、ユーザーから見えるアプリ基準フォルダ。"""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    if module_file:
        return Path(module_file).resolve().parent
    return Path(__file__).resolve().parent


def bundled_dir() -> Path:
    """PyInstaller同梱データの実体フォルダ。通常実行時はソースフォルダ。"""
    bundle = getattr(sys, "_MEIPASS", None)
    return Path(bundle).resolve() if bundle else Path(__file__).resolve().parent


def get_app_icon() -> QIcon:
    """
    Classic / Modern / ウィンドウ / タスクトレイで同一アイコンを返す。

    配布時は ``--add-data icon.ico;.`` で同梱されたICOを最優先する。
    開発時はソース横のicon.icoを使う。旧ビルドとの互換用にEXEの
    シェルアイコンも最後の候補として残す。
    """
    candidates = [bundled_dir() / "icon.ico"]
    visible_icon = app_dir() / "icon.ico"
    if visible_icon not in candidates:
        candidates.append(visible_icon)

    for path in candidates:
        if path.is_file():
            icon = QIcon(str(path))
            if not icon.isNull():
                return icon

    if getattr(sys, "frozen", False):
        icon = QFileIconProvider().icon(QFileInfo(str(Path(sys.executable).resolve())))
        if not icon.isNull():
            return icon

    app = QApplication.instance()
    if app is not None:
        return app.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
    return QIcon()


def restart_via_dispatcher(source_dir: Path | None = None) -> None:
    """UI切替を要求する。統合起動時は同一プロセス内で高速切替する。

    単体で classic_main.py / modern_main.py を起動した開発時だけ、
    従来どおり dispatcher へプロセス置換して互換性を保つ。
    """
    app = QApplication.instance()
    if app is not None:
        callback = getattr(app, "ui_switch_callback", None)
        if callable(callback):
            QTimer.singleShot(0, callback)
            return

        single_instance = getattr(app, "single_instance", None)
        if single_instance is not None:
            single_instance.shutdown()
        tray_controller = getattr(app, "tray_controller", None)
        if tray_controller is not None:
            tray_icon = (getattr(tray_controller, "tray", None)
                         or getattr(tray_controller, "tray_icon", None))
            if tray_icon is not None:
                try:
                    tray_icon.hide()
                except RuntimeError:
                    pass
        app.closeAllWindows()
        app.processEvents()

    if getattr(sys, "frozen", False):
        target = str(Path(sys.executable).resolve())
        os.execv(target, [target])

    base = Path(source_dir).resolve() if source_dir else app_dir()
    python = str(Path(sys.executable).resolve())
    dispatcher = str((base / "main.py").resolve())
    os.execv(python, [python, dispatcher])
