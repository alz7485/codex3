# -*- coding: utf-8 -*-
"""Classic / Modern 共通の複数選択ファイル・フォルダダイアログ。"""
from __future__ import annotations

import os

from PySide6.QtCore import QDir, QTranslator, QUrl
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QDialog,
    QFileDialog,
    QListView,
    QTreeView,
    QWidget,
)


class _JapaneseFileDialogTranslator(QTranslator):
    """Qt翻訳ファイルの有無に依存せず、ファイル画面を日本語化する。"""

    TRANSLATIONS = {
        "Look in:": "場所:",
        "File name:": "名前:",
        "Files of type:": "ファイルの種類:",
        "Folder:": "フォルダー:",
        "Directories": "フォルダー",
        "All Files (*)": "すべてのファイル (*)",
        "Open": "選択",
        "Choose": "選択",
        "Cancel": "キャンセル",
        "Name": "名前",
        "Size": "サイズ",
        "Type": "種類",
        "Date Modified": "更新日時",
        "Date modified": "更新日時",
        "My Computer": "PC",
        "Computer": "PC",
        "Back": "戻る",
        "Go back": "戻る",
        "Forward": "進む",
        "Go forward": "進む",
        "Parent Directory": "上のフォルダー",
        "Go to parent directory": "上のフォルダー",
        "Create New Folder": "新しいフォルダー",
        "Create a New Folder": "新しいフォルダー",
        "List View": "一覧表示",
        "Detail View": "詳細表示",
    }

    def translate(self, context, source_text, disambiguation=None, n=-1):
        return self.TRANSLATIONS.get(source_text, "")


def select_files(parent: QWidget | None, title: str = "ファイルを追加") -> list[str]:
    """存在するファイルを複数選択する。"""
    paths, _ = QFileDialog.getOpenFileNames(parent, title)
    return _unique_existing_paths(paths, want_directories=False)


def select_folders(parent: QWidget | None, title: str = "フォルダを追加") -> list[str]:
    """
    フォルダをCtrl／Shiftで複数選択する。

    Windowsのネイティブフォルダ選択画面は複数選択に対応しないため、
    Qtダイアログの一覧・ツリーだけを拡張選択へ変更する。
    """
    app = QApplication.instance()
    translator = _JapaneseFileDialogTranslator()
    if app is not None:
        app.installTranslator(translator)

    try:
        dialog = QFileDialog(parent, f"{title}（Ctrl／Shiftで複数選択）")
        dialog.setOption(QFileDialog.Option.DontUseNativeDialog, True)
        dialog.setOption(QFileDialog.Option.ShowDirsOnly, True)
        dialog.setFileMode(QFileDialog.FileMode.Directory)
        dialog.setViewMode(QFileDialog.ViewMode.Detail)
        dialog.setLabelText(QFileDialog.DialogLabel.LookIn, "場所:")
        dialog.setLabelText(QFileDialog.DialogLabel.FileName, "フォルダー名:")
        dialog.setLabelText(QFileDialog.DialogLabel.FileType, "種類:")
        dialog.setLabelText(QFileDialog.DialogLabel.Accept, "選択")
        dialog.setLabelText(QFileDialog.DialogLabel.Reject, "キャンセル")
        dialog.setMinimumSize(680, 440)
        dialog.resize(820, 540)

        # 「My Computer」を出さず、ホームと各ドライブを直接表示する。
        sidebar_urls = [QUrl.fromLocalFile(QDir.homePath())]
        known_paths = {os.path.normcase(os.path.abspath(QDir.homePath()))}
        for drive in QDir.drives():
            drive_path = drive.absoluteFilePath()
            key = os.path.normcase(os.path.abspath(drive_path))
            if key not in known_paths:
                sidebar_urls.append(QUrl.fromLocalFile(drive_path))
                known_paths.add(key)
        dialog.setSidebarUrls(sidebar_urls)

        # トップレベル化される非ネイティブダイアログにも親テーマを明示的に渡す。
        if parent is not None and parent.styleSheet():
            dialog.setStyleSheet(parent.styleSheet())

        views = dialog.findChildren(QListView) + dialog.findChildren(QTreeView)
        for view in views:
            if view.objectName() in {"listView", "treeView"}:
                view.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)

        if dialog.exec() != QDialog.DialogCode.Accepted:
            return []
        return _unique_existing_paths(dialog.selectedFiles(), want_directories=True)
    finally:
        if app is not None:
            app.removeTranslator(translator)


def _unique_existing_paths(paths, want_directories: bool) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for raw in paths or []:
        path = os.path.normpath(str(raw))
        valid = os.path.isdir(path) if want_directories else os.path.isfile(path)
        key = os.path.normcase(os.path.abspath(path))
        if valid and key not in seen:
            seen.add(key)
            result.append(path)
    return result
