"""Build setup regression checks; no user environment or real data is changed."""
import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts import build_onedir as builder


class BuildSetupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ExLauncher 日本語 ')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'requirements-build.txt').write_text('PySide6==6.8.3\nPyInstaller==6.11.1\n')
        (self.root / 'icon.ico').write_bytes(b'icon')
        (self.root / 'main.py').write_text('print("probe")')

    def make_environment(self):
        python = builder.environment_python(self.root)
        python.parent.mkdir(parents=True)
        python.write_bytes(b'synthetic executable')
        return python

    def test_missing_dependencies_are_installed_into_project_environment(self):
        python = builder.environment_python(self.root)
        calls = []
        def run(args, **kwargs):
            calls.append(args)
            if args[1:3] == ['-m', 'venv']:
                self.make_environment()
            return subprocess.CompletedProcess(args, 0)
        with patch.object(builder, 'check_dependencies', side_effect=[(False, 'No module named PyInstaller'), (True, '')]), \
             patch.object(builder.subprocess, 'run', side_effect=run):
            self.assertEqual(builder.prepare_environment(self.root), python)
        self.assertEqual(calls[0], [sys.executable, '-m', 'venv', str(self.root / '.venv')])
        install, = [args for args in calls if 'install' in args]
        self.assertEqual(install[0], str(python))
        self.assertEqual(install[-2:], ['-r', str(self.root / 'requirements-build.txt')])

    def test_prepared_environment_is_reused_without_pip_or_network(self):
        python = self.make_environment()
        with patch.object(builder, 'check_dependencies', return_value=(True, '')), \
             patch.object(builder.subprocess, 'run') as run:
            self.assertEqual(builder.prepare_environment(self.root), python)
        run.assert_not_called()

    def test_pip_failure_stops_before_any_build_or_output_change(self):
        self.make_environment()
        dist = self.root / 'dist/ExLauncher'
        dist.mkdir(parents=True)
        original = dist / 'setting.json'
        original.write_bytes(b'keep user data')
        def run(args, **kwargs):
            if 'install' in args:
                raise subprocess.CalledProcessError(1, args)
            return subprocess.CompletedProcess(args, 0)
        with patch.object(builder, 'check_dependencies', return_value=(False, 'missing')), \
             patch.object(builder.subprocess, 'run', side_effect=run), \
             patch.object(builder, 'build') as build, contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(builder.main([], self.root), 1)
        build.assert_not_called()
        self.assertEqual(original.read_bytes(), b'keep user data')

    def test_dependency_probe_uses_requested_interpreter_and_reports_error(self):
        python = self.make_environment()
        result = subprocess.CompletedProcess([], 1, '', 'No module named PyInstaller')
        with patch.object(builder.subprocess, 'run', return_value=result) as run:
            ok, details = builder.check_dependencies(python)
        self.assertFalse(ok)
        self.assertIn('No module named PyInstaller', details)
        self.assertEqual(run.call_args.args[0][0], str(python))

    def test_setup_only_does_not_start_a_build(self):
        python = self.make_environment()
        with patch.object(builder, 'prepare_environment', return_value=python), \
             patch.object(builder, 'build') as build, patch.object(builder.subprocess, 'run') as run:
            self.assertEqual(builder.main(['--setup-only'], self.root), 0)
        build.assert_not_called()
        run.assert_not_called()

    def test_default_build_runs_in_prepared_environment(self):
        python = self.make_environment()
        with patch.object(builder, 'prepare_environment', return_value=python), \
             patch.object(builder.subprocess, 'run') as run:
            self.assertEqual(builder.main([], self.root), 0)
        self.assertEqual(run.call_args.args[0], [str(python), '-u', str(self.root / 'scripts/build_onedir.py'), '--build-only'])

    def test_build_only_missing_dependency_has_readable_error_and_stops(self):
        output = io.StringIO()
        with patch.object(builder, 'check_dependencies', return_value=(False, 'No module named PyInstaller')), \
             patch.object(builder, 'build') as build, contextlib.redirect_stderr(output):
            self.assertEqual(builder.main(['--build-only'], self.root), 1)
        self.assertIn('setup', output.getvalue())
        self.assertIn('No module named PyInstaller', output.getvalue())
        build.assert_not_called()

    def test_staged_spec_uses_absolute_icon_and_data_paths(self):
        from PyInstaller.building.utils import format_binaries_and_datas
        observed = []
        def build(args, **kwargs):
            icon = args[args.index('--icon') + 1]
            source, destination = args[args.index('--add-data') + 1].rsplit(os.pathsep, 1)
            spec = Path(args[args.index('--specpath') + 1])
            self.assertEqual(Path(icon), self.root / 'icon.ico')
            self.assertTrue(Path(source).is_absolute())
            self.assertEqual(format_binaries_and_datas([(source, destination)], workingdir=spec),
                             {('icon.ico', str(self.root / 'icon.ico'))})
            observed.append(spec)
            out = Path(args[args.index('--distpath') + 1]) / 'ExLauncher'
            out.mkdir(parents=True)
            (out / ('ExLauncher.exe' if os.name == 'nt' else 'ExLauncher')).write_bytes(b'probe')
        with patch.object(builder.subprocess, 'run', side_effect=build):
            builder.build(self.root)
        self.assertEqual(len(observed), 1)

    def test_relative_icon_cannot_be_resolved_from_staged_spec_directory(self):
        from PyInstaller.building.utils import format_binaries_and_datas
        spec = self.root / 'dist/staged'
        spec.mkdir(parents=True)
        with self.assertRaises(SystemExit):
            format_binaries_and_datas([('icon.ico', '.')], workingdir=spec)
        self.assertEqual(format_binaries_and_datas([(str(self.root / 'icon.ico'), '.')], workingdir=spec),
                         {('icon.ico', str(self.root / 'icon.ico'))})

    def test_missing_entry_point_leaves_existing_output_intact(self):
        (self.root / 'main.py').unlink()
        with patch.object(builder.subprocess, 'run') as run:
            with self.assertRaises(FileNotFoundError):
                builder.build(self.root)
        run.assert_not_called()

    def test_vscode_launch_and_build_use_same_prepared_environment(self):
        root = Path(__file__).resolve().parents[1]
        launch = json.loads((root / '.vscode/launch.json').read_text())['configurations'][0]
        tasks = {t['label']: t for t in json.loads((root / '.vscode/tasks.json').read_text())['tasks']}
        prepare = tasks[launch['preLaunchTask']]
        build = next(t for t in tasks.values() if t.get('group', {}).get('isDefault'))
        self.assertEqual(prepare['command'], '${command:python.interpreterPath}')
        self.assertIn('--setup-only', prepare['args'])
        self.assertEqual(build['dependsOn'], prepare['label'])
        self.assertEqual(launch['python'], build['command'])
        self.assertIn('.venv/', launch['python'])
        self.assertIn('--build-only', build['args'])


if __name__ == '__main__':
    unittest.main()
