"""Qt regression checks using only temporary settings and synthetic items.

QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -v
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QAbstractAnimation, QCoreApplication, QEvent, QMimeData, QPoint, QPointF, Qt, QParallelAnimationGroup, QUrl
from PySide6.QtGui import QDropEvent, QIcon
from PySide6.QtTest import QSignalSpy, QTest
from PySide6.QtWidgets import QApplication, QDialog
from shiboken6 import isValid

import classic_main as classic
import exlauncher_common as common
import main as dispatcher
import modern_main as modern
import modern_style
from modern_widgets import ItemRow
from quick_search import QuickSearchDialog


APP = QApplication.instance() or QApplication([])
APP.setQuitOnLastWindowClosed(False)


def drain():
    APP.processEvents()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def finish_transition(window):
    for _ in range(200):
        drain()
        if not window._slide_animating:
            return
        QTest.qWait(10)
    raise AssertionError("Bar transition did not finish within two seconds")


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="exlauncher-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.presets = self.root / "登録情報"
        self.presets.mkdir()
        self.file = self.root / "example.txt"
        self.file.write_text("test", encoding="utf-8")
        self.data = {
            "ui_width": 220, "theme": "Dark Gray", "categories": [
                {"name": "文書", "items": [
                    {"type": "file", "name": "Document", "path": str(self.file)},
                    {"type": "text", "name": "定型文", "text": "一行目\n二行目"},
                    {"type": "separator", "name": "仕切り"},
                ]},
                {"name": "リンク", "items": [
                    {"type": "web", "name": "Web", "url": "https://example.com"},
                    {"type": "folder", "name": "Folder", "path": str(self.root)},
                ]},
                {"name": "空カテゴリ", "items": []},
            ],
        }
        self.write_preset(self.data)
        self.settings = dict(classic.DEFAULT_SETTING, current_preset="test.json", animation_speed="none")
        self.write_settings()
        for module in (classic, modern):
            for name, value in (("APP_DIR", self.root), ("PRESET_DIR", self.presets),
                                ("SETTING_FILE", self.root / "setting.json")):
                p = patch.object(module, name, value)
                p.start()
                self.addCleanup(p.stop)

    def write_settings(self):
        (self.root / "setting.json").write_text(json.dumps(self.settings), encoding="utf-8")

    def write_preset(self, data, name="test.json"):
        (self.presets / name).write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

    def window(self, cls=modern.ModernWindow):
        window = cls()
        window.show()
        drain()
        def cleanup():
            if isValid(window):
                window.shutdown_for_switch()
                window.drag_bar.hide()
                window.drag_bar.deleteLater()
                window.hide()
                window.deleteLater()
                drain()
        self.addCleanup(cleanup)
        return window

    def test_closed_categories_need_no_rows_or_shell_icons(self):
        with patch.object(modern, "QFileIconProvider") as provider:
            window = self.window()
            provider.return_value.icon.assert_not_called()
        self.assertEqual([len(p.rows) for p in window.category_panels], [0, 0, 0])
        self.assertEqual([p.count_label.text() for p in window.category_panels], ["(3)", "(2)", ""])
        self.assertEqual(window.findChildren(ItemRow), [])

    def test_first_expand_creates_only_needed_rows_and_reuses_them(self):
        window = self.window()
        panel = window.category_panels[0]
        panel.set_expanded(True, False)
        rows = panel.rows[:]
        self.assertEqual([r.text_label.text() for r in rows], ["Document", "定型文", "────────"])
        self.assertEqual(panel.target_height(), 3 * ItemRow.HEIGHT + 2 * panel.ITEM_GAP)
        self.assertEqual(panel.current_visual_height(), panel.HEADER_H + 4 + panel.target_height())
        panel.set_expanded(False, False)
        panel.set_expanded(True, False)
        self.assertEqual(rows, panel.rows)
        self.assertEqual(len(window.category_panels[1].rows), 0)

    def test_deferred_rows_follow_new_theme_and_keep_callbacks(self):
        window = self.window()
        for theme in modern_style.THEMES:
            window.data["modern_theme"] = theme
            window.apply_settings()
        panel = window.category_panels[1]
        panel.set_expanded(True, False)
        self.assertTrue(all(r.theme == window.modern_theme for r in panel.rows))
        with patch.object(window, "activate_item") as activate:
            panel.rows[1].activated.emit()
            activate.assert_called_once_with(1, 1)

    def test_edit_mode_keeps_selected_rows_and_restores_expanded_state_and_position(self):
        window = self.window()
        window.category_panels[1].set_expanded(True, False)
        window.toggle_edit_mode()
        self.assertTrue(window.edit_mode)
        self.assertEqual([len(p.rows) for p in window.category_panels], [0, 2, 0])
        self.assertEqual([p.expanded for p in window.category_panels], [False, True, False])
        self.assertTrue(all(r.edit_mode for p in window.category_panels for r in p.rows))
        window.move_from_bar(QPoint(500, 180))
        anchor = QPoint(window.drag_bar.pos())
        window.register_external_paths(0, [str(self.file)])
        window.toggle_edit_mode()
        drain()
        self.assertFalse(window.edit_mode)
        self.assertEqual([p.expanded for p in window.category_panels], [False, True, False])
        self.assertEqual(window.drag_bar.pos(), anchor)
        self.assertEqual(len(window.data["categories"][0]["items"]), 4)

    def test_edit_mode_restores_all_closed(self):
        window = self.window()
        window.toggle_edit_mode()
        window.toggle_edit_mode()
        self.assertTrue(all(not p.expanded for p in window.category_panels))
        self.assertTrue(all(not p.rows for p in window.category_panels))

    def test_rebuild_after_move_preserves_row_indices(self):
        window = self.window()
        window.toggle_edit_mode()
        window.move_item(0, 1, 1, 0)
        panel = window.category_panels[1]
        self.assertFalse(panel.rows)
        panel.set_expanded(True, False)
        self.assertEqual(panel.rows[0].text_label.text(), "定型文")
        with patch.object(window, "item_menu") as menu:
            panel.rows[0].editRequested.emit()
            menu.assert_called_once_with(1, 0)

    def test_modern_icons_cached_bounded_and_null_icons_fall_back(self):
        window = self.window()
        with patch.object(window, "file_icons") as provider:
            provider.icon.return_value = QIcon()
            first = window.item_icon({"type": "file", "path": "missing.txt"})
            self.assertFalse(first.isNull())
            window.item_icon({"type": "file", "path": "missing.txt"})
            self.assertEqual(provider.icon.call_count, 1)
            for i in range(520):
                window.item_icon({"type": "folder", "path": f"missing-{i}"})
            self.assertLessEqual(len(window._item_icon_cache), 512)
        self.assertIsNone(window.item_icon({"type": "separator"}))

    def test_settings_not_rewritten_when_unchanged_in_either_ui(self):
        for cls in (classic.MainWindow, modern.ModernWindow):
            with self.subTest(cls=cls.__name__):
                path = self.root / "setting.json"
                os.utime(path, ns=(1_000_000_000, 1_000_000_000))
                window = self.window(cls)
                self.assertEqual(path.stat().st_mtime_ns, 1_000_000_000)
                self.assertEqual(json.loads(path.read_text(encoding="utf-8")), self.settings)

    def test_legacy_migration_still_applies_to_all_presets(self):
        for mode in ("Classic", "Modern"):
            with self.subTest(mode=mode):
                self.settings.update({"ui_width": 245, "theme": "Navy"})
                self.write_settings()
                self.write_preset({"categories": []}, "legacy.json")
                if mode == "Classic":
                    classic.ensure_files()
                else:
                    common.ensure_files(self.root)
                migrated = json.loads((self.presets / "legacy.json").read_text(encoding="utf-8"))
                self.assertEqual(migrated["ui_width"], 245)
                self.assertEqual(migrated["theme"], "Navy")
                saved = json.loads((self.root / "setting.json").read_text(encoding="utf-8"))
                self.assertNotIn("theme", saved)
                self.assertNotIn("ui_width", saved)

    def test_new_install_still_creates_one_default_category(self):
        for mode in ("Classic", "Modern"):
            with self.subTest(mode=mode):
                for p in self.presets.glob("*.json"):
                    p.unlink()
                (self.root / "setting.json").unlink(missing_ok=True)
                classic.ensure_files() if mode == "Classic" else common.ensure_files(self.root)
                presets = list(self.presets.glob("*.json"))
                self.assertEqual(len(presets), 1)
                self.assertEqual(json.loads(presets[0].read_text(encoding="utf-8"))["categories"],
                                 [{"name": "新規カテゴリ", "items": []}])

    def test_search_filter_selection_unicode_and_multiterm(self):
        dialog = QuickSearchDialog(self.data)
        self.addCleanup(dialog.deleteLater)
        self.assertEqual(dialog.result_model.rowCount(), 4)
        dialog._refresh("DOCUMENT 文書")
        self.assertEqual(dialog.result_model.rowCount(), 1)
        self.assertEqual(dialog.result_model.index(0).data(Qt.ItemDataRole.UserRole), (0, 0))
        self.assertEqual(dialog.result_model.index(0).data(Qt.ItemDataRole.ToolTipRole), str(self.file))
        dialog._refresh("example.com")
        dialog._accept_current()
        self.assertEqual(dialog.selected_indices(), (1, 0))
        self.assertEqual(dialog.result(), QDialog.DialogCode.Accepted)

    def test_search_empty_results_and_keyboard_navigation(self):
        dialog = QuickSearchDialog(self.data)
        self.addCleanup(dialog.deleteLater)
        dialog._refresh("no-match-at-all")
        dialog._move_selection(1)
        dialog._accept_current()
        self.assertIsNone(dialog.selected_indices())
        dialog._refresh("")
        QTest.keyClick(dialog.search_edit, Qt.Key.Key_Down)
        self.assertEqual(dialog.result_list.currentIndex().row(), 1)
        QTest.keyClick(dialog.search_edit, Qt.Key.Key_Up)
        self.assertEqual(dialog.result_list.currentIndex().row(), 0)
        QTest.keyClick(dialog.search_edit, Qt.Key.Key_Return)
        self.assertEqual(dialog.selected_indices(), (0, 0))

    def test_multiline_copy_stays_visible_and_web_hides_for_both_pin_states(self):
        for cls in (classic.MainWindow, modern.ModernWindow):
            window = self.window(cls)
            for pin in (False, True):
                window.settings["pin"] = pin
                if cls is modern.ModernWindow:
                    window.activate_item(0, 1)
                    with patch.object(modern, "launch_item", return_value=True), \
                         patch.object(window, "_snapshot_hide_to_bar") as hide:
                        window.activate_item(1, 0)
                        self.assertEqual(hide.call_count, int(not pin))
                else:
                    window.expanded = {0, 1}
                    window.refresh_main_list()
                    rows = {window.list_widget.item(i).data(Qt.ItemDataRole.UserRole):
                            window.list_widget.item(i) for i in range(window.list_widget.count())}
                    window.main_item_clicked(rows[("item", 0, 1)])
                    with patch.object(classic, "launch_item"), \
                         patch.object(window, "toggle_from_bar") as hide:
                        window.main_item_clicked(rows[("item", 1, 0)])
                        self.assertEqual(hide.call_count, int(not pin))
                self.assertEqual(APP.clipboard().text(), "一行目\n二行目")
                self.assertTrue(window.isVisible())

    def test_file_folder_and_web_launch_dispatch_without_external_effects(self):
        for module in (classic, common):
            with patch.object(module.os, "startfile", create=True) as startfile, \
                 patch.object(module.webbrowser, "open") as browser:
                module.launch_item(self.data["categories"][0]["items"][0])
                module.launch_item(self.data["categories"][1]["items"][1])
                module.launch_item(self.data["categories"][1]["items"][0])
                self.assertEqual(startfile.call_args_list[0].args, (str(self.file),))
                self.assertEqual(startfile.call_args_list[1].args, (str(self.root),))
                browser.assert_called_once_with("https://example.com")

    def test_drop_multiple_files_and_folder_into_edit_category(self):
        window = self.window()
        window.toggle_edit_mode()
        second = self.root / "second.txt"
        second.write_text("test", encoding="utf-8")
        mime = QMimeData()
        mime.setUrls([QUrl.fromLocalFile(str(p)) for p in (self.file, second, self.root)])
        event = QDropEvent(QPointF(10, 35), Qt.DropAction.CopyAction, mime,
                           Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
        window.category_panels[2].dropEvent(event)
        self.assertTrue(event.isAccepted())
        added = window.data["categories"][2]["items"]
        self.assertEqual([item["type"] for item in added], ["file", "file", "folder"])
        self.assertEqual(len(window.category_panels[2].rows), 0)
        window.category_panels[2].set_expanded(True, False)
        self.assertEqual(len(window.category_panels[2].rows), 3)
        saved = json.loads((self.presets / "test.json").read_text(encoding="utf-8"))
        self.assertEqual(saved["categories"][2]["items"], added)

    def test_bar_hide_restore_ten_times_on_both_sides(self):
        for side, speed in (("left", "none"), ("right", "none"),
                            ("left", "fast"), ("right", "fast")):
            window = self.window()
            window.settings["drag_bar_position"] = side
            window.settings["animation_speed"] = speed
            window.apply_settings()
            window.category_panels[0].set_expanded(True, False)
            for _ in range(10):
                window.toggle_from_bar()
                finish_transition(window)
                self.assertFalse(window.isVisible())
                window.move_from_bar(QPoint(450, 160))
                anchor = QPoint(window.drag_bar.pos())
                window.toggle_from_bar()
                finish_transition(window)
                self.assertTrue(window.isVisible())
                self.assertEqual(window.drag_bar.pos(), anchor)
                self.assertEqual([p.expanded for p in window.category_panels], [True, False, False])
            drain()
            self.assertEqual(window.findChildren(QAbstractAnimation), [])

    def test_animation_reversal_keeps_actual_height_and_releases_groups(self):
        window = self.window()
        panel = window.category_panels[0]
        panel.set_animation_speed("normal")
        for _ in range(8):
            panel.set_expanded(True, True, 60)
            QTest.qWait(25)
            h = panel.current_visual_height()
            panel.set_expanded(False, True, 60)
            self.assertEqual(panel.current_visual_height(), h)
            QTest.qWait(90)
            drain()
            self.assertFalse(panel.expanded)
            self.assertFalse(panel._animating)
            self.assertEqual(panel.current_visual_height(), panel.HEADER_H)
        self.assertEqual(panel.findChildren(QParallelAnimationGroup), [])

    def test_animated_edit_keeps_dragged_position_and_releases_snapshots(self):
        window = self.window()
        window.settings["animation_speed"] = "fast"
        for side in ("left", "right"):
            window.settings["drag_bar_position"] = side
            window.apply_settings()
            for _ in range(3):
                window.toggle_edit_mode()
                finish_transition(window)
                window.move_from_bar(QPoint(480, 170))
                anchor = QPoint(window.drag_bar.pos())
                window.register_external_paths(0, [str(self.file)])
                window.toggle_edit_mode()
                finish_transition(window)
                drain()
                self.assertFalse(window.edit_mode)
                self.assertEqual(window.drag_bar.pos(), anchor)
                self.assertEqual(window._snapshot_proxies, [])
                self.assertEqual(window.findChildren(QAbstractAnimation), [])

    def test_height_changes_in_one_event_are_coalesced(self):
        window = self.window()
        window._fit_generation += 1
        window._height_adjust_timer.stop()
        spy = QSignalSpy(window._height_adjust_timer.timeout)
        for panel in window.category_panels:
            panel.set_expanded(True, False)
        self.assertEqual(spy.count(), 0)
        drain()
        self.assertEqual(spy.count(), 1)
        expected = sum(p.current_visual_height() for p in window.category_panels) + 6
        self.assertEqual(window.category_host.height(), expected)
        self.assertEqual(window.height(), expected + window.top_bar.height() + 4)

    def test_simultaneous_animation_frames_use_current_visual_heights(self):
        window = self.window()
        window._fit_generation += 1
        for panel in window.category_panels[:2]:
            panel.set_animation_speed("normal")
            panel.set_expanded(True, True)
            panel._animation.pause()
        drain()
        spy = QSignalSpy(window._height_adjust_timer.timeout)
        for time_ms in (80, 160):
            previous = spy.count()
            for panel in window.category_panels[:2]:
                panel._animation.setCurrentTime(time_ms)
            drain()
            self.assertEqual(spy.count(), previous + 1)
            expected = sum(p.current_visual_height() for p in window.category_panels) + 6
            self.assertEqual(window.category_host.height(), expected)
            self.assertEqual(window.drag_bar.height(), window.height())
        for panel in window.category_panels[:2]:
            panel.set_expanded(False, False)
        drain()
        self.assertEqual(window.category_host.height(), 3 * 28 + 6)

    def test_completion_wait_uses_signals_and_runs_once_after_settling(self):
        window = self.window()
        panel = window.category_panels[0]
        panel.set_animation_speed("normal")
        panel.set_expanded(True, True, 60)
        settled = QSignalSpy(panel.animationSettled)
        callbacks = []
        def ready():
            callbacks.append((panel._animating, window.category_host.height()))
        with patch.object(modern.QTimer, "singleShot", side_effect=AssertionError("Polling timer")):
            window._wait_category_animations(ready)
            self.assertEqual(callbacks, [])
            QTest.qWait(100)
            drain()
        self.assertEqual(settled.count(), 1)
        expected = sum(p.current_visual_height() for p in window.category_panels) + 6
        self.assertEqual(callbacks, [(False, expected)])
        panel.set_expanded(True, False)
        drain()
        self.assertEqual(len(callbacks), 1)
        self.assertIsNone(window._category_wait_callback)

    def test_completion_wait_without_animation_flushes_pending_geometry(self):
        window = self.window()
        panel = window.category_panels[0]
        panel.set_expanded(True, False)
        self.assertTrue(window._height_adjust_timer.isActive())
        heights = []
        window._wait_category_animations(lambda: heights.append(window.category_host.height()))
        expected = sum(p.current_visual_height() for p in window.category_panels) + 6
        self.assertEqual(heights, [expected])
        self.assertFalse(window._height_adjust_timer.isActive())
        drain()
        self.assertEqual(heights, [expected])

    def test_completion_wait_follows_animation_reversal(self):
        window = self.window()
        panel = window.category_panels[0]
        panel.set_animation_speed("normal")
        panel.set_expanded(True, False)
        panel.set_expanded(False, True, 120)
        callback = Mock()
        window._wait_category_animations(callback)
        QTest.qWait(25)
        panel.set_expanded(True, True, 120)
        callback.assert_not_called()
        QTest.qWait(160)
        drain()
        callback.assert_called_once_with()
        self.assertTrue(panel.expanded)

    def test_shutdown_cancels_pending_height_and_completion_callbacks(self):
        window = self.window()
        panel = window.category_panels[0]
        panel.set_animation_speed("normal")
        panel.set_expanded(True, True, 60)
        callback = Mock()
        window._wait_category_animations(callback)
        window._queue_category_completion()
        self.assertTrue(window._height_adjust_timer.isActive())
        self.assertTrue(window._category_wait_timer.isActive())
        window.shutdown_for_switch()
        QTest.qWait(100)
        drain()
        callback.assert_not_called()
        self.assertIsNone(window._category_wait_callback)
        self.assertFalse(window._height_adjust_timer.isActive())
        self.assertFalse(window._category_wait_timer.isActive())

    def test_preset_replacement_during_bar_collapse_does_not_leave_wait_pending(self):
        window = self.window()
        window.settings["animation_speed"] = "fast"
        window.apply_settings()
        window.category_panels[1].set_expanded(True, False)
        window.toggle_from_bar()
        self.assertIsNotNone(window._category_wait_callback)
        replacement = {"theme": "Dark Gray", "ui_width": 220, "categories": [
            {"name": "新プリセット", "items": [
                {"type": "text", "name": "Text", "text": "test"},
            ]},
        ]}
        self.write_preset(replacement, "replacement.json")
        window.load_preset(self.presets / "replacement.json")
        window.apply_settings()
        finish_transition(window)
        self.assertFalse(window.isVisible())
        self.assertIsNone(window._category_wait_callback)
        window.toggle_from_bar()
        finish_transition(window)
        self.assertTrue(window.isVisible())
        self.assertEqual(len(window.category_panels), 1)
        self.assertFalse(window.category_panels[0].expanded)

    def test_bar_stages_flush_height_before_horizontal_slide(self):
        window = self.window()
        window.settings["animation_speed"] = "fast"
        window.apply_settings()
        for panel in window.category_panels:
            panel.set_expanded(True, False)
        stages = []
        original = window._animate_clipped_horizontal
        def horizontal(*args, **kwargs):
            stages.append((args[2], [p._animating for p in window.category_panels],
                           window.category_host.height(), window.height()))
            return original(*args, **kwargs)
        with patch.object(window, "_animate_clipped_horizontal", side_effect=horizontal):
            window.toggle_from_bar()
            finish_transition(window)
            window.toggle_from_bar()
            finish_transition(window)
        self.assertEqual(len(stages), 2)
        for hiding, animating, category_height, height in stages:
            self.assertEqual(animating, [False, False, False])
            self.assertEqual(category_height, 3 * 28 + 6)
            self.assertEqual(height, category_height + 32 + 4)
        self.assertEqual([s[0] for s in stages], [True, False])
        self.assertTrue(all(p.expanded for p in window.category_panels))

    def test_dispatcher_switch_during_vertical_bar_animation_cancels_old_stage(self):
        single = Mock()
        controller = dispatcher.UIController(APP, single)
        self.settings["ui_style"] = "Modern"
        self.settings["animation_speed"] = "normal"
        self.write_settings()
        with patch.object(dispatcher, "read_ui_style", side_effect=lambda: self.settings["ui_style"]):
            controller.start()
            old = controller.window
            try:
                old.category_panels[0].set_expanded(True, False)
                with patch.object(old, "_animate_clipped_horizontal") as horizontal:
                    old.toggle_from_bar()
                    self.assertIsNotNone(old._category_wait_callback)
                    self.settings["ui_style"] = "Classic"
                    self.write_settings()
                    controller.request_switch()
                    drain()
                    QTest.qWait(300)
                    drain()
                    horizontal.assert_not_called()
                self.assertFalse(isValid(old))
                self.assertEqual(controller.current_style, "Classic")
                self.assertTrue(controller.window.isVisible())
            finally:
                controller._destroy_current_ui()
                drain()

    def test_fifty_dispatcher_switches_release_old_ui_and_tray(self):
        class SingleInstance:
            def set_activate_callback(self, callback):
                self.callback = callback
        single = SingleInstance()
        controller = dispatcher.UIController(APP, single)
        previous = []
        with patch.object(dispatcher, "read_ui_style", side_effect=lambda: self.settings["ui_style"]):
            controller.start()
            try:
                for i in range(50):
                    previous.append((controller.window, controller.window.drag_bar,
                                     controller.tray_controller.tray))
                    self.settings["ui_style"] = "Modern" if i % 2 == 0 else "Classic"
                    self.write_settings()
                    controller.request_switch()
                    drain()
                    drain()
                    self.assertEqual(controller.current_style, self.settings["ui_style"])
                    self.assertTrue(controller.window.isVisible())
                self.assertTrue(all(not isValid(obj) for group in previous for obj in group))
            finally:
                controller._destroy_current_ui()
                drain()


if __name__ == "__main__":
    unittest.main()
