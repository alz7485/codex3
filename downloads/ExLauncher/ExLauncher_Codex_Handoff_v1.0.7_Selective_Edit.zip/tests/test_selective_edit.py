"""Edit only the categories the user has opened; never use real settings."""
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from PySide6.QtCore import QMimeData, QPointF, Qt
from PySide6.QtGui import QDropEvent
from PySide6.QtTest import QTest

import test_performance_regressions as perf
import modern_main as modern
from modern_widgets import ItemRow, MIME_ITEM


class SelectiveEditTests(unittest.TestCase):
    write_preset = perf.LauncherTests.write_preset
    write_settings = perf.LauncherTests.write_settings
    window = perf.LauncherTests.window

    def setUp(self):
        perf.LauncherTests.setUp(self)

    def click_header(self, panel):
        QTest.mouseClick(panel.header, Qt.MouseButton.LeftButton, pos=panel.header.rect().center())
        perf.drain()

    def test_large_closed_preset_enters_edit_without_rows_or_icons(self):
        self.write_preset(dict(self.data, categories=[{'name': f'category{i}', 'items': [
            {'type': 'text', 'name': f'item{j}', 'text': str(j)} for j in range(200)]} for i in range(20)]))
        window = self.window()
        before = (self.presets / 'test.json').read_bytes()
        with patch.object(window, 'item_icon', wraps=window.item_icon) as icons:
            window.toggle_edit_mode()
            self.assertTrue(window.edit_mode)
            self.assertTrue(all(not p.expanded and not p.rows for p in window.category_panels))
            self.assertEqual(len(window.findChildren(ItemRow)), 0)
            icons.assert_not_called()
            chosen = window.category_panels[7]
            self.click_header(chosen)
            self.assertEqual(len(chosen.rows), 200)
            self.assertTrue(all(r.edit_mode for r in chosen.rows))
            self.assertEqual(sum(len(p.rows) for p in window.category_panels), 200)
            rows = chosen.rows[:]
            self.click_header(chosen)
            self.click_header(chosen)
            self.assertEqual(chosen.rows, rows)
            self.assertEqual(icons.call_count, 200)
        self.assertEqual((self.presets / 'test.json').read_bytes(), before)

    def test_enter_preserves_open_state_and_reuses_existing_panels_and_rows(self):
        window = self.window()
        window.category_panels[1].set_expanded(True, False)
        panels = window.category_panels[:]
        rows = panels[1].rows[:]
        with patch.object(window, 'item_icon') as icons:
            window.toggle_edit_mode()
            self.assertEqual(window.category_panels, panels)
            self.assertEqual(window.category_panels[1].rows, rows)
            self.assertEqual([p.expanded for p in panels], [False, True, False])
            icons.assert_not_called()
        self.click_header(panels[0])
        self.click_header(panels[1])
        self.assertEqual([p.expanded for p in panels], [True, False, False])
        window.toggle_edit_mode()
        self.assertEqual([p.expanded for p in panels], [False, True, False])
        self.assertEqual(window.category_panels[1].rows, rows)
        self.assertTrue(all(not r.edit_mode for p in panels for r in p.rows))

    def test_closed_empty_category_can_be_opened_to_add_an_item(self):
        window = self.window()
        window.toggle_edit_mode()
        panel = window.category_panels[2]
        self.assertFalse(panel.expanded)
        self.assertFalse(panel.add_item_btn.isVisible())
        self.click_header(panel)
        self.assertTrue(panel.expanded)
        self.assertTrue(panel.add_item_btn.isVisible())
        with patch.object(window, 'add_item_menu') as add:
            QTest.mouseClick(panel.add_item_btn, Qt.MouseButton.LeftButton)
            add.assert_called_once_with(2)

    def test_reordering_keeps_the_same_category_open_and_restores_it(self):
        window = self.window()
        window.data['categories'][0]['name'] = 'same'
        window.data['categories'][1]['name'] = 'same'
        window.category_panels[1].set_expanded(True, False)
        selected = window.data['categories'][1]
        window.toggle_edit_mode()
        window.move_category(1, 0)
        self.assertIs(window.data['categories'][0], selected)
        self.assertEqual([p.expanded for p in window.category_panels], [True, False, False])
        self.assertFalse(window.category_panels[1].rows)
        window.toggle_edit_mode()
        self.assertEqual([p.expanded for p in window.category_panels], [True, False, False])

    def test_deleting_an_earlier_category_does_not_open_an_unrelated_one(self):
        window = self.window()
        window.category_panels[1].set_expanded(True, False)
        window.toggle_edit_mode()
        del window.data['categories'][0]
        window.save_current()
        window.rebuild_categories()
        self.assertEqual([p.expanded for p in window.category_panels], [True, False])
        window.toggle_edit_mode()
        self.assertEqual([p.expanded for p in window.category_panels], [True, False])

    def test_drop_into_closed_unbuilt_category_appends_without_expanding(self):
        window = self.window()
        window.category_panels[0].set_expanded(True, False)
        window.toggle_edit_mode()
        target = window.category_panels[1]
        self.assertFalse(target.rows)
        mime = QMimeData()
        mime.setData(MIME_ITEM, json.dumps({'category': 0, 'item': 1}).encode())
        event = QDropEvent(QPointF(10, 5), Qt.DropAction.MoveAction, mime,
                           Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
        target.dropEvent(event)
        self.assertTrue(event.isAccepted())
        target = window.category_panels[1]
        self.assertFalse(target.expanded)
        self.assertFalse(target.rows)
        self.assertEqual([obj['name'] for obj in window.data['categories'][1]['items']], ['Web', 'Folder', '定型文'])
        self.click_header(target)
        with patch.object(window, 'item_menu') as menu:
            QTest.mouseClick(target.rows[-1].menu_btn, Qt.MouseButton.LeftButton)
            menu.assert_called_once_with(1, 2)

    def test_enter_during_collapse_preserves_closed_target(self):
        window = self.window()
        panel = window.category_panels[0]
        panel.set_expanded(True, False)
        panel.set_animation_speed('normal')
        panel.set_expanded(False, True, 240)
        self.assertTrue(panel._animating)
        window.settings['animation_speed'] = 'fast'
        window.toggle_edit_mode()
        perf.finish_transition(window)
        self.assertFalse(panel.expanded)
        self.assertEqual(panel.current_visual_height(), panel.HEADER_H)
        window.toggle_edit_mode()
        perf.finish_transition(window)
        self.assertTrue(all(not p.expanded for p in window.category_panels))

    def test_cross_preset_move_retains_other_categories_open_state(self):
        target = self.presets / 'target.json'
        self.write_preset(dict(self.data, categories=[]), target.name)
        window = self.window()
        window.category_panels[1].set_expanded(True, False)
        window.toggle_edit_mode()
        window.move_category_to_preset(0, target)
        self.assertEqual([p.expanded for p in window.category_panels], [True, False])
        self.assertEqual(len(json.loads(target.read_text())['categories']), 1)
        window.toggle_edit_mode()
        self.assertEqual([p.expanded for p in window.category_panels], [True, False])

    def test_loading_another_preset_does_not_open_matching_indices(self):
        window = self.window()
        window.category_panels[1].set_expanded(True, False)
        window.toggle_edit_mode()
        target = self.presets / 'target.json'
        self.write_preset(self.data, target.name)
        window.load_preset(target)
        self.assertTrue(all(not p.expanded and not p.rows for p in window.category_panels))
        window.toggle_edit_mode()
        self.assertTrue(all(not p.expanded for p in window.category_panels))


if __name__ == '__main__':
    unittest.main()
