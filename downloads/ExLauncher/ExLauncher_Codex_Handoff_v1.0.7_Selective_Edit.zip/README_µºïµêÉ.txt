ExLauncher v36 構成
===================

起動・共通
- main.py              Classic / Modern 起動振り分け
- app_runtime.py       アプリ基準パス、再起動、共通アイコン
- file_dialogs.py      ファイル・フォルダの共通複数選択ダイアログ
- quick_search.py      Classic / Modern共通クイック検索
- exlauncher_common.py Modern向けデータ・プリセット・実行共通処理

Classic
- classic_main.py      Classic本体（既存安定動作を維持）

Modern
- modern_main.py       Modern画面・状態遷移・操作
- modern_widgets.py    カテゴリ・アイテム・ドラッグバー
- modern_animation.py アニメーション定数・横スライド描画
- modern_style.py      テーマ・QSS

配布
- icon.ico             EXE・全ウィンドウ・タスクトレイ共通アイコン
- build_onedir.bat     PyInstaller onedirビルド

ビルド方法
1. PySide6 / PyInstallerを入れた仮想環境を有効にする。
2. build_onedir.batを実行する。
3. dist\ExLauncher\ExLauncher.exeを起動する。

icon.icoは--iconと--add-dataの両方に指定される。
EXEのシェルアイコンだけでなく、_internal内の同一ICOをClassic / Modernの
ウィンドウとタスクトレイが読むため、UI切替で表示が変わらない。

更新時の注意
- v20以降のCategoryPanel収納中は_expanded=Trueを維持するロジックを壊さない。
- Classic / Modernを1つの巨大クラスへ統合しない。
- setting.jsonと登録情報はEXEのあるフォルダ基準のまま維持する。
- 正式配布はonedirとする。
- 一覧・ツリー系ダイアログには背景色と文字色を必ず対で指定する。
- 通常時の操作ボタン順はClassic / Modernとも編集・検索・設定とする。
