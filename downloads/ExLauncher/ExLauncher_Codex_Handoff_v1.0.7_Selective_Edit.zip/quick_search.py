# -*- coding: utf-8 -*-
"""Classic / Modern 共通の軽量クイック検索ダイアログ。"""
from __future__ import annotations

from PySide6.QtCore import QAbstractListModel, QModelIndex, Qt, Signal
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import (
    QDialog,
    QLabel,
    QLineEdit,
    QListView,
    QVBoxLayout,
    QWidget,
)


TYPE_LABELS = {
    "file": "📃",
    "folder": "📁",
    "web": "🌎",
    "text": "📋",
}


class SearchEdit(QLineEdit):
    moveRequested = Signal(int)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key.Key_Down:
            self.moveRequested.emit(1)
            return
        if event.key() == Qt.Key.Key_Up:
            self.moveRequested.emit(-1)
            return
        super().keyPressEvent(event)


class SearchResultsModel(QAbstractListModel):
    """検索結果をデータとして保持し、表示する行だけをQtが描画する。"""

    def __init__(self, entries: list[dict], parent=None):
        super().__init__(parent)
        self._entries = entries
        self._matches = entries

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._matches)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self._matches):
            return None
        entry = self._matches[index.row()]
        if role == Qt.ItemDataRole.DisplayRole:
            return entry["label"]
        if role == Qt.ItemDataRole.ToolTipRole:
            return entry["tooltip"] or None
        if role == Qt.ItemDataRole.UserRole:
            return (entry["category_index"], entry["item_index"])
        return None

    def set_query(self, query: str):
        terms = [term.casefold() for term in query.split() if term]
        matches = self._entries if not terms else [
            entry for entry in self._entries
            if all(term in entry["search"] for term in terms)
        ]
        self.beginResetModel()
        self._matches = matches
        self.endResetModel()


class QuickSearchDialog(QDialog):
    """現在プリセットの実行可能項目を検索し、選択位置を返す。"""

    def __init__(self, data: dict, style_sheet: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle("クイック検索")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        self.setMinimumSize(440, 300)
        self.resize(540, 400)
        if style_sheet:
            self.setStyleSheet(style_sheet)

        self._entries = self._build_entries(data)
        self._selected: tuple[int, int] | None = None

        self.search_edit = SearchEdit()
        self.search_edit.setPlaceholderText("名前・カテゴリ・パス・URLを検索")
        self.search_edit.setClearButtonEnabled(True)

        self.result_list = QListView()
        self.result_list.setObjectName("quickSearchResults")
        self.result_list.setAlternatingRowColors(False)
        self.result_list.setUniformItemSizes(True)
        self.result_list.setEditTriggers(QListView.EditTrigger.NoEditTriggers)
        self.result_model = SearchResultsModel(self._entries, self)
        self.result_list.setModel(self.result_model)

        hint = QLabel("↑↓で選択　Enterで実行　Escで閉じる")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(6)
        layout.addWidget(self.search_edit)
        layout.addWidget(self.result_list, 1)
        layout.addWidget(hint)

        self.search_edit.textChanged.connect(self._refresh)
        self.search_edit.returnPressed.connect(self._accept_current)
        self.search_edit.moveRequested.connect(self._move_selection)
        self.result_list.activated.connect(lambda _index: self._accept_current())
        self.result_list.doubleClicked.connect(lambda _index: self._accept_current())

        self._refresh("")
        self.search_edit.setFocus()

    @staticmethod
    def _build_entries(data: dict) -> list[dict]:
        entries = []
        for ci, category in enumerate(data.get("categories", [])):
            category_name = str(category.get("name", "名称未設定"))
            for ii, item in enumerate(category.get("items", [])):
                typ = str(item.get("type", ""))
                if typ == "separator":
                    continue
                name = str(item.get("name", ""))
                extra = str(item.get("path") or item.get("url") or "")
                search_text = " ".join((name, category_name, extra, typ)).casefold()
                entries.append({
                    "category_index": ci,
                    "item_index": ii,
                    "label": f"{TYPE_LABELS.get(typ, '•')}  {name}    [{category_name}]",
                    "tooltip": extra,
                    "search": search_text,
                })
        return entries

    def selected_indices(self) -> tuple[int, int] | None:
        return self._selected

    def _refresh(self, query: str) -> None:
        self.result_model.set_query(query)
        if self.result_model.rowCount():
            self.result_list.setCurrentIndex(self.result_model.index(0))

    def _move_selection(self, delta: int) -> None:
        count = self.result_model.rowCount()
        if not count:
            return
        row = self.result_list.currentIndex().row()
        self.result_list.setCurrentIndex(self.result_model.index(max(0, min(count - 1, row + delta))))

    def _accept_current(self) -> None:
        index = self.result_list.currentIndex()
        if not index.isValid():
            return
        value = index.data(Qt.ItemDataRole.UserRole)
        if isinstance(value, (tuple, list)) and len(value) == 2:
            self._selected = (int(value[0]), int(value[1]))
            self.accept()
