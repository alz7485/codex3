# -*- coding: utf-8 -*-
"""Modern UIのアニメーション定数と描画専用ウィジェット。"""
from __future__ import annotations

from PySide6.QtCore import QPoint, Qt
from PySide6.QtGui import QPainter, QPixmap
from PySide6.QtWidgets import QApplication, QWidget


# 1か所で速度感を調整し、カテゴリ・バー・編集切替のテンポを揃える。
CATEGORY_DURATION_MS = 240
AUTO_HIDE_CATEGORY_DURATION_MS = 175
BAR_SLIDE_DURATION_MS = 300
AUTO_HIDE_BAR_SLIDE_DURATION_MS = 225
EDIT_CROSSFADE_DURATION_MS = 170

ANIMATION_SPEED_OPTIONS = [
    ("なし", "none"),
    ("高速", "fast"),
    ("標準", "normal"),
    ("ゆっくり", "slow"),
]

ANIMATION_SPEED_FACTORS = {
    "none": 0.0,
    "fast": 0.65,
    "normal": 1.0,
    "slow": 1.35,
}


def normalized_speed(value: str | None) -> str:
    value = str(value or "normal").lower()
    return value if value in ANIMATION_SPEED_FACTORS else "normal"


def scaled_duration(base_ms: int, speed: str | None) -> int:
    factor = ANIMATION_SPEED_FACTORS[normalized_speed(speed)]
    return max(1, int(round(int(base_ms) * factor)))


class SnapshotSlideProxy(QWidget):
    """固定ウィンドウ内でスナップショットだけを横移動し、端をクリップする。"""

    def __init__(self, pixmap: QPixmap, pos: QPoint, direction: str, parent=None):
        super().__init__(parent)
        self._pixmap = pixmap
        self._progress = 0.0
        self._direction = direction
        self.setWindowFlags(
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowTransparentForInput
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.resize(pixmap.size())
        self.move(pos)

    def set_progress(self, value: float) -> None:
        self._progress = max(0.0, min(1.0, float(value)))
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setClipRect(self.rect())
        distance = int(round(self.width() * self._progress))
        dx = distance if self._direction == "right" else -distance
        painter.drawPixmap(dx, 0, self._pixmap)
        painter.end()
