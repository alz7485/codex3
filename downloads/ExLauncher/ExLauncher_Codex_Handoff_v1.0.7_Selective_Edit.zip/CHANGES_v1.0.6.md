# ExLauncher v1.0.6

Python 3.11で `No module named PyInstaller` となるビルド失敗に対応し、VS Codeから起動・デバッグ・EXE作成ができる設定を加えました。最初に `VSCODE_GUIDE.md` を参照してください。

- ビルドスクリプトが `.venv` を作り、固定したPySide6/PyInstallerを同じ環境へ準備します。既に準備済みの場合はpipを再実行しません。
- `.vscode/launch.json` と `tasks.json` が、準備・F5起動・EXE作成で同じPythonを使います。推奨拡張も登録しました。
- 一時フォルダに置くspecから相対パスの `icon.ico` が見つからない問題も修正しました。`--icon` と `--add-data` の入力を絶対パスにしています。
- ビルドの一時出力・利用者データ引継ぎ・旧出力の保持は継続します。
- v1.0.5のランチャー本体モジュールは変更していません。

既存56件とビルド環境の追加11件、合計67テストを実行しました。詳細・結果は `validation_v1.0.6.json` を参照してください。WindowsのVS Code/F5/BAT/EXEは本環境では実行できないため未検証です。LinuxのネイティブビルドをWindows EXEの成功とは扱いません。

v1.0.5との差分：

- 変更：`scripts/build_onedir.py`、`tests/test_audit_fixes.py`（合成ビルドの入力・出力を実環境に整合）、`CODEX_HANDOFF.md`、`MANIFEST_SHA256.json`。
- 追加：`requirements-build.txt`、`.gitignore`、`.vscode/launch.json`、`.vscode/tasks.json`、`.vscode/extensions.json`、`tests/test_build_setup.py`、`VSCODE_GUIDE.md`、本書、`validation_v1.0.6.json`。
- 削除：なし。

配布ZIPに `.venv`、個人設定、登録データ、dist出力は含みません。
