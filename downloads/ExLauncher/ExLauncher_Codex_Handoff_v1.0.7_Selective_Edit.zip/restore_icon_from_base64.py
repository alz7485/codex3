from pathlib import Path
import base64

APP_DIR = Path(__file__).resolve().parent
src = APP_DIR / "icon_ico_base64.txt"
dst = APP_DIR / "icon.ico"
text = "".join(src.read_text(encoding="ascii").split())
dst.write_bytes(base64.b64decode(text))
print(f"復元しました: {dst}")
