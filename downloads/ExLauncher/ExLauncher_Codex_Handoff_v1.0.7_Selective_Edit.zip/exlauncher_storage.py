"""UIを共有せず、保存データの検証・原子的保存・複数ファイル復旧を提供する。"""
from __future__ import annotations

import base64
import copy
from datetime import datetime
import json
import hashlib
import os
from pathlib import Path
import re
import tempfile

JOURNAL = '.exlauncher-transaction.json'


class DataFileError(ValueError):
    def __init__(self, path, reason):
        self.path = Path(path)
        super().__init__(f'{self.path}\n{reason}')


def validate_data(path, data):
    """欠損キーと不正な型を区別する。未知の拡張キーはそのまま保持。"""
    def require(condition, message):
        if not condition:
            raise DataFileError(path, message)

    require(isinstance(data, dict), 'JSONの最上位はオブジェクトである必要があります。')
    if 'ui_width' in data:
        width = data['ui_width']
        try:
            valid = not isinstance(width, bool) and str(int(width)) == str(width) and 1 <= int(width) <= 10000
        except (TypeError, ValueError, OverflowError):
            valid = False
        require(valid, 'ui_widthが有効な整数ではありません。')
    for key in ('theme', 'modern_theme'):
        if key in data:
            require(isinstance(data[key], str), f'{key}は文字列である必要があります。')
    if Path(path).name == 'setting.json':
        for key in ('pin', 'allow_multiple_expand'):
            if key in data:
                require(isinstance(data[key], bool), f'{key}は真偽値である必要があります。')
        for key in ('current_preset', 'ui_style', 'drag_bar_position', 'animation_speed'):
            if key in data:
                require(isinstance(data[key], str), f'{key}は文字列である必要があります。')
        return data
    categories = data.get('categories', [])
    require(isinstance(categories, list), 'categoriesは配列である必要があります。')
    for ci, category in enumerate(categories):
        if not isinstance(category, dict):
            raise DataFileError(path, f'カテゴリ{ci + 1}がオブジェクトではありません。')
        if 'name' in category and not isinstance(category['name'], str):
            raise DataFileError(path, f'カテゴリ{ci + 1}の名前が文字列ではありません。')
        items = category.get('items', [])
        if not isinstance(items, list):
            raise DataFileError(path, f'カテゴリ{ci + 1}のitemsは配列である必要があります。')
        for ii, item in enumerate(items):
            if not isinstance(item, dict):
                raise DataFileError(path, f'カテゴリ{ci + 1}の項目{ii + 1}がオブジェクトではありません。')
            for key in ('type', 'name', 'path', 'url', 'text'):
                if key in item and not isinstance(item[key], str):
                    raise DataFileError(path, f'カテゴリ{ci + 1}の項目{ii + 1}の{key}が文字列ではありません。')
    return data


def load_json(path, default):
    path = Path(path)
    try:
        with path.open('r', encoding='utf-8-sig') as stream:
            data = json.load(stream)
    except FileNotFoundError:
        return copy.deepcopy(default)
    except (OSError, ValueError, UnicodeError) as exc:
        raise DataFileError(path, f'読み込めません。元ファイルは保持しています。\n{exc}') from exc
    return validate_data(path, data)


def _write_bytes(path, content):
    """同じディレクトリ内で置換。既存の回復用.tmpを上書きしない。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f'.{path.name}.', suffix='.tmp', dir=path.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def save_json(path, data):
    validate_data(path, data)
    # 実行中に外部編集/破損したファイルも、空の代替データで上書きしない。
    if Path(path).exists():
        load_json(path, {})
    content = json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8')
    _write_bytes(Path(path), content)


def recover_pending(directory):
    """確定前に中断した複数ファイル保存を、書込前のバイト列へ戻す。"""
    directory = Path(directory).resolve()
    journal = directory / JOURNAL
    if not journal.exists():
        return
    try:
        payload = json.loads(journal.read_text(encoding='utf-8'))
        if payload['version'] != 1 or payload['state'] not in ('pending', 'committed'):
            raise ValueError('Unknown journal format')
        entries = []
        for entry in payload['files']:
            relative = Path(entry['path'])
            target = (directory / relative).resolve()
            if relative.is_absolute() or '..' in relative.parts or not target.is_relative_to(directory):
                raise ValueError('Invalid journal path')
            if target.suffix != '.json' or target.name == JOURNAL:
                raise ValueError('Invalid journal target')
            before = base64.b64decode(entry['before'], validate=True) if entry['before'] is not None else None
            after_hash = entry['after_sha256']
            if not isinstance(after_hash, str) or len(after_hash) != 64:
                raise ValueError('Invalid journal hash')
            entries.append((target, before, after_hash))
        if payload['state'] == 'pending':
            # 外部編集されたデータを復旧処理で上書きしない。全件を先に照合する。
            for target, before, after_hash in entries:
                current = target.read_bytes() if target.exists() else None
                if current != before and (current is None or hashlib.sha256(current).hexdigest() != after_hash):
                    raise ValueError(f'保存中断後に変更されたファイルがあります: {target}')
            for target, before, _ in entries:
                current = target.read_bytes() if target.exists() else None
                if current == before:
                    continue
                if before is None:
                    target.unlink(missing_ok=True)
                else:
                    _write_bytes(target, before)
        journal.unlink()
        return payload['state'] == 'pending'
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise DataFileError(journal, f'前回の保存を復旧できません。記録を保持しています。\n{exc}') from exc


def save_transaction(updates, saver=None):
    """全ファイル保存後だけ確定。失敗時は復元し、復元不能なら起動時に再試行。"""
    updates = [(Path(path).resolve(), copy.deepcopy(data)) for path, data in updates]
    if not updates:
        return
    if len({path for path, _ in updates}) != len(updates):
        raise ValueError('同じ保存先が複数あります。')
    for path, data in updates:
        validate_data(path, data)
    directory = Path(os.path.commonpath([str(path.parent) for path, _ in updates]))
    directory.mkdir(parents=True, exist_ok=True)
    if recover_pending(directory):
        raise DataFileError(directory / JOURNAL, '前回の保存を復元しました。データを読み直してから、もう一度操作してください。')
    journal = directory / JOURNAL
    records = []
    for path, data in updates:
        before = path.read_bytes() if path.exists() else None
        records.append({'path': str(path.relative_to(directory)),
                        'before': base64.b64encode(before).decode('ascii') if before is not None else None,
                        'after_sha256': hashlib.sha256(json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8')).hexdigest()})
    payload = {'version': 1, 'state': 'pending', 'files': records}
    _write_bytes(journal, json.dumps(payload, ensure_ascii=False).encode('utf-8'))
    try:
        for path, data in updates:
            (saver or save_json)(path, data)
        # 確定記録の置換までをトランザクションに含める。
        payload['state'] = 'committed'
        _write_bytes(journal, json.dumps(payload, ensure_ascii=False).encode('utf-8'))
    except Exception:
        recover_pending(directory)
        raise
    # 確定後の掃除失敗は次回起動で処理。利用者へ失敗を返して再試行させない。
    try:
        journal.unlink()
    except OSError:
        pass


def validate_preset_name(name):
    name = name.strip()
    if (not name or name.lower() in ('.', '..', '.exlauncher-transaction') or name.endswith(('.', ' '))
            or re.search(r'[<>:"/\\|?*\x00-\x1f]', name)
            or name.split('.')[0].upper() in {'CON', 'PRN', 'AUX', 'NUL',
                *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10))}):
        raise ValueError('ファイル名に使えない名前です。区切り文字や予約名は使用できません。')
    return name


def backup_and_reset(path, default):
    """利用者が明示選択した復旧。退避成功前には元ファイルを変更しない。"""
    path = Path(path)
    if path.name == JOURNAL:
        raise DataFileError(path, '復旧記録は初期化できません。保存場所とアクセス権を確認してください。')
    original = path.read_bytes()
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup = path.with_name(f'{path.name}.{stamp}.bak')
    with backup.open('xb') as stream:
        stream.write(original)
        stream.flush()
        os.fsync(stream.fileno())
    validate_data(path, default)
    _write_bytes(path, json.dumps(default, ensure_ascii=False, indent=2).encode('utf-8'))
    return backup
