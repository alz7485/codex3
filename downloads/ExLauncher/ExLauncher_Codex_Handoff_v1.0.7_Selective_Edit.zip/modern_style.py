# -*- coding: utf-8 -*-
"""ExLauncher Modern 専用スタイル。Classicから完全分離。"""

from functools import lru_cache

# すべて不透明色。左下→右上へ薄く/明るくなるグラデーションを基本にする。
THEMES = {
    # Neutral → Blue → Green → Warm → Red/Pink → Purple の順。
    "Dark Gray": {"accent":"#7EB2FF","header":"#2B2F36","header2":"#3A404A","item":"#363B44","item2":"#454C57","item_hover":"#444B56","item_hover2":"#56606D","bar":"#1D2026","bar2":"#303640","text":"#F7F9FC","muted":"#C0C6CF","border":"#59616D"},
    "Carbon":    {"accent":"#A7B0BF","header":"#202328","header2":"#343941","item":"#2A2E35","item2":"#3B414B","item_hover":"#383E47","item_hover2":"#4A5260","bar":"#15171B","bar2":"#282C33","text":"#F6F7F9","muted":"#B9BEC6","border":"#535A65"},
    "Graphite":  {"accent":"#C2CBD8","header":"#2A2F36","header2":"#49515D","item":"#363D46","item2":"#56616E","item_hover":"#434C57","item_hover2":"#667381","bar":"#1C2026","bar2":"#39414A","text":"#FAFBFC","muted":"#C9CED5","border":"#68727E"},
    "Slate":     {"accent":"#A7C4DA","header":"#26333D","header2":"#435B6C","item":"#32434F","item2":"#506C7D","item_hover":"#3E5361","item_hover2":"#607F91","bar":"#19232A","bar2":"#334754","text":"#F8FCFF","muted":"#C4D2DB","border":"#667D8B"},
    "Silver":    {"accent":"#DCE7F1","header":"#404850","header2":"#687581","item":"#505A64","item2":"#798793","item_hover":"#606C77","item_hover2":"#8B9AA7","bar":"#2C3238","bar2":"#515B64","text":"#FFFFFF","muted":"#DCE2E7","border":"#89949E"},
    "Midnight":  {"accent":"#8EA8FF","header":"#1B2340","header2":"#2E3A65","item":"#252F52","item2":"#37466F","item_hover":"#324063","item_hover2":"#495A84","bar":"#11172B","bar2":"#232D4E","text":"#F8FAFF","muted":"#BCC5E0","border":"#52638C"},
    "Navy":      {"accent":"#78A9FF","header":"#101F3A","header2":"#244D7C","item":"#172B4D","item2":"#2E5F91","item_hover":"#203A61","item_hover2":"#3B72A6","bar":"#0A1528","bar2":"#19385C","text":"#F5F9FF","muted":"#B9CAE1","border":"#456D99"},
    "Blue":      {"accent":"#72BCFF","header":"#17314A","header2":"#28557B","item":"#204260","item2":"#326487","item_hover":"#2A5272","item_hover2":"#3D7398","bar":"#102439","bar2":"#1D4260","text":"#F6FBFF","muted":"#BED5E7","border":"#4C7699"},
    "Azure":     {"accent":"#69D0FF","header":"#123A52","header2":"#23647F","item":"#194A66","item2":"#2A718F","item_hover":"#205B78","item_hover2":"#3383A3","bar":"#0C293A","bar2":"#174B63","text":"#F4FCFF","muted":"#B8DCE8","border":"#46849D"},
    "Sky":       {"accent":"#8DE4FF","header":"#17435B","header2":"#3689AD","item":"#205873","item2":"#43A0C3","item_hover":"#2A6B88","item_hover2":"#54B4D4","bar":"#0F3042","bar2":"#286B89","text":"#F5FDFF","muted":"#C0E1EA","border":"#5B9BB3"},
    "Cyan":      {"accent":"#65E3E8","header":"#123E43","header2":"#22686D","item":"#194E54","item2":"#2B777C","item_hover":"#216167","item_hover2":"#368B91","bar":"#0C2B2F","bar2":"#175155","text":"#F3FFFF","muted":"#B8DDDE","border":"#468A8D"},
    "Teal":      {"accent":"#6DDBC5","header":"#173D38","header2":"#28665B","item":"#1F4D47","item2":"#337568","item_hover":"#286057","item_hover2":"#3F887A","bar":"#102B28","bar2":"#1E4D46","text":"#F4FFFC","muted":"#BCDCD4","border":"#4D887D"},
    "Emerald":   {"accent":"#72E3A8","header":"#123C2C","header2":"#22684B","item":"#1A4D39","item2":"#2D7655","item_hover":"#226047","item_hover2":"#398A64","bar":"#0C2A20","bar2":"#174E39","text":"#F3FFF8","muted":"#B8DDC9","border":"#478A68"},
    "Green":     {"accent":"#83DA9B","header":"#1D3B2B","header2":"#346348","item":"#284B38","item2":"#447457","item_hover":"#335E46","item_hover2":"#508866","bar":"#142A20","bar2":"#254A36","text":"#F6FFF8","muted":"#C3DAC9","border":"#5D846A"},
    "Forest":    {"accent":"#8DD39B","header":"#193323","header2":"#315B3D","item":"#22432F","item2":"#3D6C4B","item_hover":"#2C533A","item_hover2":"#4C805A","bar":"#102419","bar2":"#244630","text":"#F5FFF7","muted":"#BED6C3","border":"#577B60"},
    "Lime":      {"accent":"#C9F06B","header":"#34431A","header2":"#6B852A","item":"#435522","item2":"#7D9934","item_hover":"#526729","item_hover2":"#91AD40","bar":"#242F12","bar2":"#50651F","text":"#FBFFF2","muted":"#D7E4B9","border":"#839B4D"},
    "Olive":     {"accent":"#D1D978","header":"#3A3D1E","header2":"#60652F","item":"#4A4E28","item2":"#70763A","item_hover":"#5A5F31","item_hover2":"#838A45","bar":"#292B16","bar2":"#4B4F25","text":"#FFFFF3","muted":"#DDDEC0","border":"#87895C"},
    "Gold":      {"accent":"#FFD36A","header":"#493A16","header2":"#8A6B24","item":"#5C491C","item2":"#9E7B2E","item_hover":"#705923","item_hover2":"#B58E3A","bar":"#33280F","bar2":"#684F1B","text":"#FFFCF2","muted":"#E7D9B4","border":"#A18749"},
    "Amber":     {"accent":"#FFC568","header":"#493316","header2":"#876126","item":"#5B411D","item2":"#9B7130","item_hover":"#6E5024","item_hover2":"#B0823C","bar":"#33240F","bar2":"#65491C","text":"#FFF9EE","muted":"#E6D2AF","border":"#9E7A48"},
    "Orange":    {"accent":"#FFB36B","header":"#4A3020","header2":"#754B2E","item":"#5C3C28","item2":"#885A38","item_hover":"#6E4930","item_hover2":"#9A6841","bar":"#342217","bar2":"#5A3B25","text":"#FFF9F3","muted":"#E3CEBC","border":"#9A7356"},
    "Copper":    {"accent":"#E9A276","header":"#432B23","header2":"#704738","item":"#55372D","item2":"#825544","item_hover":"#674338","item_hover2":"#966451","bar":"#2F1E18","bar2":"#57382D","text":"#FFF8F4","muted":"#DFC8BB","border":"#926C5A"},
    "Coffee":    {"accent":"#D8B08A","header":"#362B26","header2":"#5A463C","item":"#44362F","item2":"#665044","item_hover":"#534239","item_hover2":"#775F51","bar":"#261E1A","bar2":"#463730","text":"#FFF9F5","muted":"#D8CAC1","border":"#806C60"},
    "Wine":      {"accent":"#E993AD","header":"#3D202C","header2":"#633346","item":"#4E2938","item2":"#744054","item_hover":"#603344","item_hover2":"#875065","bar":"#2B161F","bar2":"#4C2938","text":"#FFF7FA","muted":"#DEC1C9","border":"#8E5B69"},
    "Red":       {"accent":"#FF8E8E","header":"#482323","header2":"#763939","item":"#5A2D2D","item2":"#894545","item_hover":"#6C3737","item_hover2":"#9E5353","bar":"#321818","bar2":"#5A2B2B","text":"#FFF7F7","muted":"#E4C2C2","border":"#9A5D5D"},
    "Rose":      {"accent":"#FF9DBB","header":"#482635","header2":"#713A50","item":"#5A3042","item2":"#85465F","item_hover":"#6C3A4F","item_hover2":"#99536E","bar":"#321B26","bar2":"#582E40","text":"#FFF8FB","muted":"#E6C5D0","border":"#9C6478"},
    "Sakura":    {"accent":"#FFB2CB","header":"#472B38","header2":"#75485D","item":"#593746","item2":"#88566D","item_hover":"#6A4254","item_hover2":"#9D657E","bar":"#311E27","bar2":"#593848","text":"#FFF9FB","muted":"#E7CDD6","border":"#9B7080"},
    "Magenta":   {"accent":"#FF8BEA","header":"#472044","header2":"#873B7C","item":"#5A2955","item2":"#9B4990","item_hover":"#6D3567","item_hover2":"#B15AA5","bar":"#32162F","bar2":"#652B5E","text":"#FFF6FD","muted":"#E5C2DF","border":"#A45B9A"},
    "Purple":    {"accent":"#BE9BFF","header":"#332546","header2":"#563C72","item":"#433259","item2":"#674A82","item_hover":"#523E6B","item_hover2":"#775895","bar":"#241A33","bar2":"#432E58","text":"#FCF9FF","muted":"#D8C8E6","border":"#8069A0"},
    "Violet":    {"accent":"#AFA2FF","header":"#29274D","header2":"#48457B","item":"#373565","item2":"#57538C","item_hover":"#454279","item_hover2":"#6561A0","bar":"#1D1B36","bar2":"#37345F","text":"#FAF9FF","muted":"#D0CBE8","border":"#716EA4"},
    "Lavender":  {"accent":"#D1B5FF","header":"#382B4B","header2":"#604A7B","item":"#493861","item2":"#725993","item_hover":"#594574","item_hover2":"#856BAB","bar":"#271E35","bar2":"#4A3A60","text":"#FCF9FF","muted":"#DCCFE9","border":"#8972A1"},
}


def _mix(c1: str, c2: str, ratio: float) -> str:
    """c1へc2をratioだけ混ぜる。"""
    ratio = max(0.0, min(1.0, ratio))
    a = tuple(int(c1[i:i+2], 16) for i in (1, 3, 5))
    b = tuple(int(c2[i:i+2], 16) for i in (1, 3, 5))
    rgb = tuple(round(x * (1-ratio) + y * ratio) for x, y in zip(a, b))
    return "#%02X%02X%02X" % rgb


def _relative_luminance(color: str) -> float:
    values = [int(color[i:i+2], 16) / 255.0 for i in (1, 3, 5)]
    linear = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in values]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


@lru_cache(maxsize=512)
def _cap_luminance(color: str, maximum: float) -> str:
    """色相を保ったまま暗くし、明色文字が埋もれない明度へ抑える。"""
    if _relative_luminance(color) <= maximum:
        return color
    low, high = 0.0, 1.0
    result = color
    for _ in range(16):
        ratio = (low + high) / 2.0
        candidate = _mix(color, "#000000", ratio)
        if _relative_luminance(candidate) > maximum:
            low = ratio
        else:
            result = candidate
            high = ratio
    return result


def palette(name: str) -> dict:
    # ベーステーマから用途別の色を派生させる。
    # 追加ボタンは通常アイテムより明るくし、カテゴリ追加とアイテム追加も差をつける。
    t = dict(THEMES.get(name, THEMES["Dark Gray"]))
    t["item_add"] = _mix(t["item"], t["text"], 0.10)
    t["item_add2"] = _mix(t["item2"], t["text"], 0.16)
    t["item_add_hover"] = _mix(t["item_hover"], t["text"], 0.16)
    t["item_add2_hover"] = _mix(t["item_hover2"], t["text"], 0.22)
    t["category_add"] = _mix(t["header"], t["text"], 0.15)
    t["category_add2"] = _mix(t["header2"], t["text"], 0.22)
    t["category_add_hover"] = _mix(t["header"], t["text"], 0.22)
    t["category_add2_hover"] = _mix(t["header2"], t["text"], 0.30)
    t["control"] = _mix(t["item"], t["bar"], 0.18)
    t["control2"] = _mix(t["item2"], t["header2"], 0.20)
    return t


@lru_cache(maxsize=256)
def gradient(c1: str, c2: str) -> str:
    # 左下→右上。明色文字とのコントラストを保てる範囲で色差を付ける。
    c1 = _cap_luminance(c1, 0.11)
    c2 = _cap_luminance(c2, 0.13)
    c3 = _cap_luminance(_mix(c2, "#FFFFFF", 0.12), 0.15)
    return (
        "qlineargradient(x1:0, y1:1, x2:1, y2:0, "
        f"stop:0 {c1}, stop:0.46 {c2}, stop:1 {c3})"
    )


@lru_cache(maxsize=64)
def app_qss(name: str) -> str:
    t = palette(name)
    return f"""
    QWidget {{
        font-family: "Segoe UI", "Yu Gothic UI", sans-serif;
        color: {t['text']};
    }}
    QToolTip {{
        background: {t['bar']}; color: {t['text']};
        border: 1px solid {t['border']}; padding: 2px 5px;
    }}
    QComboBox, QSpinBox, QLineEdit, QTextEdit {{
        background: {gradient(t['control'], t['control2'])}; color: {t['text']};
        border: 1px solid {t['border']}; border-radius: 5px;
        padding: 2px 6px;
        selection-background-color: {t['accent']};
        selection-color: #101216;
    }}
    QComboBox:hover, QSpinBox:hover, QLineEdit:hover, QTextEdit:hover {{
        border-color: {t['accent']};
    }}
    QComboBox QAbstractItemView {{
        background: {t['bar']}; color: {t['text']};
        border: 1px solid {t['border']};
        selection-background-color: {t['accent']};
        selection-color: #101216;
    }}
    QListWidget, QListView, QTreeView, QTableView {{
        background: {t['control']}; color: {t['text']};
        alternate-background-color: {t['control2']};
        border: 1px solid {t['border']}; border-radius: 5px;
        selection-background-color: {t['accent']};
        selection-color: #101216;
        outline: none;
    }}
    QListWidget::item, QListView::item, QTreeView::item {{
        color: {t['text']}; padding: 3px 5px;
    }}
    QListWidget::item:selected, QListView::item:selected, QTreeView::item:selected {{
        background: {t['accent']}; color: #101216;
        border-left: 3px solid #101216;
    }}
    QHeaderView::section {{
        background: {t['header']}; color: {t['text']};
        border: none; border-right: 1px solid {t['border']};
        border-bottom: 1px solid {t['border']}; padding: 3px 5px;
    }}
    QAbstractScrollArea::corner {{ background: {t['control']}; }}
    QPushButton {{
        background: {gradient(t['control'], t['control2'])}; color: {t['text']};
        border: 1px solid {t['border']}; border-radius: 5px;
        padding: 2px 6px;
    }}
    QPushButton:hover {{ background: {gradient(t['item_hover'], t['item_hover2'])}; border-color: {t['accent']}; }}
    QPushButton:pressed {{ background: {t['header']}; }}
    QPushButton:checked {{
        background: {t['accent']}; color: #101216; font-weight: 700;
        border: 2px solid {t['text']};
    }}
    QPushButton:disabled, QLineEdit:disabled, QTextEdit:disabled,
    QComboBox:disabled, QListWidget:disabled {{
        color: {t['muted']};
    }}
    QCheckBox {{ color: {t['text']}; spacing: 5px; }}
    QDialog {{ background: {gradient(t['header'], t['header2'])}; }}
    QMenu {{
        background: {t['bar']}; color: {t['text']};
        border: 1px solid {t['border']}; border-radius: 5px;
        padding: 2px;
    }}
    QMenu::item {{ padding: 3px 11px; border-radius: 4px; }}
    QMenu::item:selected {{ background: {t['accent']}; color: #101216; }}
    """
