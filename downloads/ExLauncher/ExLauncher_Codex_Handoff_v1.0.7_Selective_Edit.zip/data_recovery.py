"""読み込み不能な保存データを、無断で初期化しないための復旧画面。"""
from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QMessageBox

from exlauncher_storage import DataFileError, JOURNAL, backup_and_reset


class StartupCancelled(Exception):
    pass


def prepare_data(ensure, settings_default, preset_default, parent=None):
    while True:
        try:
            return ensure()
        except (DataFileError, OSError) as exc:
            box = QMessageBox(parent)
            box.setIcon(QMessageBox.Icon.Warning)
            box.setWindowTitle('保存データの確認')
            box.setText('保存データを読み込めません。ファイルは自動で初期化しません。')
            box.setInformativeText(str(exc))
            stop = box.addButton('ファイルを保持して終了', QMessageBox.ButtonRole.RejectRole)
            folder = box.addButton('保存場所を開く', QMessageBox.ButtonRole.ActionRole)
            reset = None
            if isinstance(exc, DataFileError) and exc.path.name != JOURNAL:
                reset = box.addButton('バックアップして初期化', QMessageBox.ButtonRole.DestructiveRole)
            box.setDefaultButton(stop)
            box.setEscapeButton(stop)
            box.exec()
            if box.clickedButton() is folder:
                if isinstance(exc, DataFileError):
                    QDesktopServices.openUrl(QUrl.fromLocalFile(str(exc.path.parent)))
                continue
            if reset is not None and box.clickedButton() is reset:
                try:
                    backup_and_reset(exc.path, settings_default if exc.path.name == 'setting.json' else preset_default)
                except (OSError, ValueError) as reset_exc:
                    QMessageBox.warning(parent, '初期化できません', str(reset_exc))
                continue
            raise StartupCancelled() from exc
