@echo off
setlocal
cd /d "%~dp0"

python scripts\build_onedir.py
if errorlevel 1 (
    echo.
    echo Build failed. Existing installation and data were retained.
    pause
    exit /b 1
)

echo.
echo Build complete: dist\ExLauncher\ExLauncher.exe
pause
