# -*- coding: utf-8 -*-
"""ExLauncher unified entry point - Classic / Modern 高速切替版。"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from app_runtime import SingleInstanceController, get_app_icon
from data_recovery import StartupCancelled


def get_app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def read_ui_style() -> str:
    setting_file = get_app_dir() / "setting.json"
    try:
        if setting_file.exists():
            with setting_file.open("r", encoding="utf-8-sig") as f:
                data = json.load(f)
            if str(data.get("ui_style", "Classic")).strip().lower() == "modern":
                return "Modern"
    except Exception:
        pass
    return "Classic"


class UIController:
    """QApplicationを維持したままClassic/Modernのウィンドウだけを交換する。"""
    def __init__(self, app: QApplication, single_instance: SingleInstanceController):
        self.app = app
        self.single_instance = single_instance
        self.window = None
        self.tray_controller = None
        self.current_style = None
        self._switching = False

    def start(self):
        self._create_ui(read_ui_style())

    def _destroy_current_ui(self):
        tray = self.tray_controller
        if tray is not None:
            tray_icon = getattr(tray, "tray", None) or getattr(tray, "tray_icon", None)
            if tray_icon is not None:
                try:
                    tray_icon.hide()
                    tray_icon.setContextMenu(None)
                    tray_icon.deleteLater()
                except RuntimeError:
                    pass
        self.tray_controller = None
        self.app.tray_controller = None

        w = self.window
        if w is not None:
            # UI固有のアニメーション/スナップショット等を先に停止する。
            # 高速切替を何十回繰り返しても旧UIのコールバックを新UIへ持ち越さない。
            shutdown = getattr(w, "shutdown_for_switch", None)
            if callable(shutdown):
                try:
                    shutdown()
                except RuntimeError:
                    pass
            bar = getattr(w, "drag_bar", None)
            if bar is not None:
                try:
                    bar.hide()
                    bar.deleteLater()
                except RuntimeError:
                    pass
            try:
                w.hide()
                w.deleteLater()
            except RuntimeError:
                pass
        self.window = None
        self.app.processEvents()

    def _create_ui(self, style: str):
        icon = get_app_icon()
        if style == "Modern":
            import modern_main as ui
            w = ui.ModernWindow()
            w.setWindowIcon(icon)
            w.show()
            w.drag_bar.show()
            w.update_pair_geometry()
        else:
            import classic_main as ui
            w = ui.MainWindow()
            w.setWindowIcon(icon)
            w.show()

        tray = ui.TrayController(self.app, w)
        w.tray_controller = tray
        self.app.tray_controller = tray
        self.window = w
        self.tray_controller = tray
        self.current_style = style
        self.single_instance.set_activate_callback(self.reveal)

    def request_switch(self):
        if self._switching:
            return
        target = read_ui_style()
        if target == self.current_style:
            return
        self._switching = True
        self._destroy_current_ui()
        # deleteLaterを一巡させてから新UIを生成。EXE再起動は行わない。
        QTimer.singleShot(0, lambda: self._finish_switch(target))

    def _finish_switch(self, target: str):
        try:
            self._create_ui(target)
        except StartupCancelled:
            self.app.quit()
        finally:
            self._switching = False

    def reveal(self):
        w = self.window
        if w is None:
            return
        callback = getattr(w, "reveal_from_secondary_instance", None)
        if callable(callback):
            callback()
            return
        w.show()
        bar = getattr(w, "drag_bar", None)
        if bar is not None:
            bar.show()
        w.raise_()
        w.activateWindow()


def main() -> int:
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setWindowIcon(get_app_icon())

    single_instance = SingleInstanceController(parent=app)
    if not single_instance.acquire():
        return 0
    app.single_instance = single_instance
    app.aboutToQuit.connect(single_instance.shutdown)

    controller = UIController(app, single_instance)
    app.ui_controller = controller
    app.ui_switch_callback = controller.request_switch
    try:
        controller.start()
    except StartupCancelled:
        single_instance.shutdown()
        return 1
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
