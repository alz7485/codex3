"""Build in isolation, then preserve portable data and the previous installation."""
from datetime import datetime
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def publish(staged, target):
    staged, target = Path(staged), Path(target)
    backup = None
    if target.exists():
        if not target.is_dir():
            raise ValueError(f'Output is not a directory: {target}')
        # All old files remain in the backup, including unknown user files.
        if (target / '登録情報').exists():
            shutil.copytree(target / '登録情報', staged / '登録情報', dirs_exist_ok=True)
        for pattern in ('setting.json', 'setting.json.*.bak', '.exlauncher-transaction.json'):
            for data_file in target.glob(pattern):
                shutil.copy2(data_file, staged / data_file.name)
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
        backup = target.with_name(f'{target.name}.previous-{stamp}')
        target.rename(backup)
    try:
        staged.rename(target)
    except OSError:
        if backup is not None:
            backup.rename(target)
        raise
    return backup


def build(root):
    root = Path(root).resolve()
    if not (root / 'icon.ico').is_file():
        raise FileNotFoundError('Put icon.ico next to build_onedir.bat, then run it again.')
    dist = root / 'dist'
    dist.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.exlauncher-build-', dir=dist) as temp:
        staging = Path(temp)
        subprocess.run([
            sys.executable, '-m', 'PyInstaller', '--clean', '--noconfirm', '--onedir', '--noconsole',
            '--icon=icon.ico', '--add-data', 'icon.ico;.', '--name', 'ExLauncher',
            '--distpath', str(staging / 'dist'), '--workpath', str(staging / 'build'),
            '--specpath', str(staging), str(root / 'main.py'),
        ], cwd=root, check=True)
        staged = staging / 'dist' / 'ExLauncher'
        if not (staged / 'ExLauncher.exe').is_file():
            raise FileNotFoundError('Build did not produce ExLauncher.exe; existing output was retained.')
        backup = publish(staged, dist / 'ExLauncher')
    if backup:
        print(f'Previous installation retained: {backup}')


if __name__ == '__main__':
    try:
        build(Path(__file__).resolve().parents[1])
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        print(f'Build failed: {exc}', file=sys.stderr)
        sys.exit(1)
