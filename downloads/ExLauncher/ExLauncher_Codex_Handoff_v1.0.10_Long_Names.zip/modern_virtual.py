"""大量項目はQtのモデル/デリゲートで可視行だけを描画する。"""
from __future__ import annotations

import json

from PySide6.QtCore import QAbstractListModel, QModelIndex, QSize, Qt, Signal, QMimeData
from PySide6.QtGui import QColor, QDrag, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import QListView, QStyledItemDelegate, QStyle

from modern_style import palette


class ItemListModel(QAbstractListModel):
    def __init__(self, items, parent):
        super().__init__(parent)
        self.items = items

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.items)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if index.isValid() and role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.ToolTipRole,
                                       Qt.ItemDataRole.AccessibleTextRole):
            item = self.items[index.row()]
            return '────────' if item.get('type') == 'separator' else item.get('name', '')
        return None


class ItemDelegate(QStyledItemDelegate):
    def sizeHint(self, option, index):
        return QSize(100, self.parent().row_height)

    def paint(self, painter, option, index):
        view = self.parent()
        t = palette(view.theme)
        rect = option.rect.adjusted(0, 0, -1, -2)
        hover = bool(option.state & QStyle.StateFlag.State_MouseOver)
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        gradient = QLinearGradient(rect.bottomLeft(), rect.topRight())
        gradient.setColorAt(0, QColor(t['item_hover'] if hover else t['item']))
        gradient.setColorAt(1, QColor(t['item_hover2'] if hover else t['item2']))
        painter.setBrush(gradient)
        painter.setPen(QPen(QColor(t['accent'] if hover else t['border']), 1))
        painter.drawRoundedRect(rect, 4, 4)
        painter.setFont(option.font)
        painter.setPen(QColor(t['text']))
        left = rect.left() + 6
        if view.edit_mode:
            painter.drawText(rect.adjusted(4, 0, -rect.width() + 22, 0), Qt.AlignmentFlag.AlignCenter, '☰')
            painter.drawText(rect.adjusted(rect.width() - 24, 0, -3, 0), Qt.AlignmentFlag.AlignCenter, '⋮')
            left += 20
        item = view.items[index.row()]
        if item.get('type') == 'separator':
            painter.drawText(left, rect.top(), 16, rect.height(), Qt.AlignmentFlag.AlignCenter, '─')
        else:
            icon = view.icon_provider(item)
            if icon is not None:
                icon.paint(painter, left, rect.top() + (rect.height() - 14) // 2, 14, 14)
        text_rect = rect.adjusted(left - rect.left() + 19, 0, -26 if view.edit_mode else -6, 0)
        text = option.fontMetrics.elidedText(str(index.data()), Qt.TextElideMode.ElideRight, max(0, text_rect.width()))
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignVCenter, text)
        painter.restore()


class VirtualItemList(QListView):
    activatedItem = Signal(int)
    rightClickedItem = Signal(int)
    editRequested = Signal(int)

    def __init__(self, items, category_index, theme, icon_provider, row_height, parent=None):
        super().__init__(parent)
        self.items = items
        self.category_index = category_index
        self.theme = theme
        self.icon_provider = icon_provider
        self.row_height = row_height
        self.edit_mode = False
        self._press = None
        self._drag_started = False
        self.setModel(ItemListModel(items, self))
        self.setItemDelegate(ItemDelegate(self))
        self.setUniformItemSizes(True)
        self.setWordWrap(False)
        self.setMouseTracking(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setVerticalScrollMode(QListView.ScrollMode.ScrollPerPixel)
        self.setStyleSheet('QListView { border: none; background: transparent; padding: 0; }')
        self.viewport().setAutoFillBackground(False)
        available = self.screen().availableGeometry().height()
        self.setFixedHeight(min(len(items) * row_height, max(54, min(480, available - 180))))

    def set_edit_mode(self, enabled):
        self.edit_mode = bool(enabled)
        self.viewport().update()

    def apply_theme(self, theme):
        self.theme = theme
        self.viewport().update()

    def mousePressEvent(self, event):
        self._press = event.position().toPoint() if event.button() == Qt.MouseButton.LeftButton else None
        self._drag_started = False
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if (self.edit_mode and self._press is not None and self._press.x() < 25
                and event.buttons() & Qt.MouseButton.LeftButton
                and (event.position().toPoint() - self._press).manhattanLength() >= 5):
            index = self.indexAt(self._press)
            self._press = None
            self._drag_started = True
            if index.isValid():
                mime = QMimeData()
                mime.setData('application/x-exlauncher-modern-item', json.dumps({
                    'category': self.category_index, 'item': index.row()}).encode('utf-8'))
                drag = QDrag(self)
                drag.setMimeData(mime)
                drag.exec(Qt.DropAction.MoveAction)
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        index = self.indexAt(event.position().toPoint())
        clicked = not self._drag_started
        self._press = None
        super().mouseReleaseEvent(event)
        if not clicked or not index.isValid():
            return
        if event.button() == Qt.MouseButton.RightButton and not self.edit_mode:
            self.rightClickedItem.emit(index.row())
        elif event.button() == Qt.MouseButton.LeftButton:
            if not self.edit_mode:
                self.activatedItem.emit(index.row())
            elif event.position().x() >= self.viewport().width() - 26:
                self.editRequested.emit(index.row())

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.currentIndex().isValid():
            if self.edit_mode:
                self.editRequested.emit(self.currentIndex().row())
            else:
                self.activatedItem.emit(self.currentIndex().row())
            event.accept()
            return
        super().keyPressEvent(event)
