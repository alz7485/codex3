"""Regression checks for the nine v1.0.8 audit findings, synthetic data only."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from PySide6.QtCore import QMimeData, QPoint, QPointF, QRect, Qt
from PySide6.QtGui import QDropEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QMenu, QMessageBox

import test_performance_regressions as perf
import modern_main as modern
import exlauncher_storage as storage
from modern_widgets import ItemRow, MIME_CATEGORY, MIME_ITEM


class FixedAuditTests(unittest.TestCase):
    write_preset = perf.LauncherTests.write_preset
    write_settings = perf.LauncherTests.write_settings
    window = perf.LauncherTests.window

    def setUp(self):
        perf.LauncherTests.setUp(self)
        mock = patch.object(QMessageBox, 'warning', return_value=QMessageBox.StandardButton.Ok)
        self.warning = mock.start()
        self.addCleanup(mock.stop)

    def snapshot(self, window):
        return (copy.deepcopy(window.data), copy.deepcopy(window.settings),
                {p: p.read_bytes() for p in self.presets.glob('*.json')},
                (self.root / 'setting.json').read_bytes())

    def drop(self, panel, mime_type, payload, point=None):
        mime = QMimeData()
        mime.setData(mime_type, json.dumps(payload).encode())
        event = QDropEvent(point or QPointF(10, 27), Qt.DropAction.MoveAction, mime,
                           Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
        panel.dropEvent(event)
        return event

    def test_failed_category_drop_keeps_model_rows_files_and_launch_target(self):
        window = self.window()
        window.category_panels[0].set_expanded(True, False)
        row = window.category_panels[0].rows[0]
        window.toggle_edit_mode()
        before = self.snapshot(window)
        with patch.object(modern, 'save_preset', side_effect=PermissionError('synthetic denial')):
            event = self.drop(window.category_panels[1], MIME_CATEGORY, {'category': 0})
        self.assertFalse(event.isAccepted())
        self.assertEqual(self.snapshot(window), before)
        self.assertIs(window.category_panels[0].rows[0], row)
        self.warning.assert_called_once()
        window.toggle_edit_mode()
        with patch.object(modern, 'launch_item', return_value=True) as launch:
            QTest.mouseClick(row, Qt.MouseButton.LeftButton)
            self.assertEqual(launch.call_args.args[0]['name'], 'Document')

    def test_delete_after_failed_move_deletes_the_visible_registration_only(self):
        window = self.window()
        window.category_panels[0].set_expanded(True, False)
        window.toggle_edit_mode()
        with patch.object(modern, 'save_preset', side_effect=OSError('synthetic denial')):
            self.assertFalse(window.move_category(0, 2))

        class DeleteMenu(QMenu):
            def exec(self, *args):
                return self.actions()[1]

        with patch.object(modern, 'QMenu', DeleteMenu):
            QTest.mouseClick(window.category_panels[0].rows[0].menu_btn, Qt.MouseButton.LeftButton)
        saved = storage.load_json(self.presets / 'test.json', {})
        self.assertEqual([x['name'] for x in saved['categories'][0]['items']], ['定型文', '仕切り'])
        self.assertEqual(saved['categories'][1]['items'][0]['name'], 'Web')

    def test_failed_registration_retry_adds_exactly_once(self):
        window = self.window()
        window.toggle_edit_mode()
        before = self.snapshot(window)
        with patch.object(modern, 'save_preset', side_effect=OSError('synthetic denial')):
            self.assertFalse(window.register_external_paths(2, [str(self.file)]))
        self.assertEqual(self.snapshot(window), before)
        self.assertTrue(window.register_external_paths(2, [str(self.file)]))
        self.assertEqual(len(window.data['categories'][2]['items']), 1)
        self.assertEqual(len(storage.load_json(self.presets / 'test.json', {})['categories'][2]['items']), 1)

    def test_failed_item_move_keeps_data_and_retry_moves_once(self):
        window = self.window()
        window.toggle_edit_mode()
        before = self.snapshot(window)
        with patch.object(modern, 'save_preset', side_effect=OSError('synthetic denial')):
            event = self.drop(window.category_panels[1], MIME_ITEM, {'category': 0, 'item': 1})
        self.assertFalse(event.isAccepted())
        self.assertEqual(self.snapshot(window), before)
        self.assertTrue(window.move_item(0, 1, 1, 2))
        self.assertEqual([i['name'] for i in window.data['categories'][1]['items']], ['Web', 'Folder', '定型文'])

    def test_failed_item_edit_and_category_add_keep_original_objects(self):
        window = self.window()
        window.category_panels[0].set_expanded(True, False)
        before = self.snapshot(window)
        row = window.category_panels[0].rows[1]
        with patch.object(modern.ItemEditDialog, 'exec', return_value=QDialog.DialogCode.Accepted), \
             patch.object(modern.ItemEditDialog, 'value', return_value={'type': 'text', 'name': 'changed', 'text': 'changed'}), \
             patch.object(modern, 'save_preset', side_effect=OSError('synthetic denial')):
            window.normal_item_right_click(0, 1)
        window.toggle_edit_mode()
        with patch.object(modern.QInputDialog, 'getText', return_value=('added', True)), \
             patch.object(modern, 'save_preset', side_effect=OSError('synthetic denial')):
            window.add_category()
        self.assertEqual(self.snapshot(window), before)
        self.assertIs(window.category_panels[0].rows[1], row)

    def test_rename_and_delete_setting_failure_roll_back_then_retry(self):
        self.write_preset(self.data, 'other.json')
        for operation in ('rename', 'delete'):
            with self.subTest(operation=operation):
                window = self.window()
                window.toggle_edit_mode()
                before = self.snapshot(window)
                original = modern.save_json

                def fail_settings(path, data):
                    if Path(path).name == 'setting.json':
                        raise PermissionError('synthetic denial')
                    original(path, data)

                with patch.object(modern, 'save_json', side_effect=fail_settings), \
                     patch.object(modern.QInputDialog, 'getText', return_value=('renamed', True)), \
                     patch.object(QMessageBox, 'question', return_value=QMessageBox.StandardButton.Yes):
                    (window.rename_current_preset if operation == 'rename' else window.delete_current_preset)()
                self.assertEqual(self.snapshot(window), before)
                self.assertEqual(Path(window.preset_combo.currentData()).name, 'test.json')
                self.assertFalse((self.presets / 'renamed.json').exists())
                self.assertFalse((self.root / storage.JOURNAL).exists())
                window.save_current()
                after_save = self.snapshot(window)
                self.assertEqual(after_save[:2], before[:2])
                self.assertEqual({p: json.loads(b) for p, b in after_save[2].items()},
                                 {p: json.loads(b) for p, b in before[2].items()})
                with patch.object(modern.QInputDialog, 'getText', return_value=('renamed', True)), \
                     patch.object(QMessageBox, 'question', return_value=QMessageBox.StandardButton.Yes):
                    (window.rename_current_preset if operation == 'rename' else window.delete_current_preset)()
                self.assertFalse((self.presets / 'test.json').exists())
                self.assertEqual(Path(window.preset_combo.currentData()).name,
                                 'renamed.json' if operation == 'rename' else 'other.json')
                window.save_current()
                self.assertFalse((self.presets / 'test.json').exists())
                # Restore synthetic fixture for the next independent operation.
                self.write_preset(self.data)
                (self.presets / 'renamed.json').unlink(missing_ok=True)
                self.write_settings()

    def test_add_preset_setting_failure_leaves_no_new_file_or_selection(self):
        window = self.window()
        window.toggle_edit_mode()
        before = self.snapshot(window)
        original = modern.save_json

        def fail(path, data):
            if Path(path).name == 'setting.json':
                raise PermissionError('synthetic denial')
            original(path, data)

        with patch.object(modern.QInputDialog, 'getText', return_value=('new', True)), \
             patch.object(modern, 'save_json', side_effect=fail):
            window.add_preset()
        self.assertEqual(self.snapshot(window), before)
        self.assertFalse((self.presets / 'new.json').exists())

    def test_delete_transaction_crash_recovers_before_bytes_and_removes_new_file(self):
        source = self.presets / 'test.json'
        target = self.presets / 'renamed.json'
        before = source.read_bytes()

        class Crash(BaseException):
            pass

        def crash_on_settings(path, data):
            if Path(path).name == 'setting.json':
                raise Crash()
            storage.save_json(path, data)

        with self.assertRaises(Crash):
            storage.save_transaction([(target, self.data), (source, None),
                                      (self.root / 'setting.json', self.settings)], saver=crash_on_settings)
        self.assertFalse(source.exists())
        self.assertTrue(target.exists())
        self.assertEqual(json.loads((self.root / storage.JOURNAL).read_text())['version'], 2)
        self.assertTrue(storage.recover_pending(self.root))
        self.assertEqual(source.read_bytes(), before)
        self.assertFalse(target.exists())

    def test_delete_recovery_preserves_external_changes_and_journal(self):
        source = self.presets / 'test.json'

        class Crash(BaseException):
            pass

        with self.assertRaises(Crash):
            storage.save_transaction([(source, None), (self.root / 'setting.json', self.settings)],
                                     saver=lambda *args: (_ for _ in ()).throw(Crash()))
        source.write_text(json.dumps(dict(self.data, external='change')))
        before = source.read_bytes()
        with self.assertRaises(storage.DataFileError):
            storage.recover_pending(self.root)
        self.assertEqual(source.read_bytes(), before)
        self.assertTrue((self.root / storage.JOURNAL).exists())

    def test_unresolved_recovery_blocks_following_edits_then_allows_reload_and_retry(self):
        window = self.window()
        window.toggle_edit_mode()
        before = self.snapshot(window)
        source = self.presets / 'test.json'
        target = self.presets / 'renamed.json'

        class Crash(BaseException):
            pass

        def save_then_crash(path, data):
            if Path(path).name == 'setting.json':
                raise Crash()
            storage.save_json(path, data)

        with self.assertRaises(Crash):
            storage.save_transaction([(target, self.data), (source, None),
                                      (self.root / 'setting.json', self.settings)], saver=save_then_crash)
        with patch.object(storage, '_write_bytes', side_effect=PermissionError('recovery denied')):
            self.assertFalse(window.register_external_paths(2, [str(self.file)]))
        self.assertEqual(window.data, before[0])
        self.assertTrue((self.root / storage.JOURNAL).exists())
        self.assertFalse(window.register_external_paths(2, [str(self.file)]))
        self.assertEqual(source.read_bytes(), before[2][source])
        self.assertFalse(target.exists())
        window.reload_presets()
        self.assertTrue(window.register_external_paths(2, [str(self.file)]))
        self.assertEqual(len(window.data['categories'][2]['items']), 1)

    def test_settings_failure_keeps_draft_for_retry_and_cancel(self):
        window = self.window()
        before = self.snapshot(window)
        window.open_settings()
        dlg = window._settings_dialog
        dlg.width_spin.setValue(610)
        dlg.theme.setCurrentText('Navy')
        dlg.ui_style.setCurrentText('Modern')
        with patch.object(modern, 'save_transaction', side_effect=OSError('synthetic denial')):
            QTest.mouseClick(dlg.buttons.button(QDialogButtonBox.StandardButton.Ok), Qt.MouseButton.LeftButton)
        self.assertIs(window._settings_dialog, dlg)
        self.assertTrue(dlg.isVisible())
        self.assertEqual(window._settings_phase, 'shown')
        self.assertEqual(dlg.width_spin.value(), 610)
        self.assertEqual(dlg.theme.currentText(), 'Navy')
        self.assertEqual(self.snapshot(window), before)
        QTest.mouseClick(dlg.buttons.button(QDialogButtonBox.StandardButton.Ok), Qt.MouseButton.LeftButton)
        self.assertIsNone(window._settings_dialog)
        self.assertEqual(storage.load_json(self.presets / 'test.json', {})['ui_width'], 610)

    def test_narrow_settings_can_scroll_to_control_right_edges(self):
        window = self.window()
        screen = SimpleNamespace(availableGeometry=lambda: QRect(0, 0, 300, 480))
        with patch.object(window.drag_bar, 'screen', return_value=screen):
            window.open_settings()
            dlg = window._settings_dialog
            perf.drain()
            scroll = dlg.form_scroll
            self.assertGreater(scroll.horizontalScrollBar().maximum(), 0)
            self.assertTrue(scroll.horizontalScrollBar().isVisible())
            scroll.horizontalScrollBar().setValue(scroll.horizontalScrollBar().maximum())
            perf.drain()
            for control in (dlg.position, dlg.width_spin, dlg.theme):
                point = control.mapTo(scroll.viewport(), QPoint(control.width() - 1, control.height() // 2))
                self.assertTrue(scroll.viewport().rect().contains(point))
            dlg.reject()

    def large_window(self, count=2000):
        self.write_preset(dict(self.data, categories=[{'name': 'large', 'items': [
            {'type': 'text', 'name': f'Item {i}', 'text': str(i)} for i in range(count)]},
            {'name': 'closed', 'items': []}]))
        window = self.window()
        window.category_panels[0].set_expanded(True, False)
        perf.drain()
        return window

    def test_large_category_virtualizes_and_reuses_view_in_edit_mode(self):
        window = self.large_window()
        panel = window.category_panels[0]
        view = panel.virtual_list
        self.assertEqual(view.model().rowCount(), 2000)
        self.assertEqual(len(panel.rows), 0)
        self.assertEqual(window.findChildren(ItemRow), [])
        with patch.object(window, 'item_icon', wraps=window.item_icon) as icons:
            window.toggle_edit_mode()
            self.assertIs(panel.virtual_list, view)
            self.assertTrue(panel.expanded)
            self.assertFalse(window.category_panels[1].expanded)
            # Painting may request visible icons; it must never enumerate 2000 widgets/icons.
            self.assertLess(icons.call_count, 100)
        panel.set_expanded(False, False)
        panel.set_expanded(True, False)
        self.assertIs(panel.virtual_list, view)

    def test_virtual_last_row_real_click_menu_keyboard_theme_and_scroll_preservation(self):
        window = self.large_window()
        view = window.category_panels[0].virtual_list
        view.scrollToBottom()
        perf.drain()
        index = view.model().index(1999)
        rect = view.visualRect(index)
        self.assertTrue(view.viewport().rect().contains(rect.center()))
        with patch.object(modern, 'launch_item', return_value=True) as launch:
            QTest.mouseClick(view.viewport(), Qt.MouseButton.LeftButton, pos=rect.center())
            self.assertEqual(launch.call_args.args[0]['name'], 'Item 1999')
        window.toggle_edit_mode()
        with patch.object(window, 'item_menu') as menu:
            QTest.mouseClick(view.viewport(), Qt.MouseButton.LeftButton,
                             pos=QPoint(view.viewport().width() - 10, rect.center().y()))
            menu.assert_called_once_with(0, 1999)
            view.setCurrentIndex(index)
            QTest.keyClick(view, Qt.Key.Key_Return)
            self.assertEqual(menu.call_args.args, (0, 1999))
        window.data['modern_theme'] = 'Navy'
        window.apply_settings()
        self.assertEqual(view.theme, 'Navy')
        offset = view.verticalScrollBar().value()
        self.assertTrue(window._edit_current(lambda data: data['categories'][0]['items'][1999].update(name='Updated')))
        perf.drain()
        current = window.category_panels[0].virtual_list
        self.assertEqual(current.verticalScrollBar().value(), offset)
        self.assertEqual(current.model().index(1999).data(), 'Updated')

    def test_virtual_drop_uses_scrolled_model_index_and_failed_drop_is_ignored(self):
        window = self.large_window()
        window.toggle_edit_mode()
        panel = window.category_panels[0]
        view = panel.virtual_list
        view.scrollToBottom()
        perf.drain()
        rect = view.visualRect(view.model().index(1999))
        point = view.viewport().mapTo(panel, QPoint(10, rect.bottom() - 1))
        before = self.snapshot(window)
        with patch.object(modern, 'save_preset', side_effect=OSError('synthetic denial')):
            failed = self.drop(panel, MIME_ITEM, {'category': 0, 'item': 0}, QPointF(point))
        self.assertFalse(failed.isAccepted())
        self.assertEqual(self.snapshot(window), before)
        event = self.drop(panel, MIME_ITEM, {'category': 0, 'item': 0}, QPointF(point))
        self.assertTrue(event.isAccepted())
        self.assertEqual(window.data['categories'][0]['items'][-1]['name'], 'Item 0')

    def test_high_dpi_real_settings_cycles_on_both_sides(self):
        for scale in ('1', '1.5', '2'):
            with self.subTest(scale=scale):
                result = subprocess.run([sys.executable, __file__, '--dpi-probe'],
                                        env=dict(os.environ, QT_SCALE_FACTOR=scale, PYTHONDONTWRITEBYTECODE='1'),
                                        capture_output=True, text=True, timeout=15)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout)['sides_checked'], 2)


def dpi_probe():
    case = perf.LauncherTests('test_edit_mode_restores_all_closed')
    case.setUp()
    try:
        for side in ('left', 'right'):
            window = case.window()
            window.settings.update(drag_bar_position=side, animation_speed='fast', ui_style='Modern')
            window.apply_settings()
            original = window._animate_clipped_horizontal

            def inspect(pix, pos, hiding, duration, finished, **kwargs):
                original(pix, pos, hiding, duration, finished, **kwargs)
                proxy = window._snapshot_proxies[-1]
                assert proxy.size() == pix.deviceIndependentSize().toSize()
                if window._settings_phase in ('settings_show', 'settings_hide'):
                    assert proxy.width() == window._settings_dialog.width()
                    assert proxy.height() == window.drag_bar.height()
                    assert (proxy.x() == window.drag_bar.x() + window.drag_bar.width() if side == 'left'
                            else proxy.x() + proxy.width() == window.drag_bar.x())

            with patch.object(window, '_animate_clipped_horizontal', side_effect=inspect):
                window.open_settings()
                perf.finish_transition(window)
                window._settings_dialog.reject()
                perf.finish_transition(window)
            assert (window.x() == window.drag_bar.x() + window.drag_bar.width() if side == 'left'
                    else window.x() + window.width() == window.drag_bar.x())
        print(json.dumps({'sides_checked': 2, 'scale': os.environ.get('QT_SCALE_FACTOR')}))
    finally:
        case.doCleanups()


if __name__ == '__main__':
    if '--dpi-probe' in sys.argv:
        dpi_probe()
    else:
        unittest.main()
