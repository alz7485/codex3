"""Long names must not push edit actions beyond the visible viewport."""
import json
import unittest
from unittest.mock import patch

from PySide6.QtCore import QPoint, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QMenu

import test_performance_regressions as perf
import modern_main as modern


class DeleteMenu(QMenu):
    def exec(self, *args):
        return next(action for action in self.actions() if action.text() == '削除')


class LongNameTests(unittest.TestCase):
    write_preset = perf.LauncherTests.write_preset
    write_settings = perf.LauncherTests.write_settings
    window = perf.LauncherTests.window

    def setUp(self):
        perf.LauncherTests.setUp(self)

    def assert_visible_button(self, window, button):
        viewport = window.category_scroll.viewport()
        for point in (button.rect().topLeft(), button.rect().bottomRight()):
            self.assertTrue(viewport.rect().contains(button.mapTo(viewport, point)),
                            f'Button is outside viewport: {button.mapTo(viewport, point)}')
        self.assertTrue(button.isVisible())
        self.assertEqual(button.width(), 19)

    def test_long_registered_names_keep_buttons_visible_at_minimum_width(self):
        names = ['Long_file_name_with_spaces_and_underscores_' * 5 + '.txt',
                 '長いファイル名_' * 10 + '.txt']
        for width in (180, 220):
            with self.subTest(width=width):
                self.write_preset(dict(self.data, ui_width=width,
                                       categories=[{'name': 'Files', 'items': []}]))
                window = self.window()
                window.toggle_edit_mode()
                paths = []
                for name in names:
                    path = self.root / name
                    path.write_text('synthetic', encoding='utf-8')
                    paths.append(str(path))
                self.assertTrue(window.register_external_paths(0, paths))
                panel = window.category_panels[0]
                panel.set_expanded(True, False)
                QTest.qWait(20)
                perf.drain()
                for row, name in zip(panel.rows, names):
                    self.assert_visible_button(window, row.menu_btn)
                    self.assertEqual(row.text_label.text(), name)
                    self.assertEqual(row.text_label.toolTip(), name)
                window.toggle_edit_mode()
                window.toggle_edit_mode()
                self.assertFalse(panel.expanded)
                panel.set_expanded(True, False)
                QTest.qWait(20)
                perf.drain()
                for row in panel.rows:
                    self.assert_visible_button(window, row.menu_btn)
                saved = json.loads((self.presets / 'test.json').read_text())
                self.assertEqual([item['name'] for item in saved['categories'][0]['items']], names)

    def test_actual_menu_click_deletes_only_the_selected_long_named_registration(self):
        names = ['VeryLongName_' * 40 + '.txt', '日本語の長い名前_' * 40 + '.txt']
        self.write_preset(dict(self.data, ui_width=180, categories=[{'name': 'Files', 'items': [
            {'name': name, 'type': 'file', 'path': str(self.file)} for name in names]}]))
        window = self.window()
        window.category_panels[0].set_expanded(True, False)
        window.toggle_edit_mode()
        QTest.qWait(20)
        button = window.category_panels[0].rows[1].menu_btn
        self.assert_visible_button(window, button)
        with patch.object(modern, 'QMenu', DeleteMenu):
            QTest.mouseClick(button, Qt.MouseButton.LeftButton)
        saved = json.loads((self.presets / 'test.json').read_text())
        self.assertEqual([item['name'] for item in saved['categories'][0]['items']], [names[0]])
        self.assertTrue(self.file.exists())

    def test_long_category_and_virtual_list_names_keep_both_menus_operable(self):
        title = '非常に長いカテゴリ名_' * 40
        names = ['Long_item_name_' * 20 + str(i) for i in range(201)]
        self.write_preset(dict(self.data, ui_width=180, categories=[{'name': title, 'items': [
            {'name': name, 'type': 'text', 'text': str(i)} for i, name in enumerate(names)]}]))
        window = self.window()
        panel = window.category_panels[0]
        panel.set_expanded(True, False)
        window.toggle_edit_mode()
        QTest.qWait(20)
        self.assert_visible_button(window, panel.category_menu_btn)
        self.assertEqual(panel.title_label.text(), title)
        self.assertEqual(panel.title_label.toolTip(), title)
        view = panel.virtual_list
        view.scrollToBottom()
        perf.drain()
        point = QPoint(view.viewport().width() - 10, view.visualRect(view.model().index(200)).center().y())
        self.assertTrue(window.category_scroll.viewport().rect().contains(
            view.viewport().mapTo(window.category_scroll.viewport(), point)))
        with patch.object(modern, 'QMenu', DeleteMenu):
            QTest.mouseClick(view.viewport(), Qt.MouseButton.LeftButton, pos=point)
        saved = json.loads((self.presets / 'test.json').read_text())
        self.assertEqual(saved['categories'][0]['name'], title)
        self.assertEqual([item['name'] for item in saved['categories'][0]['items']], names[:200])
        QTest.qWait(20)
        # Crossing the virtual-list threshold still leaves the ordinary row menus visible.
        self.assert_visible_button(window, window.category_panels[0].rows[0].menu_btn)


if __name__ == '__main__':
    unittest.main()
