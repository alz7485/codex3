"""Adobe PDF output through the verified Trial10g -PLOT macro.

This module intentionally follows the AutoCAD_PrintTest_Trial10g path that was
confirmed on the user's machine: Adobe PDF is treated as a printer, then the
PDF created by the Adobe driver is detected and moved to ACadPresetter's staged
PDF path.  It does not ask AutoCAD to PlotToFile through Adobe PDF.
"""
from __future__ import annotations

import os
import re
import shutil
import time
import tempfile
from pathlib import Path


def normalize_timeout(value):
    """Keep legacy/malformed config compatible; public setting is 30-600 seconds."""
    import math
    try:
        seconds = float(value)
        if not math.isfinite(seconds):
            raise ValueError('non-finite timeout')
        return max(30.0, min(600.0, seconds))
    except (ValueError, TypeError):
        return 120.0


def _add_dir(result: list[Path], value):
    if not value:
        return
    try:
        text=os.path.expandvars(os.path.expanduser(str(value).strip().strip('"')))
        p=Path(text)
        if p.suffix.lower()=='.pdf' or '*' in p.name:
            p=p.parent
        if p.exists() and p.is_dir():
            rp=p.resolve()
            if rp not in result:
                result.append(rp)
    except Exception:
        pass


def candidate_dirs(device: str, source_path: str | Path, staged_output: str | Path | None=None, log=None, preferred_dir: str | Path | None=None):
    log=log or (lambda _msg: None)
    dirs=[]
    src=Path(source_path)
    if preferred_dir:
        pref=Path(os.path.expandvars(os.path.expanduser(str(preferred_dir).strip().strip('"'))))
        if not pref.exists() or not pref.is_dir():
            raise RuntimeError(f'Adobe PDF生成先フォルダが存在しません: {pref}')
        # Trial10gで実機成功した経路: 明示指定がある場合はその1フォルダだけを監視する。
        # 複数候補を走査して別ジョブのPDFを拾うリスクをなくす。
        _add_dir(dirs,pref)
        return dirs
    try:_add_dir(dirs,src.resolve().parent)
    except Exception:_add_dir(dirs,src.parent)
    if staged_output:
        _add_dir(dirs,Path(staged_output).parent)
    home=Path.home()
    for d in (home/'Documents',home/'Desktop',home/'Downloads',
              Path(os.environ.get('TEMP','')),Path(os.environ.get('TMP','')),
              Path(os.environ.get('USERPROFILE',''))/'Documents'):
        _add_dir(dirs,d)
    for env in ('OneDrive','OneDriveCommercial','OneDriveConsumer'):
        root=os.environ.get(env)
        if root:
            _add_dir(dirs,Path(root)/'Documents')
            _add_dir(dirs,Path(root)/'Desktop')

    # Printer port may itself point at Adobe's auto-save folder.  A PC3 name is
    # not a Windows printer name, so also try plain "Adobe PDF".
    try:
        import win32print
        names=[]
        for name in (str(device or ''), re.sub(r'\.pc3$','',str(device or ''),flags=re.I), 'Adobe PDF'):
            if name and name.casefold() not in {x.casefold() for x in names}:
                names.append(name)
        for name in names:
            try:
                h=win32print.OpenPrinter(name)
                try:
                    info=win32print.GetPrinter(h,2)
                    port=info.get('pPortName','')
                    if port:
                        log(f'Adobe PDF Port = {port}')
                        _add_dir(dirs,port)
                finally:
                    win32print.ClosePrinter(h)
            except Exception:
                pass
    except Exception:
        pass

    # Adobe Distiller silent/default-output registry values, when configured.
    try:
        import winreg
        roots=(winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE)
        tracks=('DC','2020','2017','15.0','11.0')
        names=('SilentAdobePDFPrintFolder','DefaultPDFOutput')
        for root in roots:
            for track in tracks:
                for suffix in ('Preferences',''):
                    key_path=rf'SOFTWARE\Adobe\Acrobat Distiller\{track}'
                    if suffix:key_path+='\\'+suffix
                    try:
                        with winreg.OpenKey(root,key_path) as key:
                            for vn in names:
                                try:
                                    value,_=winreg.QueryValueEx(key,vn)
                                    if value:
                                        log(f'Adobe設定 {vn} = {value}')
                                        _add_dir(dirs,value)
                                except OSError:
                                    pass
                    except OSError:
                        pass
    except Exception:
        pass
    return dirs


def _pdf_files(folder):
    """Read actual names, including .PDF, and fail on inaccessible folders."""
    try:
        return [p for p in Path(folder).iterdir()
                if p.suffix.casefold() == '.pdf' and not p.is_symlink() and p.is_file()]
    except OSError as exc:
        raise RuntimeError(f'Adobe PDF生成先を読み取れません: {folder}\n{exc}') from exc


def snapshot_pdfs(dirs):
    result = {}
    for folder in dirs:
        for path in _pdf_files(folder):
            try:
                st = path.stat()
                result[str(path.resolve()).casefold()] = (st.st_mtime_ns, st.st_size)
            except FileNotFoundError:
                continue  # another process removed it during enumeration
    return result


def is_pdf(path: str | Path) -> bool:
    try:
        with Path(path).open('rb') as stream:
            return stream.read(5) == b'%PDF-'
    except OSError:
        return False


def _name_score(name: str, source_stem: str):
    """Accept only the exact DWG stem or an Adobe numeric collision suffix."""
    n = Path(name).stem.casefold()
    s = source_stem.casefold()
    if n == s + ' (1)':
        return 0
    if n == s:
        return 1
    if re.fullmatch(re.escape(s) + r' \([1-9]\d*\)', n):
        return 2
    return 99


def wait_for_generated_pdf(dirs, before, source_stem: str, started_at: float,
                           timeout: float = 120.0, log=None, keep_hidden=None):
    """Require one changed, stable, fully readable PDF for this drawing.

    A prefix match is never sufficient. Multiple matching changed files are
    ambiguous, even if one has the historical Trial10g '(1)' suffix.
    """
    from .pdf_output import PdfOutputSession
    log = log or (lambda _msg: None)
    deadline = time.monotonic() + timeout
    earliest = started_at - 2.0
    stable = {}
    rejected = set()
    while time.monotonic() < deadline:
        if keep_hidden:
            keep_hidden()
        candidates = []
        for folder in dirs:
            for path in _pdf_files(folder):
                if _name_score(path.name, source_stem) == 99:
                    continue
                try:
                    st = path.stat()
                    key = str(path.resolve()).casefold()
                    signature = (st.st_mtime_ns, st.st_size)
                    if before.get(key) == signature:
                        continue
                    if max(st.st_mtime, st.st_ctime) < earliest:
                        continue
                    candidates.append((path, key, signature))
                except FileNotFoundError:
                    continue
        if len(candidates) > 1:
            raise RuntimeError('Adobe PDF候補が複数あり、今回の出力を特定できません: '
                               + ', '.join(str(p) for p, _, _ in candidates))
        if candidates:
            path, key, signature = candidates[0]
            previous = stable.get(key)
            now = time.monotonic()
            if previous is None or previous[0] != signature:
                stable[key] = (signature, now)
            elif now - previous[1] >= 0.6 and signature[1] > 0:
                try:
                    if not is_pdf(path):
                        raise RuntimeError('PDFヘッダーがありません')
                    # Do not accept a header-only or partially written PDF.
                    PdfOutputSession.validate_pdf(path)
                    check = path.stat()
                    if (check.st_mtime_ns, check.st_size) != signature:
                        stable.pop(key, None)
                        continue
                    log(f'Adobe PDF検出・全ページ検証完了 = {path.name} ({check.st_size:,} bytes)')
                    return path
                except (RuntimeError, OSError) as exc:
                    rejection = (key, signature)
                    if rejection not in rejected:
                        log(f'Adobe PDFの完成待ち: {path.name} / {exc}')
                        rejected.add(rejection)
        else:
            stable.clear()
        time.sleep(min(0.2, max(0.0, deadline - time.monotonic())))
    return None


def _command_state(doc):
    from .autocad_backend import AutoCADUnsafeState
    try:
        active = int(doc.GetVariable('CMDACTIVE'))
        if active < 0:
            raise ValueError('CMDACTIVE < 0')
    except Exception as exc:
        raise AutoCADUnsafeState('AutoCADのコマンド状態を確認できません。次の図面へ進まず停止します。') from exc
    try:
        names = str(doc.GetVariable('CMDNAMES') or '')
    except Exception:
        names = ''  # CMDACTIVE is authoritative; CMDNAMES is diagnostic only
    return active, names


def _ensure_command_idle(doc, timeout=5.0, log=None, keep_hidden=None):
    from .autocad_backend import AutoCADUnsafeState
    log = log or (lambda _msg: None)
    active, names = _command_state(doc)
    if active == 0 and not names.strip():
        return
    log(f"前回コマンドが残っています: CMDACTIVE={active}, CMDNAMES={names or '(なし)'}")
    try:
        doc.SendCommand("\x1b\x1b")
    except Exception as exc:
        raise AutoCADUnsafeState(f'前回コマンドのキャンセルに失敗しました: {exc}') from exc
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if keep_hidden:
            keep_hidden()
        active, names = _command_state(doc)
        if active == 0 and not names.strip():
            log('コマンドラインを待機状態へ戻しました')
            return
        time.sleep(0.1)
    raise AutoCADUnsafeState(f"AutoCADのコマンドラインを待機状態へ戻せませんでした。\nCMDACTIVE={active}, CMDNAMES={names or '(なし)'}")


def _wait_macro_complete(doc, started_at, timeout=45.0, log=None, keep_hidden=None):
    from .autocad_backend import AutoCADUnsafeState
    log = log or (lambda _msg: None)
    begun = time.monotonic()
    deadline = begun + timeout
    saw_active = False
    idle_since = None
    last_state = None
    while time.monotonic() < deadline:
        if keep_hidden:
            keep_hidden()
        active, names = _command_state(doc)
        state = (active, names)
        if state != last_state:
            log(f"コマンド状態: CMDACTIVE={active}, CMDNAMES={names or '(なし)'}")
            last_state = state
        now = time.monotonic()
        if active or names.strip():
            saw_active = True
            idle_since = None
        else:
            if idle_since is None:
                idle_since = now
            if now - idle_since >= 0.3 and (saw_active or now - begun >= 2.0):
                return
        time.sleep(0.12)
    active, names = _command_state(doc)
    raise AutoCADUnsafeState(
        '-PLOTマクロが時間内に終了しませんでした。\n'
        f"CMDACTIVE={active}, CMDNAMES={names or '(なし)'}\n"
        '保存確認や入力待ちの可能性があります。後続図面は停止します。'
    )


def finalize_generated_pdf(generated: str | Path, staged_output: str | Path,
                           log=None, *, remove_generated=False, timeout=5.0):
    from .pdf_output import PdfOutputSession
    log = log or (lambda _msg: None)
    generated = Path(generated).resolve()
    out = Path(staged_output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    if generated == out:
        PdfOutputSession.validate_pdf(out)
        return out
    fd, temporary = tempfile.mkstemp(prefix='.' + out.name + '.', suffix='.adobe_tmp', dir=out.parent)
    os.close(fd)
    tmp = Path(temporary)
    deadline = time.monotonic() + timeout
    try:
        while True:
            try:
                first = generated.stat()
                shutil.copy2(generated, tmp)
                last = generated.stat()
                signature = (last.st_size, last.st_mtime_ns, last.st_ctime_ns)
                if signature != (first.st_size, first.st_mtime_ns, first.st_ctime_ns):
                    raise OSError('Adobe PDFがコピー中に更新されました')
                if tmp.stat().st_size != last.st_size:
                    raise OSError('Adobe生成PDFのコピーサイズが一致しません')
                PdfOutputSession.validate_pdf(tmp)
                break
            except OSError as exc:
                if time.monotonic() >= deadline:
                    raise RuntimeError(f'Adobe PDFを取り込めません。生成元は保持しています: {generated}\n{exc}') from exc
                time.sleep(0.2)
        os.replace(tmp, out)
        PdfOutputSession.validate_pdf(out)
        # Existing user PDFs are never deleted. Delete only a newly created,
        # unchanged driver output after the staged copy has been validated.
        if remove_generated:
            try:
                current = generated.stat()
                if (current.st_size, current.st_mtime_ns, current.st_ctime_ns) == signature:
                    generated.unlink()
                else:
                    log(f'生成元が更新されたため保持しました: {generated}')
            except OSError as exc:
                log(f'Adobe生成元PDFを保持しました: {exc}')
        return out
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def plot_to_device_pdf(doc, staged_output: str | Path, device: str, *, log=None, keep_hidden=None, timeout: float=120.0, preferred_dir: str | Path | None=None):
    """Trial10g実機成功経路をそのまま使う。

    Adobe PDFは通常プリンターとして ``_.-PLOT`` / SendCommand で印刷し、
    指定されたAdobe生成先の元名・数値連番PDFを厳密に照合する。
    ``PlotToFile`` は使用しない。
    """
    log=log or (lambda _msg: None)
    source=str(getattr(doc,'FullName','') or getattr(doc,'Name','') or '')
    stem=Path(source).stem or Path(staged_output).stem
    if not preferred_dir:
        raise RuntimeError(
            'Adobe PDF生成先が未設定です。\n'
            'Trial10gと同じ方式では、Adobe PDFプリンターで指定している自動保存先フォルダを設定してください。'
        )
    watch_dir=Path(os.path.expandvars(os.path.expanduser(str(preferred_dir).strip().strip('"')))).resolve()
    if not watch_dir.exists() or not watch_dir.is_dir():
        raise RuntimeError(f'Adobe PDF生成先フォルダが存在しません: {watch_dir}')

    try: layout=doc.ActiveLayout
    except Exception as exc: raise RuntimeError('印刷対象レイアウトを取得できません。') from exc
    layout_name=str(getattr(layout,'Name','') or '')
    config=str(getattr(layout,'ConfigName','') or device or '')
    if 'adobe' not in config.casefold() or 'pdf' not in config.casefold():
        raise RuntimeError(f'適用後の出力機器がAdobe PDFではありません: {config}')

    try: doc.SetVariable('BACKGROUNDPLOT',0)
    except Exception as exc: raise RuntimeError('同期印刷を設定できないためAdobe PDF出力を停止します。') from exc
    try: doc.ActiveLayout=layout
    except Exception as exc: raise RuntimeError(f'印刷対象レイアウトをアクティブにできません: {layout_name}\n{exc}') from exc

    if not layout_name or any(c in layout_name for c in '\r\n\x00'):
        raise RuntimeError('印刷対象レイアウト名が不正です。')
    log(f'Adobe PDF監視先: {watch_dir} / 図面: {stem} / Layout: {layout_name}')
    _ensure_command_idle(doc,timeout=5.0,log=log,keep_hidden=keep_hidden)
    expected=watch_dir/f'{stem} (1).pdf'
    if expected.exists():
        log(f'注意: 印刷前から検出対象が存在します: {expected.name}。更新日時・サイズが変化した場合だけ新規生成として扱います。')
    before=snapshot_pdfs([watch_dir])
    started=time.time()

    # Trial10g default route exactly:
    # Detailed plot configuration=N / Layout=explicit / Page setup=Enter /
    # Output device=Enter(current Adobe PDF) / Write plot to a file=N /
    # Save changes=N / Proceed=Y
    macro='\n'.join(['_.-PLOT','_N',layout_name,'','','_N','_N','_Y'])+'\n'
    log('Adobe PDF印刷開始: SendCommand / _.-PLOT')
    log('マクロ: 詳細設定=N / 現在のページ設定・出力デバイス / ファイル出力=N / 保存=N / 実行=Y')
    if keep_hidden: keep_hidden()
    try: doc.SendCommand(macro)
    except Exception as exc: raise RuntimeError(f'-PLOTマクロ送信に失敗しました: {exc}') from exc
    _wait_macro_complete(doc,started,timeout=45.0,log=log,keep_hidden=keep_hidden)
    active,last_cmd=_command_state(doc)
    log(f"-PLOTコマンド終了待ち完了: CMDACTIVE={active}, CMDNAMES={last_cmd or '(なし)'}")

    generated=wait_for_generated_pdf([watch_dir],before,stem,started,timeout=timeout,log=log,keep_hidden=keep_hidden)
    if generated is None:
        from .autocad_backend import AutoCADUnsafeState
        active,last_cmd=_command_state(doc)
        observed=', '.join(p.name for p in _pdf_files(watch_dir) if _name_score(p.name,stem)!=99) or '(なし)'
        raise AutoCADUnsafeState(
            'マクロ印刷後、指定フォルダ内で新しい正常PDFを検出できませんでした。\n\n'
            f'監視フォルダ: {watch_dir}\n'
            f'検出対象: {stem}.pdf / {stem} (数字).pdf（新規・更新のみ）\n'
            f'同名候補: {observed}\n'
            f'待機時間: {timeout:g}秒\n'
            f"CMDNAMES: {last_cmd or '(なし)'}\n"
            'Adobe PDFの自動保存先を指定し、保存確認・PDFの自動表示をOFFにしてください。'
            '未完了ジョブとの混同を避けるため後続図面は停止します。'
        )
    log(f'Adobe PDF生成ファイル検出 = {generated.name}')
    return finalize_generated_pdf(generated,staged_output,log=log,
                                  remove_generated=str(generated.resolve()).casefold() not in before)

