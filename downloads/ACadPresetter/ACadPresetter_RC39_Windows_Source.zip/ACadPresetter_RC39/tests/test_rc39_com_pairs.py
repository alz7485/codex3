from array import array
from types import SimpleNamespace
import sys
import pytest

from app import autocad_backend as backend
from app.plot_settings import validate_plot_values


class Variant:
    def __init__(self, kind, value):
        self.varianttype = kind
        self.value = value


@pytest.fixture
def com_types(monkeypatch):
    constants = SimpleNamespace(VT_ARRAY=0x2000, VT_R8=5, VT_BYREF=0x4000, VT_VARIANT=12)
    client = SimpleNamespace(VARIANT=Variant)
    monkeypatch.setitem(sys.modules, 'pythoncom', constants)
    monkeypatch.setitem(sys.modules, 'win32com', SimpleNamespace(client=client))
    monkeypatch.setitem(sys.modules, 'win32com.client', client)
    return constants


def test_plot_origin_is_explicit_safearray_double_as_in_successful_reference(com_types):
    calls = []
    class Layout:
        @property
        def PlotOrigin(self):
            return calls[-1].value
        @PlotOrigin.setter
        def PlotOrigin(self, value):
            assert isinstance(value, Variant), 'two values require an explicit COM variant'
            assert value.varianttype == com_types.VT_ARRAY | com_types.VT_R8
            assert value.value == (2.5, 4.0)
            calls.append(value)
    backend._set_plot_origin(Layout(), (2.5,4))
    assert len(calls) == 1


def test_dynamic_window_setter_falls_back_to_two_double_safearrays(com_types):
    calls = []
    class Layout:
        def SetWindowToPlot(self, lower, upper):
            calls.append((lower,upper))
            if not isinstance(lower,Variant):
                raise TypeError('two values cannot be converted automatically')
            assert lower.varianttype == upper.varianttype == com_types.VT_ARRAY | com_types.VT_R8
            assert lower.value == (1.0,2.0) and upper.value == (3.0,4.0)
    backend._set_window_points(Layout(),(1,2),(3,4))
    assert len(calls) == 2


def test_dynamic_window_reader_supports_byref_outputs(com_types):
    def get_window(*args):
        if not args: raise TypeError('requires two output arguments')
        lower,upper = args
        assert lower.varianttype == upper.varianttype == com_types.VT_BYREF | com_types.VT_VARIANT
        lower.value = array('d',[1,2])
        upper.value = (3,4)
    assert backend._get_window_points(SimpleNamespace(GetWindowToPlot=get_window)) == ((1.0,2.0),(3.0,4.0))


@pytest.mark.parametrize('returns', [False,True])
def test_custom_scale_reads_byref_double_or_return_pair(com_types,returns):
    def getter(*args):
        if not args: raise TypeError('requires two output arguments')
        numerator,denominator=args
        assert numerator.varianttype == denominator.varianttype == com_types.VT_BYREF | com_types.VT_R8
        if returns: return (2.0,75.0)
        numerator.value=2.0;denominator.value=75.0
    assert backend._get_custom_scale(SimpleNamespace(GetCustomScale=getter)) == (2.0,75.0)


@pytest.mark.parametrize('value', [(1,2),array('d',[1,2]),Variant(0,(1,2)),'1 : 2'])
def test_custom_scale_accepts_two_value_containers(value):
    assert backend._coerce_custom_scale(value) == (1.0,2.0)


@pytest.mark.parametrize('value', [(1,),(1,2,3),(1,float('nan')),(float('inf'),2),(0,2),'1 : 2 : 3'])
def test_invalid_scale_is_rejected_instead_of_guessed(value):
    with pytest.raises((ValueError,TypeError)):
        backend._coerce_custom_scale(value)


@pytest.mark.parametrize('lower,upper', [((1,2),(0,3)),((0,0),(1,float('nan')))])
def test_bad_window_never_reaches_com(lower,upper):
    calls=[]
    with pytest.raises(ValueError):
        backend._set_window_points(SimpleNamespace(SetWindowToPlot=lambda *p:calls.append(p)),lower,upper)
    assert not calls


def test_preflight_rejects_invalid_geometry_and_custom_scale_despite_stale_fit_flag():
    base={'device':'Adobe PDF','paper':'A4','plot_area':'窓','window_x1':5,'window_y1':0,
          'window_x2':1,'window_y2':2,'scale_mode':'custom','fit_to_paper':True,
          'scale_num':float('nan'),'scale_den':1,'offset_x':float('inf')}
    issues=validate_plot_values(base)
    assert any('範囲' in x for x in issues)
    assert any('尺度' in x for x in issues)
    assert any('原点' in x for x in issues)


def test_two_value_com_conversion_then_adobe_pdf_pipeline_and_restore(tmp_path,monkeypatch,com_types):
    """Reproduce a driver that rejects implicit coordinate pairs, then plot."""
    from unittest.mock import Mock
    from pdf_fixtures import write_pdf
    from app import adobe_device_output as adobe

    class Layout:
        Name='Model'; ConfigName='old.pc3'; CanonicalMediaName='A4'; StyleSheet=''
        PlotType=4; PlotRotation=0; PaperUnits=1; CenterPlot=False
        UseStandardScale=False; StandardScale=0
        PlotWithLineweights=True; PlotWithPlotStyles=True; PlotTransparency=False
        def __init__(self):
            self.origin=(0.0,0.0); self.window=((0.0,0.0),(10.0,10.0)); self.scale=(1.0,25.0)
        @property
        def PlotOrigin(self): return self.origin
        @PlotOrigin.setter
        def PlotOrigin(self,value):
            if not isinstance(value,Variant):
                raise TypeError('cannot convert the two values to a Double SAFEARRAY')
            self.origin=value.value
        def RefreshPlotDeviceInfo(self): pass
        def GetCanonicalMediaNames(self): return ['A4']
        def GetLocaleMediaName(self,name): return name
        def SetWindowToPlot(self,lower,upper):
            if not isinstance(lower,Variant): raise TypeError('two points require typed variants')
            self.window=(lower.value,upper.value)
        def GetWindowToPlot(self,*args):
            if not args: raise TypeError('requires two output arguments')
            args[0].value,args[1].value=self.window
        def GetCustomScale(self,*args):
            if not args: raise TypeError('requires two output arguments')
            args[0].value,args[1].value=self.scale
        def SetCustomScale(self,numerator,denominator): self.scale=(numerator,denominator)

    layout=Layout();source=tmp_path/'sheet.dwg';source.touch();out=tmp_path/'stage'/'sheet.pdf'
    settings={'device':'Adobe PDF','paper':'A4','plot_area':'窓','center_plot':False,
              'window_x1':1,'window_y1':2,'window_x2':3,'window_y2':4,
              'offset_x':2.5,'offset_y':4,'scale_mode':'custom','fit_to_paper':False,
              'scale_num':2,'scale_den':75,'paper_units':1}
    variables={'BACKGROUNDPLOT':2,'CMDACTIVE':0,'CMDNAMES':''}
    commands=[]
    def send(command):
        assert layout.origin==(2.5,4.0)
        assert layout.scale==(2.0,75.0)
        assert layout.window==((1.0,2.0),(3.0,4.0))
        commands.append(command)
        write_pdf(tmp_path/'sheet (2).pdf')
    doc=SimpleNamespace(FullName=str(source),ActiveLayout=layout,GetVariable=lambda k:variables[k],
                        SetVariable=lambda k,v:variables.update({k:v}),SendCommand=send,Close=Mock())
    monkeypatch.setattr(backend,'_open_for_session',lambda *args:(doc,True))
    session=SimpleNamespace(app=object(),options={'adobe_pdf_watch_dir':str(tmp_path)})
    results=backend.plot_batch_pdf([{'source':str(source),'output':str(out),'settings':settings}],session=session)
    assert results[0]['status']=='ok',results
    assert any('全ページ検証完了' in line for line in results[0]['trace'])
    assert out.exists() and len(commands)==1
    assert layout.ConfigName=='old.pc3' and layout.origin==(0.0,0.0)
    assert layout.scale==(1.0,25.0) and layout.window==((0.0,0.0),(10.0,10.0))
    assert variables['BACKGROUNDPLOT']==2
    doc.Close.assert_called_once_with(False)
