import json
from datetime import datetime, timedelta
from pathlib import Path
from .store import _atomic_json_write

class OutputLogger:
    def __init__(self, data_dir, config):
        self.dir = Path(data_dir) / "logs"
        self.enabled = bool(config.get("log_enabled", True))
        self.retention = max(1, int(config.get("log_retention_days", 30)))

    def cleanup(self):
        if not self.enabled or not self.dir.exists(): return
        cutoff = datetime.now() - timedelta(days=self.retention)
        for p in self.dir.glob("output_*.json"):
            try:
                if datetime.fromtimestamp(p.stat().st_mtime) < cutoff: p.unlink()
            except OSError: pass

    def write(self, record):
        if not self.enabled: return None
        self.dir.mkdir(parents=True, exist_ok=True); self.cleanup()
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        path=self.dir/f"output_{stamp}.json"
        _atomic_json_write(path,record)
        return path
