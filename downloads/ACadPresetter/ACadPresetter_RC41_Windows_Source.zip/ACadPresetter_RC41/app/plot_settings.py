"""Canonical plot-preset normalization used by UI, JSON, preflight and AutoCAD backend."""

import math

PLOT_AREAS = ("レイアウト", "窓", "図形範囲", "表示範囲", "図面範囲")
ORIENTATIONS = ("縦", "横")


def normalize_plot_settings(raw):
    s = dict(raw or {})
    s.setdefault("setting_method", "プリセットを適用")
    s.setdefault("output", "PDF")
    s.setdefault("device", "")
    s.setdefault("paper", "")
    s.setdefault("plot_style", "")
    s.setdefault("plot_area", "レイアウト")
    s.setdefault("fit_to_paper", True)
    # RC34: preserve the exact AutoCAD scale mode when settings were imported.
    # scale_mode is "fit", "standard", "custom" or None for legacy presets.
    s.setdefault("scale_mode", None)
    s.setdefault("standard_scale_index", None)
    s.setdefault("use_standard_scale", None)
    s.setdefault("paper_units", None)
    s.setdefault("center_plot", True)
    # RC33: missing CustomScale values must stay unknown.  In particular,
    # legacy presets with UseStandardScale=OFF/fit_to_paper=False may not have
    # scale_num/scale_den at all.  Defaulting those keys to 1:1 would silently
    # change the print scale.
    s.setdefault("scale_num", None)
    s.setdefault("scale_den", None)
    s.setdefault("offset_x", 0.0)
    s.setdefault("offset_y", 0.0)
    s.setdefault("window_x1", None)
    s.setdefault("window_y1", None)
    s.setdefault("window_x2", None)
    s.setdefault("window_y2", None)
    s.setdefault("lineweights", True)
    s.setdefault("transparency", False)
    s.setdefault("plot_styles", True)
    s.setdefault("copies", 1)
    # RC37: optional PDF-only post-processing. Existing presets stay OFF.
    s.setdefault("rotate_a3_a1_landscape", False)

    # Step47 and earlier exposed both orientation and rotation.  The product
    # specification has one user-facing direction.  Preserve old JSON by
    # deriving direction from the old rotation when direction is absent/auto.
    orientation = str(s.get("orientation", "") or "")
    rotation = str(s.get("rotation", "") or "")
    if orientation not in ORIENTATIONS:
        orientation = "横" if rotation in ("90°", "270°") else "縦"
    s["orientation"] = orientation
    # Preserve the exact AutoCAD PlotRotation when it is compatible with the
    # user-facing direction.  180°/270° are not equivalent to 0°/90° for
    # drawings whose title block orientation matters, even though both map to
    # the same portrait/landscape label.  Only canonicalize inconsistent or
    # missing legacy data.
    valid_rotations = {"0°", "90°", "180°", "270°"}
    if rotation not in valid_rotations:
        rotation = "90°" if orientation == "横" else "0°"
    elif orientation == "横" and rotation not in ("90°", "270°"):
        rotation = "90°"
    elif orientation == "縦" and rotation not in ("0°", "180°"):
        rotation = "0°"
    s["rotation"] = rotation
    return s


def validate_plot_values(raw):
    s = normalize_plot_settings(raw)
    issues = []
    if s.get("setting_method") == "DWG/DXFに保存されている設定を使用":
        return issues
    if not str(s.get("device", "")).strip():
        issues.append("プリンター / PC3が未設定です。")
    if not str(s.get("paper", "")).strip():
        issues.append("用紙が未設定です。")
    if s.get("plot_area") not in PLOT_AREAS:
        issues.append("印刷範囲が不正です。")
    if s.get("plot_area")=="窓":
        try:
            vals=[float(s.get(k)) for k in ("window_x1","window_y1","window_x2","window_y2")]
            if not all(math.isfinite(v) for v in vals) or vals[2]<=vals[0] or vals[3]<=vals[1]:
                issues.append("窓の印刷範囲が不正です。")
        except Exception:
            issues.append("窓の印刷範囲座標がありません。DWG/DXFから取得し直してください。")
    if s.get("scale_mode") == "custom" or (s.get("scale_mode") is None and not s.get("fit_to_paper", True)):
        num=s.get("scale_num"); den=s.get("scale_den")
        # Both blank/None is a supported Trial10g-compatible state meaning
        # "CustomScale could not be read; preserve the target layout value".
        if num in (None,"") and den in (None,""):
            pass
        elif num in (None,"") or den in (None,""):
            issues.append("尺度は分子・分母の両方を指定してください。")
        else:
            try:
                if not all(math.isfinite(float(v)) and float(v)>0 for v in (num,den)):
                    issues.append("尺度は0より大きい値にしてください。")
            except Exception:
                issues.append("尺度が不正です。")
    for key in ("offset_x", "offset_y"):
        try:
            if not math.isfinite(float(s.get(key,0))): raise ValueError(key)
        except (ValueError, TypeError):
            issues.append("印刷原点には有限の数値を指定してください。")
            break
    return issues
