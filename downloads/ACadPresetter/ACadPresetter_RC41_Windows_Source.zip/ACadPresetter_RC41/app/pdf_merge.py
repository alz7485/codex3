"""Validated PDF merging without holding Windows source-file locks."""
from io import BytesIO
from pathlib import Path
import tempfile
import os

from .pdf_output import PdfOutputSession


def merge_pdfs(inputs, output):
    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError as exc:
        raise RuntimeError('PDF結合には pypdf が必要です。') from exc
    paths = [Path(p) for p in inputs]
    if not paths:
        raise ValueError('結合元PDFがありません。')
    missing = [str(p) for p in paths if not p.is_file()]
    if missing:
        raise RuntimeError('結合元PDFがありません:\n' + '\n'.join(missing))
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + out.name + '.', suffix='.merge_tmp', dir=out.parent)
    os.close(fd)
    tmp = Path(temporary)
    writer = PdfWriter()
    try:
        expected_pages = 0
        for path in paths:
            PdfOutputSession.validate_pdf(path)
            reader = PdfReader(BytesIO(path.read_bytes()), strict=True)
            if not expected_pages and reader.metadata:
                writer.add_metadata({str(k): str(v) for k, v in reader.metadata.items() if v is not None})
            expected_pages += len(reader.pages)
            writer.append(reader, import_outline=True)
        with tmp.open('wb') as stream:
            writer.write(stream)
        PdfOutputSession.validate_pdf(tmp)
        check = PdfReader(BytesIO(tmp.read_bytes()), strict=True)
        if len(check.pages) != expected_pages:
            raise RuntimeError('結合PDFのページ数が一致しません。')
        os.replace(tmp, out)
        PdfOutputSession.validate_pdf(out)
    finally:
        writer.close()
        tmp.unlink(missing_ok=True)
    return str(out)
