from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any
from uuid import uuid4

def new_id(prefix: str = "id") -> str:
    return f"{prefix}_{uuid4().hex}"

@dataclass
class DrawingItem:
    path: str
    manual_plot_id: str | None = None
    id: str = field(default_factory=lambda: new_id("item"))
    absolute_path: str = ""
    relative_path: str = ""
    def to_dict(self): return {"type":"file", **asdict(self)}
    @classmethod
    def from_dict(cls,data):
        return cls(path=str(data.get("path","")),manual_plot_id=data.get("manual_plot_id"),id=str(data.get("id") or new_id("item")),
                   absolute_path=str(data.get("absolute_path", "")),relative_path=str(data.get("relative_path", "")))

@dataclass
class DrawingGroup:
    name: str
    items: list[DrawingItem] = field(default_factory=list)
    id: str = field(default_factory=lambda: new_id("group"))
    def to_dict(self): return {"type":"group","id":self.id,"name":self.name,"items":[x.to_dict() for x in self.items]}
    @classmethod
    def from_dict(cls,data):
        return cls(name=str(data.get("name") or "新規グループ1"),items=[DrawingItem.from_dict(x) for x in data.get("items",[]) if isinstance(x,dict)],id=str(data.get("id") or new_id("group")))

@dataclass
class DrawingList:
    # groups/loose_items are retained for Step27 API compatibility.
    groups: list[DrawingGroup] = field(default_factory=list)
    loose_items: list[DrawingItem] = field(default_factory=list)
    collection_id: str|None = None
    version: int = 2
    next_group_number: int = 1
    entries: list[DrawingItem|DrawingGroup] = field(default_factory=list)
    base_folder: str = ""
    base_relative_to_list: str | None = None
    saved_list_folder: str = ""
    def __post_init__(self):
        if not self.entries and (self.groups or self.loose_items):
            self.entries=[*self.groups,*self.loose_items]
        elif self.entries:
            self.groups=[x for x in self.entries if isinstance(x,DrawingGroup)]
            self.loose_items=[x for x in self.entries if isinstance(x,DrawingItem)]
    def to_dict(self):
        return {"format":"ACadPresetter.acplist","schema_version":3,"version":self.version,"collection_id":self.collection_id,"next_group_number":self.next_group_number,"entries":[x.to_dict() for x in self.entries],
                "base_folder":self.base_folder,"base_relative_to_list":self.base_relative_to_list,"saved_list_folder":self.saved_list_folder}
    @classmethod
    def from_dict(cls,data):
        if int(data.get("schema_version",0))>3 or int(data.get("version",1))>3:
            raise ValueError("この.acplistは新しい形式です。対応するACadPresetterで開いてください。")
        raw=data.get("entries")
        if raw is None:
            raw=[]
            raw.extend({"type":"group",**x} for x in data.get("groups",[]) if isinstance(x,dict))
            raw.extend({"type":"file",**x} for x in data.get("loose_items",[]) if isinstance(x,dict))
        entries=[]
        for x in raw:
            if not isinstance(x,dict):continue
            entries.append(DrawingGroup.from_dict(x) if x.get("type")=="group" else DrawingItem.from_dict(x))
        return cls(collection_id=data.get("collection_id"),version=max(2,int(data.get("version",1))),next_group_number=max(1,int(data.get("next_group_number",1) or 1)),entries=entries,
                   base_folder=str(data.get("base_folder", "")),base_relative_to_list=data.get("base_relative_to_list"),saved_list_folder=str(data.get("saved_list_folder", "")))

def next_group_name(existing_names:list[str])->str:
    used={str(x).replace("📚","").strip() for x in existing_names}; n=1
    while f"新規グループ{n}" in used:n+=1
    return f"新規グループ{n}"

def normalized_path(value:str)->str:return str(Path(value).expanduser())
