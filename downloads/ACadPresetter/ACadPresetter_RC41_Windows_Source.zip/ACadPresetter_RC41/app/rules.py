import re


def _target_name(filename):
    s = str(filename).replace('\\', '/').rsplit('/', 1)[-1]
    return s.rsplit('.', 1)[0] if '.' in s else s


def _single_match(filename, r, case_sensitive=False):
    s = _target_name(filename)
    v = str(r.get('value', ''))
    mode = r.get('mode', '含む')
    cs = bool(r.get('case_sensitive', case_sensitive))
    if mode == '正規表現':
        try:
            return re.search(v, s, 0 if cs else re.IGNORECASE) is not None
        except re.error:
            return False
    a, b = (s, v) if cs else (s.casefold(), v.casefold())
    if mode == '含む': return b in a
    if mode == '含まない': return b not in a
    if mode == '先頭一致': return a.startswith(b)
    if mode == '末尾一致': return a.endswith(b)
    if mode == '完全一致': return a == b
    return False


def validate_rule(r):
    for c in r.get('conditions') or [r]:
        if c.get('mode') == '正規表現':
            try: re.compile(str(c.get('value', '')))
            except re.error as e: return False, str(e)
    return True, ''


def match_rule(filename, r):
    conds = r.get('conditions')
    if not conds:
        return _single_match(filename, r, r.get('case_sensitive', False))
    vals = [_single_match(filename, c, r.get('case_sensitive', False)) for c in conds]
    return all(vals) if r.get('relation', 'AND') == 'AND' else any(vals)


def resolve_file_detail(filename, col, data):
    """Resolve a collection assignment in display priority order.

    The first matching pair wins.  This function is the single source of truth
    used by both the list UI and output execution so that their decisions cannot
    drift apart.
    """
    if not col:
        return {"rule": None, "plot": None, "source": "none", "priority": None}
    rules = {x.get('id'): x for x in data.get('rule', [])}
    plots = {x.get('id'): x for x in data.get('plot', [])}
    for priority, pair in enumerate(col.get('pairs', []), 1):
        r = rules.get(pair.get('rule_id')); p = plots.get(pair.get('plot_id'))
        if r and p and match_rule(filename, r):
            return {"rule": r, "plot": p, "source": "rule", "priority": priority}
    fallback = plots.get(col.get('default_plot_id'))
    if fallback:
        return {"rule": None, "plot": fallback, "source": "default", "priority": None}
    return {"rule": None, "plot": None, "source": "none", "priority": None}


def resolve_file(filename, col, data):
    result = resolve_file_detail(filename, col, data)
    return result["rule"], result["plot"]
