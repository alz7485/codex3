from __future__ import annotations

from io import BytesIO
from pathlib import Path
import os
import uuid


_MM_PER_INCH = 25.4
_PT_PER_INCH = 72.0

# ISO 216 nominal dimensions (short side, long side) in millimetres.
_TARGET_SIZES_MM = {
    "A3": (297.0, 420.0),
    "A1": (594.0, 841.0),
}


def _pt_to_mm(value: float) -> float:
    return float(value) * _MM_PER_INCH / _PT_PER_INCH


def _page_size_mm(page) -> tuple[float, float]:
    box = page.mediabox
    return abs(_pt_to_mm(float(box.width))), abs(_pt_to_mm(float(box.height)))


def _iso_size_name(width_mm: float, height_mm: float, tolerance_mm: float = 5.0) -> str | None:
    short, long = sorted((float(width_mm), float(height_mm)))
    for name, (want_short, want_long) in _TARGET_SIZES_MM.items():
        if abs(short - want_short) <= tolerance_mm and abs(long - want_long) <= tolerance_mm:
            return name
    return None


def _effective_is_portrait(page) -> bool:
    """Return the orientation as a PDF viewer will display the page."""
    width_mm, height_mm = _page_size_mm(page)
    rotation = int(getattr(page, "rotation", 0) or 0) % 360
    if rotation in (90, 270):
        width_mm, height_mm = height_mm, width_mm
    return height_mm > width_mm


def rotate_a3_a1_left_to_landscape(path: str | Path) -> list[dict]:
    """Rotate portrait A3/A1 pages 90 degrees left, in-place and safely.

    Only pages whose MediaBox is approximately ISO A3 or A1 are candidates.
    Pages already displayed landscape are left untouched.  A left rotation is
    represented as +270 degrees in the PDF /Rotate entry.

    The input and validation PDFs are loaded through BytesIO so no source/temp
    file handle remains open when ``os.replace`` runs.  This matters on Windows,
    where replacing an open PDF can fail even though the same code works on Linux.
    The writer clones the full reader catalog rather than rebuilding from pages,
    preserving AutoCAD PDF metadata, outlines and catalog-level information.

    Returns one record per rotated page, e.g. [{"page": 1, "size": "A3"}].
    """
    try:
        from pypdf import PdfReader, PdfWriter
    except Exception as exc:  # pragma: no cover - deployment dependency
        raise RuntimeError("PDF回転には pypdf が必要です。") from exc

    src = Path(path)
    if not src.exists():
        raise FileNotFoundError(str(src))

    # Do not let PdfReader own an OS file handle to src. On Windows that can
    # prevent the atomic replacement at the end of this function.
    reader = PdfReader(BytesIO(src.read_bytes()), strict=True)
    if reader.is_encrypted:
        raise RuntimeError("暗号化PDFは自動回転できません。")

    original_page_count = len(reader.pages)
    # clone_from preserves the document catalog (metadata/outlines/OCProperties)
    # whereas add_page() alone only carries page-level objects.
    writer = PdfWriter(clone_from=reader)
    rotated: list[dict] = []
    for index, page in enumerate(writer.pages, start=1):
        width_mm, height_mm = _page_size_mm(page)
        size_name = _iso_size_name(width_mm, height_mm)
        if size_name and _effective_is_portrait(page):
            # pypdf's rotate() is clockwise-positive. +270 == left 90.
            page.rotate(270)
            rotated.append({"page": index, "size": size_name})

    if not rotated:
        try:
            writer.close()
        except Exception:
            pass
        return []

    tmp = src.with_name(f".{src.name}.rotate_{uuid.uuid4().hex[:8]}.tmp")
    try:
        with tmp.open("wb") as fh:
            writer.write(fh)
        try:
            writer.close()
        except Exception:
            pass

        # Validate from bytes as well, so the temp path is not held open during
        # os.replace on Windows.
        check = PdfReader(BytesIO(tmp.read_bytes()), strict=True)
        if check.is_encrypted:
            raise RuntimeError("PDF回転後のファイルが暗号化されています。")
        if len(check.pages) != original_page_count:
            raise RuntimeError("PDF回転後のページ数が一致しません。")
        # Resolve each page before replacement to catch malformed output now.
        for page in check.pages:
            _ = page.mediabox
            contents = page.get_contents()
            if contents is not None:
                contents.get_data()
        os.replace(tmp, src)
    finally:
        try:
            writer.close()
        except Exception:
            pass
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass
    return rotated
