from __future__ import annotations

import re
from pathlib import Path

CAD_EXTENSIONS = {'.dwg', '.dxf'}


def natural_path_key(path):
    name = Path(path).name
    return [int(x) if x.isdigit() else x.casefold() for x in re.split(r'(\d+)', name)]


def classify_external_drop(paths):
    """Classify Explorer drop input without recursively scanning folders.

    Returns (folders, direct_files). Unsupported/missing paths are ignored.
    Input order of folders is retained; direct files use natural-name order.
    """
    folders = []
    direct = []
    for raw in paths:
        p = Path(raw)
        if p.is_dir():
            folders.append(p)
        elif p.is_file() and p.suffix.lower() in CAD_EXTENSIONS:
            direct.append(p)
    return folders, sorted(direct, key=natural_path_key)


def direct_cad_children(folder):
    """Return only DWG/DXF files directly below folder, never descendants."""
    folder = Path(folder)
    if not folder.is_dir():
        return []
    return sorted(
        (p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in CAD_EXTENSIONS),
        key=natural_path_key,
    )


def normalize_drop_group_mode(value):
    """Normalize old/current config labels to ask/group/individual."""
    mapping = {
        'ask': 'ask', '確認する': 'ask',
        'group': 'group', 'always': 'group', '常にグループ化': 'group', '自動で1グループにする': 'group',
        'individual': 'individual', '個別に追加': 'individual', '個別に追加する': 'individual',
    }
    return mapping.get(str(value or '').strip(), 'ask')
