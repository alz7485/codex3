import re
from pathlib import Path

TOKEN_TYPES = ("*", "数字", "英字", "大文字", "小文字", "英数字")


def _length_quantifier(spec: str, default: str) -> str:
    spec = str(spec or "").strip()
    if not spec:
        return default
    if re.fullmatch(r"[1-9]\d*", spec):
        return "{" + str(int(spec)) + "}"
    m = re.fullmatch(r"([1-9]\d*)-([1-9]\d*)", spec)
    if not m:
        raise ValueError("文字数は 3 または 2-5 の形式で指定してください。")
    lo, hi = int(m.group(1)), int(m.group(2))
    if lo > hi:
        raise ValueError("文字数範囲は最小値を最大値以下にしてください。")
    return "{" + f"{lo},{hi}" + "}"


def _compile_token(content: str) -> str:
    content = str(content)
    if content.startswith("選択:"):
        raw = content[len("選択:"):]
        choices = raw.split("|")
        if not raw or any(x == "" for x in choices):
            raise ValueError("選択肢は {選択:A|B|C} の形式で指定してください。")
        return "(?:" + "|".join(re.escape(x) for x in choices) + ")"

    if ":" in content:
        kind, length = content.split(":", 1)
    else:
        kind, length = content, ""
    kind = kind.strip()
    length = length.strip()
    if kind not in TOKEN_TYPES:
        raise ValueError(f"未対応の特殊指定です: {{{content}}}")

    base_map = {
        "*": ".",
        "数字": r"[0-9]",
        "英字": r"[A-Za-z]",
        "大文字": r"(?-i:[A-Z])",
        "小文字": r"(?-i:[a-z])",
        "英数字": r"[A-Za-z0-9]",
    }
    default = "*" if kind == "*" else "+"
    return base_map[kind] + _length_quantifier(length, default)


def template_to_regex(template: str) -> str:
    """Convert the simple filename template into an anchored regular expression.

    Ordinary text is always treated literally. Only complete {...} tokens have
    special meaning. The result targets the filename stem, matching ACadPresetter's
    existing rule engine.
    """
    text = str(template or "")
    if not text:
        raise ValueError("ファイル名の形を入力してください。")

    out = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "{":
            end = text.find("}", i + 1)
            if end < 0:
                raise ValueError("{ に対応する } がありません。")
            inner = text[i + 1:end]
            if "{" in inner:
                raise ValueError("特殊指定の中に { は使用できません。")
            out.append(_compile_token(inner))
            i = end + 1
            continue
        if ch == "}":
            raise ValueError("対応する { がない } があります。")
        # Literal spans are grouped for smaller/more readable generated regexes.
        j = i + 1
        while j < len(text) and text[j] not in "{}":
            j += 1
        out.append(re.escape(text[i:j]))
        i = j
    return "^" + "".join(out) + "$"


def token_spans(text: str):
    """Return complete token spans as (start, end, content). Invalid braces are ignored."""
    s = str(text or "")
    spans = []
    for m in re.finditer(r"\{[^{}]+\}", s):
        try:
            _compile_token(m.group()[1:-1])
        except ValueError:
            continue
        spans.append((m.start(), m.end(), m.group()[1:-1]))
    return spans


def token_span_at(text: str, position: int, include_edges: bool = True):
    pos = max(0, int(position))
    for start, end, content in token_spans(text):
        if start <= pos < end or (include_edges and pos == end):
            return start, end, content
    return None


def parse_token(content: str):
    """Return (kind, mode, a, b). mode is none/fixed/range/selection."""
    content = str(content)
    if content.startswith("選択:"):
        return "選択", "selection", content[len("選択:"):], None
    if ":" in content:
        kind, length = content.split(":", 1)
        kind, length = kind.strip(), length.strip()
        m = re.fullmatch(r"([1-9]\d*)-([1-9]\d*)", length)
        if m:
            return kind, "range", int(m.group(1)), int(m.group(2))
        if re.fullmatch(r"[1-9]\d*", length):
            return kind, "fixed", int(length), None
        return kind, "invalid", length, None
    return content.strip(), "none", None, None


def make_token(kind: str, mode: str = "none", a=None, b=None) -> str:
    kind = str(kind)
    if kind == "選択":
        return "{選択:" + str(a or "") + "}"
    if kind not in TOKEN_TYPES:
        raise ValueError("未対応の特殊指定です。")
    if mode == "none":
        return "{" + kind + "}"
    if mode == "fixed":
        return "{" + kind + ":" + str(int(a)) + "}"
    if mode == "range":
        lo, hi = int(a), int(b)
        if lo < 1 or hi < 1 or lo > hi:
            raise ValueError("文字数範囲が正しくありません。")
        return "{" + kind + ":" + f"{lo}-{hi}" + "}"
    raise ValueError("文字数指定が正しくありません。")


def filename_stem(path_or_name: str) -> str:
    return Path(str(path_or_name)).stem


def template_matches(path_or_name: str, template: str, case_sensitive: bool = False) -> bool:
    pattern = template_to_regex(template)
    flags = 0 if case_sensitive else re.IGNORECASE
    return re.search(pattern, filename_stem(path_or_name), flags) is not None
