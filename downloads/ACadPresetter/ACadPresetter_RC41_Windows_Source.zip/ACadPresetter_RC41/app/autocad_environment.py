"""AutoCAD plot-environment cache helpers (no COM dependency)."""
from datetime import datetime

SCHEMA_VERSION = 3

def normalize_environment(raw):
    raw = raw or {}
    devices = [str(x) for x in raw.get("devices", []) if str(x).strip()]
    styles = [str(x) for x in raw.get("styles", []) if str(x).strip()]
    dm = raw.get("device_media") or {}
    device_media = {str(k): [str(x) for x in (v or []) if str(x).strip()] for k, v in dm.items()}
    dl = raw.get("device_media_locale") or {}
    device_media_locale = {
        str(dev): {str(k): str(v) for k, v in (mapping or {}).items() if str(k).strip()}
        for dev, mapping in dl.items()
    }
    # Backward compatibility with Step32 flat media cache.
    if not device_media and devices and raw.get("media"):
        device_media = {d: list(raw.get("media") or []) for d in devices}
    media = []
    seen = set()
    for d in devices:
        for m in device_media.get(d, []):
            if m.casefold() not in seen:
                seen.add(m.casefold()); media.append(m)
    return {
        **raw,
        "schema_version": SCHEMA_VERSION,
        "captured_at": raw.get("captured_at") or datetime.now().strftime("%Y/%m/%d %H:%M:%S"),
        "devices": devices,
        "device_media": device_media,
        "device_media_locale": device_media_locale,
        "media": media,
        "styles": styles,
        "paths": raw.get("paths") or {},
        "autocad": raw.get("autocad") or {},
    }

def media_for_device(environment, device):
    env = normalize_environment(environment)
    wanted = str(device or "").casefold()
    for key, values in env.get("device_media", {}).items():
        if key.casefold() == wanted:
            return list(values)
    return []

def validate_plot_preset(preset, environment, check_media=True):
    """Return [] or Japanese validation messages. DWG-settings mode is runtime-resolved."""
    if not preset or preset.get("setting_method") == "DWG/DXFに保存されている設定を使用":
        return []
    env = normalize_environment(environment)
    issues=[]
    device=str(preset.get("device","")).strip(); paper=str(preset.get("paper","")).strip(); style=str(preset.get("plot_style","")).strip()
    devices={x.casefold():x for x in env.get("devices",[])}
    if device and devices and device.casefold() not in devices:
        issues.append(f"プリンター/PC3が現在のAutoCAD環境にありません: {device}")
    elif device and paper and check_media:
        media=media_for_device(env,device)
        if media:
            from .media_names import resolve_media_name
            try: resolve_media_name(paper,media)
            except ValueError:
                issues.append(f"用紙をキャッシュで確認できません（出力時に実機で確認）: {device} / {paper}")
    if style and env.get("styles") and style.casefold() not in {x.casefold() for x in env["styles"]}:
        issues.append(f"CTB/STBが現在のAutoCAD環境にありません: {style}")
    return issues


def media_choices_for_device(environment, device):
    """Return [(canonical, display_label)] for one device.

    AutoCAD plots with CanonicalMediaName, but the Plot dialog shows the
    locale media label.  Keep canonical values for execution while exposing
    the same labels the user sees in AutoCAD.
    """
    env = normalize_environment(environment)
    values = media_for_device(env, device)
    wanted = str(device or "").casefold()
    mapping = {}
    for key, aliases in env.get("device_media_locale", {}).items():
        if key.casefold() == wanted:
            mapping = aliases or {}
            break
    return [(canonical, str(mapping.get(canonical) or canonical)) for canonical in values]
