from __future__ import annotations

import re
from typing import Any

from .models import new_id

PRESET_KINDS = ("plot", "rule", "dest", "name", "merge", "collection")


def ensure_ids(data: dict[str, list[dict[str, Any]]]) -> bool:
    changed = False
    prefixes = {"plot":"plot", "rule":"rule", "dest":"dest", "name":"name", "merge":"merge", "collection":"col"}
    for kind in PRESET_KINDS:
        for obj in data.get(kind, []):
            if not obj.get("id"):
                obj["id"] = new_id(prefixes[kind]); changed = True
    return changed


def validate_regex_rules(rules: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    for rule in rules:
        conditions = rule.get("conditions") or [rule]
        for cond in conditions:
            if cond.get("mode") == "正規表現":
                try:
                    re.compile(str(cond.get("value", "")))
                except re.error as exc:
                    errors.append(f"{rule.get('name','(名称なし)')}: {exc}")
    return errors


def references_to(data: dict[str, list[dict[str, Any]]], kind: str, preset_id: str) -> list[str]:
    refs: list[str] = []
    for col in data.get("collection", []):
        name = col.get("name", "(名称なし)")
        if kind == "rule" and any(x.get("rule_id") == preset_id for x in col.get("pairs", [])): refs.append(name)
        if kind == "plot" and any(x.get("plot_id") == preset_id for x in col.get("pairs", [])): refs.append(name)
        if kind == "dest" and col.get("dest_id") == preset_id: refs.append(name)
        if kind == "name" and col.get("name_id") == preset_id: refs.append(name)
        if kind == "merge" and col.get("merge_id") == preset_id: refs.append(name)
    return refs


def find_by_id(items: list[dict[str, Any]], preset_id: str | None):
    return next((x for x in items if x.get("id") == preset_id), None)
