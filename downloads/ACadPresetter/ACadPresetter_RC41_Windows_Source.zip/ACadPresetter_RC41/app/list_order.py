from pathlib import Path
import re


def natural_key(value):
    name = Path(str(value)).name
    return [int(x) if x.isdigit() else x.casefold() for x in re.split(r"(\d+)", name)]


def auto_order_enabled(merge_preset):
    if not merge_preset or not merge_preset.get("enabled", True):
        return False
    return merge_preset.get("order", "現在のリスト順") == "自動並び替え"


def order_paths(paths, merge_preset, rules, filename_of=None):
    """Return paths in merge-preset order. First matching rule wins; unmatched go last."""
    from app.rules import match_rule
    seq = list(paths)
    if not auto_order_enabled(merge_preset):
        return seq
    filename_of = filename_of or (lambda x: Path(str(x)).name)
    rule_map = {r.get("id"): r for r in rules}
    ids = list(merge_preset.get("sort_rule_ids") or [])
    rank = {rid: i for i, rid in enumerate(ids)}

    unmatched_first = merge_preset.get("unmatched", "最後に配置") == "最初に配置"

    def key(item):
        fn = filename_of(item)
        bucket = len(ids)
        matched = False
        for rid in ids:
            rule = rule_map.get(rid)
            if rule and match_rule(fn, rule):
                bucket = rank[rid]
                matched = True
                break
        if unmatched_first:
            bucket = bucket + 1 if matched else 0
        return (bucket, natural_key(fn))
    return sorted(seq, key=key)
