"""Adobe PDF printer compatibility helpers.

RC14 uses Adobe's documented PDF-printer preference first:
    HKLM\\SOFTWARE\\Adobe\\Acrobat Distiller\\<version>\\DonotSendFont = 0
Adobe documents this value as the backing preference for
"Rely on system fonts only; do not use document fonts".

Older Acrobat/Adobe PDF drivers also expose
DistillerHostFontHasMostFonts in PrinterDriverData.  We keep that as a
secondary compatibility path, but no longer rely on it alone because changing
only that value does not update all modern Adobe PDF installations.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


ADOBE_DISTILLER_VALUE = "DonotSendFont"
LEGACY_FONT_VALUE = "DistillerHostFontHasMostFonts"
DISTILLER_ROOT = r"SOFTWARE\Adobe\Acrobat Distiller"


def is_adobe_pdf_device(name: str | None) -> bool:
    text = str(name or "").casefold().replace("_", " ")
    return "adobe pdf" in text


@dataclass
class AdobePdfFontResult:
    applicable: bool = False
    found: bool = False
    enabled: bool = False
    changed: bool = False
    access_denied: bool = False
    verified_off: bool = False
    message: str = ""
    touched: list[str] = field(default_factory=list)


def _legacy_candidate_keys(printer_name: str = "Adobe PDF"):
    p = printer_name or "Adobe PDF"
    return [
        rf"SYSTEM\CurrentControlSet\Control\Print\Printers\{p}\PrinterDriverData",
        rf"SYSTEM\ControlSet001\Control\Print\Printers\{p}\PrinterDriverData",
        rf"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Printers\{p}\PrinterDriverData",
        rf"SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Print\Printers\{p}\PrinterDriverData",
    ]


def _registry_views(winreg):
    """Return distinct registry view flags supported by the running Python."""
    vals = []
    for name in ("KEY_WOW64_64KEY", "KEY_WOW64_32KEY"):
        v = int(getattr(winreg, name, 0) or 0)
        if v not in vals:
            vals.append(v)
    if not vals:
        vals = [0]
    return vals


def _enumerate_distiller_keys(winreg):
    """Yield (subkey, view) for every installed Acrobat Distiller version."""
    seen = set()
    for view in _registry_views(winreg):
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, DISTILLER_ROOT, 0, winreg.KEY_READ | view) as root:
                i = 0
                while True:
                    try:
                        version = winreg.EnumKey(root, i)
                    except OSError:
                        break
                    i += 1
                    path = DISTILLER_ROOT + "\\" + str(version)
                    key = (path.casefold(), view)
                    if key not in seen:
                        seen.add(key)
                        yield path, view
        except OSError:
            continue


def _ensure_distiller_preference(winreg, result: AdobePdfFontResult):
    """Set Adobe's documented DonotSendFont preference to 0."""
    version_keys = list(_enumerate_distiller_keys(winreg))
    for subkey, view in version_keys:
        result.found = True
        old = None
        old_found = False
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, subkey, 0, winreg.KEY_READ | view) as key:
                old, _ = winreg.QueryValueEx(key, ADOBE_DISTILLER_VALUE)
                old_found = True
        except FileNotFoundError:
            pass
        except OSError:
            pass

        try:
            old_on = bool(int(old)) if old_found else True  # absent => Adobe default is ON
        except Exception:
            old_on = bool(old) if old_found else True
        result.enabled = result.enabled or old_on

        if old_found and not old_on:
            result.verified_off = True
            continue
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, subkey, 0, winreg.KEY_SET_VALUE | view) as key:
                winreg.SetValueEx(key, ADOBE_DISTILLER_VALUE, 0, winreg.REG_DWORD, 0)
            # Verify instead of assuming SetValueEx was effective.
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, subkey, 0, winreg.KEY_READ | view) as key:
                now, _ = winreg.QueryValueEx(key, ADOBE_DISTILLER_VALUE)
            if int(now) == 0:
                result.changed = True
                result.verified_off = True
                result.touched.append(subkey + "\\" + ADOBE_DISTILLER_VALUE)
        except (PermissionError, OSError):
            result.access_denied = True


def _ensure_legacy_driver_preference(winreg, result: AdobePdfFontResult):
    """Best-effort compatibility for older Adobe PDF drivers."""
    seen = set()
    for subkey in _legacy_candidate_keys("Adobe PDF"):
        for view in _registry_views(winreg):
            sig = (subkey.casefold(), view)
            if sig in seen:
                continue
            seen.add(sig)
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, subkey, 0, winreg.KEY_READ | view) as key:
                    value, _ = winreg.QueryValueEx(key, LEGACY_FONT_VALUE)
                result.found = True
            except (FileNotFoundError, OSError):
                continue
            try:
                enabled = int(value) != 0
            except Exception:
                enabled = bool(value)
            result.enabled = result.enabled or enabled
            if not enabled:
                continue
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, subkey, 0, winreg.KEY_SET_VALUE | view) as key:
                    winreg.SetValueEx(key, LEGACY_FONT_VALUE, 0, winreg.REG_DWORD, 0)
                result.changed = True
                result.touched.append(subkey + "\\" + LEGACY_FONT_VALUE)
            except (PermissionError, OSError):
                # This legacy value is supplemental.  If the documented Distiller
                # preference is already verified OFF, failure here must not block output.
                if not result.verified_off:
                    result.access_denied = True


def ensure_adobe_pdf_document_fonts(device_name: str | None) -> AdobePdfFontResult:
    """Ensure Adobe PDF sends document fonts instead of relying on system fonts.

    The function is intentionally a no-op for non-Adobe devices/non-Windows.
    On Windows it updates Adobe's documented DonotSendFont preference and then
    the legacy PrinterDriverData value when present.  It is safe to call before
    AutoCAD starts and again immediately before plotting.

    This is best-effort: access_denied reports inability to change a machine
    registry value. It does not prove that the active printer/PC3 preference is
    ON, and callers must not use it to prevent a plot attempt.
    """
    result = AdobePdfFontResult(applicable=is_adobe_pdf_device(device_name))
    if not result.applicable or os.name != "nt":
        return result
    try:
        import winreg
    except Exception:
        return result

    _ensure_distiller_preference(winreg, result)
    _ensure_legacy_driver_preference(winreg, result)

    # Reaching a verified documented OFF value is sufficient even if an optional
    # legacy mirror could not be modified.
    if result.verified_off:
        result.access_denied = False
    if result.access_denied:
        result.message = (
            "Adobe PDF のマシン共通設定を自動変更できませんでした。"
            "この結果だけでは印刷設定のON/OFFは判定できません。現在の印刷設定で出力を試行します。"
        )
    elif result.changed:
        result.message = "Adobe PDF のフォント設定を『文書のフォントを使用』へ補正しました。"
    elif result.verified_off:
        result.message = "Adobe PDF のマシン共通設定でDonotSendFont=0を確認しました。"
    return result


def adobe_pdf_generation_hint() -> str:
    return (
        "Adobe PDFでPDFを生成できませんでした。フォント設定が既にOFFなら、"
        "Adobe PDFの出力フォルダーと保存確認画面、AutoCADの印刷ログを確認してください。"
        "表示されたAutoCAD/Adobeの元のエラー文も控えてください。"
    )
