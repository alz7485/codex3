import json, time
from pathlib import Path
from .store import _atomic_json_write, read_text_compat

class RunHistory:
    def __init__(self, app_dir, config=None):
        self.app_dir=Path(app_dir)
        self.config=config or {}
        self.path=self.app_dir/"data"/"run_history.json"
        self.path.parent.mkdir(parents=True,exist_ok=True)

    def load(self):
        try:return json.loads(read_text_compat(self.path))
        except Exception:return {"last":None}

    def save(self,data):
        _atomic_json_write(self.path,data)

    def begin(self,jobs):
        rec={"started":time.strftime("%Y-%m-%d %H:%M:%S"),"finished":None,
             "jobs":[dict(j,status="未処理",message="") for j in jobs]}
        self.save({"last":rec}); return rec

    def update(self,rec,source,kind,status,message="",trace=None):
        for j in rec["jobs"]:
            if j.get("source")==source and j.get("kind")==kind:
                j["status"]=status;j["message"]=message
                if trace is not None: j["trace"]=list(trace)[-500:]
                break
        self.save({"last":rec})

    def finish(self,rec):
        rec["finished"]=time.strftime("%Y-%m-%d %H:%M:%S")
        self.save({"last":rec})
        try:
            from .output_log import OutputLogger
            OutputLogger(self.app_dir/"data", self.config).write(rec)
        except Exception:
            pass
