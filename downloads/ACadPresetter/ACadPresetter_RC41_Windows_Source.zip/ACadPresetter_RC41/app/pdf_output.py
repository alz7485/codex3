from __future__ import annotations

import os
import shutil
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass
class StagedPdf:
    source: str
    final_path: str
    temp_path: str
    label: str = ""


class PdfOutputSession:
    """One output-run staging area. Existing final PDFs are never touched until commit."""
    def __init__(self, root: str | Path | None = None):
        base = Path(root) if root else Path(tempfile.gettempdir()) / "ACadPresetter"
        base.mkdir(parents=True, exist_ok=True)
        self.run_dir = base / ("run_" + uuid.uuid4().hex[:12])
        self.run_dir.mkdir(parents=True, exist_ok=False)
        self._items: list[StagedPdf] = []

    def stage(self, source: str, final_path: str, label: str = "") -> StagedPdf:
        final = Path(final_path)
        temp = self.run_dir / f"{len(self._items)+1:05d}_{uuid.uuid4().hex[:8]}.pdf"
        item = StagedPdf(str(source), str(final), str(temp), label)
        self._items.append(item)
        return item

    @staticmethod
    def validate_pdf(path: str | Path) -> None:
        p = Path(path)
        if not p.exists() or p.stat().st_size < 5:
            raise RuntimeError("生成されたPDFを確認できませんでした。")
        try:
            from pypdf import PdfReader
            with p.open("rb") as f:
                if f.read(5) != b"%PDF-":
                    raise ValueError("PDFヘッダーがありません")
                f.seek(0)
                reader = PdfReader(f, strict=True)
                if reader.is_encrypted:
                    raise ValueError("暗号化された生成PDFです")
                if not reader.pages:
                    raise ValueError("ページがありません")
                for page in reader.pages:
                    # Resolve page dictionaries and content streams, not just the header.
                    _ = page.mediabox
                    contents = page.get_contents()
                    if contents is not None:
                        contents.get_data()
        except Exception as exc:
            raise RuntimeError("生成ファイルが正常なPDFではありません: " + str(exc)) from exc

    @staticmethod
    def atomic_commit(temp_path: str | Path, final_path: str | Path) -> str:
        src, dst = Path(temp_path), Path(final_path)
        PdfOutputSession.validate_pdf(src)
        dst.parent.mkdir(parents=True, exist_ok=True)
        # Same-volume replace is atomic. For a different volume, copy beside destination first.
        beside = dst.parent / ("." + dst.name + ".acadpresetter_" + uuid.uuid4().hex[:8] + ".tmp")
        try:
            shutil.copy2(src, beside)
            PdfOutputSession.validate_pdf(beside)
            os.replace(beside, dst)
            # Network/server destinations are allowed. Verify the final file really
            # exists there before reporting success so a staging-only PDF can never
            # be mistaken for a completed output.
            PdfOutputSession.validate_pdf(dst)
        finally:
            try:
                if beside.exists(): beside.unlink()
            except OSError:
                pass
        return str(dst)

    def cleanup(self) -> None:
        shutil.rmtree(self.run_dir, ignore_errors=True)


def existing_outputs(paths: Iterable[str]) -> list[str]:
    return [str(Path(p)) for p in paths if Path(p).exists()]


def classify_existing(paths: Iterable[str], action: str) -> tuple[set[str], set[str]]:
    """Return (write, skip), case-insensitive absolute-ish keys."""
    keys = {str(Path(p)).casefold() for p in paths}
    if action == "スキップする":
        return set(), keys
    return keys, set()
