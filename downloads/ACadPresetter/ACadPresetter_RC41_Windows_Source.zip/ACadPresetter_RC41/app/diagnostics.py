import json, platform, sys, time
from pathlib import Path

def build_diagnostic_report(app_dir, store_data, detect_func=None, probe_func=None, config=None):
    lines=[]
    lines.append("ACadPresetter 診断レポート")
    lines.append("="*60)
    lines.append("日時: "+time.strftime("%Y-%m-%d %H:%M:%S"))
    lines.append("Python: "+sys.version.replace("\n"," "))
    lines.append("OS: "+platform.platform())
    lines.append("実行形式: "+("PyInstaller" if getattr(sys,"frozen",False) else "Python"))
    lines.append("APP_DIR: "+str(app_dir))
    lines.append("")
    lines.append("[データ]")
    for key in ("plot","rule","dest","name","merge","collection"):
        lines.append(f"{key}: {len(store_data.get(key,[]))}件")
    lines.append("")
    lines.append("[AutoCADインストール検出]")
    try:
        detected=detect_func() if detect_func else []
        rows=detected.get("items",[]) if isinstance(detected,dict) else detected
        if not rows: lines.append("検出なし")
        for x in rows:
            lines.append(str(x))
    except Exception as e:
        lines.append("検出エラー: "+repr(e))
    lines.append("")
    lines.append("[起動中AutoCAD接続テスト]")
    try:
        if probe_func is None:
            raise RuntimeError("接続テスト未実行")
        env=probe_func(False)
        lines.append("接続OK")
        lines.append("図面: "+str(env.get("drawing","")))
        lines.append("Layout: "+str(env.get("layout","")))
        lines.append("デバイス数: "+str(len(env.get("devices",[]))))
        lines.append("用紙数: "+str(len(env.get("media",[]))))
        lines.append("CTB/STB数: "+str(len(env.get("styles",[]))))
    except Exception as e:
        lines.append("未接続/取得不可: "+str(e))
        lines.append("※診断のためにAutoCADを自動起動していません。")
    lines.append("")
    lines.append('[Adobe PDF設定]')
    cfg = config or {}
    folder = str(cfg.get('adobe_pdf_watch_dir', '') or '').strip()
    from .adobe_device_output import normalize_timeout, snapshot_pdfs
    lines.append('自動保存先: ' + (folder or '未指定（Adobe PDF使用時は設定が必要）'))
    lines.append(f"生成待機: {normalize_timeout(cfg.get('adobe_pdf_timeout', 120)):g}秒")
    if folder:
        try:
            files = snapshot_pdfs([Path(folder)])
            lines.append(f'フォルダ読み取り: OK / PDF {len(files)}件')
        except Exception as exc:
            lines.append('フォルダ読み取り: NG - ' + str(exc))
    lines.append('AutoCAD/Acrobatの実際の印刷・自動保存はこの診断では実行しません。')
    lines.append('')
    lines.append("[依存ライブラリ]")
    for mod in ("PySide6","win32com.client","pypdf"):
        try:
            import importlib
            importlib.import_module(mod)
            lines.append(mod+": OK")
        except Exception as e:
            lines.append(mod+": NG - "+str(e))
    return "\n".join(lines)

def save_report(app_dir,text):
    p=Path(app_dir)/"logs"
    p.mkdir(parents=True,exist_ok=True)
    out=p/("diagnostic_"+time.strftime("%Y%m%d_%H%M%S")+".txt")
    out.write_text(text,encoding="utf-8")
    return out
