import json
from pathlib import Path
from .store import _atomic_json_write, read_text_compat
class SessionManager:
    def __init__(self,path): self.path=Path(path)
    def save(self,data):
        _atomic_json_write(self.path,data)
    def load(self):
        if not self.path.exists(): return None
        try:return json.loads(read_text_compat(self.path))
        except Exception:return None
