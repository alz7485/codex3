"""Match user paper labels to the selected plotter's canonical names."""
import re
import unicodedata


def _normal(value):
    return " ".join(unicodedata.normalize("NFKC", str(value)).casefold().replace("_", " ").split())


def resolve_media_name(requested, canonical_names, locale_names=None):
    names = list(dict.fromkeys(str(x) for x in canonical_names))
    aliases = locale_names or {}
    wanted = _normal(requested)
    exact = [x for x in names if wanted in (_normal(x), _normal(aliases.get(x, x)))]
    if len(exact) == 1:
        return exact[0]
    # A3/A1 etc. are size aliases, never a licence to replace another size.
    # Only simple size requests use this fallback; explicit media variants
    # (full bleed/expand/custom dimensions) must match exactly.
    simple = re.fullmatch(r"(?:iso\s*)?([ab][0-6])", wanted)
    if simple:
        size = simple.group(1)
        pattern = re.compile(r"(?<![a-z0-9])" + size + r"(?![a-z0-9])")
        matches = [x for x in names if pattern.search(_normal(x)) or pattern.search(_normal(aliases.get(x, x)))]
        # An Oversize A1 label is not nominal A1. Reject explicit mismatching
        # dimensions rather than silently altering the requested sheet size.
        dimensions={"a0":(841,1189),"a1":(594,841),"a2":(420,594),"a3":(297,420),"a4":(210,297),"a5":(148,210),"a6":(105,148)}
        if size in dimensions:
            def same_dimensions(name):
                text=_normal(name)
                found=re.search(r"(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)\s*(mm|millimeters|ミリ|inches|inch)",text)
                if not found:
                    return not any(word in text for word in ("oversize","extra","plus"))
                factor=25.4 if found.group(3) in ("inch","inches") else 1.0
                actual=sorted((float(found.group(1))*factor,float(found.group(2))*factor))
                return all(abs(a-b)<1.0 for a,b in zip(actual,dimensions[size]))
            matches=[x for x in matches if same_dimensions(x) and same_dimensions(aliases.get(x,x))]
        regular = [x for x in matches if not any(word in _normal(x) + " " + _normal(aliases.get(x, x))
                   for word in ("full bleed", "fullbleed", "expand", "borderless", "フチなし", "拡張"))]
        if len(regular) == 1:
            return regular[0]
        if len(matches) == 1:
            return matches[0]
        if matches:
            raise ValueError(f"用紙「{requested}」の候補が複数あります。プリセットで正式な用紙名を選んでください: " + " / ".join(matches))
    raise ValueError(f"指定用紙「{requested}」は選択した出力機器で見つかりません。使用可能な用紙: " + " / ".join(names[:20]))
