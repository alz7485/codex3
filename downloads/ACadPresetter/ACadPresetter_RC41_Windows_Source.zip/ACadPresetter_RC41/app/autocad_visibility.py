"""Keep only the AutoCAD instance owned by ACadPresetter off the user's desktop.

AutoCAD can make its main frame (and sometimes auxiliary top-level windows) visible again
while Documents.Open/Plot runs. Hiding only the first HWND is therefore not sufficient.
This guard records the PID of the owned AutoCAD instance and continuously hides all
top-level windows that belong to that PID. It never hides windows from another AutoCAD
process, so a user's already-open AutoCAD is left untouched.
"""
import os
import threading


def existing_window_handles():
    if os.name != "nt":
        return set()
    import ctypes
    from ctypes import wintypes
    handles = set()
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def visit(hwnd, _):
        handles.add(int(hwnd))
        return True
    callback = callback_type(visit)
    ctypes.windll.user32.EnumWindows(callback, 0)
    return handles


class HiddenWindowGuard:
    """Hide all top-level windows owned by one verified AutoCAD process."""
    def __init__(self, hwnd):
        self.hwnd = int(hwnd or 0)
        self._stop = threading.Event()
        self._thread = None
        self._pid = None
        self._api = None
        self._callback_type = None

    def start(self):
        if os.name != "nt" or not self.hwnd:
            return
        import ctypes
        from ctypes import wintypes
        api = ctypes.WinDLL("user32", use_last_error=True)
        api.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        api.GetWindowThreadProcessId.restype = wintypes.DWORD
        api.IsWindow.argtypes = [wintypes.HWND]
        api.IsWindow.restype = wintypes.BOOL
        api.IsWindowVisible.argtypes = [wintypes.HWND]
        api.IsWindowVisible.restype = wintypes.BOOL
        api.ShowWindowAsync.argtypes = [wintypes.HWND, ctypes.c_int]
        api.ShowWindowAsync.restype = wintypes.BOOL
        api.EnumWindows.argtypes = [ctypes.c_void_p, wintypes.LPARAM]
        api.EnumWindows.restype = wintypes.BOOL
        pid = wintypes.DWORD()
        api.GetWindowThreadProcessId(self.hwnd, ctypes.byref(pid))
        if not pid.value:
            raise RuntimeError("専用AutoCADのウィンドウを確認できませんでした。")
        self._api, self._pid = api, int(pid.value)
        self._callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        self.hide_now()
        self._thread = threading.Thread(target=self._run, name="ACadPresetter-hide-owned-autocad", daemon=True)
        self._thread.start()

    def _hide_hwnd_if_owned(self, hwnd):
        import ctypes
        from ctypes import wintypes
        if self._api is None or not self._api.IsWindow(hwnd):
            return
        pid = wintypes.DWORD()
        self._api.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if int(pid.value) != self._pid:
            return
        if self._api.IsWindowVisible(hwnd):
            self._api.ShowWindowAsync(hwnd, 0)  # SW_HIDE

    def hide_now(self):
        if self._api is None:
            return
        # Compatibility/fallback for tests and unusual environments: if EnumWindows is
        # unavailable, still protect the original main HWND.
        if self._callback_type is None or not hasattr(self._api, "EnumWindows"):
            self._hide_hwnd_if_owned(self.hwnd)
            return
        callback = self._callback_type(lambda hwnd, _lp: (self._hide_hwnd_if_owned(hwnd), True)[1])
        self._api.EnumWindows(callback, 0)

    def _run(self):
        while not self._stop.wait(0.01):
            try:
                self.hide_now()
            except Exception:
                pass

    def close(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None
