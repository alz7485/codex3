"""Adobe PDF output through the verified Trial10g -PLOT macro.

This module intentionally follows the AutoCAD_PrintTest_Trial10g path that was
confirmed on the user's machine: Adobe PDF is treated as a printer, then the
PDF created by the Adobe driver is detected and moved to ACadPresetter's staged
PDF path.  It does not ask AutoCAD to PlotToFile through Adobe PDF.
"""
from __future__ import annotations

import os
import re
import shutil
import time
import tempfile
import hashlib
import unicodedata
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath


def normalize_timeout(value):
    """Keep legacy/malformed config compatible; public setting is 30-600 seconds."""
    import math
    try:
        seconds = float(value)
        if not math.isfinite(seconds):
            raise ValueError('non-finite timeout')
        return max(30.0, min(600.0, seconds))
    except (ValueError, TypeError):
        return 120.0


def _add_dir(result: list[Path], value):
    if not value:
        return
    try:
        text=os.path.expandvars(os.path.expanduser(str(value).strip().strip('"')))
        p=Path(text)
        if p.suffix.lower()=='.pdf' or '*' in p.name:
            p=p.parent
        if p.exists() and p.is_dir():
            rp=p.resolve()
            if rp not in result:
                result.append(rp)
    except Exception:
        pass


def candidate_dirs(device: str, source_path: str | Path, staged_output: str | Path | None=None, log=None, preferred_dir: str | Path | None=None):
    log=log or (lambda _msg: None)
    dirs=[]
    src=Path(source_path)
    if preferred_dir:
        pref=Path(os.path.expandvars(os.path.expanduser(str(preferred_dir).strip().strip('"'))))
        if not pref.exists() or not pref.is_dir():
            raise RuntimeError(f'Adobe PDF生成先フォルダが存在しません: {pref}')
        # Trial10gで実機成功した経路: 明示指定がある場合はその1フォルダだけを監視する。
        # 複数候補を走査して別ジョブのPDFを拾うリスクをなくす。
        _add_dir(dirs,pref)
        return dirs
    try:_add_dir(dirs,src.resolve().parent)
    except Exception:_add_dir(dirs,src.parent)
    if staged_output:
        _add_dir(dirs,Path(staged_output).parent)
    home=Path.home()
    for d in (home/'Documents',home/'Desktop',home/'Downloads',
              Path(os.environ.get('TEMP','')),Path(os.environ.get('TMP','')),
              Path(os.environ.get('USERPROFILE',''))/'Documents'):
        _add_dir(dirs,d)
    for env in ('OneDrive','OneDriveCommercial','OneDriveConsumer'):
        root=os.environ.get(env)
        if root:
            _add_dir(dirs,Path(root)/'Documents')
            _add_dir(dirs,Path(root)/'Desktop')

    # Printer port may itself point at Adobe's auto-save folder.  A PC3 name is
    # not a Windows printer name, so also try plain "Adobe PDF".
    try:
        import win32print
        names=[]
        for name in (str(device or ''), re.sub(r'\.pc3$','',str(device or ''),flags=re.I), 'Adobe PDF'):
            if name and name.casefold() not in {x.casefold() for x in names}:
                names.append(name)
        for name in names:
            try:
                h=win32print.OpenPrinter(name)
                try:
                    info=win32print.GetPrinter(h,2)
                    port=info.get('pPortName','')
                    if port:
                        log(f'Adobe PDF Port = {port}')
                        _add_dir(dirs,port)
                finally:
                    win32print.ClosePrinter(h)
            except Exception:
                pass
    except Exception:
        pass

    # Adobe Distiller silent/default-output registry values, when configured.
    try:
        import winreg
        roots=(winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE)
        tracks=('DC','2020','2017','15.0','11.0')
        names=('SilentAdobePDFPrintFolder','DefaultPDFOutput')
        for root in roots:
            for track in tracks:
                for suffix in ('Preferences',''):
                    key_path=rf'SOFTWARE\Adobe\Acrobat Distiller\{track}'
                    if suffix:key_path+='\\'+suffix
                    try:
                        with winreg.OpenKey(root,key_path) as key:
                            for vn in names:
                                try:
                                    value,_=winreg.QueryValueEx(key,vn)
                                    if value:
                                        log(f'Adobe設定 {vn} = {value}')
                                        _add_dir(dirs,value)
                                except OSError:
                                    pass
                    except OSError:
                        pass
    except Exception:
        pass
    return dirs


def filename_key(name):
    """Compose Unicode and normalize spaces and the confirmed '(1)' suffix.

    Do not NFKC-fold the drawing name: full-width letters and circled numbers
    can identify a different CAD drawing. Fresh normalized collisions are errors.
    """
    text = unicodedata.normalize('NFC', str(name))
    text = ''.join(' ' if unicodedata.category(c) == 'Zs' else c for c in text)
    suffix = re.fullmatch(r'(.*?) +[（(][１1][）)](\.pdf)', text, flags=re.I)
    if suffix:
        text = suffix.group(1) + ' (1).pdf'
    return text.casefold()


def _path_key(path):
    # Resolve filesystem aliases, but keep the actual filename for file access.
    return os.path.normcase(str(Path(path).resolve())).casefold()


def _file_metadata(path):
    st = Path(path).stat()
    return (st.st_mtime_ns, st.st_size, st.st_ctime_ns,
            getattr(st, 'st_dev', 0), getattr(st, 'st_ino', 0))


def _file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class PdfSnapshot:
    metadata: tuple
    sha256: str | None = None


def _pdf_files(folder):
    """Enumerate actual names; resolve comparisons without changing file paths."""
    try:
        return [p for p in Path(folder).iterdir()
                if filename_key(p.name).endswith('.pdf') and not p.is_symlink() and p.is_file()]
    except OSError as exc:
        raise RuntimeError(f'Adobe PDF生成先を読み取れません: {folder}\n{exc}') from exc


def snapshot_pdfs(dirs, expected_name=None, log=None):
    """Hash only the expected output, never every unrelated PDF in the folder."""
    log = log or (lambda _msg: None)
    result = {}
    for folder in dirs:
        for path in _pdf_files(folder):
            try:
                metadata = _file_metadata(path)
                digest = None
                if expected_name is not None and filename_key(path.name) == filename_key(expected_name):
                    try:
                        digest = _file_sha256(path)
                        after = _file_metadata(path)
                        if after != metadata:
                            digest = None
                            metadata = after
                            log(f'印刷前PDFが読み取り中に更新されました: {path.name!r}')
                    except OSError as exc:
                        log(f'印刷前PDFの内容を読み取れません: {path.name!r} / {exc}')
                    log(f'印刷前PDF: {path.name!r} / mtime_ns={metadata[0]} / '
                        f'size={metadata[1]} / SHA256={digest or "未取得"}')
                result[_path_key(path)] = PdfSnapshot(metadata, digest)
            except FileNotFoundError:
                continue
    return result


def is_pdf(path: str | Path) -> bool:
    try:
        with Path(path).open('rb') as stream:
            return stream.read(5) == b'%PDF-'
    except OSError:
        return False


def adobe_generated_name(source_path):
    """Adobe's confirmed name: original CAD stem + ASCII space + (1).pdf."""
    name = PureWindowsPath(str(source_path or '')).name
    if not name:
        raise RuntimeError('Adobe PDFの照合に必要な元CADデータのファイル名を取得できません。')
    stem = PureWindowsPath(name).stem
    return f'{stem} (1).pdf'


def _name_score(name: str, source_stem: str):
    """Accept only the exact DWG stem or an Adobe numeric collision suffix."""
    n = Path(filename_key(name)).stem
    s = filename_key(source_stem)
    if n == s + ' (1)':
        return 0
    if n == s:
        return 1
    if re.fullmatch(re.escape(s) + r' \([1-9]\d*\)', n):
        return 2
    return 99


def wait_for_generated_pdf(dirs, before, source_stem: str, started_at: float,
                           timeout: float = 120.0, log=None, keep_hidden=None, expected_name=None):
    """Find a fresh, stable, valid PDF without comparing wall-clock timestamps.

    The before/after fingerprint proves new generation. The legacy started_at
    parameter stays for compatibility; server/driver time is never compared to it.
    """
    from .pdf_output import PdfOutputSession
    log = log or (lambda _msg: None)
    deadline = time.monotonic() + timeout
    stable = {}
    content_stable = {}
    hash_checks = {}
    reasons = {}

    def reason(path, message):
        key = str(path)
        if reasons.get(key) != message:
            log(f'Adobe PDF完成待ち: {Path(path).name!r} / {message}')
            reasons[key] = message

    wanted = filename_key(expected_name) if expected_name is not None else None
    if wanted is not None:
        log(f'Adobe PDF照合キー（Unicode・空白正規化後）: {wanted!r}')
    while time.monotonic() < deadline:
        if keep_hidden:
            keep_hidden()
        now = time.monotonic()
        candidates = []
        all_names = []
        matched = False
        for folder in dirs:
            for path in _pdf_files(folder):
                all_names.append(path.name)
                if wanted is not None:
                    if filename_key(path.name) != wanted:
                        continue
                elif _name_score(path.name, source_stem) == 99:
                    continue
                matched = True
                try:
                    metadata = _file_metadata(path)
                    key = _path_key(path)
                    old = before.get(key)
                    previous = stable.get(key)
                    if previous is None or previous[0] != metadata:
                        stable[key] = (metadata, now)
                        content_stable.pop(key, None)
                        hash_checks.pop(key, None)
                    ready = now - stable[key][1] >= 0.6

                    # Legacy snapshots used (mtime_ns, size); accept them as
                    # metadata evidence, but never invent a missing content hash.
                    old_meta = old.metadata if isinstance(old, PdfSnapshot) else old
                    old_digest = old.sha256 if isinstance(old, PdfSnapshot) else None
                    same_metadata = (old_meta is not None and
                                     tuple(old_meta) == metadata[:len(old_meta)])
                    if same_metadata:
                        if old_digest is None:
                            reason(path, '印刷前とファイル情報が同じで、内容差分の基準がありません')
                            continue
                        if not ready:
                            continue
                        last_check = hash_checks.get(key)
                        if last_check is not None and now - last_check < 0.6:
                            continue
                        digest = _file_sha256(path)
                        hash_checks[key] = now
                        if _file_metadata(path) != metadata:
                            stable.pop(key, None)
                            reason(path, '内容比較中にファイルが更新されました')
                            continue
                        if digest == old_digest:
                            content_stable.pop(key, None)
                            reason(path, '印刷前と日時・サイズ・内容が同じです（既存PDFを再利用しません）')
                            continue
                        previous_content = content_stable.get(key)
                        ready = (previous_content is not None and previous_content[0] == digest and
                                 now - previous_content[1] >= 0.6)
                        if previous_content is None or previous_content[0] != digest:
                            content_stable[key] = (digest, now)
                        reason(path, '日時・サイズは同じですがSHA256の変更を検出しました')
                    candidates.append((path, key, metadata, ready))
                except OSError as exc:
                    reason(path, 'ファイルの読み取りを再試行しています: ' + str(exc))
        if not matched and wanted is not None:
            names = ', '.join(repr(n) for n in sorted(all_names)[:10]) or '(なし)'
            message = f'一致する名前がありません。監視先のPDF名（最大10件）: {names}'
            if reasons.get('names') != message:
                log(message)
                reasons['names'] = message
        if len(candidates) > 1:
            raise RuntimeError('Adobe PDF候補が複数あり、今回の出力を特定できません: '
                               + ', '.join(str(p) for p, _, _, _ in candidates))
        if candidates:
            path, key, metadata, ready = candidates[0]
            if not ready:
                reason(path, 'ファイル情報・内容の安定を待っています')
            elif metadata[1] <= 0:
                reason(path, 'ファイルはありますが0バイトです')
            else:
                try:
                    if not is_pdf(path):
                        raise RuntimeError('PDFヘッダーがありません')
                    PdfOutputSession.validate_pdf(path)
                    if _file_metadata(path) != metadata:
                        stable.pop(key, None)
                        reason(path, '全ページ検証中にファイルが更新されました')
                        continue
                    if expected_name is not None and path.name != expected_name:
                        log(f'正規化後に生成名が一致: 期待={expected_name!r} / 実体={path.name!r}')
                    log(f'Adobe PDF検出・全ページ検証完了 = {path.name} ({metadata[1]:,} bytes)')
                    return path
                except (RuntimeError, OSError) as exc:
                    reason(path, str(exc))
        time.sleep(min(0.2, max(0.0, deadline - time.monotonic())))
    log('Adobe PDF待機終了: 最新の除外理由・実ファイル名は上記のログを確認してください')
    return None


def _command_state(doc):
    from .autocad_backend import AutoCADUnsafeState
    try:
        active = int(doc.GetVariable('CMDACTIVE'))
        if active < 0:
            raise ValueError('CMDACTIVE < 0')
    except Exception as exc:
        raise AutoCADUnsafeState('AutoCADのコマンド状態を確認できません。次の図面へ進まず停止します。') from exc
    try:
        names = str(doc.GetVariable('CMDNAMES') or '')
    except Exception:
        names = ''  # CMDACTIVE is authoritative; CMDNAMES is diagnostic only
    return active, names


def _ensure_command_idle(doc, timeout=5.0, log=None, keep_hidden=None):
    from .autocad_backend import AutoCADUnsafeState
    log = log or (lambda _msg: None)
    active, names = _command_state(doc)
    if active == 0 and not names.strip():
        return
    log(f"前回コマンドが残っています: CMDACTIVE={active}, CMDNAMES={names or '(なし)'}")
    try:
        doc.SendCommand("\x1b\x1b")
    except Exception as exc:
        raise AutoCADUnsafeState(f'前回コマンドのキャンセルに失敗しました: {exc}') from exc
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if keep_hidden:
            keep_hidden()
        active, names = _command_state(doc)
        if active == 0 and not names.strip():
            log('コマンドラインを待機状態へ戻しました')
            return
        time.sleep(0.1)
    raise AutoCADUnsafeState(f"AutoCADのコマンドラインを待機状態へ戻せませんでした。\nCMDACTIVE={active}, CMDNAMES={names or '(なし)'}")


def _wait_macro_complete(doc, started_at, timeout=45.0, log=None, keep_hidden=None):
    from .autocad_backend import AutoCADUnsafeState
    log = log or (lambda _msg: None)
    begun = time.monotonic()
    deadline = begun + timeout
    saw_active = False
    idle_since = None
    last_state = None
    while time.monotonic() < deadline:
        if keep_hidden:
            keep_hidden()
        active, names = _command_state(doc)
        state = (active, names)
        if state != last_state:
            log(f"コマンド状態: CMDACTIVE={active}, CMDNAMES={names or '(なし)'}")
            last_state = state
        now = time.monotonic()
        if active or names.strip():
            saw_active = True
            idle_since = None
        else:
            if idle_since is None:
                idle_since = now
            if now - idle_since >= 0.3 and (saw_active or now - begun >= 2.0):
                return
        time.sleep(0.12)
    active, names = _command_state(doc)
    raise AutoCADUnsafeState(
        '-PLOTマクロが時間内に終了しませんでした。\n'
        f"CMDACTIVE={active}, CMDNAMES={names or '(なし)'}\n"
        '保存確認や入力待ちの可能性があります。後続図面は停止します。'
    )


def finalize_generated_pdf(generated: str | Path, staged_output: str | Path,
                           log=None, *, remove_generated=False, timeout=5.0):
    from .pdf_output import PdfOutputSession
    log = log or (lambda _msg: None)
    generated = Path(generated).resolve()
    out = Path(staged_output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    if generated == out:
        PdfOutputSession.validate_pdf(out)
        return out
    fd, temporary = tempfile.mkstemp(prefix='.' + out.name + '.', suffix='.adobe_tmp', dir=out.parent)
    os.close(fd)
    tmp = Path(temporary)
    deadline = time.monotonic() + timeout
    try:
        while True:
            try:
                first = generated.stat()
                shutil.copy2(generated, tmp)
                last = generated.stat()
                signature = (last.st_size, last.st_mtime_ns, last.st_ctime_ns)
                if signature != (first.st_size, first.st_mtime_ns, first.st_ctime_ns):
                    raise OSError('Adobe PDFがコピー中に更新されました')
                if tmp.stat().st_size != last.st_size:
                    raise OSError('Adobe生成PDFのコピーサイズが一致しません')
                PdfOutputSession.validate_pdf(tmp)
                break
            except OSError as exc:
                if time.monotonic() >= deadline:
                    raise RuntimeError(f'Adobe PDFを取り込めません。生成元は保持しています: {generated}\n{exc}') from exc
                time.sleep(0.2)
        os.replace(tmp, out)
        PdfOutputSession.validate_pdf(out)
        # Existing user PDFs are never deleted. Delete only a newly created,
        # unchanged driver output after the staged copy has been validated.
        if remove_generated:
            try:
                current = generated.stat()
                if (current.st_size, current.st_mtime_ns, current.st_ctime_ns) == signature:
                    generated.unlink()
                else:
                    log(f'生成元が更新されたため保持しました: {generated}')
            except OSError as exc:
                log(f'Adobe生成元PDFを保持しました: {exc}')
        return out
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def plot_to_device_pdf(doc, staged_output: str | Path, device: str, *, log=None, keep_hidden=None, timeout: float=120.0, preferred_dir: str | Path | None=None, source_path: str | Path | None=None):
    """Trial10g実機成功経路をそのまま使う。

    Adobe PDFは通常プリンターとして ``_.-PLOT`` / SendCommand で印刷し、
    指定されたAdobe生成先の ``元CADデータ名 (1).pdf`` を厳密に照合する。
    ``PlotToFile`` は使用しない。
    """
    log=log or (lambda _msg: None)
    # The original input is authoritative. AutoCAD may expose a converted/temp
    # document name; neither that name nor the staged/final PDF name identifies
    # the Adobe output generated for the user's CAD input.
    source=str(source_path or getattr(doc,'FullName','') or getattr(doc,'Name','') or '')
    expected_name=adobe_generated_name(source)
    stem=PureWindowsPath(source).stem
    if not preferred_dir:
        raise RuntimeError(
            'Adobe PDF生成先が未設定です。\n'
            'Trial10gと同じ方式では、Adobe PDFプリンターで指定している自動保存先フォルダを設定してください。'
        )
    watch_dir=Path(os.path.expandvars(os.path.expanduser(str(preferred_dir).strip().strip('"')))).resolve()
    if not watch_dir.exists() or not watch_dir.is_dir():
        raise RuntimeError(f'Adobe PDF生成先フォルダが存在しません: {watch_dir}')

    try: layout=doc.ActiveLayout
    except Exception as exc: raise RuntimeError('印刷対象レイアウトを取得できません。') from exc
    layout_name=str(getattr(layout,'Name','') or '')
    config=str(getattr(layout,'ConfigName','') or device or '')
    if 'adobe' not in config.casefold() or 'pdf' not in config.casefold():
        raise RuntimeError(f'適用後の出力機器がAdobe PDFではありません: {config}')

    try: doc.SetVariable('BACKGROUNDPLOT',0)
    except Exception as exc: raise RuntimeError('同期印刷を設定できないためAdobe PDF出力を停止します。') from exc
    try: doc.ActiveLayout=layout
    except Exception as exc: raise RuntimeError(f'印刷対象レイアウトをアクティブにできません: {layout_name}\n{exc}') from exc

    if not layout_name or any(c in layout_name for c in '\r\n\x00'):
        raise RuntimeError('印刷対象レイアウト名が不正です。')
    log(f'Adobe PDF監視先: {watch_dir} / 図面: {stem} / Layout: {layout_name}')
    _ensure_command_idle(doc,timeout=5.0,log=log,keep_hidden=keep_hidden)
    expected=watch_dir/expected_name
    log(f'Adobe PDF検出対象（元CAD名＋半角スペース(1)）: {expected}')
    if expected.exists():
        log(f'注意: 印刷前から検出対象が存在します: {expected.name}。印刷前後のファイル情報・内容を比較して新規生成を判定します。')
    before=snapshot_pdfs([watch_dir],expected_name=expected_name,log=log)
    started=time.time()

    # Trial10g default route exactly:
    # Detailed plot configuration=N / Layout=explicit / Page setup=Enter /
    # Output device=Enter(current Adobe PDF) / Write plot to a file=N /
    # Save changes=N / Proceed=Y
    macro='\n'.join(['_.-PLOT','_N',layout_name,'','','_N','_N','_Y'])+'\n'
    log('Adobe PDF印刷開始: SendCommand / _.-PLOT')
    log('マクロ: 詳細設定=N / 現在のページ設定・出力デバイス / ファイル出力=N / 保存=N / 実行=Y')
    if keep_hidden: keep_hidden()
    try: doc.SendCommand(macro)
    except Exception as exc: raise RuntimeError(f'-PLOTマクロ送信に失敗しました: {exc}') from exc
    _wait_macro_complete(doc,started,timeout=45.0,log=log,keep_hidden=keep_hidden)
    active,last_cmd=_command_state(doc)
    log(f"-PLOTコマンド終了待ち完了: CMDACTIVE={active}, CMDNAMES={last_cmd or '(なし)'}")

    generated=wait_for_generated_pdf([watch_dir],before,stem,started,timeout=timeout,log=log,keep_hidden=keep_hidden,expected_name=expected_name)
    if generated is None:
        from .autocad_backend import AutoCADUnsafeState
        active,last_cmd=_command_state(doc)
        observed=', '.join(p.name for p in _pdf_files(watch_dir) if filename_key(p.name)==filename_key(expected_name)) or '(なし)'
        raise AutoCADUnsafeState(
            'マクロ印刷後、指定フォルダ内で新しい正常PDFを検出できませんでした。\n\n'
            f'監視フォルダ: {watch_dir}\n'
            f'検出対象: {expected_name}（元CAD名＋半角スペース(1)、新規・更新のみ）\n'
            f'同名候補: {observed}\n'
            f'待機時間: {timeout:g}秒\n'
            f"CMDNAMES: {last_cmd or '(なし)'}\n"
            'Adobe PDFの自動保存先を指定し、保存確認・PDFの自動表示をOFFにしてください。'
            '未完了ジョブとの混同を避けるため後続図面は停止します。'
        )
    log(f'Adobe PDF生成ファイル検出 = {generated.name}')
    return finalize_generated_pdf(generated,staged_output,log=log,
                                  remove_generated=_path_key(generated) not in before)

