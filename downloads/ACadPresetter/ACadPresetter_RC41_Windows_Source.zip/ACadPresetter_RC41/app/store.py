import json
import os
import shutil
from datetime import datetime
from pathlib import Path

from .models import DrawingList
from .preset_manager import PRESET_KINDS, ensure_ids


def read_text_compat(path):
    raw = Path(path).read_bytes()
    last = None
    for enc in ("utf-8-sig", "utf-8", "cp932", "shift_jis"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError as e:
            last = e
    raise last


def _atomic_json_write(path, value, backup=False):
    if isinstance(value, dict):
        value={"schema_version":1,**value}
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if backup and path.exists():
        backup_dir = path.parent.parent / "backup" if path.parent.name == "presets" else path.parent / "backup"
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        shutil.copy2(path, backup_dir / f"{path.stem}_{stamp}{path.suffix}.bak")
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


class Store:
    def __init__(self, data_dir):
        self.dir = Path(data_dir)
        self.preset_dir = self.dir / "presets"
        self.config_path = self.dir / "config.json"
        self.environment_path = self.dir / "autocad_environment.json"
        self.shared_cache_path = self.dir / "shared_presets_cache.json"
        self.shared_load_error = ""
        self.data = {}
        self.local_data = {}
        self.config = {}
        self._environment_cache = None
        self._environment_cache_mtime_ns = None

    def _ensure_paths(self):
        # Always keep mutable data beside the app/exe. Never redirect to PyInstaller _internal.
        self.dir.mkdir(parents=True, exist_ok=True)
        self.preset_dir.mkdir(parents=True, exist_ok=True)
        (self.dir / "backup").mkdir(parents=True, exist_ok=True)
        (self.dir / "logs").mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _read_json(path, default=None):
        path = Path(path)
        if not path.exists(): return default
        return json.loads(read_text_compat(path))

    def load(self):
        self._ensure_paths()
        self.config = self.load_config()
        self.data = self.load_presets()
        return self.data

    def save(self):
        self.save_presets(self.data)

    def load_config(self):
        self._ensure_paths()
        default = {
            "schema_version":1,
            "drop_group_mode":"ask", "restore_session":True,
            "existing_pdf_action":"確認する", "confirm_physical_print":True,
            "autocad_version":"自動", "prefer_running_autocad":True,
            "adobe_pdf_watch_dir":"", "adobe_pdf_timeout":120,
            "auto_refresh_autocad_environment":True,
            "shared_presets_enabled":False, "shared_presets_path":"",
            "shared_plot_resources_enabled":False, "shared_pc3_path":"", "shared_plot_style_path":"",
            "preset_backup_enabled":True, "preset_backup_retention":20,
            "log_enabled":True, "log_retention_days":30,
        }
        if not self.config_path.exists():
            self.config = default.copy(); self.save_config(self.config); return self.config
        obj = self._read_json(self.config_path, default)
        if not isinstance(obj, dict): raise ValueError(f"設定JSONの形式が不正です: {self.config_path}")
        if int(obj.get("schema_version",0))>1: raise ValueError("config.jsonの形式が新しすぎます。対応するバージョンで開いてください。")
        self.config = {**default, **obj}; return self.config

    def save_config(self, config=None):
        if config is not None: self.config = dict(config)
        self.config["schema_version"]=1
        _atomic_json_write(self.config_path, self.config, backup=False)

    def load_presets(self, refresh_shared=False):
        self.preset_dir.mkdir(parents=True, exist_ok=True)
        result = {}
        for kind in PRESET_KINDS:
            p = self.preset_dir / f"{kind}.json"
            obj = self._read_json(p, [])
            result[kind] = self._preset_items(obj, str(p))
        changed = ensure_ids(result)
        self.local_data = result
        if changed:
            self.data = result
            self.save_presets(result)
        self.data = self._merge_shared_presets(result, refresh=refresh_shared)
        return self.data

    @staticmethod
    def _preset_items(obj, label):
        if isinstance(obj, dict):
            if int(obj.get("schema_version",0))>1:
                raise ValueError(f"プリセットの形式が新しすぎます: {label}")
            obj=obj.get("items")
        if not isinstance(obj,list) or any(not isinstance(x,dict) for x in obj):
            raise ValueError(f"プリセットJSONの形式が不正です: {label}")
        return obj

    def _merge_shared_presets(self, local, refresh=False):
        merged = {k: [dict(x) for x in local.get(k, [])] for k in PRESET_KINDS}
        if not bool((self.config or {}).get("shared_presets_enabled", False)):
            return merged
        raw = str((self.config or {}).get("shared_presets_path", "")).strip()
        if not raw:
            return merged
        # Startup consults this local snapshot only. Never stat/open the shared
        # path unless the user explicitly presses the refresh control.
        self.shared_load_error=""
        shared={}
        try:
            cache=self._read_json(self.shared_cache_path,{})
            if cache.get("source")==raw:
                shared=cache.get("presets",{})
        except (OSError,ValueError,AttributeError):
            pass
        if refresh:
            try:
                src=Path(raw)
                if src.is_dir():
                    fresh={k:self._preset_items(self._read_json(src/f"{k}.json",[]),str(src/f"{k}.json")) for k in PRESET_KINDS}
                else:
                    if not src.is_file(): raise FileNotFoundError(raw)
                    obj=self._read_json(src,{})
                    if not isinstance(obj,dict): raise ValueError("共有プリセットはカテゴリを含むJSONにしてください。")
                    if int(obj.get("schema_version",0))>1: raise ValueError("共有プリセットの形式が新しすぎます。")
                    fresh={k:self._preset_items(obj.get(k,[]),k) for k in PRESET_KINDS}
                _atomic_json_write(self.shared_cache_path,{"source":raw,"presets":fresh})
                shared=fresh
            except (OSError,ValueError) as exc:
                self.shared_load_error=str(exc)
        try:
            local_ids = {x.get("id") for k in PRESET_KINDS for x in merged[k]}
            for kind in PRESET_KINDS:
                for item in shared.get(kind, []) or []:
                    if not isinstance(item, dict) or not item.get("id") or item.get("id") in local_ids: continue
                    cp = dict(item); cp["_shared"] = True; merged[kind].append(cp)
            return merged
        except Exception:
            # Shared storage is optional: network/path failures never block local operation.
            return merged

    def save_presets(self, presets=None):
        if presets is not None: self.data = presets
        local = {k: [{kk:vv for kk,vv in x.items() if kk != "_shared"} for x in self.data.get(k, []) if not x.get("_shared")] for k in PRESET_KINDS}
        self.local_data = local
        ensure_ids(local)
        self.preset_dir.mkdir(parents=True, exist_ok=True)
        backup_enabled = bool((self.config or {}).get("preset_backup_enabled", True))
        retention = max(1, int((self.config or {}).get("preset_backup_retention", 20)))
        for kind in PRESET_KINDS:
            path = self.preset_dir / f"{kind}.json"
            _atomic_json_write(path, {"schema_version":1,"kind":kind,"items":local.get(kind, [])}, backup=backup_enabled)
            if backup_enabled:
                backup_dir = path.parent.parent / "backup" if path.parent.name == "presets" else path.parent / "backup"
                files = sorted(backup_dir.glob(f"{path.stem}_*{path.suffix}.bak"), key=lambda x: x.stat().st_mtime, reverse=True)
                for old in files[retention:]:
                    try: old.unlink()
                    except OSError: pass

    def load_environment(self, force=False):
        """Load the AutoCAD environment cache only when the file actually changed."""
        from .autocad_environment import normalize_environment
        try:
            mtime_ns = self.environment_path.stat().st_mtime_ns
        except OSError:
            mtime_ns = None
        if not force and self._environment_cache is not None and mtime_ns == self._environment_cache_mtime_ns:
            return self._environment_cache
        obj = self._read_json(self.environment_path, {})
        env = normalize_environment(obj) if isinstance(obj, dict) and obj else {}
        self._environment_cache = env
        self._environment_cache_mtime_ns = mtime_ns
        return env

    def save_environment(self, environment):
        from .autocad_environment import normalize_environment
        env = normalize_environment(environment)
        _atomic_json_write(self.environment_path, env, backup=False)
        self._environment_cache = env
        try:
            self._environment_cache_mtime_ns = self.environment_path.stat().st_mtime_ns
        except OSError:
            self._environment_cache_mtime_ns = None

    def load_drawing_list(self, path):
        obj = self._read_json(path, {})
        if not isinstance(obj, dict): raise ValueError("acplistの形式が不正です")
        from .list_paths import resolve_list_paths
        dl=DrawingList.from_dict(obj)
        return DrawingList.from_dict(resolve_list_paths(dl.to_dict(),path))

    def save_drawing_list(self, path, drawing_list):
        value = drawing_list.to_dict() if isinstance(drawing_list, DrawingList) else DrawingList.from_dict(drawing_list).to_dict()
        from .list_paths import prepare_list_paths
        _atomic_json_write(path, prepare_list_paths(value,path), backup=False)
