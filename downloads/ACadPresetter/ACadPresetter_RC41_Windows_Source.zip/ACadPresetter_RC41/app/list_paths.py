"""Portable .acplist paths; resolve only when the user explicitly loads a list."""
from copy import deepcopy
import ntpath
import os
from pathlib import Path


def _files(payload):
    for entry in payload.get("entries",[]):
        if entry.get("type")=="group":
            yield from entry.get("items",[])
        else:
            yield entry


def prepare_list_paths(payload,list_file):
    data=deepcopy(payload)
    folder=Path(list_file).absolute().parent
    files=list(_files(data))
    native=[]
    for item in files:
        raw=str(item.get("path","") or "")
        if not raw:
            continue
        # Preserve Windows paths while inspecting/testing on another OS.
        foreign=os.name!="nt" and bool(ntpath.splitdrive(raw)[0])
        absolute=raw if foreign else str(Path(raw).absolute())
        item.update(path=absolute,absolute_path=absolute,relative_path="")
        if not foreign:
            native.append(Path(absolute).parent)
    try:
        base=Path(os.path.commonpath([str(folder),*(str(p) for p in native)]))
    except ValueError:  # Different drives: absolute path still works per item.
        base=folder
    data.update(schema_version=3,version=3,base_folder=str(base),
                saved_list_folder=str(folder),base_relative_to_list=os.path.relpath(base,folder))
    for item in files:
        raw=item.get("absolute_path","")
        if raw and not (os.name!="nt" and ntpath.splitdrive(raw)[0]):
            try: item["relative_path"]=os.path.relpath(raw,base)
            except ValueError: pass
    return data


def resolve_list_paths(payload,list_file):
    data=deepcopy(payload)
    folder=Path(list_file).absolute().parent
    base=data.get("base_folder","")
    base_rel=data.get("base_relative_to_list")
    moved_base=folder/base_rel if base_rel is not None else None
    relocated=bool(data.get("saved_list_folder")) and os.path.normcase(str(folder))!=os.path.normcase(data["saved_list_folder"])
    for item in _files(data):
        absolute=str(item.get("absolute_path") or item.get("path", ""))
        relative=str(item.get("relative_path") or "")
        portable=(moved_base/relative) if moved_base is not None and relative else None
        original=(Path(base)/relative) if base and relative else None
        candidates=([portable,Path(absolute) if absolute else None,original] if relocated else
                    [Path(absolute) if absolute else None,portable,original])
        for candidate in candidates:
            if candidate is not None and candidate.is_file():
                item["path"]=str(candidate.resolve())
                break
        else:
            item["path"]=absolute  # Leave missing paths available for manual relink.
    return data
