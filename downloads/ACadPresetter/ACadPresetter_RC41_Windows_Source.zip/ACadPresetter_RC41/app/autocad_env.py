import os, winreg
from pathlib import Path

def _registry_versions():
    found=[]
    roots=[
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Autodesk\AutoCAD"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Autodesk\AutoCAD"),
    ]
    for root,key in roots:
        try:
            with winreg.OpenKey(root,key) as k:
                i=0
                while True:
                    try: ver=winreg.EnumKey(k,i); i+=1
                    except OSError: break
                    try:
                        with winreg.OpenKey(k,ver) as vk:
                            j=0
                            while True:
                                try: sub=winreg.EnumKey(vk,j); j+=1
                                except OSError: break
                                try:
                                    with winreg.OpenKey(vk,sub) as sk:
                                        loc,_=winreg.QueryValueEx(sk,"AcadLocation")
                                        exe=Path(loc)/"acad.exe"
                                        if exe.exists(): found.append((ver,sub,str(exe)))
                                except OSError: pass
                    except OSError: pass
        except OSError: pass
    return found

def _common_paths():
    out=[]
    pf=Path(os.environ.get("ProgramFiles",r"C:\Program Files"))
    for year in ("2027","2026","2025","2024"):
        p=pf/"Autodesk"/f"AutoCAD {year}"/"acad.exe"
        if p.exists(): out.append((year,"",str(p)))
    return out

def detect_autocad():
    vals=_registry_versions()+_common_paths()
    unique={}
    for ver,sub,exe in vals: unique[exe.casefold()]={"version":ver,"product":sub,"exe":exe}
    def score(x):
        text=(x["version"]+" "+x["exe"])
        for y in ("2027","2026","2025","2024"):
            if y in text:return int(y)
        # AutoCAD R25.x ~= recent; leave below explicit year matches
        return 0
    return sorted(unique.values(),key=score,reverse=True)

def detect_status():
    items=detect_autocad()
    return {"found":bool(items),"items":items,"preferred":items[0] if items else None}
