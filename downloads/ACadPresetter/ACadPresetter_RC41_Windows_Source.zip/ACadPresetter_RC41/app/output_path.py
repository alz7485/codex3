from __future__ import annotations

import os
import re
from datetime import datetime
from pathlib import Path

INVALID_CHARS = '<>:"/\\|?*'
_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1,10)), *(f"LPT{i}" for i in range(1,10))}
_TOKEN_RE = re.compile(r"\{[^{}]+\}")


def sanitize_filename_component(value: str, replacement: str = "_") -> str:
    s = str(value or "")
    s = ''.join(replacement if (c in INVALID_CHARS or ord(c) < 32) else c for c in s)
    s = s.rstrip(' .')
    if s.split(".", 1)[0].rstrip(" ").upper() in _RESERVED:
        s = '_' + s
    return s


def render_pdf_stem(template: str, *, cad_name: str, group_name: str = "", plot_name: str = "", date_text: str | None = None) -> str:
    date_text = date_text or datetime.now().strftime('%Y%m%d')
    values = {
        "{CAD名}": sanitize_filename_component(cad_name),
        "{グループ名}": sanitize_filename_component(group_name),
        "{印刷設定名}": sanitize_filename_component(plot_name),
        "{日付}": sanitize_filename_component(date_text),
    }
    stem = str(template or "{CAD名}")
    for token, value in values.items():
        stem = stem.replace(token, value)
    # Unknown tokens are almost certainly a preset typo; do not silently create braces in names.
    if _TOKEN_RE.search(stem):
        raise ValueError(f"未対応のファイル名項目があります: {_TOKEN_RE.search(stem).group(0)}")
    stem = sanitize_filename_component(stem).strip()
    if not stem:
        raise ValueError("PDFファイル名が空になります。")
    return stem


def resolve_output_dir(source: str | Path, dest: dict) -> Path:
    src = Path(source)
    mode = str((dest or {}).get('mode', 'CADと同じ'))
    value = str((dest or {}).get('path', '') or '').strip()
    if mode == 'CADと同じ':
        return src.parent
    if mode in ('相対パス', 'サブフォルダ'):
        if not value:
            raise ValueError('PDF保存先の相対パスが空です。')
        # Relative means relative. Reject drive/UNC/absolute values instead of producing surprising paths.
        pv = Path(value)
        if pv.is_absolute() or re.match(r'^[A-Za-z]:[\\/]', value) or value.startswith('\\\\'):
            raise ValueError('相対パスには相対フォルダを指定してください。')
        return Path(os.path.normpath(str(src.parent / pv)))
    if mode == '固定フォルダ':
        if not value:
            raise ValueError('固定PDF保存先が未設定です。')
        return Path(value)
    # Older data used any non-special mode as fixed path.
    if value:
        return Path(value)
    raise ValueError(f'未対応のPDF保存方法です: {mode}')


def build_pdf_path(source: str | Path, dest: dict, name_preset: dict, *, group_name: str = '', plot_name: str = '', date_text: str | None = None) -> Path:
    src = Path(source)
    outdir = resolve_output_dir(src, dest)
    stem = render_pdf_stem((name_preset or {}).get('template', '{CAD名}'), cad_name=src.stem, group_name=group_name, plot_name=plot_name, date_text=date_text)
    return outdir / (stem + '.pdf')
