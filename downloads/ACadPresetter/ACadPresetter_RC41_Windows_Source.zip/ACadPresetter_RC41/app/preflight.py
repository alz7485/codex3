from .plot_settings import validate_plot_values
from dataclasses import dataclass, field
from pathlib import Path
import os
import tempfile
from .autocad_environment import validate_plot_preset, media_for_device


@dataclass
class PreflightIssue:
    level: str          # fatal / file_error / warning
    name: str
    message: str
    source: str = ""
    kind: str = ""


@dataclass
class PreflightReport:
    issues: list = field(default_factory=list)

    @property
    def fatal(self):
        return [x for x in self.issues if x.level == "fatal"]

    @property
    def file_errors(self):
        return [x for x in self.issues if x.level == "file_error"]

    @property
    def warnings(self):
        return [x for x in self.issues if x.level == "warning"]

    def blocked_sources(self):
        return {x.source for x in self.file_errors if x.source}


def _issue(report, level, job, message, kind=""):
    source = str(job.get("source", "")) if job else ""
    name = Path(source).name if source else "ACadPresetter"
    report.issues.append(PreflightIssue(level, name, message, source, kind))


def build_report(pdf_jobs, print_jobs, environment=None):
    """Lightweight preflight. Does not start AutoCAD or inspect layouts.

    Fatal errors stop the whole run. File errors block only that drawing.
    Warnings are informational/confirmable and never silently change settings.
    """
    report = PreflightReport()
    env = environment or {}
    devices = {str(x).casefold() for x in env.get("devices", [])}
    styles = {str(x).casefold() for x in env.get("styles", [])}
    all_jobs = list(pdf_jobs) + list(print_jobs)

    if not all_jobs:
        report.issues.append(PreflightIssue("fatal", "ACadPresetter", "出力対象がありません。"))
        return report

    # Source/settings validation. A source problem blocks both PDF/print jobs for that drawing.
    checked_sources = set()
    for j in all_jobs:
        src = Path(j.get("source", ""))
        source_key = str(src)
        st = j.get("settings") or {}
        if source_key not in checked_sources:
            checked_sources.add(source_key)
            if not src.exists():
                _issue(report, "file_error", j, "元CADファイルがありません。")
                continue
            if src.suffix.lower() not in (".dwg", ".dxf"):
                _issue(report, "file_error", j, "DWG/DXFではありません。")
            elif not os.access(src, os.R_OK):
                _issue(report, "file_error", j, "元CADファイルを読み込めません。")

        # DWG-settings mode is resolved after opening the drawing.
        if st.get("setting_method") == "DWG/DXFに保存されている設定を使用":
            continue
        for msg in validate_plot_values(st):
            _issue(report, "file_error", j, msg)
        device = str(st.get("device", "")).strip()
        style = str(st.get("plot_style", "")).strip()
        if device and devices and device.casefold() not in devices:
            _issue(report, "file_error", j, f"現在のAutoCAD環境にプリンター/PC3がありません: {device}")
        if style and styles and style.casefold() not in styles:
            _issue(report, "file_error", j, f"現在のAutoCAD環境にCTB/STBがありません: {style}")
        # Cached media can be stale or canonical names rather than A3/A1 labels.
        # Actual device selection and strict media validation happen at plotting.
        paper=str(st.get("paper","")).strip()
        cached_media=media_for_device(env,device)
        if paper and cached_media:
            from .media_names import resolve_media_name
            try: resolve_media_name(paper,cached_media)
            except ValueError:
                _issue(report, "warning", j, f"用紙「{paper}」をキャッシュで確認できません。出力時に「{device}」の最新の用紙一覧で照合します。")
        for msg in validate_plot_preset(st, env, check_media=False):
            _issue(report, "file_error", j, msg)

    # PDF destination validation and collision detection.
    seen = {}
    tested_parents = {}
    for j in pdf_jobs:
        src = Path(j.get("source", ""))
        out = Path(j.get("output", ""))
        if not str(out):
            _issue(report, "file_error", j, "PDF出力先が未設定です。", "PDF")
            continue
        key = str(out.resolve(strict=False)).casefold()
        if key in seen:
            _issue(report, "file_error", j, f"PDF出力先が重複しています: {out}", "PDF")
            # The first source must also be blocked; add a paired issue.
            first = next((x for x in pdf_jobs if str(Path(x.get("source", ""))) == seen[key]), None)
            if first:
                _issue(report, "file_error", first, f"PDF出力先が重複しています: {out}", "PDF")
        else:
            seen[key] = str(src)

        parent = out.parent
        pkey = str(parent.resolve(strict=False)).casefold()
        if pkey not in tested_parents:
            try:
                parent.mkdir(parents=True, exist_ok=True)
                # Never truncate a pre-existing file, even one with our probe name.
                with tempfile.NamedTemporaryFile(prefix=".acad_presetter_", suffix=".tmp", dir=parent):
                    pass
                tested_parents[pkey] = True
            except Exception as e:
                tested_parents[pkey] = False
                report.issues.append(PreflightIssue("fatal", "ACadPresetter", f"PDF保存先へ書き込めません: {parent} ({e})"))
        if out.exists():
            _issue(report, "warning", j, f"同名PDFが既に存在します: {out.name}", "PDF")

    for j in print_jobs:
        st = j.get("settings") or {}
        if st.get("setting_method") != "DWG/DXFに保存されている設定を使用" and not str(st.get("device", "")).strip():
            _issue(report, "file_error", j, "物理プリンターが未設定です。", "PRINT")

    # Deduplicate identical issues caused by PDF+printer dual jobs.
    unique = []
    keys = set()
    for x in report.issues:
        key = (x.level, x.source, x.message)
        if key not in keys:
            keys.add(key); unique.append(x)
    report.issues = unique
    return report


def check_jobs(pdf_jobs, print_jobs, environment=None):
    """Backward-compatible tuple API used by older tests/code."""
    report = build_report(pdf_jobs, print_jobs, environment)
    level_map = {"fatal": "エラー", "file_error": "エラー", "warning": "警告"}
    return [(level_map[x.level], x.name, x.message) for x in report.issues]
