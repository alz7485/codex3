from pathlib import Path

def test_new_group_expansion_is_deferred_until_after_rejudge():
    text=Path('main.py').read_text(encoding='utf-8')
    assert 'self._pending_new_group_states[gid]' in text
    assert 'def _apply_pending_new_group_states' in text
    rejudge=text[text.index('    def rejudge(self):'):text.index('    def open_preset_manager', text.index('    def rejudge(self):'))]
    assert rejudge.index('self._apply_auto_order_to_tree()') < rejudge.index('self._apply_pending_new_group_states()')

def test_group_selected_uses_deferred_expansion():
    text=Path('main.py').read_text(encoding='utf-8')
    section=text[text.index('    def group_selected(self):'):text.index('    def ungroup_selected', text.index('    def group_selected(self):'))]
    assert '_pending_new_group_states[gid]' in section
    assert '_apply_pending_new_group_states()' in section
