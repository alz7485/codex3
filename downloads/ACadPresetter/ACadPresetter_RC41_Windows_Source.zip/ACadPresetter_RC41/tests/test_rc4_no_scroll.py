from pathlib import Path

def test_preset_manager_no_scroll():
    text = (Path(__file__).parents[1] / "main.py").read_text(encoding="utf-8")
    block = text[text.index("class PresetDialog"):text.index("class CadListTree")]
    assert "QScrollArea()" not in block
    assert "availableGeometry().height()" in block
    assert "min(900, available_h - 24)" in block
    assert "self.resize(900, dialog_h)" in block
