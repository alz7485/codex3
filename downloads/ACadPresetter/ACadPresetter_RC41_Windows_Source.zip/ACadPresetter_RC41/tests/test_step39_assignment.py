from app.rules import resolve_file_detail


def _data():
    return {
        "rule":[
            {"id":"r_generic","name":"A3","conditions":[{"mode":"含む","value":"A3"}]},
            {"id":"r_cover","name":"表紙A3","relation":"AND","conditions":[{"mode":"含む","value":"A3"},{"mode":"含む","value":"COVER"}]},
        ],
        "plot":[{"id":"p1","name":"通常A3"},{"id":"p2","name":"表紙"},{"id":"p3","name":"既定"}],
    }


def test_first_matching_pair_wins():
    data=_data(); col={"pairs":[{"rule_id":"r_cover","plot_id":"p2"},{"rule_id":"r_generic","plot_id":"p1"}]}
    x=resolve_file_detail("P01_A3_COVER.dwg",col,data)
    assert x["plot"]["id"]=="p2" and x["rule"]["id"]=="r_cover" and x["priority"]==1


def test_collection_order_changes_result():
    data=_data(); col={"pairs":[{"rule_id":"r_generic","plot_id":"p1"},{"rule_id":"r_cover","plot_id":"p2"}]}
    x=resolve_file_detail("P01_A3_COVER.dwg",col,data)
    assert x["plot"]["id"]=="p1" and x["priority"]==1


def test_default_assignment_has_reason():
    data=_data(); col={"pairs":[],"default_plot_id":"p3"}
    x=resolve_file_detail("UNKNOWN.dxf",col,data)
    assert x["source"]=="default" and x["rule"] is None and x["plot"]["id"]=="p3"


def test_no_collection_is_unassigned():
    x=resolve_file_detail("P01.dwg",None,_data())
    assert x["source"]=="none" and x["plot"] is None
