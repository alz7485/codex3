import json, os, time
from pathlib import Path
from app.store import Store
from app.run_history import RunHistory
from app.output_log import OutputLogger


def test_shared_presets_merge_readonly_and_not_saved(tmp_path):
    data=tmp_path/'data'; shared=tmp_path/'shared.json'
    st=Store(data); st.load_config()
    shared.write_text(json.dumps({'plot':[{'id':'shared_plot','name':'共有A3'}]},ensure_ascii=False),encoding='utf-8')
    st.config.update(shared_presets_enabled=True,shared_presets_path=str(shared)); st.save_config(); st.load_presets(refresh_shared=True)
    item=next(x for x in st.data['plot'] if x['id']=='shared_plot')
    assert item['_shared'] is True
    st.save()
    local=json.loads((data/'presets'/'plot.json').read_text(encoding='utf-8'))
    assert all(x.get('id')!='shared_plot' for x in local['items'])


def test_shared_failure_does_not_break_local(tmp_path):
    st=Store(tmp_path/'data'); st.load_config(); st.config.update(shared_presets_enabled=True,shared_presets_path=str(tmp_path/'missing.json')); st.save_config()
    assert isinstance(st.load(),dict)


def test_output_log_written_on_finish(tmp_path):
    cfg={'log_enabled':True,'log_retention_days':30}
    rh=RunHistory(tmp_path,cfg); rec=rh.begin([{'source':'a.dwg','kind':'PDF','output':'a.pdf'}]); rh.update(rec,'a.dwg','PDF','成功'); rh.finish(rec)
    logs=list((tmp_path/'data'/'logs').glob('output_*.json'))
    assert len(logs)==1 and json.loads(logs[0].read_text(encoding='utf-8'))['jobs'][0]['status']=='成功'


def test_output_log_off_has_no_log_io(tmp_path):
    rh=RunHistory(tmp_path,{'log_enabled':False}); rec=rh.begin([]); rh.finish(rec)
    assert not (tmp_path/'data'/'logs').exists()


def test_log_retention_cleanup(tmp_path):
    d=tmp_path/'data'/'logs'; d.mkdir(parents=True); old=d/'output_old.json'; old.write_text('{}')
    past=time.time()-10*86400; os.utime(old,(past,past))
    lg=OutputLogger(tmp_path/'data',{'log_enabled':True,'log_retention_days':3}); lg.write({'ok':True})
    assert not old.exists()
