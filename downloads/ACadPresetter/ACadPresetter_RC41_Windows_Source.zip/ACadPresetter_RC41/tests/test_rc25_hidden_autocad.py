from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
VIS=(ROOT/'app'/'autocad_visibility.py').read_text(encoding='utf-8')
BACK=(ROOT/'app'/'autocad_backend.py').read_text(encoding='utf-8')

def test_guard_hides_every_window_of_owned_pid():
    assert 'EnumWindows' in VIS
    assert 'int(pid.value) != self._pid' in VIS
    assert 'ShowWindowAsync(hwnd, 0)' in VIS

def test_guard_is_fast_and_does_not_use_com():
    assert '_stop.wait(0.01)' in VIS
    assert 'win32com' not in VIS

def test_open_is_bracketed_by_hidden_guard():
    block=BACK[BACK.index('def _open_for_session'):BACK.index('def plot_batch_pdf')]
    assert block.count('_keep_session_hidden(session)') >= 2
    assert 'session._window_guard.hide_now()' in block
