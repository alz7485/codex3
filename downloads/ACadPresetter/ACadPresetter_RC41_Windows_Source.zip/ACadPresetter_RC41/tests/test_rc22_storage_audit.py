import json
import shutil
from pathlib import Path
from unittest.mock import Mock

import pytest

from app.models import DrawingList, DrawingGroup, DrawingItem
from app.store import Store
from app.session import SessionManager
from app.run_history import RunHistory


def test_moved_project_uses_relative_files_even_when_original_still_exists(tmp_path):
    old=tmp_path/"old"
    (old/"cad").mkdir(parents=True)
    (old/"lists").mkdir()
    a=old/"cad"/"A.dwg"; b=old/"cad"/"B.dxf"
    a.touch(); b.touch()
    store=Store(tmp_path/"data")
    listing=old/"lists"/"work.acplist"
    store.save_drawing_list(listing,DrawingList(collection_id="collection",entries=[
        DrawingGroup("工事A",[DrawingItem(str(a),manual_plot_id="manual")]),DrawingItem(str(b)),
    ]))
    raw=json.loads(listing.read_text())
    assert raw["schema_version"]==3 and raw["base_folder"]==str(old)
    item=raw["entries"][0]["items"][0]
    assert item["absolute_path"]==str(a) and Path(item["relative_path"])==Path("cad/A.dwg")
    assert "checked" not in str(raw) and "run_state" not in str(raw)
    new=tmp_path/"new"; shutil.copytree(old,new)
    got=store.load_drawing_list(new/"lists"/"work.acplist")
    assert got.entries[0].items[0].path==str(new/"cad"/"A.dwg")
    assert got.entries[0].items[0].manual_plot_id=="manual"
    assert got.entries[1].path==str(new/"cad"/"B.dxf")
    assert got.collection_id=="collection"


def test_old_preset_arrays_migrate_on_save_with_ids_and_order(tmp_path):
    st=Store(tmp_path/"data"); st.load_config()
    path=st.preset_dir/"plot.json"
    items=[{"id":"second","name":"配管A3"},{"id":"first","name":"配管A1"}]
    path.write_bytes(json.dumps(items,ensure_ascii=False).encode("cp932"))
    st.load_presets(); st.save()
    obj=json.loads(path.read_text())
    assert obj["schema_version"]==1 and obj["items"]==items
    assert Store(st.dir).load()["plot"]==items


def test_newer_config_schema_is_not_overwritten(tmp_path):
    st=Store(tmp_path/"data"); st.dir.mkdir()
    raw='{"schema_version":999,"setting":"keep"}'
    st.config_path.write_text(raw)
    with pytest.raises(ValueError,match="新しすぎ"):
        st.load()
    assert st.config_path.read_text()==raw


def test_shared_only_read_when_explicitly_refreshed_and_cache_is_readonly(tmp_path,monkeypatch):
    shared=tmp_path/"shared.json"
    shared.write_text(json.dumps({"plot":[{"id":"shared","name":"共有"}]}))
    st=Store(tmp_path/"data"); st.load_config()
    st.config.update(shared_presets_enabled=True,shared_presets_path=str(shared)); st.save_config()
    assert not st.load()["plot"]
    st.load_presets(refresh_shared=True)
    assert st.data["plot"][0]["_shared"]
    source_bytes=shared.read_bytes()
    st.save()
    assert shared.read_bytes()==source_bytes
    shared.unlink()
    original_read=Store._read_json
    def guarded(path,default=None):
        assert Path(path)!=shared, "Startup touched shared storage"
        return original_read(path,default)
    monkeypatch.setattr(Store,"_read_json",staticmethod(guarded))
    new=Store(st.dir)
    assert new.load()["plot"][0]["id"]=="shared"
    monkeypatch.setattr(Store,"_read_json",staticmethod(original_read))
    new.load_presets(refresh_shared=True)
    assert new.shared_load_error and new.data["plot"][0]["id"]=="shared"


def test_changed_shared_source_does_not_reuse_wrong_snapshot(tmp_path):
    st=Store(tmp_path/"data"); st.load_config()
    st.config.update(shared_presets_enabled=True,shared_presets_path="new-server")
    st.shared_cache_path.write_text(json.dumps({"source":"old-server","presets":{"plot":[{"id":"old"}]}}))
    assert not st.load_presets()["plot"]


def test_session_and_history_schema_and_legacy_encoding(tmp_path):
    session=SessionManager(tmp_path/"session.json")
    session.path.write_bytes('{"collection_id":"配管"}'.encode("cp932"))
    assert session.load()["collection_id"]=="配管"
    session.save(session.load())
    assert json.loads(session.path.read_text())["schema_version"]==1
    history=RunHistory(tmp_path)
    history.begin([])
    assert json.loads(history.path.read_text())["schema_version"]==1


def test_startup_never_restores_drawings_or_connects_autocad(tmp_path,monkeypatch):
    pytest.importorskip("PySide6")
    from PySide6.QtWidgets import QApplication
    import main
    app=QApplication.instance() or QApplication([])
    monkeypatch.setattr(main,"APP_DIR",tmp_path)
    connect=Mock(side_effect=AssertionError("AutoCAD accessed at startup"))
    monkeypatch.setattr(main.AutoCADBackend,"connect",connect)
    data=tmp_path/"data"; data.mkdir()
    (data/"session.json").write_text(json.dumps({"items":[{"type":"file","text":"old.dwg","path":"//offline-server/old.dwg"}]}))
    window=main.MainWindow()
    assert window.tree.topLevelItemCount()==0
    connect.assert_not_called()
    window.close()
    app.processEvents()


def test_refreshing_plot_environment_does_not_accumulate_media_handlers(tmp_path,monkeypatch):
    pytest.importorskip("PySide6")
    from PySide6.QtWidgets import QApplication,QPushButton,QComboBox
    from PySide6.QtCore import SIGNAL
    import main
    app=QApplication.instance() or QApplication([])
    store=Store(tmp_path/"data"); store.load()
    store.data["plot"]=[{"id":"plot","name":"A3","device":"Adobe PDF","paper":"A3"}]
    store.save()
    env={"devices":["Adobe PDF","Other"],"device_media":{"Adobe PDF":["A3"],"Other":["A4"]}}
    monkeypatch.setattr(main,"probe_plot_environment",lambda *_:env)
    monkeypatch.setattr(main.QMessageBox,"information",lambda *_:None)
    dialog=main.PresetDialog(store)
    button=next(b for b in dialog.findChildren(QPushButton) if b.text()=="AutoCAD環境を更新")
    button.click()
    env["device_media"]["Adobe PDF"]=["A1","A3"]
    button.click()
    device=next(c for c in dialog.findChildren(QComboBox) if getattr(c,"_media_update_slot",None) is not None and c.currentText()=="Adobe PDF")
    assert device.receivers(SIGNAL("currentTextChanged(QString)"))==1
    device.setCurrentText("Other")
    dialog.close()
    app.processEvents()
