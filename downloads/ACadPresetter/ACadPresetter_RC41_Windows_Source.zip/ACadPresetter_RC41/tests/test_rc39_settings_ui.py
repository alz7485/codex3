from unittest.mock import Mock
import pytest
pytest.importorskip('PySide6')
from PySide6.QtWidgets import QApplication,QDialog,QLineEdit,QSpinBox,QDialogButtonBox,QPushButton,QLabel


def test_settings_match_required_folder_and_save_wait_time(tmp_path,monkeypatch):
    import main
    app=QApplication.instance() or QApplication([])
    monkeypatch.setattr(main,'APP_DIR',tmp_path)
    connect=Mock(side_effect=AssertionError('settings must not start AutoCAD'))
    monkeypatch.setattr(main.AutoCADBackend,'connect',connect)
    window=main.MainWindow()
    folder=tmp_path/'Adobe output';folder.mkdir()
    def inspect_and_save(dialog):
        fields=dialog.findChildren(QLineEdit)
        path=next(w for w in fields if 'Adobe使用時は必須' in w.placeholderText())
        assert '未指定＝自動検出' not in path.placeholderText()
        path.setText(str(folder))
        spin=dialog.findChild(QSpinBox,'adobe_pdf_timeout')
        assert spin.value()==120 and spin.minimum()==30 and spin.maximum()==600
        spin.setValue(180)
        notes=[w.text() for w in dialog.findChildren(QLabel)]
        assert any('最終PDF保存先はプリセット' in text for text in notes)
        buttons=dialog.findChild(QDialogButtonBox)
        buttons.button(QDialogButtonBox.Save).click()
        return QDialog.Accepted
    monkeypatch.setattr(QDialog,'exec',inspect_and_save)
    window.show_app_settings()
    assert window.store.config['adobe_pdf_watch_dir']==str(folder)
    assert window.store.config['adobe_pdf_timeout']==180
    connect.assert_not_called()
    window.close();app.processEvents()
