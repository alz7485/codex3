from pathlib import Path

from app.adobe_pdf import is_adobe_pdf_device, ensure_adobe_pdf_document_fonts
from app.list_order import auto_order_enabled, order_paths


ROOT = Path(__file__).resolve().parents[1]


def test_adobe_pdf_is_supported_device_name():
    assert is_adobe_pdf_device("Adobe PDF")
    assert is_adobe_pdf_device("Adobe PDF.pc3")
    assert not is_adobe_pdf_device("DWG To PDF.pc3")


def test_adobe_helper_is_safe_off_windows():
    # CI is non-Windows; helper must stay a harmless no-op rather than make Adobe
    # PDF an unsupported device.
    r = ensure_adobe_pdf_document_fonts("Adobe PDF")
    assert r.applicable is True


def test_legacy_merge_preset_without_enabled_still_auto_orders():
    # Older preset JSON showed the merge checkbox as ON by default but did not
    # necessarily persist the 'enabled' key.  UI and ordering must agree.
    merge = {"order": "自動並び替え", "sort_rule_ids": ["r_cover", "r_a3"]}
    rules = [
        {"id": "r_cover", "name": "表紙", "conditions": [{"mode": "含む", "value": "COVER"}]},
        {"id": "r_a3", "name": "A3", "conditions": [{"mode": "含む", "value": "A3"}]},
    ]
    assert auto_order_enabled(merge)
    src = ["P10_A3.dwg", "DETAIL.dwg", "COVER.dwg", "P2_A3.dwg"]
    assert order_paths(src, merge, rules) == ["COVER.dwg", "P2_A3.dwg", "P10_A3.dwg", "DETAIL.dwg"]


def test_rc8_uses_one_hidden_autocad_batch_session():
    main = (ROOT / "main.py").read_text(encoding="utf-8")
    backend = (ROOT / "app" / "autocad_backend.py").read_text(encoding="utf-8")
    assert "AutoCADBatchSession(conn_opts)" in main
    assert "session=acad_session" in main
    assert "visible=False" in backend
    assert "class AutoCADBatchSession" in backend
    # Batch output paths must not force an AutoCAD window visible.
    pdf_section = backend[backend.index("def plot_batch_pdf"):backend.index("def save_page_setup")]
    assert "visible=True" not in pdf_section


def test_collection_change_has_explicit_rejudge_handler():
    main = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "self.collection.currentIndexChanged.connect(self._on_collection_changed)" in main
    assert "def _on_collection_changed(self, *_args):" in main
    assert "self.rejudge()" in main[main.index("def _on_collection_changed"):main.index("def selected_cad_paths")]
