from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'main.py').read_text(encoding='utf-8')

def test_required_qt_widgets_imported():
    assert 'QTabWidget' in MAIN.split(')\nfrom app.store',1)[0]
    assert 'QPlainTextEdit' in MAIN.split(')\nfrom app.store',1)[0]

def test_app_name_and_page_setup_prefix_are_current():
    assert 'self.setWindowTitle("ACadPresetter")' in MAIN
    assert 'setup_name="ACadPresetter_"' in MAIN
    assert 'setup_name="CADOutput_"' not in MAIN

def test_session_does_not_persist_target_check():
    block=MAIN[MAIN.index('    def session_dict(self):'):MAIN.index('    def save_session', MAIN.index('    def session_dict(self):'))]
    assert 'checked=' not in block

def test_only_one_context_menu_signal_connection():
    assert MAIN.count('customContextMenuRequested.connect(')==1
    assert 'customContextMenuRequested.connect(self.file_context_menu)' in MAIN

def test_selected_paths_uses_current_dict_model():
    block=MAIN[MAIN.index('    def selected_cad_paths(self):'):MAIN.index('    def choose_source_dwg_for_settings', MAIN.index('    def selected_cad_paths(self):'))]
    assert 'data.get("type")' in block
    assert 'cd.get("path")' in block
