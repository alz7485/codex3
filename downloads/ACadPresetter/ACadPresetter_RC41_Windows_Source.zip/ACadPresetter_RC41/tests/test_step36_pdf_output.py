from pdf_fixtures import write_pdf, pdf_bytes
from pathlib import Path
import pytest
from app.pdf_output import PdfOutputSession, existing_outputs


def test_atomic_commit_preserves_old_until_valid(tmp_path):
    final=tmp_path/'x.pdf'; final.write_bytes(b'%PDF-old')
    bad=tmp_path/'bad.pdf'; bad.write_bytes(b'bad')
    with pytest.raises(RuntimeError): PdfOutputSession.atomic_commit(bad, final)
    assert final.read_bytes()==b'%PDF-old'


def test_atomic_commit_replaces_after_validation(tmp_path):
    final=tmp_path/'x.pdf'; final.write_bytes(b'%PDF-old')
    new=tmp_path/'new.pdf'; write_pdf(new)
    PdfOutputSession.atomic_commit(new, final)
    assert final.read_bytes()==new.read_bytes()


def test_session_unique_temp_and_cleanup(tmp_path):
    s=PdfOutputSession(tmp_path)
    a=s.stage('a.dwg',str(tmp_path/'same.pdf')); b=s.stage('b.dwg',str(tmp_path/'same.pdf'))
    assert a.temp_path != b.temp_path
    run=s.run_dir; assert run.exists(); s.cleanup(); assert not run.exists()


def test_existing_outputs(tmp_path):
    a=tmp_path/'a.pdf'; a.write_bytes(b'%PDF-x')
    assert existing_outputs([str(a),str(tmp_path/'b.pdf')])==[str(a)]
