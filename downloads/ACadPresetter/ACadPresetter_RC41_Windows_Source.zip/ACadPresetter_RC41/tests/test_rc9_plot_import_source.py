from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")


def _import_block():
    start = MAIN.index("            def import_from_dwg():")
    end = MAIN.index("            import_dwg.clicked.connect(import_from_dwg)", start)
    return MAIN[start:end]


def test_plot_import_can_choose_from_registered_list_and_file_dialog():
    block = _import_block()
    assert 'ff.addRow("リストから選択",list_source)' in block
    assert 'for path in self.registered_cad_paths()' in block
    assert 'ff.addRow("ファイルから選択",filerow)' in block
    assert 'QFileDialog.getOpenFileName' in block
    assert 'list_source.currentIndexChanged.connect(select_from_list)' in block
    assert 'browse.clicked.connect(choose_file)' in block


def test_plot_import_starts_blank_each_time():
    block = _import_block()
    assert 'list_source.addItem("（リストから選択してください）", None)' in block
    assert 'file_source.setPlaceholderText("未選択")' in block
    assert 'reset_loaded_source()' in block
    # The old recent-file mechanism must not preselect/reload the previous source.
    assert 'src.addItems(recent)' not in block
    assert 'if src.currentText(): load_source(src.currentText())' not in block
    assert 'self.store.config["plot_import_recent"]' not in block


def test_registered_source_uses_all_main_list_cad_files_not_selection_only():
    assert 'def registered_cad_paths(self):' in MAIN
    helper = MAIN[MAIN.index('    def registered_cad_paths(self):'):MAIN.index('    def reload(self):')]
    assert 'owner.all_file_items()' in helper
    assert 'selectedItems()' not in helper
    assert 'path.lower().endswith((".dwg",".dxf"))' in helper
