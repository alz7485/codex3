from app.plot_settings import normalize_plot_settings, validate_plot_values
from app.autocad_backend import _apply_plot_settings


def base_settings(**kw):
    d={
        "device":"", "paper":"", "plot_style":"", "plot_area":"レイアウト",
        "fit_to_paper":False, "center_plot":True,
        "lineweights":True,"transparency":False,"plot_styles":True,"rotation":"0°",
    }
    d.update(kw)
    return d


def test_legacy_missing_custom_scale_does_not_become_one_to_one():
    s=normalize_plot_settings({"fit_to_paper":False})
    assert s["scale_num"] is None
    assert s["scale_den"] is None
    assert not [x for x in validate_plot_values({"device":"x","paper":"A3","fit_to_paper":False}) if "尺度" in x]


def test_apply_missing_custom_scale_never_calls_setcustomscale():
    calls=[]
    class L:
        ConfigName=""; CanonicalMediaName=""; StyleSheet=""; PlotType=5
        CenterPlot=True; UseStandardScale=False; StandardScale=0
        PlotWithLineweights=True; PlotTransparency=False; PlotWithPlotStyles=True; PlotRotation=0
        PlotOrigin=(0.0,0.0)
        def RefreshPlotDeviceInfo(self): pass
        def SetCustomScale(self,a,b): calls.append((a,b))
    _apply_plot_settings(L(), base_settings())
    assert calls == []


def test_window_plain_tuple_is_first_choice():
    calls=[]
    class L:
        ConfigName=""; CanonicalMediaName=""; StyleSheet=""; PlotType=5
        CenterPlot=False; UseStandardScale=True; StandardScale=0
        PlotWithLineweights=True; PlotTransparency=False; PlotWithPlotStyles=True; PlotRotation=0
        PlotOrigin=(0.0,0.0)
        def RefreshPlotDeviceInfo(self): pass
        def SetWindowToPlot(self,a,b): calls.append((a,b))
    _apply_plot_settings(L(), base_settings(plot_area="窓",fit_to_paper=True,
        window_x1=1,window_y1=2,window_x2=11,window_y2=12))
    assert calls == [((1.0,2.0),(11.0,12.0))]
