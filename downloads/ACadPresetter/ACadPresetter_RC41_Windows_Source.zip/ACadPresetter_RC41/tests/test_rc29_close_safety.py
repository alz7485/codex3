from pathlib import Path
import pytest

from app.autocad_backend import (
    AutoCADUnsafeState,
    _looks_like_connection_loss,
    _safe_close_owned_document,
)


class _Session:
    def __init__(self):
        self.hidden_checks = 0
    def ensure_hidden(self):
        self.hidden_checks += 1


class _DocOK:
    FullName = r"C:\\work\\ok.dwg"
    def __init__(self):
        self.calls=[]
    def Close(self, save):
        self.calls.append(save)


class _DocFail:
    FullName = r"C:\\work\\locked.dwg"
    def Close(self, save):
        raise RuntimeError("AutoCAD is busy")


def test_safe_close_keeps_trial10g_fail_hard_behavior():
    session=_Session(); doc=_DocOK()
    assert _safe_close_owned_document(session,doc) is True
    assert doc.calls == [False]
    assert session.hidden_checks == 1


def test_close_failure_is_fatal_for_batch_continuation():
    with pytest.raises(AutoCADUnsafeState) as exc:
        _safe_close_owned_document(_Session(),_DocFail())
    text=str(exc.value)
    assert "次の図面は開かず" in text
    assert "locked.dwg" in text
    assert _looks_like_connection_loss(exc.value) is True


def test_all_owned_document_close_paths_use_strict_helper():
    text=Path('app/autocad_backend.py').read_text(encoding='utf-8')
    # Direct Close(False) is allowed only inside the single strict helper.
    assert text.count('doc.Close(False)') == 1
    for name in ('plot_batch_pdf','print_batch','save_page_setup','list_layouts','plot_layouts_pdf','inspect_drawing_plot_settings'):
        start=text.index(f'def {name}')
        next_def=text.find('\ndef ',start+5)
        block=text[start: next_def if next_def!=-1 else len(text)]
        assert '_safe_close_owned_document' in block, name


def test_batch_marks_following_drawings_unprocessed_after_close_failure():
    text=Path('app/autocad_backend.py').read_text(encoding='utf-8')
    for name in ('plot_batch_pdf','print_batch'):
        start=text.index(f'def {name}')
        next_def=text.find('\ndef ',start+5)
        block=text[start: next_def if next_def!=-1 else len(text)]
        assert '前の図面を閉じられなかったため未処理' in block
        assert 'if fatal: break' in block
