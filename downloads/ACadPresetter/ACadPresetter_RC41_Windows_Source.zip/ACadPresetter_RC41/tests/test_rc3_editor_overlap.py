from pathlib import Path


def test_editor_disposal_detaches_widgets_immediately():
    src = (Path(__file__).parents[1] / "main.py").read_text(encoding="utf-8")
    assert "def _dispose_layout_widgets" in src
    assert "w.hide()" in src
    assert "w.setParent(None)" in src
    assert "self._dispose_layout_widgets(body_lay)" in src
    assert "self._dispose_layout_widgets(lay)" in src
