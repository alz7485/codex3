from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")


def test_preset_editor_uses_consistent_width_classes():
    for marker in (
        "W_LONG = 210",
        "W_MEDIUM = 150",
        "W_SHORT = 115",
        "W_SMALL = 72",
        "W_ACTION = 130",
    ):
        assert marker in MAIN


def test_matching_plot_controls_share_widths():
    for marker in (
        "device.setFixedWidth(W_LONG)",
        "printer_device.setFixedWidth(W_LONG)",
        "paper.setFixedWidth(W_MEDIUM)",
        "printer_paper.setFixedWidth(W_MEDIUM)",
        "out.setFixedWidth(W_SHORT)",
        "plot_area.setFixedWidth(W_SHORT)",
        "refresh_env.setFixedWidth(W_ACTION)",
        "import_dwg.setFixedWidth(W_ACTION)",
    ):
        assert marker in MAIN


def test_compound_rows_have_stable_widths():
    assert "window_box.setFixedWidth(330)" in MAIN
    assert "layoutrow.setFixedWidth(286)" in MAIN
    assert "scale_box.setFixedWidth(160)" in MAIN
    assert "offbox.setFixedWidth(178)" in MAIN


def test_other_preset_pages_do_not_stretch_simple_fields_needlessly():
    for marker in (
        "mode.setFixedWidth(W_MEDIUM)",
        "tmpl.setFixedWidth(W_LONG)",
        "individual.setFixedWidth(W_MEDIUM)",
        "merged_name.setFixedWidth(W_LONG)",
        "defaultc.setFixedWidth(W_LONG)",
    ):
        assert marker in MAIN
