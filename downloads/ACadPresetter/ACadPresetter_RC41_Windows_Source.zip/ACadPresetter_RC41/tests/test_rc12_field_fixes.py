from pdf_fixtures import write_pdf, pdf_bytes
from pathlib import Path

from app.autocad_backend import AutoCADBatchSession
from app.plot_settings import normalize_plot_settings, validate_plot_values
from app.pdf_output import PdfOutputSession

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
BACKEND = (ROOT / "app" / "autocad_backend.py").read_text(encoding="utf-8")


def test_preset_manager_supports_drag_and_arrow_reorder():
    assert "self.items.setDragDropMode(QAbstractItemView.InternalMove)" in MAIN
    assert "def _on_preset_rows_moved" in MAIN
    assert "def move_preset(self, delta):" in MAIN
    assert 'b_up=QPushButton("↑")' in MAIN and 'b_down=QPushButton("↓")' in MAIN


def test_main_auto_order_includes_ungrouped_top_level_files():
    start = MAIN.index("def _apply_merge_auto_order")
    end = MAIN.index("def group_selected", start)
    block = MAIN[start:end]
    assert "Ungrouped files are sorted too" in block
    assert "takeTopLevelItem" in block and "insertTopLevelItem" in block


def test_multiple_layout_ui_is_explicit_and_print_expands_too():
    assert '"全Layout","全Layout"' in MAIN
    assert '"指定Layout（複数可）","指定Layout"' in MAIN
    assert 'QPushButton("選択...")' in MAIN
    assert "def _expand_layout_print_jobs" in MAIN
    assert 'explicit_layout=job.get("layout")' in BACKEND


def test_dwg_import_has_only_one_layout_selector():
    # The source-layout combo itself is the target; the old second radio-button selector is gone.
    assert 'ff.addRow("設定取得元",layouts)' in MAIN
    assert "出力時の対象Layout" not in MAIN


def test_output_batch_uses_dedicated_hidden_autocad_and_can_quit_owned_instance():
    assert '"dedicated_hidden":True' in MAIN
    assert "DispatchEx" in BACKEND

    class App:
        def __init__(self): self.quit_count = 0
        def Quit(self): self.quit_count += 1
    app = App()
    session = AutoCADBatchSession({"dedicated_hidden": True})
    session.app = app
    session.backend.app = app
    session.backend.started_by_us = True
    session.close()
    assert app.quit_count == 1


def test_user_owned_autocad_is_never_quit():
    class App:
        def __init__(self): self.quit_count = 0
        def Quit(self): self.quit_count += 1
    app = App()
    session = AutoCADBatchSession({"dedicated_hidden": False})
    session.app = app
    session.backend.app = app
    session.backend.started_by_us = False
    session.close()
    assert app.quit_count == 0


def test_window_plot_area_is_preserved_and_validated():
    p = normalize_plot_settings({
        "device":"DWG To PDF.pc3", "paper":"A3", "plot_area":"窓",
        "window_x1":0, "window_y1":0, "window_x2":100, "window_y2":50,
    })
    assert p["plot_area"] == "窓"
    assert validate_plot_values(p) == []
    bad = dict(p); bad["window_x2"] = None
    assert any("窓" in x for x in validate_plot_values(bad))


def test_pdf_commit_verifies_final_destination(tmp_path):
    source = tmp_path / "stage.pdf"
    write_pdf(source)
    dest = tmp_path / "server_like" / "out.pdf"
    out = PdfOutputSession.atomic_commit(source, dest)
    assert Path(out).exists()
    assert Path(out).read_bytes().startswith(b"%PDF-")


def test_output_result_exposes_actual_folder():
    assert 'QPushButton("📁 保存先を開く")' in MAIN
    assert "self._last_output_folders=folders" in MAIN
    assert "保存先:" in MAIN
