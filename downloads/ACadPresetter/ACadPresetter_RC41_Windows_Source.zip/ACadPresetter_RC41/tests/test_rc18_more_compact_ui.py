from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")


def test_preset_manager_is_narrower_but_keeps_no_scroll_height():
    assert "self.resize(900, dialog_h)" in MAIN
    assert "self.setMinimumSize(800, min(720, dialog_h))" in MAIN
    assert "split.setSizes([125,170,500])" in MAIN


def test_compact_width_classes_are_used():
    for marker in (
        "W_LONG = 210",
        "W_MEDIUM = 150",
        "W_SHORT = 115",
        "W_SMALL = 72",
        "W_ACTION = 130",
    ):
        assert marker in MAIN


def test_compound_rows_and_dwg_import_are_compact():
    for marker in (
        "w.setFixedWidth(56)",
        "window_box.setFixedWidth(330)",
        "layoutrow.setFixedWidth(286)",
        "pathrow.setFixedWidth(284)",
        "list_source.setFixedWidth(280)",
        "file_source.setFixedWidth(225)",
        "layouts.setFixedWidth(180)",
    ):
        assert marker in MAIN
