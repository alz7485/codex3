from app.plot_settings import normalize_plot_settings, validate_plot_values


def test_orientation_is_canonical_and_drives_rotation():
    assert normalize_plot_settings({"orientation":"縦"})["rotation"] == "0°"
    assert normalize_plot_settings({"orientation":"横"})["rotation"] == "90°"


def test_legacy_rotation_migrates_to_orientation():
    assert normalize_plot_settings({"rotation":"90°", "orientation":"自動"})["orientation"] == "横"
    assert normalize_plot_settings({"rotation":"180°", "orientation":"自動"})["orientation"] == "縦"


def test_required_plot_values():
    issues=validate_plot_values({"setting_method":"プリセットを適用","device":"","paper":"","plot_styles":True,"plot_style":""})
    assert any("PC3" in x for x in issues)
    assert any("用紙" in x for x in issues)


def test_dwg_settings_mode_does_not_require_preset_values():
    assert validate_plot_values({"setting_method":"DWG/DXFに保存されている設定を使用"}) == []


def test_invalid_custom_scale():
    issues=validate_plot_values({"device":"x","paper":"A3","plot_styles":False,"fit_to_paper":False,"scale_num":1,"scale_den":0})
    assert any("尺度" in x for x in issues)
