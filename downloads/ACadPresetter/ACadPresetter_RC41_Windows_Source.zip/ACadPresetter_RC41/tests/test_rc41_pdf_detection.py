from pathlib import Path
import os
import time
import unicodedata
import pytest
from pdf_fixtures import write_pdf
from app import adobe_device_output as adobe


class Clock:
    def __init__(self): self.elapsed=0.0;self.wall=time.time()
    def time(self): return self.wall+self.elapsed
    def monotonic(self): return self.elapsed
    def sleep(self,seconds): self.elapsed+=seconds


@pytest.fixture
def clock(monkeypatch):
    clock=Clock();monkeypatch.setattr(adobe,'time',clock)
    return clock


def detect(folder,clock,before=None,expected='図面ガ (1).pdf',started_at=None,log=None,timeout=3):
    return adobe.wait_for_generated_pdf([folder],before or {},'図面ガ',
        clock.time() if started_at is None else started_at,
        timeout=timeout,expected_name=expected,log=log)


@pytest.mark.parametrize('offset',[3600,86400,365*86400])
def test_new_pdf_is_not_rejected_when_file_clock_is_behind_pc(tmp_path,clock,offset):
    path=tmp_path/'図面ガ (1).pdf';write_pdf(path)
    os.utime(path,(1000,1000))
    assert detect(tmp_path,clock,started_at=clock.time()+offset)==path


def test_timestamp_and_size_preserved_content_changed_is_detected(tmp_path,clock,monkeypatch):
    path=tmp_path/'図面ガ (1).pdf';old=write_pdf(path,300)
    fixed=adobe._file_metadata(path)
    real_metadata=adobe._file_metadata
    monkeypatch.setattr(adobe,'_file_metadata',lambda p:fixed if Path(p)==path else real_metadata(p))
    before=adobe.snapshot_pdfs([tmp_path],expected_name=path.name)
    changed=write_pdf(path,400)
    assert len(old)==len(changed) and old!=changed
    trace=[]
    assert detect(tmp_path,clock,before=before,log=trace.append)==path
    assert any('SHA256の変更' in line for line in trace)
    assert clock.elapsed>=1.2  # content itself was observed stable twice


def test_unchanged_existing_pdf_is_still_rejected(tmp_path,clock):
    path=tmp_path/'図面ガ (1).pdf';original=write_pdf(path)
    before=adobe.snapshot_pdfs([tmp_path],expected_name=path.name)
    trace=[]
    assert detect(tmp_path,clock,before=before,started_at=clock.time()+86400,
                  log=trace.append,timeout=2) is None
    assert path.read_bytes()==original
    assert any('日時・サイズ・内容が同じ' in line for line in trace)


def test_file_replacement_is_detected_even_with_same_bytes_size_and_mtime(tmp_path,clock):
    path=tmp_path/'図面ガ (1).pdf';content=write_pdf(path)
    before=adobe.snapshot_pdfs([tmp_path],expected_name=path.name)
    old=path.stat()
    replacement=tmp_path/'replacement.tmp';replacement.write_bytes(content)
    os.utime(replacement,ns=(old.st_atime_ns,old.st_mtime_ns))
    os.replace(replacement,path)
    assert path.stat().st_size==old.st_size and path.stat().st_mtime_ns==old.st_mtime_ns
    assert detect(tmp_path,clock,before=before)==path


@pytest.mark.parametrize('actual',[
    '図面カ\u3099 (1).pdf',
    '図面ガ\u00a0(1).pdf',
    '図面ガ\u3000(1).PDF',
    '図面ガ  (1).pdf',
    '図面ガ （１）.pdf',
])
def test_unicode_and_space_normalization_matches_actual_filename(tmp_path,clock,actual):
    path=tmp_path/actual;write_pdf(path)
    trace=[]
    assert detect(tmp_path,clock,log=trace.append)==path
    assert any('正規化後に生成名が一致' in line for line in trace)


def test_normalization_collision_never_selects_an_arbitrary_pdf(tmp_path,clock):
    a=tmp_path/'図面ガ (1).pdf';b=tmp_path/'図面カ\u3099 (1).pdf'
    write_pdf(a);write_pdf(b)
    with pytest.raises(RuntimeError,match='候補が複数'):
        detect(tmp_path,clock)


def test_fullwidth_drawing_letters_are_not_folded_into_another_drawing(tmp_path,clock):
    write_pdf(tmp_path/'Ａ1 (1).pdf')
    assert detect(tmp_path,clock,expected='A1 (1).pdf',timeout=1) is None


def test_snapshot_hashes_only_matching_output_not_unrelated_pdfs(tmp_path,monkeypatch):
    expected=tmp_path/'図面ガ (1).pdf';write_pdf(expected)
    other=tmp_path/'other.pdf';write_pdf(other)
    calls=[];real=adobe._file_sha256
    def checked(path): calls.append(Path(path));return real(path)
    monkeypatch.setattr(adobe,'_file_sha256',checked)
    snapshot=adobe.snapshot_pdfs([tmp_path],expected_name=expected.name)
    assert len(snapshot)==2
    assert calls==[expected]
    calls.clear()
    assert len(adobe.snapshot_pdfs([tmp_path]))==2
    assert not calls  # lightweight diagnostic enumeration remains lightweight


def test_unreadable_snapshot_does_not_guess_freshness_when_metadata_is_unchanged(tmp_path,clock,monkeypatch):
    path=tmp_path/'図面ガ (1).pdf';write_pdf(path)
    real=adobe._file_sha256
    monkeypatch.setattr(adobe,'_file_sha256',lambda p:(_ for _ in ()).throw(PermissionError('locked')))
    before=adobe.snapshot_pdfs([tmp_path],expected_name=path.name)
    monkeypatch.setattr(adobe,'_file_sha256',real)
    trace=[]
    assert detect(tmp_path,clock,before=before,log=trace.append,timeout=1.5) is None
    assert any('内容差分の基準がありません' in line for line in trace)


def test_no_name_match_logs_actual_names_for_diagnosis(tmp_path,clock):
    write_pdf(tmp_path/'other (1).pdf')
    trace=[]
    assert detect(tmp_path,clock,log=trace.append,timeout=1) is None
    assert any("'other (1).pdf'" in line and '一致する名前がありません' in line for line in trace)
