from app.autocad_backend import _find_open_document,_capture_layout_state,_restore_layout_state,_prepare_plot

class Docs(list): pass
class Doc:
    def __init__(self,p): self.FullName=p
class Layout:
    def __init__(self,name='Model'):
        self.Name=name; self.ConfigName='OLD.pc3'; self.CanonicalMediaName='OLD_A3'; self.StyleSheet='old.ctb'
        self.PlotType=1; self.CenterPlot=False; self.UseStandardScale=True; self.StandardScale=0
        self.PlotWithLineweights=True; self.PlotTransparency=False; self.PlotWithPlotStyles=True; self.PlotRotation=0; self.PlotOrigin=(1,2)
    def RefreshPlotDeviceInfo(self): pass
    def GetCustomScale(self): return (1,1)
    def SetCustomScale(self,a,b): self.custom=(a,b)
class Drawing:
    def __init__(self): self.ActiveLayout=Layout(); self.Layouts=[self.ActiveLayout]

def test_find_open_document_full_path_case_insensitive(tmp_path):
    p=tmp_path/'A.dwg'; p.write_text('x')
    app=type('A',(),{})(); app.Documents=Docs([Doc(str(p).upper())])
    assert _find_open_document(app,p) is app.Documents[0]

def test_layout_snapshot_restore():
    l=Layout(); st=_capture_layout_state(l); l.ConfigName='NEW.pc3'; l.CanonicalMediaName='NEW_A4'; l.StyleSheet='new.ctb'
    _restore_layout_state(l,st)
    assert (l.ConfigName,l.CanonicalMediaName,l.StyleSheet)==('OLD.pc3','OLD_A3','old.ctb')

def test_dwg_setting_mode_does_not_apply_preset():
    d=Drawing(); st={'setting_method':'DWG/DXFに保存されている設定を使用','device':'NEW.pc3','paper':'NEW_A4'}
    lay,snap,active,device,use_dwg=_prepare_plot(d,st)
    assert use_dwg is True and device=='OLD.pc3' and lay.ConfigName=='OLD.pc3'
