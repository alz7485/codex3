from types import SimpleNamespace

from app.autocad_backend import _get_window_points, _get_custom_scale, _verify_applied_plot_settings


def test_window_reader_accepts_nested_and_flat_values():
    assert _get_window_points(SimpleNamespace(GetWindowToPlot=lambda:((1,2),(3,4)))) == ((1.0,2.0),(3.0,4.0))
    assert _get_window_points(SimpleNamespace(GetWindowToPlot=lambda:(1,2,3,4))) == ((1.0,2.0),(3.0,4.0))


def test_custom_scale_tuple_return():
    assert _get_custom_scale(SimpleNamespace(GetCustomScale=lambda:(2,5))) == (2.0,5.0)


def test_applied_settings_verify_window_and_scale():
    class L:
        ConfigName='DWG To PDF.pc3'
        CanonicalMediaName='ISO_A3'
        PlotType=4
        PlotRotation=1
        def GetWindowToPlot(self):return ((10,20),(30,40))
        def GetCustomScale(self):return (1,2)
    settings={
        'device':'DWG To PDF.pc3','paper':'ISO_A3','plot_area':'窓','orientation':'横',
        'rotation':'90°','fit_to_paper':False,'scale_num':1,'scale_den':2,
        'window_x1':10,'window_y1':20,'window_x2':30,'window_y2':40,
    }
    assert _verify_applied_plot_settings(L(),settings)
