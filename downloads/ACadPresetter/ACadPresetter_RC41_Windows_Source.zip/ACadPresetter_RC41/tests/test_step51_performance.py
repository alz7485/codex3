from pathlib import Path
import tempfile

from app.store import Store


def test_environment_cache_avoids_redecode_until_file_changes():
    with tempfile.TemporaryDirectory() as td:
        st=Store(Path(td))
        env={"version":2,"devices":[],"plot_styles":[]}
        st.save_environment(env)
        first=st.load_environment()
        second=st.load_environment()
        assert first is second


def test_main_uses_debounced_session_autosave():
    text=Path(__file__).resolve().parents[1].joinpath("main.py").read_text(encoding="utf-8")
    assert "_session_save_timer.setInterval(250)" in text
    assert "def _flush_session_save" in text
    assert "immediate=True" in text


def test_startup_has_no_forced_autocad_probe_or_shared_access():
    text=Path(__file__).resolve().parents[1].joinpath("main.py").read_text(encoding="utf-8")
    init=text[text.index("class MainWindow"):text.index("    def selected_cad_paths")]
    assert "probe_plot_environment(" not in init
    assert "shared_presets_path" not in init
