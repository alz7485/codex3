from pathlib import Path
import pytest

from app.adobe_device_output import candidate_dirs


def test_explicit_adobe_watch_dir_is_the_only_directory(tmp_path):
    src_dir=tmp_path/'src'; src_dir.mkdir()
    adobe_dir=tmp_path/'adobe'; adobe_dir.mkdir()
    stage_dir=tmp_path/'stage'; stage_dir.mkdir()
    src=src_dir/'A001.dwg'; src.write_bytes(b'')
    dirs=candidate_dirs('Adobe PDF',src,stage_dir/'A001.pdf',preferred_dir=adobe_dir)
    assert dirs == [adobe_dir.resolve()]


def test_explicit_adobe_watch_dir_must_exist(tmp_path):
    src=tmp_path/'A001.dwg'; src.write_bytes(b'')
    with pytest.raises(RuntimeError, match='Adobe PDF生成先フォルダが存在しません'):
        candidate_dirs('Adobe PDF',src,tmp_path/'A001.pdf',preferred_dir=tmp_path/'missing')


def test_config_has_adobe_watch_dir_default(tmp_path):
    from app.store import Store
    st=Store(tmp_path/'data')
    cfg=st.load_config()
    assert 'adobe_pdf_watch_dir' in cfg
    assert cfg['adobe_pdf_watch_dir']==''
