from app.models import DrawingList, DrawingGroup, DrawingItem

def test_next_group_number_roundtrip():
    x=DrawingList(collection_id="c",next_group_number=12,entries=[DrawingGroup("新規グループ11",[DrawingItem("a.dwg")])])
    y=DrawingList.from_dict(x.to_dict())
    assert y.next_group_number == 12
    assert y.to_dict()["next_group_number"] == 12
