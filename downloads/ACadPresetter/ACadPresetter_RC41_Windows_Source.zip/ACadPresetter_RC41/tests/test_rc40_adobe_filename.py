import os
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from pdf_fixtures import write_pdf
from app import adobe_device_output as adobe
from app import autocad_backend as backend


@pytest.mark.parametrize('source,expected', [
    (r'C:\工事\図面A.dwg', '図面A (1).pdf'),
    (r'\\server\図面\配管 A.改訂2.dxf', '配管 A.改訂2 (1).pdf'),
    (r'C:\CAD\元名 (1).DWG', '元名 (1) (1).pdf'),
    ('/tmp/P-001.dwg', 'P-001 (1).pdf'),
])
def test_confirmed_adobe_filename_uses_original_cad_stem_and_ascii_space(source,expected):
    actual=adobe.adobe_generated_name(source)
    assert actual==expected
    assert actual.endswith(' (1).pdf')


def test_missing_cad_name_is_error_instead_of_guessing_staged_name():
    with pytest.raises(RuntimeError,match='元CADデータのファイル名'):
        adobe.adobe_generated_name('')


class Clock:
    def __init__(self): self.wall=time.time();self.elapsed=0.0
    def time(self): return self.wall+self.elapsed
    def monotonic(self): return self.elapsed
    def sleep(self,seconds): self.elapsed+=seconds


@pytest.fixture
def clock(monkeypatch):
    clock=Clock();monkeypatch.setattr(adobe,'time',clock)
    return clock


def make_doc(folder,original,clock):
    layout=SimpleNamespace(Name='Sheet1',ConfigName='Adobe PDF')
    calls=[]
    state={'active':0}
    def getvar(name):
        if name=='CMDACTIVE':
            value=state['active'];state['active']=0;return value
        if name=='CMDNAMES': return ''
        return 2
    def send(command):
        calls.append(command);state['active']=1
        # Adobe's real output uses the original CAD name, while this AutoCAD
        # document exposes a different converted/temporary drawing name.
        for name in [adobe.adobe_generated_name(original),'converted (1).pdf','custom_final.pdf']:
            path=folder/name;write_pdf(path)
            os.utime(path,(clock.time(),clock.time()))
    doc=SimpleNamespace(FullName=str(folder/'converted.dwg'),Name='converted.dwg',ActiveLayout=layout,
                        GetVariable=getvar,SetVariable=lambda *args:None,SendCommand=send,Close=Mock())
    return doc,calls


@pytest.mark.parametrize('multi_layout',[False,True])
def test_original_source_name_reaches_adobe_detection_through_backend(tmp_path,clock,monkeypatch,multi_layout):
    original=tmp_path/'図面A.dxf';original.touch()
    staged=tmp_path/'stage'/'00001_random_id.pdf'
    doc,calls=make_doc(tmp_path,original,clock)
    monkeypatch.setattr(backend,'_open_for_session',lambda *args:(doc,True))
    monkeypatch.setattr(backend,'_prepare_plot',lambda *args:(None,None,None,'Adobe PDF',False))
    session=SimpleNamespace(app=object(),options={'adobe_pdf_watch_dir':str(tmp_path)})
    if multi_layout:
        results=backend.plot_layouts_pdf(original,{'Sheet1':str(staged)},{},['Sheet1'],session=session)
    else:
        results=backend.plot_batch_pdf([{'source':str(original),'output':str(staged),'settings':{}}],session=session)
    assert results[0]['status']=='ok',results
    assert staged.exists() and len(calls)==1
    assert any('図面A (1).pdf' in line and '検出対象' in line for line in results[0]['trace'])
    assert (tmp_path/'converted (1).pdf').exists()
    assert (tmp_path/'custom_final.pdf').exists()
    doc.Close.assert_called_once_with(False)


def test_exact_production_name_ignores_other_changed_name_variants(tmp_path,clock):
    for name in ['図面A.pdf','図面A (2).pdf','図面A(1).pdf']:
        write_pdf(tmp_path/name)
    assert adobe.wait_for_generated_pdf([tmp_path],{},'図面A',clock.time(),timeout=1,
                                        expected_name='図面A (1).pdf') is None
    matching=tmp_path/'図面A (1).pdf';write_pdf(matching)
    assert adobe.wait_for_generated_pdf([tmp_path],{},'図面A',clock.time(),timeout=2,
                                        expected_name='図面A (1).pdf')==matching
