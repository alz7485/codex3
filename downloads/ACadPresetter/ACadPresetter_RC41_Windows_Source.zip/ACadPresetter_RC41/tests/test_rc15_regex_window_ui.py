from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")


def test_regex_token_typing_collapses_to_end_not_replace():
    assert "def _collapse_token_selection_to_end" in MAIN
    assert "self._collapse_token_selection_to_end()" in MAIN
    assert "def inputMethodEvent" in MAIN


def test_regex_active_token_not_sticky_while_editor_has_focus():
    assert "if self.template_edit.hasFocus():" in MAIN
    assert "self._active_token_span = None" in MAIN


def test_window_coordinates_are_visible_editor_controls():
    for name in ("window_x1", "window_y1", "window_x2", "window_y2"):
        assert f'{name}=_coord_spin' in MAIN or f'{name}=_coord_edit' in MAIN or f'({name},"{name}")' in MAIN
    assert 'f.addRow("窓範囲",window_box)' in MAIN
    assert 'plot_area.currentText()=="窓"' in MAIN


def test_imported_window_coordinates_populate_controls():
    assert '((window_x1,"window_x1"),(window_y1,"window_y1"),(window_x2,"window_x2"),(window_y2,"window_y2"))' in MAIN


def test_saved_window_coordinates_come_from_controls():
    assert ('window_x1=window_x1.value()' in MAIN or 'window_x1=_coord_value(window_x1)' in MAIN)
    assert ('window_y2=window_y2.value()' in MAIN or 'window_y2=_coord_value(window_y2)' in MAIN)
