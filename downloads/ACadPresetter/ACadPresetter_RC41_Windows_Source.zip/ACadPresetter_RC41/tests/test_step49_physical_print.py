from app.preflight import build_report

def test_dwg_settings_print_allows_blank_device(tmp_path):
    f=tmp_path/'a.dwg'; f.write_bytes(b'x')
    st={'setting_method':'DWG/DXFに保存されている設定を使用'}
    r=build_report([], [{'source':str(f),'settings':st}], {})
    assert not r.file_errors

def test_explicit_print_requires_device(tmp_path):
    f=tmp_path/'a.dwg'; f.write_bytes(b'x')
    st={'setting_method':'プリセットを適用','device':'','paper':'A3'}
    r=build_report([], [{'source':str(f),'settings':st}], {})
    assert any('プリンター' in x.message for x in r.file_errors)

def test_print_copies_default_normalized():
    from app.plot_settings import normalize_plot_settings
    assert normalize_plot_settings({}).get('copies') == 1
