from pathlib import Path
from pypdf import PdfReader, PdfWriter

from app.autocad_backend import PLOT_SCALE_RATIOS
from app.pdf_postprocess import rotate_a3_a1_left_to_landscape

PT_PER_MM = 72.0 / 25.4


def test_acplotscale_mapping_has_no_nonexistent_1_to_5_shift():
    # Trial10g / Autodesk acPlotScale: 1:5 does not exist.
    assert PLOT_SCALE_RATIOS[18] == (1, 4)
    assert PLOT_SCALE_RATIOS[19] == (1, 8)
    assert PLOT_SCALE_RATIOS[20] == (1, 10)
    assert PLOT_SCALE_RATIOS[26] == (1, 100)
    assert PLOT_SCALE_RATIOS[27] == (2, 1)
    assert max(PLOT_SCALE_RATIOS) == 31


def test_rotation_preserves_metadata_and_outline(tmp_path: Path):
    pdf = tmp_path / "a3.pdf"
    w = PdfWriter()
    w.add_blank_page(width=297 * PT_PER_MM, height=420 * PT_PER_MM)
    w.add_metadata({"/Title": "ACadPresetter audit"})
    w.add_outline_item("Sheet A3", 0)
    with pdf.open("wb") as f:
        w.write(f)
    w.close()

    changed = rotate_a3_a1_left_to_landscape(pdf)
    assert changed == [{"page": 1, "size": "A3"}]

    r = PdfReader(str(pdf), strict=True)
    assert r.metadata.title == "ACadPresetter audit"
    assert r.outline
    assert int(r.pages[0].rotation or 0) % 360 == 270


def test_rotation_implementation_does_not_reader_lock_paths():
    # Static regression guard for the Windows-only failure mode: PdfReader(path)
    # can hold the destination open until after os.replace().
    text = (Path(__file__).parents[1] / "app" / "pdf_postprocess.py").read_text(encoding="utf-8")
    assert "PdfReader(BytesIO(src.read_bytes())" in text
    assert "PdfReader(BytesIO(tmp.read_bytes())" in text
    assert "PdfWriter(clone_from=reader)" in text
