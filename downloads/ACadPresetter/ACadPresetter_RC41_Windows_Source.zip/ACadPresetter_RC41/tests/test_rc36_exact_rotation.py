from app.plot_settings import normalize_plot_settings


def test_preserves_180_for_portrait():
    s=normalize_plot_settings({"orientation":"縦","rotation":"180°"})
    assert s["orientation"]=="縦"
    assert s["rotation"]=="180°"

def test_preserves_270_for_landscape():
    s=normalize_plot_settings({"orientation":"横","rotation":"270°"})
    assert s["orientation"]=="横"
    assert s["rotation"]=="270°"

def test_inconsistent_rotation_is_canonicalized():
    s=normalize_plot_settings({"orientation":"縦","rotation":"270°"})
    assert s["rotation"]=="0°"
    s=normalize_plot_settings({"orientation":"横","rotation":"180°"})
    assert s["rotation"]=="90°"

def test_orientation_derived_from_rotation_when_missing():
    s=normalize_plot_settings({"rotation":"270°"})
    assert s["orientation"]=="横"
    assert s["rotation"]=="270°"
