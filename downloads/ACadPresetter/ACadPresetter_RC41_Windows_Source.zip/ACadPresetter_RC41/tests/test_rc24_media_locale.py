from app.autocad_environment import normalize_environment, media_choices_for_device


def test_locale_media_labels_are_separate_from_canonical_values():
    env = normalize_environment({
        "devices": ["Adobe PDF"],
        "device_media": {"Adobe PDF": ["A3", "A4"]},
        "device_media_locale": {
            "Adobe PDF": {
                "A3": "A3 (297 x 420 mm)",
                "A4": "A4 (210 x 297 mm)",
            }
        },
    })
    assert media_choices_for_device(env, "Adobe PDF") == [
        ("A3", "A3 (297 x 420 mm)"),
        ("A4", "A4 (210 x 297 mm)"),
    ]


def test_old_environment_without_locale_labels_still_works():
    env = normalize_environment({
        "devices": ["PDF.pc3"],
        "device_media": {"PDF.pc3": ["ISO_A3"]},
    })
    assert media_choices_for_device(env, "PDF.pc3") == [("ISO_A3", "ISO_A3")]
