from pathlib import Path


def test_adobe_module_uses_trial10g_macro_route():
    text=(Path(__file__).parents[1]/'app'/'adobe_device_output.py').read_text(encoding='utf-8')
    assert "'_.-PLOT'" in text
    assert "['_N',layout_name" not in text  # guard against malformed nested line construction
    assert "macro='\\n'.join(['_.-PLOT','_N',layout_name,'','','_N','_N','_Y'])+'\\n'" in text
    assert 'doc.SendCommand(macro)' in text
    assert "return f'{stem} (1).pdf'" in text
    assert 'PlotToDevice()' not in text


def test_adobe_route_requires_explicit_watch_folder():
    text=(Path(__file__).parents[1]/'app'/'adobe_device_output.py').read_text(encoding='utf-8')
    assert 'Adobe PDF生成先が未設定です' in text
