from app.autocad_environment import normalize_environment, media_for_device, validate_plot_preset

def test_device_media_dependency():
    env=normalize_environment({"devices":["PDF.pc3","Printer"],"device_media":{"PDF.pc3":["A3","A4"],"Printer":["A4"]},"styles":["mono.ctb"]})
    assert media_for_device(env,"PDF.pc3")==["A3","A4"]
    assert media_for_device(env,"Printer")==["A4"]

def test_invalid_media_and_style():
    env=normalize_environment({"devices":["PDF.pc3"],"device_media":{"PDF.pc3":["A3"]},"styles":["mono.ctb"]})
    msgs=validate_plot_preset({"device":"PDF.pc3","paper":"A4","plot_style":"color.ctb"},env)
    assert any("用紙" in x for x in msgs)
    assert any("CTB/STB" in x for x in msgs)

def test_old_flat_cache_compatibility():
    env=normalize_environment({"devices":["PDF.pc3"],"media":["A3"],"styles":[]})
    assert media_for_device(env,"PDF.pc3")==["A3"]
