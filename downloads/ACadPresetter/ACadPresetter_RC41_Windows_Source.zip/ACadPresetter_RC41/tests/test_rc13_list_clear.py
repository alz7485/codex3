from pathlib import Path


def test_rc13_main_has_clear_button_and_close_clears_tree():
    root = Path(__file__).resolve().parents[1]
    text = (root / "main.py").read_text(encoding="utf-8")
    assert 'QPushButton("🗑 リストクリア")' in text
    assert 'b_clear.clicked.connect(self.clear_main_list)' in text
    assert 'def clear_main_list(self, confirm=True, save_session=True):' in text
    # closeEvent must clear before its immediate session save, so restart sees an empty list.
    close = text.split('    def closeEvent(self,event):', 1)[1].split('\nif __name__=="__main__":', 1)[0]
    assert 'self.tree.clear()' in close
    assert 'self.save_session(silent=True, immediate=True)' in close
    assert close.index('self.tree.clear()') < close.index('self.save_session(silent=True, immediate=True)')


def test_rc13_clear_releases_current_acplist_association():
    root = Path(__file__).resolve().parents[1]
    text = (root / "main.py").read_text(encoding="utf-8")
    block = text.split('    def clear_main_list(self, confirm=True, save_session=True):', 1)[1].split('    def export_list(self):', 1)[0]
    assert 'self._current_list_path=None' in block
    assert 'self._next_group_number=1' in block
    assert '元のDWG/DXFファイルや保存済み.acplistは削除されません' in block
