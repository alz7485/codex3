import re
import pytest

from app.regex_builder import (
    template_to_regex, template_matches, token_spans, parse_token, make_token
)


def test_builder_core_tokens_and_ranges():
    pattern = template_to_regex("P-{数字:4}-{*:2-5}-{大文字:1}")
    assert re.fullmatch(pattern, "P-0123-MAIN-A")
    assert re.fullmatch(pattern, "P-9999-AB-Z")
    assert not re.fullmatch(pattern, "P-12-MAIN-A")
    assert not re.fullmatch(pattern, "P-0123-TOOLONG-A")


def test_builder_supported_character_classes():
    assert template_matches("ABC-aa-A1.dwg", "{英字:3}-{小文字:2}-{英数字:2}")
    assert template_matches("XYZ-ZZ-99.dxf", "{大文字:3}-{大文字:2}-{英数字:2}")
    assert not template_matches("XYZ-Zz-99.dwg", "{大文字:3}-{大文字:2}-{英数字:2}", case_sensitive=True)


def test_builder_any_default_can_match_zero_chars():
    assert template_matches("AB--001.dwg", "AB-{*}-001")
    assert template_matches("AB-MAIN-001.dwg", "AB-{*}-001")


def test_builder_plain_text_is_literal_not_regex():
    pattern = template_to_regex("A.01(改)-{数字:3}")
    assert re.fullmatch(pattern, "A.01(改)-123")
    assert not re.fullmatch(pattern, "AX01改-123")


def test_builder_choice_is_literal_alternation():
    assert template_matches("P-PDF-001.dwg", "P-{選択:PDF|CAD|SCAN}-{数字:3}")
    assert template_matches("P-CAD-999.dwg", "P-{選択:PDF|CAD|SCAN}-{数字:3}")
    assert not template_matches("P-DOC-999.dwg", "P-{選択:PDF|CAD|SCAN}-{数字:3}")


def test_builder_token_spans_and_token_factory():
    text = "P-{数字:4}-{*:2-5}-A"
    spans = token_spans(text)
    assert [x[2] for x in spans] == ["数字:4", "*:2-5"]
    assert parse_token("*:2-5") == ("*", "range", 2, 5)
    assert make_token("数字", "fixed", 4, None) == "{数字:4}"
    assert make_token("*", "range", 2, 5) == "{*:2-5}"


def test_builder_rejects_invalid_tokens_and_ranges():
    with pytest.raises(ValueError):
        template_to_regex("P-{数字:5-2}")
    with pytest.raises(ValueError):
        template_to_regex("P-{未知:3}")
    with pytest.raises(ValueError):
        template_to_regex("P-{選択:A||B}")


def test_upper_and_lower_tokens_remain_strict_when_rule_is_case_insensitive():
    assert template_matches("ABC-abc.dwg", "{大文字:3}-{小文字:3}", case_sensitive=False)
    assert not template_matches("AbC-abc.dwg", "{大文字:3}-{小文字:3}", case_sensitive=False)
    assert not template_matches("ABC-aBc.dwg", "{大文字:3}-{小文字:3}", case_sensitive=False)
