from pathlib import Path
import base64
from app.icon_data import icon_bytes
from app.store import Store

def test_embedded_icon_is_ico():
    b=icon_bytes(); assert len(b)>1000; assert b[:4]==b"\x00\x00\x01\x00"

def test_first_run_dirs(tmp_path):
    s=Store(tmp_path/"data"); s.load_config()
    assert (tmp_path/"data"/"presets").is_dir()
    assert (tmp_path/"data"/"backup").is_dir()
    assert (tmp_path/"data"/"logs").is_dir()

def test_no_internal_redirect(tmp_path):
    (tmp_path/"_internal"/"data").mkdir(parents=True)
    (tmp_path/"_internal"/"data"/"config.json").write_text("{}",encoding="utf-8")
    s=Store(tmp_path/"data"); s.load_config()
    assert s.dir == tmp_path/"data"
