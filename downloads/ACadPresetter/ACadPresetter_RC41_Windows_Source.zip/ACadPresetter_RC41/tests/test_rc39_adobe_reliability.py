from pathlib import Path
from types import SimpleNamespace
import os
import time

import pytest
from pdf_fixtures import write_pdf
from app import adobe_device_output as adobe
from app import autocad_backend as backend
from app.pdf_output import PdfOutputSession


class Clock:
    def __init__(self):
        self.elapsed = 0.0
        self.wall = time.time()
        self.on_sleep = None

    def time(self):
        return self.wall + self.elapsed

    def monotonic(self):
        return self.elapsed

    def sleep(self, seconds):
        self.elapsed += seconds
        if self.on_sleep:
            self.on_sleep(self.elapsed)


@pytest.fixture
def clock(monkeypatch):
    clock = Clock()
    monkeypatch.setattr(adobe, 'time', clock)
    return clock


@pytest.mark.parametrize('filename', ['sheet.pdf', 'sheet (1).pdf', 'sheet (2).pdf', 'SHEET (12).PDF'])
def test_driver_name_variants_are_detected_without_touching_old_outputs(tmp_path, clock, filename):
    old = tmp_path / 'sheet (1).pdf'
    if filename.casefold() != old.name.casefold():
        write_pdf(old)
    before = adobe.snapshot_pdfs([tmp_path])
    target = tmp_path / filename
    write_pdf(target, 250)
    found = adobe.wait_for_generated_pdf([tmp_path], before, 'sheet', clock.time(), timeout=2)
    assert found == target


def test_unchanged_existing_pdf_and_prefix_matches_are_never_used(tmp_path, clock):
    old = tmp_path / 'sheet (1).pdf'
    original = write_pdf(old)
    before = adobe.snapshot_pdfs([tmp_path])
    write_pdf(tmp_path / 'sheet_other.pdf')
    assert adobe.wait_for_generated_pdf([tmp_path], before, 'sheet', clock.time(), timeout=1) is None
    assert old.read_bytes() == original


def test_ambiguous_new_outputs_are_rejected(tmp_path, clock):
    write_pdf(tmp_path / 'sheet.pdf')
    write_pdf(tmp_path / 'sheet (1).pdf')
    with pytest.raises(RuntimeError, match='候補が複数'):
        adobe.wait_for_generated_pdf([tmp_path], {}, 'sheet', clock.time(), timeout=2)


def test_header_only_pdf_is_not_treated_as_finished(tmp_path, clock):
    path = tmp_path / 'sheet.pdf'
    path.write_bytes(b'%PDF-1.7\nunfinished')
    trace = []
    assert adobe.wait_for_generated_pdf([tmp_path], {}, 'sheet', clock.time(), timeout=1.5, log=trace.append) is None
    assert trace and '完成待ち' in trace[0]


def test_slow_driver_is_awaited_until_pdf_is_readable(tmp_path, clock):
    path = tmp_path / 'sheet (2).pdf'
    path.write_bytes(b'%PDF-1.7\nunfinished')
    done = []
    def finish(elapsed):
        if elapsed >= 0.8 and not done:
            write_pdf(path)
            done.append(True)
    clock.on_sleep = finish
    assert adobe.wait_for_generated_pdf([tmp_path], {}, 'sheet', clock.time(), timeout=3) == path
    assert clock.elapsed >= 1.4


def test_wait_uses_monotonic_deadline_and_pumps_ui(tmp_path, clock):
    pulses = []
    def wall_jump(elapsed):
        clock.wall -= 10000
    clock.on_sleep = wall_jump
    assert adobe.wait_for_generated_pdf([tmp_path], {}, 'sheet', clock.time(), timeout=1,
                                        keep_hidden=lambda: pulses.append(True)) is None
    assert 1 <= clock.elapsed < 1.5
    assert len(pulses) > 1


def test_unreadable_watch_directory_is_not_silently_ignored(tmp_path, monkeypatch):
    original = Path.iterdir
    def deny(path):
        if path == tmp_path:
            raise PermissionError('denied')
        return original(path)
    monkeypatch.setattr(Path, 'iterdir', deny)
    with pytest.raises(RuntimeError, match='生成先を読み取れません'):
        adobe.snapshot_pdfs([tmp_path])


def test_locked_pdf_copy_retries_then_preserves_preexisting_driver_file(tmp_path, clock, monkeypatch):
    generated = tmp_path / 'sheet.pdf'
    content = write_pdf(generated)
    staged = tmp_path / 'staged.pdf'
    original_copy = adobe.shutil.copy2
    calls = []
    def locked_once(source, target):
        calls.append(True)
        if len(calls) == 1:
            raise PermissionError('Adobe still holds the file')
        return original_copy(source, target)
    monkeypatch.setattr(adobe.shutil, 'copy2', locked_once)
    adobe.finalize_generated_pdf(generated, staged)
    assert len(calls) == 2
    assert generated.read_bytes() == staged.read_bytes() == content
    assert not list(tmp_path.glob('*.adobe_tmp'))


def test_invalid_generated_pdf_cannot_replace_stage_or_be_deleted(tmp_path):
    generated = tmp_path / 'sheet.pdf'
    generated.write_bytes(b'%PDF-1.7\ncorrupt')
    staged = tmp_path / 'staged.pdf'
    old = write_pdf(staged)
    with pytest.raises(RuntimeError, match='正常なPDF'):
        adobe.finalize_generated_pdf(generated, staged, remove_generated=True)
    assert staged.read_bytes() == old
    assert generated.exists()
    assert not list(tmp_path.glob('*.adobe_tmp'))


def test_changed_source_during_copy_is_not_committed(tmp_path, clock, monkeypatch):
    generated = tmp_path / 'sheet.pdf'
    write_pdf(generated)
    staged = tmp_path / 'staged.pdf'
    old = write_pdf(staged)
    original_copy = adobe.shutil.copy2
    count = []
    def mutate(source, target):
        original_copy(source, target)
        count.append(True)
        write_pdf(generated, 100 + len(count))
    monkeypatch.setattr(adobe.shutil, 'copy2', mutate)
    with pytest.raises(RuntimeError, match='取り込めません'):
        adobe.finalize_generated_pdf(generated, staged, remove_generated=True, timeout=0.5)
    assert staged.read_bytes() == old
    assert generated.exists()


def macro_doc(source, watch, filename=None):
    calls = []
    state = {'active': 0}
    def getvar(name):
        if name == 'CMDACTIVE':
            active = state['active']
            state['active'] = 0
            return active
        if name == 'CMDNAMES':
            return ''
        return 0
    def send(command):
        calls.append(command)
        state['active'] = 1
        if filename:
            generated = watch / filename
            write_pdf(generated)
            os.utime(generated, (adobe.time.time(), adobe.time.time()))
    layout = SimpleNamespace(Name='Model', ConfigName='Adobe PDF')
    return SimpleNamespace(FullName=str(source), ActiveLayout=layout, GetVariable=getvar,
                           SetVariable=lambda *args: None, SendCommand=send), calls


def test_three_consecutive_macro_outputs_use_one_document_and_preserve_existing_pdf(tmp_path, clock):
    source = tmp_path / 'sheet.dwg'
    source.touch()
    existing = tmp_path / 'sheet.pdf'
    old = write_pdf(existing)
    doc, calls = macro_doc(source, tmp_path, 'sheet (1).pdf')
    outputs = []
    for index in range(3):
        staged = tmp_path / 'stage' / f'{index}.pdf'
        adobe.plot_to_device_pdf(doc, staged, 'Adobe PDF', preferred_dir=tmp_path, timeout=3)
        PdfOutputSession.validate_pdf(staged)
        outputs.append(staged)
    assert len(outputs) == len(calls) == 3
    assert all(command == '_.-PLOT\n_N\nModel\n\n\n_N\n_N\n_Y\n' for command in calls)
    assert existing.read_bytes() == old
    assert not (tmp_path / 'sheet (1).pdf').exists()


def test_missing_driver_output_is_fatal_and_preserves_old_final(tmp_path, clock):
    source = tmp_path / 'sheet.dwg'
    source.touch()
    doc, calls = macro_doc(source, tmp_path)
    final = tmp_path / 'final.pdf'
    original = write_pdf(final)
    with pytest.raises(backend.AutoCADUnsafeState, match='後続図面は停止'):
        adobe.plot_to_device_pdf(doc, final, 'Adobe PDF', preferred_dir=tmp_path, timeout=1)
    assert len(calls) == 1
    assert final.read_bytes() == original


def test_com_state_failure_is_fatal_not_idle():
    def disconnected(name):
        raise RuntimeError('RPC disconnected')
    with pytest.raises(backend.AutoCADUnsafeState, match='状態を確認できません'):
        adobe._command_state(SimpleNamespace(GetVariable=disconnected))


def test_macro_timeout_stops_batch(tmp_path, clock):
    doc = SimpleNamespace(GetVariable=lambda name: 1 if name == 'CMDACTIVE' else '-PLOT')
    with pytest.raises(backend.AutoCADUnsafeState, match='後続図面は停止'):
        adobe._wait_macro_complete(doc, clock.time(), timeout=0.5)


@pytest.mark.parametrize('value, expected', [(None,120),('bad',120),('nan',120),(-1,30),(9999,600),('180',180)])
def test_saved_timeout_is_safe_and_compatible(value, expected):
    assert adobe.normalize_timeout(value) == expected
