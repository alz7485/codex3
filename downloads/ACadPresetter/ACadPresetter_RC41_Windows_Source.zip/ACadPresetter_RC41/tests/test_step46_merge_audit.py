from pdf_fixtures import write_pdf, pdf_bytes
from pathlib import Path
from app.list_order import order_paths, auto_order_enabled
from app.pdf_output import PdfOutputSession


def rules():
    return [
        {"id":"cover","conditions":[{"type":"含む","value":"COVER"}],"logic":"AND","case_sensitive":False},
        {"id":"a3","conditions":[{"type":"含む","value":"A3"}],"logic":"AND","case_sensitive":False},
    ]


def test_auto_order_only_when_selected():
    paths=["P10_A3.pdf","ZZ.pdf","COVER.pdf","P2_A3.pdf"]
    manual={"enabled":True,"order":"現在のリスト順","sort_rule_ids":["cover","a3"]}
    assert not auto_order_enabled(manual)
    assert order_paths(paths,manual,rules()) == paths


def test_auto_order_rule_then_natural_then_unmatched_last():
    paths=["P10_A3.pdf","ZZ.pdf","COVER.pdf","P2_A3.pdf"]
    mp={"enabled":True,"order":"自動並び替え","sort_rule_ids":["cover","a3"],"unmatched":"最後に配置"}
    assert order_paths(paths,mp,rules()) == ["COVER.pdf","P2_A3.pdf","P10_A3.pdf","ZZ.pdf"]


def test_unmatched_first_is_honoured():
    paths=["P10_A3.pdf","ZZ.pdf","COVER.pdf","AA.pdf"]
    mp={"enabled":True,"order":"自動並び替え","sort_rule_ids":["cover","a3"],"unmatched":"最初に配置"}
    assert order_paths(paths,mp,rules()) == ["AA.pdf","ZZ.pdf","COVER.pdf","P10_A3.pdf"]


def test_atomic_merge_commit_preserves_old_until_valid(tmp_path):
    final=tmp_path/"merged.pdf"; final.write_bytes(b"%PDF-old")
    sess=PdfOutputSession(tmp_path/"temp")
    staged=sess.stage("<merge>",final)
    Path(staged.temp_path).write_bytes(b"bad")
    try:
        try: sess.atomic_commit(staged.temp_path,final)
        except RuntimeError: pass
        assert final.read_bytes()==b"%PDF-old"
        write_pdf(staged.temp_path)
        sess.atomic_commit(staged.temp_path,final)
        assert final.read_bytes()==Path(staged.temp_path).read_bytes()
    finally:
        sess.cleanup()
