from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")


def test_window_coordinates_use_compact_line_edits_without_spin_buttons():
    assert "def _coord_edit(value):" in MAIN
    assert "w=QLineEdit()" in MAIN
    assert "w.setFixedWidth(56)" in MAIN
    assert "QDoubleValidator" in MAIN
    block = MAIN[MAIN.index("def _coord_edit(value):"):MAIN.index("window_x1=_coord_edit")]
    assert "QDoubleSpinBox" not in block


def test_window_coordinate_save_and_import_use_text_controls():
    assert "window_x1=_coord_value(window_x1)" in MAIN
    assert "window_y2=_coord_value(window_y2)" in MAIN
    assert "widget_.setText" in MAIN


def test_plot_editor_wide_controls_are_capped():
    for marker in (
        "device.setFixedWidth(W_LONG)",
        "paper.setFixedWidth(W_MEDIUM)",
        "setting_method.setFixedWidth(W_LONG)",
        "plot_area.setFixedWidth(W_SHORT)",
        "layout_mode.setFixedWidth(W_MEDIUM)",
        "layout_names.setFixedWidth(W_LONG)",
        "import_dwg.setFixedWidth(W_ACTION)",
        "refresh_env.setFixedWidth(W_ACTION)",
    ):
        assert marker in MAIN


def test_window_row_is_compact_and_does_not_force_dialog_width():
    assert 'wh.setSpacing(4)' in MAIN
    assert 'wh.addWidget(QLabel("左下"))' in MAIN
    assert 'wh.addWidget(QLabel("右上"))' in MAIN
