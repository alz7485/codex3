from pathlib import Path
import tempfile
from app.models import DrawingList, DrawingGroup, DrawingItem
from app.store import Store


def test_acplist_roundtrip_preserves_order_manual_and_counter():
    with tempfile.TemporaryDirectory() as td:
        store=Store(Path(td)/"data")
        src=Path(td)/"work.acplist"
        dl=DrawingList(collection_id="collection_x", next_group_number=8, entries=[
            DrawingGroup("新規グループ3", [DrawingItem(r"C:\\CAD\\A.dwg", manual_plot_id="plot_a")]),
            DrawingItem(r"C:\\CAD\\loose.dxf", manual_plot_id="plot_b"),
            DrawingGroup("工事B", [DrawingItem(r"C:\\CAD\\B.dwg")]),
        ])
        store.save_drawing_list(src, dl)
        got=store.load_drawing_list(src)
        assert got.next_group_number == 8
        assert [type(x).__name__ for x in got.entries] == ["DrawingGroup","DrawingItem","DrawingGroup"]
        assert got.entries[0].items[0].manual_plot_id == "plot_a"
        assert got.entries[1].manual_plot_id == "plot_b"
        raw=src.read_text(encoding="utf-8")
        assert "check" not in raw.lower()
        assert "checked" not in raw.lower()


def test_step43_source_tracks_current_list_and_has_relink():
    src=Path(__file__).resolve().parents[1].joinpath("main.py").read_text(encoding="utf-8")
    assert "self._current_list_path=None" in src
    assert "self._current_list_path=Path(path)" in src
    assert "def relink_missing_files" in src
    assert "見つからないファイルを再リンク" in src
