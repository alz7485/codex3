from types import SimpleNamespace
import pytest

from app.autocad_backend import _get_custom_scale, _apply_plot_settings, _verify_applied_plot_settings
from app.plot_settings import validate_plot_values


def _base_settings(**kw):
    d={
        "device":"", "paper":"", "plot_style":"", "plot_area":"レイアウト",
        "fit_to_paper":False, "center_plot":True, "scale_num":None, "scale_den":None,
        "lineweights":True, "transparency":False, "plot_styles":True,
        "orientation":"縦", "rotation":"0°", "offset_x":0, "offset_y":0,
    }
    d.update(kw)
    return d


def _layout():
    calls=[]
    class L:
        ConfigName=""; CanonicalMediaName=""; StyleSheet=""; PlotType=5
        CenterPlot=True; UseStandardScale=False; StandardScale=0
        PlotWithLineweights=True; PlotTransparency=False; PlotWithPlotStyles=True; PlotRotation=0
        PlotOrigin=(0.0,0.0); CustomScale=(3.0,25.0)
        def RefreshPlotDeviceInfo(self): pass
        def SetCustomScale(self,a,b): calls.append((a,b)); self.CustomScale=(a,b)
        def GetCustomScale(self): raise RuntimeError("dynamic dispatch unavailable")
    return L(),calls


def test_property_fallback_reads_custom_scale():
    lay,_=_layout()
    assert _get_custom_scale(lay)==(3.0,25.0)


def test_blank_custom_scale_does_not_set_1_to_1():
    lay,calls=_layout()
    _apply_plot_settings(lay,_base_settings())
    assert calls==[]
    assert lay.CustomScale==(3.0,25.0)


def test_blank_custom_scale_skips_verification():
    lay,_=_layout()
    assert _verify_applied_plot_settings(lay,_base_settings()) is True


def test_explicit_custom_scale_is_applied_and_verified():
    lay,calls=_layout()
    st=_base_settings(scale_num=2.0,scale_den=50.0)
    _apply_plot_settings(lay,st)
    assert calls==[(2.0,50.0)]
    assert _verify_applied_plot_settings(lay,st) is True


def test_validation_allows_both_missing_but_not_half_missing():
    base=_base_settings(device="DWG To PDF.pc3",paper="A4")
    assert not [x for x in validate_plot_values(base) if "尺度" in x]
    bad=dict(base,scale_num=1.0,scale_den=None)
    assert any("尺度" in x for x in validate_plot_values(bad))
