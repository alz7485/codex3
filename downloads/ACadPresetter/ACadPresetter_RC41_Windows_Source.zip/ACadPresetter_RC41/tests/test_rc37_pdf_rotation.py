from pathlib import Path

from pypdf import PdfReader, PdfWriter

from app.pdf_postprocess import rotate_a3_a1_left_to_landscape
from app.plot_settings import normalize_plot_settings

PT_PER_MM = 72.0 / 25.4


def _make_pdf(path: Path, sizes_mm):
    w = PdfWriter()
    for width, height in sizes_mm:
        w.add_blank_page(width=width * PT_PER_MM, height=height * PT_PER_MM)
    with path.open("wb") as f:
        w.write(f)


def _display_landscape(page):
    width = float(page.mediabox.width)
    height = float(page.mediabox.height)
    rot = int(page.rotation or 0) % 360
    if rot in (90, 270):
        width, height = height, width
    return width > height


def test_rotate_portrait_a3_a1_only(tmp_path):
    pdf = tmp_path / "mixed.pdf"
    _make_pdf(pdf, [(297, 420), (594, 841), (210, 297), (420, 297)])
    changed = rotate_a3_a1_left_to_landscape(pdf)
    assert changed == [{"page": 1, "size": "A3"}, {"page": 2, "size": "A1"}]
    pages = PdfReader(str(pdf)).pages
    assert int(pages[0].rotation or 0) % 360 == 270
    assert int(pages[1].rotation or 0) % 360 == 270
    assert int(pages[2].rotation or 0) % 360 == 0
    assert int(pages[3].rotation or 0) % 360 == 0
    assert _display_landscape(pages[0])
    assert _display_landscape(pages[1])
    assert _display_landscape(pages[3])


def test_already_landscape_a3_is_not_rotated(tmp_path):
    pdf = tmp_path / "a3_landscape.pdf"
    _make_pdf(pdf, [(420, 297)])
    assert rotate_a3_a1_left_to_landscape(pdf) == []
    page = PdfReader(str(pdf)).pages[0]
    assert int(page.rotation or 0) % 360 == 0


def test_rotation_option_defaults_off_for_legacy_presets():
    assert normalize_plot_settings({})["rotate_a3_a1_landscape"] is False
    assert normalize_plot_settings({"rotate_a3_a1_landscape": True})["rotate_a3_a1_landscape"] is True
