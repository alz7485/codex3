from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")


def test_bulk_updates_do_not_block_qtreewidget_model_signals():
    """Structural model signals must remain live or inserted rows can stay invisible."""
    start = MAIN.index("def _bulk_tree_update")
    end = MAIN.index("def _apply_auto_order_to_tree", start)
    block = MAIN[start:end]
    assert ".model().blockSignals(" not in block
    assert "self.tree.blockSignals(True)" in block


def test_auto_order_does_not_block_model_during_take_add_child():
    start = MAIN.index("def _apply_merge_auto_order")
    end = MAIN.index("def group_selected", start)
    block = MAIN[start:end]
    assert "model.blockSignals" not in block
    assert "takeChild" in block and "addChild" in block


def test_external_drop_finishes_with_rejudge():
    start = MAIN.index("def _handle_external_drop_paths")
    end = MAIN.index("@staticmethod", start)
    block = MAIN[start:end]
    assert "if added:" in block
    assert "self.rejudge()" in block
