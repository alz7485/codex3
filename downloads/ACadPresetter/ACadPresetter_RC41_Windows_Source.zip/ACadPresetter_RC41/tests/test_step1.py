import json
from pathlib import Path

from app.models import DrawingGroup, DrawingItem, DrawingList, next_group_name
from app.preset_manager import ensure_ids, references_to, validate_regex_rules
from app.store import Store, read_text_compat


def test_encoding(tmp_path):
    for enc in ("utf-8", "utf-8-sig", "cp932"):
        p=tmp_path/f"x_{enc}.json"; p.write_bytes('{"名前":"配管図"}'.encode(enc)); assert "配管図" in read_text_compat(p)


def test_initial_creation(tmp_path):
    s=Store(tmp_path/"data"); cfg=s.load_config(); presets=s.load_presets()
    assert cfg["restore_session"] is True and all(k in presets for k in ("plot","rule","dest","name","merge","collection"))


def test_ids_and_references_survive_rename():
    data={k:[] for k in ("plot","rule","dest","name","merge","collection")}
    data["plot"]=[{"name":"A3"}]; ensure_ids(data); pid=data["plot"][0]["id"]
    data["collection"]=[{"id":"c1","name":"集","pairs":[{"rule_id":"r1","plot_id":pid}]}]
    data["plot"][0]["name"]="A3 新名称"
    assert references_to(data,"plot",pid)==["集"]


def test_acplist_does_not_persist_checked(tmp_path):
    dl=DrawingList(groups=[DrawingGroup("新規グループ1",[DrawingItem("C:/a.dwg")])],collection_id="c1")
    s=Store(tmp_path/"data"); p=tmp_path/"work.acplist"; s.save_drawing_list(p,dl)
    raw=json.loads(p.read_text(encoding="utf-8")); assert "checked" not in json.dumps(raw)
    loaded=s.load_drawing_list(p); assert loaded.groups[0].items[0].path=="C:/a.dwg"


def test_group_numbering():
    assert next_group_name(["新規グループ1","📚 新規グループ3"])=="新規グループ2"


def test_regex_validation():
    assert validate_regex_rules([{"name":"bad","mode":"正規表現","value":"["}])
