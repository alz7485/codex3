from pathlib import Path
import tempfile
from app.run_history import RunHistory


def test_run_history_keeps_failed_and_pending_separate():
    with tempfile.TemporaryDirectory() as td:
        h=RunHistory(Path(td))
        rec=h.begin([
            {"source":"A.dwg","kind":"PDF","output":"A.pdf"},
            {"source":"B.dwg","kind":"PDF","output":"B.pdf"},
            {"source":"C.dwg","kind":"PDF","output":"C.pdf"},
        ])
        h.update(rec,"A.dwg","PDF","成功")
        h.update(rec,"B.dwg","PDF","失敗","plot error")
        saved=h.load()["last"]["jobs"]
        assert [x["source"] for x in saved if x["status"]=="失敗"] == ["B.dwg"]
        assert [x["source"] for x in saved if x["status"]=="未処理"] == ["C.dwg"]


def test_cancel_status_can_be_resumed_as_pending():
    with tempfile.TemporaryDirectory() as td:
        h=RunHistory(Path(td))
        rec=h.begin([{"source":"A.dwg","kind":"PDF","output":"A.pdf"}])
        h.update(rec,"A.dwg","PDF","中止")
        saved=h.load()["last"]["jobs"]
        assert saved[0]["status"] in ("未処理","中止")
