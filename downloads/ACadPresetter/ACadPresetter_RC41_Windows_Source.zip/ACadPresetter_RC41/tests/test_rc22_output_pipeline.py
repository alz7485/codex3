from pdf_fixtures import write_pdf, pdf_bytes
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

from app import autocad_backend as backend
from app.adobe_distiller import AdobeDistiller, generated_file_kind
from app.autocad_visibility import HiddenWindowGuard
from app.media_names import resolve_media_name
from app.pdf_output import PdfOutputSession
from app.preflight import build_report


@pytest.mark.parametrize("payload,kind", [
    (b"%PDF-1.4\n", "pdf"), (b"%!PS-Adobe-3.0\n", "postscript"),
    (b"\x04%!PS-Adobe-3.0\n", "postscript"),
    (b"\x1b%-12345X@PJL ENTER LANGUAGE=POSTSCRIPT\n%!PS-Adobe\n", "postscript"),
    (b"garbage", "unknown"), (b"", "empty"),
])
def test_generated_format_uses_bytes_not_extension(tmp_path, payload, kind):
    path=tmp_path/"plot.pdf"
    path.write_bytes(payload)
    assert generated_file_kind(path)==kind


def _macro_doc(source, folder, ok=True):
    state={"active":0}
    calls=[]
    layout=SimpleNamespace(Name="Model",ConfigName="Adobe PDF")
    def getvar(name):
        if name=="CMDACTIVE":
            v=state["active"]
            if v: state["active"]=0
            return v
        if name=="CMDNAMES": return "-PLOT" if state["active"] else ""
        return 0
    def send(cmd):
        calls.append(cmd)
        if not ok: raise RuntimeError("plot failed")
        state["active"]=1
        write_pdf(folder/(source.stem+" (1).pdf"))
    return SimpleNamespace(FullName=str(source),ActiveLayout=layout,GetVariable=getvar,SetVariable=lambda *_:None,SendCommand=send),calls

def test_adobe_trial10g_macro_is_staged_then_final_commit(tmp_path):
    final=tmp_path/"final.pdf"
    final.write_bytes(b"%PDF-old")
    stage=PdfOutputSession(tmp_path/"staging")
    temp=Path(stage.stage("example.dwg",str(final)).temp_path)
    source=tmp_path/"example.dwg"; source.write_bytes(b"dwg")
    doc,calls=_macro_doc(source,tmp_path,True)
    assert backend._plot_pdf_to_file(doc,temp,"Adobe PDF",adobe_watch_dir=tmp_path)
    assert calls and '_.-PLOT' in calls[0]
    assert final.read_bytes()==b"%PDF-old"
    assert stage.atomic_commit(temp,final)==str(final)
    assert final.read_bytes().startswith(b"%PDF-")
    stage.cleanup()

def test_adobe_macro_failure_preserves_old_pdf(tmp_path):
    final=tmp_path/"final.pdf"
    final.write_bytes(b"%PDF-old")
    temp=tmp_path/"new.pdf"
    source=tmp_path/"example.dwg"; source.write_bytes(b"dwg")
    doc,_=_macro_doc(source,tmp_path,False)
    with pytest.raises(RuntimeError,match="-PLOTマクロ送信に失敗"):
        backend._plot_pdf_to_file(doc,temp,"Adobe PDF",adobe_watch_dir=tmp_path)
    assert final.read_bytes()==b"%PDF-old"
    assert not temp.exists()

def test_distiller_configured_hidden_and_synchronous_before_first_method(tmp_path,monkeypatch):
    import sys
    calls=[]
    class Automation:
        def FileToPDF(self,source,output,options):
            assert self.bShowWindow==0 and self.bSpoolJobs==0
            write_pdf(output)
            return 1
    def dispatch(progid):
        calls.append(progid)
        return Automation()
    client=SimpleNamespace(DispatchEx=dispatch)
    monkeypatch.setitem(sys.modules,"win32com",SimpleNamespace(client=client))
    monkeypatch.setitem(sys.modules,"win32com.client",client)
    d=AdobeDistiller()
    for i in range(2):
        ps=tmp_path/f"{i}.ps"; ps.write_bytes(b"%!PS-Adobe-3.0\n")
        d.convert(ps,tmp_path/f"{i}.pdf")
    assert len(calls)==1
    d.close()
    assert d._automation is None


@pytest.mark.parametrize("label,canonical",[
    ("A3","ISO_A3_(297.00_x_420.00_MM)"),
    ("Ａ１","ISO_A1_(594.00_x_841.00_MM)"),
])
def test_standard_paper_aliases_resolve_to_correct_device_name(label,canonical):
    assert resolve_media_name(label,["ISO_A4_(210.00_x_297.00_MM)",canonical])==canonical


def test_localized_media_alias_and_wrong_size_protection():
    assert resolve_media_name("A3",["UserDefinedMetric"],{"UserDefinedMetric":"A3"})=="UserDefinedMetric"
    with pytest.raises(ValueError):
        resolve_media_name("A1",["ISO_A3_(297.00_x_420.00_MM)","Oversize_A1_(625.00_x_882.00_MM)"])
    with pytest.raises(ValueError,match="候補が複数"):
        resolve_media_name("A3",["ISO_A3_(297.00_x_420.00_MM)","ISO_A3_(420.00_x_297.00_MM)"])


def test_stale_media_cache_does_not_block_job_before_live_check(tmp_path):
    src=tmp_path/"a.dwg"; src.touch()
    jobs=[{"source":str(src),"output":str(tmp_path/"a.pdf"),"settings":{"device":"Adobe PDF","paper":"A1"}}]
    report=build_report(jobs,[],{"devices":["Adobe PDF"],"device_media":{"Adobe PDF":["A4"]}})
    assert not report.fatal and not report.file_errors
    assert any("A1" in x.message for x in report.warnings)


def test_unsupported_live_media_is_not_silently_ignored_and_layout_restored():
    original=SimpleNamespace(Name="Original")
    layout=SimpleNamespace(
        Name="Target",ConfigName="old.pc3",CanonicalMediaName="A4",
        RefreshPlotDeviceInfo=lambda:None,GetCanonicalMediaNames=lambda:["A4"],
    )
    doc=SimpleNamespace(ActiveLayout=original,Layouts=[layout])
    with pytest.raises(RuntimeError,match="用紙設定失敗"):
        backend._prepare_plot(doc,{"device":"new.pc3","paper":"A1"},"Target")
    assert layout.ConfigName=="old.pc3" and layout.CanonicalMediaName=="A4"
    assert doc.ActiveLayout is original


def test_dedicated_batch_hides_again_after_each_document_open(monkeypatch):
    app=SimpleNamespace(Name="AutoCAD",Visible=True,HWND=77,Quit=Mock())
    client=SimpleNamespace(DispatchEx=Mock(return_value=app),GetActiveObject=Mock())
    monkeypatch.setattr(backend.AutoCADBackend,"_client",lambda self:client)
    monkeypatch.setattr("app.autocad_visibility.existing_window_handles",lambda:{66})
    guard=Mock()
    monkeypatch.setattr("app.autocad_visibility.HiddenWindowGuard",lambda hwnd:guard)
    def open_doc(_app,source):
        app.Visible=True  # Simulate AutoCAD making its window visible on Open.
        return SimpleNamespace(Close=Mock()),True
    monkeypatch.setattr(backend,"_acquire_document",open_doc)
    with backend.AutoCADBatchSession() as session:
        for source in ("a.dwg","b.dwg"):
            doc,owned=backend._open_for_session(session,source)
            assert app.Visible is False
            doc.Close(False)
    assert client.DispatchEx.call_count==1
    client.GetActiveObject.assert_not_called()
    app.Quit.assert_called_once()
    guard.start.assert_called_once()
    guard.close.assert_called_once()


def test_existing_user_window_returned_by_com_is_not_hidden_or_quit(monkeypatch):
    user=SimpleNamespace(Visible=True,HWND=66,Quit=Mock())
    monkeypatch.setattr(backend.AutoCADBackend,"_client",lambda self:SimpleNamespace(DispatchEx=lambda _:user))
    monkeypatch.setattr("app.autocad_visibility.existing_window_handles",lambda:{66})
    be=backend.AutoCADBackend()
    with pytest.raises(RuntimeError,match="既存ウィンドウ"):
        be.connect(allow_start=True,prefer_running=False)
    assert user.Visible is True and not be.started_by_us
    user.Quit.assert_not_called()


def test_no_dispatch_fallback_can_attach_to_user_instance(monkeypatch):
    client=SimpleNamespace(Dispatch=Mock())
    monkeypatch.setattr(backend.AutoCADBackend,"_client",lambda self:client)
    with pytest.raises(RuntimeError):
        backend.AutoCADBackend().connect(allow_start=True,prefer_running=False)
    client.Dispatch.assert_not_called()


def test_hidden_guard_does_not_hide_reused_handle_from_another_process():
    def set_pid(hwnd,pointer):
        pointer._obj.value=999
    guard=HiddenWindowGuard(77)
    guard._pid=111
    guard._api=SimpleNamespace(IsWindow=lambda _:True,GetWindowThreadProcessId=set_pid,
                               IsWindowVisible=lambda _:True,ShowWindowAsync=Mock())
    guard.hide_now()
    guard._api.ShowWindowAsync.assert_not_called()


@pytest.mark.parametrize("read_mode",["all_settings","layout_list","single_settings"])
def test_dwg_settings_and_layout_inspection_use_dedicated_hidden_autocad(monkeypatch,read_mode):
    layout=SimpleNamespace(Name="Model",ModelType=True,ConfigName="Adobe PDF",CanonicalMediaName="A3",
                           RefreshPlotDeviceInfo=lambda:None)
    doc=SimpleNamespace(ActiveLayout=layout,Layouts=[layout],Close=Mock(),Save=Mock())
    app=SimpleNamespace(Name="AutoCAD",Visible=True,HWND=88,Quit=Mock())
    client=SimpleNamespace(DispatchEx=Mock(return_value=app),GetActiveObject=Mock())
    monkeypatch.setattr(backend.AutoCADBackend,"_client",lambda self:client)
    monkeypatch.setattr("app.autocad_visibility.existing_window_handles",lambda:{66})
    guard=Mock()
    monkeypatch.setattr("app.autocad_visibility.HiddenWindowGuard",lambda hwnd:guard)
    def open_doc(_app,source):
        app.Visible=True
        return doc,True
    monkeypatch.setattr(backend,"_acquire_document",open_doc)
    def refresh():
        assert app.Visible is False
    layout.RefreshPlotDeviceInfo=refresh
    if read_mode=="all_settings":
        result=backend.inspect_drawing_plot_settings("example.dwg")
        assert result["layouts"][0]["settings"]["paper"]=="A3"
    elif read_mode=="layout_list":
        assert backend.list_layouts("example.dwg")==[{"name":"Model","model":True}]
    else:
        assert backend.read_dwg_plot_settings("example.dwg","Model")["paper"]=="A3"
    assert app.Visible is False
    client.GetActiveObject.assert_not_called()
    assert client.DispatchEx.call_count==1
    app.Quit.assert_called_once()
    doc.Close.assert_called_once_with(False)
    doc.Save.assert_not_called()
    guard.start.assert_called_once()
    guard.close.assert_called_once()
