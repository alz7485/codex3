from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'main.py').read_text(encoding='utf-8')


def test_main_compiles_and_auto_order_entry_exists():
    ast.parse(MAIN)
    assert 'def _apply_auto_order_to_tree(self):' in MAIN


def test_bulk_tree_update_disables_repaint_without_blocking_structural_model_signals():
    assert 'def _bulk_tree_update(self):' in MAIN
    assert 'self.tree.setUpdatesEnabled(False)' in MAIN
    assert 'self.tree.blockSignals(True)' in MAIN
    # RC5: model signals must stay live so inserted rows become visible to the view.
    start=MAIN.index('    def _bulk_tree_update(self):')
    end=MAIN.index('\n    def _apply_auto_order_to_tree', start)
    assert '.model().blockSignals(' not in MAIN[start:end]
    assert 'self.tree.setUpdatesEnabled(True)' in MAIN


def test_rejudge_is_batched():
    start=MAIN.index('    def rejudge(self):')
    end=MAIN.index('\n    def open_preset_manager', start)
    body=MAIN[start:end]
    assert 'with self._bulk_tree_update()' in body
    assert 'for it in items' in body


def test_external_drop_is_batched():
    start=MAIN.index('    def _handle_external_drop_paths')
    end=MAIN.index('\n    @staticmethod', start)
    body=MAIN[start:end]
    assert 'with self._bulk_tree_update()' in body
