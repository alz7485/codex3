from pathlib import Path


def test_environment_probe_uses_hidden_owned_session():
    text=Path('app/autocad_backend.py').read_text(encoding='utf-8')
    block=text[text.index('def probe_plot_environment'):text.index('def _point2d')]
    assert 'AutoCADBatchSession' in block
    assert '"dedicated_hidden":True' in block
    assert 'session.close()' in block
    assert 'visible=allow_start' not in block


def test_plot_to_file_waits_for_delayed_pdf():
    text=Path('app/autocad_backend.py').read_text(encoding='utf-8')
    block=text[text.index('def _plot_pdf_to_file'):text.index('def plot_single_pdf')]
    assert 'deadline=time.monotonic()+15.0' in block
    assert 'stable>=2' in block
    assert 'time.sleep(0.2)' in block


def test_window_guard_stops_before_quit():
    text=Path('app/autocad_backend.py').read_text(encoding='utf-8')
    start=text.index('    def close(self):', text.index('class AutoCADBatchSession'))
    end=text.index('    def __enter__', start)
    block=text[start:end]
    assert block.index('self._window_guard.close()') < block.index('app.Quit()')


def test_adobe_candidate_requires_exact_source_or_numbered_name():
    from app.adobe_device_output import _name_score
    assert _name_score('sheet (1).pdf','sheet') == 0
    assert _name_score('sheet.pdf','sheet') == 1
    assert _name_score('sheet (2).pdf','sheet') == 2
    assert _name_score('sheet_other.pdf','sheet') == 99
