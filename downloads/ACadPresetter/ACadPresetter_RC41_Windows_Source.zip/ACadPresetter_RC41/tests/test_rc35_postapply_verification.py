import pytest

from app.autocad_backend import _apply_plot_settings, _verify_applied_plot_settings


class FakeLayout:
    def __init__(self):
        self.ConfigName="Adobe PDF"
        self.CanonicalMediaName="A3"
        self.PaperUnits=1
        self.StyleSheet="monochrome.ctb"
        self.PlotType=4
        self.CenterPlot=False
        self.UseStandardScale=False
        self.StandardScale=0
        self.PlotWithLineweights=True
        self.PlotTransparency=False
        self.PlotWithPlotStyles=True
        self.PlotRotation=0
        self.PlotOrigin=(12.5, 34.5)
        self.CustomScale=(1.0,100.0)
        self.window=((0.0,0.0),(100.0,100.0))
    def RefreshPlotDeviceInfo(self): pass
    def GetCanonicalMediaNames(self): return ["A3"]
    def GetLocaleMediaName(self, name): return name
    def SetCustomScale(self,a,b): self.CustomScale=(a,b)
    def GetCustomScale(self): return self.CustomScale
    def SetWindowToPlot(self,ll,ur): self.window=(tuple(ll),tuple(ur))
    def GetWindowToPlot(self): return self.window


def settings(**kw):
    d={
        "device":"Adobe PDF", "paper":"A3", "plot_style":"monochrome.ctb",
        "plot_area":"窓", "window_x1":0.0, "window_y1":0.0,
        "window_x2":100.0, "window_y2":100.0,
        "orientation":"縦", "rotation":"0°", "paper_units":1,
        "center_plot":False, "offset_x":12.5, "offset_y":34.5,
        "scale_mode":"custom", "fit_to_paper":False,
        "scale_num":1.0, "scale_den":100.0,
        "lineweights":True, "transparency":False, "plot_styles":True,
    }
    d.update(kw)
    return d


def test_rc35_apply_and_verify_style_center_origin_flags():
    lay=FakeLayout()
    st=settings()
    _apply_plot_settings(lay, st)
    assert _verify_applied_plot_settings(lay, st) is True


def test_rc35_detects_silently_rejected_plot_style():
    lay=FakeLayout()
    st=settings()
    lay.StyleSheet="other.ctb"
    with pytest.raises(RuntimeError, match="CTB/STB"):
        _verify_applied_plot_settings(lay, st)


def test_rc35_detects_silently_rejected_center_plot():
    lay=FakeLayout()
    st=settings(center_plot=False)
    lay.CenterPlot=True
    with pytest.raises(RuntimeError, match="中央配置"):
        _verify_applied_plot_settings(lay, st)


def test_rc35_detects_silently_rejected_plot_origin():
    lay=FakeLayout()
    st=settings(center_plot=False, offset_x=12.5, offset_y=34.5)
    lay.PlotOrigin=(0.0,0.0)
    with pytest.raises(RuntimeError, match="印刷原点"):
        _verify_applied_plot_settings(lay, st)


def test_rc35_detects_plot_style_usage_and_lineweight_flags():
    lay=FakeLayout()
    st=settings(plot_styles=True, lineweights=True)
    lay.PlotWithPlotStyles=False
    lay.PlotWithLineweights=False
    with pytest.raises(RuntimeError) as ei:
        _verify_applied_plot_settings(lay, st)
    msg=str(ei.value)
    assert "印刷スタイル使用" in msg
    assert "線の太さ" in msg
