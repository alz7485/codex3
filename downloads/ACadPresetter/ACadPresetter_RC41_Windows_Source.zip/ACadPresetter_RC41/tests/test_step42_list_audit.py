from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'main.py').read_text(encoding='utf-8')

def test_no_shadowed_legacy_group_handlers():
    assert SRC.count('    def group_selected(self):') == 1
    assert SRC.count('    def ungroup_selected(self):') == 1
    assert SRC.count('    def remove_selected(self):') == 1

def test_session_does_not_persist_runtime_check_state():
    start=SRC.index('    def session_dict(self):')
    end=SRC.index('    def save_session(',start)
    block=SRC[start:end]
    assert 'checkState' not in block
    assert 'manual_plot_id' in block

def test_internal_dnd_guards_nested_groups_and_file_children():
    assert 'class CadListTree(QTreeWidget):' in SRC
    assert 'moving_group' in SRC
    assert '~Qt.ItemIsDropEnabled' in SRC

def test_empty_groups_are_cleaned_after_list_operations():
    assert 'def _remove_empty_groups(self):' in SRC
    assert SRC.count('self._remove_empty_groups()') >= 3
