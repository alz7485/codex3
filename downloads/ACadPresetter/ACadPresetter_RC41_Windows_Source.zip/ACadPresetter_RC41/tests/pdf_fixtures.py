from io import BytesIO
from pathlib import Path
from pypdf import PdfWriter


def pdf_bytes(width=100, height=100):
    writer=PdfWriter()
    writer.add_blank_page(width=width,height=height)
    buffer=BytesIO()
    writer.write(buffer)
    writer.close()
    return buffer.getvalue()


def write_pdf(path, width=100, height=100):
    data=pdf_bytes(width,height)
    Path(path).write_bytes(data)
    return data
