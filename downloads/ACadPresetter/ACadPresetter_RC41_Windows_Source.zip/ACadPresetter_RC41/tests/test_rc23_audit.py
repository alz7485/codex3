from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
pytest.importorskip("PySide6.QtWidgets")
from pdf_fixtures import write_pdf, pdf_bytes
from app.pdf_output import PdfOutputSession
from app.preflight import build_report
from app import autocad_backend as backend


@pytest.mark.parametrize('payload',[b'%PDF-1.4\n', b'%PDF-1.4\nnot a document\n%%EOF'])
def test_header_only_pdf_never_replaces_valid_existing(tmp_path,payload):
    final=tmp_path/'old.pdf'; original=write_pdf(final)
    bad=tmp_path/'new.pdf'; bad.write_bytes(payload)
    with pytest.raises(RuntimeError): PdfOutputSession.atomic_commit(bad,final)
    assert final.read_bytes()==original


def test_copy_corruption_never_replaces_old(tmp_path,monkeypatch):
    final=tmp_path/'old.pdf'; original=write_pdf(final)
    new=tmp_path/'new.pdf'; write_pdf(new,200)
    monkeypatch.setattr('app.pdf_output.shutil.copy2',lambda src,dst:Path(dst).write_bytes(b'%PDF-corrupt'))
    with pytest.raises(RuntimeError): PdfOutputSession.atomic_commit(new,final)
    assert final.read_bytes()==original


def test_same_source_layout_output_collision_is_blocked(tmp_path):
    src=tmp_path/'a.dwg'; src.touch()
    job={'source':str(src),'output':str(tmp_path/'same.pdf'),'settings':{'device':'x','paper':'A4'}}
    probe=tmp_path/'.acad_presetter_write_test.tmp'; probe.write_text('user file')
    report=build_report([job,dict(job)],[],{})
    assert any('重複' in x.message for x in report.file_errors)
    assert probe.read_text()=='user file'


@pytest.mark.parametrize('code',[0x800706BA,0x80010108,0x80010007])
def test_localized_com_errors_use_hresult(code):
    exc=RuntimeError(code-2**32,'オートメーション例外')
    assert backend._looks_like_connection_loss(exc)
    assert not backend._looks_like_connection_loss(RuntimeError('invalid paper'))


def test_window_coordinates_precede_type_and_use_trial10g_pairs():
    events=[]
    class Layout:
        ConfigName='x'; CanonicalMediaName='A4'
        def RefreshPlotDeviceInfo(self): pass
        def SetWindowToPlot(self,p1,p2):
            assert tuple(p1)==(0.0,0.0) and tuple(p2)==(100.0,200.0)
            events.append('window')
        def __setattr__(self,name,value):
            if name=='PlotType':
                assert events==['window']
                events.append('type')
            object.__setattr__(self,name,value)
    layout=Layout()
    backend._apply_plot_settings(layout,{'device':'x','paper':'A4','plot_area':'窓',
        'window_x1':0,'window_y1':0,'window_x2':100,'window_y2':200})
    assert events==['window','type']


def test_false_physical_print_result_is_not_success(tmp_path,monkeypatch):
    src=tmp_path/'a.dwg';src.touch()
    doc=SimpleNamespace(Plot=SimpleNamespace(PlotToDevice=Mock(return_value=False)),
        GetVariable=lambda _:0,SetVariable=lambda *_:None,Close=Mock())
    monkeypatch.setattr(backend,'_open_for_session',lambda *_:(doc,True))
    monkeypatch.setattr(backend,'_prepare_plot',lambda *_:(None,None,None,'Printer',False))
    result=backend.print_batch([{'source':str(src),'settings':{'copies':2}}],session=SimpleNamespace(app=object()))
    assert result[0]['status']=='error'
    assert '0/2' in result[0]['message']
    doc.Plot.PlotToDevice.assert_called_once()
    doc.Close.assert_called_once_with(False)


@pytest.mark.parametrize('scale,ratio',[(0,(1,1)),(19,(1,8)),(26,(1,100)),(27,(2,1)),(31,(100,1))])
def test_import_fixed_standard_scale_is_not_fit(scale,ratio,monkeypatch):
    layout=SimpleNamespace(Name='Model',ModelType=True,UseStandardScale=True,StandardScale=scale,
        GetCustomScale=lambda:(9,9))
    doc=SimpleNamespace(ActiveLayout=layout,Layouts=[layout],Close=Mock())
    monkeypatch.setattr(backend,'_open_for_session',lambda *_:(doc,True))
    result=backend.inspect_drawing_plot_settings('a.dwg',session=SimpleNamespace(app=object()))
    st=result['layouts'][0]['settings']
    assert st['fit_to_paper']==(scale==0)
    if scale: assert (st['scale_num'],st['scale_den'])==ratio


@pytest.fixture
def window(tmp_path,monkeypatch):
    from PySide6.QtWidgets import QApplication
    import main
    app=QApplication.instance() or QApplication([])
    monkeypatch.setattr(main,'APP_DIR',tmp_path)
    for method in ('warning','critical','information'):
        monkeypatch.setattr(main.QMessageBox,method,Mock(return_value=main.QMessageBox.Yes))
    w=main.MainWindow()
    w.store.config['existing_pdf_action']='上書きする'
    yield w
    w._output_in_progress=False
    w.close();app.processEvents()


def add_drawing(w,tmp_path,name,parent=None):
    path=tmp_path/name;path.touch()
    w.add_file(path,parent=parent)
    return str(path)


def test_pdf_layout_retry_never_becomes_physical_and_no_double_suffix(window,tmp_path,monkeypatch):
    w=window;src=add_drawing(w,tmp_path,'a.dwg')
    preset={'output':'PDF＋プリンター','device':'Adobe PDF','paper':'A4',
            'printer_device':'Office printer','printer_paper':'A3','layout_mode':'全Layout'}
    monkeypatch.setattr(w,'_resolve_item_assignment',lambda _: {'plot':preset})
    rec=w.run_history.begin([{'source':src,'kind':'PDF:Sheet1','output':str(tmp_path/'a_Sheet1.pdf')},
                             {'source':src,'kind':'印刷:Sheet2','output':''}])
    for j in rec['jobs']:j['status']='失敗'
    w.run_history.save({'last':rec})
    execute=Mock();monkeypatch.setattr(w,'_execute_output_jobs',execute)
    w.retry_last_output('failed')
    pdf,prt,_=execute.call_args.args
    assert len(pdf)==len(prt)==1
    assert pdf[0]['settings']['layout_names']==['Sheet1']
    normal,multi,errors=w._expand_layout_pdf_jobs(pdf)
    assert multi[0]['layout_outputs']=={'Sheet1':str(tmp_path/'a_Sheet1.pdf')}
    assert prt[0]['settings']['device']=='Office printer'
    assert prt[0]['settings']['paper']=='A3'
    assert prt[0]['settings']['layout_names']==['Sheet2']


def test_merge_uses_expanded_outputs_tree_order_and_unique_safe_names(window,tmp_path,monkeypatch):
    w=window;group=w._new_group_item('../same')
    a=add_drawing(w,tmp_path,'first.dwg',group);b=add_drawing(w,tmp_path,'second.dwg',group)
    group2=w._new_group_item('../same')
    c=add_drawing(w,tmp_path,'third.dwg',group2)
    monkeypatch.setattr(w,'_resolve_item_assignment',lambda _: {'plot':{'output':'PDF'}})
    monkeypatch.setattr(w,'_merge_preset_for_collection',lambda:{'enabled':True,'order':'自動並び替え','merged_name':'{グループ名}.pdf'})
    outputs={a:[str(tmp_path/'Z_1.pdf'),str(tmp_path/'Z_2.pdf')],b:[str(tmp_path/'A.pdf')],c:[str(tmp_path/'C1.pdf'),str(tmp_path/'C2.pdf')]}
    plans=w._merge_plan(outputs_by_source=outputs)
    assert plans[0]['inputs']==outputs[a]+outputs[b]
    assert len(plans)==2
    assert plans[0]['output']!=plans[1]['output']
    assert all(Path(x['output']).parent==tmp_path for x in plans)
    outputs.pop(b)
    assert len(w._merge_plan(outputs_by_source=outputs))==1


def test_mixed_layout_pdf_and_print_execute_in_visible_order(window,tmp_path,monkeypatch):
    import main
    w=window
    a=add_drawing(w,tmp_path,'first.dwg');b=add_drawing(w,tmp_path,'second.dwg');c=add_drawing(w,tmp_path,'third.dwg')
    monkeypatch.setattr(w,'_merge_preset_for_collection',lambda:None)
    monkeypatch.setattr(w,'_preflight_dialog',lambda pdf,prt:(pdf,prt))
    session=SimpleNamespace(open=Mock(),close=Mock())
    factory=Mock(return_value=session);monkeypatch.setattr(main,'AutoCADBatchSession',factory)
    calls=[]
    def single(jobs,**kwargs):
        assert kwargs['session'] is session
        calls.append(('PDF',jobs[0]['source']))
        write_pdf(jobs[0]['output'])
        return [{'status':'ok','source':jobs[0]['source'],'output':jobs[0]['output']}]
    def multi(src,outputs,settings,names,**kwargs):
        assert kwargs['session'] is session
        calls.append(('LAYOUT',src))
        for out in outputs.values():write_pdf(out)
        return [{'status':'ok','source':src,'layout':n,'output':outputs[n]} for n in names]
    def printer(jobs,**kwargs):
        assert kwargs['session'] is session
        calls.append(('PRINT',jobs[0]['source']))
        return [{'status':'ok','source':jobs[0]['source']}]
    monkeypatch.setattr(main,'plot_batch_pdf',single);monkeypatch.setattr(main,'plot_layouts_pdf',multi);monkeypatch.setattr(main,'print_batch',printer)
    jobs=[{'source':a,'output':str(tmp_path/'first.pdf'),'settings':{'layout_mode':'指定Layout','layout_names':['S']}},
          {'source':c,'output':str(tmp_path/'third.pdf'),'settings':{'layout_mode':'現在のLayout'}}]
    w._execute_output_jobs(jobs,[{'source':b,'settings':{}}])
    assert calls==[('LAYOUT',a),('PRINT',b),('PDF',c)]
    factory.assert_called_once();session.close.assert_called_once()
    assert (tmp_path/'first_S.pdf').is_file()
    assert (tmp_path/'third.pdf').is_file()


def test_close_and_delete_during_output_only_request_safe_stop(window,tmp_path):
    from PySide6.QtGui import QCloseEvent
    w=window;add_drawing(w,tmp_path,'keep.dwg')
    w.tree.topLevelItem(0).setSelected(True)
    w._set_output_running(True,1)
    w.remove_selected()
    event=QCloseEvent();w.closeEvent(event)
    assert w.tree.topLevelItemCount()==1
    assert not event.isAccepted()
    assert w._output_cancel_requested


@pytest.mark.parametrize('fail_first',[False,True])
def test_multi_layout_merge_requires_every_pdf_from_this_run(window,tmp_path,monkeypatch,fail_first):
    import main
    from pypdf import PdfReader
    w=window;group=w._new_group_item('drawings')
    a=add_drawing(w,tmp_path,'first.dwg',group);b=add_drawing(w,tmp_path,'second.dwg',group)
    monkeypatch.setattr(w,'_resolve_item_assignment',lambda _: {'plot':{'output':'PDF'}})
    monkeypatch.setattr(w,'_merge_preset_for_collection',lambda:{'enabled':True,'order':'現在のリスト順','merged_name':'merged.pdf','individual':'残す'})
    monkeypatch.setattr(w,'_preflight_dialog',lambda pdf,prt:(pdf,prt))
    monkeypatch.setattr(main,'AutoCADBatchSession',lambda *_:SimpleNamespace(open=lambda:None,close=lambda:None))
    old=write_pdf(tmp_path/'merged.pdf',500)
    write_pdf(tmp_path/'first_S.pdf',600)  # Must not be picked up on a failed run.
    def multi(src,outputs,settings,names,**kwargs):
        if fail_first:return [{'source':src,'layout':'S','status':'error','message':'failed'}]
        write_pdf(outputs['S'],100)
        return [{'source':src,'layout':'S','status':'ok','output':outputs['S']}]
    def single(jobs,**kwargs):
        write_pdf(jobs[0]['output'],200)
        return [{'source':b,'status':'ok','output':jobs[0]['output']}]
    monkeypatch.setattr(main,'plot_layouts_pdf',multi);monkeypatch.setattr(main,'plot_batch_pdf',single)
    jobs=[{'source':a,'output':str(tmp_path/'first.pdf'),'settings':{'layout_mode':'指定Layout','layout_names':['S']}},
          {'source':b,'output':str(tmp_path/'second.pdf'),'settings':{}}]
    w._execute_output_jobs(jobs,[])
    if fail_first:
        assert (tmp_path/'merged.pdf').read_bytes()==old
    else:
        assert [float(x.mediabox.width) for x in PdfReader(tmp_path/'merged.pdf').pages]==[100,200]


def test_existing_output_confirmation_is_not_duplicated(window,tmp_path,monkeypatch):
    import main
    w=window;src=tmp_path/'a.dwg';src.touch();write_pdf(tmp_path/'a.pdf')
    jobs=[{'source':str(src),'output':str(tmp_path/'a.pdf'),'settings':{'device':'PDF','paper':'A4'}}]
    assert w._preflight_dialog(jobs,[]) == (jobs,[])
    main.QMessageBox.warning.assert_not_called()


def test_connection_dialog_reuses_hidden_session_and_closes_owned_document(window,monkeypatch):
    import main
    from PySide6.QtWidgets import QPushButton
    w=window
    document=SimpleNamespace(Close=Mock())
    be=SimpleNamespace(info=lambda:{'visible':False})
    session=SimpleNamespace(open=Mock(),close=Mock(),ensure_hidden=Mock(),backend=be,
        app=SimpleNamespace(Documents=SimpleNamespace(Count=0,Add=Mock(return_value=document))))
    factory=Mock(return_value=session);monkeypatch.setattr(main,'AutoCADBatchSession',factory)
    monkeypatch.setattr(main,'detect_status',lambda:{'found':False})
    def interact(dialog):
        button=next(b for b in dialog.findChildren(QPushButton) if b.text()=='AutoCADを起動して接続')
        button.click();button.click()
        return 0
    monkeypatch.setattr(main.QDialog,'exec',interact)
    w.show_autocad_status()
    factory.assert_called_once()
    assert factory.call_args.args[0]['dedicated_hidden'] is True
    document.Close.assert_called_once_with(False)
    session.close.assert_called_once()
