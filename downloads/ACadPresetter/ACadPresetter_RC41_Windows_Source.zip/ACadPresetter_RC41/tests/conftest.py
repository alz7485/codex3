"""Allow Qt-only regression tests on Linux without emulating Windows APIs."""
import os
import sys
from types import ModuleType

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if sys.platform != "win32":
    # Importing main loads autocad_env. Real registry/COM tests supply their own
    # mocks; GUI construction must not call either service during startup.
    sys.modules.setdefault("winreg", ModuleType("winreg"))
