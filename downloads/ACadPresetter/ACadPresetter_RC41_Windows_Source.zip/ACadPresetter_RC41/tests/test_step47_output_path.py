from pathlib import Path
import tempfile

from app.output_path import build_pdf_path, render_pdf_stem, sanitize_filename_component


def test_modes_and_tokens():
    src=Path(r'C:\work\CAD\P001.dwg')
    # Platform-neutral source for path parent semantics in tests.
    src=Path('/work/CAD/P001.dwg')
    assert build_pdf_path(src, {'mode':'CADと同じ','path':''}, {'template':'{CAD名}'}, date_text='20260927') == Path('/work/CAD/P001.pdf')
    assert build_pdf_path(src, {'mode':'相対パス','path':'../PDF'}, {'template':'{グループ名}_{CAD名}_{日付}'}, group_name='G1', date_text='20260927') == Path('/work/PDF/G1_P001_20260927.pdf')
    assert build_pdf_path(src, {'mode':'固定フォルダ','path':'/out'}, {'template':'{CAD名}'}, date_text='20260927') == Path('/out/P001.pdf')


def test_invalid_filename_characters_are_sanitized():
    assert render_pdf_stem('{グループ名}_{CAD名}', cad_name='P:01', group_name='A/B', date_text='20260927') == 'A_B_P_01'
    assert sanitize_filename_component('CON') == '_CON'
    assert sanitize_filename_component('abc. ') == 'abc'


def test_bad_template_and_empty_paths_fail():
    try:
        render_pdf_stem('{UNKNOWN}',cad_name='P1')
        assert False
    except ValueError: pass
    try:
        build_pdf_path('/work/P1.dwg', {'mode':'固定フォルダ','path':''}, {'template':'{CAD名}'})
        assert False
    except ValueError: pass
    try:
        build_pdf_path('/work/P1.dwg', {'mode':'相対パス','path':'/absolute'}, {'template':'{CAD名}'})
        assert False
    except ValueError: pass


def test_collision_keys_are_case_insensitive_by_caller_contract():
    a=build_pdf_path('/a/P1.dwg', {'mode':'固定フォルダ','path':'/out'}, {'template':'Same'})
    b=build_pdf_path('/b/P2.dwg', {'mode':'固定フォルダ','path':'/out'}, {'template':'same'})
    assert str(a).casefold() == str(b).casefold()
