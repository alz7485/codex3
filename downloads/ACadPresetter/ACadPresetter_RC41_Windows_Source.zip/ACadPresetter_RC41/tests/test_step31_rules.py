from app.rules import match_rule, resolve_file, validate_rule


def test_rule_multiple_conditions_and_case_insensitive():
    r={"relation":"AND","case_sensitive":False,"conditions":[{"mode":"含む","value":"A3"},{"mode":"含まない","value":"OLD"}]}
    assert match_rule("p001_a3.dwg",r)
    assert not match_rule("P001_A3_OLD.dwg",r)


def test_regex_and_validation():
    r={"conditions":[{"mode":"正規表現","value":r"_A[34]$"}]}
    assert validate_rule(r)[0]
    assert match_rule("P001_A3.dwg",r)
    bad={"conditions":[{"mode":"正規表現","value":"["}]}
    assert not validate_rule(bad)[0]


def test_collection_default_plot():
    data={"rule":[],"plot":[{"id":"p1","name":"A3"}]}
    rr,pp=resolve_file("UNKNOWN.dwg",{"pairs":[],"default_plot_id":"p1"},data)
    assert rr is None and pp["id"]=="p1"
