from app.autocad_backend import AutoCADBackend, AutoCADConnectionLost, _looks_like_connection_loss
class FakeApp:
    Name='AutoCAD'; Version='25.1'; Caption='AutoCAD 2026'; Visible=True
class FakeClient:
    def __init__(self, active=None): self.active=active; self.dispatched=0
    def GetActiveObject(self, name):
        if self.active is None: raise RuntimeError('none')
        return self.active
    def DispatchEx(self, name): self.dispatched += 1; return FakeApp()
def test_running_instance_is_preferred_and_not_owned(monkeypatch):
    be=AutoCADBackend(); fc=FakeClient(FakeApp()); monkeypatch.setattr(be,'_client',lambda:fc)
    assert be.connect(allow_start=True,prefer_running=True) is fc.active
    assert be.started_by_us is False and fc.dispatched == 0
def test_start_when_no_running_instance(monkeypatch):
    be=AutoCADBackend(); fc=FakeClient(None); monkeypatch.setattr(be,'_client',lambda:fc)
    app=be.connect(allow_start=True,visible=True,selected_year='自動')
    assert app.Name=='AutoCAD' and be.started_by_us is True and fc.dispatched == 1
def test_disconnect_never_quits_application():
    class App(FakeApp):
        def Quit(self): raise AssertionError('Quit must never be called')
    be=AutoCADBackend(); be.app=App(); be.started_by_us=True
    be.disconnect(); assert be.app is None
def test_connection_loss_classification():
    assert _looks_like_connection_loss(AutoCADConnectionLost('専用AutoCADを非表示に維持できません'))
    assert _looks_like_connection_loss(RuntimeError('RPC server is unavailable 0x800706BA'))
    assert _looks_like_connection_loss(RuntimeError('Object invoked has disconnected from its clients'))
    assert not _looks_like_connection_loss(RuntimeError('用紙がありません'))
def test_ensure_alive_reports_disconnect():
    be=AutoCADBackend()
    try: be.ensure_alive()
    except AutoCADConnectionLost: pass
    else: raise AssertionError('expected AutoCADConnectionLost')
