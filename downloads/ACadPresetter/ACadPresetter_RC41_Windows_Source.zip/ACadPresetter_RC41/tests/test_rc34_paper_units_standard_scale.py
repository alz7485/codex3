from app.autocad_backend import _apply_plot_settings, _verify_applied_plot_settings
from app.plot_settings import normalize_plot_settings


class FakeLayout:
    def __init__(self):
        self.ConfigName=""
        self.CanonicalMediaName=""
        self.PaperUnits=0
        self.StyleSheet=""
        self.PlotType=5
        self.CenterPlot=True
        self.UseStandardScale=False
        self.StandardScale=0
        self.PlotWithLineweights=True
        self.PlotTransparency=False
        self.PlotWithPlotStyles=True
        self.PlotRotation=0
        self.PlotOrigin=(0.0,0.0)
        self.CustomScale=(1.0,1.0)
    def RefreshPlotDeviceInfo(self): pass
    def SetCustomScale(self,a,b): self.CustomScale=(a,b)
    def GetCustomScale(self): return self.CustomScale


def base(**kw):
    d={
        "device":"", "paper":"", "plot_style":"", "plot_area":"レイアウト",
        "fit_to_paper":False, "center_plot":True,
        "scale_num":1.0, "scale_den":100.0,
        "lineweights":True, "transparency":False, "plot_styles":True,
        "orientation":"縦", "rotation":"0°", "offset_x":0.0, "offset_y":0.0,
    }
    d.update(kw)
    return d


def test_normalize_keeps_exact_scale_metadata_optional():
    s=normalize_plot_settings({})
    assert s["scale_mode"] is None
    assert s["standard_scale_index"] is None
    assert s["paper_units"] is None


def test_trial10g_paper_units_are_applied_before_plotting():
    lay=FakeLayout()
    st=base(scale_mode="custom", paper_units=1)
    _apply_plot_settings(lay,st)
    assert lay.PaperUnits == 1
    assert _verify_applied_plot_settings(lay,st) is True


def test_exact_standard_scale_is_not_converted_to_custom_scale():
    lay=FakeLayout()
    called=[]
    lay.SetCustomScale=lambda a,b: called.append((a,b))
    st=base(scale_mode="standard", use_standard_scale=True,
            standard_scale_index=27, paper_units=1,
            scale_num=1.0, scale_den=100.0)
    _apply_plot_settings(lay,st)
    assert lay.UseStandardScale is True
    assert lay.StandardScale == 27
    assert called == []
    assert _verify_applied_plot_settings(lay,st) is True


def test_fit_scale_uses_exact_autocad_scale_to_fit_enum():
    lay=FakeLayout()
    st=base(scale_mode="fit", fit_to_paper=True,
            use_standard_scale=True, standard_scale_index=0)
    _apply_plot_settings(lay,st)
    assert lay.UseStandardScale is True
    assert lay.StandardScale == 0
    assert _verify_applied_plot_settings(lay,st) is True
