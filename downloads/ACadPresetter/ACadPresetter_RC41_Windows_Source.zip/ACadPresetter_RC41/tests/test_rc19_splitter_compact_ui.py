from pathlib import Path

MAIN=(Path(__file__).parents[1]/"main.py").read_text(encoding="utf-8")

def test_left_panes_are_protected_from_editor_width_pressure():
    assert "self.kinds.setMinimumWidth(118)" in MAIN
    assert "self.items.setMinimumWidth(155)" in MAIN
    assert "split.setChildrenCollapsible(False)" in MAIN
    assert "split.setSizes([125,170,500])" in MAIN

def test_editor_fields_do_not_expand_to_full_right_pane():
    assert "QFormLayout.FieldsStayAtSizeHint" in MAIN
    assert "w.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)" in MAIN
    assert "w.setMaximumWidth(590)" in MAIN
    assert "body_lay.addWidget(w, 0, Qt.AlignLeft | Qt.AlignTop)" in MAIN

def test_collection_spanning_controls_are_capped():
    assert "pairs_box.setMaximumWidth(420)" in MAIN
    assert "addbtn.setFixedWidth(190)" in MAIN
    assert "testbox.setMaximumWidth(430)" in MAIN
    assert 'btn=QPushButton("保存"); btn.setFixedWidth(110)' in MAIN
