from pdf_fixtures import write_pdf, pdf_bytes
"""Regression tests runnable without Windows, AutoCAD or PySide6."""
import ast
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from app import adobe_pdf, autocad_backend


def denied_result():
    return adobe_pdf.AdobePdfFontResult(
        applicable=True, found=True, access_denied=True,
        message="machine registry access denied",
    )


class AdobePermissionTests(unittest.TestCase):
    def test_registry_denial_is_reported_without_claiming_printer_setting_is_on(self):
        def denied(_registry, result):
            result.access_denied = True

        with patch.object(adobe_pdf.os, "name", "nt"), \
             patch.dict(sys.modules, {"winreg": SimpleNamespace()}), \
             patch.object(adobe_pdf, "_ensure_distiller_preference", side_effect=denied), \
             patch.object(adobe_pdf, "_ensure_legacy_driver_preference"):
            result = adobe_pdf.ensure_adobe_pdf_document_fonts("Adobe PDF")
        self.assertTrue(result.access_denied)
        self.assertFalse(result.verified_off)
        self.assertIn("出力を試行", result.message)
        self.assertNotIn("OFFにしてください", result.message)

    def test_main_output_entry_continues_after_registry_denial(self):
        # Compile the real entry method without importing the Qt UI. Stop at
        # layout expansion, before any AutoCAD session or actual output starts.
        source = Path(__file__).resolve().parents[1] / "main.py"
        tree = ast.parse(source.read_text(encoding="utf-8"))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MainWindow")
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "_execute_output_jobs")
        namespace = {
            "ensure_adobe_pdf_document_fonts": Mock(return_value=denied_result()),
            "is_adobe_pdf_device": adobe_pdf.is_adobe_pdf_device,
            "normalize_timeout": __import__("app.adobe_device_output",fromlist=["normalize_timeout"]).normalize_timeout,
            "QMessageBox": SimpleNamespace(critical=Mock()),
        }
        exec(compile(ast.Module(body=[method], type_ignores=[]), str(source), "exec"), namespace)

        class ReachedLayoutExpansion(BaseException):
            pass

        expand = Mock(side_effect=ReachedLayoutExpansion)
        owner = SimpleNamespace(store=SimpleNamespace(config={}), _expand_layout_pdf_jobs=expand)
        jobs = [{"source": "example.dwg", "settings": {"device": "Adobe PDF"}}]
        with self.assertRaises(ReachedLayoutExpansion):
            namespace["_execute_output_jobs"](owner, jobs, [])
        namespace["ensure_adobe_pdf_document_fonts"].assert_called_once_with("Adobe PDF")
        namespace["QMessageBox"].critical.assert_not_called()

    def _run_pdf(self, stored_settings=False, multi_layout=False, plot_ok=True):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "sample.dwg"
            source.write_bytes(b"fake drawing")
            output = Path(td) / "sample.pdf"
            layout = SimpleNamespace(Name="Model", ConfigName="Adobe PDF", RefreshPlotDeviceInfo=Mock())

            state={"active":0}
            send=Mock()
            def send_command(cmd):
                send(cmd)
                if not plot_ok:
                    raise RuntimeError("plot failed")
                state["active"]=1
                write_pdf(source.with_name(source.stem + " (1).pdf"))
            def get_variable(name):
                if name=="CMDACTIVE":
                    v=state["active"]
                    if v: state["active"]=0
                    return v
                if name=="CMDNAMES": return "-PLOT" if state["active"] else ""
                if name=="BACKGROUNDPLOT": return 2
                return 0
            doc = SimpleNamespace(
                FullName=str(source), ActiveLayout=layout, Layouts=[layout],
                GetVariable=Mock(side_effect=get_variable), SetVariable=Mock(), SendCommand=send_command,
                Save=Mock(), Close=Mock(),
            )
            session = SimpleNamespace(app=object(),options={"adobe_pdf_watch_dir":str(source.parent)})
            settings = {"device": "Adobe PDF", "paper": "A4"}
            if stored_settings:
                settings["setting_method"] = "DWG/DXFに保存されている設定を使用"
                # A stale preset device must not override the DWG-saved device.
                settings["device"] = "old.pc3"
            with patch.object(adobe_pdf, "ensure_adobe_pdf_document_fonts", return_value=denied_result()), \
                 patch.object(autocad_backend, "_acquire_document", return_value=(doc, True)):
                if multi_layout:
                    results = autocad_backend.plot_layouts_pdf(
                        source, {"Model": str(output)}, settings, ["Model"], session=session,
                    )
                else:
                    results = autocad_backend.plot_batch_pdf([
                        {"source": str(source), "output": str(output), "settings": settings},
                    ], session=session)
            self.assertGreaterEqual(send.call_count,1)
            if plot_ok:
                self.assertTrue(output.exists())
            doc.Save.assert_not_called()
            doc.Close.assert_called_once_with(False)
            self.assertEqual(doc.SetVariable.call_args_list[-1].args, ("BACKGROUNDPLOT", 2))
            self.assertEqual(layout.ConfigName, "Adobe PDF")
            return results

    def test_preset_pdf_output_proceeds_when_registry_update_is_denied(self):
        self.assertEqual(self._run_pdf()[0]["status"], "ok")

    def test_dwg_saved_settings_output_proceeds_when_registry_update_is_denied(self):
        self.assertEqual(self._run_pdf(stored_settings=True)[0]["status"], "ok")

    def test_multiple_layout_output_proceeds_when_registry_update_is_denied(self):
        self.assertEqual(self._run_pdf(multi_layout=True)[0]["status"], "ok")

    def test_actual_plot_failure_still_returns_error(self):
        result = self._run_pdf(plot_ok=False)[0]
        self.assertEqual(result["status"], "error")
        self.assertIn("-PLOTマクロ送信に失敗", result["message"])


if __name__ == "__main__":
    unittest.main()
