from pathlib import Path


def test_regex_builder_entry_exists():
    root = Path(__file__).resolve().parents[1]
    text = (root / "main.py").read_text(encoding="utf-8")
    assert "class RegexBuilderDialog(QDialog):" in text
    assert 'QPushButton("正規表現ビルダー...")' in text
    assert "dlg=RegexBuilderDialog(" in text


def test_regex_builder_entry_is_no_longer_placeholder():
    root = Path(__file__).resolve().parents[1]
    text = (root / "main.py").read_text(encoding="utf-8")
    assert "詳細仕様は今後追加します" not in text
    assert "ファイル名の形" in text
