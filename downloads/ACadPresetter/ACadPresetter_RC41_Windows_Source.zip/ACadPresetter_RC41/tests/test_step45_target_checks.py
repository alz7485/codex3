from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'main.py').read_text(encoding='utf-8')


def block(start_name, end_name):
    start=SRC.index(f'    def {start_name}(')
    end=SRC.index(f'    def {end_name}(', start)
    return SRC[start:end]


def test_child_check_recalculates_parent_three_state():
    assert 'def _refresh_group_check_state(self, group):' in SRC
    changed=block('_on_tree_item_changed','_manual_reorder_allowed')
    assert 'item.parent()' in changed
    assert '_refresh_group_check_state(item.parent())' in changed
    assert 'Qt.PartiallyChecked' in SRC


def test_group_check_propagates_to_children():
    changed=block('_on_tree_item_changed','_manual_reorder_allowed')
    assert 'for i in range(item.childCount())' in changed
    assert 'item.child(i).setCheckState(0,state)' in changed


def test_new_and_loaded_items_default_to_checked():
    assert SRC.count('setCheckState(0,Qt.Checked)') >= 5
    load=block('load_session','_drawing_list_payload')
    assert 'setCheckState(0,Qt.Checked)' in load


def test_runtime_checks_are_not_persisted():
    session=block('session_dict','save_session')
    payload=block('_drawing_list_payload','export_list')
    assert 'checkState' not in session
    assert 'checkState' not in payload
    toggle=block('toggle_selected_output','_selected_file_items')
    assert 'save_session' not in toggle


def test_retry_uses_history_without_changing_target_checks():
    retry=block('retry_last_output','_layout_targets')
    assert 'setCheckState' not in retry
    assert 'run_history.load()' in retry


def test_status_shows_runtime_target_count():
    status=block('update_status','build_pdf_jobs')
    assert 'targets=' in status
    assert '対象 {targets}' in status
