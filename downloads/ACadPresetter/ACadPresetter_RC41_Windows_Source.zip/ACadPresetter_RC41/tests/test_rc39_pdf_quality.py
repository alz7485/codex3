from io import BytesIO
from pathlib import Path
import json
import pytest
from pypdf import PdfReader, PdfWriter
from pdf_fixtures import write_pdf
from app.pdf_merge import merge_pdfs
from app.output_path import sanitize_filename_component
from app.run_history import RunHistory
from app.diagnostics import build_diagnostic_report


def pdf_with_outline(path, width, title):
    writer=PdfWriter()
    writer.add_blank_page(width=width,height=400)
    writer.add_metadata({'/Title':title})
    writer.add_outline_item(title,0)
    with path.open('wb') as f: writer.write(f)
    writer.close()


def test_merge_preserves_page_order_outlines_and_first_title(tmp_path):
    a,b=tmp_path/'a.pdf',tmp_path/'b.pdf'
    pdf_with_outline(a,200,'First sheet')
    pdf_with_outline(b,300,'Second sheet')
    output=tmp_path/'merged.pdf'
    assert merge_pdfs([a,b],output)==str(output)
    reader=PdfReader(BytesIO(output.read_bytes()),strict=True)
    assert [float(page.mediabox.width) for page in reader.pages]==[200,300]
    assert reader.metadata.title=='First sheet'
    assert [item.title for item in reader.outline]==['First sheet','Second sheet']
    assert not list(tmp_path.glob('*.merge_tmp'))


@pytest.mark.parametrize('kind',['empty','corrupt','missing'])
def test_invalid_merge_preserves_existing_output(tmp_path,kind):
    output=tmp_path/'final.pdf';old=write_pdf(output)
    source=tmp_path/'source.pdf'
    if kind=='corrupt': source.write_bytes(b'%PDF-1.7\ninvalid')
    inputs=[] if kind=='empty' else [source]
    with pytest.raises((RuntimeError,ValueError)): merge_pdfs(inputs,output)
    assert output.read_bytes()==old
    assert not list(tmp_path.glob('*.merge_tmp'))


def test_merge_does_not_keep_windows_input_handles_open(tmp_path,monkeypatch):
    source=tmp_path/'source.pdf';write_pdf(source)
    output=tmp_path/'output.pdf'
    from app import pdf_merge
    original=pdf_merge.os.replace
    def replace(src,dst):
        # PdfReader receives memory streams, so even replacing a source on
        # Windows cannot collide with a PdfReader-owned file handle.
        source.rename(tmp_path/'moved.pdf')
        return original(src,dst)
    monkeypatch.setattr(pdf_merge.os,'replace',replace)
    merge_pdfs([source],output)
    assert output.exists() and not source.exists()


@pytest.mark.parametrize('name',['CON','CON.txt','nul.pdf','COM1.extra','LPT9.more.pdf'])
def test_windows_reserved_names_are_safe_even_with_extensions(name):
    assert sanitize_filename_component(name).startswith('_')


def test_trace_is_saved_in_history_and_output_log(tmp_path):
    history=RunHistory(tmp_path,{'log_enabled':True})
    record=history.begin([{'source':'sheet.dwg','kind':'PDF','output':'sheet.pdf'}])
    history.update(record,'sheet.dwg','PDF','成功',trace=['macro sent','PDF validated'])
    history.finish(record)
    assert history.load()['last']['jobs'][0]['trace']==['macro sent','PDF validated']
    log=next((tmp_path/'data'/'logs').glob('output_*.json'))
    assert json.loads(log.read_text())['jobs'][0]['trace']==['macro sent','PDF validated']


def test_diagnostics_explains_missing_adobe_folder_without_printing(tmp_path):
    report=build_diagnostic_report(tmp_path,{},config={'adobe_pdf_timeout':180})
    assert '未指定（Adobe PDF使用時は設定が必要）' in report
    assert '生成待機: 180秒' in report
    assert '実行しません' in report
