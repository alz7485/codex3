from pathlib import Path
import tempfile
from app.drop_import import classify_external_drop, direct_cad_children, natural_path_key, normalize_drop_group_mode

ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'main.py').read_text(encoding='utf-8')


def test_folder_scan_is_direct_only_and_natural_order():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        (root/'P10.dwg').write_text('x')
        (root/'P2.dxf').write_text('x')
        (root/'ignore.pdf').write_text('x')
        sub=root/'sub'; sub.mkdir(); (sub/'P1.dwg').write_text('x')
        got=[p.name for p in direct_cad_children(root)]
        assert got==['P2.dxf','P10.dwg']


def test_mixed_drop_keeps_folders_and_only_direct_cad_files():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); folder=root/'A'; folder.mkdir()
        dwg=root/'X.dwg'; dwg.write_text('x')
        txt=root/'X.txt'; txt.write_text('x')
        folders,direct=classify_external_drop([folder,dwg,txt])
        assert folders==[folder]
        assert direct==[dwg]


def test_group_mode_current_and_legacy_values_are_supported():
    assert normalize_drop_group_mode('group')=='group'
    assert normalize_drop_group_mode('自動で1グループにする')=='group'
    assert normalize_drop_group_mode('ask')=='ask'
    assert normalize_drop_group_mode('individual')=='individual'


def test_tree_forwards_explorer_drop_to_single_importer():
    assert 'def _handle_external_drop_paths(self, paths):' in SRC
    assert 'owner._handle_external_drop_paths(paths)' in SRC
    assert 'direct_cad_children(folder)' in SRC
    assert 'normalize_drop_group_mode' in SRC
