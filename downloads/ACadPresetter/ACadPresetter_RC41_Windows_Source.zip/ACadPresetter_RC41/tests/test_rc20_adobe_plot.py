from pdf_fixtures import write_pdf
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from app.autocad_backend import _plot_pdf_to_file


class PdfPlotCallTests(unittest.TestCase):
    def test_adobe_pdf_uses_trial10g_plot_macro_and_captures_driver_pdf(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            source=root/'drawing.dwg'; source.write_bytes(b'dwg')
            output=root/'stage'/'adobe.pdf'; output.parent.mkdir()
            calls=[]
            state={"active":0}
            layout=SimpleNamespace(Name="Model",ConfigName="Adobe PDF")
            def getvar(name):
                if name=="CMDACTIVE":
                    v=state["active"]
                    if v: state["active"]=0
                    return v
                if name=="CMDNAMES": return "-PLOT" if state["active"] else ""
                return 0
            def send(cmd):
                calls.append(cmd); state["active"]=1
                write_pdf(root/'drawing (1).pdf')
            doc=SimpleNamespace(FullName=str(source),ActiveLayout=layout,GetVariable=getvar,SetVariable=lambda *_:None,SendCommand=send)
            self.assertTrue(_plot_pdf_to_file(doc,output,'Adobe PDF',adobe_watch_dir=root))
            self.assertEqual(len(calls),1)
            self.assertIn('_.-PLOT',calls[0])
            self.assertTrue(output.exists())
            self.assertTrue(output.read_bytes().startswith(b'%PDF-'))

    def test_pc3_uses_plot_to_file(self):
        with tempfile.TemporaryDirectory() as td:
            output=Path(td)/'acad.pdf'; calls=[]
            def plot(*args):
                calls.append(args); write_pdf(output); return True
            doc=SimpleNamespace(Plot=SimpleNamespace(PlotToFile=plot))
            self.assertTrue(_plot_pdf_to_file(doc,output,'DWG To PDF.pc3'))
            self.assertEqual(calls,[(str(output),)])

    def test_false_pc3_plot_result_is_error_even_if_file_exists(self):
        with tempfile.TemporaryDirectory() as td:
            output=Path(td)/'old.pdf'; write_pdf(output)
            doc=SimpleNamespace(Plot=SimpleNamespace(PlotToFile=lambda *_:False))
            with self.assertRaisesRegex(RuntimeError,'受け付けませんでした'):
                _plot_pdf_to_file(doc,output,'DWG To PDF.pc3')


if __name__=='__main__':
    unittest.main()
