import os
import sys
from types import SimpleNamespace

import pytest

from app import adobe_pdf


def test_rc14_adobe_uses_documented_distiller_preference():
    src = open(adobe_pdf.__file__, encoding="utf-8").read()
    assert 'ADOBE_DISTILLER_VALUE = "DonotSendFont"' in src
    assert 'DISTILLER_ROOT = r"SOFTWARE\\Adobe\\Acrobat Distiller"' in src


def test_rc14_adobe_sets_missing_documented_value_to_zero(monkeypatch):
    values = {}
    root = adobe_pdf.DISTILLER_ROOT
    version = root + r"\DC"

    class Key:
        def __init__(self, path): self.path = path
        def __enter__(self): return self
        def __exit__(self, *args): return False

    def open_key(hive, path, reserved=0, access=0):
        if path in (root, version):
            return Key(path)
        raise FileNotFoundError(path)

    def enum_key(key, i):
        if key.path == root and i == 0:
            return "DC"
        raise OSError("end")

    def query_value(key, name):
        k = (key.path, name)
        if k not in values:
            raise FileNotFoundError(name)
        return values[k], 4

    def set_value(key, name, reserved, typ, value):
        values[(key.path, name)] = value

    fake = SimpleNamespace(
        HKEY_LOCAL_MACHINE=object(), KEY_READ=1, KEY_SET_VALUE=2,
        KEY_WOW64_64KEY=0x100, KEY_WOW64_32KEY=0x200, REG_DWORD=4,
        OpenKey=open_key, EnumKey=enum_key, QueryValueEx=query_value, SetValueEx=set_value,
    )
    monkeypatch.setitem(sys.modules, "winreg", fake)
    monkeypatch.setattr(adobe_pdf.os, "name", "nt")
    r = adobe_pdf.ensure_adobe_pdf_document_fonts("Adobe PDF")
    assert values[(version, "DonotSendFont")] == 0
    assert r.changed and r.verified_off and not r.access_denied


def test_rc14_regex_token_is_block_and_numeric_length_applies(monkeypatch):
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    pytest.importorskip("PySide6")
    from PySide6.QtWidgets import QApplication
    from main import RegexBuilderDialog
    app = QApplication.instance() or QApplication([])
    dlg = RegexBuilderDialog(initial_template="P-{数字}-A")
    # Clicking/positioning anywhere inside the token resolves to the whole token.
    pos = dlg.template_edit.text().index("数")
    span = dlg.template_edit.select_token_at(pos)
    app.processEvents()
    assert span[2] == "数字"
    assert dlg.template_edit.selectedText() == "{数字}"
    dlg._sync_selected_token_controls()
    assert dlg.length_mode.isEnabled()
    dlg.length_mode.setCurrentText("固定")
    dlg.len_a.setValue(4)
    dlg._apply_length_to_selected()
    app.processEvents()
    assert dlg.template_edit.text() == "P-{数字:4}-A"
    assert dlg.template_edit.selectedText() == "{数字:4}"
    assert dlg.regex_preview.text() == r"^P\-[0-9]{4}\-A$"
    dlg.close()
