from pathlib import Path


def test_preset_editor_layout_is_not_forced_into_scroll_area():
    text = (Path(__file__).parents[1] / "main.py").read_text(encoding="utf-8")
    block = text[text.index("class PresetDialog"):text.index("class CadListTree")]
    assert "QScrollArea()" not in block
    assert "body_lay.setAlignment(Qt.AlignTop)" in block


def test_preset_dialog_has_safe_minimum_size():
    text = (Path(__file__).parents[1] / "main.py").read_text(encoding="utf-8")
    assert "self.setMinimumSize(800, min(720, dialog_h))" in text
