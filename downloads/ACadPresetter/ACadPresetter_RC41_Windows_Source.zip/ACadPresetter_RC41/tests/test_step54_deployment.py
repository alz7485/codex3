from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def test_requirements_cover_runtime_dependencies():
    req = (ROOT / 'requirements.txt').read_text(encoding='utf-8').lower()
    for name in ('pyside6', 'pywin32', 'pypdf'):
        assert name in req


def test_onedir_build_uses_final_app_name_and_no_bat_dependency():
    build = (ROOT / 'BUILD_onedir.txt').read_text(encoding='utf-8')
    assert '--onedir' in build
    assert '--name ACadPresetter' in build
    assert '--name CADOutput' not in build
    assert not (ROOT / 'build_onedir.bat').exists()


def test_build_does_not_bundle_writable_data_into_internal():
    build = (ROOT / 'BUILD_onedir.txt').read_text(encoding='utf-8')
    # Both a PATH interpreter and the documented Windows virtualenv interpreter
    # are valid. The test checks packaging options, not an interpreter spelling.
    command_lines = [x for x in build.splitlines()
                     if re.match(r'^\s*(?:python|(?:\S*[\\/])?python\.exe)\s+-m\s+PyInstaller\s+',x,re.I)]
    assert command_lines
    assert all('--add-data' not in command for command in command_lines)


def test_legacy_pagesetup_prefix_removed():
    backend = (ROOT / 'app' / 'autocad_backend.py').read_text(encoding='utf-8')
    assert '"CADOutput_"+settings.get' not in backend
    assert '"ACadPresetter_"+settings.get' in backend
