from app.list_order import auto_order_enabled, order_paths

RULES=[
 {"id":"cover","mode":"含む","value":"COVER"},
 {"id":"a3","mode":"含む","value":"A3"},
 {"id":"a4","mode":"含む","value":"A4"},
]

def test_manual_order_is_preserved():
    mp={"enabled":True,"order":"現在のリスト順"}
    src=["P10_A4.dwg","COVER.dwg","P2_A3.dwg"]
    assert order_paths(src,mp,RULES)==src
    assert not auto_order_enabled(mp)

def test_auto_order_uses_rule_priority_then_natural_order():
    mp={"enabled":True,"order":"自動並び替え","sort_rule_ids":["cover","a3","a4"]}
    src=["P10_A3.dwg","P2_A4.dwg","P2_A3.dwg","Z.dwg","COVER.dwg"]
    assert order_paths(src,mp,RULES)==["COVER.dwg","P2_A3.dwg","P10_A3.dwg","P2_A4.dwg","Z.dwg"]

def test_disabled_merge_does_not_auto_sort():
    mp={"enabled":False,"order":"自動並び替え","sort_rule_ids":["cover"]}
    src=["Z.dwg","COVER.dwg"]
    assert order_paths(src,mp,RULES)==src
