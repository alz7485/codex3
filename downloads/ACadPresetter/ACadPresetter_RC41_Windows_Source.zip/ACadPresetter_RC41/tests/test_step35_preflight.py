from pathlib import Path
from app.preflight import build_report


def env():
    return {"devices":["PDF.pc3","Printer A"],"device_media":{"PDF.pc3":["A3"],"Printer A":["A4"]},"styles":["mono.ctb"]}


def test_bad_device_blocks_only_that_source(tmp_path):
    a=tmp_path/'a.dwg'; b=tmp_path/'b.dwg'; a.write_bytes(b'x'); b.write_bytes(b'x')
    pdf=[
        {"source":str(a),"output":str(tmp_path/'a.pdf'),"settings":{"device":"PDF.pc3","paper":"A3","plot_style":"mono.ctb"}},
        {"source":str(b),"output":str(tmp_path/'b.pdf'),"settings":{"device":"OLD.pc3","paper":"A3","plot_style":"mono.ctb"}},
    ]
    r=build_report(pdf,[],env())
    assert str(b) in r.blocked_sources()
    assert str(a) not in r.blocked_sources()
    assert not r.fatal


def test_duplicate_output_blocks_both_sources(tmp_path):
    a=tmp_path/'a.dwg'; b=tmp_path/'b.dwg'; a.write_bytes(b'x'); b.write_bytes(b'x')
    out=tmp_path/'same.pdf'
    jobs=[{"source":str(x),"output":str(out),"settings":{"device":"PDF.pc3","paper":"A3"}} for x in (a,b)]
    r=build_report(jobs,[],env())
    assert r.blocked_sources()=={str(a),str(b)}


def test_existing_pdf_is_warning_not_block(tmp_path):
    a=tmp_path/'a.dwg'; a.write_bytes(b'x'); out=tmp_path/'a.pdf'; out.write_bytes(b'old')
    r=build_report([{"source":str(a),"output":str(out),"settings":{"device":"PDF.pc3","paper":"A3"}}],[],env())
    assert r.warnings and not r.file_errors and not r.fatal
