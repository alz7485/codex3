from pathlib import Path

def test_rc6_group_options_source():
    src=Path(__file__).parents[1].joinpath('main.py').read_text(encoding='utf-8')
    assert 'group_name_from_folder' in src
    assert 'expand_new_groups' in src
    assert 'グループ名にファイルの格納フォルダ名を使用する' in src
    assert 'グループ追加時に展開する' in src
    assert 'def _group_name_for_paths' in src
