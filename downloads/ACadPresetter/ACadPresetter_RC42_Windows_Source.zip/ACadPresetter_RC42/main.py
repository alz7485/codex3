
import sys
import copy
import uuid
import shutil
import time
from contextlib import contextmanager
from pathlib import Path
from PySide6.QtWidgets import QProgressDialog, QSpinBox, QProgressBar
from PySide6.QtGui import QCursor, QDesktopServices, QShortcut, QKeySequence, QIcon, QPixmap, QDoubleValidator
from PySide6.QtCore import QUrl, Qt, QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QComboBox,QPushButton,
    QTreeWidget,QTreeWidgetItem,QAbstractItemView,QMenu,QMessageBox,QLabel,QDialog,
    QListWidget,QListWidgetItem,QStackedWidget,QFormLayout,QLineEdit,QCheckBox,QSpinBox,QDialogButtonBox,
    QSplitter,QInputDialog,QDoubleSpinBox,QFileDialog,QGroupBox,QRadioButton,QTabWidget,QPlainTextEdit,
    QScrollArea,QSizePolicy
)
from app.store import Store
from app.rules import match_rule, resolve_file, resolve_file_detail, validate_rule
from app.session import SessionManager
from app.autocad_env import detect_status
from app.autocad_backend import AutoCADBackend, AutoCADBatchSession, probe_plot_environment, plot_single_pdf, plot_batch_pdf, print_batch, save_page_setup, list_layouts, plot_layouts_pdf, read_dwg_plot_settings, inspect_drawing_plot_settings
from app.autocad_environment import normalize_environment, media_for_device, media_choices_for_device, validate_plot_preset
from app.plot_settings import normalize_plot_settings, validate_plot_values
from app.pdf_merge import merge_pdfs, pdf_content_fingerprint
from app.pdf_postprocess import rotate_a3_a1_left_to_landscape
from app.pdf_output import PdfOutputSession, existing_outputs
from app.preflight import check_jobs, build_report
from app.run_history import RunHistory
from app.diagnostics import build_diagnostic_report, save_report
from app.list_order import auto_order_enabled, order_paths
from app.output_path import build_pdf_path, render_pdf_stem
from app.drop_import import classify_external_drop, direct_cad_children, natural_path_key, normalize_drop_group_mode
from app.icon_data import icon_bytes
from app.regex_builder import template_to_regex, template_matches, token_spans, token_span_at, parse_token, make_token
from app.adobe_pdf import is_adobe_pdf_device, ensure_adobe_pdf_document_fonts
from app.adobe_device_output import normalize_timeout
from app.adobe_paths import normalize_watch_dir

# PyInstaller onedir では __file__ が _internal 側を指すため、
# 設定・プリセットは exe/main.py のある配布ルート側を優先する。
def get_app_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

APP_DIR = get_app_dir()


def load_app_icon():
    """Load the embedded icon; no external icon file is required at runtime."""
    try:
        pix = QPixmap()
        if pix.loadFromData(icon_bytes(), "ICO"):
            return QIcon(pix)
    except Exception:
        pass
    return QIcon()



class RegexTemplateEdit(QLineEdit):
    """特殊指定 {...} を1つの部品として扱う1行エディタ。

    RC15:
    - 特殊指定をクリックしたときは塊で選択する。
    - 選択中の特殊指定へ通常文字を入力した場合は、トークンを上書きせず
      その直後へ文字を続けて入力する。
    - 左右キーまたはトークン外クリックで通常のカーソルへ戻れる。
    - Delete/Backspace/Cut は従来どおりトークン単位で処理する。
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._token_snap_guard = False
        self.cursorPositionChanged.connect(self._snap_cursor_if_inside_token)

    def _select_span(self, span):
        if span:
            self._token_snap_guard = True
            try:
                self.setSelection(span[0], span[1] - span[0])
            finally:
                self._token_snap_guard = False

    def _span_for_click(self, pos):
        return token_span_at(self.text(), pos, include_edges=False)

    def select_token_at(self, pos):
        span = self._span_for_click(pos)
        if span:
            self._select_span(span)
        return span

    def _selection_is_token_block(self):
        start = self.selectionStart()
        selected = self.selectedText()
        if start < 0 or not selected:
            return False
        end = start + len(selected)
        spans = token_spans(self.text())
        # 1個または連続した複数トークンを丸ごと選択している場合を対象にする。
        touched = [sp for sp in spans if sp[0] < end and sp[1] > start]
        if not touched:
            return False
        return min(sp[0] for sp in touched) == start and max(sp[1] for sp in touched) == end

    def _collapse_token_selection_to_end(self):
        """通常文字入力時は選択トークンを置換せず、その後ろへカーソルを置く。"""
        if not self._selection_is_token_block():
            return False
        start = self.selectionStart()
        end = start + len(self.selectedText())
        self._token_snap_guard = True
        try:
            self.setCursorPosition(end)
        finally:
            self._token_snap_guard = False
        return True

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        try:
            point = event.position().toPoint() if hasattr(event, "position") else event.pos()
            pos = self.cursorPositionAt(point)
            QTimer.singleShot(0, lambda p=pos: self.select_token_at(p))
        except Exception:
            pass

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        try:
            if self.selectedText():
                self._expand_current_selection_to_tokens()
                return
            point = event.position().toPoint() if hasattr(event, "position") else event.pos()
            pos = self.cursorPositionAt(point)
            self.select_token_at(pos)
        except Exception:
            pass

    def mouseDoubleClickEvent(self, event):
        super().mouseDoubleClickEvent(event)
        try:
            point = event.position().toPoint() if hasattr(event, "position") else event.pos()
            self.select_token_at(self.cursorPositionAt(point))
        except Exception:
            pass

    def _snap_cursor_if_inside_token(self, old_pos, new_pos):
        if self._token_snap_guard or self.selectedText():
            return
        span = token_span_at(self.text(), new_pos, include_edges=False)
        if span:
            QTimer.singleShot(0, lambda sp=span: self._select_span(sp))

    def _expand_current_selection_to_tokens(self):
        start = self.selectionStart()
        if start < 0 or not self.selectedText():
            return
        end = start + len(self.selectedText())
        changed = True
        while changed:
            changed = False
            for sp in token_spans(self.text()):
                a, b, _ = sp
                if a < end and b > start and (a < start or b > end):
                    start, end = min(start, a), max(end, b)
                    changed = True
        self._select_span((start, end, ""))

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy) or event.matches(QKeySequence.Cut):
            self._expand_current_selection_to_tokens()
            super().keyPressEvent(event)
            return

        if event.key() in (Qt.Key_Delete, Qt.Key_Backspace):
            if self.selectedText():
                self._expand_current_selection_to_tokens()
                super().keyPressEvent(event)
                return
            pos = self.cursorPosition()
            span = token_span_at(self.text(), pos, include_edges=False)
            if not span and event.key() == Qt.Key_Delete:
                span = next((sp for sp in token_spans(self.text()) if sp[0] == pos), None)
            if not span and event.key() == Qt.Key_Backspace:
                span = next((sp for sp in token_spans(self.text()) if sp[1] == pos), None)
                if not span and pos > 0:
                    span = token_span_at(self.text(), pos - 1, include_edges=False)
            if span:
                self._select_span(span)
                super().keyPressEvent(event)
                return

        # 選択中トークンから左右キーで簡単に抜けられるようにする。
        if event.key() in (Qt.Key_Left, Qt.Key_Right) and self._selection_is_token_block():
            start = self.selectionStart(); end = start + len(self.selectedText())
            self._token_snap_guard = True
            try:
                self.setCursorPosition(start if event.key() == Qt.Key_Left else end)
            finally:
                self._token_snap_guard = False
            return

        if event.key() in (Qt.Key_Left, Qt.Key_Right) and not self.selectedText():
            pos = self.cursorPosition()
            if event.key() == Qt.Key_Right:
                span = next((sp for sp in token_spans(self.text()) if sp[0] == pos), None)
                if span:
                    self.setCursorPosition(span[1]); return
            else:
                span = next((sp for sp in token_spans(self.text()) if sp[1] == pos), None)
                if span:
                    self.setCursorPosition(span[0]); return

        # 文字キーは選択トークンを置換せず、その直後へ続けて入力する。
        # Ctrl/Alt/Meta ショートカットは通常処理（貼付け等）を維持する。
        text = event.text()
        mods = event.modifiers()
        shortcut_mods = Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier
        if text and not (mods & shortcut_mods) and self._selection_is_token_block():
            self._collapse_token_selection_to_end()

        super().keyPressEvent(event)

    def inputMethodEvent(self, event):
        # 日本語IME等でも、選択トークンを上書きせず後ろへ入力する。
        try:
            incoming = (event.commitString() or "") + (event.preeditString() or "")
        except Exception:
            incoming = ""
        if incoming and self._selection_is_token_block():
            self._collapse_token_selection_to_end()
        super().inputMethodEvent(event)

    def insert_token(self, token):
        # ボタンによるトークン追加は、選択中トークンがあれば置換として扱う。
        if self.selectedText():
            self._expand_current_selection_to_tokens()
        start = self.selectionStart()
        if start < 0:
            start = self.cursorPosition()
        self.insert(token)
        self._select_span((start, start + len(token), ""))


class RegexBuilderDialog(QDialog):
    """正規表現を知らなくてもファイル名の形からルールを作れるビルダー。"""
    def __init__(self, parent=None, initial_template="", case_sensitive=False, test_files=None):
        super().__init__(parent)
        self.setWindowTitle("正規表現ビルダー")
        self.setModal(True)
        self.resize(880, 680)
        self.case_sensitive = bool(case_sensitive)
        self.test_files = list(test_files or [])
        self.regex_pattern = ""
        self.template_text = ""
        self._syncing_token_controls = False
        self._active_token_span = None

        lay = QVBoxLayout(self)
        title = QLabel("正規表現ビルダー")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        lay.addWidget(title)
        note = QLabel(
            "普通の文字はそのまま入力します。特殊指定だけ { } の部品で追加します。\n"
            "例: P-{数字:4}-{*:2-5}-A    ※ - や . ( ) などの記号も普通の文字として扱います。"
        )
        note.setWordWrap(True); lay.addWidget(note)

        box = QGroupBox("ファイル名の形")
        bv = QVBoxLayout(box)
        self.template_edit = RegexTemplateEdit()
        self.template_edit.setPlaceholderText("例: P-{数字:4}-{*:2-5}-A")
        self.template_edit.setText(initial_template or "")
        bv.addWidget(self.template_edit)

        token_row = QHBoxLayout()
        for label, token in [
            ("任意文字", "{*}"), ("数字", "{数字}"), ("英字", "{英字}"),
            ("大文字", "{大文字}"), ("小文字", "{小文字}"), ("英数字", "{英数字}"),
        ]:
            b = QPushButton(label)
            b.clicked.connect(lambda _=False, t=token: self._insert_token(t))
            token_row.addWidget(b)
        self.choice_btn = QPushButton("選択肢")
        self.choice_btn.clicked.connect(self._insert_choice)
        token_row.addWidget(self.choice_btn); token_row.addStretch(1)
        bv.addLayout(token_row)
        lay.addWidget(box)

        token_edit_box = QGroupBox("選択中の特殊指定")
        te = QHBoxLayout(token_edit_box)
        self.selected_token = QLabel("（特殊指定をクリック）")
        self.selected_token.setMinimumWidth(155)
        self.length_mode = QComboBox(); self.length_mode.addItems(["指定なし", "固定", "範囲"])
        self.len_a = QSpinBox(); self.len_a.setRange(1, 999); self.len_a.setValue(3); self.len_a.setFixedWidth(70)
        self.range_sep = QLabel("-")
        self.len_b = QSpinBox(); self.len_b.setRange(1, 999); self.len_b.setValue(5); self.len_b.setFixedWidth(70)
        self.apply_length_btn = QPushButton("文字数を適用")
        self.edit_choice_btn = QPushButton("選択肢を編集...")
        self.edit_choice_btn.clicked.connect(self._edit_selected_choice)
        te.addWidget(self.selected_token); te.addWidget(QLabel("文字数")); te.addWidget(self.length_mode)
        te.addWidget(self.len_a); te.addWidget(self.range_sep); te.addWidget(self.len_b)
        te.addWidget(self.apply_length_btn); te.addWidget(self.edit_choice_btn); te.addStretch(1)
        lay.addWidget(token_edit_box)

        prev_box = QGroupBox("変換された正規表現")
        ph = QHBoxLayout(prev_box)
        self.regex_preview = QLineEdit(); self.regex_preview.setReadOnly(True)
        copy_btn = QPushButton("コピー")
        copy_btn.clicked.connect(lambda: QApplication.clipboard().setText(self.regex_preview.text()))
        ph.addWidget(self.regex_preview, 1); ph.addWidget(copy_btn)
        lay.addWidget(prev_box)

        test_box = QGroupBox("テスト")
        tv = QVBoxLayout(test_box)
        th = QHBoxLayout()
        self.test_name = QLineEdit(); self.test_name.setPlaceholderText("例: P-0123-MAIN-A.dwg")
        self.test_result = QLabel("―"); self.test_result.setMinimumWidth(100)
        th.addWidget(self.test_name, 1); th.addWidget(self.test_result); tv.addLayout(th)
        self.list_test = QTreeWidget(); self.list_test.setHeaderLabels(["リスト登録ファイル", "判定"])
        self.list_test.setColumnWidth(0, 610); self.list_test.setColumnWidth(1, 100)
        self.list_test.setMaximumHeight(210); tv.addWidget(self.list_test)
        case_text = "区別する" if self.case_sensitive else "区別しない"
        self.case_note = QLabel(f"大文字・小文字: {case_text}（名前ルール側の設定を使用）")
        tv.addWidget(self.case_note)
        lay.addWidget(test_box, 1)

        self.error_label = QLabel("")
        self.error_label.setWordWrap(True)
        lay.addWidget(self.error_label)

        buttons = QHBoxLayout(); buttons.addStretch(1)
        cancel = QPushButton("キャンセル")
        self.use_btn = QPushButton("使用する")
        self.use_btn.setDefault(True)
        cancel.clicked.connect(self.reject); self.use_btn.clicked.connect(self._accept_result)
        buttons.addWidget(cancel); buttons.addWidget(self.use_btn); lay.addLayout(buttons)

        self.template_edit.textChanged.connect(self._refresh)
        self.template_edit.selectionChanged.connect(self._sync_selected_token_controls)
        self.template_edit.cursorPositionChanged.connect(lambda *_: self._sync_selected_token_controls())
        self.test_name.textChanged.connect(self._refresh_single_test)
        self.length_mode.currentTextChanged.connect(self._update_length_control_visibility)
        self.apply_length_btn.clicked.connect(self._apply_length_to_selected)
        self._refresh()
        self._sync_selected_token_controls()

    def _selected_span(self, allow_active=True):
        """現在選択中のトークン、または設定欄へ移動した直前のトークンを返す。

        RC15ではテンプレート欄にフォーカスがある間、カーソルがトークン外へ
        移動したら過去の active token を再選択しない。これにより普通の文字を
        続けて入力できる。
        """
        text = self.template_edit.text()
        start = self.template_edit.selectionStart()
        if start >= 0 and self.template_edit.selectedText():
            end = start + len(self.template_edit.selectedText())
            for span in token_spans(text):
                if span[0] == start and span[1] == end:
                    self._active_token_span = span
                    return span
            touched = [sp for sp in token_spans(text) if sp[0] < end and sp[1] > start]
            if touched:
                a = min([start] + [sp[0] for sp in touched])
                b = max([end] + [sp[1] for sp in touched])
                exact = next((sp for sp in token_spans(text) if sp[0] == a and sp[1] == b), None)
                if exact:
                    self.template_edit._select_span(exact)
                    self._active_token_span = exact
                    return exact

        # テンプレート欄にフォーカスがある場合は、現在位置だけを信頼する。
        # トークン外へ出た時点で active を解除して「張り付き」を防ぐ。
        if self.template_edit.hasFocus():
            pos = self.template_edit.cursorPosition()
            span = token_span_at(text, pos, include_edges=False)
            if span:
                self._active_token_span = span
                return span
            self._active_token_span = None
            return None

        # 文字数設定等へフォーカスを移した場合だけ直前トークンを保持する。
        if allow_active and self._active_token_span:
            a, b, content = self._active_token_span
            if 0 <= a < b <= len(text) and text[a:b] == "{" + content + "}":
                return self._active_token_span
        return None

    def _insert_token(self, token):
        self.template_edit.insert_token(token)
        span = self._selected_span(allow_active=False)
        if span:
            self._active_token_span = span
        self._sync_selected_token_controls()

    def _sync_selected_token_controls(self):
        span = self._selected_span()
        self._syncing_token_controls = True
        try:
            if not span:
                self.selected_token.setText("（特殊指定をクリック）")
                self.length_mode.setEnabled(False); self.len_a.setEnabled(False); self.len_b.setEnabled(False)
                self.range_sep.setEnabled(False); self.apply_length_btn.setEnabled(False); self.edit_choice_btn.setEnabled(False)
                return
            self._active_token_span = span
            # If the cursor merely entered a token, make the block selection visible.
            a0, b0, _ = span
            if self.template_edit.selectionStart() != a0 or len(self.template_edit.selectedText()) != (b0-a0):
                self.template_edit._select_span(span)
            content = span[2]
            kind, mode, a, b = parse_token(content)
            self.selected_token.setText("{" + content + "}")
            if kind == "選択":
                self.length_mode.setEnabled(False); self.len_a.setEnabled(False); self.len_b.setEnabled(False)
                self.range_sep.setEnabled(False); self.apply_length_btn.setEnabled(False); self.edit_choice_btn.setEnabled(True)
                return
            self.length_mode.setEnabled(True); self.apply_length_btn.setEnabled(True); self.edit_choice_btn.setEnabled(False)
            if mode == "fixed":
                self.length_mode.setCurrentText("固定"); self.len_a.setValue(int(a))
            elif mode == "range":
                self.length_mode.setCurrentText("範囲"); self.len_a.setValue(int(a)); self.len_b.setValue(int(b))
            else:
                self.length_mode.setCurrentText("指定なし")
        finally:
            self._syncing_token_controls = False
        self._update_length_control_visibility()

    def _update_length_control_visibility(self):
        if self._syncing_token_controls:
            return
        enabled = self.length_mode.isEnabled()
        mode = self.length_mode.currentText()
        self.len_a.setEnabled(enabled and mode in ("固定", "範囲"))
        self.range_sep.setEnabled(enabled and mode == "範囲")
        self.len_b.setEnabled(enabled and mode == "範囲")

    def _apply_length_to_selected(self):
        span = self._selected_span()
        if not span:
            return
        kind, _, _, _ = parse_token(span[2])
        if kind == "選択":
            return
        mode_text = self.length_mode.currentText()
        mode = {"指定なし": "none", "固定": "fixed", "範囲": "range"}[mode_text]
        try:
            token = make_token(kind, mode, self.len_a.value(), self.len_b.value())
        except ValueError as e:
            QMessageBox.warning(self, "文字数", str(e)); return
        a, b, _ = span
        text = self.template_edit.text()
        self.template_edit.setText(text[:a] + token + text[b:])
        new_span = (a, a + len(token), token[1:-1])
        self._active_token_span = new_span
        self.template_edit._select_span(new_span)
        self._sync_selected_token_controls()

    def _insert_choice(self):
        text, ok = QInputDialog.getText(self, "選択肢", "候補を | で区切って入力してください。\n例: A|B|C")
        if not ok:
            return
        choices = text.strip()
        if not choices or any(x == "" for x in choices.split("|")):
            QMessageBox.warning(self, "選択肢", "A|B|C のように入力してください。")
            return
        self._insert_token("{選択:" + choices + "}")

    def _edit_selected_choice(self):
        span = self._selected_span()
        if not span:
            return
        kind, mode, value, _ = parse_token(span[2])
        if kind != "選択":
            return
        text, ok = QInputDialog.getText(self, "選択肢", "候補を | で区切って入力してください。", QLineEdit.EchoMode.Normal, str(value))
        if not ok:
            return
        choices = text.strip()
        if not choices or any(x == "" for x in choices.split("|")):
            QMessageBox.warning(self, "選択肢", "A|B|C のように入力してください。")
            return
        token = "{選択:" + choices + "}"
        a, b, _ = span; whole = self.template_edit.text()
        self.template_edit.setText(whole[:a] + token + whole[b:])
        new_span = (a, a + len(token), token[1:-1])
        self._active_token_span = new_span
        self.template_edit._select_span(new_span)
        self._sync_selected_token_controls()

    def _refresh(self):
        template = self.template_edit.text()
        try:
            pattern = template_to_regex(template)
            self.regex_pattern = pattern
            self.regex_preview.setText(pattern)
            self.error_label.setText("")
            self.use_btn.setEnabled(True)
        except ValueError as e:
            self.regex_pattern = ""
            self.regex_preview.clear()
            self.error_label.setText("⚠ " + str(e))
            self.use_btn.setEnabled(False)
        self._refresh_single_test()
        self._refresh_list_test()

    def _refresh_single_test(self):
        name = self.test_name.text().strip()
        if not name:
            self.test_result.setText("―"); return
        if not self.regex_pattern:
            self.test_result.setText("⚠ 無効"); return
        try:
            ok = template_matches(name, self.template_edit.text(), self.case_sensitive)
        except ValueError:
            ok = False
        self.test_result.setText("✓ 一致" if ok else "× 不一致")

    def _refresh_list_test(self):
        self.list_test.clear()
        if not self.test_files:
            it = QTreeWidgetItem(["（リストにDWG/DXFがありません）", "―"])
            self.list_test.addTopLevelItem(it); return
        for name in self.test_files:
            if self.regex_pattern:
                try:
                    ok = template_matches(name, self.template_edit.text(), self.case_sensitive)
                    result = "✓ 一致" if ok else "× 不一致"
                except ValueError:
                    result = "⚠ 無効"
            else:
                result = "⚠ 無効"
            self.list_test.addTopLevelItem(QTreeWidgetItem([str(name), result]))

    def _accept_result(self):
        try:
            self.regex_pattern = template_to_regex(self.template_edit.text())
        except ValueError as e:
            QMessageBox.warning(self, "正規表現ビルダー", str(e)); return
        self.template_text = self.template_edit.text()
        self.accept()


class PresetDialog(QDialog):
    def __init__(self, store, parent=None):
        super().__init__(parent); self.store=store
        self.setWindowTitle("プリセット管理")
        # プリセット管理はスクロールを使わず、全項目を一画面で確認する。
        # 会社PCなど表示領域が異なる環境では利用可能なデスクトップ高さに合わせる。
        screen = QApplication.primaryScreen()
        available_h = screen.availableGeometry().height() if screen else 900
        dialog_h = max(720, min(900, available_h - 24))
        self.resize(900, dialog_h)
        self.setMinimumSize(800, min(720, dialog_h))
        outer=QVBoxLayout(self)
        tools=QHBoxLayout()
        b_new=QPushButton("＋ 新規"); b_dup=QPushButton("複製"); b_del=QPushButton("削除")
        b_up=QPushButton("↑"); b_down=QPushButton("↓"); b_up.setToolTip("選択プリセットを上へ"); b_down.setToolTip("選択プリセットを下へ")
        tools.addWidget(b_new); tools.addWidget(b_dup); tools.addWidget(b_del); tools.addWidget(b_up); tools.addWidget(b_down); tools.addStretch()
        outer.addLayout(tools)
        lay=QHBoxLayout(); outer.addLayout(lay,1)
        self.last_rows = dict(self.store.config.get("preset_manager_rows", {}))
        self.kinds=QListWidget()
        for x in ["🖨 印刷設定","🔍 名前ルール","📁 PDF保存先","🏷 PDFファイル名","🔗 PDF結合","📚 プリセット集"]:
            self.kinds.addItem(x)
        self.items=QListWidget(); self.editor=QStackedWidget()
        # RC19: 右側Editorの内容幅に引っ張られて左2ペインが潰れないよう、
        # カテゴリ/プリセット一覧の実用幅を先に確保する。
        self.kinds.setMinimumWidth(118)
        self.items.setMinimumWidth(155)
        self.kinds.setMaximumWidth(145)
        self.items.setMaximumWidth(210)
        # RC12: プリセット一覧はD&Dで並び替え可能。順番はJSONへそのまま保存する。
        self.items.setSelectionMode(QAbstractItemView.SingleSelection)
        self.items.setDragDropMode(QAbstractItemView.InternalMove)
        self.items.setDefaultDropAction(Qt.MoveAction)
        self.items.setDropIndicatorShown(True)
        self._syncing_preset_order=False
        self.items.model().rowsMoved.connect(self._on_preset_rows_moved)
        # 種類ごとに専用ページを固定で持つ。別種類のEditorを使い回さない。
        self.editor_pages={}
        for key, title in zip(["plot","rule","dest","name","merge","collection"],
                              ["印刷設定","名前ルール","PDF保存先","PDFファイル名","PDF結合","プリセット集"]):
            page=QWidget(); v=QVBoxLayout(page); v.setContentsMargins(12,12,12,12)
            head=QLabel(title); head.setStyleSheet("font-size: 16px; font-weight: 700;")
            v.addWidget(head)
            # RC4: 右ペインはスクロールを使わずページへ直接配置する。
            # ウィンドウ自体の縦幅を確保し、全項目を一画面で操作できる構成にする。
            body=QWidget(); body.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            body_lay=QVBoxLayout(body); body_lay.setContentsMargins(0,4,6,4); body_lay.setSpacing(4)
            body_lay.setAlignment(Qt.AlignTop)
            hint=QLabel("左の一覧からプリセットを選択してください。"); hint.setAlignment(Qt.AlignCenter)
            body_lay.addWidget(hint)
            v.addWidget(body,1)
            self.editor.addWidget(page)
            self.editor_pages[key]=(page, body, body_lay)
        split=QSplitter(); split.addWidget(self.kinds); split.addWidget(self.items); split.addWidget(self.editor)
        split.setChildrenCollapsible(False)
        split.setStretchFactor(0,0); split.setStretchFactor(1,0); split.setStretchFactor(2,1)
        split.setSizes([125,170,500]); lay.addWidget(split)
        self.kinds.currentRowChanged.connect(self.reload)
        self.items.currentRowChanged.connect(self.show_editor)
        b_new.clicked.connect(self.create_preset)
        b_dup.clicked.connect(self.duplicate_preset)
        b_del.clicked.connect(self.delete_preset)
        b_up.clicked.connect(lambda:self.move_preset(-1)); b_down.clicked.connect(lambda:self.move_preset(1))
        self.kinds.setCurrentRow(int(self.store.config.get("preset_manager_category",0)))

    def unique_name(self, base):
        names={x["name"] for x in self.store.data[self.key()]}
        if base not in names:return base
        n=2
        while f"{base} {n}" in names:n+=1
        return f"{base} {n}"

    def default_preset(self):
        k=self.key(); uid=f"{k}_{uuid.uuid4().hex[:10]}"
        defaults={
          "plot":{"id":uid,"name":"新しい印刷設定","output":"PDF","setting_method":"プリセットを適用","paper":"A3","orientation":"縦","layout_mode":"現在のLayout","rotate_a3_a1_landscape":False},
          "rule":{"id":uid,"name":"新しい名前ルール","relation":"AND","case_sensitive":False,"conditions":[{"mode":"含む","value":""}]},
          "dest":{"id":uid,"name":"新しいPDF保存先","mode":"CADと同じ","path":""},
          "name":{"id":uid,"name":"新しいPDFファイル名","template":"{CAD名}"},
          "merge":{"id":uid,"name":"新しいPDF結合設定","enabled":True,"keep_individual":False},
          "collection":{"id":uid,"name":"新しいプリセット集","pairs":[],"default_plot_id":None,"dest_id":None,"name_id":None,"merge_id":None}}
        return defaults[k]

    def create_preset(self):
        obj=self.default_preset(); obj["name"]=self.unique_name(obj["name"])
        self.store.data[self.key()].append(obj); self.store.save()
        self.reload(); self.items.setCurrentRow(self.items.count()-1)

    def duplicate_preset(self):
        row=self.items.currentRow()
        if row<0:return
        if self.store.data[self.key()][row].get("_shared"):
            QMessageBox.information(self,"共有プリセット","共有プリセットは読み取り専用です。")
            return
        obj=copy.deepcopy(self.store.data[self.key()][row])
        obj["id"]=f"{self.key()}_{uuid.uuid4().hex[:10]}"
        obj["name"]=self.unique_name(obj["name"]+" のコピー")
        self.store.data[self.key()].append(obj); self.store.save()
        self.reload(); self.items.setCurrentRow(self.items.count()-1)

    def move_preset(self, delta):
        row=self.items.currentRow()
        if row<0:return
        item=self.items.item(row); pid=item.data(Qt.UserRole); key=self.key()
        selected_obj=next((x for x in self.store.data.get(key,[]) if x.get("id")==pid),None)
        if selected_obj and selected_obj.get("_shared"):
            QMessageBox.information(self,"共有プリセット","共有プリセットは並び替えできません。")
            return
        local=[x for x in self.store.data.get(key,[]) if not x.get("_shared")]
        shared=[x for x in self.store.data.get(key,[]) if x.get("_shared")]
        idx=next((i for i,x in enumerate(local) if x.get("id")==pid),-1)
        ni=idx+int(delta)
        if idx<0 or ni<0 or ni>=len(local):return
        local[idx],local[ni]=local[ni],local[idx]
        self.store.data[key]=local+shared; self.store.save(); self.reload()
        for i in range(self.items.count()):
            if self.items.item(i).data(Qt.UserRole)==pid:
                self.items.setCurrentRow(i); break

    def references_to(self,pid):
        refs=[]
        for c in self.store.data["collection"]:
            k=self.key()
            if k=="rule" and any(x.get("rule_id")==pid for x in c.get("pairs",[])):refs.append(c["name"])
            elif k=="plot" and any(x.get("plot_id")==pid for x in c.get("pairs",[])):refs.append(c["name"])
            elif k=="dest" and c.get("dest_id")==pid:refs.append(c["name"])
            elif k=="name" and c.get("name_id")==pid:refs.append(c["name"])
            elif k=="merge" and c.get("merge_id")==pid:refs.append(c["name"])
        return refs

    def delete_preset(self):
        row=self.items.currentRow()
        if row<0:return
        obj=self.store.data[self.key()][row]
        if obj.get("_shared"):
            QMessageBox.information(self,"共有プリセット","共有プリセットは読み取り専用です。")
            return
        refs=[] if self.key()=="collection" else self.references_to(obj["id"])
        if refs:
            QMessageBox.warning(self,"削除できません","このプリセットは次のプリセット集で使用されています。\n\n"+"\n".join("・"+x for x in refs))
            return
        if QMessageBox.question(self,"削除確認",f"「{obj['name']}」を削除しますか？",QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        del self.store.data[self.key()][row]; self.store.save(); self.reload()

    def filter_items(self,text):
        q=text.casefold().strip()
        for i in range(self.items.count()):
            it=self.items.item(i); it.setHidden(bool(q) and q not in it.text().casefold())

    def key(self):
        return ["plot","rule","dest","name","merge","collection"][self.kinds.currentRow()]

    def registered_cad_paths(self):
        """Return every DWG/DXF currently registered in the main list.

        The preset editor deliberately uses the whole registered list rather than
        MainWindow's current selection, so users can fetch plot settings without
        leaving the preset manager.
        """
        owner=self.parentWidget()
        if owner is None or not hasattr(owner,"all_file_items"):
            return []
        paths=[]
        for item in owner.all_file_items():
            try:
                path=str(owner.item_path(item) or "")
            except Exception:
                data=item.data(0,Qt.UserRole) or {}
                path=str(data.get("path") or "")
            if path.lower().endswith((".dwg",".dxf")):
                paths.append(path)
        return list(dict.fromkeys(paths))

    def reload(self):
        self.store.config["preset_manager_category"]=self.kinds.currentRow()
        # カテゴリを移動する前に、直前カテゴリの選択位置を保存
        old_key = getattr(self, "_active_key", None)
        if old_key is not None and self.items.currentRow() >= 0:
            self.last_rows[old_key] = self.items.currentRow()

        key = self.key()
        self._active_key = key
        # 種類を切り替えた瞬間に専用ページへ切替。前カテゴリの右ペインを残さない。
        self.editor.setCurrentWidget(self.editor_pages[key][0])
        self._clear_editor_body(key)
        self.items.blockSignals(True)
        self.items.clear()
        for p in self.store.data[key]:
            item=QListWidgetItem(p["name"] + ("  [共有]" if p.get("_shared") else ""))
            item.setData(Qt.UserRole,p.get("id"))
            if p.get("_shared"):
                item.setFlags(item.flags() & ~Qt.ItemIsDragEnabled)
            self.items.addItem(item)
        self.items.blockSignals(False)

        if self.items.count():
            # 初回は先頭、2回目以降はそのカテゴリで最後に選んだ位置
            row = self.last_rows.get(key, 0)
            row = max(0, min(row, self.items.count()-1))
            self.items.setCurrentRow(row)
            self.show_editor(row)

    def _on_preset_rows_moved(self, *_args):
        """Persist the visible preset-list order. Shared presets stay read-only and last."""
        if self._syncing_preset_order or self.kinds.currentRow()<0:
            return
        key=self.key()
        current=list(self.store.data.get(key,[]))
        by_id={x.get("id"):x for x in current if not x.get("_shared")}
        shared=[x for x in current if x.get("_shared")]
        shared_ids={x.get("id") for x in current if x.get("_shared")}
        ordered_ids=[self.items.item(i).data(Qt.UserRole) for i in range(self.items.count())
                     if self.items.item(i).data(Qt.UserRole) not in shared_ids]
        ordered=[by_id[x] for x in ordered_ids if x in by_id]
        # Keep any malformed/legacy entries rather than dropping them.
        ordered.extend(x for x in current if not x.get("_shared") and x not in ordered)
        if [x.get("id") for x in ordered] == [x.get("id") for x in current if not x.get("_shared")]:
            return
        selected_id=self.items.currentItem().data(Qt.UserRole) if self.items.currentItem() else None
        self.store.data[key]=ordered+shared
        self.store.save()
        self._syncing_preset_order=True
        try:
            self.reload()
            if selected_id:
                for i in range(self.items.count()):
                    if self.items.item(i).data(Qt.UserRole)==selected_id:
                        self.items.setCurrentRow(i); break
        finally:
            self._syncing_preset_order=False

    def _dispose_layout_widgets(self, lay):
        """Remove old editor widgets immediately from the visible hierarchy.

        deleteLater() alone leaves the widget alive and visible until Qt returns to
        the event loop. show_editor() can be called several times in one event
        cycle (reload/currentRowChanged), which used to leave old controls painted
        underneath the new controls.
        """
        while lay.count():
            item = lay.takeAt(0)
            child_lay = item.layout()
            if child_lay is not None:
                self._dispose_layout_widgets(child_lay)
            w = item.widget()
            if w is not None:
                w.hide()
                w.setParent(None)
                w.deleteLater()

    def _clear_editor_body(self, key):
        _page, _body, lay = self.editor_pages[key]
        self._dispose_layout_widgets(lay)
        hint=QLabel("左の一覧からプリセットを選択してください。")
        hint.setAlignment(Qt.AlignCenter)
        lay.addWidget(hint,1)

    def show_editor(self, row):
        key=self.key()
        if row < 0 or row >= len(self.store.data.get(key, [])):
            self._clear_editor_body(key)
            return
        self.last_rows[key] = row
        self.store.config["preset_manager_rows"]=self.last_rows
        p=self.store.data[key][row]
        if p.get("_shared"):
            self._clear_editor_body(key)
            _page,_body,body_lay=self.editor_pages[key]
            note=QLabel("共有プリセット（読み取り専用）\n\nこのプリセットは共有元で管理されています。")
            note.setWordWrap(True); note.setAlignment(Qt.AlignCenter); body_lay.addWidget(note,1)
            return
        w=QWidget(); w.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        f=QFormLayout(w)
        f.setContentsMargins(0,0,8,0); f.setHorizontalSpacing(14); f.setVerticalSpacing(8)
        # RC19: 入力欄やグループ枠を右端まで無意味に引き伸ばさない。
        f.setFieldGrowthPolicy(QFormLayout.FieldsStayAtSizeHint)
        f.setRowWrapPolicy(QFormLayout.DontWrapRows)
        f.setLabelAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        # RC19: 125%/150%表示でも横に間延びしない論理幅へ再調整。
        # 同種は揃えるが、左ペインを圧迫する固定幅は持たせない。
        W_LONG = 210      # PC3/プリンター名、パス、プリセット名など
        W_MEDIUM = 150    # 用紙、CTB/STB、Layout指定など
        W_SHORT = 115     # 出力種別、印刷範囲、単純な選択肢
        W_SMALL = 72      # 数値や短い選択肢
        W_ACTION = 130    # 操作ボタン

        name=QLineEdit(p["name"]); name.setFixedWidth(W_LONG); f.addRow("名前",name)
        if key=="plot":
            out=QComboBox(); out.addItems(["PDF","プリンター","PDF＋プリンター"]); out.setCurrentText(p.get("output","PDF")); out.setFixedWidth(W_SHORT)
            setting_method=QComboBox(); setting_method.addItems(["プリセットを適用","DWG/DXFに保存されている設定を使用"]); setting_method.setCurrentText(p.get("setting_method","プリセットを適用")); setting_method.setFixedWidth(W_LONG)
            device=QComboBox(); device.setEditable(True); device.setFixedWidth(W_LONG)
            if p.get("device"): device.addItem(p.get("device"))
            paper=QComboBox(); paper.setEditable(True); paper.setFixedWidth(W_MEDIUM)
            for x in ["A4","A3","A2","A1"]: paper.addItem(x)
            paper.setCurrentText(p.get("paper","A3"))
            style=QComboBox(); style.setEditable(True); style.setFixedWidth(W_MEDIUM)
            if p.get("plot_style"): style.addItem(p.get("plot_style"))
            pnorm=normalize_plot_settings(p)
            orient=QComboBox(); orient.addItems(["縦","横"]); orient.setCurrentText(pnorm.get("orientation","縦")); orient.setFixedWidth(W_SMALL)
            # RC36: the UI intentionally exposes only portrait/landscape, but
            # AutoCAD also has 180°/270°. Preserve the exact imported rotation
            # unless the user actually changes the direction combo.
            _exact_rotation_state={
                "rotation": pnorm.get("rotation","0°"),
                "orientation": pnorm.get("orientation","縦"),
            }
            copies=QSpinBox(); copies.setRange(1,99); copies.setValue(int(p.get("copies",1))); copies.setFixedWidth(W_SMALL)
            # Step49: PDF＋プリンターではPDF用PC3と物理プリンターを分離する。
            printer_device=QComboBox(); printer_device.setEditable(True); printer_device.setFixedWidth(W_LONG)
            printer_paper=QComboBox(); printer_paper.setEditable(True); printer_paper.setFixedWidth(W_MEDIUM)
            if p.get("printer_device"): printer_device.addItem(p.get("printer_device"))
            if p.get("printer_paper"): printer_paper.addItem(p.get("printer_paper"))
            plot_area=QComboBox(); plot_area.addItems(["レイアウト","窓","図形範囲","表示範囲","図面範囲"]); plot_area.setCurrentText(p.get("plot_area","レイアウト")); plot_area.setFixedWidth(W_SHORT)
            # RC16: 窓座標はスピンボタン不要。コンパクトな数値テキスト欄にする。
            def _coord_edit(value):
                w=QLineEdit()
                validator=QDoubleValidator(-1000000000000.0,1000000000000.0,6,w)
                validator.setNotation(QDoubleValidator.StandardNotation)
                w.setValidator(validator)
                w.setFixedWidth(56)
                try:
                    v=float(value if value is not None else 0.0)
                    text=(f"{v:.6f}").rstrip("0").rstrip(".")
                    w.setText(text if text not in ("-0","") else "0")
                except Exception:
                    w.setText("0")
                return w
            def _coord_value(edit):
                text=edit.text().strip().replace(",", ".")
                try: return float(text)
                except Exception: return 0.0
            window_x1=_coord_edit(p.get("window_x1")); window_y1=_coord_edit(p.get("window_y1"))
            window_x2=_coord_edit(p.get("window_x2")); window_y2=_coord_edit(p.get("window_y2"))
            window_box=QWidget(); window_box.setFixedWidth(330); wh=QHBoxLayout(window_box); wh.setContentsMargins(0,0,0,0); wh.setSpacing(4)
            wh.addWidget(QLabel("左下")); wh.addWidget(QLabel("X")); wh.addWidget(window_x1); wh.addWidget(QLabel("Y")); wh.addWidget(window_y1)
            wh.addSpacing(8); wh.addWidget(QLabel("右上")); wh.addWidget(QLabel("X")); wh.addWidget(window_x2); wh.addWidget(QLabel("Y")); wh.addWidget(window_y2); wh.addStretch(1)
            fit=QCheckBox("用紙にフィット"); fit.setChecked(p.get("fit_to_paper",True))
            center=QCheckBox("中央配置"); center.setChecked(p.get("center_plot",True))
            # RC32: CustomScale取得不能を1:1へ捏造しない。0はUI上だけの
            # sentinelで、"未取得" と表示し保存時はNoneへ戻す。
            def _scale_spin(value):
                w=QDoubleSpinBox(); w.setRange(0.0,1000000); w.setDecimals(4); w.setSpecialValueText("未取得"); w.setFixedWidth(W_SMALL)
                try:
                    w.setValue(float(value) if value not in (None,"") else 0.0)
                except Exception:
                    w.setValue(0.0)
                return w
            # RC33: absent values are unknown, not 1:1.
            scale_num=_scale_spin(p.get("scale_num")); scale_den=_scale_spin(p.get("scale_den"))
            # RC34: an imported AutoCAD standard scale (UseStandardScale=ON,
            # StandardScale!=acScaleToFit) cannot be represented by the old
            # "用紙にフィット" checkbox alone. Keep its exact enum internally
            # until the user edits the scale controls.
            _exact_scale_state={
                "mode": p.get("scale_mode"),
                "standard_scale_index": p.get("standard_scale_index"),
                "paper_units": p.get("paper_units"),
                "num": p.get("scale_num"),
                "den": p.get("scale_den"),
            }
            scale_box=QWidget(); scale_box.setFixedWidth(160); sh=QHBoxLayout(scale_box); sh.setContentsMargins(0,0,0,0); sh.setSpacing(5); sh.addWidget(scale_num); sh.addWidget(QLabel(":")); sh.addWidget(scale_den); sh.addStretch(1)
            scale_box.setToolTip("未取得の場合は適用先Layoutの現在のCustomScaleを維持します。値を入力すればその尺度を適用します。")
            offx=QDoubleSpinBox(); offx.setRange(-100000,100000); offx.setDecimals(2); offx.setValue(float(p.get("offset_x",0))); offx.setFixedWidth(W_SMALL)
            offy=QDoubleSpinBox(); offy.setRange(-100000,100000); offy.setDecimals(2); offy.setValue(float(p.get("offset_y",0))); offy.setFixedWidth(W_SMALL)
            offbox=QWidget(); offbox.setFixedWidth(178); oh=QHBoxLayout(offbox); oh.setContentsMargins(0,0,0,0); oh.setSpacing(5); oh.addWidget(QLabel("X")); oh.addWidget(offx); oh.addWidget(QLabel("Y")); oh.addWidget(offy); oh.addStretch(1)
            lineweights=QCheckBox("線の太さを印刷"); lineweights.setChecked(p.get("lineweights",True))
            transparency=QCheckBox("透過性を印刷"); transparency.setChecked(p.get("transparency",False))
            plotstyles=QCheckBox("印刷スタイルを使用"); plotstyles.setChecked(p.get("plot_styles",True))
            rotate_a_sizes=QCheckBox("PDF出力後、A3/A1を左90°回転して横向きにする")
            rotate_a_sizes.setChecked(bool(p.get("rotate_a3_a1_landscape",False)))
            rotate_a_sizes.setToolTip("生成されたPDFの実ページサイズを確認し、A3/A1で縦向きのページだけを左90°回転します。")
            layout_mode=QComboBox(); layout_mode.setFixedWidth(W_MEDIUM)
            for label,data in [("現在のLayout","現在のLayout"),("Modelのみ","Modelのみ"),("全Layout","全Layout"),("指定Layout（複数可）","指定Layout")]:
                layout_mode.addItem(label,data)
            old_layout_mode=p.get("layout_mode","現在のLayout")
            ix=layout_mode.findData(old_layout_mode); layout_mode.setCurrentIndex(ix if ix>=0 else 0)
            layout_names_state=list(p.get("layout_names",[]) or [])
            layout_names=QLineEdit(", ".join(layout_names_state)); layout_names.setReadOnly(True); layout_names.setFixedWidth(W_LONG)
            layout_names.setPlaceholderText("対象Layoutを選択してください")
            layout_pick=QPushButton("選択..."); layout_pick.setFixedWidth(70)
            layoutrow=QWidget(); layoutrow.setFixedWidth(286); lrh=QHBoxLayout(layoutrow); lrh.setContentsMargins(0,0,0,0); lrh.setSpacing(6); lrh.addWidget(layout_names); lrh.addWidget(layout_pick)

            def choose_layout_names():
                dlg=QDialog(self); dlg.setWindowTitle("対象Layoutを複数選択"); dlg.resize(560,500)
                vv=QVBoxLayout(dlg)
                source_row=QHBoxLayout(); source=QComboBox(); source.addItem("（候補を取得するDWG/DXFを選択）",None)
                for path in self.registered_cad_paths():
                    pp=Path(path); source.addItem(f"{pp.name} — {pp.parent.name}",path)
                browse_layout=QPushButton("ファイル..."); source_row.addWidget(source,1); source_row.addWidget(browse_layout); vv.addLayout(source_row)
                hint=QLabel("チェックしたLayoutをすべて出力します。Modelも選択できます。候補にない名前は下から追加できます。")
                hint.setWordWrap(True); vv.addWidget(hint)
                lst=QListWidget(); vv.addWidget(lst,1)
                manual_row=QHBoxLayout(); manual=QLineEdit(); manual.setPlaceholderText("Layout名を追加"); add_manual=QPushButton("追加")
                manual_row.addWidget(manual,1); manual_row.addWidget(add_manual); vv.addLayout(manual_row)
                buttons2=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); vv.addWidget(buttons2)
                selected=set(layout_names_state)
                def fill(names):
                    merged=[]
                    for x in list(names)+list(layout_names_state):
                        if x and x not in merged: merged.append(x)
                    lst.clear()
                    for name_ in merged:
                        it=QListWidgetItem(name_); it.setFlags(it.flags()|Qt.ItemIsUserCheckable); it.setCheckState(Qt.Checked if name_ in selected else Qt.Unchecked); lst.addItem(it)
                fill(layout_names_state)
                def load_path(path):
                    if not path:return
                    QApplication.setOverrideCursor(Qt.WaitCursor)
                    try:
                        rows=list_layouts(path,connection_options={"selected_year":str(self.store.config.get("autocad_version","自動")),"dedicated_hidden":True})
                        selected.update(lst.item(i).text() for i in range(lst.count()) if lst.item(i).checkState()==Qt.Checked)
                        fill([x.get("name","") for x in rows])
                    except Exception as e:
                        QMessageBox.warning(dlg,"Layout取得",str(e))
                    finally:
                        QApplication.restoreOverrideCursor()
                source.currentIndexChanged.connect(lambda i: load_path(source.itemData(i)))
                def browse_for_layouts():
                    fn,_=QFileDialog.getOpenFileName(dlg,"Layout候補を取得するDWG/DXF","","CAD (*.dwg *.dxf)")
                    if fn: load_path(fn)
                browse_layout.clicked.connect(browse_for_layouts)
                def add_name():
                    name_=manual.text().strip()
                    if not name_:return
                    selected.update(lst.item(i).text() for i in range(lst.count()) if lst.item(i).checkState()==Qt.Checked)
                    selected.add(name_); fill([lst.item(i).text() for i in range(lst.count())]+[name_]); manual.clear()
                add_manual.clicked.connect(add_name); manual.returnPressed.connect(add_name)
                buttons2.accepted.connect(dlg.accept); buttons2.rejected.connect(dlg.reject)
                if dlg.exec()!=QDialog.Accepted:return
                layout_names_state[:] = [lst.item(i).text() for i in range(lst.count()) if lst.item(i).checkState()==Qt.Checked]
                layout_names.setText(", ".join(layout_names_state))
                if layout_names_state:
                    ix=layout_mode.findData("指定Layout"); layout_mode.setCurrentIndex(ix)
            layout_pick.clicked.connect(choose_layout_names)
            def update_layout_picker():
                on=layout_mode.currentData()=="指定Layout"
                layout_names.setEnabled(on); layout_pick.setEnabled(on)
            layout_mode.currentIndexChanged.connect(lambda _=None:update_layout_picker()); update_layout_picker()
            refresh_env=QPushButton("AutoCAD環境を更新"); refresh_env.setFixedWidth(W_ACTION)
            import_dwg=QPushButton("📥 DWG/DXFから取得"); import_dwg.setFixedWidth(W_ACTION)
            env_status=QLabel("未取得")
            def apply_cached_environment(env=None):
                env=normalize_environment(env or self.store.load_environment()) if (env or self.store.load_environment()) else {}
                curdev=device.currentText(); curstyle=style.currentText()
                device.blockSignals(True); device.clear(); device.addItems(env.get("devices",[])); device.setCurrentText(curdev); device.blockSignals(False)
                style.clear(); style.addItems(env.get("styles",[])); style.setCurrentText(curstyle)
                def _combo_value(combo):
                    data=combo.currentData()
                    return str(data) if data not in (None, "") else combo.currentText()
                def _fill_media_combo(combo, dev, current_value):
                    combo.blockSignals(True)
                    combo.clear()
                    choices=media_choices_for_device(env,dev)
                    for canonical,label in choices:
                        combo.addItem(label,canonical)
                    idx=combo.findData(current_value) if current_value else -1
                    if idx>=0:
                        combo.setCurrentIndex(idx)
                    elif current_value:
                        # Unknown/legacy value remains editable and is validated at output.
                        combo.setEditText(str(current_value))
                    combo.blockSignals(False)
                def update_media():
                    cur=_combo_value(paper); _fill_media_combo(paper,device.currentText(),cur)
                def update_printer_media():
                    cur=_combo_value(printer_paper); _fill_media_combo(printer_paper,printer_device.currentText(),cur)
                # 物理プリンター候補も同じ環境キャッシュから選べる。PC3も候補に残し、環境依存の名称を推測しない。
                curprinter=printer_device.currentText(); printer_device.blockSignals(True)
                printer_device.clear(); printer_device.addItems(env.get("devices",[])); printer_device.setCurrentText(curprinter)
                printer_device.blockSignals(False)
                previous=getattr(device,"_media_update_slot",None)
                if previous is not None: device.currentTextChanged.disconnect(previous)
                previous=getattr(printer_device,"_media_update_slot",None)
                if previous is not None: printer_device.currentTextChanged.disconnect(previous)
                device._media_update_slot=update_media
                printer_device._media_update_slot=update_printer_media
                device.currentTextChanged.connect(update_media); printer_device.currentTextChanged.connect(update_printer_media)
                update_media(); update_printer_media()
                if env:
                    env_status.setText(f"キャッシュ: PC3/プリンター {len(env.get('devices',[]))}件 / CTB・STB {len(env.get('styles',[]))}件")
                else: env_status.setText("未取得")
            apply_cached_environment()
            def import_from_dwg():
                # RC9: 取得元は毎回クリアして開く。前回選択したDWGを
                # 新しい印刷設定へ暗黙に引き継がない。
                dlg=QDialog(self); dlg.setWindowTitle("DWG/DXFから印刷設定を取得"); dlg.resize(610,540)
                dv=QVBoxLayout(dlg); ff=QFormLayout(); ff.setVerticalSpacing(8); dv.addLayout(ff)

                # 1) メインリストに登録済みのDWG/DXFから選択
                list_source=QComboBox(); list_source.setFixedWidth(280)
                list_source.addItem("（リストから選択してください）", None)
                for path in self.registered_cad_paths():
                    pp=Path(path)
                    parent_name=pp.parent.name or str(pp.parent)
                    list_source.addItem(f"{pp.name}  —  {parent_name}", path)
                if list_source.count()==1:
                    list_source.setEnabled(False)
                    list_source.setToolTip("メインリストにDWG/DXFが登録されていません。")
                ff.addRow("リストから選択",list_source)

                # 2) 任意のフォルダから通常のファイル選択ダイアログで指定
                filerow=QWidget(); frh=QHBoxLayout(filerow); frh.setContentsMargins(0,0,0,0)
                file_source=QLineEdit(); file_source.setReadOnly(True); file_source.setPlaceholderText("未選択"); file_source.setFixedWidth(225)
                browse=QPushButton("参照..."); browse.setFixedWidth(68); frh.setSpacing(6); frh.addWidget(file_source); frh.addWidget(browse); frh.addStretch(1)
                ff.addRow("ファイルから選択",filerow)

                current_source=QLabel("未選択"); current_source.setWordWrap(True); current_source.setTextInteractionFlags(Qt.TextSelectableByMouse)
                ff.addRow("現在の取得元",current_source)

                layouts=QComboBox(); layouts.setEnabled(False); layouts.setFixedWidth(180)
                preview=QLabel("取得元DWG/DXFを選択してください。"); preview.setWordWrap(True)
                preview.setTextInteractionFlags(Qt.TextSelectableByMouse)
                ff.addRow("設定取得元",layouts)
                box=QGroupBox("現在の印刷設定"); bv=QVBoxLayout(box); bv.addWidget(preview); dv.addWidget(box,1)
                buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); buttons.button(QDialogButtonBox.Ok).setText("この設定を取得"); buttons.button(QDialogButtonBox.Ok).setEnabled(False); dv.addWidget(buttons)
                state={"info":None,"path":""}

                def reset_loaded_source():
                    state["info"]=None; state["path"]=""
                    current_source.setText("未選択")
                    layouts.blockSignals(True); layouts.clear(); layouts.blockSignals(False); layouts.setEnabled(False)
                    preview.setText("取得元DWG/DXFを選択してください。")
                    buttons.button(QDialogButtonBox.Ok).setEnabled(False)

                def show_layout():
                    info=state.get("info") or {}; rows=info.get("layouts",[]); lname=layouts.currentText(); row=next((x for x in rows if x.get("name")==lname),None)
                    if not row:
                        preview.setText("Layoutを選択してください。")
                        buttons.button(QDialogButtonBox.Ok).setEnabled(False)
                        return
                    st=row.get("settings",{})
                    if st.get('fit_to_paper',True):
                        scale_text="用紙にフィット"
                    elif st.get('scale_num') in (None,"") and st.get('scale_den') in (None,""):
                        scale_text="取得不能（適用時は現行値を維持）"
                    else:
                        scale_text=f"{st.get('scale_num')} : {st.get('scale_den')}"
                    preview.setText(
                        f"プリンター / PC3：{st.get('device','')}\n用紙：{st.get('paper_display') or st.get('paper','')}\n印刷範囲：{st.get('plot_area','')}\n"
                        f"尺度：{scale_text}\n"
                        f"中央配置：{'ON' if st.get('center_plot',True) else 'OFF'}\n用紙方向：{normalize_plot_settings(st).get('orientation','縦')}\n"
                        f"CTB / STB：{st.get('plot_style','')}\n線の太さ：{'ON' if st.get('lineweights',True) else 'OFF'}\n"
                        f"透過性：{'ON' if st.get('transparency',False) else 'OFF'}" +
                        ((f"\n窓範囲：({st.get('window_x1')}, {st.get('window_y1')}) - ({st.get('window_x2')}, {st.get('window_y2')})") if st.get('plot_area')=='窓' and st.get('window_x1') is not None else ""))
                    buttons.button(QDialogButtonBox.Ok).setEnabled(True)

                def load_source(path):
                    path=str(path or "").strip()
                    if not path:
                        reset_loaded_source(); return
                    try:
                        info=inspect_drawing_plot_settings(path,connection_options={"selected_year":str(self.store.config.get("autocad_version","自動")),"dedicated_hidden":True})
                    except Exception as e:
                        reset_loaded_source(); QMessageBox.critical(dlg,"DWG/DXFから取得",str(e)); return
                    state["info"]=info; state["path"]=path
                    current_source.setText(path)
                    layouts.blockSignals(True); layouts.clear()
                    names=[x.get("name","") for x in info.get("layouts",[])]
                    layouts.addItems(names); active=info.get("active_layout","")
                    if active in names: layouts.setCurrentText(active)
                    layouts.blockSignals(False); layouts.setEnabled(bool(names)); show_layout()

                def select_from_list(index):
                    path=list_source.itemData(index)
                    if not path:return
                    # 明示的にリストを選んだのでファイル参照側はクリアする。
                    file_source.clear(); load_source(path)

                def choose_file():
                    start_dir=str(Path(state.get("path") or file_source.text()).parent) if (state.get("path") or file_source.text()) else ""
                    fn,_=QFileDialog.getOpenFileName(dlg,"印刷設定を取得するDWG/DXF",start_dir,"CAD (*.dwg *.dxf)")
                    if not fn:return
                    # 明示的にファイルを選んだのでリスト選択側を初期位置へ戻す。
                    list_source.blockSignals(True); list_source.setCurrentIndex(0); list_source.blockSignals(False)
                    file_source.setText(fn); load_source(fn)

                list_source.currentIndexChanged.connect(select_from_list)
                browse.clicked.connect(choose_file); layouts.currentTextChanged.connect(show_layout)
                buttons.accepted.connect(dlg.accept); buttons.rejected.connect(dlg.reject)

                # 毎回ここから開始。plot_import_recent等の過去選択は意図的に使わない。
                reset_loaded_source()
                if dlg.exec()!=QDialog.Accepted:return
                info=state.get("info") or {}; lname=layouts.currentText(); row=next((x for x in info.get("layouts",[]) if x.get("name")==lname),None)
                if not row:return
                st=row.get("settings",{})
                device.setCurrentText(st.get("device",""))
                _paper_value=str(st.get("paper","") or "")
                _paper_idx=paper.findData(_paper_value)
                if _paper_idx>=0: paper.setCurrentIndex(_paper_idx)
                else: paper.setEditText(_paper_value)
                style.setCurrentText(st.get("plot_style",""))
                plot_area.setCurrentText(st.get("plot_area","レイアウト")); fit.setChecked(st.get("fit_to_paper",True)); center.setChecked(st.get("center_plot",True))
                _sn=st.get("scale_num"); _sd=st.get("scale_den")
                scale_num.setValue(float(_sn) if _sn not in (None,"") else 0.0)
                scale_den.setValue(float(_sd) if _sd not in (None,"") else 0.0)
                _exact_scale_state.update(
                    mode=st.get("scale_mode"),
                    standard_scale_index=st.get("standard_scale_index"),
                    paper_units=st.get("paper_units"),
                    num=_sn, den=_sd,
                )
                offx.setValue(float(st.get("offset_x",0))); offy.setValue(float(st.get("offset_y",0)))
                lineweights.setChecked(st.get("lineweights",True)); transparency.setChecked(st.get("transparency",False)); plotstyles.setChecked(st.get("plot_styles",True))
                _import_norm=normalize_plot_settings(st)
                orient.setCurrentText(_import_norm.get("orientation","縦"))
                _exact_rotation_state.update(
                    rotation=_import_norm.get("rotation","0°"),
                    orientation=_import_norm.get("orientation","縦"),
                )
                # 取得元プルダウンの選択が、そのまま出力対象になる。二重選択はしない。
                row_is_model=bool(row.get("model"))
                if row_is_model:
                    ix=layout_mode.findData("Modelのみ"); layout_mode.setCurrentIndex(ix if ix>=0 else 0)
                    layout_names_state[:] = []; layout_names.clear()
                else:
                    ix=layout_mode.findData("指定Layout"); layout_mode.setCurrentIndex(ix if ix>=0 else 0)
                    layout_names_state[:] = [lname]; layout_names.setText(lname)
                for widget_, key_ in ((window_x1,"window_x1"),(window_y1,"window_y1"),(window_x2,"window_x2"),(window_y2,"window_y2")):
                    try:
                        if st.get(key_) is not None:
                            v=float(st.get(key_)); widget_.setText((f"{v:.6f}").rstrip("0").rstrip(".") or "0")
                    except Exception:
                        pass
            import_dwg.clicked.connect(import_from_dwg)
            def load_plot_env():
                try:
                    from datetime import datetime
                    env=probe_plot_environment(True, connection_options={
                        "selected_year":str(self.store.config.get("autocad_version","自動")),
                        "shared_plot_resources_enabled":bool(self.store.config.get("shared_plot_resources_enabled",False)),
                        "shared_pc3_path":self.store.config.get("shared_pc3_path",""),
                        "shared_plot_style_path":self.store.config.get("shared_plot_style_path","")})
                    env["captured_at"]=datetime.now().strftime("%Y/%m/%d %H:%M:%S")
                    self.store.save_environment(env); apply_cached_environment(env)
                    problems=[]
                    for pp in self.store.data.get("plot",[]):
                        msgs=validate_plot_preset(pp,env)
                        if msgs: problems.append(pp.get("name","(名称なし)")+": "+" / ".join(msgs))
                    text="AutoCAD印刷環境を更新しました。"
                    if problems: text+=f"\n\n既存印刷設定の要確認: {len(problems)}件\n"+"\n".join(problems[:8])
                    QMessageBox.information(self,"AutoCAD環境",text)
                except Exception as e:
                    QMessageBox.warning(self,"AutoCAD環境",str(e))
            refresh_env.clicked.connect(load_plot_env)
            f.addRow("設定方法",setting_method); f.addRow("出力",out); f.addRow("PDF用 PC3 / プリンター",device); f.addRow("PDF用 用紙",paper)
            f.addRow("物理プリンター",printer_device); f.addRow("物理プリンター用紙",printer_paper)
            f.addRow("CTB / STB",style); f.addRow("用紙方向",orient)
            f.addRow("印刷部数",copies); f.addRow("印刷範囲",plot_area); f.addRow("窓範囲",window_box); f.addRow(fit); f.addRow(center)
            f.addRow(rotate_a_sizes)
            window_label=f.labelForField(window_box)
            def update_window_fields():
                on=plot_area.currentText()=="窓"
                window_box.setVisible(on)
                if window_label is not None: window_label.setVisible(on)
            plot_area.currentTextChanged.connect(lambda _=None:update_window_fields()); update_window_fields()
            def update_output_fields():
                m=out.currentText(); has_pdf=m in ("PDF","PDF＋プリンター","PDF+プリンター"); has_print=m in ("プリンター","PDF＋プリンター","PDF+プリンター")
                device.setEnabled(has_pdf or m=="プリンター"); paper.setEnabled(has_pdf or m=="プリンター")
                printer_device.setEnabled(has_print and m not in ("プリンター",)); printer_paper.setEnabled(has_print and m not in ("プリンター",))
                copies.setEnabled(has_print)
            out.currentTextChanged.connect(lambda _=None:update_output_fields()); update_output_fields()
            f.addRow("尺度",scale_box); f.addRow("オフセット",offbox)
            f.addRow(lineweights); f.addRow(transparency); f.addRow(plotstyles)
            f.addRow("Layout対象",layout_mode); f.addRow("対象Layout",layoutrow)
            f.addRow(import_dwg); f.addRow(refresh_env,env_status)
        elif key=="rule":
            relation=QComboBox(); relation.addItems(["AND","OR"]); relation.setCurrentText(p.get("relation","AND")); relation.setFixedWidth(W_SHORT)
            case_sensitive=QCheckBox("大文字・小文字を区別"); case_sensitive.setChecked(bool(p.get("case_sensitive",False)))
            cond_box=QWidget(); cv=QVBoxLayout(cond_box); cv.setContentsMargins(0,0,0,0); cond_widgets=[]
            builder_target={"ent":None}
            add_cond_btn=QPushButton("＋ 条件")
            regex_builder_btn=QPushButton("正規表現ビルダー..."); regex_builder_btn.setFixedWidth(W_ACTION)
            regex_builder_btn.setToolTip("ファイル名の形から正規表現を作成します")

            def add_condition(data=None):
                data=data or {"mode":"含む","value":""}
                rw=QWidget(); rw.setMaximumWidth(420); rh=QHBoxLayout(rw); rh.setContentsMargins(0,0,0,0)
                mc=QComboBox(); mc.addItems(["含む","含まない","先頭一致","末尾一致","完全一致","正規表現"]); mc.setCurrentText(data.get("mode","含む")); mc.setFixedWidth(W_SHORT)
                val=QLineEdit(data.get("value","")); val.setProperty("builder_template", data.get("builder_template", "")); val.setFixedWidth(W_LONG)
                rm=QPushButton("－"); rm.setFixedWidth(30)
                rh.addWidget(mc); rh.addWidget(val,1); rh.addWidget(rm); cv.insertWidget(max(0,cv.count()-1),rw)
                ent=[rw,mc,val]; cond_widgets.append(ent)
                if builder_target["ent"] is None: builder_target["ent"]=ent
                def mark_target(*_): builder_target["ent"]=ent
                def manual_text_edited(_text):
                    builder_target["ent"]=ent
                    # A hand-edited regex no longer has a lossless builder template.
                    val.setProperty("builder_template", "")
                val.cursorPositionChanged.connect(mark_target); val.textEdited.connect(manual_text_edited); mc.currentTextChanged.connect(mark_target)
                def remove():
                    if len(cond_widgets)<=1:return
                    cond_widgets.remove(ent)
                    if builder_target.get("ent") is ent: builder_target["ent"]=cond_widgets[0] if cond_widgets else None
                    rw.deleteLater(); update_test()
                rm.clicked.connect(remove); mc.currentTextChanged.connect(lambda _=None:update_test()); val.textChanged.connect(lambda _=None:update_test())
                return ent

            cv.addWidget(add_cond_btn)
            for c in p.get("conditions") or [{"mode":p.get("mode","含む"),"value":p.get("value","")}]: add_condition(c)
            add_cond_btn.clicked.connect(lambda:add_condition())

            def registered_list_files():
                owner=self.parent()
                while owner is not None and not hasattr(owner,"all_file_items"):
                    owner=owner.parent() if hasattr(owner,"parent") else None
                if owner is None:return []
                out=[]
                try:
                    for it in owner.all_file_items():
                        path=owner.item_path(it)
                        if path: out.append(Path(path).name)
                except Exception:
                    return []
                return out

            def open_regex_builder():
                ent=builder_target.get("ent")
                if ent is None:
                    ent=add_condition({"mode":"正規表現","value":""})
                # A non-empty ordinary condition must never be overwritten silently.
                if ent[1].currentText()!="正規表現" and ent[2].text().strip():
                    ent=add_condition({"mode":"正規表現","value":""})
                    builder_target["ent"]=ent
                initial=ent[2].property("builder_template") or ""
                dlg=RegexBuilderDialog(self, initial_template=initial,
                                       case_sensitive=case_sensitive.isChecked(),
                                       test_files=registered_list_files())
                if dlg.exec()!=QDialog.Accepted:return
                ent[1].setCurrentText("正規表現")
                ent[2].setText(dlg.regex_pattern)
                ent[2].setProperty("builder_template", dlg.template_text)
                builder_target["ent"]=ent
                update_test()
            regex_builder_btn.clicked.connect(open_regex_builder)

            test_name=QLineEdit(); test_name.setPlaceholderText("例: P001_A3.dwg"); test_name.setFixedWidth(W_LONG)
            test_result=QLabel("―")
            def current_rule():
                conditions=[]
                for _,mc,val in cond_widgets:
                    c={"mode":mc.currentText(),"value":val.text()}
                    bt=val.property("builder_template") or ""
                    if mc.currentText()=="正規表現" and bt:
                        c["builder_template"]=bt
                    conditions.append(c)
                return {"relation":relation.currentText(),"case_sensitive":case_sensitive.isChecked(),"conditions":conditions}
            def update_test():
                rr=current_rule(); ok,msg=validate_rule(rr)
                if not ok: test_result.setText("⚠ 正規表現エラー: "+msg); return
                if not test_name.text().strip(): test_result.setText("―"); return
                test_result.setText("✓ 一致" if match_rule(test_name.text(),rr) else "× 不一致")
            relation.currentTextChanged.connect(lambda _=None:update_test()); case_sensitive.toggled.connect(lambda _=None:update_test()); test_name.textChanged.connect(lambda _=None:update_test())
            f.addRow("条件",cond_box); f.addRow("正規表現",regex_builder_btn); f.addRow("条件の組み合わせ",relation); f.addRow(case_sensitive); f.addRow("テスト",test_name); f.addRow("判定",test_result)
        elif key=="dest":
            mode=QComboBox(); mode.addItems(["CADと同じ","相対パス","固定フォルダ"]); mode.setCurrentText(p.get("mode","CADと同じ")); mode.setFixedWidth(W_MEDIUM)
            path=QLineEdit(p.get("path","")); path.setFixedWidth(W_LONG); browse=QPushButton("参照"); browse.setFixedWidth(68)
            pathrow=QWidget(); pathrow.setFixedWidth(284); ph=QHBoxLayout(pathrow); ph.setContentsMargins(0,0,0,0); ph.setSpacing(6); ph.addWidget(path); ph.addWidget(browse)
            preview=QLabel(); preview.setWordWrap(True)
            def choose_dest():
                d=QFileDialog.getExistingDirectory(self,"保存先フォルダ")
                if d:path.setText(d)
            def update_dest():
                m=mode.currentText(); pathrow.setEnabled(m!="CADと同じ")
                base=r"D:\工事\12345\CAD\P001.dwg"
                if m=="CADと同じ": out=r"D:\工事\12345\CAD\P001.pdf"
                elif m=="相対パス": out="D:\\工事\\12345\\CAD\\"+(path.text() or "..\\PDF")+"\\P001.pdf"
                else: out=(path.text() or r"D:\PDF_Output")+r"\P001.pdf"
                preview.setText("例: "+out)
            browse.clicked.connect(choose_dest); mode.currentTextChanged.connect(lambda _=None:update_dest()); path.textChanged.connect(lambda _=None:update_dest()); update_dest()
            f.addRow("保存方法",mode); f.addRow("パス",pathrow); f.addRow("プレビュー",preview)
        elif key=="name":
            tmpl=QLineEdit(p.get("template","{CAD名}")); tmpl.setFixedWidth(W_LONG); prev=QLabel(); prev.setWordWrap(True)
            tokenrow=QWidget(); th=QHBoxLayout(tokenrow); th.setContentsMargins(0,0,0,0)
            for label,token in [("CAD名","{CAD名}"),("グループ名","{グループ名}"),("日付","{日付}")]:
                b=QPushButton(label); b.clicked.connect(lambda _=False,t=token: tmpl.insert(t)); th.addWidget(b)
            th.addStretch(1)
            def update_name_preview():
                try:
                    stem=render_pdf_stem(tmpl.text(),cad_name="P-001-A3",group_name="新規グループ1",plot_name="A3縦PDF",date_text="20260927")
                    prev.setText(stem+".pdf")
                except ValueError as e:
                    prev.setText("⚠ "+str(e))
            tmpl.textChanged.connect(lambda _=None:update_name_preview()); update_name_preview()
            f.addRow("ファイル名構成",tmpl); f.addRow("項目を挿入",tokenrow); f.addRow("プレビュー",prev)
        elif key=="merge":
            enabled=QCheckBox("グループ単位でPDFを結合"); enabled.setChecked(p.get("enabled",True)); f.addRow(enabled)
            individual=QComboBox(); individual.addItems(["残す","結合成功後に削除","別フォルダへ移動"]); individual.setCurrentText(p.get("individual","残す" if p.get("keep_individual",True) else "結合成功後に削除")); individual.setFixedWidth(W_MEDIUM)
            subfolder=QLineEdit(p.get("individual_folder","個別PDF")); subfolder.setFixedWidth(W_LONG); f.addRow("個別PDF",individual); f.addRow("移動先サブフォルダ",subfolder)
            order=QComboBox(); order.addItems(["現在のリスト順","自動並び替え"]); order.setCurrentText(p.get("order","現在のリスト順")); order.setFixedWidth(W_MEDIUM); f.addRow("結合順",order)
            sort_rules=QListWidget(); sort_rules.setMaximumHeight(125)
            rule_by_id={r.get("id"):r for r in self.store.data.get("rule",[])}
            for rid in p.get("sort_rule_ids",[]):
                if rid in rule_by_id:
                    it=QListWidgetItem(rule_by_id[rid].get("name",rid)); it.setData(Qt.UserRole,rid); sort_rules.addItem(it)
            sr_row=QWidget(); srh=QHBoxLayout(sr_row); srh.setContentsMargins(0,0,0,0)
            sr_combo=QComboBox(); sr_combo.setFixedWidth(W_MEDIUM)
            for r in self.store.data.get("rule",[]): sr_combo.addItem(r.get("name",""),r.get("id"))
            sr_add=QPushButton("＋"); sr_up=QPushButton("↑"); sr_down=QPushButton("↓"); sr_del=QPushButton("－")
            for b in (sr_add,sr_up,sr_down,sr_del): b.setFixedWidth(30)
            srh.addWidget(sr_combo,1); srh.addWidget(sr_add); srh.addWidget(sr_up); srh.addWidget(sr_down); srh.addWidget(sr_del)
            def add_sort_rule():
                rid=sr_combo.currentData()
                if rid is None:return
                if any(sort_rules.item(i).data(Qt.UserRole)==rid for i in range(sort_rules.count())):return
                it=QListWidgetItem(sr_combo.currentText()); it.setData(Qt.UserRole,rid); sort_rules.addItem(it)
            def move_sort_rule(delta):
                row=sort_rules.currentRow(); new=row+delta
                if row<0 or new<0 or new>=sort_rules.count():return
                it=sort_rules.takeItem(row); sort_rules.insertItem(new,it); sort_rules.setCurrentRow(new)
            sr_add.clicked.connect(add_sort_rule); sr_up.clicked.connect(lambda:move_sort_rule(-1)); sr_down.clicked.connect(lambda:move_sort_rule(1)); sr_del.clicked.connect(lambda: sort_rules.takeItem(sort_rules.currentRow()) if sort_rules.currentRow()>=0 else None)
            f.addRow("自動並び替えルール",sort_rules); f.addRow("ルール操作",sr_row)
            same_class=QComboBox(); same_class.addItems(["自然順"]); same_class.setCurrentText(p.get("same_class_order","自然順")); same_class.setFixedWidth(W_MEDIUM)
            unmatched=QComboBox(); unmatched.addItems(["最後に配置","最初に配置"]); unmatched.setCurrentText(p.get("unmatched","最後に配置")); unmatched.setFixedWidth(W_MEDIUM)
            f.addRow("同じ分類内",same_class); f.addRow("分類されないファイル",unmatched)
            merged_name=QLineEdit(p.get("merged_name","{グループ名}.pdf")); merged_name.setFixedWidth(W_LONG); f.addRow("結合PDF名",merged_name)
            def sync_sort_enabled():
                on=enabled.isChecked() and order.currentText()=="自動並び替え"
                sort_rules.setEnabled(on); sr_row.setEnabled(on)
            enabled.toggled.connect(sync_sort_enabled); order.currentTextChanged.connect(sync_sort_enabled); sync_sort_enabled()
        else:
            # プリセット集: 他の既存プリセットを参照して組み合わせるだけの上位プリセット
            guide=QLabel("プリセット集は既存プリセットの組み合わせです。ここでは個別の印刷条件を直接設定しません。")
            guide.setWordWrap(True)
            f.addRow(guide)
            pairs_box=QWidget(); pairs_box.setMaximumWidth(420); pv=QVBoxLayout(pairs_box); pv.setContentsMargins(0,0,0,0)
            pair_widgets=[]

            def add_pair(pair=None):
                pair=pair or {}
                rw=QWidget(); rw.setMaximumWidth(420); rh=QHBoxLayout(rw); rh.setContentsMargins(0,0,0,0)
                rc=QComboBox(); pc=QComboBox(); rc.setFixedWidth(W_MEDIUM); pc.setFixedWidth(W_MEDIUM)
                for rr in self.store.data["rule"]: rc.addItem(rr["name"],rr["id"])
                for pp in self.store.data["plot"]: pc.addItem(pp["name"],pp["id"])
                if pair.get("rule_id") is not None:
                    ix=rc.findData(pair["rule_id"]); rc.setCurrentIndex(max(ix,0))
                if pair.get("plot_id") is not None:
                    ix=pc.findData(pair["plot_id"]); pc.setCurrentIndex(max(ix,0))
                up=QPushButton("↑"); down=QPushButton("↓"); rm=QPushButton("×")
                for b in (up,down,rm): b.setFixedWidth(28)
                rh.addWidget(rc,1); rh.addWidget(QLabel("→")); rh.addWidget(pc,1); rh.addWidget(up); rh.addWidget(down); rh.addWidget(rm)
                # insert before add button if it exists
                insert_at=max(0,pv.count()-1)
                pv.insertWidget(insert_at,rw)
                ent=[rw,rc,pc]; pair_widgets.append(ent)

                def rebuild():
                    # Visual order = pair_widgets order
                    for ent2 in pair_widgets:
                        pv.removeWidget(ent2[0])
                    for i,ent2 in enumerate(pair_widgets):
                        pv.insertWidget(i,ent2[0])
                def move(delta):
                    i=pair_widgets.index(ent); j=i+delta
                    if 0<=j<len(pair_widgets):
                        pair_widgets[i],pair_widgets[j]=pair_widgets[j],pair_widgets[i]; rebuild()
                def remove():
                    if len(pair_widgets)<=1:return
                    pair_widgets.remove(ent); rw.deleteLater()
                up.clicked.connect(lambda:move(-1)); down.clicked.connect(lambda:move(1)); rm.clicked.connect(remove)

            addbtn=QPushButton("＋ 組み合わせを追加"); addbtn.setFixedWidth(190)
            pv.addWidget(addbtn, 0, Qt.AlignLeft)
            for pair in p.get("pairs",[]): add_pair(pair)
            if not pair_widgets:add_pair()
            addbtn.clicked.connect(lambda:add_pair())
            f.addRow("名前ルール → 印刷設定",pairs_box)

            defaultc=QComboBox(); defaultc.setFixedWidth(W_LONG); defaultc.addItem("未設定",None)
            for x in self.store.data["plot"]: defaultc.addItem(x["name"],x["id"])
            ix=defaultc.findData(p.get("default_plot_id")); defaultc.setCurrentIndex(max(ix,0))
            f.addRow("一致しない場合",defaultc)

            destc=QComboBox(); destc.setFixedWidth(W_LONG)
            for x in self.store.data["dest"]: destc.addItem(x["name"],x["id"])
            ix=destc.findData(p.get("dest_id")); destc.setCurrentIndex(max(ix,0))
            namec=QComboBox(); namec.setFixedWidth(W_LONG)
            for x in self.store.data["name"]: namec.addItem(x["name"],x["id"])
            ix=namec.findData(p.get("name_id")); namec.setCurrentIndex(max(ix,0))
            mergec=QComboBox(); mergec.setFixedWidth(W_LONG)
            for x in self.store.data["merge"]: mergec.addItem(x["name"],x["id"])
            ix=mergec.findData(p.get("merge_id")); mergec.setCurrentIndex(max(ix,0))
            f.addRow("PDF保存先プリセット",destc)
            f.addRow("PDFファイル名プリセット",namec)
            f.addRow("PDF結合プリセット",mergec)

            # Collection test area
            testbox=QGroupBox("判定テスト"); testbox.setMaximumWidth(430)
            tv=QVBoxLayout(testbox)
            th=QHBoxLayout()
            testpath=QLineEdit(); testpath.setPlaceholderText("DWG/DXFファイル名、またはファイルを選択"); testpath.setFixedWidth(240)
            choose=QPushButton("ファイル選択"); choose.setFixedWidth(78)
            th.addWidget(testpath,1); th.addWidget(choose); tv.addLayout(th)
            testresult=QLabel("―"); testresult.setWordWrap(True); tv.addWidget(testresult)
            def run_collection_test():
                from pathlib import Path as _P
                fn=_P(testpath.text()).name
                if not fn: testresult.setText("―"); return
                tempcol={"pairs":[{"rule_id":rc.currentData(),"plot_id":pc.currentData()} for _,rc,pc in pair_widgets]}
                rr,pp=resolve_file(fn,tempcol,self.store.data)
                testresult.setText(f"✓ {rr['name']} → {pp['name']}" if rr and pp else "⚠ 未判定")
            def choose_file():
                fp,_=QFileDialog.getOpenFileName(self,"判定するDWG/DXFを選択","","CAD (*.dwg *.dxf)")
                if fp:testpath.setText(fp)
            choose.clicked.connect(choose_file); testpath.textChanged.connect(run_collection_test)
            f.addRow(testbox)
        btn=QPushButton("保存"); btn.setFixedWidth(110)
        def save():
            p["name"]=name.text().strip() or p["name"]
            if key=="plot":
                _paper_saved = str(paper.currentData()) if paper.currentData() not in (None, "") else paper.currentText()
                _printer_paper_saved = str(printer_paper.currentData()) if printer_paper.currentData() not in (None, "") else printer_paper.currentText()
                _cur_num = None if scale_num.value()==0.0 and scale_den.value()==0.0 else scale_num.value()
                _cur_den = None if scale_num.value()==0.0 and scale_den.value()==0.0 else scale_den.value()
                def _same_scale_value(a,b):
                    if a in (None,"") and b in (None,""): return True
                    try: return abs(float(a)-float(b)) <= max(1e-9,abs(float(a))*1e-9)
                    except Exception: return False
                if fit.isChecked():
                    _scale_mode="fit"; _use_std=True; _std_index=0
                elif (_exact_scale_state.get("mode")=="standard" and
                      _same_scale_value(_cur_num,_exact_scale_state.get("num")) and
                      _same_scale_value(_cur_den,_exact_scale_state.get("den"))):
                    # No scale edit since DWG import/editor load: retain the exact
                    # AutoCAD StandardScale enum instead of silently converting it
                    # to a custom ratio.
                    _scale_mode="standard"; _use_std=True; _std_index=_exact_scale_state.get("standard_scale_index")
                else:
                    _scale_mode="custom"; _use_std=False; _std_index=None
                _current_orientation=orient.currentText()
                _saved_rotation=_exact_rotation_state.get("rotation")
                if (_current_orientation==_exact_rotation_state.get("orientation") and
                    ((_current_orientation=="横" and _saved_rotation in ("90°","270°")) or
                     (_current_orientation=="縦" and _saved_rotation in ("0°","180°")))):
                    _rotation_to_save=_saved_rotation
                else:
                    _rotation_to_save="90°" if _current_orientation=="横" else "0°"
                p.update(output=out.currentText(),setting_method=setting_method.currentText(),device=device.currentText(),paper=_paper_saved,
                                      printer_device=printer_device.currentText(),printer_paper=_printer_paper_saved,
                                      plot_style=style.currentText(),orientation=_current_orientation,rotation=_rotation_to_save,
                                      copies=copies.value(),plot_area=plot_area.currentText(),
                                      fit_to_paper=fit.isChecked(),center_plot=center.isChecked(),
                                      scale_mode=_scale_mode,use_standard_scale=_use_std,standard_scale_index=_std_index,
                                      paper_units=_exact_scale_state.get("paper_units"),
                                      scale_num=_cur_num,scale_den=_cur_den,
                                      offset_x=offx.value(),offset_y=offy.value(),
                                      lineweights=lineweights.isChecked(),transparency=transparency.isChecked(),
                                      plot_styles=plotstyles.isChecked(),rotate_a3_a1_landscape=rotate_a_sizes.isChecked(),layout_mode=layout_mode.currentData(),
                                      layout_names=list(layout_names_state),
                                      window_x1=_coord_value(window_x1),window_y1=_coord_value(window_y1),
                                      window_x2=_coord_value(window_x2),window_y2=_coord_value(window_y2))
            elif key=="rule":
                rr=current_rule(); ok,msg=validate_rule(rr)
                if not ok:
                    QMessageBox.warning(self,"保存できません","正規表現が正しくありません。\n\n"+msg); return
                p.update(relation=rr["relation"],case_sensitive=rr["case_sensitive"],conditions=rr["conditions"])
                p.pop("mode",None); p.pop("value",None)
            elif key=="dest": p.update(mode=mode.currentText(),path=path.text())
            elif key=="name": p["template"]=tmpl.text()
            elif key=="merge": p.update(enabled=enabled.isChecked(),order=order.currentText(),
                                      sort_rule_ids=[sort_rules.item(i).data(Qt.UserRole) for i in range(sort_rules.count())],
                                      individual=individual.currentText(),individual_folder=subfolder.text().strip() or "個別PDF",
                                      merged_name=merged_name.text().strip() or "{グループ名}.pdf",
                                      same_class_order=same_class.currentText(),unmatched=unmatched.currentText(),
                                      keep_individual=(individual.currentText()=="残す"))
            elif key=="collection":
                p["pairs"]=[{"rule_id":rc.currentData(),"plot_id":pc.currentData()} for _,rc,pc in pair_widgets]
                p["default_plot_id"]=defaultc.currentData()
                p["dest_id"]=destc.currentData()
                p["name_id"]=namec.currentData()
                p["merge_id"]=mergec.currentData()
            self.store.save()
            self.store.config["preset_manager_category"]=self.kinds.currentRow()
            self.store.config["preset_manager_rows"]=self.last_rows
            self.store.save_config()
            self.reload()
        btn.clicked.connect(save); f.addRow(btn)
        # 現在カテゴリ専用ページの本文だけを差し替える。
        _page, _body, body_lay = self.editor_pages[key]
        # Removed widgets must be detached immediately. deleteLater()だけでは、
        # 同一イベントループ中の連続 show_editor() で旧Editorが画面に残り、
        # 新Editorと重なって見えるため。
        self._dispose_layout_widgets(body_lay)
        # RC3の旧Editor即時破棄対策は維持。RC4ではスクロールを使わないため、
        # 固定の最小高さを課さず、利用可能な縦幅へQtレイアウトで収める。
        # RC19: Editor本体は内容幅だけ使い、右側の余白は空白として残す。
        # これにより右側の長い枠がSplitterを押して左一覧を縮めない。
        w.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        w.setMaximumWidth(590)
        body_lay.addWidget(w, 0, Qt.AlignLeft | Qt.AlignTop)
        body_lay.addStretch(1)
        self.editor.setCurrentWidget(_page)

class CadListTree(QTreeWidget):
    """D&D guard for both internal moves and Explorer file/folder drops."""
    def dragEnterEvent(self,event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction(); return
        super().dragEnterEvent(event)

    def dragMoveEvent(self,event):
        if event.mimeData().hasUrls() and event.source() is not self:
            event.acceptProposedAction(); return
        super().dragMoveEvent(event)

    def dropEvent(self,event):
        # Explorer drops normally land on the tree itself, not MainWindow.
        # Forward them to the same importer used by MainWindow drops.
        if event.source() is not self and event.mimeData().hasUrls():
            paths=[u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
            owner=self.window()
            if hasattr(owner,"_handle_external_drop_paths"):
                owner._handle_external_drop_paths(paths)
                event.acceptProposedAction(); return
        selected=self.selectedItems()
        if not selected:return
        target=self.itemAt(event.position().toPoint()) if hasattr(event,"position") else self.itemAt(event.pos())
        pos=self.dropIndicatorPosition()
        moving_group=any((x.data(0,Qt.UserRole) or {}).get("type")=="group" for x in selected)
        if moving_group:
            if pos==QAbstractItemView.OnItem or (target is not None and target.parent() is not None):
                event.ignore(); return
        else:
            if pos==QAbstractItemView.OnItem and target is not None and (target.data(0,Qt.UserRole) or {}).get("type")!="group":
                event.ignore(); return
        super().dropEvent(event)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("ACadPresetter"); self.resize(980,680)
        self.store=Store(APP_DIR/"data"); self.store.load()
        self.run_history=RunHistory(APP_DIR, self.store.config)
        self.session = SessionManager(APP_DIR/"data"/"session.json")
        c=QWidget(); self.setCentralWidget(c); v=QVBoxLayout(c)
        top=QHBoxLayout(); top.addWidget(QLabel("プリセット集"))
        self.collection=QComboBox()
        self.collection.addItem("（未選択）",None)
        for p in self.store.data["collection"]: self.collection.addItem(p["name"],p["id"])
        top.addWidget(self.collection,1)
        b_pre=QPushButton("🔧 プリセット管理"); b_set=QPushButton("⚙ 設定")
        b_save=QPushButton("💾 リスト保存"); b_load=QPushButton("📂 リスト読込"); b_import=QPushButton("➕ リスト追加")
        b_clear=QPushButton("🗑 リストクリア")
        b_clear.setToolTip("メインリストだけを空にします。DWG/DXFや保存済み.acplistは削除しません。")
        top.addWidget(b_save); top.addWidget(b_load); top.addWidget(b_import); top.addWidget(b_clear); top.addWidget(b_pre); top.addWidget(b_set); v.addLayout(top)
        self.tree=CadListTree(); self.tree.setHeaderLabels(["ファイル / グループ","判定ルール","印刷設定","出力","状態"])
        QShortcut(QKeySequence("Ctrl+G"),self,self.group_selected)
        QShortcut(QKeySequence("Ctrl+Shift+G"),self,self.ungroup_selected)
        QShortcut(QKeySequence("F2"),self,self.rename_selected)
        QShortcut(QKeySequence("Delete"),self,self.remove_selected)
        QShortcut(QKeySequence("Ctrl+A"),self.tree,self.tree.selectAll)
        QShortcut(QKeySequence("Space"),self.tree,self.toggle_selected_output)
        # ファイル名を優先。全体幅を抑えつつ、最初の列を広くする。
        self.tree.setColumnWidth(0, 390)
        self.tree.setColumnWidth(1, 145)
        self.tree.setColumnWidth(2, 150)
        self.tree.setColumnWidth(3, 80)
        self.tree.setColumnWidth(4, 65)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setDragDropMode(QAbstractItemView.InternalMove)
        self.tree.setDefaultDropAction(Qt.MoveAction)
        self._reordering=False
        self.tree.model().rowsMoved.connect(self._on_internal_rows_moved)
        self._syncing_checks=False
        self._bulk_tree_depth=0
        # Newly-created groups are expanded/collapsed only after all rejudge/order work finishes.
        # This prevents a later tree mutation from losing the requested initial state.
        self._pending_new_group_states={}
        self.tree.itemChanged.connect(self._on_tree_item_changed)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.file_context_menu); v.addWidget(self.tree,1)
        # Step37: 出力進捗は別ダイアログではなくメイン画面内に表示する。
        self.progress_panel=QWidget(); pg=QVBoxLayout(self.progress_panel); pg.setContentsMargins(0,4,0,4)
        pg_top=QHBoxLayout(); self.progress_text=QLabel("待機中"); self.progress_elapsed=QLabel("")
        pg_top.addWidget(self.progress_text,1); pg_top.addWidget(self.progress_elapsed)
        self.progress_bar=QProgressBar(); self.progress_bar.setRange(0,100); self.progress_bar.setValue(0)
        self.cancel_output_btn=QPushButton("■ 中止"); self.cancel_output_btn.setVisible(False)
        self.open_output_folder_btn=QPushButton("📁 保存先を開く"); self.open_output_folder_btn.setVisible(False)
        self._last_output_folders=[]
        self.open_output_folder_btn.clicked.connect(self.open_last_output_folder)
        pg_bar=QHBoxLayout(); pg_bar.addWidget(self.progress_bar,1); pg_bar.addWidget(self.open_output_folder_btn); pg_bar.addWidget(self.cancel_output_btn)
        pg.addLayout(pg_top); pg.addLayout(pg_bar); self.progress_panel.setVisible(False); v.addWidget(self.progress_panel)

        bottom=QHBoxLayout(); self.status=QLabel("0ファイル"); bottom.addWidget(self.status); bottom.addStretch()
        retry_failed=QPushButton("↻ 失敗だけ再実行")
        retry_pending=QPushButton("▶ 未処理だけ再開")
        runout=QPushButton("▶ 対象を出力")
        bottom.addWidget(retry_failed); bottom.addWidget(retry_pending); bottom.addWidget(runout); v.addLayout(bottom)
        self._output_lock_widgets=[self.collection,b_save,b_load,b_import,b_clear,b_pre,b_set,retry_failed,retry_pending,runout]
        self._output_cancel_requested=False; self._output_started_at=0.0; self._output_in_progress=False
        self._next_group_number=1
        # Step43: replacement-load/save tracks the current .acplist. Append import never changes it.
        self._current_list_path=None
        # Step51: frequent UI operations (D&D/reorder/rejudge) may request session saves
        # several times in a short burst. Coalesce them into one disk write.
        self._session_save_pending=False
        self._session_save_timer=QTimer(self)
        self._session_save_timer.setSingleShot(True)
        self._session_save_timer.setInterval(250)
        self._session_save_timer.timeout.connect(self._flush_session_save)
        self.setAcceptDrops(True)
        self.collection.currentIndexChanged.connect(self._on_collection_changed)
        b_pre.clicked.connect(self.open_preset_manager)
        b_save.clicked.connect(self.export_list)
        b_load.clicked.connect(self.import_list_replace)
        b_import.clicked.connect(self.import_list_append)
        b_clear.clicked.connect(self.clear_main_list)
        b_set.clicked.connect(self.show_app_settings)
        retry_failed.clicked.connect(lambda: self.retry_last_output("failed"))
        retry_pending.clicked.connect(lambda: self.retry_last_output("pending"))
        runout.clicked.connect(self.run_batch_output)
        self.cancel_output_btn.clicked.connect(self.request_output_cancel)
        delact=QAction(self); delact.setShortcut(QKeySequence.Delete); delact.triggered.connect(self.remove_selected); self.addAction(delact)
        if self.store.config.get("restore_session", True):
            self.load_session(silent=True, restore_items=False)

    def _on_collection_changed(self, *_args):
        """Collection changes always rejudge assignments and reapply merge-list order."""
        self.rejudge()

    def selected_cad_paths(self):
        """Return selected DWG/DXF paths from the current dict-based tree model."""
        paths=[]
        for item in self.tree.selectedItems():
            data=item.data(0,Qt.UserRole) or {}
            if data.get("type")=="group":
                candidates=[item.child(i) for i in range(item.childCount())]
            else:
                candidates=[item]
            for candidate in candidates:
                cd=candidate.data(0,Qt.UserRole) or {}
                if cd.get("type")!="file":
                    continue
                path=str(cd.get("path") or "")
                if path.lower().endswith((".dwg",".dxf")):
                    paths.append(path)
        return list(dict.fromkeys(paths))

    def choose_source_dwg_for_settings(self):
        paths=self.selected_cad_paths()
        if len(paths)==1:return paths[0]
        if len(paths)>1:
            labels=[Path(p).name for p in paths]
            name,ok=QInputDialog.getItem(self,"DWGから印刷設定を取得","複数選択されています。取得元DWGを選択してください:",labels,0,False)
            if not ok:return None
            return paths[labels.index(name)]
        fn,_=QFileDialog.getOpenFileName(self,"印刷設定を取得するDWG/DXF","","CAD (*.dwg *.dxf)")
        return fn or None

    def dragEnterEvent(self,e):
        if e.mimeData().hasUrls(): e.acceptProposedAction()

    def dropEvent(self,e):
        paths=[u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        self._handle_external_drop_paths(paths)
        e.acceptProposedAction()

    def _handle_external_drop_paths(self, paths):
        if getattr(self,"_output_in_progress",False): return
        """Single entry point for Explorer D&D, whether dropped on tree or window."""
        folders,direct=classify_external_drop(paths)
        existing={str(Path(self.item_path(x)).resolve()).casefold() for x in self.all_file_items() if self.item_path(x)}
        skipped=0; added=0; groups_added=0

        def fresh(seq):
            nonlocal skipped
            out=[]
            for p in seq:
                try:key=str(Path(p).resolve()).casefold()
                except Exception:key=str(Path(p)).casefold()
                if key in existing:
                    skipped+=1; continue
                existing.add(key); out.append(Path(p))
            return out

        # Bulk insertion disables intermediate paints/signals. A 200-file folder should
        # feel like one list update, not 200 separate UI operations.
        with self._bulk_tree_update():
            # Folder D&D is intentionally simple: direct children only, one folder = one group.
            # Empty/unsupported folders do not create empty groups.
            for folder in folders:
                files=fresh(direct_cad_children(folder))
                if not files: continue
                # When enabled, a folder-created group uses the dropped folder name.
                group_name = Path(folder).name if self.store.config.get("group_name_from_folder", True) else None
                parent=self._new_group_item(group_name); groups_added+=1
                for fp in files:self.add_file(fp,parent); added+=1

            # Directly dropped CAD files follow the user setting. A single file stays ungrouped.
            direct=fresh(direct)
            if direct:
                group=False
                if len(direct)>1:
                    mode=normalize_drop_group_mode(self.store.config.get("drop_group_mode","ask"))
                    if mode=="group": group=True
                    elif mode=="ask":
                        group=QMessageBox.question(self,"グループ化",f"{len(direct)}個の図面ファイルを1つのグループとして追加しますか？",QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes
                if group:
                    group_name = self._group_name_for_paths(direct) if self.store.config.get("group_name_from_folder", True) else None
                    parent=self._new_group_item(group_name)
                else:
                    parent=None
                if parent is not None:groups_added+=1
                for fp in direct:self.add_file(fp,parent); added+=1

        if added:
            self.rejudge()  # includes auto merge-order normalization and session save
        else:
            self.update_status(); self.save_session(silent=True)
        extras=[]
        if added:extras.append(f"追加 {added}件")
        if groups_added:extras.append(f"グループ {groups_added}件")
        if skipped:extras.append(f"重複 {skipped}件を除外")
        if extras:self.status.setText(self.status.text()+" ｜ "+" ｜ ".join(extras))
        return {"added":added,"groups":groups_added,"duplicates":skipped}

    @staticmethod
    def _natural_path_key(p):
        return natural_path_key(p)

    def _group_name_for_paths(self, paths):
        """Use the containing folder name when every grouped file comes from one folder."""
        parents=[]
        for p in paths:
            try:
                parents.append(Path(p).resolve().parent)
            except Exception:
                parents.append(Path(p).parent)
        if parents and all(str(x).casefold()==str(parents[0]).casefold() for x in parents):
            return parents[0].name or None
        return None

    def _new_group_item(self, name=None, group_id=None):
        name=name or self.next_group_name()
        gid=group_id or "group_"+uuid.uuid4().hex
        g=QTreeWidgetItem([name,"","","",""])
        g.setData(0,Qt.UserRole,{"type":"group","id":gid,"name":name})
        g.setFlags(g.flags()|Qt.ItemIsDropEnabled|Qt.ItemIsEditable|Qt.ItemIsAutoTristate|Qt.ItemIsUserCheckable)
        g.setCheckState(0,Qt.Checked)
        self.tree.addTopLevelItem(g)
        self._pending_new_group_states[gid]=bool(self.store.config.get("expand_new_groups", True))
        return g

    def _apply_pending_new_group_states(self):
        """Apply initial expansion after all list rebuild/reorder operations are complete."""
        if not self._pending_new_group_states:
            return
        pending=dict(self._pending_new_group_states)
        self._pending_new_group_states.clear()
        for i in range(self.tree.topLevelItemCount()):
            it=self.tree.topLevelItem(i)
            d=it.data(0,Qt.UserRole) or {}
            gid=d.get("id")
            if d.get("type")=="group" and gid in pending:
                it.setExpanded(bool(pending[gid]))
        self.tree.viewport().update()

    def next_group_name(self):
        # Deleted/renamed groups must not make automatic numbering go backwards.
        import re
        highest=int(getattr(self,"_next_group_number",1))-1
        for i in range(self.tree.topLevelItemCount()):
            it=self.tree.topLevelItem(i); d=it.data(0,Qt.UserRole) or {}
            if d.get("type")!="group": continue
            m=re.fullmatch(r"新規グループ(\d+)",it.text(0).strip())
            if m: highest=max(highest,int(m.group(1)))
        n=max(1,highest+1)
        self._next_group_number=n+1
        return f"新規グループ{n}"

    def add_file(self,p,parent=None,manual_plot_id=None,item_id=None):
        it=QTreeWidgetItem([p.name,"","","","未判定"])
        it.setFlags(it.flags() & ~Qt.ItemIsDropEnabled)
        it.setCheckState(0,Qt.Checked); it.setData(0,Qt.UserRole,{"type":"file","id":item_id or "item_"+uuid.uuid4().hex,"path":str(p),"manual_plot_id":manual_plot_id})
        (parent.addChild(it) if parent else self.tree.addTopLevelItem(it))

    def all_file_items(self):
        out=[]
        def walk(it):
            d=it.data(0,Qt.UserRole) or {}
            if d.get("type")=="file": out.append(it)
            for j in range(it.childCount()): walk(it.child(j))
        for i in range(self.tree.topLevelItemCount()): walk(self.tree.topLevelItem(i))
        return out
    def item_path(self,it): return (it.data(0,Qt.UserRole) or {}).get("path","")

    def _resolve_item_assignment(self, it):
        d=it.data(0,Qt.UserRole) or {}
        manual_id=d.get("manual_plot_id")
        if manual_id:
            pp=next((x for x in self.store.data.get("plot",[]) if x.get("id")==manual_id),None)
            return {"rule":None,"plot":pp,"source":"manual","priority":None}
        return resolve_file_detail(Path(self.item_path(it)).name,self.current_collection(),self.store.data)

    def _apply_assignment_to_item(self,it,result=None):
        d=it.data(0,Qt.UserRole) or {}
        result=result or self._resolve_item_assignment(it); rr=result.get("rule"); pp=result.get("plot")
        if result.get("source")=="manual":
            it.setText(1,"手動指定"); it.setText(2,pp.get("name","") if pp else "⚠ 設定なし")
            it.setText(3,pp.get("output","") if pp else ""); it.setText(4,"🔒" if pp else "⚠")
            it.setToolTip(0,"手動指定: "+(pp.get("name","") if pp else "削除された印刷設定"))
        elif pp:
            it.setText(1,rr.get("name","") if rr else "既定")
            it.setText(2,pp.get("name","")); it.setText(3,pp.get("output","PDF")); it.setText(4,"✓")
            tip=(f"自動判定: {rr.get('name','')} (優先順位 {result.get('priority')})" if rr else "自動判定: 一致しない場合の既定設定")
            it.setToolTip(0,tip)
        else:
            it.setText(1,"―"); it.setText(2,"―"); it.setText(3,"―"); it.setText(4,"⚠"); it.setToolTip(0,"未判定")
        d["plot_id"]=pp.get("id") if pp else None
        d["rule_id"]=rr.get("id") if rr else None
        d["assignment_source"]=result.get("source","none")
        d["rule_priority"]=result.get("priority")
        d.pop("manual",None)
        it.setData(0,Qt.UserRole,d)
        return result

    @contextmanager
    def _bulk_tree_update(self):
        """Coalesce expensive tree repaint/signal work during mass mutations."""
        outer = self._bulk_tree_depth == 0
        self._bulk_tree_depth += 1
        if outer:
            # Do NOT block the QTreeWidget model here.  QTreeWidgetItem insertion/removal
            # relies on the model's rowsInserted/rowsRemoved signals to make the view aware
            # of the new rows.  Blocking the model leaves the items in the internal tree
            # (so counters see them) while the viewport stays visually empty.
            self.tree.setUpdatesEnabled(False)
            self.tree.blockSignals(True)
        try:
            yield
        finally:
            self._bulk_tree_depth -= 1
            if outer:
                self.tree.blockSignals(False)
                self.tree.setUpdatesEnabled(True)
                self.tree.viewport().update()

    def _apply_auto_order_to_tree(self):
        """Compatibility entry point: normalize only when merge auto-order is enabled."""
        self._apply_merge_auto_order()

    def rejudge(self):
        # One repaint for the whole batch instead of 5-column updates per drawing.
        # This matters much more than raw Python matching cost on thin clients.
        items=self.all_file_items()
        with self._bulk_tree_update():
            for it in items:
                self._apply_assignment_to_item(it)
        self._apply_auto_order_to_tree()
        self._apply_pending_new_group_states()
        self.update_status(); self.save_session(silent=True)

    def open_preset_manager(self):
        current=self.collection.currentData()
        PresetDialog(self.store,self).exec()
        # Preset names/collections may have changed while the dialog was open.
        self.collection.blockSignals(True); self.collection.clear(); self.collection.addItem("（未選択）",None)
        for p in self.store.data.get("collection",[]): self.collection.addItem(p.get("name",""),p.get("id"))
        idx=self.collection.findData(current); self.collection.setCurrentIndex(idx if idx>=0 else 0); self.collection.blockSignals(False)
        self.rejudge()

    def update_status(self):
        fs=self.all_file_items(); ok=sum(x.text(4)=="✓" for x in fs); warn=sum(x.text(4)=="⚠" for x in fs)
        targets=sum(x.checkState(0)==Qt.Checked for x in fs)
        self.status.setText(f"{len(fs)}ファイル ｜ 対象 {targets} ｜ 判定済 {ok} ｜ 未判定 {warn}")

    def build_pdf_jobs(self):
        jobs=[]; problems=[]; seen={}
        col=self.current_collection()
        for it in self.all_file_items():
            if it.checkState(0)!=Qt.Checked: continue
            src=self.item_path(it)
            d=it.data(0,Qt.UserRole) or {}
            result=self._resolve_item_assignment(it); pp=result.get("plot")
            if not pp:
                problems.append(f"{Path(src).name}: 印刷設定が未判定"); continue
            # Step11 is PDF batch only. Physical printer path comes later.
            if pp.get("output","PDF") not in ("PDF","PDF＋プリンター","PDF+プリンター"):
                continue
            out=self.calc_output(it)
            if not out:
                problems.append(f"{Path(src).name}: PDF出力先を計算できません"); continue
            key=str(out).casefold()
            if key in seen:
                problems.append(f"{Path(src).name}: PDF名が重複 → {out}")
            seen[key]=src
            jobs.append({"source":src,"output":str(out),"settings":pp,"label":Path(src).name})
        return jobs,problems

    def _merge_preset_for_collection(self):
        col=self.current_collection()
        if not col:return None
        mid=col.get("merge_id") or col.get("merge")
        if isinstance(mid,dict):return mid
        for p in self.store.data.get("merge",[]):
            if p.get("id")==mid or p.get("name")==mid:return p
        return None

    def _merge_plan(self, only_existing=False, outputs_by_source=None):
        mp=self._merge_preset_for_collection()
        if not mp or not mp.get("enabled",True): return []
        from app.output_path import sanitize_filename_component
        plans=[]
        if outputs_by_source is None and only_existing:
            outputs_by_source={}
            rec=self.run_history.load().get("last") or {}
            for job in rec.get("jobs",[]):
                if str(job.get("kind","")).split(":",1)[0]=="PDF" and job.get("status")=="成功" and job.get("output"):
                    outputs_by_source.setdefault(job["source"],[]).append(job["output"])
        def outputs(it):
            src=self.item_path(it)
            if outputs_by_source is not None:
                return list(outputs_by_source.get(src,[]))
            out=self.calc_output(it)
            return [str(out)] if out else []
        # Reserve all individual destinations, including ungrouped drawings.
        reserved={str(Path(x)).casefold() for it in self.all_file_items() for x in outputs(it)}
        for gi in range(self.tree.topLevelItemCount()):
            g=self.tree.topLevelItem(gi); gd=g.data(0,Qt.UserRole) or {}
            if gd.get("type")!="group": continue
            inputs=[]; incomplete=False
            for ci in range(g.childCount()):
                it=g.child(ci)
                if it.checkState(0)!=Qt.Checked: continue
                pp=self._resolve_item_assignment(it).get("plot")
                if not pp or pp.get("output","PDF") not in ("PDF","PDF＋プリンター","PDF+プリンター"): continue
                values=outputs(it)
                if not values or (only_existing and any(not Path(x).is_file() for x in values)):
                    incomplete=True; break
                inputs.extend(values)
            if incomplete or len(inputs)<2: continue
            # The main tree has already applied the preset's sort rules to CAD
            # stems. Never sort again using renamed PDF filenames.
            gn=g.text(0).strip() or f"Group_{gi+1}"
            name=str(mp.get("merged_name","{グループ名}.pdf")).replace("{グループ名}",gn)
            name=sanitize_filename_component(name).strip() or "結合.pdf"
            if not name.lower().endswith(".pdf"): name+=".pdf"
            candidate=Path(inputs[0]).parent/name; merged=candidate; n=2
            while str(merged).casefold() in reserved:
                merged=candidate.with_name(f"{candidate.stem}_結合{n}{candidate.suffix}"); n+=1
            reserved.add(str(merged).casefold())
            plans.append({"group":gn,"inputs":inputs,"output":str(merged),"preset":mp})
        return plans

    def _execute_merge_plans(self, plans):
        """Commit merges, then retire only unchanged input revisions."""
        ok=[];err=[]
        for plan in plans:
            temp_session=None;staged=None
            try:
                temp_session=PdfOutputSession()
                staged=temp_session.stage("<merge>",plan["output"],plan.get("group","結合"))
                fingerprints={}
                merge_pdfs(plan["inputs"],staged.temp_path,input_fingerprints=fingerprints)
                temp_session.validate_pdf(staged.temp_path)
                temp_session.atomic_commit(staged.temp_path,staged.final_path)
                mp=plan["preset"];mode=mp.get("individual","残す")
                warnings=[]
                if mode in ("削除","結合成功後に削除","別フォルダへ移動"):
                    folder=None
                    if mode=="別フォルダへ移動":
                        folder=Path(plan["output"]).parent/(mp.get("individual_folder") or "個別PDF")
                        folder.mkdir(parents=True,exist_ok=True)
                    for x in plan["inputs"]:
                        src=Path(x)
                        try:
                            consumed=fingerprints.get(str(src))
                            if consumed is None or pdf_content_fingerprint(src)!=consumed:
                                warnings.append(f"結合後に内容が変わったため個別PDFを保持しました: {src}")
                                continue
                            if folder is None:
                                src.unlink()
                            else:
                                dst=folder/src.name;n=2
                                while dst.exists():
                                    dst=folder/f"{src.stem}_{n}{src.suffix}";n+=1
                                shutil.move(str(src),str(dst))
                        except Exception as exc:
                            warnings.append(f"個別PDFを削除・移動せず保持しました: {src} / {exc}")
                ok.append(plan)
                if warnings:
                    plan["warnings"]=warnings
                    err.append((plan,"結合PDFは保存済みです。\n"+"\n".join(warnings)))
            except Exception as exc:
                message=str(exc)
                if temp_session is not None and staged is not None:
                    try:
                        recovery=temp_session.retain_failed(staged.temp_path,APP_DIR/"data"/"recovery")
                        message+=f"\n生成ファイルの保全先: {recovery}"
                    except FileNotFoundError:
                        pass
                    except Exception as preserve_exc:
                        message+=f"\n生成ファイルの保全失敗: {preserve_exc}"
                err.append((plan,message))
            finally:
                if temp_session: temp_session.cleanup()
        return ok,err

    def remerge_existing_pdfs(self):
        plans=self._merge_plan(only_existing=True)
        if not plans:
            QMessageBox.information(self,"PDF再結合","結合できるグループがありません。\n各グループ内に生成済みPDFが2件以上必要です。")
            return
        text="\n".join(f"・{x['group']}: {len(x['inputs'])}枚 → {x['output']}" for x in plans)
        if QMessageBox.question(self,"PDF再結合","AutoCADを起動せず、生成済みPDFだけを結合します。\n\n"+text+"\n\n実行しますか？",
                                QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        ok,err=self._execute_merge_plans(plans)
        msg=f"結合成功: {len(ok)}グループ\n問題・要確認: {len(err)}グループ"
        if err: msg+="\n\n"+"\n".join(f"・{p['group']}: {e}" for p,e in err)
        QMessageBox.information(self,"PDF再結合結果",msg)

    def _remove_empty_groups(self):
        """Remove groups that became empty after move/delete/ungroup operations."""
        for i in range(self.tree.topLevelItemCount()-1,-1,-1):
            it=self.tree.topLevelItem(i); d=it.data(0,Qt.UserRole) or {}
            if d.get("type")=="group" and it.childCount()==0:
                self.tree.takeTopLevelItem(i)

    def _refresh_group_check_state(self, group):
        """Reflect child target states on the group checkbox.

        Target check state is runtime-only.  Explicit synchronization is used instead
        of relying solely on Qt ItemIsAutoTristate so that "group OFF -> one child ON"
        is always shown as PartiallyChecked on supported PySide6 versions.
        """
        if not group or group.childCount()==0:
            return
        states=[group.child(i).checkState(0) for i in range(group.childCount())]
        if all(x==Qt.Checked for x in states): state=Qt.Checked
        elif all(x==Qt.Unchecked for x in states): state=Qt.Unchecked
        else: state=Qt.PartiallyChecked
        group.setCheckState(0,state)

    def _on_tree_item_changed(self,item,column):
        """Synchronize group/child output-target checks without persisting them."""
        if self._syncing_checks or self._bulk_tree_depth or column!=0:return
        d=item.data(0,Qt.UserRole) or {}
        self._syncing_checks=True
        try:
            if d.get("type")=="group":
                state=item.checkState(0)
                if state!=Qt.PartiallyChecked:
                    for i in range(item.childCount()):item.child(i).setCheckState(0,state)
            elif d.get("type")=="file" and item.parent():
                self._refresh_group_check_state(item.parent())
        finally:
            self._syncing_checks=False
        self.update_status()

    def _manual_reorder_allowed(self):
        return not auto_order_enabled(self._merge_preset_for_collection())

    def _on_internal_rows_moved(self,*_args):
        if self._reordering:return
        self._remove_empty_groups()
        # Auto-order affects file order only. Moving a file to another group is allowed,
        # but arbitrary manual order inside that group is immediately normalized.
        if auto_order_enabled(self._merge_preset_for_collection()):
            self._apply_merge_auto_order()
            self.status.setText(self.status.text()+" ｜ 結合プリセット順に自動整列")
        self.update_status(); self.save_session(silent=True)

    def _apply_merge_auto_order(self):
        mp=self._merge_preset_for_collection()
        if not auto_order_enabled(mp) or self._reordering:return
        rules=self.store.data.get("rule",[])
        self._reordering=True
        # Keep model signals alive while rows are physically reordered.  The view needs
        # those structural notifications.  Only suppress QTreeWidget's high-level signals
        # to avoid recursive itemChanged work.
        old_blocked=self.tree.blockSignals(True)
        old_updates=self.tree.updatesEnabled()
        self.tree.setUpdatesEnabled(False)
        try:
            for gi in range(self.tree.topLevelItemCount()):
                g=self.tree.topLevelItem(gi); gd=g.data(0,Qt.UserRole) or {}
                if gd.get("type")!="group" or g.childCount()<2:continue
                children=[g.child(i) for i in range(g.childCount())]
                ordered=order_paths(children,mp,rules,filename_of=lambda it: Path(self.item_path(it)).name)
                while g.childCount():g.takeChild(0)
                for ch in ordered:g.addChild(ch)
            # Ungrouped files are sorted too, while group rows keep their positions/order.
            file_slots=[]; files=[]
            for i in range(self.tree.topLevelItemCount()):
                top=self.tree.topLevelItem(i); td=top.data(0,Qt.UserRole) or {}
                if td.get("type")=="file": file_slots.append(i); files.append(top)
            if len(files)>1:
                ordered_files=order_paths(files,mp,rules,filename_of=lambda it: Path(self.item_path(it)).name)
                for i in reversed(file_slots): self.tree.takeTopLevelItem(i)
                for i,it in zip(file_slots,ordered_files): self.tree.insertTopLevelItem(i,it)
        finally:
            self.tree.setUpdatesEnabled(old_updates)
            self.tree.blockSignals(old_blocked)
            self.tree.viewport().update()
            self._reordering=False

    def group_selected(self):
        if getattr(self,"_output_in_progress",False): return
        items=self._selected_file_items()
        if len(items)<2:
            QMessageBox.information(self,"グループ化","2ファイル以上選択してください。"); return
        paths=[self.item_path(it) for it in items]
        name=(self._group_name_for_paths(paths) if self.store.config.get("group_name_from_folder", True) else None) or self.next_group_name()
        gid="group_"+uuid.uuid4().hex
        g=QTreeWidgetItem([name,"","","",""])
        g.setData(0,Qt.UserRole,{"type":"group","id":gid,"name":name})
        g.setFlags(g.flags()|Qt.ItemIsDropEnabled|Qt.ItemIsEditable|Qt.ItemIsAutoTristate|Qt.ItemIsUserCheckable)
        g.setCheckState(0,Qt.Checked)
        self._pending_new_group_states[gid]=bool(self.store.config.get("expand_new_groups", True))
        # Insert at earliest selected top-level position where possible.
        positions=[]
        for it in items:
            top=it
            while top.parent(): top=top.parent()
            positions.append(self.tree.indexOfTopLevelItem(top))
        insert_at=max(0,min([x for x in positions if x>=0] or [self.tree.topLevelItemCount()]))
        self.tree.insertTopLevelItem(insert_at,g)
        for it in items:
            par=it.parent()
            if par: par.takeChild(par.indexOfChild(it))
            else:
                idx=self.tree.indexOfTopLevelItem(it)
                if idx>=0:self.tree.takeTopLevelItem(idx)
            g.addChild(it)
        # Apply only after the structural moves are finished.
        self._apply_pending_new_group_states()
        self.save_session()

    def ungroup_selected(self):
        if getattr(self,"_output_in_progress",False): return
        selected=list(self.tree.selectedItems())
        groups=[x for x in selected if (x.data(0,Qt.UserRole) or {}).get("type")=="group"]
        # A selected group means "ungroup the whole group". Selected child files mean
        # "remove only these files from their group". Do not unexpectedly dissolve
        # the entire parent group when just one child was selected.
        child_files=[x for x in selected if (x.data(0,Qt.UserRole) or {}).get("type")=="file" and x.parent() and x.parent() not in groups]
        for g in groups:
            idx=self.tree.indexOfTopLevelItem(g)
            if idx<0:continue
            children=[]
            while g.childCount():children.append(g.takeChild(0))
            self.tree.takeTopLevelItem(idx)
            for n,ch in enumerate(children):self.tree.insertTopLevelItem(idx+n,ch)
        # Process per parent, inserting detached files immediately after that group.
        by_parent={}
        for it in child_files:by_parent.setdefault(it.parent(),[]).append(it)
        for parent,items in list(by_parent.items()):
            idx=self.tree.indexOfTopLevelItem(parent)
            if idx<0:continue
            ordered=[parent.child(i) for i in range(parent.childCount()) if parent.child(i) in items]
            for it in ordered:parent.takeChild(parent.indexOfChild(it))
            insert_at=idx+1
            for n,it in enumerate(ordered):self.tree.insertTopLevelItem(insert_at+n,it)
        self._remove_empty_groups(); self._apply_merge_auto_order(); self.update_status(); self.save_session()

    def rename_selected(self):
        if getattr(self,"_output_in_progress",False): return
        items=self.tree.selectedItems()
        if len(items)!=1:return
        it=items[0]; d=it.data(0,Qt.UserRole) or {}
        if d.get("type")!="group":return
        name,ok=QInputDialog.getText(self,"グループ名変更","グループ名:",text=it.text(0))
        if ok and name.strip():
            it.setText(0,name.strip()); d["name"]=name.strip(); it.setData(0,Qt.UserRole,d); self.save_session()

    def remove_selected(self):
        if getattr(self,"_output_in_progress",False): return
        for x in list(self.tree.selectedItems()):
            par=x.parent()
            if par:par.removeChild(x)
            else:
                idx=self.tree.indexOfTopLevelItem(x)
                if idx>=0:self.tree.takeTopLevelItem(idx)
        self._remove_empty_groups(); self.update_status(); self.save_session()

    def toggle_selected_output(self):
        if getattr(self,"_output_in_progress",False): return
        """Toggle runtime output targets. This intentionally does not save check states."""
        items=self.tree.selectedItems()
        if not items:return
        target=Qt.Unchecked if all(x.checkState(0)==Qt.Checked for x in items) else Qt.Checked
        self._syncing_checks=True
        try:
            touched_groups=set()
            for x in items:
                x.setCheckState(0,target)
                d=x.data(0,Qt.UserRole) or {}
                if d.get("type")=="group":
                    for i in range(x.childCount()):x.child(i).setCheckState(0,target)
                    touched_groups.add(x)
                elif x.parent():
                    touched_groups.add(x.parent())
            for g in touched_groups:self._refresh_group_check_state(g)
        finally:
            self._syncing_checks=False
        self.update_status()

    def _selected_file_items(self):
        return [x for x in self.tree.selectedItems() if (x.data(0,Qt.UserRole) or {}).get("type")=="file"]

    def _plot_presets(self):
        return self.store.data.get("plot",[])

    def manual_set_plot(self):
        if getattr(self,"_output_in_progress",False): return
        items=self._selected_file_items()
        if not items:
            QMessageBox.information(self,"印刷設定","ファイルを選択してください。"); return
        menu=QMenu(self)
        actions=[]
        for p in self._plot_presets():
            a=menu.addAction(p.get("name","")); actions.append((a,p))
        if not actions:return
        act=menu.exec(QCursor.pos())
        pp=next((p for a,p in actions if a==act),None)
        if not pp:return
        for it in items:
            d=it.data(0,Qt.UserRole) or {}
            d["manual_plot_id"]=pp.get("id"); d["manual_plot_name"]=pp.get("name"); d.pop("manual",None)
            it.setData(0,Qt.UserRole,d); self._apply_assignment_to_item(it)
        self.update_status(); self.save_session()

    def return_auto_plot(self):
        if getattr(self,"_output_in_progress",False): return
        items=self._selected_file_items()
        for it in items:
            d=it.data(0,Qt.UserRole) or {}
            d.pop("manual_plot_id",None); d.pop("manual_plot_name",None)
            it.setData(0,Qt.UserRole,d)
        self.rejudge_items(items)

    def rejudge_items(self,items=None):
        items=items or self._selected_file_items()
        for it in items:self._apply_assignment_to_item(it)
        self._apply_auto_order_to_tree(); self.update_status(); self.save_session()

    def show_assignment_details(self):
        items=self._selected_file_items()
        if len(items)!=1:
            QMessageBox.information(self,"判定内容","CADファイルを1件選択してください。"); return
        it=items[0]; result=self._resolve_item_assignment(it); rr=result.get("rule"); pp=result.get("plot")
        lines=[Path(self.item_path(it)).name,""]
        if result.get("source")=="manual":
            lines += ["判定: 手動指定",f"印刷設定: {pp.get('name','') if pp else '⚠ 削除された設定'}"]
        elif result.get("source")=="rule":
            lines += [f"プリセット集: {self.current_collection().get('name','')}",f"名前ルール: {rr.get('name','')}",f"優先順位: {result.get('priority')}",f"印刷設定: {pp.get('name','')}","","一致条件:"]
            relation=rr.get("relation","AND"); conds=rr.get("conditions") or [rr]
            for c in conds: lines.append(f"・{c.get('mode','含む')} 「{c.get('value','')}」")
            if len(conds)>1: lines.append(f"条件の組み合わせ: {relation}")
        elif result.get("source")=="default":
            lines += [f"プリセット集: {self.current_collection().get('name','')}","名前ルール: 一致なし",f"印刷設定: {pp.get('name','')}","判定: 『一致しない場合』の既定設定"]
        else:
            lines += ["判定: 未判定","一致する名前ルール・既定印刷設定がありません。"]
        QMessageBox.information(self,"判定内容を確認","\n".join(lines))

    def file_context_menu(self,pos):
        it=self.tree.itemAt(pos)
        if it and not it.isSelected():
            self.tree.clearSelection(); it.setSelected(True)
        menu=QMenu(self)
        a_group=menu.addAction("グループ化  Ctrl+G")
        a_ungroup=menu.addAction("グループ解除  Ctrl+Shift+G")
        a_rename=menu.addAction("グループ名変更  F2")
        menu.addSeparator()
        a_manual=menu.addAction("🔒 印刷設定を手動指定")
        a_auto=menu.addAction("↺ 自動判定へ戻す")
        a_rejudge=menu.addAction("🔄 再判定")
        a_detail=menu.addAction("🔎 判定内容を確認")
        menu.addSeparator()
        a_open=menu.addAction("📄 ファイルを開く")
        a_folder=menu.addAction("📁 フォルダを開く")
        a_relink=menu.addAction("🔗 見つからないファイルを再リンク")
        menu.addSeparator()
        a_remove=menu.addAction("削除")
        act=menu.exec(self.tree.viewport().mapToGlobal(pos))
        if act==a_group:self.group_selected()
        elif act==a_ungroup:self.ungroup_selected()
        elif act==a_rename:self.rename_selected()
        elif act==a_manual:self.manual_set_plot()
        elif act==a_auto:self.return_auto_plot()
        elif act==a_rejudge:self.rejudge_items()
        elif act==a_detail:self.show_assignment_details()
        elif act==a_open:
            items=self._selected_file_items()
            if items: QDesktopServices.openUrl(QUrl.fromLocalFile(self.item_path(items[0])))
        elif act==a_folder:
            items=self._selected_file_items()
            if items: QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self.item_path(items[0])).parent)))
        elif act==a_relink:self.relink_missing_files()
        elif act==a_remove:self.remove_selected()

    def _preflight_dialog(self,pdf_jobs,print_jobs):
        # Step35: 起動時/出力前にAutoCADを無理に起動せず、保存済み環境キャッシュで軽量検証する。
        env=self.store.load_environment()
        report=build_report(pdf_jobs,print_jobs,env)
        if report.fatal:
            lines=[f"✕ {x.message}" for x in report.fatal]
            QMessageBox.critical(self,"出力前チェック","\n".join(lines)+"\n\n出力を開始できません。")
            return None

        blocked=report.blocked_sources()
        valid_pdf=[j for j in pdf_jobs if str(j.get("source","")) not in blocked]
        valid_print=[j for j in print_jobs if str(j.get("source","")) not in blocked]
        file_errors=report.file_errors
        # Existing-file decisions are handled once by the overwrite/skip dialog.
        warnings=[x for x in report.warnings if not (x.kind=="PDF" and x.message.startswith("同名PDFが既に存在します:"))]
        physical=len(valid_print)
        confirm_physical=bool(self.store.config.get("confirm_physical_print",True))

        # 問題なしの場合、PDFのみ、または物理印刷確認OFFなら即実行。
        if not file_errors and not warnings and (not physical or not confirm_physical):
            return valid_pdf,valid_print

        lines=[]
        if file_errors:
            lines.append(f"出力可能: {len({str(j.get('source','')) for j in valid_pdf+valid_print})}ファイル")
            lines.append(f"出力不可: {len(blocked)}ファイル")
            lines.append("")
            for x in file_errors[:30]: lines.append(f"✕ {x.name}: {x.message}")
            if len(file_errors)>30: lines.append(f"…ほか {len(file_errors)-30}件")
        if warnings:
            if lines: lines.append("")
            for x in warnings[:20]: lines.append(f"⚠ {x.name}: {x.message}")
            if len(warnings)>20: lines.append(f"…ほか {len(warnings)-20}件")
        if physical:
            if lines: lines.append("")
            by_device={}
            total_copies=0
            for j in valid_print:
                st=j.get("settings") or {}; dev=str(st.get("device") or "DWG設定"); copies=max(1,int(st.get("copies",1)))
                by_device.setdefault(dev,[0,0]); by_device[dev][0]+=1; by_device[dev][1]+=copies; total_copies+=copies
            lines.append(f"物理プリンター出力: {physical}図面 / 合計{total_copies}部")
            for dev,(n,c) in by_device.items(): lines.append(f"  {dev}: {n}図面 / {c}部")

        if not valid_pdf and not valid_print:
            QMessageBox.critical(self,"出力前チェック","\n".join(lines)+"\n\n出力可能なファイルがありません。")
            return None

        text="\n".join(lines)
        if file_errors:
            text += f"\n\n問題のある{len(blocked)}ファイルを除外して続行しますか？"
        elif physical:
            text += "\n\nこの内容で出力しますか？"
        else:
            text += "\n\n警告があります。このまま続行しますか？"
        ans=QMessageBox.warning(self,"出力前チェック",text,QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        return (valid_pdf,valid_print) if ans==QMessageBox.Yes else None

    def _find_item_by_source(self, source):
        key=str(Path(source)).casefold()
        return next((x for x in self.all_file_items() if str(Path(self.item_path(x))).casefold()==key),None)

    def _set_item_run_state(self, source, state, message=""):
        it=self._find_item_by_source(source)
        if not it: return
        marks={"running":"● 出力中","success":"✓","error":"✕","skipped":"－","pending":""}
        it.setText(4,marks.get(state,state)); it.setToolTip(4,message or "")
        if state=="running": self.tree.scrollToItem(it,QAbstractItemView.PositionAtCenter)

    def _set_output_running(self, running, total=0):
        self._output_in_progress=running
        self.tree.setEnabled(not running)
        self.setAcceptDrops(not running)
        self.progress_panel.setVisible(running)
        self.cancel_output_btn.setVisible(running)
        self.cancel_output_btn.setEnabled(running)
        self.tree.setDragDropMode(QAbstractItemView.NoDragDrop if running else QAbstractItemView.InternalMove)
        for w in self._output_lock_widgets: w.setEnabled(not running)
        if running:
            self.open_output_folder_btn.setVisible(False); self._last_output_folders=[]
            self.cancel_output_btn.setText("■ 中止")
            self._output_cancel_requested=False; self._output_started_at=time.monotonic()
            self.progress_bar.setRange(0,max(1,total)); self.progress_bar.setValue(0)
            self.progress_text.setText(f"出力中：0 / {total}"); self.progress_elapsed.setText("経過 00:00")

    def open_last_output_folder(self):
        folders=[Path(x) for x in getattr(self,"_last_output_folders",[]) if x]
        if not folders:return
        target=folders[0]
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(target)))

    def request_output_cancel(self):
        if self._output_cancel_requested: return
        self._output_cancel_requested=True
        self.cancel_output_btn.setText("中止しています..."); self.cancel_output_btn.setEnabled(False)
        self.progress_text.setText("中止処理中... 現在の安全な区切りで停止します")
        QApplication.processEvents()

    def _update_embedded_progress(self, done, total, label, phase):
        names={"open":"図面を開いています...","plot":"PDFへ出力しています...","print":"印刷しています...","wait_pdf":"PDFの生成・確認を待っています...","done":"完了"}
        done=max(0,min(done,total)); self.progress_bar.setMaximum(max(1,total)); self.progress_bar.setValue(done)
        self.progress_text.setText(f"出力中：{done} / {total}　{label}　{names.get(phase,phase)}")
        sec=int(max(0,time.monotonic()-self._output_started_at)); self.progress_elapsed.setText(f"経過 {sec//60:02d}:{sec%60:02d}")
        QApplication.processEvents()

    def retry_last_output(self, mode="all"):
        data=self.run_history.load(); rec=data.get("last")
        if not rec or not rec.get("jobs"):
            QMessageBox.information(self,"再実行","前回の出力履歴がありません。"); return
        wanted={"failed":{"失敗"}, "pending":{"未処理","中止"}}.get(mode,{"失敗","未処理","中止"})
        targets=[j for j in rec["jobs"] if j.get("status") in wanted]
        if not targets:
            label="失敗" if mode=="failed" else "未処理" if mode=="pending" else "失敗・未処理"
            QMessageBox.information(self,"再実行",f"前回処理に{label}の項目はありません。"); return
        pdf=[];prt=[]
        for j in targets:
            item=next((x for x in self.all_file_items() if self.item_path(x)==j.get("source")),None)
            if not item: continue
            pp=self._resolve_item_assignment(item).get("plot")
            if not pp: continue
            settings=dict(pp); kind=str(j.get("kind",""))
            family,_,layout=kind.partition(":")
            if family not in ("PDF","印刷"): continue
            # A failed layout retries only that layout. The output filename is
            # already expanded in history, so do not append its name a second time.
            settings["layout_mode"]="指定Layout" if layout else "現在のLayout"
            settings["layout_names"]=[layout] if layout else []
            job={"source":j["source"],"settings":settings,"label":Path(j["source"]).name}
            if family=="PDF":
                out=j.get("output") or self.calc_output(item)
                if out:
                    job["output"]=str(out)
                    if layout: job["retry_layout_output"]={layout:str(out)}
                    pdf.append(job)
            else:
                if pp.get("output") in ("PDF＋プリンター","PDF+プリンター") and pp.get("setting_method")!="DWG/DXFに保存されている設定を使用":
                    settings["device"]=str(pp.get("printer_device","")).strip()
                    settings["paper"]=str(pp.get("printer_paper","")).strip() or str(pp.get("paper","")).strip()
                prt.append(job)
        if not pdf and not prt:
            QMessageBox.warning(self,"再実行","現在のリスト/プリセットから再実行対象を復元できませんでした。"); return
        self._execute_output_jobs(pdf,prt,True)

    def _layout_targets(self,src,settings,session=None):
        mode=settings.get("layout_mode","現在のLayout")
        if mode=="現在のLayout": return None
        # Model/explicit Layout names are already known from the preset; do not open
        # the DWG once just to validate and then open it again for output.
        if mode=="Modelのみ": return ["Model"]
        if mode=="指定Layout": return list(settings.get("layout_names",[]) or [])
        rows=list_layouts(src,session=session)
        if mode=="全Layout":
            vals=[x["name"] for x in rows if not x["model"]]
            return vals or [x["name"] for x in rows if x["model"]]
        return []

    def _layout_output_path(self,base,layout):
        p=Path(base)
        from app.output_path import sanitize_filename_component
        safe=sanitize_filename_component(layout).strip() or "Layout"
        return str(p.with_name(f"{p.stem}_{safe}{p.suffix}"))

    def _expand_layout_pdf_jobs(self,pdf_jobs,session=None):
        normal=[]; multi=[]; errors=[]
        for j in pdf_jobs:
            if j["settings"].get("layout_mode","現在のLayout")=="現在のLayout":
                normal.append(j); continue
            try:
                names=self._layout_targets(j["source"],j["settings"],session=session)
                if not names:
                    errors.append(f"{Path(j['source']).name}: 対象Layoutがありません"); continue
                outputs={name:j.get("retry_layout_output",{}).get(name) or self._layout_output_path(j["output"],name) for name in names}
                multi.append(dict(j,layout_names=names,layout_outputs=outputs))
            except Exception as e:
                errors.append(f"{Path(j['source']).name}: Layout取得失敗 - {e}")
        return normal,multi,errors

    def _expand_layout_print_jobs(self,print_jobs,session=None):
        expanded=[]; errors=[]
        for j in print_jobs:
            mode=(j.get("settings") or {}).get("layout_mode","現在のLayout")
            if mode=="現在のLayout":
                expanded.append(j); continue
            try:
                names=self._layout_targets(j["source"],j["settings"],session=session)
                if not names:
                    errors.append(f"{Path(j['source']).name}: 対象Layoutがありません"); continue
                for name in names:
                    jj=dict(j); jj["layout"]=name; jj["label"]=f"{Path(j['source']).name} / {name}"; expanded.append(jj)
            except Exception as e:
                errors.append(f"{Path(j['source']).name}: Layout取得失敗 - {e}")
        return expanded,errors

    def _execute_output_jobs(self,pdf_jobs,print_jobs,is_retry=False):
        # RC14: Adobe PDF のドライバー設定は AutoCAD 起動前に補正する。
        # Adobe 側が設定を起動時にキャッシュする環境でも反映されるようにするため。
        adobe_devices=[]
        for j in list(pdf_jobs) + list(print_jobs):
            st=j.get("settings") or {}
            if st.get("setting_method") == "DWG/DXFに保存されている設定を使用":
                continue
            dev=str(st.get("device","") or "").strip()
            if dev and is_adobe_pdf_device(dev) and dev.casefold() not in {x.casefold() for x in adobe_devices}:
                adobe_devices.append(dev)
        for dev in adobe_devices:
            # RC21: machine-wide registry access is optional. A failed update
            # does not tell us whether the user's printer preference is OFF.
            # Use the existing Adobe PDF settings and judge the actual output.
            ensure_adobe_pdf_document_fonts(dev)

        conn_opts={"prefer_running":False,"dedicated_hidden":True,
                   "selected_year":str(self.store.config.get("autocad_version","自動")),
                   "shared_plot_resources_enabled":bool(self.store.config.get("shared_plot_resources_enabled",False)),
                   "shared_pc3_path":self.store.config.get("shared_pc3_path",""),
                   "shared_plot_style_path":self.store.config.get("shared_plot_style_path",""),
                   "adobe_pdf_watch_dir":self.store.config.get("adobe_pdf_watch_dir",""),
                   "adobe_pdf_timeout":normalize_timeout(self.store.config.get("adobe_pdf_timeout",120))}
        acad_session=None
        # Only multi-layout expansion needs AutoCAD before preflight. When needed, open
        # one hidden dedicated session here and keep THE SAME session through plotting.
        needs_layout_scan=any((j.get("settings") or {}).get("layout_mode","現在のLayout")=="全Layout" for j in (list(pdf_jobs)+list(print_jobs)))
        try:
            if needs_layout_scan:
                acad_session=AutoCADBatchSession(conn_opts); acad_session.open()
            normal_pdf,multi_pdf,layout_errors=self._expand_layout_pdf_jobs(pdf_jobs,session=acad_session)
            print_jobs,print_layout_errors=self._expand_layout_print_jobs(print_jobs,session=acad_session)
            layout_errors.extend(print_layout_errors)
        except Exception as e:
            if acad_session is not None:
                try: acad_session.close()
                except Exception: pass
            QMessageBox.critical(self,"Layout確認",str(e)); return
        if layout_errors:
            if acad_session is not None:
                try: acad_session.close()
                except Exception: pass
            QMessageBox.critical(self,"Layout確認","\n".join("・"+x for x in layout_errors)); return
        preflight_pdf=list(normal_pdf)
        for j in multi_pdf:
            for name,out in j["layout_outputs"].items():
                preflight_pdf.append({"source":j["source"],"output":out,"settings":j["settings"],
                                      "label":f"{Path(j['source']).name} / {name}"})
        checked=self._preflight_dialog(preflight_pdf,print_jobs)
        if checked is None:
            if acad_session is not None:
                try: acad_session.close()
                except Exception: pass
            return
        checked_pdf,print_jobs=checked
        allowed={(str(j.get("source","")),str(j.get("output",""))) for j in checked_pdf}
        normal_pdf=[j for j in normal_pdf if (str(j.get("source","")),str(j.get("output",""))) in allowed]
        filtered_multi=[]
        for j in multi_pdf:
            outputs={name:out for name,out in j["layout_outputs"].items() if (str(j.get("source","")),str(out)) in allowed}
            if outputs:
                jj=dict(j); jj["layout_outputs"]=outputs; jj["layout_names"]=[x for x in j["layout_names"] if x in outputs]; filtered_multi.append(jj)
        multi_pdf=filtered_multi

        # Step36: resolve existing final PDFs once, before AutoCAD plotting.
        finals=[str(j["output"]) for j in normal_pdf]
        finals += [str(out) for j in multi_pdf for out in j["layout_outputs"].values()]
        # Merge outputs participate in the same overwrite/skip decision as individual PDFs.
        outputs_by_source={}
        for job in preflight_pdf:
            outputs_by_source.setdefault(job["source"],[]).append(job["output"])
        preliminary_merge_plans=self._merge_plan(only_existing=False,outputs_by_source=outputs_by_source)
        merge_final_keys={str(Path(x["output"])).casefold() for x in preliminary_merge_plans}
        finals += [x["output"] for x in preliminary_merge_plans]
        action=self.store.config.get("existing_pdf_action","確認する")
        existing=existing_outputs(finals)
        if existing and action=="確認する":
            shown="\n".join("・"+str(Path(x)) for x in existing[:12])
            if len(existing)>12: shown+=f"\n…ほか {len(existing)-12}件"
            box=QMessageBox(self); box.setWindowTitle("既存PDF")
            box.setText(f"既存PDFが {len(existing)}件あります。\n\n{shown}")
            overwrite_btn=box.addButton("すべて上書き",QMessageBox.AcceptRole)
            skip_btn=box.addButton("すべてスキップ",QMessageBox.DestructiveRole)
            box.addButton("キャンセル",QMessageBox.RejectRole); box.exec()
            if box.clickedButton() is overwrite_btn: action="上書きする"
            elif box.clickedButton() is skip_btn: action="スキップする"
            else:
                if acad_session is not None:
                    try: acad_session.close()
                    except Exception: pass
                return
        skip_keys={str(Path(x)).casefold() for x in existing} if action=="スキップする" else set()
        skipped_merge_keys=merge_final_keys & skip_keys
        normal_pdf=[j for j in normal_pdf if str(Path(j["output"])).casefold() not in skip_keys]
        fm=[]
        for j in multi_pdf:
            outputs={n:o for n,o in j["layout_outputs"].items() if str(Path(o)).casefold() not in skip_keys}
            if outputs:
                jj=dict(j); jj["layout_outputs"]=outputs; jj["layout_names"]=[n for n in j["layout_names"] if n in outputs]; fm.append(jj)
        multi_pdf=fm

        pdf_session=PdfOutputSession()
        staged_normal=[]; staged_multi=[]; final_by_temp={}; rotate_by_temp={}; job_by_temp={}
        for j in normal_pdf:
            st=pdf_session.stage(j["source"],j["output"],j.get("label","")); jj=dict(j); jj["output"]=st.temp_path
            job_by_temp[st.temp_path]=(j["source"],"")
            final_by_temp[st.temp_path]=st.final_path; rotate_by_temp[st.temp_path]=bool((j.get("settings") or {}).get("rotate_a3_a1_landscape",False)); staged_normal.append(jj)
        for j in multi_pdf:
            jj=dict(j); outs={}
            for name,out in j["layout_outputs"].items():
                st=pdf_session.stage(j["source"],out,f"{Path(j['source']).name} / {name}"); outs[name]=st.temp_path; final_by_temp[st.temp_path]=st.final_path; rotate_by_temp[st.temp_path]=bool((j.get("settings") or {}).get("rotate_a3_a1_landscape",False))
                job_by_temp[st.temp_path]=(j["source"],name)
            jj["layout_outputs"]=outs; staged_multi.append(jj)

        total=len(staged_normal)+sum(len(j["layout_names"]) for j in staged_multi)+len(print_jobs)
        records=[{"source":j["source"],"kind":"PDF","output":final_by_temp.get(j.get("output",""),j.get("output",""))} for j in staged_normal]
        for j in staged_multi:
            for name,out in j["layout_outputs"].items(): records.append({"source":j["source"],"kind":"PDF:"+name,"output":final_by_temp.get(out,out)})
        records += [{"source":j["source"],"kind":("印刷:"+j.get("layout","") if j.get("layout") else "印刷"),"output":""} for j in print_jobs]
        rec=self.run_history.begin(records)
        self._set_output_running(True,total); offset=[0]
        for j in records: self._set_item_run_state(j["source"],"pending")
        def cb(i,n,label,phase):
            done=offset[0]+(i if phase=="done" else max(0,i-1))
            source=next((r["source"] for r in records if Path(r["source"]).name==label or label.startswith(Path(r["source"]).name)),None)
            if source: self._set_item_run_state(source,"running")
            self._update_embedded_progress(done,total,label,phase)
        pdfres=[]; printres=[]; committed=[];committed_temps=set()
        def retain_generated(temp, result=None):
            if temp not in final_by_temp or temp in committed_temps:
                return None
            try:
                recovery=pdf_session.retain_failed(temp,APP_DIR/"data"/"recovery")
            except FileNotFoundError:
                return None
            if result is not None:
                result["recovery"]=recovery
                note=f"生成ファイルの保全先: {recovery}"
                if note not in result.get("message",""):
                    result["message"]=(result.get("message","")+"\n" if result.get("message") else "")+note
                    result.setdefault("trace",[]).append(note)
            return recovery
        try:
            if (staged_normal or staged_multi or print_jobs) and acad_session is None:
                acad_session=AutoCADBatchSession(conn_opts); acad_session.open()
            source_order={self.item_path(it):i for i,it in enumerate(self.all_file_items())}
            actions=[("PDF",j) for j in staged_normal]+[("LAYOUT",j) for j in staged_multi]+[("PRINT",j) for j in print_jobs]
            actions.sort(key=lambda action:source_order.get(action[1]["source"],len(source_order)))
            for kind,job in actions:
                if self._output_cancel_requested or any(x.get("status")=="fatal" for x in pdfres+printres): break
                cb(1,1,job.get("label",Path(job["source"]).name),"open")
                if self._output_cancel_requested: break
                if kind=="PDF":
                    res=plot_batch_pdf([job],progress=cb,should_cancel=lambda:self._output_cancel_requested,connection_options=conn_opts,session=acad_session)
                    pdfres.extend(res); offset[0]+=1
                elif kind=="LAYOUT":
                    try:
                        res=plot_layouts_pdf(job["source"],job["layout_outputs"],job["settings"],job["layout_names"],progress=cb,should_cancel=lambda:self._output_cancel_requested,connection_options=conn_opts,session=acad_session)
                    except Exception as exc:
                        from app.autocad_backend import _looks_like_connection_loss
                        res=[{"source":job["source"],"layout":name,"status":"fatal" if _looks_like_connection_loss(exc) else "error","message":str(exc)} for name in job["layout_names"]]
                    pdfres.extend(res); offset[0]+=len(job["layout_names"])
                else:
                    printres.extend(print_batch([job],progress=cb,should_cancel=lambda:self._output_cancel_requested,connection_options=conn_opts,session=acad_session))
                    offset[0]+=1
            # Commit only PDFs generated successfully in THIS run. Existing finals stay untouched on failure/cancel.
            for x in pdfres:
                if x.get("status")!="ok":
                    retain_generated(str(x.get("output","")),x)
                    continue
                tmp=str(x.get("output", "")); final=final_by_temp.get(tmp)
                if not final: continue
                try:
                    if rotate_by_temp.get(tmp,False):
                        rotated_pages=rotate_a3_a1_left_to_landscape(tmp)
                        if rotated_pages:
                            x["message"]=(x.get("message","")+" / " if x.get("message") else "")+"A3/A1を左90°回転: "+", ".join(f"{r['size']} p{r['page']}" for r in rotated_pages)
                    x["output"]=pdf_session.atomic_commit(tmp,final); committed.append(final);committed_temps.add(tmp)
                except Exception as e:
                    x["status"]="error"; x["message"]="PDF確定失敗: "+str(e)
                    retain_generated(tmp,x)
            # A COM error after generation may omit output from its result.
            # Check every staged job before cleanup, independently of that field.
            for temp,(source,layout) in job_by_temp.items():
                if temp in committed_temps:
                    continue
                matching=[x for x in pdfres if x.get("source")==source and x.get("layout","")==layout]
                result=next((x for x in matching if x.get("status")!="ok"),None)
                if result is None:
                    result={"source":source,"layout":layout,"status":"error","output":temp,
                            "message":"生成PDFを最終保存先に確定できませんでした。"}
                    if retain_generated(temp,result):
                        pdfres.append(result)
                else:
                    retain_generated(temp,result)
            # History after commit, so a failed final replacement is not reported as success.
            for x in pdfres:
                kind="PDF:"+x.get("layout","") if x.get("layout") else "PDF"
                st={"ok":"成功","cancelled":"中止","unprocessed":"未処理"}.get(x["status"],"失敗")
                self.run_history.update(rec,x["source"],kind,st,x.get("message",""),trace=x.get("trace"))
                self._set_item_run_state(x["source"],"success" if st=="成功" else "pending" if st=="中止" else "error",x.get("message",""))
            for x in printres:
                st={"ok":"成功","cancelled":"中止","unprocessed":"未処理"}.get(x["status"],"失敗")
                kind=("印刷:"+x.get("layout","") if x.get("layout") else "印刷")
                self.run_history.update(rec,x["source"],kind,st,x.get("message",""),trace=x.get("trace"))
            # One source can have mixed outcomes. Never hide one failed layout
            # behind a successful later layout or printer job.
            for source in dict.fromkeys(j["source"] for j in rec["jobs"]):
                rows=[j for j in rec["jobs"] if j["source"]==source]
                statuses={j["status"] for j in rows}
                state="error" if "失敗" in statuses else "pending" if statuses & {"未処理","中止"} else "success"
                self._set_item_run_state(source,state,"\n".join(j["kind"]+": "+j["status"]+(" / "+j["message"] if j["message"] else "") for j in rows))
        except Exception as e:
            message=str(e);recovered=[]
            for temp in final_by_temp:
                try:
                    path=retain_generated(temp)
                    if path and path not in recovered: recovered.append(path)
                except Exception as preserve_exc:
                    message+=f"\n生成ファイルの保全失敗: {preserve_exc}"
            if recovered:
                message+="\n\n生成ファイルの保全先:\n"+"\n".join(recovered)
            try: self.run_history.finish(rec)
            except Exception as history_exc: message+=f"\n出力履歴の保存失敗: {history_exc}"
            self._set_output_running(False)
            QMessageBox.critical(self,"出力エラー",message); return
        finally:
            if acad_session is not None:
                try: acad_session.close()
                except Exception: pass
            pdf_session.cleanup()
        self.run_history.finish(rec); self._set_output_running(False)

        # Merge only when every checked PDF member of a group was generated successfully this run.
        committed_keys={str(Path(x)).casefold() for x in committed}
        merge_plans=[]
        for plan in preliminary_merge_plans:
            if str(Path(plan["output"])).casefold() in skipped_merge_keys:
                continue
            if plan["inputs"] and all(str(Path(x)).casefold() in committed_keys for x in plan["inputs"]):
                merge_plans.append(plan)
        merge_ok=[]; merge_err=[]
        if merge_plans and not self._output_cancel_requested: merge_ok,merge_err=self._execute_merge_plans(merge_plans)
        allres=pdfres+printres
        ok=sum(x["status"]=="ok" for x in allres); err=[x for x in allres if x.get("status") in ("error","fatal")]
        pending=sum(j["status"] in ("未処理","中止") for j in rec["jobs"])
        skipped=len(skip_keys)
        summary=f"成功 {ok} / 失敗 {len(err)} / スキップ {skipped} / 未処理 {pending}"
        final_outputs=[str(Path(x)) for x in committed if Path(x).exists()]
        final_outputs += [str(Path(x["output"])) for x in merge_ok if Path(x.get("output","")).exists()]
        folders=[]
        for outp in final_outputs:
            folder=str(Path(outp).parent)
            if folder.casefold() not in {x.casefold() for x in folders}: folders.append(folder)
        self._last_output_folders=folders
        location=(folders[0] if len(folders)==1 else (f"{len(folders)}か所" if folders else ""))
        suffix=(f" ｜ 保存先: {location}" if location else "")
        self.status.setText(("⚠ 出力完了 ｜ " if err or pending or merge_err else "✓ 出力完了 ｜ ")+summary+suffix)
        self.progress_panel.setVisible(True); self.progress_bar.setMaximum(max(1,total)); self.progress_bar.setValue(total-pending)
        self.progress_text.setText(("⚠ 出力完了　" if err or pending or merge_err else "✓ 出力完了　")+summary+(f"　保存先: {location}" if location else ""))
        self.open_output_folder_btn.setVisible(bool(folders))
        self.open_output_folder_btn.setToolTip("\n".join(folders))
        sec=int(max(0,time.monotonic()-self._output_started_at)); self.progress_elapsed.setText(f"経過 {sec//60:02d}:{sec%60:02d}")
        self.cancel_output_btn.setVisible(False); self.cancel_output_btn.setText("■ 中止")
        if err or merge_err:
            details=[]
            for x in err[:12]:
                details.append(f"・{Path(x.get('source','')).name}: {x.get('message','出力に失敗しました。')}")
            for plan,msg in merge_err[:8]:
                details.append(f"・PDF結合 {plan.get('group','')}: {msg}")
            planned=sorted({str(Path(x)) for x in finals if str(x)})
            text=summary+"\n\n"+"\n".join(details)
            if planned:
                text += "\n\n予定されていたPDF保存先:\n"+"\n".join("・"+x for x in planned[:10])
            QMessageBox.warning(self,"出力結果",text)

    def run_batch_output(self):
        if getattr(self,"_output_in_progress",False): return
        col=self.current_collection(); pdf_jobs=[]; print_jobs=[]; problems=[]; seen={}
        for it in self.all_file_items():
            if it.checkState(0)!=Qt.Checked: continue
            src=self.item_path(it)
            d=it.data(0,Qt.UserRole) or {}
            result=self._resolve_item_assignment(it); pp=result.get("plot")
            if not pp:
                problems.append(f"{Path(src).name}: 印刷設定が未判定"); continue
            mode=pp.get("output","PDF")
            if mode in ("PDF","PDF＋プリンター","PDF+プリンター"):
                out=self.calc_output(it)
                if not out: problems.append(f"{Path(src).name}: PDF出力先不明")
                else:
                    key=str(out).casefold()
                    if key in seen: problems.append(f"{Path(src).name}: PDF名重複 → {out}")
                    seen[key]=src
                    pdf_jobs.append({"source":src,"output":str(out),"settings":pp,"label":Path(src).name})
            if mode in ("プリンター","PDF＋プリンター","PDF+プリンター"):
                pst=dict(pp)
                # プリンター専用は従来device/paperを使用。PDF＋プリンターだけ専用の物理出力先へ切替。
                if mode in ("PDF＋プリンター","PDF+プリンター") and pp.get("setting_method") != "DWG/DXFに保存されている設定を使用":
                    pst["device"]=str(pp.get("printer_device","")).strip()
                    pst["paper"]=str(pp.get("printer_paper","")).strip() or str(pp.get("paper","")).strip()
                if pst.get("setting_method") != "DWG/DXFに保存されている設定を使用" and not pst.get("device"):
                    problems.append(f"{Path(src).name}: 物理プリンター未設定")
                else:
                    print_jobs.append({"source":src,"settings":pst,"label":Path(src).name})
        if problems:
            # 問題のある図面だけ除外し、正常な図面は継続できる。
            # ここで全体停止すると Step35/53 の「ファイル単位エラー」方針と矛盾する。
            if not pdf_jobs and not print_jobs:
                QMessageBox.warning(self,"出力前チェック","出力可能な図面がありません。\n\n"+"\n".join("・"+x for x in problems)); return
            text="一部の図面は出力対象から除外されます。\n\n"+"\n".join("・"+x for x in problems[:30])
            if len(problems)>30: text+=f"\n…ほか {len(problems)-30}件"
            text+="\n\n正常な図面だけ続行しますか？"
            if QMessageBox.warning(self,"出力前チェック",text,QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:
                return
        if not pdf_jobs and not print_jobs:
            QMessageBox.information(self,"出力開始","出力対象がありません。"); return
        self._execute_output_jobs(pdf_jobs,print_jobs,False)

    def test_single_pdf(self):
        items=[x for x in self.tree.selectedItems() if (x.data(0,Qt.UserRole) or {}).get("type")=="file"]
        if len(items)!=1:
            QMessageBox.information(self,"PDFテスト出力","ファイルを1件だけ選択してください。")
            return
        it=items[0]; result=self._resolve_item_assignment(it); pp=result.get("plot")
        if not pp:
            QMessageBox.warning(self,"PDFテスト出力","印刷設定が確定していません。")
            return
        out=self.calc_output(it)
        if not out:
            QMessageBox.warning(self,"PDFテスト出力","PDF出力先を計算できません。")
            return
        msg=(f"CAD: {self.item_path(it)}\n印刷設定: {pp['name']}\nPDF: {out}\n\n"
             "元図面は保存せず閉じます。実行しますか？")
        if QMessageBox.question(self,"1件PDFテスト",msg,QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:
            return
        try:
            res=plot_single_pdf(self.item_path(it),out,pp)
            QMessageBox.information(self,"PDFテスト出力",f"完了しました。\n\n{res['output']}")
        except Exception as e:
            QMessageBox.critical(self,"PDFテスト出力エラー",
                                 f"{e}\n\nAutoCADは自動起動しません。先にAutoCADを起動してください。")

    def inspect_layouts(self):
        items=self._selected_file_items()
        if len(items) != 1:
            QMessageBox.information(self,"Layout確認","CADファイルを1件選択してください。")
            return
        src=self.item_path(items[0])
        try:
            rows=list_layouts(src)
            text="\\n".join(("Model" if x.get("model") else "Layout")+" : "+str(x.get("name","")) for x in rows)
            QMessageBox.information(self,"Layout確認",f"{Path(src).name}\\n\\n{text or 'Layoutがありません。'}")
        except Exception as e:
            QMessageBox.critical(self,"Layout確認",str(e))

    def save_settings_to_dwg(self):
        items=self._selected_file_items()
        if not items:
            QMessageBox.information(self,"DWGへ設定","設定を書き込むCADファイルを選択してください。")
            return
        if QMessageBox.question(
            self,"DWGへ設定",
            f"{len(items)}件の元CADファイルを変更します。\\n変更前に各CADと同じ場所の bak フォルダへバックアップします。\\n\\n続行しますか？",
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No
        ) != QMessageBox.Yes:
            return
        plots={x.get("id"):x for x in self.store.data.get("plot",[])}
        ok=[]; ng=[]
        for it in items:
            d=it.data(0,Qt.UserRole) or {}
            pid=d.get("manual_plot_id") or d.get("plot_id")
            p=plots.get(pid)
            if not p:
                # Fall back to the plot preset name currently displayed in the list.
                pname=it.text(2)
                p=next((x for x in plots.values() if x.get("name")==pname),None)
            if not p:
                ng.append(f"{Path(self.item_path(it)).name}: 印刷設定がありません")
                continue
            src=self.item_path(it)
            try:
                bak=Path(src).parent/"bak"
                save_page_setup(src,p,setup_name="ACadPresetter_"+p.get("name","Plot"),backup_dir=bak,connection_options={"selected_year":str(self.store.config.get("autocad_version","自動"))})
                ok.append(Path(src).name)
            except Exception as e:
                ng.append(f"{Path(src).name}: {e}")
        msg=f"成功: {len(ok)}件"
        if ng: msg += f"\\n失敗: {len(ng)}件\\n\\n" + "\\n".join(ng[:20])
        QMessageBox.information(self,"DWGへ設定",msg)

    def show_app_settings(self):
        """アプリ/PC固有設定。プリセット内容はここでは編集しない。"""
        cfg = dict(self.store.config or self.store.load_config())
        dlg=QDialog(self); dlg.setWindowTitle("ACadPresetter 設定"); dlg.resize(650,520)
        v=QVBoxLayout(dlg); tabs=QTabWidget(); v.addWidget(tabs,1)

        # --- 基本 ---------------------------------------------------------
        p1=QWidget(); f1=QFormLayout(p1)
        group=QComboBox(); group.addItems(["確認する","自動で1グループにする","個別に追加する"])
        old_group=cfg.get("drop_group_mode","ask")
        group_map={"ask":"確認する","group":"自動で1グループにする","individual":"個別に追加する",
                   "常にグループ化":"自動で1グループにする","グループ化しない":"個別に追加する"}
        group.setCurrentText(group_map.get(old_group, old_group if old_group in [group.itemText(i) for i in range(group.count())] else "確認する"))
        overwrite=QComboBox(); overwrite.addItems(["確認する","上書きする","スキップする"])
        overwrite.setCurrentText(cfg.get("existing_pdf_action","確認する"))
        physical=QCheckBox("物理プリンターへの出力前に確認する"); physical.setChecked(cfg.get("confirm_physical_print",True))
        restore=QCheckBox("前回選んだプリセット集を復元する"); restore.setChecked(cfg.get("restore_session",True))
        folder_group_name=QCheckBox("グループ名にファイルの格納フォルダ名を使用する"); folder_group_name.setChecked(cfg.get("group_name_from_folder",True))
        expand_groups=QCheckBox("グループ追加時に展開する"); expand_groups.setChecked(cfg.get("expand_new_groups",True))
        f1.addRow("複数DWG/DXFをD&D",group)
        f1.addRow(folder_group_name); f1.addRow(expand_groups)
        f1.addRow("既存PDF",overwrite)
        f1.addRow(physical); f1.addRow(restore)
        note=QLabel("※ フォルダD&Dはこの設定に関係なく、1フォルダ＝1グループで追加します。")
        note.setWordWrap(True); f1.addRow(note); tabs.addTab(p1,"基本")

        # --- AutoCAD ------------------------------------------------------
        p2=QWidget(); f2=QFormLayout(p2)
        ver=QComboBox(); ver.addItems(["自動","2026","2025"]); ver.setCurrentText(str(cfg.get("autocad_version","自動")))
        env=self.store.load_environment()
        env_status=QLabel()
        def update_env_status(e=None):
            e=e if e is not None else self.store.load_environment()
            if not e:
                env_status.setText("未取得")
                return
            devices=e.get("devices",[]) or [] ; media=e.get("media",[]) or [] ; styles=e.get("styles",[]) or []; dm=e.get("device_media",{}) or {}
            stamp=e.get("captured_at","")
            env_status.setText(f"取得済み  PC3/プリンター {len(devices)}件 / 用紙 {len(media)}種類 / 対応表 {len(dm)}件 / CTB・STB {len(styles)}件" + (f"\n更新: {stamp}" if stamp else ""))
        update_env_status(env)
        b_env=QPushButton("AutoCADから印刷環境を取得")
        def refresh_environment():
            try:
                from datetime import datetime
                e=probe_plot_environment(True, connection_options={
                    "selected_year":ver.currentText(),
                    "shared_plot_resources_enabled":bool(self.store.config.get("shared_plot_resources_enabled",False)),
                    "shared_pc3_path":self.store.config.get("shared_pc3_path",""),
                    "shared_plot_style_path":self.store.config.get("shared_plot_style_path","")})
                e["captured_at"]=datetime.now().strftime("%Y/%m/%d %H:%M:%S")
                self.store.save_environment(e); update_env_status(e)
                problems=[]
                for pp in self.store.data.get("plot",[]):
                    msgs=validate_plot_preset(pp,e)
                    if msgs: problems.append(pp.get("name","(名称なし)")+": "+" / ".join(msgs))
                msg="印刷環境を保存しました。"
                if problems: msg+=f"\n\n既存印刷設定の要確認: {len(problems)}件\n"+"\n".join(problems[:8])
                QMessageBox.information(dlg,"AutoCAD印刷環境",msg)
            except Exception as ex:
                QMessageBox.warning(dlg,"AutoCAD印刷環境",str(ex))
        b_env.clicked.connect(refresh_environment)
        adobe_dir=QLineEdit(str(cfg.get("adobe_pdf_watch_dir","") or "")); adobe_dir.setPlaceholderText("Adobe PDFの自動保存先を指定（Adobe使用時は必須）")
        b_adobe_dir=QPushButton("参照")
        b_adobe_open=QPushButton("開く"); b_adobe_open.setEnabled(bool(adobe_dir.text().strip()))
        def open_adobe_dir():
            try:
                folder=normalize_watch_dir(adobe_dir.text())
                if not folder.is_dir():
                    raise ValueError(f"Adobe PDF生成先フォルダが存在しません: {folder}")
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
            except (ValueError,OSError) as exc:
                QMessageBox.warning(dlg,"Adobe PDF生成先",str(exc))
        b_adobe_open.clicked.connect(open_adobe_dir)
        adobe_dir.textChanged.connect(lambda text: b_adobe_open.setEnabled(bool(text.strip())))
        adobe_row=QWidget(); ah=QHBoxLayout(adobe_row); ah.setContentsMargins(0,0,0,0); ah.setSpacing(6)
        ah.addWidget(adobe_dir,1); ah.addWidget(b_adobe_dir); ah.addWidget(b_adobe_open)
        def pick_adobe_dir():
            try: initial=str(normalize_watch_dir(adobe_dir.text()))
            except (ValueError,OSError): initial=""
            d=QFileDialog.getExistingDirectory(dlg,"Adobe PDFの自動保存先を選択",initial)
            if d: adobe_dir.setText(d)
        b_adobe_dir.clicked.connect(pick_adobe_dir)
        adobe_note=QLabel("Adobe PDF使用時は、プリンター側の自動保存先と同じフォルダを指定してください。保存確認・作成後のPDF表示をOFFにします。最終PDF保存先はプリセットで指定します。")
        adobe_note.setWordWrap(True)
        adobe_timeout=QSpinBox(); adobe_timeout.setObjectName("adobe_pdf_timeout"); adobe_timeout.setRange(30,600); adobe_timeout.setSuffix(" 秒"); adobe_timeout.setFixedWidth(110)
        adobe_timeout.setValue(int(normalize_timeout(cfg.get("adobe_pdf_timeout",120))))
        adobe_timeout.setToolTip("AdobeドライバーによるPDF生成を待つ時間。大きな図面では増やしてください。")
        tools=QWidget(); th=QHBoxLayout(tools); th.setContentsMargins(0,0,0,0)
        b_diag=QPushButton("接続確認"); b_health=QPushButton("診断")
        b_diag.clicked.connect(self.show_autocad_status)
        b_health.clicked.connect(lambda: self.run_diagnostics(config={
            **cfg,"autocad_version":ver.currentText(),
            "adobe_pdf_watch_dir":adobe_dir.text(),"adobe_pdf_timeout":adobe_timeout.value(),
            "shared_plot_resources_enabled":shared_pc3.isChecked(),
            "shared_pc3_path":pc3_path.text(),"shared_plot_style_path":style_path.text()}))
        th.addWidget(b_diag); th.addWidget(b_health); th.addStretch(1)
        f2.addRow("AutoCADバージョン",ver); f2.addRow(QLabel("出力・DWG設定取得には専用の非表示AutoCADを使用します。")); f2.addRow("印刷環境",env_status); f2.addRow(b_env)
        f2.addRow("Adobe PDF生成先",adobe_row); f2.addRow("PDF生成の待機時間",adobe_timeout); f2.addRow(adobe_note); f2.addRow("詳細",tools)
        tabs.addTab(p2,"AutoCAD")

        # --- 共有 ---------------------------------------------------------
        p3=QWidget(); f3=QFormLayout(p3)
        shared=QCheckBox("共有プリセットを使用する"); shared.setChecked(cfg.get("shared_presets_enabled",False))
        shared_path=QLineEdit(cfg.get("shared_presets_path","")); b_shared=QPushButton("参照")
        row=QWidget(); rh=QHBoxLayout(row); rh.setContentsMargins(0,0,0,0); rh.addWidget(shared_path,1); rh.addWidget(b_shared)
        def pick_shared():
            fn,_=QFileDialog.getOpenFileName(dlg,"共有プリセットを選択",shared_path.text() or "","JSON (*.json);;すべて (*.*)")
            if fn: shared_path.setText(fn)
        b_shared.clicked.connect(pick_shared)
        refresh_shared=QPushButton("共有プリセットを更新")
        refresh_shared.setFixedWidth(190)
        shared_status=QLabel("起動時は前回取得した内容を使用します。")
        shared_status.setWordWrap(True)
        def refresh_shared_presets():
            source=shared_path.text().strip()
            if not source:
                shared_status.setText("共有プリセットのファイルまたはフォルダを指定してください。")
                return
            probe=Store(self.store.dir)
            probe.config={**cfg,"shared_presets_enabled":True,"shared_presets_path":source}
            refresh_shared.setEnabled(False)
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                probe.load_presets(refresh_shared=True)
                if probe.shared_load_error:
                    shared_status.setText("更新できませんでした。前回の取得内容を保持しています。\n"+probe.shared_load_error)
                else:
                    count=sum(bool(p.get("_shared")) for rows in probe.data.values() for p in rows)
                    shared_status.setText(f"共有プリセット {count}件を取得しました。「保存」で反映します。")
            except Exception as exc:
                shared_status.setText("更新できませんでした: "+str(exc))
            finally:
                QApplication.restoreOverrideCursor()
                refresh_shared.setEnabled(True)
        refresh_shared.clicked.connect(refresh_shared_presets)
        shared_pc3=QCheckBox("共有PC3 / 印刷スタイルを参照する"); shared_pc3.setChecked(cfg.get("shared_plot_resources_enabled",False))
        pc3_path=QLineEdit(cfg.get("shared_pc3_path","")); style_path=QLineEdit(cfg.get("shared_plot_style_path",""))
        def folder_row(edit):
            w=QWidget(); h=QHBoxLayout(w); h.setContentsMargins(0,0,0,0); b=QPushButton("参照")
            b.clicked.connect(lambda: (lambda d: edit.setText(d) if d else None)(QFileDialog.getExistingDirectory(dlg,"フォルダを選択",edit.text() or "")))
            h.addWidget(edit,1); h.addWidget(b); return w
        f3.addRow(shared); f3.addRow("共有プリセット",row)
        f3.addRow(refresh_shared); f3.addRow(shared_status)
        f3.addRow(shared_pc3); f3.addRow("PC3フォルダ",folder_row(pc3_path)); f3.addRow("印刷スタイル",folder_row(style_path))
        shared_note=QLabel("共有側は読み取り専用として扱います。通常は自分のAutoCAD環境を使用します。")
        shared_note.setWordWrap(True); f3.addRow(shared_note); tabs.addTab(p3,"共有")

        # --- ログ・バックアップ -----------------------------------------
        p4=QWidget(); f4=QFormLayout(p4)
        preset_bak=QCheckBox("プリセット変更時に自動バックアップ"); preset_bak.setChecked(cfg.get("preset_backup_enabled",True))
        retain=QSpinBox(); retain.setRange(1,100); retain.setValue(int(cfg.get("preset_backup_retention",20)))
        log_on=QCheckBox("出力ログを保存する"); log_on.setChecked(cfg.get("log_enabled",True))
        logs=QSpinBox(); logs.setRange(1,365); logs.setValue(int(cfg.get("log_retention_days",30)))
        f4.addRow(preset_bak); f4.addRow("バックアップ保持数",retain); f4.addRow(log_on); f4.addRow("ログ保持日数",logs)
        tabs.addTab(p4,"ログ・バックアップ")

        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); v.addWidget(buttons)
        buttons.button(QDialogButtonBox.Save).setText("保存")
        buttons.button(QDialogButtonBox.Cancel).setText("キャンセル")
        buttons.rejected.connect(dlg.reject)
        def save_settings():
            gm={"確認する":"ask","自動で1グループにする":"group","個別に追加する":"individual"}[group.currentText()]
            cfg.update(
                drop_group_mode=gm, group_name_from_folder=folder_group_name.isChecked(), expand_new_groups=expand_groups.isChecked(),
                existing_pdf_action=overwrite.currentText(), confirm_physical_print=physical.isChecked(),
                restore_session=restore.isChecked(), autocad_version=ver.currentText(),
                adobe_pdf_watch_dir=adobe_dir.text().strip(), adobe_pdf_timeout=adobe_timeout.value(),
                shared_presets_enabled=shared.isChecked(),
                shared_presets_path=shared_path.text().strip(), shared_plot_resources_enabled=shared_pc3.isChecked(),
                shared_pc3_path=pc3_path.text().strip(), shared_plot_style_path=style_path.text().strip(),
                preset_backup_enabled=preset_bak.isChecked(), preset_backup_retention=retain.value(),
                log_enabled=log_on.isChecked(), log_retention_days=logs.value())
            self.store.save_config(cfg)
            self.store.load()
            selected=self.collection.currentData()
            self.collection.blockSignals(True)
            self.collection.clear(); self.collection.addItem("（未選択）",None)
            for preset in self.store.data["collection"]:
                self.collection.addItem(preset["name"],preset["id"])
            self.collection.setCurrentIndex(max(0,self.collection.findData(selected)))
            self.collection.blockSignals(False)
            self.rejudge()
            self.run_history.config=self.store.config
            dlg.accept()
        buttons.accepted.connect(save_settings); dlg.exec()

    def run_diagnostics(self, *, config=None):
        try:
            text=build_diagnostic_report(APP_DIR,self.store.data,detect_status,probe_plot_environment,
                                         config=self.store.config if config is None else config)
            path=save_report(APP_DIR,text)
            box=QMessageBox(self); box.setWindowTitle("環境診断")
            box.setIcon(QMessageBox.Information)
            box.setText("診断が完了しました。\nAutoCADは診断のために自動起動しません。")
            box.setDetailedText(text)
            box.setInformativeText(f"レポート保存先:\n{path}")
            box.exec()
        except Exception as e:
            QMessageBox.critical(self,"環境診断",str(e))

    def show_autocad_status(self):
        dlg=QDialog(self); dlg.setWindowTitle("AutoCAD環境"); dlg.resize(650,460)
        v=QVBoxLayout(dlg)
        info=QPlainTextEdit(); info.setReadOnly(True); v.addWidget(info)
        row=QHBoxLayout()
        b_detect=QPushButton("インストール検出")
        b_connect=QPushButton("起動中AutoCADへ接続")
        b_start=QPushButton("AutoCADを起動して接続")
        b_env=QPushButton("PC3・用紙・CTB取得")
        b_close=QPushButton("閉じる")
        for b in (b_detect,b_connect,b_start,b_env,b_close):row.addWidget(b)
        v.addLayout(row)
        backend={"obj":None,"session":None,"document":None}
        def release_connection():
            if backend["session"] is not None:
                if backend["document"] is not None:
                    try: backend["document"].Close(False)
                    except Exception: pass
                backend["session"].close()
            elif backend["obj"] is not None:
                backend["obj"].disconnect()
            backend.update(obj=None,session=None,document=None)
        def append(t): info.appendPlainText(str(t))
        def detect():
            try:
                r=detect_status(); append("【インストール検出】")
                append(r if r else "AutoCADを検出できませんでした。")
            except Exception as e:append("検出エラー: "+str(e))
        def connect_active():
            try:
                release_connection()
                be=AutoCADBackend(); be.connect(allow_start=False,visible=False); backend["obj"]=be
                append("【接続OK】"); append(be.info())
            except Exception as e:append("接続できません: "+str(e))
        def start_connect():
            try:
                if backend["session"] is None:
                    release_connection()
                    session=AutoCADBatchSession({"selected_year":str(self.store.config.get("autocad_version","自動")),"dedicated_hidden":True})
                    session.open(); backend.update(obj=session.backend,session=session)
                    # An empty owned drawing is enough to enumerate plot resources.
                    if not session.app.Documents.Count:
                        backend["document"]=session.app.Documents.Add()
                    else:
                        backend["document"]=session.app.ActiveDocument
                    session.ensure_hidden()
                append("【非表示で起動・接続OK】"); append(backend["obj"].info())
            except Exception as e:append("起動/接続エラー: "+str(e))
        def environment():
            try:
                be=backend.get("obj")
                if be is None:
                    be=AutoCADBackend(); be.connect(allow_start=False,visible=False); backend["obj"]=be
                env=be.active_plot_environment()
                append("【現在の図面】 "+str(env.get("drawing","")))
                append("【Layout】 "+str(env.get("layout","")))
                append("【PC3/プリンター】\n  "+"\n  ".join(env.get("devices",[]) or ["なし"]))
                append("【用紙】\n  "+"\n  ".join(env.get("media",[]) or ["なし"]))
                append("【CTB/STB】\n  "+"\n  ".join(env.get("styles",[]) or ["なし"]))
            except Exception as e:append("環境取得エラー: "+str(e))
        b_detect.clicked.connect(detect); b_connect.clicked.connect(connect_active)
        b_start.clicked.connect(start_connect); b_env.clicked.connect(environment); b_close.clicked.connect(dlg.accept)
        detect()
        dlg.exec()
        try: release_connection()
        except Exception: pass


    def current_collection(self):
        cid=self.collection.currentData()
        return next((x for x in self.store.data["collection"] if x["id"]==cid),None)

    def group_name_for(self,it):
        p=it.parent()
        if p and (p.data(0,Qt.UserRole) or {}).get("type")=="group":
            return p.text(0).replace("📚 ","")
        return ""

    def calc_output(self,it):
        from datetime import datetime
        src=Path(self.item_path(it)); col=self.current_collection()
        if not col:return None
        dest=next((x for x in self.store.data["dest"] if x["id"]==col.get("dest_id")),None)
        nam=next((x for x in self.store.data["name"] if x["id"]==col.get("name_id")),None)
        if not dest or not nam:return None
        try:
            return build_pdf_path(
                src, dest, nam,
                group_name=self.group_name_for(it),
                plot_name=it.text(2),
                date_text=datetime.now().strftime("%Y%m%d"),
            )
        except (ValueError, OSError):
            return None

    def simulate(self):
        rows=[]; warnings=[]; outputs={}
        for it in self.all_file_items():
            if it.checkState(0)!=Qt.Checked:continue
            out=self.calc_output(it)
            if it.text(4)!="✓": warnings.append(Path(self.item_path(it)).name)
            if out:
                outputs.setdefault(str(out).casefold(),[]).append(Path(self.item_path(it)).name)
            rows.append(f"{Path(self.item_path(it)).name}\n  ルール: {it.text(1)}\n  印刷設定: {it.text(2)}\n  出力: {it.text(3)}\n  PDF: {out if out else '未決定'}")
        msg="\n\n".join(rows) if rows else "出力対象がありません。"
        if warnings: msg += "\n\n⚠ 未判定: " + ", ".join(warnings)
        dup=[v for v in outputs.values() if len(v)>1]
        if dup:
            msg += "\n\n⚠ PDF名重複:\n" + "\n".join(" / ".join(x) for x in dup)
        QMessageBox.information(self,"出力シミュレーション",msg)

    def session_dict(self):
        def node(it):
            d=it.data(0,Qt.UserRole) or {}
            obj={"text":it.text(0),"type":d.get("type"),"expanded":it.isExpanded()}
            if d.get("type")=="file":
                obj.update(path=d.get("path",""),manual_plot_id=d.get("manual_plot_id"))
            else:
                obj["children"]=[node(it.child(i)) for i in range(it.childCount())]
            return obj
        return {"collection_id":self.collection.currentData(),
                "next_group_number":int(getattr(self,"_next_group_number",1)),
                "items":[node(self.tree.topLevelItem(i)) for i in range(self.tree.topLevelItemCount())]}

    def save_session(self, silent=False, immediate=False):
        """Save the work session without turning ordinary UI operations into disk I/O.

        Silent autosaves are debounced. Explicit saves and application shutdown flush
        immediately. This is especially noticeable on thin clients/network-profile PCs.
        """
        if silent and not immediate:
            self._session_save_pending=True
            if hasattr(self, "_session_save_timer"):
                self._session_save_timer.start()
                return
        self._flush_session_save()
        if not silent: self.status.setText(self.status.text()+" ｜ 作業状態を保存しました")

    def _flush_session_save(self):
        if hasattr(self, "_session_save_timer") and self._session_save_timer.isActive():
            self._session_save_timer.stop()
        self.session.save(self.session_dict())
        self._session_save_pending=False

    def load_session(self, silent=False, restore_items=True):
        data=self.session.load()
        if not data:
            if not silent: QMessageBox.information(self,"作業読込","保存された作業状態はありません。")
            return
        self.tree.clear()
        self._next_group_number=max(1,int(data.get("next_group_number",1) or 1))
        cid=data.get("collection_id")
        idx=self.collection.findData(cid)
        if idx>=0:
            self.collection.blockSignals(True); self.collection.setCurrentIndex(idx); self.collection.blockSignals(False)
        def add(obj,parent=None):
            it=QTreeWidgetItem([obj.get("text",""),"","","",""])
            typ=obj.get("type")
            if typ=="file":
                it.setData(0,Qt.UserRole,{"type":"file","id":"item_"+uuid.uuid4().hex,"path":obj.get("path",""),"manual_plot_id":obj.get("manual_plot_id")})
                it.setFlags(it.flags() & ~Qt.ItemIsDropEnabled)
                it.setCheckState(0,Qt.Checked)
            else:
                it.setData(0,Qt.UserRole,{"type":"group","id":"group_"+uuid.uuid4().hex,"name":obj.get("text","")})
                it.setFlags(it.flags()|Qt.ItemIsDropEnabled|Qt.ItemIsEditable|Qt.ItemIsAutoTristate|Qt.ItemIsUserCheckable)
                it.setCheckState(0,Qt.Checked)
            (parent.addChild(it) if parent else self.tree.addTopLevelItem(it))
            if typ=="group":
                for c in obj.get("children",[]): add(c,it)
                it.setExpanded(obj.get("expanded",True))
            return it
        if restore_items:
            for obj in data.get("items",[]): add(obj)
        self.rejudge()
        if not silent:self.status.setText(self.status.text()+" ｜ 作業状態を復元しました")

    def _drawing_list_payload(self):
        entries=[]
        for i in range(self.tree.topLevelItemCount()):
            top=self.tree.topLevelItem(i); d=top.data(0,Qt.UserRole) or {}
            if d.get("type")=="group":
                children=[]
                for j in range(top.childCount()):
                    ch=top.child(j); cd=ch.data(0,Qt.UserRole) or {}
                    children.append({"type":"file","id":cd.get("id") or "item_"+uuid.uuid4().hex,"path":cd.get("path",""),"manual_plot_id":cd.get("manual_plot_id")})
                entries.append({"type":"group","id":d.get("id") or "group_"+uuid.uuid4().hex,"name":top.text(0),"items":children})
            elif d.get("type")=="file":
                entries.append({"type":"file","id":d.get("id") or "item_"+uuid.uuid4().hex,"path":d.get("path",""),"manual_plot_id":d.get("manual_plot_id")})
        return {"format":"ACadPresetter.acplist","version":2,"collection_id":self.collection.currentData(),
                "next_group_number":int(getattr(self,"_next_group_number",1)),"entries":entries}

    def clear_main_list(self, confirm=True, save_session=True):
        """Clear only the working main list.

        Source DWG/DXF files and saved .acplist files are never deleted.  The current
        .acplist association is also released so a later Ctrl+S cannot accidentally
        overwrite the previously opened list with an empty list.
        """
        if getattr(self, "_output_in_progress", False):
            QMessageBox.information(self, "リストクリア", "出力中はリストをクリアできません。")
            return False
        if self.tree.topLevelItemCount() == 0:
            self._current_list_path=None
            self._next_group_number=1
            if save_session:
                self.save_session(silent=True, immediate=True)
            self.update_status()
            return True
        if confirm:
            ans=QMessageBox.question(
                self, "リストクリア",
                "メインリストに登録されているDWG/DXFとグループをすべて解除します。\n\n"
                "元のDWG/DXFファイルや保存済み.acplistは削除されません。\nよろしいですか？",
                QMessageBox.Yes|QMessageBox.No, QMessageBox.No)
            if ans != QMessageBox.Yes:
                return False
        with self._bulk_tree_update():
            self.tree.clear()
        self._current_list_path=None
        self._next_group_number=1
        self._pending_new_group_states.clear()
        self._last_output_folders=[]
        self.open_output_folder_btn.setVisible(False)
        self.update_status()
        if save_session:
            self.save_session(silent=True, immediate=True)
        self.status.setText(self.status.text()+" ｜ リストをクリアしました")
        return True

    def export_list(self):
        """Save to the current .acplist when one is open; otherwise ask once.

        This makes the common workflow: load -> append/change -> save, a one-click overwrite.
        """
        fn=str(self._current_list_path or "")
        if not fn:
            fn,_=QFileDialog.getSaveFileName(self,"リストを保存","","ACadPresetter List (*.acplist)")
            if not fn:return
            if not fn.lower().endswith(".acplist"):fn += ".acplist"
        self.store.save_drawing_list(fn,self._drawing_list_payload())
        self._current_list_path=Path(fn)
        self.status.setText(self.status.text()+f" ｜ リストを保存しました: {Path(fn).name}")

    def _load_acplist_entries(self,path,append=False):
        dl=self.store.load_drawing_list(path)
        payload=dl.to_dict()
        entries=payload.get("entries",[])
        if not append:
            self.tree.clear()
            self._next_group_number=max(1,int(payload.get("next_group_number",1) or 1))
            self._current_list_path=Path(path)
        existing={str(Path(self.item_path(x)).resolve()).casefold() for x in self.all_file_items() if self.item_path(x)}
        skipped=0
        for ent in entries:
            if ent.get("type")=="group":
                fresh=[]
                for f in ent.get("items",[]):
                    pp=f.get("path",""); key=str(Path(pp).resolve()).casefold() if pp else ""
                    if not pp or key in existing: skipped+=1; continue
                    existing.add(key); fresh.append(f)
                if not fresh:continue
                # Appended automatic names get fresh local numbering. Custom names are retained.
                name=ent.get("name") or self.next_group_name()
                if append and name.startswith("新規グループ"):name=self.next_group_name()
                g=self._new_group_item(name,ent.get("id") if not append else None)
                for f in fresh:self.add_file(Path(f["path"]),g,manual_plot_id=f.get("manual_plot_id"),item_id=f.get("id") if not append else None)
            else:
                pp=ent.get("path",""); key=str(Path(pp).resolve()).casefold() if pp else ""
                if not pp or key in existing: skipped+=1; continue
                existing.add(key); self.add_file(Path(pp),None,manual_plot_id=ent.get("manual_plot_id"),item_id=ent.get("id") if not append else None)
        if not append:
            idx=self.collection.findData(payload.get("collection_id"))
            if idx>=0:self.collection.setCurrentIndex(idx)
        self.rejudge(); self.update_status(); self.save_session(silent=True)
        if skipped:self.status.setText(self.status.text()+f" ｜ 重複/無効 {skipped}件を除外")
        if append:
            self.status.setText(self.status.text()+f" ｜ {Path(path).name} を追加")
        else:
            self.status.setText(self.status.text()+f" ｜ {Path(path).name} を読込")

    def import_list_replace(self):
        fn,_=QFileDialog.getOpenFileName(self,"リストを読込","","ACadPresetter List (*.acplist)")
        if fn:self._load_acplist_entries(fn,False)

    def import_list_append(self):
        fn,_=QFileDialog.getOpenFileName(self,"リストを追加","","ACadPresetter List (*.acplist)")
        if fn:self._load_acplist_entries(fn,True)

    def relink_missing_files(self):
        """Relink selected missing drawings after a folder move.

        One item: choose the replacement DWG/DXF directly.
        Multiple items: choose the new root. Relative paths from the selected old
        common root are tried first; unique recursive filename matches are the fallback.
        """
        items=[x for x in self._selected_file_items() if self.item_path(x) and not Path(self.item_path(x)).exists()]
        if not items:
            QMessageBox.information(self,"再リンク","選択範囲に見つからないDWG/DXFはありません。")
            return
        if len(items)==1:
            old=Path(self.item_path(items[0]))
            fn,_=QFileDialog.getOpenFileName(self,"再リンク先を選択",str(old.parent),"CAD図面 (*.dwg *.dxf)")
            if not fn:return
            self._set_item_path(items[0],Path(fn))
            self.rejudge(); self.update_status(); self.save_session(silent=True)
            return
        root=QFileDialog.getExistingDirectory(self,"移動後のフォルダを選択")
        if not root:return
        new_root=Path(root)
        old_paths=[Path(self.item_path(x)) for x in items]
        try:
            import os
            common=Path(os.path.commonpath([str(x.parent) for x in old_paths]))
        except Exception:
            common=None
        # Build filename index only once for fallback matching.
        index={}
        try:
            for fp in new_root.rglob("*"):
                if fp.is_file() and fp.suffix.lower() in (".dwg",".dxf"):
                    index.setdefault(fp.name.casefold(),[]).append(fp)
        except OSError:
            pass
        linked=ambiguous=missing=0
        for it,old in zip(items,old_paths):
            candidate=None
            if common is not None:
                try:
                    rel=old.relative_to(common); test=new_root/rel
                    if test.is_file(): candidate=test
                except ValueError: pass
            if candidate is None:
                matches=index.get(old.name.casefold(),[])
                if len(matches)==1:candidate=matches[0]
                elif len(matches)>1:ambiguous+=1; continue
            if candidate is None:missing+=1; continue
            self._set_item_path(it,candidate); linked+=1
        self.rejudge(); self.update_status(); self.save_session(silent=True)
        msg=f"再リンク: {linked}件"
        if ambiguous:msg+=f"\n候補が複数: {ambiguous}件"
        if missing:msg+=f"\n見つからない: {missing}件"
        QMessageBox.information(self,"再リンク結果",msg)

    def _set_item_path(self,it,path):
        d=dict(it.data(0,Qt.UserRole) or {})
        d["path"]=str(path)
        it.setData(0,Qt.UserRole,d)
        it.setText(0,Path(path).name)

    def closeEvent(self,event):
        if getattr(self,"_output_in_progress",False):
            self.request_output_cancel()
            event.ignore()
            return
        # RC13: the main drawing list is intentionally a per-launch work area.
        # On a normal application exit, persist an EMPTY list so the next startup
        # never brings back drawings/groups from the previous run.  Saved .acplist
        # files are independent and are not touched.  Keep the selected collection
        # in the session so only the list itself is cleared as requested.
        try:
            with self._bulk_tree_update():
                self.tree.clear()
            self._current_list_path=None
            self._next_group_number=1
            self._pending_new_group_states.clear()
            self.save_session(silent=True, immediate=True)
        finally:
            event.accept()

if __name__=="__main__":
    app=QApplication(sys.argv); app.setStyle("Fusion")
    app.setApplicationName("ACadPresetter")
    app.setWindowIcon(load_app_icon())
    w=MainWindow(); w.setWindowIcon(load_app_icon()); w.show(); sys.exit(app.exec())
