"""Validated PDF merging without holding Windows source-file locks."""
from io import BytesIO
from pathlib import Path
import tempfile
import os
import hashlib

from .pdf_output import PdfOutputSession


def pdf_content_fingerprint(path):
    """Compare original inputs with the exact bytes included in a merge."""
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def merge_pdfs(inputs, output, *, input_fingerprints=None):
    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError as exc:
        raise RuntimeError('PDF結合には pypdf が必要です。') from exc
    paths = [Path(p) for p in inputs]
    if not paths:
        raise ValueError('結合元PDFがありません。')
    missing = [str(p) for p in paths if not p.is_file()]
    if missing:
        raise RuntimeError('結合元PDFがありません:\n' + '\n'.join(missing))
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + out.name + '.', suffix='.merge_tmp', dir=out.parent)
    os.close(fd)
    tmp = Path(temporary)
    writer = PdfWriter()
    try:
        expected_pages = 0
        merged_fingerprints = {}
        for path in paths:
            PdfOutputSession.validate_pdf(path)
            payload = path.read_bytes()
            reader = PdfReader(BytesIO(payload), strict=True)
            # Fingerprint the actual memory snapshot consumed by PdfWriter,
            # rather than a separate read before/after merging that could see
            # a concurrent editor's different revision of the input file.
            merged_fingerprints[str(path)] = hashlib.sha256(payload).hexdigest()
            if not expected_pages and reader.metadata:
                writer.add_metadata({str(k): str(v) for k, v in reader.metadata.items() if v is not None})
            expected_pages += len(reader.pages)
            writer.append(reader, import_outline=True)
        with tmp.open('wb') as stream:
            writer.write(stream)
        PdfOutputSession.validate_pdf(tmp)
        check = PdfReader(BytesIO(tmp.read_bytes()), strict=True)
        if len(check.pages) != expected_pages:
            raise RuntimeError('結合PDFのページ数が一致しません。')
        os.replace(tmp, out)
        PdfOutputSession.validate_pdf(out)
        if input_fingerprints is not None:
            input_fingerprints.update(merged_fingerprints)
    finally:
        writer.close()
        tmp.unlink(missing_ok=True)
    return str(out)
