"""One interpretation of the Adobe PDF folder for printing and UI tools."""
from __future__ import annotations

import os
from pathlib import Path


def normalize_watch_dir(value: str | Path | None) -> Path:
    """Accept Explorer's quoted path, environment variables, and ``~``.

    Only outer double quotes are removed. Folder spelling and Unicode are kept
    intact; changing them could select a different directory.
    """
    text = str(value or "").strip()
    if len(text) >= 2 and text.startswith('"') and text.endswith('"'):
        text = text[1:-1].strip()
    if not text:
        raise ValueError("Adobe PDF生成先フォルダが未設定です。")
    text = os.path.expandvars(os.path.expanduser(text))
    return Path(text).resolve()
