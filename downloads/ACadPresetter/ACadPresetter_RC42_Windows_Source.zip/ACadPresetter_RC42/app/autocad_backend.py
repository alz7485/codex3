import time

class AutoCADConnectionLost(RuntimeError):
    """Raised when the COM server disappeared and continuing the batch is unsafe."""


class AutoCADUnsafeState(RuntimeError):
    """Raised when AutoCAD remains in a state where opening the next drawing is unsafe."""


def _looks_like_connection_loss(exc):
    if isinstance(exc,(AutoCADConnectionLost,AutoCADUnsafeState)):
        return True
    # pywintypes.com_error often exposes only a signed integer/localized text.
    codes=[getattr(exc,"hresult",None), *(getattr(exc,"args",())[:1])]
    fatal_codes={0x800706BA,0x80010108,0x80010007,0x80010012,0x80080005}
    if any(isinstance(code,int) and (code & 0xFFFFFFFF) in fatal_codes for code in codes):
        return True
    if exc.__cause__ is not None and exc.__cause__ is not exc:
        if _looks_like_connection_loss(exc.__cause__): return True
    text=str(exc).casefold()
    markers=("rpc server", "rpc サーバ", "server execution failed", "call was rejected",
             "disconnected", "object invoked has disconnected", "0x800706ba",
             "0x80010108", "0x80010001")
    return any(x in text for x in markers)


class AutoCADBackend:
    """Late-bound COM backend. It never quits AutoCAD on disconnect."""
    def __init__(self):
        self.app=None
        self.started_by_us=False
        self.selected_year="自動"

    def _client(self):
        try:
            import win32com.client
            return win32com.client
        except Exception as e:
            raise RuntimeError("pywin32 が見つかりません。AutoCAD接続には pywin32 が必要です。") from e

    def _start_selected(self, year, visible):
        """Create a NEW AutoCAD COM instance so batch output never hijacks the user's window."""
        c=self._client()
        # AutoCAD 2025/2026 use the R25.x COM ProgIDs. Try the requested year first,
        # then the registered default. DispatchEx is important: Dispatch can attach to
        # an already-running visible AutoCAD and make every Documents.Open flash on screen.
        progids=[]
        versioned={"2025":"AutoCAD.Application.25.0","2026":"AutoCAD.Application.25.1","2027":"AutoCAD.Application.25.2"}
        y=str(year or "自動")
        if y in versioned: progids.append(versioned[y])
        progids.append("AutoCAD.Application")
        from .autocad_visibility import existing_window_handles
        previous_windows=existing_window_handles()
        last=None
        for progid in progids:
            try:
                app=c.DispatchEx(progid)
            except Exception as e:
                last=e
                continue
            # Do not claim, hide or Quit a window that existed before this call.
            if int(getattr(app,"HWND",0) or 0) in previous_windows:
                raise RuntimeError("専用AutoCADを作成できず既存ウィンドウが返されました。ユーザーのAutoCADは操作しません。")
            self.started_by_us=True
            try:
                app.Visible=bool(visible)
            except Exception as e:
                try: app.Quit()
                except Exception: pass
                self.started_by_us=False
                raise RuntimeError("専用AutoCADの表示状態を設定できませんでした。") from e
            return app
        raise RuntimeError("AutoCADを起動できませんでした。") from last

    def connect(self, allow_start=False, visible=False, prefer_running=True, selected_year="自動"):
        c=self._client(); self.selected_year=str(selected_year or "自動")
        if prefer_running:
            try:
                self.app=c.GetActiveObject("AutoCAD.Application")
                self.started_by_us=False
                return self.app
            except Exception:
                pass
        if not allow_start:
            # Even when prefer_running is false, an already running instance is still safer than failing.
            try:
                self.app=c.GetActiveObject("AutoCAD.Application")
                self.started_by_us=False
                return self.app
            except Exception as e:
                raise RuntimeError("起動中のAutoCADがありません。") from e
        self.app=self._start_selected(self.selected_year,visible)
        return self.app

    def disconnect(self):
        # Deliberately release only our COM reference. Never call Application.Quit().
        self.app=None

    def ensure_alive(self):
        if self.app is None:
            raise AutoCADConnectionLost("AutoCADに接続されていません。")
        try:
            _=self.app.Name
            return True
        except Exception as e:
            raise AutoCADConnectionLost("AutoCADとの接続が失われました。") from e

    def info(self):
        self.ensure_alive()
        return {
            "name":getattr(self.app,"Name","AutoCAD"),
            "version":getattr(self.app,"Version",""),
            "caption":getattr(self.app,"Caption",""),
            "visible":bool(getattr(self.app,"Visible",False)),
            "started_by_acad_presetter":bool(self.started_by_us),
        }

    def active_plot_environment(self):
        """Capture devices, per-device media, styles and useful plot paths without saving the drawing."""
        if self.app is None: raise RuntimeError("AutoCADに接続されていません。")
        try: doc=self.app.ActiveDocument
        except Exception as e: raise RuntimeError("AutoCADに図面が開かれていません。") from e
        if doc is None: raise RuntimeError("AutoCADに図面が開かれていません。")
        layout=doc.ActiveLayout
        def arr(fn):
            try:return [str(x) for x in fn()]
            except Exception:return []
        try: layout.RefreshPlotDeviceInfo()
        except Exception: pass
        devices=arr(layout.GetPlotDeviceNames)
        styles=arr(layout.GetPlotStyleTableNames)
        original_state=_capture_layout_state(layout)
        device_media={}
        device_media_locale={}
        try:
            for dev in devices:
                try:
                    layout.ConfigName=dev
                    try: layout.RefreshPlotDeviceInfo()
                    except Exception: pass
                    canonical=arr(layout.GetCanonicalMediaNames)
                    device_media[dev]=canonical
                    aliases={}
                    for name in canonical:
                        try:
                            label=str(layout.GetLocaleMediaName(name) or "").strip()
                        except Exception:
                            label=""
                        if label:
                            aliases[str(name)]=label
                    device_media_locale[dev]=aliases
                except Exception:
                    device_media[dev]=[]
                    device_media_locale[dev]={}
        finally:
            errors=_restore_layout_state(layout,original_state)
            if errors:
                raise AutoCADUnsafeState("印刷環境取得後に元設定を復元できません。\n"+"\n".join(errors))
        paths={}
        try:
            files=self.app.Preferences.Files
            for key,attr in (("printer_config","PrinterConfigPath"),("plot_style","PrinterStyleSheetPath"),("printer_description","PrinterDescPath")):
                try: paths[key]=str(getattr(files,attr) or "")
                except Exception: pass
        except Exception: pass
        info=self.info()
        media=[]; seen=set()
        for dev in devices:
            for value in device_media.get(dev,[]):
                if value.casefold() not in seen:
                    seen.add(value.casefold()); media.append(value)
        return {"drawing":doc.Name,"layout":layout.Name,"devices":devices,"device_media":device_media,"device_media_locale":device_media_locale,"media":media,"styles":styles,"paths":paths,"autocad":info}

def probe_plot_environment(allow_start=False, connection_options=None):
    """Read the plot environment without disturbing the user's AutoCAD.

    When starting AutoCAD is allowed, use the same dedicated hidden batch session as
    output/inspection and close only that owned instance afterward.  The old path
    attached to an already-running interactive AutoCAD and temporarily changed its
    active layout device while enumerating media.
    """
    if allow_start:
        session=AutoCADBatchSession({**(connection_options or {}),"dedicated_hidden":True,"prefer_running":False})
        temporary_doc=None
        session.open()
        try:
            if bool(getattr(session.backend,"started_by_us",False)) and int(session.app.Documents.Count)==0:
                _keep_session_hidden(session)
                temporary_doc=session.app.Documents.Add()
                _keep_session_hidden(session)
            return session.backend.active_plot_environment()
        finally:
            try:
                if temporary_doc is not None:
                    _safe_close_owned_document(session,temporary_doc,"印刷環境取得用の一時図面")
            finally:
                session.close()
    be=AutoCADBackend()
    be.connect(allow_start=False, visible=False, prefer_running=True)
    try:
        return be.active_plot_environment()
    finally:
        be.disconnect()


def _unwrap_variant(value):
    # Explicit pywin32 VARIANTs and fake variants used in regression tests.
    return getattr(value, 'value', value)


def _numeric_pair(value, label='2値'):
    import math
    from array import array
    value = _unwrap_variant(value)
    if not isinstance(value, (tuple, list, array)) or len(value) != 2:
        raise ValueError(f'{label}は数値2個が必要です: {value!r}')
    pair = tuple(float(_unwrap_variant(v)) for v in value)
    if not all(math.isfinite(v) for v in pair):
        raise ValueError(f'{label}は有限の数値2個が必要です。')
    return pair


def _point2d(values):
    from array import array
    return array('d', _numeric_pair(values, '座標'))


def _point_variant(values):
    """Trial10g's explicit SAFEARRAY(Double) for dynamic ActiveX setters."""
    pair = _numeric_pair(values, '座標')
    try:
        import pythoncom, win32com.client
    except ImportError:
        return _point2d(pair)  # non-Windows test environments
    return win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, pair)


def _set_plot_origin(layout, values):
    pair = _numeric_pair(values, '印刷原点')
    try:
        layout.PlotOrigin = _point_variant(pair)
    except Exception as exc:
        raise RuntimeError(f'印刷原点の2値を適用できません (PlotOrigin / SAFEARRAY Double): {pair}\n{exc}') from exc


def _set_window_points(layout, lower, upper):
    lower = _numeric_pair(lower, '窓の左下')
    upper = _numeric_pair(upper, '窓の右上')
    if upper[0] <= lower[0] or upper[1] <= lower[1]:
        raise ValueError(f'窓の印刷範囲が不正です: 左下={lower} / 右上={upper}')
    try:
        layout.SetWindowToPlot(lower, upper)  # successful Trial10g route
    except Exception as first:
        try:
            layout.SetWindowToPlot(_point_variant(lower), _point_variant(upper))
        except Exception as second:
            raise RuntimeError('窓の印刷座標の2点を適用できません (SetWindowToPlot)。\n'
                               f'左下={lower} / 右上={upper}\nタプル指定: {first}\n'
                               f'SAFEARRAY Double指定: {second}') from second


def _coerce_custom_scale(value):
    import re
    value = _unwrap_variant(value)
    if isinstance(value, str):
        nums = re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?", value)
        value = nums
    pair = _numeric_pair(value, 'CustomScale')
    if min(pair) <= 0:
        raise ValueError('CustomScaleは正の有限数値2個が必要です。')
    return pair


def _get_custom_scale(layout):
    """Read makepy returns, BYREF doubles, then a two-value property."""
    errors = []
    try:
        getter = getattr(layout, 'GetCustomScale', None)
    except Exception as exc:
        errors.append(exc)
        getter = None
    if callable(getter):
        try:
            return _coerce_custom_scale(getter())
        except Exception as exc:
            errors.append(exc)
        try:
            import pythoncom, win32com.client
            num = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_R8, 0.0)
            den = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_R8, 0.0)
            returned = getter(num, den)
            # Some dispatch wrappers return values even when BYREF args were supplied.
            if returned is not None:
                return _coerce_custom_scale(returned)
            return _coerce_custom_scale((num.value, den.value))
        except Exception as exc:
            errors.append(exc)
    try:
        return _coerce_custom_scale(getattr(layout, 'CustomScale'))
    except Exception as exc:
        errors.append(exc)
    raise RuntimeError('カスタム尺度の2値を取得できません (GetCustomScale / BYREF Double)。\n'
                       + '\n'.join(str(e) for e in errors)) from errors[-1]


def _coerce_window_points(value):
    from array import array
    value = _unwrap_variant(value)
    if isinstance(value, (tuple, list, array)):
        if len(value) == 2:
            return (_numeric_pair(value[0], '窓の左下'), _numeric_pair(value[1], '窓の右上'))
        if len(value) == 4:
            return (_numeric_pair(value[:2], '窓の左下'), _numeric_pair(value[2:], '窓の右上'))
    raise ValueError(f'窓の印刷範囲を解釈できません: {value!r}')


def _get_window_points(layout):
    errors = []
    try:
        return _coerce_window_points(layout.GetWindowToPlot())
    except Exception as exc:
        errors.append(exc)
    try:
        import pythoncom, win32com.client
        lower = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_VARIANT, None)
        upper = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_VARIANT, None)
        returned = layout.GetWindowToPlot(lower, upper)
        if returned is not None:
            return _coerce_window_points(returned)
        return (_numeric_pair(lower.value, '窓の左下'), _numeric_pair(upper.value, '窓の右上'))
    except Exception as exc:
        errors.append(exc)
    raise RuntimeError('窓の印刷範囲の2点を取得できません (GetWindowToPlot)。\n'
                       + '\n'.join(str(e) for e in errors)) from errors[-1]


# AutoCAD acPlotScale enum -> exact paper:model ratio.
# Keep this in one canonical table.  Trial10g explicitly confirmed that 1:5
# does NOT exist in acPlotScale; inserting it shifts every enum from 1:8 onward.
PLOT_SCALE_RATIOS = {
    1:(1,1536), 2:(1,768), 3:(1,384), 4:(1,192), 5:(1,128),
    6:(1,96), 7:(1,64), 8:(1,48), 9:(1,32), 10:(1,24),
    11:(1,16), 12:(1,12), 13:(1,4), 14:(1,2), 15:(1,1),
    16:(1,1), 17:(1,2), 18:(1,4), 19:(1,8), 20:(1,10),
    21:(1,16), 22:(1,20), 23:(1,30), 24:(1,40), 25:(1,50),
    26:(1,100), 27:(2,1), 28:(4,1), 29:(8,1), 30:(10,1), 31:(100,1),
}


def _float_close(a,b,rel=1e-7,abs_tol=1e-7):
    a=float(a); b=float(b)
    return abs(a-b) <= max(abs_tol,abs(a)*rel)


def _verify_applied_plot_settings(layout, settings):
    """Re-read critical ActiveX values before plotting.

    Trial10g showed that AutoCAD can silently reject/replace a requested plot
    value.  Failing before PlotToFile/PlotToDevice is safer than producing a
    plausible-looking PDF with the wrong device/media/window.
    """
    from .plot_settings import normalize_plot_settings
    s=normalize_plot_settings(settings)
    mismatches=[]
    def get(name,default=None):
        try:return getattr(layout,name)
        except Exception:return default
    req_device=str(s.get("device","") or "").strip()
    got_device=str(get("ConfigName","") or "").strip()
    if req_device and got_device and req_device.casefold()!=got_device.casefold():
        mismatches.append(f"出力機器: 指定={req_device} / 実値={got_device}")
    req_media=str(s.get("paper","") or "").strip()
    got_media=str(get("CanonicalMediaName","") or "").strip()
    if req_media and got_media and req_media.casefold()!=got_media.casefold():
        # UI may hold a localized media label. Resolve once more against the
        # active device before declaring a mismatch.
        try:
            from .media_names import resolve_media_name
            available=[str(x) for x in layout.GetCanonicalMediaNames()]
            aliases={}
            for name in available:
                try:aliases[name]=str(layout.GetLocaleMediaName(name) or "")
                except Exception:pass
            req_media=resolve_media_name(req_media,available,aliases)
        except Exception:
            pass
        if req_media.casefold()!=got_media.casefold():
            mismatches.append(f"用紙: 指定={req_media} / 実値={got_media}")
    pt={"表示範囲":0,"図形範囲":1,"図面範囲":2,"ビュー":3,"窓":4,"レイアウト":5}
    area=s.get("plot_area")
    got_pt=get("PlotType",None)
    if area in pt and got_pt is not None and int(got_pt)!=pt[area]:
        mismatches.append(f"印刷範囲: 指定={area} / 実値={got_pt}")
    rotmap={"0°":0,"90°":1,"180°":2,"270°":3}
    req_rot=rotmap.get(s.get("rotation","0°"))
    got_rot=get("PlotRotation",None)
    if req_rot is not None and got_rot is not None and int(got_rot)!=req_rot:
        mismatches.append(f"方向: 指定={s.get('rotation')} / 実値={got_rot}")
    if area=="窓":
        try:
            (p1,p2)=_get_window_points(layout)
            req=(float(s["window_x1"]),float(s["window_y1"]),float(s["window_x2"]),float(s["window_y2"]))
            got=(p1[0],p1[1],p2[0],p2[1])
            if not all(_float_close(a,b) for a,b in zip(req,got)):
                mismatches.append(f"窓範囲: 指定={req} / 実値={got}")
        except Exception as exc:
            mismatches.append(f"窓範囲の再確認失敗: {exc}")
    # RC34: PaperUnits changes how plot geometry/scale is interpreted.  Trial10g
    # transfers and verifies it, so do the same when the source value is known.
    req_units=s.get("paper_units")
    if req_units not in (None, ""):
        got_units=get("PaperUnits",None)
        if got_units is None or int(got_units)!=int(req_units):
            mismatches.append(f"用紙単位: 指定={req_units} / 実値={got_units}")

    # RC35: Trial10g validates the style/centering/origin values after the
    # ActiveX write as well.  AutoCAD may silently reject or replace these,
    # so do not proceed to plotting just because SetAttr itself succeeded.
    req_style=str(s.get("plot_style","") or "").strip()
    if req_style:
        got_style=str(get("StyleSheet","") or "").strip()
        if req_style.casefold()!=got_style.casefold():
            mismatches.append(f"CTB/STB: 指定={req_style} / 実値={got_style}")

    req_plot_styles=bool(s.get("plot_styles",True))
    got_plot_styles=get("PlotWithPlotStyles",None)
    if got_plot_styles is not None and bool(got_plot_styles)!=req_plot_styles:
        mismatches.append(
            f"印刷スタイル使用: 指定={'ON' if req_plot_styles else 'OFF'} / "
            f"実値={'ON' if bool(got_plot_styles) else 'OFF'}"
        )

    req_lineweights=bool(s.get("lineweights",True))
    got_lineweights=get("PlotWithLineweights",None)
    if got_lineweights is not None and bool(got_lineweights)!=req_lineweights:
        mismatches.append(
            f"線の太さ: 指定={'ON' if req_lineweights else 'OFF'} / "
            f"実値={'ON' if bool(got_lineweights) else 'OFF'}"
        )

    # PlotTransparency is not exposed by every ActiveX version.  Verify only
    # when AutoCAD exposes it, matching the best-effort apply behavior.
    got_transparency=get("PlotTransparency",None)
    if got_transparency is not None:
        req_transparency=bool(s.get("transparency",False))
        if bool(got_transparency)!=req_transparency:
            mismatches.append(
                f"透過性: 指定={'ON' if req_transparency else 'OFF'} / "
                f"実値={'ON' if bool(got_transparency) else 'OFF'}"
            )

    # CenterPlot is not valid for acLayout.  For all other plot types it is a
    # real transferred setting and must match before output.
    if area!="レイアウト":
        req_center=bool(s.get("center_plot",True))
        got_center=get("CenterPlot",None)
        if got_center is not None and bool(got_center)!=req_center:
            mismatches.append(
                f"中央配置: 指定={'ON' if req_center else 'OFF'} / "
                f"実値={'ON' if bool(got_center) else 'OFF'}"
            )

    # Origin matters when centering is OFF, and for Layout output.  Compare
    # numerically with tolerance because COM can round coordinates slightly.
    if area=="レイアウト" or not bool(s.get("center_plot",True)):
        try:
            req_origin=(float(s.get("offset_x",0.0)),float(s.get("offset_y",0.0)))
            got_origin=_numeric_pair(get("PlotOrigin",None), "PlotOrigin")
            if not all(_float_close(a,b) for a,b in zip(req_origin,got_origin)):
                mismatches.append(f"印刷原点: 指定={req_origin} / 実値={got_origin}")
        except Exception as exc:
            mismatches.append(f"印刷原点の再確認失敗: {exc}")

    mode=s.get("scale_mode")
    if mode in ("fit","standard"):
        got_use=bool(get("UseStandardScale",False))
        if not got_use:
            mismatches.append("尺度方式: 標準縮尺を指定しましたがUseStandardScale=OFFです")
        req_std=0 if mode=="fit" else s.get("standard_scale_index")
        if req_std not in (None,""):
            got_std=get("StandardScale",None)
            if got_std is None or int(got_std)!=int(req_std):
                mismatches.append(f"標準縮尺: 指定={req_std} / 実値={got_std}")
    if mode=="custom" or (mode is None and not bool(s.get("fit_to_paper",True))):
        req_num=s.get("scale_num"); req_den=s.get("scale_den")
        # Trial10g behavior: an unreadable/blank CustomScale means "leave the
        # target layout's current custom scale unchanged".  Only verify when
        # the preset actually carries two values.
        if req_num not in (None,"") or req_den not in (None,""):
            try:
                req_num=float(req_num); req_den=float(req_den)
                if req_num <= 0 or req_den <= 0:
                    raise ValueError("CustomScaleは正の値2個が必要です。")
                got_num,got_den=_get_custom_scale(layout)
                if not (_float_close(req_num,got_num) and _float_close(req_den,got_den)):
                    mismatches.append(f"尺度: 指定={req_num}:{req_den} / 実値={got_num}:{got_den}")
            except Exception as exc:
                mismatches.append(f"尺度の再確認失敗: {exc}")
    if mismatches:
        raise RuntimeError("AutoCADへ印刷設定を反映後、実値が一致しません。\n"+"\n".join(mismatches))
    return True


def _apply_plot_settings(layout, settings):
    """Apply common AutoCAD ActiveX plot properties where supported."""
    from .plot_settings import normalize_plot_settings
    settings=normalize_plot_settings(settings)
    device=settings.get("device",""); media=settings.get("paper",""); style=settings.get("plot_style","")
    if device: layout.ConfigName=device
    try: layout.RefreshPlotDeviceInfo()
    except Exception: pass
    if media:
        from .media_names import resolve_media_name
        try: available=list(layout.GetCanonicalMediaNames())
        except Exception: available=[]
        aliases={}
        for name in available:
            try: aliases[str(name)]=str(layout.GetLocaleMediaName(name))
            except Exception: pass
        try:
            resolved=resolve_media_name(media,available,aliases) if available else media
            layout.CanonicalMediaName=resolved
            if str(layout.CanonicalMediaName).casefold()!=str(resolved).casefold():
                raise ValueError("AutoCADが指定用紙を反映しませんでした。")
        except Exception as e:
            raise RuntimeError(f"用紙設定失敗（出力機器: {device} / 指定: {media}）: {e}") from e
    def apply(name, value):
        try: setattr(layout,name,value)
        except Exception as exc:
            raise RuntimeError(f"印刷設定を適用できません（{name}）: {exc}") from exc
    # Trial10g applies paper units and rotation before window/origin because
    # AutoCAD can reinterpret geometry when either changes.
    if settings.get("paper_units") not in (None, ""):
        apply("PaperUnits",int(settings.get("paper_units")))
    rotmap={"0°":0,"90°":1,"180°":2,"270°":3}
    apply("PlotRotation",rotmap[settings.get("rotation","0°")])
    if style: apply("StyleSheet",style)
    pt={"表示範囲":0,"図形範囲":1,"図面範囲":2,"ビュー":3,"窓":4,"レイアウト":5}
    area=settings.get("plot_area")
    # ActiveX requires window coordinates BEFORE setting PlotType=acWindow.
    if area=="窓":
        _set_window_points(layout,
                           (settings["window_x1"], settings["window_y1"]),
                           (settings["window_x2"], settings["window_y2"]))
    if area in pt: apply("PlotType",pt[area])
    # Trial10g order: when CenterPlot is OFF, disable centering first, then
    # write PlotOrigin.  When CenterPlot is ON, enable it after origin handling.
    # CenterPlot itself is not valid for acLayout.
    want_center=bool(settings.get("center_plot",True))
    if area!="レイアウト" and not want_center:
        apply("CenterPlot",False)
    if area=="レイアウト" or not want_center:
        _set_plot_origin(layout, (settings.get("offset_x",0),settings.get("offset_y",0)))
    if area!="レイアウト" and want_center:
        apply("CenterPlot",True)
    mode=settings.get("scale_mode")
    if mode=="fit":
        apply("UseStandardScale",True); apply("StandardScale",0)
    elif mode=="standard":
        std=settings.get("standard_scale_index")
        if std in (None,""):
            raise RuntimeError("標準縮尺の種類が取得できていません。DWG/DXFから設定を取得し直してください。")
        apply("UseStandardScale",True); apply("StandardScale",int(std))
    else:
        # Legacy presets without scale_mode keep the former UI semantics:
        # fit_to_paper=True means acScaleToFit, otherwise custom scale.
        custom_mode = (mode=="custom") or not bool(settings.get("fit_to_paper",True))
        if not custom_mode:
            apply("UseStandardScale",True); apply("StandardScale",0)
        else:
            apply("UseStandardScale",False)
            num=settings.get("scale_num"); den=settings.get("scale_den")
            # If the source drawing had UseStandardScale=OFF but AutoCAD could not
            # expose CustomScale, keep the destination layout's existing custom
            # scale. Never silently substitute 1:1.
            if num not in (None,"") or den not in (None,""):
                try:
                    num,den=_coerce_custom_scale((num,den))
                    layout.SetCustomScale(num,den)
                except Exception as exc:
                    raise RuntimeError(f"印刷尺度の2値を適用できません (SetCustomScale): {num}:{den}\n"+str(exc)) from exc
    apply("PlotWithLineweights",bool(settings.get("lineweights",True)))
    # This property is unavailable on some ActiveX versions. Keep the legacy
    # best-effort behavior here; other core geometry/style settings are strict.
    try: layout.PlotTransparency=bool(settings.get("transparency",False))
    except Exception: pass
    apply("PlotWithPlotStyles",bool(settings.get("plot_styles",True)))

def _norm_path(value):
    from pathlib import Path
    try:
        return str(Path(str(value)).resolve()).replace("/", "\\").casefold()
    except Exception:
        return str(value or "").replace("/", "\\").casefold()


def _find_open_document(app, source_path):
    """Return an already-open document for source_path, matched by normalized FullName."""
    wanted=_norm_path(source_path)
    try:
        for doc in app.Documents:
            full=str(getattr(doc,"FullName","") or "")
            if full and _norm_path(full)==wanted:
                return doc
    except Exception:
        pass
    return None


def _acquire_document(app, source_path):
    doc=_find_open_document(app,source_path)
    if doc is not None:
        return doc,False
    return app.Documents.Open(str(source_path),False),True


def _layout_by_settings(doc, settings, explicit_name=None):
    if explicit_name:
        wanted=explicit_name
    else:
        mode=settings.get("layout_mode","現在のLayout")
        if mode=="Modelのみ": wanted="Model"
        elif mode=="指定Layout":
            vals=settings.get("layout_names",[]) or []
            wanted=vals[0] if vals else ""
        else: wanted=""
    if not wanted:
        return doc.ActiveLayout
    for lay in doc.Layouts:
        if str(lay.Name).casefold()==str(wanted).casefold():
            return lay
    raise RuntimeError(f'対象レイアウト「{wanted}」がありません。')


def _capture_layout_state(layout):
    names=("ConfigName","CanonicalMediaName","PaperUnits","StyleSheet","PlotType","CenterPlot","UseStandardScale",
           "StandardScale","PlotWithLineweights","PlotTransparency","PlotWithPlotStyles","PlotRotation","PlotOrigin")
    state={}
    for name in names:
        try: state[name]=getattr(layout,name)
        except Exception: pass
    try: state["CustomScale"]=_get_custom_scale(layout)
    except Exception: pass
    try: state["WindowToPlot"]=_get_window_points(layout)
    except Exception: pass
    return state


def _restore_layout_state(layout,state):
    """Restore in dependency order and return actionable failures to the caller."""
    errors=[]

    def restore(name,value,setter=None):
        try:
            if setter is None:
                try:
                    if getattr(layout,name)==value:
                        return
                except Exception:
                    pass
                setattr(layout,name,value)
            else:
                setter(value)
        except Exception as exc:
            errors.append(f"{name}: {exc}")

    # Units and rotation precede all coordinates, just as during application.
    if "ConfigName" in state:
        restore("ConfigName",state["ConfigName"])
        try: layout.RefreshPlotDeviceInfo()
        except Exception: pass
    if "CanonicalMediaName" in state:
        restore("CanonicalMediaName",state["CanonicalMediaName"])
    for name in ("PaperUnits","PlotRotation"):
        if name in state:
            restore(name,state[name])
    if "WindowToPlot" in state:
        def restore_window(value):
            try:
                if _get_window_points(layout)==value:
                    return
            except Exception:
                pass
            lower,upper=value
            if state.get("PlotType")!=4 and (upper[0]<=lower[0] or upper[1]<=lower[1]):
                # New/non-window layouts can expose an unset zero-area window.
                # It is inert for the original plot type and cannot be applied
                # through the strict window setter as an active plot rectangle.
                return
            _set_window_points(layout,*value)
        restore("WindowToPlot",state["WindowToPlot"],restore_window)
    for name in ("StyleSheet","PlotType","UseStandardScale","StandardScale","PlotWithLineweights",
                 "PlotTransparency","PlotWithPlotStyles"):
        if name in state:
            restore(name,state[name])
    # acLayout does not support CenterPlot. For other areas, turn centering off
    # before restoring the origin, then restore the original centering mode last.
    if state.get("PlotType")!=5 and "CenterPlot" in state:
        restore("CenterPlot",False)
    if "PlotOrigin" in state:
        restore("PlotOrigin",state["PlotOrigin"],lambda value:_set_plot_origin(layout,value))
    if state.get("PlotType")!=5 and "CenterPlot" in state:
        restore("CenterPlot",state["CenterPlot"])
    if "CustomScale" in state and not bool(state.get("UseStandardScale",True)):
        restore("CustomScale",state["CustomScale"],lambda value:layout.SetCustomScale(*value))
    return errors


def _prepare_plot(doc, settings, explicit_layout=None):
    layout=_layout_by_settings(doc,settings,explicit_layout)
    original_active=getattr(doc,"ActiveLayout",None)
    state=_capture_layout_state(layout)
    try:
        doc.ActiveLayout=layout
        use_dwg=settings.get("setting_method")=="DWG/DXFに保存されている設定を使用"
        # Adobe PDF is a supported PDF destination.  Adobe documents that PDF
        # creation can fail when its system-font-only printer preference is ON.
        # Apply the known preference before the device is activated when possible.
        from .adobe_pdf import ensure_adobe_pdf_document_fonts
        requested_device=str(settings.get("device","") or "")
        if requested_device and not use_dwg:
            # RC21: this is a best-effort registry adjustment, not a prerequisite
            # for printing. User/PC3 preferences may already be set correctly.
            ensure_adobe_pdf_document_fonts(requested_device)
        if not use_dwg:
            _apply_plot_settings(layout,settings)
            # Re-read the values before plotting. This mirrors the successful
            # Trial10g flow: read -> apply -> verify -> output.
            _verify_applied_plot_settings(layout,settings)
        try: layout.RefreshPlotDeviceInfo()
        except Exception: pass
        device=str(getattr(layout,"ConfigName","") or "")
        if not device:
            raise RuntimeError("使用可能なプリンター / PC3 が設定されていません。")
        # DWG-saved settings may reveal Adobe PDF only after the layout is read.
        adobe=ensure_adobe_pdf_document_fonts(device)
        if adobe.changed:
            try: layout.RefreshPlotDeviceInfo()
            except Exception: pass
        return layout,state,original_active,device,use_dwg
    except Exception:
        _restore_after_plot(doc,layout,state,original_active,strict=True)
        raise


def _restore_after_plot(doc,layout,state,original_active,strict=False):
    errors=_restore_layout_state(layout,state)
    if original_active is not None:
        try: doc.ActiveLayout=original_active
        except Exception as exc: errors.append(f"ActiveLayout: {exc}")
    if strict and errors:
        raise AutoCADUnsafeState("元の印刷設定を安全に復元できません。後続図面は停止します。\n"+"\n".join(errors))
    return errors


def _set_sync_plot(doc):
    try: old=doc.GetVariable("BACKGROUNDPLOT")
    except Exception: old=None
    try: doc.SetVariable("BACKGROUNDPLOT",0)
    except Exception as exc:
        raise RuntimeError("同期印刷を設定できないため出力を停止します。") from exc
    return old


def _restore_sync_plot(doc,old,strict=False):
    if old is not None:
        try: doc.SetVariable("BACKGROUNDPLOT",old)
        except Exception as exc:
            if strict:
                raise AutoCADUnsafeState("BACKGROUNDPLOTを復元できません。後続図面は停止します。\n"+str(exc)) from exc


def _restore_plot_document(doc,layout,state,original_active,bg):
    """Attempt every restoration even when one fails, then report the failures."""
    errors=[]
    if layout is not None and state is not None:
        try: _restore_after_plot(doc,layout,state,original_active,strict=True)
        except Exception as exc: errors.append(str(exc))
    try: _restore_sync_plot(doc,bg,strict=True)
    except Exception as exc: errors.append(str(exc))
    if errors:
        raise AutoCADUnsafeState("\n".join(errors))


def _plot_pdf_to_file(doc, output_path, device, converter=None, keep_hidden=None, log=None, adobe_watch_dir=None, adobe_timeout=120.0, source_path=None):
    """Create a staged PDF using the device already selected on ActiveLayout.

    AutoCAD PDF PC3 devices use PlotToFile. Adobe PDF follows the Trial10g
    path proven on the user's machine: SendCommand / -PLOT, detect the Adobe-created
    PDF, then copy it to ACadPresetter's staged output path.
    """
    from pathlib import Path
    from .adobe_pdf import is_adobe_pdf_device
    from .adobe_distiller import generated_file_kind

    out=Path(output_path)
    if is_adobe_pdf_device(device):
        from .adobe_device_output import plot_to_device_pdf
        path=plot_to_device_pdf(doc,out,device,log=log,keep_hidden=keep_hidden,preferred_dir=adobe_watch_dir,timeout=adobe_timeout,source_path=source_path)
        return bool(path and Path(path).exists())

    sent=bool(doc.Plot.PlotToFile(str(out)))
    if not sent:
        raise RuntimeError(f"AutoCADが印刷ジョブを受け付けませんでした。出力機器: {device}")
    # Trial10g proved that PlotToFile can return before the driver has finished
    # creating/flushing the PDF.  Do not report a false failure immediately.
    deadline=time.monotonic()+15.0
    last_size=-1
    stable=0
    kind="missing"
    while time.monotonic()<deadline:
        if keep_hidden:
            keep_hidden()
        if out.exists():
            try:
                size=out.stat().st_size
            except OSError:
                size=-1
            kind=generated_file_kind(out)
            if kind=="pdf" and size>4:
                if size==last_size:
                    stable+=1
                    if stable>=2:
                        return True
                else:
                    stable=0
                last_size=size
            else:
                stable=0
        time.sleep(0.2)
    if not out.exists():
        raise RuntimeError(f"PlotToFile後にPDFファイルを確認できませんでした。出力機器: {device} / 出力先: {out}")
    kind=generated_file_kind(out)
    raise RuntimeError(f"生成データが正常なPDFとして確定しませんでした（出力機器: {device} / 種別: {kind} / 出力先: {out}）。")

def _adobe_timeout(session):
    from .adobe_device_output import normalize_timeout
    return normalize_timeout(getattr(session, 'options', {}).get('adobe_pdf_timeout', 120))


def plot_single_pdf(source_path, output_pdf, settings):
    from pathlib import Path
    return plot_batch_pdf([{"source":str(source_path),"output":str(output_pdf),"settings":settings,"label":Path(source_path).name}])[0]


def _apply_shared_plot_paths(app, options):
    """Temporarily append optional shared PC3/plot-style folders. Returns original values."""
    originals={}
    if not options or not options.get("shared_plot_resources_enabled"): return originals
    try: files=app.Preferences.Files
    except Exception: return originals
    for attr,key in (("PrinterConfigPath","shared_pc3_path"),("PrinterStyleSheetPath","shared_plot_style_path")):
        extra=str(options.get(key,"") or "").strip()
        if not extra: continue
        try:
            old=str(getattr(files,attr) or ""); originals[attr]=old
            parts=[x for x in old.split(";") if x]
            if extra.casefold() not in {x.casefold() for x in parts}: setattr(files,attr, old+(";" if old else "")+extra)
        except Exception: pass
    return originals

def _restore_shared_plot_paths(app, originals):
    if not originals: return
    try: files=app.Preferences.Files
    except Exception: return
    for attr,value in originals.items():
        try: setattr(files,attr,value)
        except Exception: pass


class AutoCADBatchSession:
    """One AutoCAD connection for one ACadPresetter output batch.

    The default is one dedicated hidden instance. Only that owned instance is
    hidden and closed. An explicitly reused user's instance is never hidden.
    """
    def __init__(self, connection_options=None):
        self.options=dict(connection_options or {})
        self.backend=AutoCADBackend()
        self.app=None
        self.shared_originals={}
        self._window_guard=None
        from .adobe_distiller import AdobeDistiller
        self.distiller=AdobeDistiller()

    def open(self):
        if self.app is not None:
            self.backend.ensure_alive()
            return self
        dedicated=bool(self.options.get("dedicated_hidden",True))
        prefer_running=False if dedicated else bool(self.options.get("prefer_running",True))
        selected_year=self.options.get("selected_year","自動")
        # Batch output uses a dedicated hidden instance by default. Existing user AutoCAD
        # is never hidden and never used unless a caller explicitly disables dedicated mode.
        self.app=self.backend.connect(allow_start=True, visible=False, prefer_running=prefer_running, selected_year=selected_year)
        try:
            if dedicated and self.backend.started_by_us:
                from .autocad_visibility import HiddenWindowGuard
                self._window_guard=HiddenWindowGuard(getattr(self.app,"HWND",0))
                self._window_guard.start()
                self.ensure_hidden()
            self.shared_originals=_apply_shared_plot_paths(self.app,self.options)
        except Exception:
            self.close()
            raise
        return self

    def ensure_hidden(self):
        if self.app is None or not self.backend.started_by_us or not self.options.get("dedicated_hidden",True):
            return
        try:
            self.app.Visible=False
            if self._window_guard: self._window_guard.hide_now()
            if bool(self.app.Visible):
                raise RuntimeError("Visible=Falseが反映されませんでした。")
        except Exception as e:
            raise AutoCADConnectionLost("専用AutoCADを非表示に維持できないため処理を停止します: "+str(e)) from e

    def close(self):
        app=self.app
        owned=bool(self.backend.started_by_us)
        if app is not None:
            try: _restore_shared_plot_paths(app,self.shared_originals)
            except Exception: pass
        # Stop the Win32 hide thread before destroying AutoCAD windows.  Keeping the
        # guard alive during Application.Quit creates a race against disappearing HWNDs.
        if self._window_guard is not None:
            self._window_guard.close()
            self._window_guard=None
        if app is not None:
            # A dedicated instance created by ACadPresetter is safe to close after the batch.
            # Never Quit an AutoCAD instance that was already owned by the user.
            if owned and bool(self.options.get("quit_started_instance",True)):
                try: app.Quit()
                except Exception: pass
        self.distiller.close()
        self.shared_originals={}
        self.backend.disconnect()
        self.app=None

    def __enter__(self):
        return self.open()

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False


def _keep_session_hidden(session):
    hide=getattr(session,"ensure_hidden",None)
    if hide is not None: hide()


def _safe_close_owned_document(session, doc, source=None):
    """Close a document we opened and fail hard if AutoCAD refuses.

    Trial10g proved that discarding the COM reference after a failed Close(False) is
    dangerous: the drawing remains in AutoCAD and the next drawing may be opened on
    top of an unexpected modal/dirty state.  Keep this strict and let batch callers
    stop the remaining work.
    """
    if doc is None:
        return True
    label=str(source or "").strip()
    if not label:
        for attr in ("FullName","Name"):
            try:
                label=str(getattr(doc,attr) or "").strip()
                if label: break
            except Exception:
                pass
    if not label:
        label="（不明な図面）"
    try:
        doc.Close(False)
    except Exception as exc:
        raise AutoCADUnsafeState(
            f"図面を安全に閉じられませんでした: {label}\n"
            "次の図面は開かず、バッチを停止します。\n" + str(exc)
        ) from exc
    try:
        _keep_session_hidden(session)
    except Exception as exc:
        raise AutoCADUnsafeState(
            f"図面を閉じた後にAutoCADの安全状態を確認できませんでした: {label}\n"
            "次の図面は開かず、バッチを停止します。\n" + str(exc)
        ) from exc
    return True


def _open_for_session(session,source):
    # AutoCAD frequently attempts to show/activate its frame during Documents.Open.
    # Keep the owned process hidden before and immediately after the COM call.
    _keep_session_hidden(session)
    if getattr(session, "_window_guard", None):
        session._window_guard.hide_now()
    doc,owned=_acquire_document(session.app,source)
    try:
        _keep_session_hidden(session)
        if getattr(session, "_window_guard", None):
            session._window_guard.hide_now()
    except Exception as original:
        if owned:
            try:
                _safe_close_owned_document(session,doc,source)
            except Exception as close_exc:
                raise close_exc from original
        raise
    return doc,owned


def plot_batch_pdf(jobs, progress=None, should_cancel=None, connection_options=None, session=None):
    """Plot PDFs without saving source drawings. Reuses one hidden batch session."""
    from pathlib import Path
    own_session=session is None
    session=session or AutoCADBatchSession(connection_options)
    if own_session: session.open()
    app=session.app; results=[]
    try:
        total=len(jobs)
        for i,job in enumerate(jobs,1):
            if should_cancel and should_cancel():
                results.append({"status":"cancelled","source":job["source"],"message":"中止"}); break
            doc=None; owned=False; layout=None; state=None; active=None; bg=None; fatal=False; device=""; close_error=None; restore_error=None
            trace=[]; result_start=len(results)
            def pulse():
                _keep_session_hidden(session)
                if progress: progress(i,total,job.get("label",Path(job["source"]).name),"wait_pdf")
            try:
                src=Path(job["source"]); out=Path(job["output"]); out.parent.mkdir(parents=True,exist_ok=True)
                if not src.exists(): raise RuntimeError(f"CADファイルがありません: {src}")
                if progress: progress(i,total,job.get("label",src.name),"open")
                trace.append(f"図面を開く: {src}")
                doc,owned=_open_for_session(session,src)
                trace.append("印刷設定の適用・実値の検証を開始")
                layout,state,active,device,_=_prepare_plot(doc,job["settings"])
                trace.append(f"印刷設定の検証完了: {device} / {getattr(layout,'Name','')}")
                bg=_set_sync_plot(doc)
                _keep_session_hidden(session)
                if progress: progress(i,total,job.get("label",src.name),"plot")
                ok=_plot_pdf_to_file(doc,out,device,converter=getattr(session,"distiller",None),
                                     keep_hidden=pulse, log=trace.append,
                                     adobe_watch_dir=getattr(session,"options",{}).get("adobe_pdf_watch_dir",""),
                                     adobe_timeout=_adobe_timeout(session), source_path=src)
                _keep_session_hidden(session)
                results.append({"status":"ok","source":str(src),"output":str(out),"plot_result":bool(ok),"opened_by_app":owned})
            except Exception as e:
                fatal=_looks_like_connection_loss(e)
                msg=str(e)
                trace.append("失敗: "+msg)
                try:
                    from .adobe_pdf import is_adobe_pdf_device, adobe_pdf_generation_hint
                    if device and is_adobe_pdf_device(device) and "Adobe PDFの場合" not in msg:
                        msg += "\n" + adobe_pdf_generation_hint()
                except Exception:
                    pass
                results.append({"status":"fatal" if fatal else "error","source":job["source"],"message":msg})
                if fatal:
                    # Remaining drawings are unprocessed, not failed.
                    for rest in jobs[i:]:
                        results.append({"status":"unprocessed","source":rest["source"],"message":"AutoCAD接続断のため未処理"})
            finally:
                if result_start < len(results) and trace:
                    results[result_start]["trace"]=trace[-500:]
                if doc is not None:
                    try:
                        _restore_plot_document(doc,layout,state,active,bg)
                    except Exception as exc:
                        restore_error=exc
                    if owned:
                        try:
                            _safe_close_owned_document(session,doc,job.get("source"))
                        except Exception as exc:
                            close_error=exc
            if close_error is not None or restore_error is not None:
                fatal=True
                errors="\n".join(str(e) for e in (restore_error,close_error) if e is not None)
                if result_start<len(results) and results[result_start].get("source")==job.get("source"):
                    prior=results[result_start].get("message","")
                    results[result_start]["status"]="fatal"
                    results[result_start]["message"]=(prior+"\n" if prior else "")+errors
                    results[result_start].setdefault("trace",[]).append("復元・終了時の失敗: "+errors)
                else:
                    results.append({"status":"fatal","source":job.get("source"),"message":errors})
                for rest in jobs[i:]:
                    if not any(x.get("status")=="unprocessed" and x.get("source")==rest.get("source") for x in results):
                        message="前の図面を閉じられなかったため未処理" if close_error is not None else "元の印刷設定を復元できなかったため未処理"
                        results.append({"status":"unprocessed","source":rest["source"],"message":message})
            if progress: progress(i,total,job.get("label",Path(job["source"]).name),"done")
            if fatal: break
        return results
    finally:
        if own_session: session.close()


def print_batch(jobs, progress=None, should_cancel=None, connection_options=None, session=None):
    """Physical print with the same ownership/restore rules as PDF plotting."""
    from pathlib import Path
    own_session=session is None
    session=session or AutoCADBatchSession(connection_options)
    if own_session: session.open()
    app=session.app; results=[]
    try:
        total=len(jobs)
        for i,job in enumerate(jobs,1):
            if should_cancel and should_cancel(): results.append({"status":"cancelled","source":job["source"],"message":"中止"}); break
            doc=None; owned=False; layout=None; state=None; active=None; bg=None; fatal=False; close_error=None; restore_error=None; result_start=len(results)
            try:
                src=Path(job["source"]); st=job["settings"]
                if progress: progress(i,total,job.get("label",src.name),"open")
                doc,owned=_open_for_session(session,src)
                explicit_layout=job.get("layout")
                layout,state,active,device,_=_prepare_plot(doc,st,explicit_layout)
                bg=_set_sync_plot(doc); copies=max(1,int(st.get("copies",1))); printed=0
                _keep_session_hidden(session)
                if progress: progress(i,total,job.get("label",src.name),"print")
                for _ in range(copies):
                    if should_cancel and should_cancel(): break
                    if not doc.Plot.PlotToDevice():
                        raise RuntimeError(f"AutoCADが印刷を送信できませんでした（{printed}/{copies}部送信済み）。")
                    printed += 1
                    _keep_session_hidden(session)
                if printed < copies:
                    results.append({"status":"cancelled","source":str(src),"layout":job.get("layout",""),"device":device,"copies":copies,"printed_copies":printed,"message":f"中止（{printed}/{copies}部印刷済み）","opened_by_app":owned})
                else:
                    results.append({"status":"ok","source":str(src),"layout":job.get("layout",""),"device":device,"copies":copies,"printed_copies":printed,"opened_by_app":owned})
            except Exception as e:
                fatal=_looks_like_connection_loss(e)
                results.append({"status":"fatal" if fatal else "error","source":job["source"],"layout":job.get("layout",""),"message":str(e)})
                if fatal:
                    for rest in jobs[i:]: results.append({"status":"unprocessed","source":rest["source"],"message":"AutoCAD接続断のため未処理"})
            finally:
                if doc is not None:
                    try:
                        _restore_plot_document(doc,layout,state,active,bg)
                    except Exception as exc:
                        restore_error=exc
                    if owned:
                        try:
                            _safe_close_owned_document(session,doc,job.get("source"))
                        except Exception as exc:
                            close_error=exc
            if close_error is not None or restore_error is not None:
                fatal=True
                errors="\n".join(str(e) for e in (restore_error,close_error) if e is not None)
                if result_start<len(results) and results[result_start].get("source")==job.get("source"):
                    prior=results[result_start].get("message","")
                    results[result_start]["status"]="fatal"
                    results[result_start]["message"]=(prior+"\n" if prior else "")+errors
                else:
                    results.append({"status":"fatal","source":job.get("source"),"message":errors})
                for rest in jobs[i:]:
                    if not any(x.get("status")=="unprocessed" and x.get("source")==rest.get("source") for x in results):
                        message="前の図面を閉じられなかったため未処理" if close_error is not None else "元の印刷設定を復元できなかったため未処理"
                        results.append({"status":"unprocessed","source":rest["source"],"message":message})
            if progress: progress(i,total,job.get("label",Path(job["source"]).name),"done")
            if fatal: break
        return results
    finally:
        if own_session: session.close()

def save_page_setup(source_path, settings, setup_name=None, backup_dir=None, connection_options=None):
    """Explicitly save plot settings into the DWG/DXF through a dedicated hidden AutoCAD.

    This command intentionally modifies the source drawing, but it must not borrow or
    expose the user's interactive AutoCAD instance. A backup is created first when
    ``backup_dir`` is supplied.
    """
    from pathlib import Path
    import shutil, time
    src=Path(source_path)
    if not src.exists(): raise RuntimeError(f"CADファイルがありません: {src}")
    backup=None
    if backup_dir:
        bd=Path(backup_dir); bd.mkdir(parents=True,exist_ok=True)
        stamp=time.strftime("%Y%m%d_%H%M%S")
        backup=bd/f"{src.stem}_{stamp}{src.suffix}"
        n=2
        while backup.exists():
            backup=bd/f"{src.stem}_{stamp}_{n}{src.suffix}"; n+=1
        shutil.copy2(src,backup)

    options={**(connection_options or {}),"dedicated_hidden":True}
    session=AutoCADBatchSession(options); doc=None; owned=False
    session.open()
    try:
        doc,owned=_open_for_session(session,src)
        if bool(getattr(doc,"ReadOnly",False)):
            raise RuntimeError("CADファイルが読み取り専用のため設定を保存できません。別のAutoCADで開かれていないか確認してください。")
        layout=doc.ActiveLayout
        try: layout.RefreshPlotDeviceInfo()
        except Exception: pass
        device=settings.get("device",""); media=settings.get("paper",""); style=settings.get("plot_style","")
        if device: layout.ConfigName=device
        try: layout.RefreshPlotDeviceInfo()
        except Exception: pass
        if media: layout.CanonicalMediaName=media
        if style: layout.StyleSheet=style
        rotmap={"0°":0,"90°":1,"180°":2,"270°":3}
        rot=settings.get("rotation","0°")
        if rot in rotmap:
            try: layout.PlotRotation=rotmap[rot]
            except Exception: pass

        # Create/update a named PlotConfiguration from the active layout when supported.
        name=setup_name or ("ACadPresetter_"+settings.get("name","Plot"))
        pc=None
        try:
            pcs=doc.PlotConfigurations
            try: pc=pcs.Item(name)
            except Exception:
                pc=pcs.Add(name, layout.ModelType)
            try: pc.CopyFrom(layout)
            except Exception: pass
        except Exception:
            pc=None

        _apply_plot_settings(layout,settings)
        session.ensure_hidden()
        doc.Save()
        session.ensure_hidden()
        return {"source":str(src),"backup":str(backup) if backup else None,
                "setup_name":name,"named_setup":bool(pc)}
    finally:
        close_exc=None
        if doc is not None and owned:
            try:
                _safe_close_owned_document(session,doc,src)
            except Exception as exc:
                close_exc=exc
        session.close()
        if close_exc is not None:
            raise close_exc

def list_layouts(source_path, session=None, connection_options=None):
    """List Model/Layout names. Reuse the caller's hidden batch session when supplied."""
    from pathlib import Path
    src=Path(source_path); own_session=session is None
    session=session or AutoCADBatchSession({**(connection_options or {}),"dedicated_hidden":True})
    if own_session: session.open()
    app=session.app; doc=None; owned=False
    try:
        doc,owned=_open_for_session(session,src)
        rows=[]
        for lay in doc.Layouts:
            rows.append({"name":str(lay.Name),"model":bool(getattr(lay,"ModelType",False))})
        return rows
    finally:
        close_exc=None
        if doc is not None and owned:
            try:
                _safe_close_owned_document(session,doc,src)
            except Exception as exc:
                close_exc=exc
        if own_session: session.close()
        if close_exc is not None:
            raise close_exc


def plot_layouts_pdf(source_path, outputs, settings, layout_names, progress=None, should_cancel=None, connection_options=None, session=None):
    """Plot requested layouts through the shared hidden batch AutoCAD session."""
    from pathlib import Path
    src=Path(source_path); own_session=session is None
    session=session or AutoCADBatchSession(connection_options)
    if own_session: session.open()
    app=session.app; results=[]; doc=None; owned=False; bg=None; fatal=False
    try:
        doc,owned=_open_for_session(session,src); bg=_set_sync_plot(doc); total=len(layout_names)
        for i,name in enumerate(layout_names,1):
            if should_cancel and should_cancel(): results.append({"status":"cancelled","source":str(src),"layout":name,"message":"中止"}); break
            layout=state=active=None; device=""
            trace=[]; result_start=len(results)
            def pulse():
                _keep_session_hidden(session)
                if progress: progress(i,total,f"{src.name} / {name}","wait_pdf")
            try:
                trace.append(f"印刷設定の適用・実値の検証を開始: {src} / {name}")
                layout,state,active,device,_=_prepare_plot(doc,settings,name)
                trace.append(f"印刷設定の検証完了: {device} / {name}")
                _keep_session_hidden(session)
                out=Path(outputs[name]); out.parent.mkdir(parents=True,exist_ok=True)
                if progress: progress(i,total,f"{src.name} / {name}","plot")
                ok=_plot_pdf_to_file(doc,out,device,converter=getattr(session,"distiller",None),
                                     keep_hidden=pulse, log=trace.append,
                                     adobe_watch_dir=getattr(session,"options",{}).get("adobe_pdf_watch_dir",""),
                                     adobe_timeout=_adobe_timeout(session), source_path=src)
                _keep_session_hidden(session)
                results.append({"status":"ok","source":str(src),"layout":name,"output":str(out),"plot_result":bool(ok)})
            except Exception as e:
                fatal=_looks_like_connection_loss(e)
                msg=str(e)
                trace.append("失敗: "+msg)
                try:
                    from .adobe_pdf import is_adobe_pdf_device, adobe_pdf_generation_hint
                    if device and is_adobe_pdf_device(device) and "Adobe PDFの場合" not in msg:
                        msg += "\n" + adobe_pdf_generation_hint()
                except Exception:
                    pass
                results.append({"status":"fatal" if fatal else "error","source":str(src),"layout":name,"message":msg})
            finally:
                if result_start < len(results) and trace:
                    results[result_start]["trace"]=trace[-500:]
                if layout is not None and state is not None:
                    try:
                        _restore_after_plot(doc,layout,state,active,strict=True)
                    except Exception as exc:
                        fatal=True
                        errors=str(exc)
                        if result_start<len(results):
                            prior=results[result_start].get("message","")
                            results[result_start]["status"]="fatal"
                            results[result_start]["message"]=(prior+"\n" if prior else "")+errors
                            results[result_start].setdefault("trace",[]).append("復元時の失敗: "+errors)
                        else:
                            results.append({"status":"fatal","source":str(src),"layout":name,"message":errors})
            if progress: progress(i,total,f"{src.name} / {name}","done")
            if fatal:
                for rest in layout_names[i:]:
                    results.append({"status":"unprocessed","source":str(src),"layout":rest,"message":"AutoCAD接続断のため未処理"})
                break
        return results
    finally:
        cleanup_errors=[]
        if doc is not None:
            try:
                _restore_sync_plot(doc,bg,strict=True)
            except Exception as exc:
                cleanup_errors.append(str(exc))
            if owned:
                try:
                    _safe_close_owned_document(session,doc,src)
                except Exception as exc:
                    cleanup_errors.append(str(exc))
        if cleanup_errors:
            message="\n".join(cleanup_errors)
            # Keep the layout identity so the UI updates the existing history
            # entry rather than creating an unmatchable generic PDF failure.
            target=next((row for row in reversed(results) if row.get("status")!="unprocessed"),None)
            if target is not None:
                prior=target.get("message","")
                target["status"]="fatal"
                target["message"]=(prior+"\n" if prior else "")+message
                target.setdefault("trace",[]).append("復元・終了時の失敗: "+message)
            else:
                results.append({"status":"fatal","source":str(src),"message":message})
        if own_session: session.close()


def read_dwg_plot_settings(source_path, layout_name=None):
    """Read one layout through the same dedicated hidden inspection session."""
    info=inspect_drawing_plot_settings(source_path,connection_options={"dedicated_hidden":True})
    wanted=layout_name if layout_name is not None else info["active_layout"]
    for row in info["layouts"]:
        if row["name"].casefold()==str(wanted).casefold():
            return {**row["settings"],"layout":row["name"]}
    raise RuntimeError("指定Layoutがありません。")


def inspect_drawing_plot_settings(source_path, session=None, connection_options=None):
    """Read Model/all Layout plot settings in one hidden open/close cycle."""
    from pathlib import Path
    src=Path(source_path); own_session=session is None
    session=session or AutoCADBatchSession({**(connection_options or {}),"dedicated_hidden":True})
    if own_session: session.open()
    app=session.app; doc=None; owned=False
    try:
        doc,owned=_open_for_session(session,src)
        active=str(getattr(getattr(doc,"ActiveLayout",None),"Name","") or "")
        rows=[]
        pt={0:"表示範囲",1:"図形範囲",2:"図面範囲",3:"ビュー",4:"窓",5:"レイアウト"}
        rot={0:"0°",1:"90°",2:"180°",3:"270°"}
        for layout in doc.Layouts:
            try: layout.RefreshPlotDeviceInfo()
            except Exception: pass
            def g(n,d=None):
                try:return getattr(layout,n)
                except Exception:return d
            canonical_paper=str(g("CanonicalMediaName","") or "")
            try:
                locale_paper=str(layout.GetLocaleMediaName(canonical_paper) or "") if canonical_paper else ""
            except Exception:
                locale_paper=""
            _use_std=bool(g("UseStandardScale",True))
            _std_index=int(g("StandardScale",0) or 0)
            _scale_mode=("fit" if _use_std and _std_index==0 else ("standard" if _use_std else "custom"))
            st={"layout":str(layout.Name),"device":str(g("ConfigName","") or ""),"paper":canonical_paper,"paper_display":locale_paper or canonical_paper,
                "plot_style":str(g("StyleSheet","") or ""),"plot_area":pt.get(g("PlotType"),"レイアウト"),
                "center_plot":bool(g("CenterPlot",True)),"fit_to_paper":_scale_mode=="fit",
                "scale_mode":_scale_mode,"use_standard_scale":_use_std,"standard_scale_index":_std_index,
                "paper_units":g("PaperUnits",None),
                "lineweights":bool(g("PlotWithLineweights",True)),"transparency":bool(g("PlotTransparency",False)),
                "plot_styles":bool(g("PlotWithPlotStyles",True)),"rotation":rot.get(g("PlotRotation"),"0°")}
            try:o=g("PlotOrigin"); st["offset_x"],st["offset_y"]=float(o[0]),float(o[1])
            except Exception: st["offset_x"],st["offset_y"]=0.0,0.0
            try:
                n,d=_get_custom_scale(layout); st["scale_num"],st["scale_den"]=float(n),float(d)
                st["custom_scale_unavailable"]=False
            except Exception:
                # Do not fabricate 1:1.  Explicit None survives normalization
                # and tells the apply path to preserve the target's scale.
                st["scale_num"],st["scale_den"]=None,None
                st["custom_scale_unavailable"]=not bool(g("UseStandardScale",True))
            if st.get("scale_mode")=="standard":
                # acPlotScale enumeration (not acViewportScale).
                index=int(g("StandardScale",0))
                ratio=PLOT_SCALE_RATIOS.get(index)
                if ratio is None:
                    raise RuntimeError(f"印刷尺度を取得できません: {layout.Name} / {index}")
                st["scale_num"],st["scale_den"]=ratio
            st["orientation"]="横" if st.get("rotation") in ("90°","270°") else "縦"
            if st.get("plot_area")=="窓":
                try:
                    p1,p2=_get_window_points(layout)
                    st["window_x1"],st["window_y1"]=p1
                    st["window_x2"],st["window_y2"]=p2
                except Exception: pass
            rows.append({"name":str(layout.Name),"model":bool(g("ModelType",False)),"settings":st})
        return {"drawing":str(src),"active_layout":active,"layouts":rows}
    finally:
        close_exc=None
        if doc is not None and owned:
            try:
                _safe_close_owned_document(session,doc,src)
            except Exception as exc:
                close_exc=exc
        if own_session: session.close()
        if close_exc is not None:
            raise close_exc
