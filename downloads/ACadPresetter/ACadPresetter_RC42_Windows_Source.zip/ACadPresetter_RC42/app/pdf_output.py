from __future__ import annotations

import os
import shutil
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass
class StagedPdf:
    source: str
    final_path: str
    temp_path: str
    label: str = ""


class PdfOutputSession:
    """One output-run staging area. Existing final PDFs are never touched until commit."""
    def __init__(self, root: str | Path | None = None):
        base = Path(root) if root else Path(tempfile.gettempdir()) / "ACadPresetter"
        base.mkdir(parents=True, exist_ok=True)
        self.run_dir = base / ("run_" + uuid.uuid4().hex[:12])
        self.run_dir.mkdir(parents=True, exist_ok=False)
        self._items: list[StagedPdf] = []
        self._protected_paths: set[Path] = set()
        self._retained_paths: dict[Path, Path] = {}

    def stage(self, source: str, final_path: str, label: str = "") -> StagedPdf:
        final = Path(final_path)
        temp = self.run_dir / f"{len(self._items)+1:05d}_{uuid.uuid4().hex[:8]}.pdf"
        item = StagedPdf(str(source), str(final), str(temp), label)
        self._items.append(item)
        return item

    @staticmethod
    def validate_pdf(path: str | Path) -> None:
        p = Path(path)
        if not p.exists() or p.stat().st_size < 5:
            raise RuntimeError("生成されたPDFを確認できませんでした。")
        try:
            from pypdf import PdfReader
            with p.open("rb") as f:
                if f.read(5) != b"%PDF-":
                    raise ValueError("PDFヘッダーがありません")
                f.seek(0)
                reader = PdfReader(f, strict=True)
                if reader.is_encrypted:
                    raise ValueError("暗号化された生成PDFです")
                if not reader.pages:
                    raise ValueError("ページがありません")
                for page in reader.pages:
                    # Resolve page dictionaries and content streams, not just the header.
                    _ = page.mediabox
                    contents = page.get_contents()
                    if contents is not None:
                        contents.get_data()
        except Exception as exc:
            raise RuntimeError("生成ファイルが正常なPDFではありません: " + str(exc)) from exc

    @staticmethod
    def atomic_commit(temp_path: str | Path, final_path: str | Path) -> str:
        src, dst = Path(temp_path), Path(final_path)
        PdfOutputSession.validate_pdf(src)
        dst.parent.mkdir(parents=True, exist_ok=True)
        # Same-volume replace is atomic. For a different volume, copy beside destination first.
        beside = dst.parent / ("." + dst.name + ".acadpresetter_" + uuid.uuid4().hex[:8] + ".tmp")
        try:
            shutil.copy2(src, beside)
            PdfOutputSession.validate_pdf(beside)
            os.replace(beside, dst)
            # Network/server destinations are allowed. Verify the final file really
            # exists there before reporting success so a staging-only PDF can never
            # be mistaken for a completed output.
            PdfOutputSession.validate_pdf(dst)
        finally:
            try:
                if beside.exists(): beside.unlink()
            except OSError:
                pass
        return str(dst)

    def retain_failed(self, temp_path: str | Path, recovery_root: str | Path) -> str:
        """Keep a failed final output recoverable before transient cleanup.

        Adobe's driver folder must be available for the next ``(1)`` output,
        so retention belongs to this session rather than the driver folder.
        Prefer a validated copy under the application's persistent recovery
        directory. If that directory is locked/full/unavailable, protect the
        existing staging file instead; cleanup remains safe on repeated calls.
        """
        src = Path(temp_path).resolve()
        # Even inspecting a locked staging file can fail on Windows. Protect it
        # before testing its existence so a recovery error never exposes it to
        # unconditional cleanup.
        self._protected_paths.add(src)
        previous = self._retained_paths.get(src)
        try:
            if previous is not None and previous.is_file():
                self._protected_paths.discard(src)
                return str(previous)
            if not src.is_file():
                raise FileNotFoundError(f"復旧用の生成PDFがありません: {src}")
        except PermissionError:
            return str(src)

        # Protect first, before any operation on the potentially unavailable
        # recovery destination. Never require another successful disk write to
        # preserve the only remaining copy of an already generated PDF.
        try:
            destination = Path(recovery_root).resolve() / self.run_dir.name / src.name
            if destination.is_relative_to(self.run_dir.resolve()):
                return str(src)
            self.atomic_commit(src, destination)
            self._retained_paths[src] = destination
            self._protected_paths.discard(src)
            return str(destination)
        except Exception:
            # The caller receives the actual remaining path and can include it
            # in the output error/history. A later call may retry the backup.
            return str(src)

    def cleanup(self) -> None:
        if not self._protected_paths:
            shutil.rmtree(self.run_dir, ignore_errors=True)
            return

        def clean(directory: Path) -> None:
            try:
                entries = list(directory.iterdir())
            except OSError:
                return
            for entry in entries:
                try:
                    if entry.resolve() in self._protected_paths:
                        continue
                    if entry.is_dir() and not entry.is_symlink():
                        clean(entry)
                    else:
                        entry.unlink()
                except OSError:
                    pass
            try:
                directory.rmdir()
            except OSError:
                pass

        clean(self.run_dir)


def existing_outputs(paths: Iterable[str]) -> list[str]:
    return [str(Path(p)) for p in paths if Path(p).exists()]


def classify_existing(paths: Iterable[str], action: str) -> tuple[set[str], set[str]]:
    """Return (write, skip), case-insensitive absolute-ish keys."""
    keys = {str(Path(p)).casefold() for p in paths}
    if action == "スキップする":
        return set(), keys
    return keys, set()
