"""Adobe/AutoCAD workflow audit: exercise failures through real backend routing.

COM stand-ins model observable state changes; no Windows driver is emulated.
"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import time

import pytest

from pdf_fixtures import write_pdf
from app import adobe_device_output as adobe
from app import autocad_backend as backend


class Clock:
    def __init__(self):
        self.elapsed = 0.0
        self.wall = time.time()

    def time(self):
        return self.wall + self.elapsed

    def monotonic(self):
        return self.elapsed

    def sleep(self, seconds):
        self.elapsed += seconds


@pytest.fixture
def clock(monkeypatch):
    clock = Clock()
    monkeypatch.setattr(adobe, 'time', clock)
    return clock


def document(source, watch_dir, fail_after_queue=False):
    variables = {'CMDACTIVE': 0, 'CMDNAMES': '', 'BACKGROUNDPLOT': 2}
    layout = SimpleNamespace(Name='Sheet1', ConfigName='Adobe PDF')
    commands = []

    def send(command):
        commands.append(command)
        if fail_after_queue:
            # A SendCommand error is not evidence that its queued command was
            # cancelled. The backend must not open the next drawing here.
            variables.update(CMDACTIVE=1, CMDNAMES='-PLOT')
            raise RuntimeError('driver failed after command was queued')
        write_pdf(watch_dir / adobe.adobe_generated_name(source))

    return SimpleNamespace(
        FullName=str(source), ActiveLayout=layout, GetVariable=lambda name:variables[name],
        SetVariable=lambda name,value:variables.update({name:value}), SendCommand=send,
        Close=Mock(), variables=variables, commands=commands,
    )


@pytest.mark.parametrize('multi_layout', [False, True])
def test_partly_queued_sendcommand_failure_stops_following_work(tmp_path, clock, monkeypatch, multi_layout):
    """User-owned documents have no Close(False) fallback to catch a busy command."""
    first_source = tmp_path / 'first.dwg'
    second_source = tmp_path / 'second.dwg'
    first_source.touch()
    second_source.touch()
    first = document(first_source, tmp_path, fail_after_queue=True)
    second = document(second_source, tmp_path)
    opened = []

    def acquire(session, source):
        opened.append(Path(source))
        return (first if Path(source) == first_source else second), False

    monkeypatch.setattr(backend, '_open_for_session', acquire)
    monkeypatch.setattr(backend, '_prepare_plot', lambda doc,*args:(doc.ActiveLayout, {}, doc.ActiveLayout, 'Adobe PDF', False))
    session = SimpleNamespace(app=object(), options={'adobe_pdf_watch_dir': str(tmp_path)})
    if multi_layout:
        results = backend.plot_layouts_pdf(first_source,
            {'Sheet1': tmp_path/'first.pdf', 'Sheet2': tmp_path/'second.pdf'}, {},
            ['Sheet1', 'Sheet2'], session=session)
        assert len(first.commands) == 1, results
    else:
        results = backend.plot_batch_pdf([
            {'source': str(first_source), 'output': str(tmp_path/'first.pdf'), 'settings': {}},
            {'source': str(second_source), 'output': str(tmp_path/'second.pdf'), 'settings': {}},
        ], session=session)
        assert opened == [first_source], results
    assert [row['status'] for row in results] == ['fatal', 'unprocessed'], results
    first.Close.assert_not_called()


@pytest.mark.parametrize('multi_layout', [False, True])
@pytest.mark.parametrize('owned', [False, True])
def test_restore_device_failure_is_visible_in_result(tmp_path, monkeypatch, multi_layout, owned):
    """A successful PDF must not hide a changed printer in a reused drawing."""
    class Layout:
        Name = 'Sheet1'
        fail_restore = False
        device = 'user_original.pc3'

        @property
        def ConfigName(self):
            return self.device

        @ConfigName.setter
        def ConfigName(self, value):
            if value == 'user_original.pc3' and self.fail_restore:
                raise RuntimeError('AutoCAD rejected restoration of original printer')
            self.device = value

        def RefreshPlotDeviceInfo(self):
            pass

    source = tmp_path/'drawing.dwg'
    source.touch()
    layout = Layout()
    doc = SimpleNamespace(ActiveLayout=layout, GetVariable=lambda name:2, SetVariable=Mock(), Close=Mock())

    def prepare(doc, settings, *args):
        state = {'ConfigName': layout.ConfigName}
        layout.ConfigName = 'Adobe PDF'
        return layout, state, layout, 'Adobe PDF', False

    def plot(doc, output, *args, **kwargs):
        write_pdf(output)
        layout.fail_restore = True
        return True

    monkeypatch.setattr(backend, '_open_for_session', lambda *args:(doc, owned))
    monkeypatch.setattr(backend, '_prepare_plot', prepare)
    monkeypatch.setattr(backend, '_plot_pdf_to_file', plot)
    session = SimpleNamespace(app=object(), options={})
    if multi_layout:
        results = backend.plot_layouts_pdf(source, {'Sheet1': tmp_path/'drawing.pdf'}, {}, ['Sheet1'], session=session)
    else:
        results = backend.plot_batch_pdf([
            {'source': str(source), 'output': str(tmp_path/'drawing.pdf'), 'settings': {}},
        ], session=session)
    assert layout.ConfigName == 'Adobe PDF'  # The restore error was observable.
    assert any(row['status'] in {'error', 'fatal'} for row in results), results
    assert any('restoration' in row.get('message', '') for row in results), results
    if owned:
        doc.Close.assert_called_once_with(False)
    else:
        doc.Close.assert_not_called()


def test_multi_layout_background_restore_failure_keeps_layout_identity(tmp_path, monkeypatch):
    """The history update must match the actual PDF:Sheet1 record on cleanup errors."""
    source = tmp_path/'drawing.dwg'
    source.touch()
    layout = SimpleNamespace(Name='Sheet1', ConfigName='Adobe PDF')

    def set_variable(name, value):
        if name == 'BACKGROUNDPLOT' and value == 2:
            raise RuntimeError('cannot restore BACKGROUNDPLOT')

    doc = SimpleNamespace(ActiveLayout=layout, GetVariable=lambda name:2,
        SetVariable=set_variable, Close=Mock())
    monkeypatch.setattr(backend, '_open_for_session', lambda *args:(doc, True))
    monkeypatch.setattr(backend, '_prepare_plot', lambda *args:(layout, {}, layout, 'Adobe PDF', False))

    def plot(doc, output, *args, **kwargs):
        write_pdf(output)
        return True

    monkeypatch.setattr(backend, '_plot_pdf_to_file', plot)
    results = backend.plot_layouts_pdf(source, {'Sheet1': tmp_path/'drawing.pdf'}, {},
        ['Sheet1'], session=SimpleNamespace(app=object(), options={}))
    assert len(results) == 1, results
    assert results[0]['status'] == 'fatal'
    assert results[0]['layout'] == 'Sheet1'
    assert 'BACKGROUNDPLOT' in results[0]['message']
    doc.Close.assert_called_once_with(False)


def test_restore_units_and_rotation_before_coordinates():
    """Model the coordinate reinterpretation explicitly addressed by RC34."""
    class Layout:
        def __init__(self):
            self.units = 1
            self.rotation = 1
            self.window = ((50.0, 50.0), (100.0, 100.0))

        @property
        def PaperUnits(self):
            return self.units

        @PaperUnits.setter
        def PaperUnits(self, value):
            self.units = value
            self.window = ((0.0, 0.0), (5.0, 5.0))

        @property
        def PlotRotation(self):
            return self.rotation

        @PlotRotation.setter
        def PlotRotation(self, value):
            self.rotation = value
            self.window = ((0.0, 0.0), (10.0, 10.0))

        def SetWindowToPlot(self, lower, upper):
            self.window = (lower, upper)

    layout = Layout()
    original = ((1.0, 2.0), (3.0, 4.0))
    assert backend._restore_layout_state(layout,
        {'PaperUnits': 0, 'PlotRotation': 0, 'WindowToPlot': original}) == []
    assert layout.window == original


def test_unused_default_window_does_not_turn_a_successful_plot_into_failure():
    """AutoCAD may report an unset zero rectangle for a non-window layout."""
    setter = Mock()
    layout = SimpleNamespace(PlotType=1, GetWindowToPlot=lambda:((0.0,0.0),(0.0,0.0)),
        SetWindowToPlot=setter)
    state = {'PlotType': 1, 'WindowToPlot': ((0.0,0.0),(0.0,0.0))}
    doc = SimpleNamespace(ActiveLayout=layout)
    assert backend._restore_after_plot(doc, layout, state, layout, strict=True) == []
    setter.assert_not_called()


def test_probe_closes_session_even_when_temporary_document_close_fails(monkeypatch):
    calls = []
    temporary = SimpleNamespace(Close=Mock(side_effect=RuntimeError('cannot close temporary document')))

    class Session:
        def __init__(self, options):
            self.app = SimpleNamespace(Documents=SimpleNamespace(Count=0, Add=lambda:temporary))
            self.backend = SimpleNamespace(started_by_us=True,
                active_plot_environment=lambda:{'devices':['Adobe PDF']})

        def open(self):
            calls.append('open')

        def close(self):
            calls.append('close')

    monkeypatch.setattr(backend, 'AutoCADBatchSession', Session)
    with pytest.raises(backend.AutoCADUnsafeState, match='cannot close temporary document'):
        backend.probe_plot_environment(True)
    assert calls == ['open', 'close']
    temporary.Close.assert_called_once_with(False)


def test_probe_never_adds_a_document_without_confirmed_instance_ownership(monkeypatch):
    add = Mock()
    closed = Mock()

    class Session:
        def __init__(self, options):
            self.app = SimpleNamespace(Documents=SimpleNamespace(Count=0, Add=add))
            self.backend = SimpleNamespace(started_by_us=False, active_plot_environment=lambda:{'devices':[]})

        def open(self):
            pass

        def close(self):
            closed()

    monkeypatch.setattr(backend, 'AutoCADBatchSession', Session)
    assert backend.probe_plot_environment(True) == {'devices':[]}
    add.assert_not_called()
    closed.assert_called_once()


def test_ordinary_preplot_failure_can_continue_to_next_drawing(tmp_path, monkeypatch):
    """Stopping ambiguous queued work must still permit clean pre-plot errors."""
    sources = [tmp_path/'first.dwg', tmp_path/'second.dwg']
    for source in sources:
        source.touch()
    docs = [SimpleNamespace(ActiveLayout=SimpleNamespace(Name='Model', ConfigName='PDF.pc3'),
        GetVariable=lambda name:2, SetVariable=Mock(), Close=Mock()) for _ in sources]
    prepared = []

    def acquire(session, source):
        return docs[sources.index(Path(source))], True

    def prepare(doc, settings, *args):
        prepared.append(doc)
        if doc is docs[0]:
            raise RuntimeError('requested paper does not exist')
        return None, None, None, 'PDF.pc3', False

    def plot(doc, output, *args, **kwargs):
        write_pdf(output)
        return True

    monkeypatch.setattr(backend, '_open_for_session', acquire)
    monkeypatch.setattr(backend, '_prepare_plot', prepare)
    monkeypatch.setattr(backend, '_plot_pdf_to_file', plot)
    session = SimpleNamespace(app=object(), options={})
    results = backend.plot_batch_pdf([
        {'source': str(source), 'output': str(source.with_suffix('.pdf')), 'settings': {}}
        for source in sources
    ], session=session)
    assert [row['status'] for row in results] == ['error', 'ok']
    assert prepared == docs
    for doc in docs:
        doc.Close.assert_called_once_with(False)
