"""Adversarial PDF-output regressions.

Real PDF bytes are used. Frozen metadata, Windows-style creation times and
sharing violations are simulated: these tests do not run AutoCAD or Acrobat.
"""
from pathlib import Path
from types import SimpleNamespace
import os
import time

import pytest
from pypdf import PdfReader

from app import adobe_device_output as adobe
from app.pdf_output import PdfOutputSession
from pdf_fixtures import write_pdf


class Clock:
    def __init__(self):
        self.elapsed = 0.0
        self.wall = time.time()
        self.on_sleep = None

    def time(self):
        return self.wall + self.elapsed

    def monotonic(self):
        return self.elapsed

    def sleep(self, seconds):
        self.elapsed += seconds
        if self.on_sleep is not None:
            self.on_sleep(self.elapsed)


@pytest.fixture
def clock(monkeypatch):
    clock = Clock()
    monkeypatch.setattr(adobe, 'time', clock)
    return clock


def detect(folder, clock, before=None, timeout=4.0):
    return adobe.wait_for_generated_pdf(
        [folder], before or {}, 'sheet', clock.time(), timeout=timeout,
        expected_name='sheet (1).pdf',
    )


@pytest.mark.parametrize('preexisting', [False, True])
def test_same_stat_content_writer_must_finish_before_detection(
    tmp_path, clock, monkeypatch, preexisting,
):
    """A new output and an overwritten output both need content stability."""
    generated = tmp_path / 'sheet (1).pdf'
    write_pdf(generated, 300)
    before = adobe.snapshot_pdfs([tmp_path], expected_name=generated.name) if preexisting else {}
    write_pdf(generated, 400)
    frozen = adobe._file_metadata(generated)
    real_metadata = adobe._file_metadata
    monkeypatch.setattr(
        adobe, '_file_metadata',
        lambda path: frozen if Path(path) == generated else real_metadata(path),
    )
    final_written = []

    def driver_still_writing(elapsed):
        if elapsed < 1.6:
            # Real valid PDFs, equal byte sizes, changing on every observation.
            write_pdf(generated, 400 if round(elapsed * 5) % 2 else 500)
        elif not final_written:
            write_pdf(generated, 600)
            final_written.append(elapsed)

    clock.on_sleep = driver_still_writing
    found = detect(tmp_path, clock, before)
    assert found == generated
    assert final_written, 'An intermediate valid PDF was accepted while the driver was writing'
    assert clock.elapsed >= final_written[0] + 0.6
    assert float(PdfReader(found).pages[0].mediabox.width) == 600


def test_metadata_only_touch_does_not_reuse_an_old_pdf(tmp_path, clock):
    """A timestamp change alone is not proof that a fresh plot was produced."""
    generated = tmp_path / 'sheet (1).pdf'
    original = write_pdf(generated, 300)
    before = adobe.snapshot_pdfs([tmp_path], expected_name=generated.name)
    old_stat = generated.stat()
    os.utime(generated, ns=(old_stat.st_atime_ns, old_stat.st_mtime_ns + 10_000_000_000))
    assert detect(tmp_path, clock, before, timeout=2.0) is None
    assert generated.read_bytes() == original


def test_transient_validation_sharing_violation_is_retried_during_copy(
    tmp_path, clock, monkeypatch,
):
    """validate_pdf wraps an OS sharing violation in RuntimeError."""
    generated = tmp_path / 'sheet (1).pdf'
    contents = write_pdf(generated, 300)
    staged = tmp_path / 'staged.pdf'
    write_pdf(staged, 100)
    real_validate = PdfOutputSession.validate_pdf
    calls = []

    def temporarily_locked(path):
        if str(path).endswith('.adobe_tmp'):
            calls.append(Path(path))
            if len(calls) == 1:
                try:
                    raise PermissionError('Windows sharing violation')
                except OSError as exc:
                    raise RuntimeError('生成ファイルが正常なPDFではありません: ' + str(exc)) from exc
        return real_validate(path)

    monkeypatch.setattr(PdfOutputSession, 'validate_pdf', staticmethod(temporarily_locked))
    assert adobe.finalize_generated_pdf(generated, staged, timeout=1.0) == staged
    assert len(calls) >= 2
    assert staged.read_bytes() == generated.read_bytes() == contents
    assert not list(tmp_path.glob('*.adobe_tmp'))


def test_same_stat_source_change_during_copy_is_not_deleted_or_committed(
    tmp_path, clock, monkeypatch,
):
    """On Windows ctime is creation time; same-size rewrites can preserve stat."""
    generated = tmp_path / 'sheet (1).pdf'
    initial = write_pdf(generated, 300)
    staged = tmp_path / 'staged.pdf'
    old_stage = write_pdf(staged, 100)
    original_stat = generated.stat()
    real_stat = Path.stat
    real_copy = adobe.shutil.copy2
    mutations = []

    def windows_style_stat(path, *args, **kwargs):
        observed = real_stat(path, *args, **kwargs)
        if path == generated:
            fields = {name: getattr(observed, name) for name in dir(observed) if name.startswith('st_')}
            fields['st_ctime'] = original_stat.st_ctime
            fields['st_ctime_ns'] = original_stat.st_ctime_ns
            return SimpleNamespace(**fields)
        return observed

    def copy_then_driver_rewrites(source, target):
        result = real_copy(source, target)
        updated = write_pdf(generated, 400 if len(mutations) % 2 == 0 else 500)
        assert len(updated) == len(initial)
        mutations.append(updated)
        os.utime(generated, ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns))
        return result

    monkeypatch.setattr(Path, 'stat', windows_style_stat)
    monkeypatch.setattr(adobe.shutil, 'copy2', copy_then_driver_rewrites)
    with pytest.raises(RuntimeError, match='取り込めません'):
        adobe.finalize_generated_pdf(generated, staged, remove_generated=True, timeout=0.6)
    assert generated.exists(), 'Concurrent driver output was deleted'
    assert staged.read_bytes() == old_stage
    assert not list(tmp_path.glob('*.adobe_tmp'))


def test_new_file_with_sharing_violation_becomes_usable_after_unlock(
    tmp_path, clock, monkeypatch,
):
    generated = tmp_path / 'sheet (1).pdf'
    write_pdf(generated, 300)
    real_validate = PdfOutputSession.validate_pdf
    locks = []

    def validate_after_unlock(path):
        if clock.elapsed < 2.0:
            locks.append(clock.elapsed)
            raise RuntimeError('生成ファイルが正常なPDFではありません: sharing violation')
        return real_validate(path)

    monkeypatch.setattr(PdfOutputSession, 'validate_pdf', staticmethod(validate_after_unlock))
    assert detect(tmp_path, clock) == generated
    assert clock.elapsed >= 2.0
    assert locks


def test_previous_pdf_with_future_timestamp_is_not_reused(tmp_path, clock):
    generated = tmp_path / 'sheet (1).pdf'
    original = write_pdf(generated, 300)
    os.utime(generated, (clock.wall + 86400, clock.wall + 86400))
    before = adobe.snapshot_pdfs([tmp_path], expected_name=generated.name)
    assert detect(tmp_path, clock, before, timeout=2.0) is None
    assert generated.read_bytes() == original


def test_old_normalized_collision_does_not_hide_fresh_exact_output(tmp_path, clock):
    decomposed_old = tmp_path / 'sheet\u00a0(1).pdf'
    old = write_pdf(decomposed_old, 300)
    before = adobe.snapshot_pdfs([tmp_path], expected_name='sheet (1).pdf')
    exact = tmp_path / 'sheet (1).pdf'
    write_pdf(exact, 400)
    assert detect(tmp_path, clock, before) == exact
    assert decomposed_old.read_bytes() == old


def test_two_fresh_normalized_outputs_are_rejected_even_if_one_is_empty(tmp_path, clock):
    write_pdf(tmp_path / 'sheet (1).pdf', 300)
    (tmp_path / 'sheet\u00a0(1).pdf').touch()
    with pytest.raises(RuntimeError, match='候補が複数'):
        detect(tmp_path, clock)


def test_same_stat_change_during_page_validation_restarts_content_stability(
    tmp_path, clock, monkeypatch,
):
    generated = tmp_path / 'sheet (1).pdf'
    write_pdf(generated, 300)
    frozen = adobe._file_metadata(generated)
    real_metadata = adobe._file_metadata
    real_validate = PdfOutputSession.validate_pdf
    validations = []
    changed_at = []
    monkeypatch.setattr(adobe, '_file_metadata',
                        lambda path: frozen if Path(path) == generated else real_metadata(path))

    def driver_changes_during_validation(path):
        real_validate(path)
        validations.append(clock.elapsed)
        if not changed_at:
            write_pdf(generated, 400)
            changed_at.append(clock.elapsed)

    monkeypatch.setattr(PdfOutputSession, 'validate_pdf', staticmethod(driver_changes_during_validation))
    assert detect(tmp_path, clock) == generated
    assert len(validations) >= 2
    assert clock.elapsed >= changed_at[0] + 0.6
    assert float(PdfReader(generated).pages[0].mediabox.width) == 400


def test_same_stat_change_after_stage_validation_retains_updated_driver_pdf(
    tmp_path, clock, monkeypatch,
):
    generated = tmp_path / 'sheet (1).pdf'
    original = write_pdf(generated, 300)
    staged = tmp_path / 'staged.pdf'
    original_stat = generated.stat()
    real_stat = Path.stat
    real_validate = PdfOutputSession.validate_pdf
    updated = []

    def windows_style_stat(path, *args, **kwargs):
        observed = real_stat(path, *args, **kwargs)
        if path == generated:
            fields = {name: getattr(observed, name) for name in dir(observed) if name.startswith('st_')}
            fields['st_ctime'] = original_stat.st_ctime
            fields['st_ctime_ns'] = original_stat.st_ctime_ns
            return SimpleNamespace(**fields)
        return observed

    monkeypatch.setattr(Path, 'stat', windows_style_stat)

    def driver_changes_after_commit(path):
        real_validate(path)
        if Path(path) == staged:
            updated.append(write_pdf(generated, 400))
            os.utime(generated, ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns))

    monkeypatch.setattr(PdfOutputSession, 'validate_pdf', staticmethod(driver_changes_after_commit))
    assert adobe.finalize_generated_pdf(generated, staged, remove_generated=True) == staged
    assert staged.read_bytes() == original
    assert generated.exists()
    assert generated.read_bytes() == updated[0]


def test_case_matching_does_not_expand_sharp_s_into_another_cad_name(tmp_path, clock):
    generated = tmp_path / 'Strasse (1).pdf'
    write_pdf(generated, 300)
    assert adobe.filename_key('Straße (1).pdf') != adobe.filename_key(generated.name)
    assert adobe._path_key(tmp_path / 'Straße (1).pdf') != adobe._path_key(generated)
    assert adobe.wait_for_generated_pdf(
        [tmp_path], {}, 'Straße', clock.time(), timeout=2,
        expected_name='Straße (1).pdf',
    ) is None
    assert adobe.filename_key('STRAẞE (1).PDF') == adobe.filename_key('Straße (1).pdf')


@pytest.mark.parametrize('failure_state', ['busy', 'unknown', 'idle'])
def test_sendcommand_failure_checks_whether_it_left_queued_work(
    tmp_path, clock, monkeypatch, failure_state,
):
    from app.autocad_backend import AutoCADUnsafeState

    layout = SimpleNamespace(Name='Model', ConfigName='Adobe PDF')

    def send(command):
        raise RuntimeError('SendCommand failed after possible queueing')

    def read_state(name):
        if failure_state == 'unknown':
            raise RuntimeError('RPC state is unavailable')
        if name == 'CMDACTIVE':
            return 1 if failure_state == 'busy' else 0
        return '-PLOT' if failure_state == 'busy' else ''

    doc = SimpleNamespace(ActiveLayout=layout, SendCommand=send,
                          SetVariable=lambda *args: None, GetVariable=read_state)
    monkeypatch.setattr(adobe, '_ensure_command_idle', lambda *args, **kwargs: None)
    error = AutoCADUnsafeState if failure_state != 'idle' else RuntimeError
    match = '後続図面は停止' if failure_state != 'idle' else 'マクロ送信に失敗'
    with pytest.raises(error, match=match) as caught:
        adobe.plot_to_device_pdf(doc, tmp_path / 'staged.pdf', 'Adobe PDF',
                                 preferred_dir=tmp_path, source_path=tmp_path / 'sheet.dwg')
    if failure_state == 'idle':
        assert not isinstance(caught.value, AutoCADUnsafeState)


def test_explicit_watch_folder_named_pdf_is_not_reinterpreted_as_file(tmp_path):
    folder = tmp_path / 'Adobe.output.pdf'
    folder.mkdir()
    assert adobe.candidate_dirs('Adobe PDF', tmp_path / 'sheet.dwg', preferred_dir=folder) == [folder]


def test_disappearing_same_stat_output_must_stabilize_after_reappearance(
    tmp_path, clock, monkeypatch,
):
    generated = tmp_path / 'sheet (1).pdf'
    contents = write_pdf(generated, 300)
    frozen = adobe._file_metadata(generated)
    real_metadata = adobe._file_metadata
    monkeypatch.setattr(adobe, '_file_metadata',
                        lambda path: frozen if Path(path) == generated else real_metadata(path))
    appeared_at = []

    def interrupted_driver_output(elapsed):
        if 0.8 <= elapsed < 1.4:
            generated.unlink(missing_ok=True)
        elif elapsed >= 1.4 and not appeared_at:
            generated.write_bytes(contents)
            appeared_at.append(elapsed)

    clock.on_sleep = interrupted_driver_output
    assert detect(tmp_path, clock) == generated
    assert appeared_at, 'The PDF was accepted before the interrupted output reappeared'
    assert clock.elapsed >= appeared_at[0] + 1.2
