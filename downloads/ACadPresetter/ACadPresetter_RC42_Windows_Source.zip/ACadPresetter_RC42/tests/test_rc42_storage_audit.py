"""RC42 storage fault injection; no real Windows printer/server is required.

The tests use real PDF bytes and file operations. Only the exact OS failure or
concurrent update boundary is injected, so a passing test does not establish
Windows COM, sharing-mode, or SMB integration readiness.
"""
from pathlib import Path
from types import SimpleNamespace
import errno

import pytest
from pypdf import PdfReader

from pdf_fixtures import write_pdf, pdf_bytes
from app import adobe_device_output as adobe
from app import pdf_merge, pdf_output, pdf_postprocess
from app.pdf_output import PdfOutputSession


def _fail_final_replace(monkeypatch, final):
    real_replace = pdf_output.os.replace

    def locked_replace(src, dst):
        if Path(dst) == final:
            raise PermissionError(errno.EACCES, "injected Windows sharing violation", str(dst))
        return real_replace(src, dst)

    monkeypatch.setattr(pdf_output.os, "replace", locked_replace)


def test_atomic_commit_copy_enospc_preserves_original_and_staging(tmp_path, monkeypatch):
    final, staged = tmp_path / "final.pdf", tmp_path / "staged.pdf"
    old, new = write_pdf(final, 100), write_pdf(staged, 200)

    def no_space(src, dst):
        Path(dst).write_bytes(new[:20])
        raise OSError(errno.ENOSPC, "injected destination disk full")

    monkeypatch.setattr(pdf_output.shutil, "copy2", no_space)
    with pytest.raises(OSError, match="disk full"):
        PdfOutputSession.atomic_commit(staged, final)
    assert final.read_bytes() == old
    assert staged.read_bytes() == new
    assert set(tmp_path.iterdir()) == {final, staged}


def test_atomic_commit_locked_destination_preserves_old_and_staging(tmp_path, monkeypatch):
    final, staged = tmp_path / "final.pdf", tmp_path / "staged.pdf"
    old, new = write_pdf(final, 100), write_pdf(staged, 200)
    _fail_final_replace(monkeypatch, final)
    with pytest.raises(PermissionError, match="sharing violation"):
        PdfOutputSession.atomic_commit(staged, final)
    assert final.read_bytes() == old
    assert staged.read_bytes() == new
    assert set(tmp_path.iterdir()) == {final, staged}


def test_adobe_import_copy_failure_preserves_driver_and_old_staging(tmp_path, monkeypatch):
    generated, staged = tmp_path / "sheet (1).pdf", tmp_path / "stage.pdf"
    new, old = write_pdf(generated, 200), write_pdf(staged, 100)

    def denied_copy(src, dst):
        Path(dst).write_bytes(b"partial")
        raise PermissionError("injected driver sharing violation")

    monkeypatch.setattr(adobe.shutil, "copy2", denied_copy)
    with pytest.raises(RuntimeError, match="生成元は保持"):
        adobe.finalize_generated_pdf(generated, staged, remove_generated=True, timeout=0)
    assert generated.read_bytes() == new
    assert staged.read_bytes() == old
    assert set(tmp_path.iterdir()) == {generated, staged}


def test_new_adobe_pdf_survives_final_save_failure_and_session_cleanup(tmp_path, monkeypatch):
    """The actual plotting import must keep a recoverable copy until commit.

    main.MainWindow.output performs session.cleanup() even after commit fails.
    RC42 retains failed staging output in the application's recovery folder;
    leaving Adobe's driver output there would make a later job produce ``(2)``.
    COM plotting and detection are stubbed; the driver-file import, commit, and
    cleanup are production implementations and exercise their complete lifecycle.
    """
    source, final = tmp_path / "sheet.dwg", tmp_path / "final.pdf"
    source.write_bytes(b"cad-source-must-stay")
    old = write_pdf(final, 100)
    generated = tmp_path / "sheet (1).pdf"
    new = pdf_bytes(200)
    session = PdfOutputSession(tmp_path / "staging")
    staged = Path(session.stage(str(source), str(final)).temp_path)
    doc = SimpleNamespace(
        ActiveLayout=SimpleNamespace(Name="Model", ConfigName="Adobe PDF"),
        SetVariable=lambda *_: None,
        GetVariable=lambda name: 0 if name == "CMDACTIVE" else "",
        SendCommand=lambda _: generated.write_bytes(new),
    )
    monkeypatch.setattr(adobe, "_ensure_command_idle", lambda *_a, **_k: None)
    monkeypatch.setattr(adobe, "_wait_macro_complete", lambda *_a, **_k: None)
    monkeypatch.setattr(adobe, "wait_for_generated_pdf", lambda *_a, **_k: generated)
    adobe.plot_to_device_pdf(doc, staged, "Adobe PDF", preferred_dir=tmp_path, source_path=source)
    assert staged.read_bytes() == new
    _fail_final_replace(monkeypatch, final)
    try:
        with pytest.raises(PermissionError, match="sharing violation"):
            session.atomic_commit(staged, final)
        retained = Path(session.retain_failed(staged, tmp_path / "data" / "recovery"))
    finally:
        session.cleanup()
    assert source.read_bytes() == b"cad-source-must-stay"
    assert final.read_bytes() == old
    # A user must be able to recover the successfully generated new PDF even
    # though the selected final folder is locked and transient staging is gone.
    assert retained.exists(), "new Adobe PDF was lost instead of being retained for recovery"
    assert retained.read_bytes() == new


@pytest.mark.parametrize("failure", ["copy", "replace", "mkdir"])
def test_recovery_destination_failure_keeps_failed_staging_through_repeated_cleanup(tmp_path, monkeypatch, failure):
    session = PdfOutputSession(tmp_path / "staging")
    failed = Path(session.stage("failed.dwg", str(tmp_path / "final.pdf")).temp_path)
    normal = Path(session.stage("ok.dwg", str(tmp_path / "ok.pdf")).temp_path)
    generated = write_pdf(failed, 200)
    write_pdf(normal, 100)
    recovery_root = tmp_path / "data" / "recovery"

    def disk_full(*_args, **_kwargs):
        raise OSError(errno.ENOSPC, "injected recovery disk full")

    if failure == "copy":
        monkeypatch.setattr(pdf_output.shutil, "copy2", disk_full)
    elif failure == "replace":
        monkeypatch.setattr(pdf_output.os, "replace", disk_full)
    else:
        real_mkdir = Path.mkdir

        def unavailable_mkdir(path, *args, **kwargs):
            if Path(path).is_relative_to(recovery_root):
                raise PermissionError("injected inaccessible recovery directory")
            return real_mkdir(path, *args, **kwargs)

        monkeypatch.setattr(Path, "mkdir", unavailable_mkdir)
    retained = Path(session.retain_failed(failed, recovery_root))
    assert retained == failed
    for _ in range(3):
        session.cleanup()
        assert retained.read_bytes() == generated
        assert not normal.exists()
    assert session.run_dir.exists()


def test_recovery_success_cleans_staging_but_retains_persistent_copy(tmp_path):
    session = PdfOutputSession(tmp_path / "staging")
    failed = Path(session.stage("failed.dwg", str(tmp_path / "final.pdf")).temp_path)
    generated = write_pdf(failed, 200)
    recovery_root = tmp_path / "data" / "recovery"
    retained = Path(session.retain_failed(failed, recovery_root))
    assert retained.is_relative_to(recovery_root)
    assert retained.read_bytes() == generated
    for _ in range(3):
        session.cleanup()
        assert retained.read_bytes() == generated
        assert not session.run_dir.exists()
    assert Path(session.retain_failed(failed, recovery_root)) == retained


def test_recovery_under_transient_staging_falls_back_to_protecting_original(tmp_path):
    session = PdfOutputSession(tmp_path / "staging")
    failed = Path(session.stage("failed.dwg", str(tmp_path / "final.pdf")).temp_path)
    generated = write_pdf(failed, 200)
    retained = Path(session.retain_failed(failed, session.run_dir / "recovery"))
    assert retained == failed
    session.cleanup()
    session.cleanup()
    assert retained.read_bytes() == generated


def test_merge_fingerprints_describe_exact_consumed_bytes(tmp_path, monkeypatch):
    a, b, output = tmp_path / "a.pdf", tmp_path / "b.pdf", tmp_path / "merged.pdf"
    original_a, original_b = write_pdf(a, 100), write_pdf(b, 200)
    original_hash_a = pdf_merge.pdf_content_fingerprint(a)
    original_hash_b = pdf_merge.pdf_content_fingerprint(b)
    real_replace = pdf_merge.os.replace

    def replace_then_update(src, dst):
        result = real_replace(src, dst)
        a.write_bytes(pdf_bytes(300))
        return result

    monkeypatch.setattr(pdf_merge.os, "replace", replace_then_update)
    fingerprints = {}
    pdf_merge.merge_pdfs([a, b], output, input_fingerprints=fingerprints)
    assert fingerprints == {str(a): original_hash_a, str(b): original_hash_b}
    assert pdf_merge.pdf_content_fingerprint(a) != fingerprints[str(a)]
    assert pdf_merge.pdf_content_fingerprint(b) == fingerprints[str(b)]
    assert b.read_bytes() == original_b and a.read_bytes() != original_a
    assert [float(p.mediabox.width) for p in PdfReader(output).pages] == [100, 200]


def test_merge_delete_retains_input_modified_after_merging(tmp_path, monkeypatch):
    """An editor/network writer must not lose an update not in the merged PDF."""
    import main

    a, b, output = tmp_path / "a.pdf", tmp_path / "b.pdf", tmp_path / "merged.pdf"
    write_pdf(a, 100)
    write_pdf(b, 200)
    updated = pdf_bytes(300)
    real_commit = PdfOutputSession.atomic_commit

    def commit_with_concurrent_update(staged, final):
        result = real_commit(staged, final)
        a.write_bytes(updated)  # Another writer saves after snapshot/merge.
        return result

    monkeypatch.setattr(PdfOutputSession, "atomic_commit", staticmethod(commit_with_concurrent_update))
    plan = {"group": "group", "inputs": [str(a), str(b)], "output": str(output),
            "preset": {"individual": "結合成功後に削除"}}
    main.MainWindow._execute_merge_plans(None, [plan])
    assert [float(p.mediabox.width) for p in PdfReader(output).pages] == [100, 200]
    assert a.exists(), "concurrently updated individual PDF was deleted without being merged"
    assert a.read_bytes() == updated


def test_merge_locked_output_preserves_inputs_and_previous_merge(tmp_path, monkeypatch):
    a, b, final = tmp_path / "a.pdf", tmp_path / "b.pdf", tmp_path / "merged.pdf"
    first, second, old = write_pdf(a, 100), write_pdf(b, 200), write_pdf(final, 300)
    _fail_final_replace(monkeypatch, final)
    with pytest.raises(PermissionError, match="sharing violation"):
        pdf_merge.merge_pdfs([a, b], final)
    assert a.read_bytes() == first and b.read_bytes() == second
    assert final.read_bytes() == old
    assert set(tmp_path.iterdir()) == {a, b, final}


def test_rotation_locked_output_preserves_original_and_cleans_temporary(tmp_path, monkeypatch):
    final = tmp_path / "portrait.pdf"
    original = write_pdf(final, 297 * 72 / 25.4, 420 * 72 / 25.4)
    _fail_final_replace(monkeypatch, final)
    with pytest.raises(PermissionError, match="sharing violation"):
        pdf_postprocess.rotate_a3_a1_left_to_landscape(final)
    assert final.read_bytes() == original
    assert set(tmp_path.iterdir()) == {final}


def test_adobe_import_retries_when_source_changes_during_copy(tmp_path, monkeypatch):
    generated, staged = tmp_path / "sheet (1).pdf", tmp_path / "stage.pdf"
    write_pdf(generated, 100)
    updated = pdf_bytes(200)
    real_copy = adobe.shutil.copy2
    calls = []

    def copy_then_update(src, dst):
        result = real_copy(src, dst)
        calls.append((src, dst))
        if len(calls) == 1:
            generated.write_bytes(updated)
        return result

    monkeypatch.setattr(adobe.shutil, "copy2", copy_then_update)
    adobe.finalize_generated_pdf(generated, staged, timeout=2)
    assert len(calls) >= 2
    assert generated.read_bytes() == updated
    assert staged.read_bytes() == updated
    assert set(tmp_path.iterdir()) == {generated, staged}


@pytest.mark.parametrize("multi_layout", [False, True])
def test_ui_retains_generated_pdf_when_autocad_disconnects_after_staging(tmp_path, monkeypatch, multi_layout):
    """Exercise production UI/backend after the driver copy already succeeded.

    The COM connection disappears on the backend's first visibility check after
    plotting. Adobe import, result routing, history, commit gating, recovery, and
    session cleanup are real. Printer generation, COM/document acquisition, and
    the post-plot COM failure are substituted; no AutoCAD/Acrobat process runs.
    """
    from PySide6.QtWidgets import QApplication
    import main
    from app import autocad_backend as backend

    qt_app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main, "APP_DIR", tmp_path)
    for method in ("warning", "critical", "information"):
        monkeypatch.setattr(main.QMessageBox, method, lambda *_a, **_k: main.QMessageBox.Yes)
    window = main.MainWindow()
    window.store.config["existing_pdf_action"] = "上書きする"
    source = tmp_path / "sheet.dwg"
    source.write_bytes(b"cad-input")
    window.add_file(source)
    monkeypatch.setattr(window, "_preflight_dialog", lambda pdf, print_jobs: (pdf, print_jobs))
    monkeypatch.setattr(window, "_merge_preset_for_collection", lambda: None)
    final = tmp_path / ("final_Sheet1.pdf" if multi_layout else "final.pdf")
    old = write_pdf(final, 100)
    generated = tmp_path / "sheet (1).pdf"
    new = pdf_bytes(200)
    observed_staging = []
    state = {"completed": False}

    def ensure_hidden():
        if state["completed"]:
            raise backend.AutoCADConnectionLost("injected COM disconnected after PDF completed")

    session = SimpleNamespace(app=object(), options={}, ensure_hidden=ensure_hidden,
        open=lambda: None, close=lambda: None)
    monkeypatch.setattr(main, "AutoCADBatchSession", lambda _options: session)
    layout = SimpleNamespace(Name="Sheet1", ConfigName="Adobe PDF")
    doc = SimpleNamespace(ActiveLayout=layout, GetVariable=lambda name: 0,
        SetVariable=lambda *_args: None, Close=lambda *_args: None)
    monkeypatch.setattr(backend, "_open_for_session", lambda *_args: (doc, True))
    monkeypatch.setattr(backend, "_prepare_plot",
        lambda *_args: (layout, {}, layout, "Adobe PDF", False))

    def plot(_doc, output, *_args, **_kwargs):
        generated.write_bytes(new)
        adobe.finalize_generated_pdf(generated, output, remove_generated=True)
        observed_staging.append(Path(output))
        state["completed"] = True
        return True

    monkeypatch.setattr(backend, "_plot_pdf_to_file", plot)
    settings = {"device": "PDF.pc3", "layout_mode": "指定Layout" if multi_layout else "現在のLayout",
                "layout_names": ["Sheet1"]}
    try:
        window._execute_output_jobs([{"source": str(source), "output": str(tmp_path / "final.pdf"),
                                      "settings": settings}], [])
        assert final.read_bytes() == old
        assert not generated.exists()
        candidates = observed_staging + list((tmp_path / "data" / "recovery").glob("**/*.pdf"))
        recovered = [path for path in candidates if path.exists() and path.read_bytes() == new]
        assert recovered, (
            "fatal backend result omitted output, so successful staged PDF was deleted by UI cleanup")
        kind = "PDF:Sheet1" if multi_layout else "PDF"
        record = next(row for row in window.run_history.load()["last"]["jobs"]
                      if row["source"] == str(source) and row["kind"] == kind)
        assert record["status"] == "失敗"
        assert str(recovered[0]) in record["message"]
        assert any(str(recovered[0]) in line for line in record["trace"])
    finally:
        window._output_in_progress = False
        window.close()
        qt_app.processEvents()


@pytest.mark.parametrize("recovery_available", [True, False])
def test_ui_retains_generated_pdf_when_final_commit_fails(tmp_path, monkeypatch, recovery_available):
    """The UI must invoke retention itself after a real final replace fails.

    Real PDFs run through the backend/UI commit path; COM/printer output is
    substituted. Recovery storage is tested both normally and with injected
    disk-full failure, and the displayed/history paths must actually exist.
    """
    from PySide6.QtWidgets import QApplication
    import main
    from app import autocad_backend as backend

    qt_app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main, "APP_DIR", tmp_path)
    displayed = []
    for method in ("critical", "information"):
        monkeypatch.setattr(main.QMessageBox, method, lambda *_a, **_k: main.QMessageBox.Yes)

    def warning(_parent, _title, message, *_args):
        displayed.append(message)
        return main.QMessageBox.Yes

    monkeypatch.setattr(main.QMessageBox, "warning", warning)
    window = main.MainWindow()
    window.store.config["existing_pdf_action"] = "上書きする"
    source = tmp_path / "sheet.dwg"
    source.write_bytes(b"cad-input")
    window.add_file(source)
    monkeypatch.setattr(window, "_preflight_dialog", lambda pdf, print_jobs: (pdf, print_jobs))
    monkeypatch.setattr(window, "_merge_preset_for_collection", lambda: None)
    final = tmp_path / "final.pdf"
    old = write_pdf(final, 100)
    generated = tmp_path / "sheet (1).pdf"
    new = pdf_bytes(200)
    observed_staging = []
    session = SimpleNamespace(app=object(), options={}, ensure_hidden=lambda: None,
        open=lambda: None, close=lambda: None)
    monkeypatch.setattr(main, "AutoCADBatchSession", lambda _options: session)
    layout = SimpleNamespace(Name="Model", ConfigName="Adobe PDF")
    doc = SimpleNamespace(ActiveLayout=layout, GetVariable=lambda name: 0,
        SetVariable=lambda *_args: None, Close=lambda *_args: None)
    monkeypatch.setattr(backend, "_open_for_session", lambda *_args: (doc, True))
    monkeypatch.setattr(backend, "_prepare_plot",
        lambda *_args: (layout, {}, layout, "Adobe PDF", False))

    def plot(_doc, output, *_args, **_kwargs):
        generated.write_bytes(new)
        adobe.finalize_generated_pdf(generated, output, remove_generated=True)
        observed_staging.append(Path(output))
        return True

    monkeypatch.setattr(backend, "_plot_pdf_to_file", plot)
    _fail_final_replace(monkeypatch, final)
    recovery_root = tmp_path / "data" / "recovery"
    if not recovery_available:
        real_copy = pdf_output.shutil.copy2

        def copy_with_full_recovery_disk(src, dst, *args, **kwargs):
            if Path(dst).is_relative_to(recovery_root):
                raise OSError(errno.ENOSPC, "injected recovery disk full")
            return real_copy(src, dst, *args, **kwargs)

        monkeypatch.setattr(pdf_output.shutil, "copy2", copy_with_full_recovery_disk)
    try:
        window._execute_output_jobs([{"source": str(source), "output": str(final),
            "settings": {"device": "PDF.pc3", "layout_mode": "現在のLayout"}}], [])
        assert final.read_bytes() == old
        assert source.read_bytes() == b"cad-input"
        assert not generated.exists()
        candidates = observed_staging + list(recovery_root.glob("**/*.pdf"))
        recovered = [path for path in candidates if path.exists() and path.read_bytes() == new]
        assert len(recovered) == 1
        retained = recovered[0]
        assert retained.is_relative_to(recovery_root) is recovery_available
        assert observed_staging[0].exists() is (not recovery_available)
        record = next(row for row in window.run_history.load()["last"]["jobs"]
                      if row["source"] == str(source) and row["kind"] == "PDF")
        assert record["status"] == "失敗"
        assert "PDF確定失敗" in record["message"]
        assert str(retained) in record["message"]
        assert any(str(retained) in line for line in record["trace"])
        assert any(str(retained) in message for message in displayed)
    finally:
        window._output_in_progress = False
        window.close()
        qt_app.processEvents()
        # The disk-full fallback is intentionally persistent. Remove its test
        # copy explicitly, only after asserting production cleanup preserved it.
        for staged in observed_staging:
            staged.unlink(missing_ok=True)
            if staged.parent.exists():
                staged.parent.rmdir()
