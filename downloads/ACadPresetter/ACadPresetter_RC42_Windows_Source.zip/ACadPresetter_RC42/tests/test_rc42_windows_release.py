"""Windows user workflows that can be exercised without AutoCAD or Acrobat."""
from types import SimpleNamespace
import json
from pathlib import Path

import pytest

from app.adobe_device_output import candidate_dirs
from app.adobe_paths import normalize_watch_dir
from app.autocad_backend import probe_plot_environment
from app.diagnostics import build_diagnostic_report
from app.store import Store
from pdf_fixtures import write_pdf


@pytest.mark.parametrize("input_kind", ["quoted", "environment_variable"])
def test_diagnostics_uses_the_same_adobe_folder_as_printing(tmp_path, monkeypatch, input_kind):
    folder = tmp_path / "Adobe generated PDFs"
    folder.mkdir()
    write_pdf(folder / "図面A (1).pdf")
    if input_kind == "quoted":
        configured = f'"{folder}"'
    else:
        monkeypatch.setenv("ACAD_TEST_ADOBE_DIR", str(folder))
        configured = "$ACAD_TEST_ADOBE_DIR"
    # This is already accepted by the printing route and therefore must also
    # work when a user follows the troubleshooting guidance in Settings.
    assert candidate_dirs("Adobe PDF", tmp_path / "図面A.dwg", preferred_dir=configured) == [folder]
    report = build_diagnostic_report(tmp_path, {}, config={"adobe_pdf_watch_dir": configured})
    assert "フォルダ読み取り: OK / PDF 1件" in report


def test_open_adobe_folder_accepts_explorer_copy_as_path(tmp_path, monkeypatch):
    pytest.importorskip("PySide6")
    from PySide6.QtWidgets import QApplication, QDialog, QPushButton
    import main

    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main, "APP_DIR", tmp_path)
    folder = tmp_path / "Adobe generated PDFs"
    folder.mkdir()
    store = Store(tmp_path / "data")
    store.load()
    store.config["adobe_pdf_watch_dir"] = f'"{folder}"'
    store.save_config()
    opened = []
    monkeypatch.setattr(main.QDesktopServices, "openUrl", lambda url: opened.append(url.toLocalFile()) or True)

    def inspect(dialog):
        button = next(button for button in dialog.findChildren(QPushButton) if button.text() == "開く")
        assert button.isEnabled()
        button.click()
        return QDialog.Rejected

    monkeypatch.setattr(QDialog, "exec", inspect)
    window = main.MainWindow()
    try:
        window.show_app_settings()
        assert opened == [str(folder)]
    finally:
        window.close()
        app.processEvents()


def test_environment_capture_uses_current_autocad_version_selection(tmp_path, monkeypatch):
    pytest.importorskip("PySide6")
    from PySide6.QtWidgets import QApplication, QComboBox, QDialog, QPushButton
    import main

    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main, "APP_DIR", tmp_path)
    captured = []

    def capture(*args, **kwargs):
        captured.append((args, kwargs))
        return {"devices": ["Adobe PDF"], "media": [], "styles": []}

    monkeypatch.setattr(main, "probe_plot_environment", capture)
    monkeypatch.setattr(main.QMessageBox, "information", lambda *args: None)
    monkeypatch.setattr(main.QMessageBox, "warning", lambda *args: None)

    def inspect(dialog):
        version = next(combo for combo in dialog.findChildren(QComboBox)
                       if "2025" in [combo.itemText(i) for i in range(combo.count())])
        version.setCurrentText("2025")
        next(button for button in dialog.findChildren(QPushButton)
             if button.text() == "AutoCADから印刷環境を取得").click()
        return QDialog.Rejected

    monkeypatch.setattr(QDialog, "exec", inspect)
    window = main.MainWindow()
    try:
        window.show_app_settings()
        assert len(captured) == 1
        assert captured[0][0] == (True,)
        assert captured[0][1]["connection_options"]["selected_year"] == "2025"
    finally:
        window.close()
        app.processEvents()


def test_existing_windows_data_preserves_user_configuration_and_presets(tmp_path):
    store = Store(tmp_path / "data")
    store.load()
    user_settings = {
        "autocad_version": "2025",
        "adobe_pdf_watch_dir": r'"\\server\図面用出力\Adobe PDF"',
        "adobe_pdf_timeout": 300,
        "existing_pdf_action": "スキップする",
        "log_enabled": False,
        "user_extension": {"future_option": "preserve"},
    }
    store.config.update(user_settings)
    store.save_config()
    store.data["plot"] = [{"id": "my_custom_plot", "name": "会社専用Adobe PDF", "device": "Adobe PDF"}]
    store.save()
    before = {file.name: file.read_bytes() for file in store.preset_dir.glob("*.json")}
    loaded = Store(store.dir)
    loaded.load()
    assert all(loaded.config[key] == value for key, value in user_settings.items())
    assert loaded.data["plot"] == store.data["plot"]
    assert {file.name: file.read_bytes() for file in loaded.preset_dir.glob("*.json")} == before
    assert json.loads(loaded.config_path.read_text(encoding="utf-8"))["user_extension"] == user_settings["user_extension"]


def test_frozen_application_uses_executable_directory_for_existing_data(tmp_path, monkeypatch):
    pytest.importorskip("PySide6")
    import main

    distribution = tmp_path / "会社用 ACadPresetter"
    monkeypatch.setattr(main.sys, "frozen", True, raising=False)
    monkeypatch.setattr(main.sys, "executable", str(distribution / "ACadPresetter.exe"))
    monkeypatch.setattr(main, "__file__", str(distribution / "_internal" / "main.py"))
    monkeypatch.chdir(tmp_path)
    assert main.get_app_dir() == distribution


def test_environment_capture_works_when_owned_autocad_starts_without_a_drawing(monkeypatch):
    """AutoCAD's start screen/STARTUP setting may leave Documents.Count at 0."""
    from app import autocad_backend

    calls = []
    document = SimpleNamespace(Close=lambda save: calls.append(("document_close", save)))

    class Documents:
        Count = 0

        def Add(self):
            self.Count = 1
            calls.append("document_add")
            return document

    class Application:
        def __init__(self):
            self.Documents = Documents()

        @property
        def ActiveDocument(self):
            if not self.Documents.Count:
                raise RuntimeError("AutoCADに図面が開かれていません。")
            return document

    class Session:
        def __init__(self, options):
            calls.append(("session_options", options))
            self.app = Application()
            self.backend = SimpleNamespace(started_by_us=True, active_plot_environment=self.capture)

        def open(self):
            calls.append("session_open")

        def capture(self):
            assert self.app.ActiveDocument is document
            calls.append("capture")
            return {"devices": ["Adobe PDF"], "media": [], "styles": []}

        def close(self):
            calls.append("session_close")

        def ensure_hidden(self):
            calls.append("ensure_hidden")

    monkeypatch.setattr(autocad_backend, "AutoCADBatchSession", Session)
    result = probe_plot_environment(True, connection_options={
        "selected_year": "2025", "shared_plot_resources_enabled": True,
        "shared_pc3_path": r"\\server\plotters", "shared_plot_style_path": r"\\server\plot styles",
    })
    assert result["devices"] == ["Adobe PDF"]
    assert "document_add" in calls
    options = next(call[1] for call in calls if isinstance(call, tuple) and call[0] == "session_options")
    assert options["selected_year"] == "2025"
    assert options["shared_pc3_path"] == r"\\server\plotters"
    assert options["shared_plot_style_path"] == r"\\server\plot styles"
    assert options["shared_plot_resources_enabled"] is True
    assert calls[-1] == "session_close"


@pytest.mark.parametrize("configured", [None, "", "  ", '""', '"  "'])
def test_empty_adobe_folder_cannot_select_current_directory(configured):
    with pytest.raises(ValueError, match="未設定"):
        normalize_watch_dir(configured)


def test_adobe_folder_normalization_preserves_actual_unicode_directory(tmp_path):
    folder = tmp_path / "図面Ａ① ガ"
    folder.mkdir()
    assert normalize_watch_dir(f'  "{folder}"  ') == folder


def test_settings_diagnoses_current_adobe_input_before_saving(tmp_path, monkeypatch):
    pytest.importorskip("PySide6")
    from PySide6.QtWidgets import QApplication, QDialog, QLineEdit, QPushButton, QSpinBox
    import main

    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main, "APP_DIR", tmp_path)
    current_folder = tmp_path / "corrected Adobe output"
    current_folder.mkdir()
    captured = []

    def report(*args, config=None, **kwargs):
        captured.append(dict(config))
        return "diagnostic report"

    monkeypatch.setattr(main, "build_diagnostic_report", report)
    monkeypatch.setattr(main, "save_report", lambda *args: tmp_path / "diagnostic.txt")
    monkeypatch.setattr(main.QMessageBox, "exec", lambda *args: main.QMessageBox.Ok)

    def inspect(dialog):
        folder = next(field for field in dialog.findChildren(QLineEdit)
                      if "Adobe使用時は必須" in field.placeholderText())
        folder.setText(str(current_folder))
        dialog.findChild(QSpinBox, "adobe_pdf_timeout").setValue(180)
        next(button for button in dialog.findChildren(QPushButton) if button.text() == "診断").click()
        return QDialog.Rejected

    monkeypatch.setattr(QDialog, "exec", inspect)
    window = main.MainWindow()
    try:
        window.show_app_settings()
        assert len(captured) == 1
        assert captured[0]["adobe_pdf_watch_dir"] == str(current_folder)
        assert captured[0]["adobe_pdf_timeout"] == 180
        assert window.store.config["adobe_pdf_watch_dir"] == "", "diagnostic must not persist unsaved edits"
    finally:
        window.close()
        app.processEvents()


def test_created_pdf_remains_recoverable_when_autocad_disconnects_after_generation(tmp_path, monkeypatch):
    """Real backend errors may omit output even though the PDF already exists."""
    pytest.importorskip("PySide6")
    from PySide6.QtWidgets import QApplication
    import main
    from app import autocad_backend as backend
    from app.pdf_output import PdfOutputSession

    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main, "APP_DIR", tmp_path)
    source = tmp_path / "drawing.dwg"
    source.touch()
    generated = {"complete": False}
    staging_sessions = []
    notifications = []

    class AcadSession:
        def __init__(self, options):
            self.options = options
            self.app = object()

        def open(self):
            pass

        def close(self):
            pass

        def ensure_hidden(self):
            if generated["complete"]:
                raise backend.AutoCADConnectionLost("RPC disconnected after PDF generation")

    class Staging(PdfOutputSession):
        def __init__(self):
            super().__init__(tmp_path / "staging")
            staging_sessions.append(self)

    monkeypatch.setattr(main, "AutoCADBatchSession", AcadSession)
    monkeypatch.setattr(main, "PdfOutputSession", Staging)
    monkeypatch.setattr(main.QMessageBox, "warning", lambda *args: notifications.append(args))
    monkeypatch.setattr(main.QMessageBox, "critical", lambda *args: notifications.append(args))
    doc = SimpleNamespace(ActiveLayout=SimpleNamespace(Name="Model"))
    monkeypatch.setattr(backend, "_open_for_session", lambda *args: (doc, False))
    monkeypatch.setattr(backend, "_prepare_plot", lambda *args: (doc.ActiveLayout, {}, doc.ActiveLayout, "PDF.pc3", False))
    monkeypatch.setattr(backend, "_set_sync_plot", lambda *args: 0)
    monkeypatch.setattr(backend, "_restore_plot_document", lambda *args: None)

    def generate_pdf(doc, output, *args, **kwargs):
        write_pdf(output)
        generated["complete"] = True
        return True

    monkeypatch.setattr(backend, "_plot_pdf_to_file", generate_pdf)
    window = main.MainWindow()
    monkeypatch.setattr(window, "_preflight_dialog", lambda pdf, prints: (pdf, prints))
    monkeypatch.setattr(window, "_merge_plan", lambda **kwargs: [])
    try:
        window._execute_output_jobs([{
            "source": str(source), "output": str(tmp_path / "final.pdf"),
            "settings": {}, "label": source.name,
        }], [])
        staged = Path(staging_sessions[0]._items[0].temp_path)
        recovered = list((tmp_path / "data" / "recovery").rglob("*.pdf"))
        assert staged.exists() or recovered, "the only created PDF was deleted during cleanup"
        history = window.run_history.load()["last"]["jobs"][0]
        assert history["status"] == "失敗"
        assert "保全先" in history["message"]
        assert notifications and "保全先" in notifications[-1][2]
    finally:
        window.close()
        app.processEvents()


