"""Formula-preserving edits of points and sizes through numeric gesture deltas."""
import copy,math,re
from vertex_points import points_text,read_vertices
PATHS=frozenset(('LINE','POLYLINE','HATCH','SPLINE','LEADER'))
INSERTIONS=frozenset(('TEXT','MTEXT','INSERT','POINT'))
def _point(v):
 try:
  if len(v)!=2 or any(isinstance(x,bool) for x in v):raise ValueError
  p=tuple(float(x) for x in v)
 except (TypeError,ValueError,OverflowError):raise ValueError('位置は2つの有限数値で指定してください') from None
 if not all(math.isfinite(x) for x in p):raise ValueError('位置は有限数値で指定してください')
 return p
def _delta(expr,amount):
 if not math.isfinite(amount):raise ValueError('移動量は有限数値で指定してください')
 if amount==0:return expr
 from coordinate_values import split_coordinate,compose_coordinate
 base,old=split_coordinate(str(expr))
 try:movement=format(float(old)+amount,'.15g')
 except (ValueError,TypeError):movement=f'({old})+({amount:.15g})'
 return compose_coordinate(base,movement)
def _number(expr,context,evaluate):
 v=evaluate(str(expr),context)
 if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v):raise ValueError('ハンドルの値は有限数値で指定してください')
 return float(v)
def _shift(d,suffix,dx,dy):
 for axis,v in (('x',dx),('y',dy)):d[axis+suffix]=_delta(d.get(axis+suffix,'0'),v)
def supported_names(command):
 k=command.get('type')
 if k in PATHS:
  vs=read_vertices(command);names={'始点','終点'}|{f'頂点{i+1}' for i in range(len(vs))}
  if k=='SPLINE':names.update(f'通過点{i+1}' for i in range(len(vs)))
  if not any('前点' in p[a] for p in vs for a in ('x','y')):names.add('中点')
  return names
 if k=='CIRCLE':return {'中心','上','下','左','右'}
 if k=='RECTANGLE':return {'対角点1','対角点2','中心','左上','右上','左下','右下','上辺中点','下辺中点','左辺中点','右辺中点'}
 if k=='VIEWPORT':return {'対角点1','対角点2','中心','表示内容'}
 if k=='ELLIPSE':return {'中心','長軸端点1','長軸端点2','短軸端点1','短軸端点2'}
 if k in INSERTIONS:return {'位置'} if k=='POINT' else {'挿入点'}
 if k in ('DIMLINEAR','DIMALIGNED'):return {'測定点1','測定点2','寸法位置'}
 if k in ('DIMRADIUS','DIMDIAMETER'):return {'中心','寸法位置'}
 return set()
def move(command,name,old_xy,new_xy,context,evaluate):
 if name not in supported_names(command):raise ValueError('この点はハンドルで変更できません')
 old,new=_point(old_xy),_point(new_xy);dx,dy=(b-a for a,b in zip(old,new));d=copy.deepcopy(command)
 if not all(math.isfinite(v) for v in (dx,dy)):raise ValueError('移動量は有限数値で指定してください')
 if dx==0 and dy==0:return d
 k=d.get('type')
 if k=='VIEWPORT':
  if name in ('中心','表示内容'):
   scale=_number(d.get('view_scale','1'),context,evaluate)
   if scale<=0:raise ValueError('尺度は正数にしてください')
   d.update(view_x=_delta(d.get('view_x','0'),-dx/scale),view_y=_delta(d.get('view_y','0'),-dy/scale),configure_view=True)
  else:_shift(d,name[-1],dx,dy)
  return d
 if k in PATHS:
  vs=read_vertices(d)
  indices=range(len(vs)) if name=='中点' else (0 if name=='始点' else len(vs)-1,) if name in ('始点','終点') else (int(re.search(r'\d+$',name).group())-1,)
  for i in indices:vs[i]['x']=_delta(vs[i]['x'],dx);vs[i]['y']=_delta(vs[i]['y'],dy)
  if k=='LINE' and 'vertices' not in d:
   for suffix,v in zip(('1','2'),vs):d['x'+suffix],d['y'+suffix]=v['x'],v['y']
  else:
   if 'vertices' in d:
    for target,v in zip(d['vertices'],vs):target.update(x=v['x'],y=v['y'])
   d['points']=points_text(vs)
  return d
 if k in INSERTIONS or k in ('CIRCLE','ELLIPSE','DIMRADIUS','DIMDIAMETER') and name=='中心':_shift(d,'',dx,dy)
 elif k=='RECTANGLE':
  if name=='中心':_shift(d,'1',dx,dy);_shift(d,'2',dx,dy)
  elif name.startswith('対角点'):_shift(d,name[-1],dx,dy)
  else:
   x1,x2=(_number(d.get('x'+s,'0'),context,evaluate) for s in ('1','2'));y1,y2=(_number(d.get('y'+s,'0'),context,evaluate) for s in ('1','2'))
   xs=('1' if x1<=x2 else '2') if name.startswith('左') else ('1' if x1>=x2 else '2')
   ys=('1' if y1>=y2 else '2') if name.startswith('上') or name.endswith('上') else ('1' if y1<=y2 else '2')
   if name in ('左上','右上','左下','右下'):d['x'+xs]=_delta(d.get('x'+xs,'0'),dx);d['y'+ys]=_delta(d.get('y'+ys,'0'),dy)
   elif name.startswith(('上','下')):d['y'+ys]=_delta(d.get('y'+ys,'0'),dy)
   else:d['x'+xs]=_delta(d.get('x'+xs,'0'),dx)
 elif k in ('CIRCLE','ELLIPSE'):
  center=tuple(_number(d.get(a,'0'),context,evaluate) for a in ('x','y'));change=math.dist(center,new)-math.dist(center,old)
  if k=='CIRCLE':
   field='diameter' if d.get('circle_mode')=='diameter' else 'r';d[field]=_delta(d.get(field,'0'),change*(2 if field=='diameter' else 1))
   if _number(d[field],context,evaluate)<=0:raise ValueError('円のサイズは正数にしてください')
  else:
   field='rx' if name.startswith('長軸') else 'ry';d[field]=_delta(d.get(field,'0'),change);rx,ry=(_number(d.get(f,'0'),context,evaluate) for f in ('rx','ry'))
   if not 0<ry<=rx:raise ValueError('楕円は長軸半径≧短軸半径>0で指定してください')
 elif k in ('DIMLINEAR','DIMALIGNED'):_shift(d,'3' if name=='寸法位置' else name[-1],dx,dy)
 else:_shift(d,'3',dx,dy)
 return d
