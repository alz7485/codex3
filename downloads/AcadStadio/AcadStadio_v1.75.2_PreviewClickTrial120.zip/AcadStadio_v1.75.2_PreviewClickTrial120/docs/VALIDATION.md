# 1.75.2-beta120の検証

メインのProjectNavigator.addが新規作成フラグを渡していなかったため、画面入力が自動開始されませんでした。creating=Trueを渡し、自動SELECTから返る複数コマンドも一覧に正しく挿入します。

- 関連GUI3ファイル・33件成功（test_gui_unified_navigator、test_gui_preview_input、test_gui_select_flow）。
- 新規テストでは一覧の「追加」を実際に実行し、手動refresh_command_previewを呼ばずに画面指定開始・クリック2点・LINE保存まで確認しました。
- 自動SELECTと操作コマンドの順序を維持して挿入することも確認しました。
- スモーク成功。
- コア全件・GUI全件の今回の再実行はしていません。前版Trial119はコア578件・関連GUI21件が成功しています。
- Linux/Tk環境で検証。Windowsのマウス実操作、AutoCAD実機、EXEビルドは未確認です。
