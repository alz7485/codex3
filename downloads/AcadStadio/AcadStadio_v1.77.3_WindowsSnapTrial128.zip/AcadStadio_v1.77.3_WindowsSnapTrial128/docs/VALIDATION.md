# 1.77.3-beta128の検証

- コア全581件成功。関連GUI3ファイル・32件成功（preview_input 23、drawing_guides 4、select_flow 5）。スモーク成功。GUI全件の今回の再実行はしていません。
- WindowsのNumLock状態0x8を付けたマウスイベントとWindows用キー判定をLinux/Tk上で再現。通常の線分本体を選んでも点数が0のままで、始点と終点の選択後にX/Yが点参照で保存されることを確認しました。
- キーマスクの単体検証でWindowsのNumLock/Shift/Caps/Controlの組合せではスナップ解除せず、実際のAlt 0x20000では解除することを確認。X11のAlt判定は維持。
- 根拠：Tk 8.6 win/tkWinX.cでVK_NUMLOCKはMod1Mask、VK_MENUはALT_MASKを使用。generic/tkInt.hのALT_MASKはAnyModifier<<2 (=0x20000)。
- ソース：https://github.com/tcltk/tk/blob/core-8-6-branch/win/tkWinX.c および https://github.com/tcltk/tk/blob/core-8-6-branch/generic/tkInt.h
- ガイド図形の参照・元ガイド変更への追従、SELECTの従来動作の回帰も成功。
- プレビューで通常図形を暗い色に表示しても、元コマンドのguide属性は変更しません。
- Windows実機の操作・AutoCAD実機・EXEビルドは未確認です。
