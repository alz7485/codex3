import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from sample_project import EXAMPLE
from engine import compile_project, MacroError
from command_points import reference, new_id
from project_model import normalize_sequential_project
from audit import audit_details

class CrossBlockPoints(unittest.TestCase):
    def project(self):
        p=copy.deepcopy(EXAMPLE);identity=new_id()
        source=dict(type='LINE',point_id=identity,x1='@X',y1='@Y',x2='@X+@OD',y2='@Y')
        target=dict(type='POINT',x=reference('source/'+identity,'中点','X')+'-10',y=reference('source/'+identity,'中点','Y'))
        p['blocks']=[dict(id='source',name='作図',commands=[source]),dict(id='target',name='後の作図',commands=[target])]
        return p

    def test_previous_block_references_follow_row_values_and_json(self):
        p=self.project();p=normalize_sequential_project(json.loads(json.dumps(p)))
        _,items=compile_project(p,[0,1]);self.assertEqual(items[1]['coords'],(140,100));self.assertEqual(items[3]['coords'],(470,100))
        self.assertFalse(audit_details(p))

    def test_same_command_id_in_copied_blocks_is_unambiguous(self):
        p=self.project();other=copy.deepcopy(p['blocks'][0]);other.update(id='copy',name='複製')
        other['commands'][0]['x1']='1000';other['commands'][0]['x2']='1200'
        p['blocks'].insert(1,other)
        _,items=compile_project(p,[0]);self.assertEqual(items[-1]['coords'],(140,100))
        p['blocks'][-1]['commands'][0]['x']=p['blocks'][-1]['commands'][0]['x'].replace('source/','copy/')
        self.assertEqual(compile_project(p,[0])[1][-1]['coords'],(1090,100))

    def test_missing_forward_and_skipped_block_references_error(self):
        p=self.project()
        for change in ['delete','forward','skip']:
            with self.subTest(change=change):
                q=copy.deepcopy(p)
                if change=='delete':q['blocks'].pop(0)
                if change=='forward':q['blocks'].reverse()
                if change=='skip':q['blocks'][0]['condition']='False'
                with self.assertRaisesRegex(MacroError,'参照先の点がありません'):compile_project(q,[0])

    def test_cross_row_state_does_not_leak(self):
        p=self.project();p['blocks'][0]['condition']='@OD == 100'
        with self.assertRaisesRegex(MacroError,'2行目'):compile_project(p,[0,1])

    def test_block_rename_and_unrelated_insertion_keep_reference_identity(self):
        p=self.project();p['blocks'][0]['name']='作図を改名'
        p['blocks'].insert(0,dict(id='another',name='他の作図',commands=[dict(type='CIRCLE',x='0',y='0',r='5')]))
        self.assertEqual(compile_project(p,[0])[1][-1]['coords'],(140,100))
