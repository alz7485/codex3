"""Shared single-row control and a staged checkbox list for drawing targets."""

import tkinter as tk
from tkinter import ttk, messagebox
from project_data import parse_row_number, row_title, title_table, target_settings
from table_grid import GridTreeview
from theme import fit_window


class DrawingTargetControls(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.columnconfigure(3, weight=1)
        ttk.Radiobutton(self, text="行番号", variable=app.scope, value="range").grid(
            row=0, column=0, sticky="w"
        )
        self.spin = ttk.Spinbox(
            self,
            from_=1,
            to=max(1, len(app.rows)),
            increment=1,
            textvariable=app.row_range,
            width=5,
            wrap=False,
        )
        self.spin.grid(row=0, column=1, sticky="w", padx=(0, 5))
        self.total = ttk.Label(self, style="Muted.TLabel")
        self.total.grid(row=0, column=2, sticky="w", padx=(0, 8))
        self.title = tk.StringVar()
        self.title_label = ttk.Label(self, textvariable=self.title, wraplength=205)
        self.title_label.grid(row=0, column=3, sticky="ew")
        self.title_label.bind("<Enter>", self.show_title)
        self.title_label.bind("<Leave>", lambda e: app.icons.hide())
        ttk.Radiobutton(
            self, text="チェックした行", variable=app.scope, value="selected"
        ).grid(row=1, column=0, sticky="w", pady=(7, 0))
        self.choose = ttk.Button(
            self,
            text="選択行…",
            command=lambda: app.choose_drawing_rows(self.winfo_toplevel()),
            style="Compact.TButton",
        )
        self.choose.grid(row=1, column=1, columnspan=2, sticky="w", pady=(7, 0))
        self.checked = ttk.Label(self, style="Muted.TLabel")
        self.checked.grid(row=1, column=3, sticky="w", pady=(7, 0))
        self.note = ttk.Label(self, style="Muted.TLabel", wraplength=375)
        self.note.grid(row=2, column=0, columnspan=4, sticky="w", pady=(6, 0))
        app._target_controls.append(self)
        self.bind("<Destroy>", self.destroyed)

    def destroyed(self, event):
        if event.widget is self and self in self.app._target_controls:
            self.app._target_controls.remove(self)

    def show_title(self, event):
        table, column = title_table(self.app.data)
        self.app.icons.schedule(
            self.title_label,
            f"入力表1「{table['name']}」 / {column or '左端列なし'}\n{getattr(self, 'full_title', self.title.get())[:1024]}",
        )

    def sync(self):
        count = len(self.app.rows)
        single = self.app.scope.get() == "range"
        self.spin.configure(
            to=max(1, count), state="normal" if single and count else "disabled"
        )
        self.total.configure(text=f"/ {count}行")
        self.checked.configure(
            text=f"{len(target_settings(self.app.data)['selected'])}行チェック"
        )
        if single:
            try:
                index = parse_row_number(self.app.row_range.get(), count)
                full = row_title(self.app.data, index)
                self.full_title = full
                display = " ".join(full.splitlines())
                self.title.set(
                    "タイトル: "
                    + (display if len(display) <= 22 else display[:21] + "…")
                )
                self.note.configure(
                    text="タイトルは入力表1の左端列を表示します", foreground="#67788d"
                )
            except ValueError as exc:
                self.full_title = str(exc)
                self.title.set("タイトル: —")
                self.note.configure(text=str(exc), foreground="#b42318")
        else:
            self.full_title = "行番号モードで1行を指定すると、タイトルを表示します"
            self.title.set("タイトル: —")
            self.note.configure(
                text="「選択行…」のチェックリストで作図する行を指定します",
                foreground="#67788d",
            )


class RowSelectionDialog:
    def __init__(self, app, parent):
        self.app = app
        from engine import RowResolver, convert, evaluate, MacroError
        self.resolver = RowResolver(app.data, convert, evaluate, MacroError)
        self.project = app.data
        self.table_id = app.data["active_table"]
        self.table, self.column = title_table(app.data)
        self.limit = min(len(self.table["rows"]), len(app.rows))
        self.checked = set(
            i for i in target_settings(app.data)["selected"] if i < self.limit
        )
        self.win = tk.Toplevel(parent)
        self.win.title("選択行 — 作図対象")
        self.win.transient(parent)
        fit_window(self.win, 620, 600, 520, 420)
        self.previous_grab = app.root.grab_current()
        self.win.grab_set()
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        self.win.bind("<Escape>", lambda e: self.cancel())
        self.win.bind("<Control-Return>", lambda e: self.apply())
        header = ttk.Frame(self.win, padding=(16, 14, 16, 6))
        header.pack(fill="x")
        ttk.Label(header, text="作図する行にチェック", style="Section.TLabel").pack(
            anchor="w"
        )
        ttk.Label(
            header,
            text=f"入力表1: {self.table['name']} / タイトル: {self.column or '左端列なし'}",
            wraplength=560,
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(5, 0))
        footer = ttk.Frame(self.win, padding=(16, 8, 16, 14))
        footer.pack(side="bottom", fill="x")
        ttk.Button(footer, text="キャンセル", command=self.cancel).pack(side="right")
        self.apply_button = ttk.Button(
            footer,
            text="チェックした行を適用",
            command=self.apply,
            style="Primary.TButton",
        )
        self.apply_button.pack(side="right", padx=(0, 8))
        toolbar = ttk.Frame(self.win, padding=(16, 4, 16, 8))
        toolbar.pack(fill="x")
        ttk.Button(
            toolbar,
            text="すべてチェック",
            command=self.check_all,
            style="Compact.TButton",
        ).pack(side="left")
        ttk.Button(
            toolbar, text="すべて外す", command=self.clear_all, style="Compact.TButton"
        ).pack(side="left", padx=6)
        self.count = tk.StringVar()
        ttk.Label(toolbar, textvariable=self.count, style="Muted.TLabel").pack(
            side="right"
        )
        area = ttk.Frame(self.win, padding=(16, 0, 16, 0))
        area.pack(fill="both", expand=True)
        area.rowconfigure(0, weight=1)
        area.columnconfigure(0, weight=1)
        self.tree = GridTreeview(
            area,
            columns=("check", "row", "title"),
            show="headings",
            selectmode="browse",
        )
        self.tree.heading("check", text="選択")
        self.tree.column("check", width=48, stretch=False, anchor="center")
        self.tree.heading("row", text="行番号")
        self.tree.column("row", width=65, stretch=False, anchor="center")
        self.tree.heading("title", text="タイトル")
        self.tree.column("title", width=420, minwidth=200)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(area, command=self.tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(area, orient="horizontal", command=self.tree.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=scroll.set, xscrollcommand=horizontal.set)
        self.tree.tag_configure("unavailable", foreground="#9ca8b6")
        for i in range(len(self.table["rows"])):
            self.tree.insert(
                "",
                "end",
                iid=str(i),
                values=(self.mark(i), i + 1, self.display_title(i)),
                tags=("unavailable",) if i >= self.limit else (),
            )
        self.tree.bind("<ButtonRelease-1>", self.click)
        self.tree.bind("<space>", self.toggle_focused)
        note = "クリック / Spaceで切替。適用するまで作図対象は変わりません。"
        if self.limit < len(self.table["rows"]):
            note += " 作図に使用する入力表に存在しない行は選べません。"
        ttk.Label(
            self.win, text=note, style="Muted.TLabel", wraplength=560, padding=(16, 8)
        ).pack(fill="x")
        self.update_count()
        self.tree.focus_set()

    def display_title(self, i):
        return row_title(self.app.data, i, resolver=self.resolver)

    def mark(self, i):
        return "—" if i >= self.limit else "☑" if i in self.checked else "☐"

    def update_count(self):
        self.count.set(f"{len(self.checked)} / {len(self.table['rows'])}行チェック")

    def toggle(self, i):
        if not 0 <= i < self.limit:
            return
        if i in self.checked:
            self.checked.remove(i)
        else:
            self.checked.add(i)
        self.tree.set(str(i), "check", self.mark(i))
        self.update_count()

    def click(self, event):
        row = self.tree.identify_row(event.y)
        if row and self.tree.identify_region(event.x, event.y) == "cell":
            self.tree.focus(row)
            self.tree.selection_set(row)
            self.toggle(int(row))

    def toggle_focused(self, event=None):
        row = self.tree.focus()
        if row:
            self.toggle(int(row))
        return "break"

    def check_all(self):
        self.checked = set(range(self.limit))
        self.render_checks()

    def clear_all(self):
        self.checked.clear()
        self.render_checks()

    def render_checks(self):
        for i in range(len(self.table["rows"])):
            self.tree.set(str(i), "check", self.mark(i))
        self.update_count()

    def apply(self):
        if (
            self.app.data is not self.project
            or self.app.data["active_table"] != self.table_id
        ):
            messagebox.showerror(
                "選択行",
                "入力表が変更されました。リストを開き直してください。",
                parent=self.win,
            )
            return
        self.app.set_checked_rows(sorted(self.checked))
        self.cancel()

    def cancel(self):
        self.win.destroy()
        if self.previous_grab is not None and self.previous_grab.winfo_exists():
            self.previous_grab.grab_set()
