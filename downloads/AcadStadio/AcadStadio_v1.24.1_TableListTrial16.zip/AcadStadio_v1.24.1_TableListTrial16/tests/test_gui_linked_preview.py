"""Independent table-row preview and stable camera across display-only changes."""
import copy
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui

@unittest.skipUnless(sys.platform == 'win32' or os.environ.get('DISPLAY'), 'GUI display unavailable')
class LinkedPreviewGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def settle(self):
        self.root.after(240, self.root.quit)
        self.root.mainloop()
        self.root.update()

    def test_real_row_click_and_keyboard_follow_without_changing_scr_targets_or_data(self):
        app = self.app
        before = copy.deepcopy(app.data); history = copy.deepcopy(app._history)
        script = app.compile()[0]
        app.show_input_table(); self.root.update()
        x,y,w,h = app.table.bbox('1', '#row-number')
        app.table.event_generate('<ButtonPress-1>', x=x+w//2, y=y+h//2)
        app.table.event_generate('<ButtonRelease-1>', x=x+w//2, y=y+h//2)
        self.settle()
        self.assertEqual(app.selected_rows(), [1])
        self.assertEqual({i['row'] for i in app.canvas.items}, {1})
        self.assertEqual(len(app.canvas.items), 104)
        self.assertIn('確認行2', app.preview_status.get())
        app.table.focus_force(); self.root.update(); app.table.event_generate('<Down>')
        self.settle()
        self.assertEqual({i['row'] for i in app.canvas.items}, {2})
        self.assertEqual(app.data, before)
        self.assertEqual(app._history, history)
        self.assertEqual(app.target_rows(), [0])
        self.assertEqual(app._script_text, script)
        self.assertEqual(app.compile()[0], script)
        path = Path(self.library_dir.name) / 'drawing.scr'
        app.export(); self.root.update()
        win = gui.top(self.root, 'SCRを書き出す')
        with patch('tkinter.filedialog.asksaveasfilename', return_value=str(path)):
            gui.button(win, '保存先を選んで書き出す').invoke()
        self.assertEqual(path.read_text(encoding=app.encoding.get()), script)

    def test_multiple_selected_rows_clear_and_explicit_drawing_setting(self):
        app = self.app
        app.show_input_table(); self.root.update()
        app.table.selection_set('0', '2'); self.settle()
        self.assertEqual({i['row'] for i in app.canvas.items}, {0,2})
        self.assertEqual(app.target_rows(), [0])
        app.table.selection_remove(app.table.selection()); self.settle()
        self.assertEqual({i['row'] for i in app.canvas.items}, {0})
        app.table.selection_set('2'); self.settle()
        app.row_range.set('2'); app.preview(quiet=True)
        self.assertEqual({i['row'] for i in app.canvas.items}, {1})
        self.assertEqual(app.target_rows(), [1])

    def test_invalid_preview_row_does_not_erase_valid_scr_and_recovers_after_edit(self):
        app = self.app; script = app.compile()[0]
        app.rows[1]['OD'] = 'bad'; app.refresh()
        app.show_input_table(); self.root.update()
        app.table.selection_set('1'); self.settle()
        self.assertEqual(app.canvas.items, [])
        self.assertIn('プレビュー:', app.status.get())
        self.assertEqual(app._script_text, script)
        app.rows[1]['OD'] = '120'; app.refresh(); self.settle()
        self.assertEqual({i['row'] for i in app.canvas.items}, {1})
        self.assertEqual(app._script_text, script)

    def test_visibility_empty_and_regeneration_keep_actual_scale_pan_and_screen_coordinates(self):
        app = self.app; canvas = app.canvas; browser = app.block_browser
        canvas.fit()
        canvas.zoom(SimpleNamespace(x=230,y=170,delta=120), 1.7)
        canvas.drag_point = (10,10); canvas.drag(SimpleNamespace(x=44,y=38))
        self.root.update()
        view = copy.deepcopy(canvas.get_view()); scale = canvas.scale_value; offset = canvas.offset
        def lines():
            return {(repr(item), canvas.type(node)): canvas.coords(node)
                    for node,item,color in canvas.geometry if item['block_index'] == 1}
        before = lines()
        self.assertTrue(before)
        ids = {b['id'] for b in app.data['blocks']}
        for hidden in ({app.data['blocks'][0]['id']}, ids, {app.data['blocks'][2]['id']}, set()):
            browser.set_preview_visibility(ids, True)
            browser.set_preview_visibility(hidden, False)
            self.root.update()
            self.assertAlmostEqual(canvas.scale_value, scale)
            self.assertEqual(canvas.get_view(), view)
            self.assertEqual(canvas.offset, offset)
            for key,coords in lines().items():
                for value,old in zip(coords,before[key]): self.assertAlmostEqual(value,old)
        for _ in range(2):
            app.preview(quiet=True); app.show_script(); app.script_window.withdraw(); self.root.update()
            self.assertAlmostEqual(canvas.scale_value, scale)
            self.assertEqual(canvas.get_view(), view)

    def test_row_change_recenters_without_zoom_even_while_all_blocks_are_hidden(self):
        app = self.app; canvas = app.canvas
        canvas.fit(); canvas.zoom(SimpleNamespace(x=250,y=180,delta=120), 1.4)
        scale = canvas.scale_value
        app.block_browser.set_preview_visibility({b['id'] for b in app.data['blocks']}, False)
        app.show_input_table(); self.root.update(); app.table.selection_set('1'); self.settle()
        self.assertEqual(canvas.items, [])
        self.assertAlmostEqual(canvas.scale_value, scale)
        app.block_browser.set_preview_visibility({b['id'] for b in app.data['blocks']}, True)
        self.assertEqual({i['row'] for i in canvas.items}, {1})
        self.assertAlmostEqual(canvas.scale_value, scale)
        xs = [v for node,_,_ in canvas.geometry for v in canvas.coords(node)[::2]]
        self.assertLess(min(xs), canvas.winfo_width()/2)
        self.assertGreater(max(xs), canvas.winfo_width()/2)

    def test_left_controls_leave_preview_at_top_and_all_buttons_fit(self):
        for size in ('1320x840','1040x680'):
            self.root.geometry(size); self.root.update()
            canvas = self.app.canvas
            self.assertEqual(canvas.winfo_rooty(), self.app.drawing_page.winfo_rooty())
            for label in ('入力表を編集', 'CAD初期設定'):
                button = gui.button(self.app.sourcebar, label)
                self.assertTrue(button.winfo_ismapped())
                self.assertLessEqual(button.winfo_rootx()+button.winfo_width(),canvas.winfo_rootx())
            self.assertGreater(self.app.block_list.winfo_height(),100)

    def test_manual_fit_is_available_and_resize_does_not_change_zoom_scale(self):
        canvas = self.app.canvas
        canvas.fit(); canvas.zoom(SimpleNamespace(x=200,y=170,delta=120), 1.8)
        scale = canvas.scale_value
        self.root.geometry('1040x680'); self.root.update()
        self.assertAlmostEqual(canvas.scale_value, scale)
        canvas.fit()
        self.assertEqual(canvas.get_view()['zoom'],1)
        self.assertEqual(canvas.get_view()['pan'],[0,0])
