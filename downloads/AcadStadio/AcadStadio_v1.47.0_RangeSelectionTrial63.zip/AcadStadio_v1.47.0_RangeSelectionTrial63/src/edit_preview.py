"""Analytical previews for line trims and line/circle offsets.

Unsupported CAD-only geometry remains explicitly marked; it is never guessed.
"""
import math


def segments(item):
    if item.get('segments'):return [tuple(s) for s in item['segments']]
    typ=item.get('display_type',item['type']);c=item['coords']
    if typ=='RECTANGLE':
        x,y,u,v=c;return [(x,y,u,y),(u,y,u,v),(u,v,x,v),(x,v,x,y)]
    if typ not in ('LINE','POLYLINE'):return []
    points=list(zip(c[::2],c[1::2]))
    if item.get('closed'):points.append(points[0])
    return [(*a,*b) for a,b in zip(points,points[1:])]


def projection(p,line):
    x,y,u,v=line;dx,dy=u-x,v-y;length=dx*dx+dy*dy
    return ((p[0]-x)*dx+(p[1]-y)*dy)/length if length else 0


def distance(p,item):
    lines=segments(item)
    if lines:
        return min(math.hypot(p[0]-(s[0]+max(0,min(1,projection(p,s)))*(s[2]-s[0])),p[1]-(s[1]+max(0,min(1,projection(p,s)))*(s[3]-s[1]))) for s in lines)
    typ=item.get('display_type',item['type']);c=item['coords']
    if typ in ('CIRCLE','ARC'):
        x,y,r=c
        angle=math.degrees(math.atan2(p[1]-y,p[0]-x))%360
        if typ=='CIRCLE' or on_arc(angle,item):return abs(math.hypot(p[0]-x,p[1]-y)-r)
        from command_points import geometry_points
        return min(math.dist(p,q) for name,q in geometry_points(item).items() if name in ('始点','終点'))
    return math.inf


def on_arc(angle,item):
    return (angle-item['start_angle'])%360<=item['sweep']+1e-9


def select(p,items,tolerance):
    from range_selection import entities
    candidates=[item for item in entities(items) if not item.get('guide') and not item.get('operation_deleted') and distance(p,item)<=tolerance]
    return candidates[0] if len(candidates)==1 else None


def intersections(line,edge, *, extend=False):
    if edge.get('boundary_edges'):
        return sorted(set(t for child in edge['boundary_edges'] for t in intersections(line,child,extend=extend)))
    x,y,u,v=line;dx,dy=u-x,v-y;result=[]
    for a,b,c,d in segments(edge):
        ex,ey=c-a,d-b;den=dx*ey-dy*ex
        if abs(den)<1e-12:continue
        t=((a-x)*ey-(b-y)*ex)/den;s=((a-x)*dy-(b-y)*dx)/den
        if (extend or 0<t<1) and -1e-9<=s<=1+1e-9:result.append(t)
    typ=edge.get('display_type',edge['type'])
    if typ in ('CIRCLE','ARC'):
        cx,cy,r=edge['coords'];aa=dx*dx+dy*dy;bb=2*((x-cx)*dx+(y-cy)*dy);cc=(x-cx)**2+(y-cy)**2-r*r
        det=bb*bb-4*aa*cc
        if det>1e-12:
            for t in ((-bb-math.sqrt(det))/(2*aa),(-bb+math.sqrt(det))/(2*aa)):
                if (extend or 0<t<1) and (typ=='CIRCLE' or on_arc(math.degrees(math.atan2(y+t*dy-cy,x+t*dx-cx))%360,edge)):result.append(t)
    return sorted(set(round(t,12) for t in result))


def apply_edit(item,items,tolerance):
    """Return modified source items so the compiler can refresh point references."""
    typ=item['type']
    if typ in ('COPY','MIRROR'):
        from transform_preview import apply_transform
        return apply_transform(item,items,tolerance)
    a=item['coords'][:2];b=item['coords'][2:4]
    if item.get('selection_box'):
        from range_selection import select_range
        boundaries=select_range(items,item['selection_box'],item['selection_mode'])
        source=dict(type='BOUNDARIES',coords=(),boundary_edges=boundaries) if boundaries else None
    else:source=select(a,items,tolerance)
    if source is None:return []
    if typ=='OFFSET':
        kind=source.get('display_type',source['type']);d=item['distance']
        if kind=='LINE' and len(segments(source))==1:
            x,y,u,v=segments(source)[0];length=math.hypot(u-x,v-y)
            cross=(u-x)*(b[1]-y)-(v-y)*(b[0]-x)
            if abs(cross)/length<=tolerance:raise ValueError('オフセットする側の点を対象の図形から離してください')
            sign=1 if cross>0 else -1;nx,ny=-(v-y)*d*sign/length,(u-x)*d*sign/length
            item.update(display_type='LINE',coords=(x+nx,y+ny,u+nx,v+ny),preview_note='')
        elif kind=='CIRCLE':
            x,y,r=source['coords'];radial=math.hypot(b[0]-x,b[1]-y)
            if abs(radial-r)<=tolerance:raise ValueError('オフセットする側の点を円周から離してください')
            radius=r+(d if radial>r else -d)
            if radius<=0:raise ValueError('内側のオフセット距離が円の半径以上です')
            item.update(display_type='CIRCLE',coords=(x,y,radius),preview_note='')
        return []
    target=select(b,items,tolerance)
    if target is None or target is source:return []
    if target.get('display_type',target['type'])!='LINE':return []
    lines=segments(target);matches=[s for s in lines if distance(b,dict(type='LINE',coords=s))<=tolerance]
    if len(matches)!=1:return []
    line=matches[0]
    if typ=='EXTEND':
        t=projection(b,line);length=math.hypot(line[2]-line[0],line[3]-line[1])
        if abs(t-.5)*length<=tolerance:raise ValueError('延長する側の端点寄りの点を指定してください')
        cuts=intersections(line,source,extend=True)
        options=[c for c in cuts if c>1+1e-9] if t>.5 else [c for c in cuts if c< -1e-9]
        if not options:return []
        at=min(options) if t>.5 else max(options)
        q=(line[0]+at*(line[2]-line[0]),line[1]+at*(line[3]-line[1]))
        updated=(*line[:2],*q) if t>.5 else (*q,*line[2:])
        remaining=[updated if s==line else s for s in lines]
        target['coords']=tuple(z for s in remaining for z in s)
        if len(remaining)>1:target['segments']=remaining
        else:target.pop('segments',None)
        item.update(preview_applied=True,preview_note='延長：線分の編集結果を反映')
        return [target]
    cuts=intersections(line,source)
    if not cuts:return []
    t=projection(b,line);length=math.hypot(line[2]-line[0],line[3]-line[1])
    if any(abs(t-cut)*length<=tolerance for cut in cuts):raise ValueError('トリムの削除側の点を交点から離してください')
    bounds=[0]+cuts+[1];removed=next(((l,r) for l,r in zip(bounds,bounds[1:]) if l<t<r),None)
    if removed is None:return []
    l,r=removed
    at=lambda t:(line[0]+(line[2]-line[0])*t,line[1]+(line[3]-line[1])*t)
    replacement=[]
    if l>0:replacement.append((*at(0),*at(l)))
    if r<1:replacement.append((*at(r),*at(1)))
    remaining=[s for s in lines if s!=line]+replacement
    target['segments']=remaining;target['coords']=tuple(z for s in remaining for z in s)
    if len(remaining)==1:target.pop('segments',None)
    item.update(preview_applied=True,preview_note='トリム：線分の編集結果を反映')
    return [target]
