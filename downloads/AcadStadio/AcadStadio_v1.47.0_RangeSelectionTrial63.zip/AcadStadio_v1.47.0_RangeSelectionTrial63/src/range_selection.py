"""Bounded rectangular selection, independent of the preview camera."""
import math

MODES={'point':'点で選択','window':'範囲内に完全に入る図形','crossing':'範囲に触れる図形も含む'}
RANGE_TYPES=('COPY','MIRROR','TRIM','EXTEND')
MAX_SELECTED=1000


def entities(items):
    for item in items:
        if item.get('operation_deleted'):continue
        if 'children' in item:
            for child in item['children']:
                for key in ('row','block_index','command_index','command_path','command_addresses','guide','definition_block_index'):
                    if key in item:child.setdefault(key,item[key])
            yield from entities(item['children'])
        else:yield item


def box_points(command,number,values):
    if any(k not in command for k in ('x1','y1','x4','y4')):raise ValueError('範囲の始点・対角点が必要です')
    a=tuple(float(number(command[k],values)) for k in ('x1','y1'))
    b=tuple(float(number(command[k],values)) for k in ('x4','y4'))
    if a[0]==b[0] or a[1]==b[1]:raise ValueError('選択範囲の幅と高さは0以外にしてください')
    return (min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1]))


def native_selection(box,mode,destination, *, curves=False):
    """Native W/C selection under a temporary world plan view, then restore it.

    Window ssget can miss off-screen entities. A unique temporary named view
    protects the user's view while making the entire selection rectangle visible.
    """
    x,y,u,v=box;pad=max(u-x,v-y)*.05+1e-6
    option='_W' if mode=='window' else '_C'
    filter_arg=" (list (cons 0 \"LINE,ARC,CIRCLE,LWPOLYLINE,POLYLINE,SPLINE,ELLIPSE\"))" if curves else ''
    return (
        f'(setq {destination} ((lambda (/ name suffix result restored picked) '
        '(setq name "_AcadStadioRange" suffix 0) '
        '(while (tblsearch "VIEW" name) (setq suffix (1+ suffix) name (strcat "_AcadStadioRange" (itoa suffix)))) '
        '(command-s "_.-VIEW" "_Save" name) '
        '(setq result (vl-catch-all-apply \'(lambda () '
        '(if (> (getvar "CVPORT") 1) (command-s "_.PLAN" "_World")) '
        f'(command-s "_.ZOOM" "_Window" (list {x-pad:.12g} {y-pad:.12g} 0.0) (list {u+pad:.12g} {v+pad:.12g} 0.0)) '
        f'(ssget "{option}" (list {x:.12g} {y:.12g} 0.0) (list {u:.12g} {v:.12g} 0.0){filter_arg})'
        ') nil)) '
        '(setq restored (vl-catch-all-apply \'command-s (list "_.-VIEW" "_Restore" name))) '
        '(if (vl-catch-all-error-p restored) (error (strcat "AcadStadio: Restore saved view manually: " name))) '
        '(command-s "_.-VIEW" "_Delete" name) '
        '(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
        '(if (not result) (error "AcadStadio: Range contains no selectable entities")) '
        f'(if (> (sslength result) {MAX_SELECTED}) (error "AcadStadio: Range selection exceeds 1000 entities")) result))) '
    )


def contains(box,p):return box[0]-1e-9<=p[0]<=box[2]+1e-9 and box[1]-1e-9<=p[1]<=box[3]+1e-9


def segment_cross(box,line):
    x,y,u,v=line;dx,dy=u-x,v-y;low,high=0.,1.
    for p,q in [(-dx,x-box[0]),(dx,box[2]-x),(-dy,y-box[1]),(dy,box[3]-y)]:
        if abs(p)<1e-12:
            if q<0:return False
        elif p<0:low=max(low,q/p)
        else:high=min(high,q/p)
    return low<=high


def geometry_bounds(item):
    c=item['coords'];kind=item.get('display_type',item['type'])
    if kind in ('CIRCLE','ARC'):return (c[0]-c[2],c[1]-c[2],c[0]+c[2],c[1]+c[2])
    if kind=='ELLIPSE':
        a=math.radians(item.get('angle',0));dx=math.hypot(c[2]*math.cos(a),c[3]*math.sin(a));dy=math.hypot(c[2]*math.sin(a),c[3]*math.cos(a))
        return (c[0]-dx,c[1]-dy,c[0]+dx,c[1]+dy)
    if kind=='TEXT':
        a=math.radians(item.get('angle',0));w=len(item.get('text',''))*c[2]*.7;h=c[2]
        points=[(c[0]+x*math.cos(a)-y*math.sin(a),c[1]+x*math.sin(a)+y*math.cos(a)) for x,y in ((0,0),(w,0),(w,h),(0,h))]
    elif kind in ('POINT','INSERT'):points=[c[:2]]
    else:
        coords=item.get('curve',c);points=list(zip(coords[::2],coords[1::2]))
    return (min(p[0] for p in points),min(p[1] for p in points),max(p[0] for p in points),max(p[1] for p in points))


def select_range(items,box,mode):
    from edit_preview import segments,intersections
    result=[]
    for item in entities(items):
        if item.get('guide'):continue
        kind=item.get('display_type',item['type'])
        if kind not in ('LINE','POLYLINE','RECTANGLE','CIRCLE','ARC','ELLIPSE','SPLINE','HATCH','LEADER','TEXT','POINT','INSERT'):continue
        if kind=='LINE' and len(segments(item))>1:
            for line in segments(item):
                child=dict(item,coords=line,segments=[],point_id=None,entity_parent=item,entity_segment=line)
                if select_range([child],box,mode):result.append(child)
            if len(result)>MAX_SELECTED:raise ValueError('範囲選択は1000図形までです')
            continue
        bounds=geometry_bounds(item)
        # ARC extents use the actual sampled sweep instead of a full circle.
        if kind=='ARC':
            c=item['coords'];angles=[item['start_angle'],item['start_angle']+item['sweep']]+[a for a in (0,90,180,270) if (a-item['start_angle'])%360<=item['sweep']]
            points=[(c[0]+c[2]*math.cos(math.radians(a)),c[1]+c[2]*math.sin(math.radians(a))) for a in angles]
            bounds=(min(p[0] for p in points),min(p[1] for p in points),max(p[0] for p in points),max(p[1] for p in points))
        inside=contains(box,bounds[:2]) and contains(box,bounds[2:])
        selected=inside
        if not selected and mode=='crossing' and not(bounds[2]<box[0] or bounds[0]>box[2] or bounds[3]<box[1] or bounds[1]>box[3]):
            if kind in ('CIRCLE','ARC'):
                x,y,u,v=box;edges=[(x,y,u,y),(u,y,u,v),(u,v,x,v),(x,v,x,y)]
                selected=any(intersections(edge,item) for edge in edges)
                if kind=='CIRCLE':
                    cx,cy,r=item['coords'];near=(max(x,min(u,cx)),max(y,min(v,cy)))
                    selected=selected or math.isclose(math.dist((cx,cy),near),r,abs_tol=1e-8)
            elif kind in ('TEXT','INSERT','POINT'):selected=True
            else:
                lines=segments(item)
                if not lines:
                    c=item.get('curve',item['coords'])
                    if kind=='ELLIPSE':
                        cx,cy,rx,ry=c;a=math.radians(item.get('angle',0));coords=[]
                        for i in range(129):
                            t=2*math.pi*i/128;coords.extend((cx+rx*math.cos(t)*math.cos(a)-ry*math.sin(t)*math.sin(a),cy+rx*math.cos(t)*math.sin(a)+ry*math.sin(t)*math.cos(a)))
                        c=coords
                    points=list(zip(c[::2],c[1::2]));lines=[(*a,*b) for a,b in zip(points,points[1:])]
                    if kind=='HATCH' and points:lines.append((*points[-1],*points[0]))
                selected=any(segment_cross(box,line) for line in lines)
        if selected:
            result.append(item)
        if len(result)>MAX_SELECTED:raise ValueError('範囲選択は1000図形までです')
    return result


def delete_entity(source):
    parent=source.get('entity_parent')
    if parent is None:
        source['operation_deleted']=True
        return source
    from edit_preview import segments
    remaining=[s for s in segments(parent) if tuple(s)!=tuple(source['entity_segment'])]
    if not remaining:parent['operation_deleted']=True
    else:
        parent['coords']=tuple(z for s in remaining for z in s)
        if len(remaining)>1:parent['segments']=remaining
        else:parent.pop('segments',None)
    return parent
