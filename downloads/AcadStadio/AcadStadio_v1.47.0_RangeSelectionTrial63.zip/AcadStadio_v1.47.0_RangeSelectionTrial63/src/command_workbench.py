"""Small supporting views for the command workbench."""
import tkinter as tk
from tkinter import ttk
from command_points import geometry_points
from engine import row_values, evaluate
from theme import fit_window


def evaluated_fields(project, blocks, items, row, locals_=None):
    values=dict(row_values(project,row),__local__={},__command_points__={},__all_command_points__={})
    for name,expression in (locals_ or {}).items():
        values['__local__'][name]=evaluate(expression,values)
    for item in items:
        bi=item.get('block_index',item.get('preset_index',0));ci=item.get('command_index',-1)
        if not 0<=bi<len(blocks) or not 0<=ci<len(blocks[bi]['commands']):continue
        command=blocks[bi]['commands'][ci]
        if bi==len(blocks)-1 and ci==len(blocks[bi]['commands'])-1:continue
        identity=command.get('point_id')
        if identity:
            if command.get('type') in ('COPY','MIRROR') and command.get('selection_mode','point')!='point':continue
            points=geometry_points(item)
            values['__all_command_points__'][blocks[bi]['id']+'/'+identity]=points
            if bi==len(blocks)-1:values['__command_points__'][identity]=points
    return values


def show_reference_list(parent,groups,on_select):
    win=tk.Toplevel(parent);win.title('列・変数の一覧');win.transient(parent);win.grab_set()
    fit_window(win,500,520,360,300)
    query=tk.StringVar();ttk.Entry(win,textvariable=query).pack(fill='x',padx=12,pady=12)
    listing=tk.Listbox(win,exportselection=False);listing.pack(fill='both',expand=True,padx=12)
    values=[r for _,refs in groups for r in refs]
    def refresh(*_):
        listing.delete(0,'end')
        for value in values:
            if query.get().casefold() in value.casefold():listing.insert('end',value)
    def apply(*_):
        if listing.curselection():on_select(listing.get(listing.curselection()[0]));win.destroy()
    query.trace_add('write',refresh);refresh();listing.bind('<Double-1>',apply)
    bar=ttk.Frame(win,padding=12);bar.pack(fill='x')
    ttk.Button(bar,text='キャンセル',command=win.destroy).pack(side='left')
    ttk.Button(bar,text='参照を挿入',command=apply).pack(side='right')
    parent.wait_window(win)
    restore_parent_grab(parent)


def choose_kind(parent,groups,labels,on_select,icons):
    win=tk.Toplevel(parent);win.title('追加するコマンド');win.transient(parent);win.grab_set()
    fit_window(win,650,540,520,480)
    query=tk.StringVar();entry=ttk.Entry(win,textvariable=query);entry.pack(fill='x',padx=12,pady=12)
    from entry_hints import add_entry_hint
    add_entry_hint(entry, query, 'コマンドを検索')
    categories=ttk.Frame(win);categories.pack(fill='x',padx=12)
    host=ttk.Frame(win,padding=(12,8));host.pack(fill='both',expand=True)
    host.rowconfigure(0,weight=1);host.columnconfigure(0,weight=1)
    canvas=tk.Canvas(host,highlightthickness=0,background='#f3f5f9',height=260)
    canvas.grid(row=0,column=0,sticky='nsew')
    scroll=ttk.Scrollbar(host,command=canvas.yview)
    area=ttk.Frame(canvas,padding=(0,4))
    window=canvas.create_window(0,0,window=area,anchor='nw')
    def scrolled(first,last):
        scroll.set(first,last)
        if area.winfo_reqheight()>canvas.winfo_height():scroll.grid(row=0,column=1,sticky='ns')
        else:scroll.grid_remove()
    canvas.configure(yscrollcommand=scrolled)
    def reflow(event=None):
        canvas.itemconfigure(window,width=canvas.winfo_width())
        canvas.configure(scrollregion=(0,0,canvas.winfo_width(),area.winfo_reqheight()))
        scrolled(*canvas.yview())
    area.bind('<Configure>',reflow,add='+')
    canvas.bind('<Configure>',reflow)
    def wheel(event):
        if str(event.widget).startswith(str(host)):
            direction=-1 if getattr(event,'num',None)==4 or getattr(event,'delta',0)>0 else 1
            canvas.yview_scroll(direction,'units');return 'break'
    for sequence in ('<MouseWheel>','<Button-4>','<Button-5>'):win.bind(sequence,wheel,add='+')
    active=[0];column_count=[3]
    def draw(*_):
        canvas.yview_moveto(0)
        columns=2 if 1<area.winfo_width()<620 else 3
        column_count[0]=columns
        for j,b in enumerate(buttons):b.configure(style="WorkbenchSegmentOn.TButton" if j==active[0] else "WorkbenchSegment.TButton")
        for child in area.winfo_children():child.destroy()
        kinds=[kind for _,group in groups for kind in group] if query.get() else groups[active[0]][1]
        filtered=[k for k in kinds if query.get().casefold() in labels[k].casefold()]
        for i,kind in enumerate(filtered):
            icon=next(('blocks','script','tree')[j] for j,(_,group) in enumerate(groups) if kind in group)
            button=ttk.Button(area,text=labels[kind],image=shape_icon(icons,kind) if kind in ('LINE','POLYLINE','CIRCLE','ARC','ELLIPSE','RECTANGLE','POINT') else icons.get(icon),compound='left',command=lambda k=kind:(win.destroy(),on_select(k)))
            button.grid(row=i//columns,column=i%columns,sticky='ew',padx=4,pady=5)
        for i in range(3):area.columnconfigure(i,weight=1 if i<columns else 0)
    buttons=[]
    for i,(title,_) in enumerate(groups):
        name=title.replace('を追加 ▾','')
        button=ttk.Button(categories,text=name,command=lambda j=i:(active.__setitem__(0,j),query.set(''),draw()))
        button.pack(side='left',padx=(0,5));buttons.append(button)
    def resize(event):
        columns=2 if event.width<620 else 3
        if columns!=column_count[0]:draw()
    area.bind('<Configure>',resize,add='+')
    if parent.winfo_width()>=520:
        x=min(parent.winfo_rootx(),win.winfo_screenwidth()-650)
        y=min(parent.winfo_rooty(),win.winfo_screenheight()-480)
        win.geometry(f'{min(650,parent.winfo_width())}x540+{max(0,x)}+{max(0,y)}')
    query.trace_add('write',draw);draw();entry.focus_set()
    ttk.Button(win,text='キャンセル',command=win.destroy).pack(anchor='w',padx=12,pady=10)
    parent.wait_window(win)
    restore_parent_grab(parent)


def shape_icon(icons, kind):
    """Tiny native icons for the shape palette, cached with the normal icons."""
    import math
    shapes={'LINE':[(3,17),(17,3)],'POLYLINE':[(2,16),(7,5),(12,14),(18,3)],
            'RECTANGLE':[(3,4),(17,4),(17,16),(3,16),(3,4)]}
    key='shape_'+kind
    if key in icons.images:return icons.images[key]
    points=shapes.get(kind)
    if kind in ('CIRCLE','ELLIPSE','ARC'):
        stop=math.pi*2 if kind!='ARC' else math.pi
        points=[(10+7*math.cos(i*stop/48),10-(4 if kind=='ELLIPSE' else 7)*math.sin(i*stop/48)) for i in range(49)]
    if kind=='POINT':points=[(9,10),(11,10)]
    if not points:return icons.get('commands')
    image=tk.PhotoImage(master=icons.root,width=20,height=20)
    for (x1,y1),(x2,y2) in zip(points,points[1:]):
        steps=max(1,int(max(abs(x2-x1),abs(y2-y1))*3))
        for i in range(steps+1):
            x=round(x1+(x2-x1)*i/steps);y=round(y1+(y2-y1)*i/steps)
            if 0<=x<19 and 0<=y<19:image.put('#3568a6',to=(x,y,x+2,y+2))
    icons.images[key]=image
    return image


def restore_parent_grab(parent):
    """Modal children must return the grab to the whole editor, never its list."""
    try:
        host=parent.winfo_toplevel()
        if host.winfo_exists() and host is not host._root():host.grab_set()
    except tk.TclError:
        pass
