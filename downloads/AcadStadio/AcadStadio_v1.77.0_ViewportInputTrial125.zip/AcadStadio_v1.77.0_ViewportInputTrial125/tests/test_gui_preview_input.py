import os,sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class PreviewInputGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def prior(self):return [dict(type='LINE',x1='-20',y1='0',x2='100',y2='0'),dict(type='CIRCLE',x='30',y='30',r='5')]
 def stage(self,fn):
  try:fn(gui.top(self.root,'コマンドの設定'))
  except Exception as exc:
   self.errors.append(exc)
   for w in list(gui.descendants(self.root)):
    if isinstance(w,gui.tk.Toplevel) and w.winfo_exists():w.destroy()
 def click(self,c,point):
  x,y=c.screen_point(point);c.event_generate('<ButtonPress-1>',x=round(x),y=round(y));c.event_generate('<ButtonRelease-1>',x=round(x),y=round(y));self.root.update()
 def edit(self,kind,fn,prior=None,**extra):
  self.root.after(220,lambda:self.stage(fn))
  return edit_command(self.root,dict(type=kind,**extra),self.app.data['blocks'],self.app.data,point_sources=self.prior() if prior is None else prior,creating=True)
 def compile(self,prior,result):
  p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=prior+[result])];return compile_project(p,[0])[1]
 def test_line_clicks_fill_vertices_and_accept_with_compact_form(self):
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas;direct=w.preview_input
   self.assertTrue(direct.capturing);self.assertFalse(w.command_viewport.winfo_ismapped())
   self.click(c,(10,10));self.click(c,(80,20));self.assertEqual(len(direct.picks),2)
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit('LINE',inspect);self.assertIsNotNone(result);items=self.compile(self.prior(),result)
  self.assertEqual(len(items),3);self.assertEqual(items[-1]['type'],'LINE');self.assertGreater(items[-1]['coords'][2],items[-1]['coords'][0])
 def test_circle_drag_then_latest_scalar_is_kept(self):
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas
   a=c.screen_point((50,15));b=c.screen_point((60,15))
   c.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]));c.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]));c.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]));self.root.update()
   self.assertFalse(w.preview_input.capturing);e=w.preview_input.compact_entries['r'];e.delete(0,'end');e.insert(0,'17')
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit('CIRCLE',inspect);self.assertIsNotNone(result);self.assertEqual(self.compile(self.prior(),result)[-1]['coords'][2],17)
 def test_diameter_picks_circle_then_label_retains_reference(self):
  prior=self.prior()
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas
   self.click(c,(30,30));self.click(c,(60,40));self.assertFalse(w.preview_input.capturing);gui.button(w,'コマンドを反映').invoke()
  result=self.edit('DIMDIAMETER',inspect,prior=prior);self.assertIsNotNone(result);self.assertIn('点(',result['x']);self.assertEqual(self.compile(prior,result)[-1]['type'],'DIMDIAMETER')
 def test_copy_clicks_and_immediate_scalar_or_geometry_fields_survive(self):
  prior=self.prior()+[dict(type='SELECT',point_id='p_'+'a'*32,selection_name='対象',selections=[dict(mode='window',x1='-21',y1='-1',x4='101',y4='36')])]
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas
   self.click(c,(10,10));self.click(c,(50,20));gui.button(w,'コマンドを反映').invoke()
  result=self.edit('COPY',inspect,prior=prior,selection_ref='p_'+'a'*32);self.assertIsNotNone(result);self.compile(prior,result)
 def test_partial_points_survive_redraw_and_escape_undo(self):
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas
   self.click(c,(10,10));w.refresh_command_preview();self.root.update();self.assertEqual(len(w.preview_input.picks),1);self.assertTrue(c.find_withtag('direct-input'))
   self.assertTrue(w.preview_input.escape());self.assertEqual(w.preview_input.picks,[]);gui.button(w,'キャンセル').invoke()
  self.assertIsNone(self.edit('POLYLINE',inspect))
 def test_control_condition_evaluation_is_visible(self):
  def inspect(w):
   w.refresh_command_preview();self.root.update();self.assertTrue(w.preview_input.message.get());self.assertIn('条件',w.preview_input.message.get());gui.button(w,'キャンセル').invoke()
  self.assertIsNone(self.edit('IF',inspect))
 def test_circle_mode_switch_preserves_center_and_size(self):
  def inspect(w):
   w.refresh_command_preview();self.root.update();w.circle_mode_picker.set('直径');w.circle_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update()
   self.assertEqual(w.command_entries['x'].get(),'123');self.assertEqual(w.command_entries['y'].get(),'456')
   from engine import evaluate
   self.assertEqual(evaluate(w.command_entries['diameter'].get(),{}),74);gui.button(w,'キャンセル').invoke()
  self.assertIsNone(self.edit('CIRCLE',inspect,x='123',y='456',r='37'))

 def test_existing_circle_handle_drag_keeps_formula(self):
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas;self.assertFalse(w.preview_input.capturing)
   a=c.screen_point((100,100));b=c.screen_point((110,120))
   c.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]));c.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]));c.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]));self.root.update()
   self.assertIn('@X',w.command_entries['x'].get());self.assertNotEqual(w.coordinate_values['x'].movement.get(),'0');gui.button(w,'コマンドを反映').invoke()
  self.root.after(220,lambda:self.stage(inspect))
  result=edit_command(self.root,dict(type='CIRCLE',x='@X',y='@Y',r='25'),self.app.data['blocks'],self.app.data,point_sources=self.prior())
  self.assertIsNotNone(result);self.assertAlmostEqual(self.compile(self.prior(),result)[-1]['coords'][0],110,delta=.5)
 def test_latest_copy_count_is_used_when_gesture_finishes(self):
  prior=self.prior()+[dict(type='SELECT',point_id='p_'+'a'*32,selection_name='対象',selections=[dict(mode='window',x1='-21',y1='-1',x4='101',y4='36')])]
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas;self.click(c,(10,10))
   e=w.preview_input.compact_entries['copy_count'];e.delete(0,'end');e.insert(0,'7')
   self.click(c,(10,20));gui.button(w,'コマンドを反映').invoke()
  result=self.edit('ROTATECOPY',inspect,prior=prior,selection_ref='p_'+'a'*32)
  self.assertIsNotNone(result);self.assertEqual(result['copy_count'],'7');self.compile(prior,result)
 def test_viewport_paper_model_steps_and_pan(self):
  from block_model import new_block
  model=new_block('モデル',commands=[dict(type='CIRCLE',x='50',y='50',r='10')]);model['drawing_space']='Model'
  paper=new_block('用紙',commands=[]);paper['drawing_space']='A4'
  project=copy.deepcopy(self.app.data);project['blocks']=[model,paper]
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas
   self.assertEqual(c.space_tabs.active,'A4');self.assertFalse(any(i.get('type')=='RECTANGLE' for i in c.items));self.click(c,(10,10));self.assertFalse(any(i.get('type')=='RECTANGLE' for i in c.items));self.click(c,(100,100));self.assertEqual(c.space_tabs.active,'Model')
   self.click(c,(50,50));self.assertFalse(w.preview_input.capturing);self.assertEqual(c.space_tabs.active,'A4')
   a=c.screen_point((25,25));b=c.screen_point((27,28))
   c.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]));c.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]));c.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]));self.root.update()
   frames=[i for i in c.items if i.get('viewport_view')];self.assertTrue(frames);self.assertAlmostEqual(frames[0]['viewport_view']['center'][0],46,delta=.8)
   gui.button(w,'コマンドを反映').invoke()
  self.root.after(220,lambda:self.stage(inspect))
  result=edit_command(self.root,dict(type='VIEWPORT',view_scale='1/2'),project['blocks'],project,previous_blocks=[model],owner_block_id=paper['id'],owner_space='A4',creating=True)
  self.assertIsNotNone(result);self.assertTrue(result['configure_view']);self.assertIn('点(',result['view_x'])
 def test_batch_system_variables_show_errors_before_accept(self):
  def inspect(w):
   w.refresh_command_preview();self.root.update();ed=w.system_variables_editor
   ed.rows[0]['value'].set('2*');self.root.update();gui.button(w,'コマンドを反映').invoke();self.assertTrue(w.winfo_exists());self.assertTrue(self.messages)
   ed.rows[0]['value'].set('@OD/2');w.refresh_command_preview();self.root.update();self.assertIn('50',ed.feedback_labels[0].cget('text'))
   self.assertIn('数値・式',ed.row_widgets[0]['value_kind'].cget('values'));gui.button(w,'コマンドを反映').invoke()
  result=self.edit('SYSVARS',inspect,items=[dict(name='USERR1',value_kind='number',value='1')]);self.assertIsNotNone(result);self.assertEqual(result['items'][0]['value'],'@OD/2')

 def test_hatch_inside_rectangle_creates_referenced_boundary(self):
  prior=[dict(type='RECTANGLE',x1='0',y1='0',x2='100',y2='60')]
  def inspect(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas;self.click(c,(30,20))
   self.assertFalse(w.preview_input.capturing);gui.button(w,'コマンドを反映').invoke()
  result=self.edit('HATCH',inspect,prior=prior);self.assertIsNotNone(result);self.assertIn('点(',result['vertices'][0]['x']);self.assertEqual(self.compile(prior,result)[-1]['type'],'HATCH')

 def test_auto_trim_selection_names_boundary(self):
  def inspect(w):
   self.assertIn('切断境界',w.select_editor.purpose);gui.button(w,'キャンセル').invoke()
  self.assertIsNone(self.edit('TRIM',inspect))
 def test_compact_scalar_focus_targets_correct_original_entry(self):
  def inspect(w):
   w.refresh_command_preview();self.root.update();e=w.preview_input.compact_entries['r'];e.focus_force();self.root.update()
   self.assertIs(self.root.focus_get(),e);gui.button(w,'キャンセル').invoke()
  self.assertIsNone(self.edit('CIRCLE',inspect))

 def test_snapped_points_save_references_and_follow_source_changes(self):
  prior=self.prior()
  def inspect(w):
   c=w.command_preview.canvas;direct=w.preview_input
   x,y=c.screen_point((-20,0));c.event_generate('<Motion>',x=round(x)+3,y=round(y)+2);self.root.update()
   texts=[c.itemcget(n,'text') for n in c.find_withtag('direct-input') if c.type(n)=='text']
   self.assertTrue(any('始点（点参照）' in text for text in texts))
   for point in [(-20,0),(30,30)]:
    x,y=c.screen_point(point)
    c.event_generate('<ButtonPress-1>',x=round(x)+3,y=round(y)+2)
    c.event_generate('<ButtonRelease-1>',x=round(x)+3,y=round(y)+2);self.root.update()
   self.assertEqual([p['snap_name'] for p in direct.picks],['始点','中心'])
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit('LINE',inspect,prior=prior)
  self.assertIsNotNone(result)
  for vertex in result['vertices']:
   self.assertIn('点(',vertex['x']);self.assertIn('点(',vertex['y'])
  self.assertIn(prior[0]['point_id'],result['vertices'][0]['x'])
  self.assertIn(prior[1]['point_id'],result['vertices'][1]['x'])
  prior[0]['x1']='-40';prior[1].update(x='60',y='45')
  self.assertEqual(self.compile(prior,result)[-1]['coords'],(-40.,0.,60.,45.))

 def test_rectangle_corner_aliases_snap_without_candidate_dialog(self):
  prior=[dict(type='RECTANGLE',x1='0',y1='0',x2='100',y2='50')]
  def inspect(w):
   c=w.command_preview.canvas;x,y=c.screen_point((0,0))
   choices=w.preview_input.candidates(x+2,y+1)
   self.assertEqual(len(choices),1)
   self.assertTrue(choices[0]['snap_name'])
   self.click(c,(0,0));self.click(c,(100,50))
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit('LINE',inspect,prior=prior)
  self.assertIsNotNone(result);self.assertIn('点(',result['vertices'][0]['x'])

 def test_body_click_selects_command_then_named_point_without_xy_capture(self):
  prior=[dict(type='LINE',x1='-20',y1='0',x2='100',y2='0'),dict(type='CIRCLE',x='30',y='40',r='20')]
  def inspect(w):
   c=w.command_preview.canvas;d=w.preview_input
   self.click(c,(0,0))
   self.assertEqual(len(d.picks),0)
   self.assertIsNotNone(d.reference_source)
   labels=[c.itemcget(n,'text') for n in c.find_withtag('direct-input') if c.type(n)=='text']
   self.assertIn('始点',labels);self.assertIn('中点',labels);self.assertIn('終点',labels)
   self.click(c,(80,60));self.assertEqual(len(d.picks),0)
   self.click(c,(100,0));self.assertEqual(len(d.picks),1);self.assertEqual(d.picks[0]['snap_name'],'終点')
   self.click(c,(44.142,54.142));self.assertEqual(len(d.picks),1)
   self.assertIsNotNone(d.reference_source)
   self.click(c,(30,40));self.assertEqual(len(d.picks),2)
   self.assertEqual(d.picks[1]['snap_name'],'中心')
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit('LINE',inspect,prior=prior)
  self.assertIsNotNone(result)
  self.assertIn('終点',result['vertices'][0]['x']);self.assertIn('中心',result['vertices'][1]['x'])
  prior[0]['x2']='120';prior[1]['x']='50'
  self.assertEqual(self.compile(prior,result)[-1]['coords'],(120.,0.,50.,40.))

 def test_circle_virtual_corner_selection_and_source_change(self):
  prior=[dict(type='CIRCLE',x='30',y='40',r='20')]
  def inspect(w):
   c=w.command_preview.canvas;d=w.preview_input
   self.click(c,(44.142,54.142));self.assertEqual(len(d.picks),0)
   labels=[c.itemcget(n,'text') for n in c.find_withtag('direct-input') if c.type(n)=='text']
   for name in ('左上','右上','左下','右下'):self.assertIn('仮想交点・'+name,labels)
   self.assertTrue(any(c.type(n)=='rectangle' and c.itemcget(n,'dash') for n in c.find_withtag('direct-input')))
   self.click(c,(50,60));self.click(c,(10,20))
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit('LINE',inspect,prior=prior)
  self.assertIsNotNone(result)
  self.assertIn('仮想交点・右上',result['vertices'][0]['x']);self.assertIn('仮想交点・左下',result['vertices'][1]['y'])
  prior[0].update(x='50',y='60',r='30')
  self.assertEqual(self.compile(prior,result)[-1]['coords'],(80.,90.,20.,30.))

 def test_middle_pan_and_zoom_keep_picked_point_overlay_aligned(self):
  def inspect(w):
   c=w.command_preview.canvas;d=w.preview_input
   self.click(c,(-20,0));self.assertEqual(len(d.picks),1)
   c.event_generate('<ButtonPress-2>',x=300,y=250)
   c.event_generate('<B2-Motion>',x=350,y=290)
   c.event_generate('<ButtonRelease-2>',x=350,y=290);self.root.update()
   def check():
    target=c.screen_point(d.picks[0]['xy'])
    picked=[n for n in c.find_withtag('direct-input') if c.type(n)=='oval' and c.itemcget(n,'fill')=='#fbbf24']
    self.assertTrue(picked)
    box=c.coords(picked[0]);self.assertAlmostEqual((box[0]+box[2])/2,target[0],delta=.01);self.assertAlmostEqual((box[1]+box[3])/2,target[1],delta=.01)
    self.assertAlmostEqual(c.world_point(*target)[0],-20,delta=.001)
   check()
   from types import SimpleNamespace
   c.zoom(SimpleNamespace(x=400,y=350,delta=120),1.2);self.root.update();check()
   self.click(c,(100,0));self.assertEqual(d.picks[1]['snap_name'],'終点')
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit('LINE',inspect);self.assertIsNotNone(result);self.assertIn('点(',result['vertices'][1]['x'])

 def test_existing_viewport_corner_resize_and_center_frame_move(self):
  from block_model import new_block
  model=new_block('モデル',commands=[dict(type='CIRCLE',x='50',y='50',r='10')]);model['drawing_space']='Model'
  command=dict(type='VIEWPORT',viewport_action='矩形を作成',configure_view=True,x1='10',y1='10',x2='100',y2='80',view_x='50',view_y='50',view_scale='1')
  paper=new_block('用紙',commands=[command]);paper['drawing_space']='A4'
  project=copy.deepcopy(self.app.data);project['blocks']=[model,paper]
  def inspect(w):
   c=w.command_preview.canvas
   self.assertFalse(w.preview_input.capturing);self.assertEqual(c.space_tabs.active,'A4')
   c.event_generate('<ButtonPress-2>',x=300,y=250);c.event_generate('<B2-Motion>',x=345,y=280);c.event_generate('<ButtonRelease-2>',x=345,y=280);self.root.update()
   def drag(a,b):
    a=c.screen_point(a);b=c.screen_point(b)
    c.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]));c.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]));c.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]));self.root.update()
   drag((100,80),(120,90))
   frame=next(i for i in c.items if i.get('viewport_view'))
   self.assertAlmostEqual(frame['coords'][2],120,delta=.5);self.assertAlmostEqual(frame['coords'][3],90,delta=.5)
   center=((frame['coords'][0]+frame['coords'][2])/2,(frame['coords'][1]+frame['coords'][3])/2)
   drag(center,(center[0]+5,center[1]+7))
   frame=next(i for i in c.items if i.get('viewport_view'))
   self.assertAlmostEqual(frame['coords'][0],15,delta=.6);self.assertAlmostEqual(frame['coords'][1],17,delta=.6)
   self.assertEqual(frame['viewport_view']['center'],(50.,50.))
   gui.button(w,'コマンドを反映').invoke()
  self.root.after(220,lambda:self.stage(inspect))
  result=edit_command(self.root,command,project['blocks'],project,previous_blocks=[model],owner_block_id=paper['id'],owner_space='A4')
  self.assertIsNotNone(result)
