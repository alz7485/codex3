"""Find an unambiguous point on a chosen figure and save a dynamic reference."""
import math
from command_points import geometry_points,reference
from range_selection import entities
from selection_sets import DXF_TYPES
from transform_preview import general_distance


def exclusion_reference(source, items, clicked, tolerance, identity):
    if source.get('entity_parent') is not None:
        raise ValueError('分割された線の一部分は点参照で除外できません。元図形を確認してください。')
    points=geometry_points(source)
    kind=source.get('display_type',source['type'])
    candidates=[]
    for name,p in points.items():
        # Prefer points on the outline rather than the centre of a curve.
        if kind in ('CIRCLE','ARC','ELLIPSE') and name=='中心':continue
        candidates.append((p,lambda key,axis,n=name:reference(key,n,axis)))
    if kind in ('LINE','POLYLINE','LEADER','DIMLINEAR','DIMALIGNED'):
        vertices=[n for n in points if n.startswith('頂点') and '中点' not in n]
        pairs=[('寸法線始点','寸法線終点')] if kind in ('DIMLINEAR','DIMALIGNED') else list(zip(vertices,vertices[1:])) if vertices else [('始点','終点')]
        if source.get('closed') and vertices:pairs.append((vertices[-1],vertices[0]))
        for a,b in pairs:
            if a not in points or b not in points:continue
            for t in (.25,.75,.125,.375,.625,.875):
                p=tuple(points[a][i]*(1-t)+points[b][i]*t for i in (0,1))
                candidates.append((p,lambda key,axis,a=a,b=b,t=t:f'({reference(key,a,axis)})*{1-t}+({reference(key,b,axis)})*{t}'))
    if kind in ('CIRCLE','ARC'):
        cx,cy,r=source['coords'][:3]
        start=source.get('start_angle',0);sweep=source.get('sweep',360)
        for i in range(1,32):
            angle=(start+sweep*i/32)%360
            p=(cx+r*math.cos(math.radians(angle)),cy+r*math.sin(math.radians(angle)))
            name='右' if kind=='CIRCLE' else '角度指定点'
            candidates.append((p,lambda key,axis,a=angle,n=name:reference(key,n,axis,a)))
    pool=[s for s in entities(items) if not s.get('guide') and s.get('display_type',s['type']) in DXF_TYPES and s.get('cad_space','Model')==source.get('cad_space','Model')]
    for p,expression in sorted(candidates,key=lambda c:math.dist(c[0],clicked)):
        if general_distance(p,source)>tolerance:continue
        if any(other is not source and general_distance(p,other)<=tolerance for other in pool):continue
        key=identity(source)
        if not key:raise ValueError('除外図形の点参照元を特定できません。')
        return dict(mode='point',x1=expression(key,'X'),y1=expression(key,'Y'),entity_type=kind,unique_pick=True)
    raise ValueError('他の図形と重ならない点参照を作れません。同じ位置の図形や選択許容差を確認してください。')
