"""Availability for new commands; legacy saved commands remain readable."""
def block_space(blocks, owner_id, project=None):
    block=next((b for b in blocks if b.get('id')==owner_id),{}) if isinstance(blocks,list) else {}
    if block.get('drawing_space'):return block['drawing_space']
    if project and block.get('folder_id'):
        from space_folders import folder_space
        return folder_space(project,block['folder_id']) or 'Model'
    return 'Model'

def creation_reason(kind,space):
    if kind=='SPACE':return '作図空間はブロック一覧で選んだ場所に従います。'
    if kind=='LAYOUT':return 'レイアウトはプレビュータブの「＋」から追加してください。'
    if kind=='VIEWPORT' and space in ('Model','モデル','コマンドに従う','',None):return 'ビューポートはレイアウトのブロックで追加してください。'
    return ''
