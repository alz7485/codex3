"""Return to the requesting Tk window after a CAD operation completes."""
import tkinter as tk

def restore(window):
    try:
        if not window.winfo_exists():return
        window.lift();window.focus_force()
        if window.tk.call('tk','windowingsystem')=='win32':
            import ctypes
            from ctypes import wintypes
            api=ctypes.windll.user32
            api.GetAncestor.argtypes=(wintypes.HWND,wintypes.UINT);api.GetAncestor.restype=wintypes.HWND
            api.ShowWindow.argtypes=(wintypes.HWND,ctypes.c_int)
            api.SetForegroundWindow.argtypes=(wintypes.HWND,)
            hwnd=api.GetAncestor(window.winfo_id(),2)
            if hwnd:api.ShowWindow(hwnd,9);api.SetForegroundWindow(hwnd)
    except (tk.TclError,OSError,AttributeError):pass
