"""Editable variable rows; changes are staged until Apply closes the window."""
import copy
import tkinter as tk
from tkinter import ttk

from engine import MacroError, RowResolver, convert, evaluate, parse_expression
from project_data import current_table
from project_model import valid_variable_name
from theme import fit_window


class VariableEditor:
    def __init__(self, app, values, *, parent=None, title='変数', validator=None):
        self.app = app
        self.parent = (parent or app.root).winfo_toplevel()
        self.snapshot = copy.deepcopy(app.data)
        self.validator = validator
        self.result = None
        self.rows = []
        self.job = None
        self.win = tk.Toplevel(self.parent)
        self.win.title(title)
        self.win.transient(self.parent)
        self.win.grab_set()
        fit_window(self.win, 1050, 650, 760, 440)
        self.win.variable_editor = self
        self.win.protocol('WM_DELETE_WINDOW', self.cancel)
        self.win.bind('<Escape>', lambda e: self.cancel())
        self.win.bind('<Destroy>', self.destroyed, add='+')
        top = self.top = ttk.Frame(self.win, padding=(12, 10, 12, 6))
        top.pack(fill='x')
        self.add_button = ttk.Button(top, text='＋ 変数を追加', command=self.add)
        self.add_button.icon_only = False
        self.add_button.pack(side='left')
        self.count = ttk.Label(top, style='Muted.TLabel')
        self.count.pack(side='left', padx=10)
        self.help_open = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text='入力例', variable=self.help_open,
                        command=self.toggle_help).pack(side='right')
        self.help = ttk.Label(self.win, text='数値：100　 計算：100 / 2　 表：@OD / 2　 変数：変数.尺度　 文字："名称"',
                              wraplength=900, style='Muted.TLabel', padding=(12, 2, 12, 6))
        try:
            self.row_index = (app.preview_rows() or [0])[0]
        except ValueError:
            self.row_index = 0
        table = current_table(self.snapshot)
        self.table_name = table['name']
        context = (f"{self.table_name} / {self.row_index+1}行目" if table['rows'] else '行なし・定数の確認')
        info = ttk.Frame(self.win, padding=(12, 0, 12, 8))
        info.pack(fill='x')
        ttk.Label(info, text='作図からは「変数.名前」で使います。', style='Muted.TLabel').pack(side='left')
        ttk.Label(info, text='確認値：' + context, style='Muted.TLabel').pack(side='right')
        footer = ttk.Frame(self.win, padding=12)
        footer.pack(side='bottom', fill='x')
        self.status = tk.StringVar(value='')
        self.status_label = ttk.Label(footer, textvariable=self.status, wraplength=580)
        self.status_label.pack(side='left', fill='x', expand=True)
        self.status_label.bind('<Configure>', lambda e: self.status_label.configure(wraplength=max(180, e.width)))
        self.apply_button = ttk.Button(footer, text='適用して閉じる', command=self.commit, style='Primary.TButton')
        self.apply_button.icon_only = False
        self.apply_button.pack(side='right', padx=(8, 0))
        ttk.Button(footer, text='キャンセル', command=self.cancel).pack(side='right', padx=4)
        body = ttk.Frame(self.win, padding=(12, 0, 12, 0))
        body.pack(fill='both', expand=True)
        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=1)
        self.canvas = tk.Canvas(body, highlightthickness=0, background='white')
        self.canvas.grid(row=0, column=0, sticky='nsew')
        scroll = ttk.Scrollbar(body, command=self.canvas.yview)
        scroll.grid(row=0, column=1, sticky='ns')
        self.canvas.configure(yscrollcommand=scroll.set)
        self.content = ttk.Frame(self.canvas, padding=6, style='Surface.TFrame')
        self.node = self.canvas.create_window(0, 0, window=self.content, anchor='nw')
        for column, weight in ((0, 2), (1, 5), (2, 3)):
            self.content.columnconfigure(column, weight=weight)
        for column, text in enumerate(('変数名', '値・式', '確認値', '', '')):
            ttk.Label(self.content, text=text, style='SurfaceTitle.TLabel').grid(row=0, column=column, sticky='w', padx=4, pady=(0, 6))
        self.empty = ttk.Label(self.content, text='変数はまだありません。「＋ 変数を追加」から作成できます。', style='SurfaceMuted.TLabel')
        self.content.bind('<Configure>', self.resize)
        self.canvas.bind('<Configure>', self.resize)
        for sequence in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
            self.win.bind(sequence, self.wheel, add='+')
        for name, value in values.items():
            self.add(name, str(value), focus=False)
        self.arrange()
        self.refresh()

    def run(self):
        self.parent.wait_window(self.win)
        return self.result

    def resize(self, event=None):
        self.canvas.itemconfigure(self.node, width=max(1, self.canvas.winfo_width()))
        self.canvas.configure(scrollregion=self.canvas.bbox('all'))

    def wheel(self, event):
        if self.content.winfo_height() <= self.canvas.winfo_height():
            return
        widget = event.widget
        if widget is not self.canvas and not str(widget).startswith(str(self.content)):
            return
        step = -1 if event.num == 4 else 1 if event.num == 5 else -1 if event.delta > 0 else 1
        self.canvas.yview_scroll(step, 'units')

    def toggle_help(self):
        if self.help_open.get():
            self.help.pack(fill='x', after=self.top)
        else:
            self.help.pack_forget()

    def add(self, name=None, expression='0', *, focus=True):
        if name is None:
            taken = {row['name'].get().strip() for row in self.rows}
            number = 1
            while f'新しい変数{number}' in taken:
                number += 1
            name = f'新しい変数{number}'
        row = dict(name=tk.StringVar(self.win, value=name), expression=tk.StringVar(self.win, value=expression))
        row['name_entry'] = ttk.Entry(self.content, textvariable=row['name'], width=14)
        row['value_entry'] = ttk.Entry(self.content, textvariable=row['expression'], width=22)
        row['feedback'] = ttk.Label(self.content, text='', width=1, wraplength=200, style='Surface.TLabel')
        row['reference_button'] = ttk.Menubutton(self.content, text='参照', width=0)
        row['menu'] = tk.Menu(row['reference_button'], tearoff=False,
                              postcommand=lambda: self.reference_menu(row))
        row['reference_button'].configure(menu=row['menu'])
        row['delete_button'] = ttk.Button(self.content, text='削除', command=lambda: self.delete(row))
        row['delete_button'].icon_only = False
        row['widgets'] = [row[key] for key in ('name_entry', 'value_entry', 'feedback', 'reference_button', 'delete_button')]
        row['name_entry'].bind('<Return>', lambda e: (row['value_entry'].focus_set(), 'break')[-1])
        row['value_entry'].bind('<Return>', lambda e: self.confirm_row(row))
        for value in (row['name'], row['expression']):
            value.trace_add('write', self.changed)
        row['feedback'].bind('<Enter>', lambda e: self.app.icons.schedule(row['feedback'], row.get('detail', '')))
        row['feedback'].bind('<Leave>', lambda e: self.app.icons.hide())
        self.rows.append(row)
        self.arrange()
        self.changed()
        if focus:
            self.win.after_idle(lambda: self.reveal(row))
        return row

    def arrange(self):
        self.empty.grid_remove()
        if not self.rows:
            self.empty.grid(row=1, column=0, columnspan=5, sticky='w', pady=18)
        for index, row in enumerate(self.rows, 1):
            for column, widget in enumerate(row['widgets']):
                widget.grid(row=index, column=column, sticky='ew', padx=4, pady=4)
        self.count.configure(text=f'{len(self.rows)}件')

    def reveal(self, row):
        if row not in self.rows:
            return
        self.win.update_idletasks()
        entry = row['name_entry']
        bottom = entry.winfo_y() + entry.winfo_height() + 8
        top = entry.winfo_y() - 8
        if bottom > self.canvas.canvasy(0) + self.canvas.winfo_height():
            self.canvas.yview_moveto((bottom-self.canvas.winfo_height())/max(1, self.content.winfo_height()))
        elif top < self.canvas.canvasy(0):
            self.canvas.yview_moveto(top/max(1, self.content.winfo_height()))
        entry.focus_set()
        entry.selection_range(0, 'end')

    def delete(self, row):
        self.rows.remove(row)
        for widget in row['widgets']:
            widget.destroy()
        self.arrange()
        self.changed()

    def confirm_row(self, row):
        self.refresh()
        index = self.rows.index(row)
        if index+1 < len(self.rows):
            self.reveal(self.rows[index+1])
        else:
            self.add_button.focus_set()
        return 'break'

    def reference_menu(self, row):
        menu = row['menu']
        menu.delete(0, 'end')
        menu.add_command(label='表の列・セルから置き換える…', command=lambda: self.table_reference(row))
        names = [other['name'].get().strip() for other in self.rows
                 if other is not row and valid_variable_name(other['name'].get().strip())]
        if names:
            menu.add_separator()
            for name in names:
                menu.add_command(label='変数.'+name, command=lambda value=name: row['expression'].set('変数.'+value))

    def table_reference(self, row):
        from input_assist import show_table_reference_picker
        project = dict(self.snapshot, globals=self.data())
        show_table_reference_picker(self.win, project, row['expression'].set, on_replace=row['expression'].set)

    def data(self):
        return {row['name'].get().strip(): row['expression'].get().strip() for row in self.rows}

    def changed(self, *_):
        if self.job is not None:
            self.win.after_cancel(self.job)
        self.job = self.win.after(150, self.refresh)

    def refresh(self):
        if self.job is not None:
            self.win.after_cancel(self.job)
            self.job = None
        names = [row['name'].get().strip() for row in self.rows]
        resolver = RowResolver(dict(self.snapshot, globals=self.data()), convert, evaluate, MacroError)
        self.errors = []
        calculation_errors = []
        for row, name in zip(self.rows, names):
            value = row['expression'].get().strip()
            error, field = '', 'name_entry'
            if not valid_variable_name(name):
                error = '名前を入力してください。日本語・英数字・_を使用し、空白や予約名は避けてください。'
            elif names.count(name) > 1:
                error = f'「{name}」が重複しています。別の名前にしてください。'
            else:
                field = 'value_entry'
                try:
                    if not value:
                        raise MacroError('値・式を入力してください。')
                    parse_expression(value)
                except MacroError as exc:
                    error = str(exc)
            if error:
                self.errors.append((row, field, error))
                text = '名前を確認' if field == 'name_entry' else '式を確認'
            else:
                try:
                    result = resolver.variable(self.table_name, self.row_index, name)
                    text = format(result, '.10g') if type(result) in (int, float) else str(result)
                except (MacroError, ValueError, ArithmeticError, KeyError) as exc:
                    error = str(exc)
                    calculation_errors.append(error)
                    text = '確認行では計算できません'
            row['detail'] = error or text
            row['feedback'].configure(text=text, foreground='#b33a32' if error else '#245882')
        self.status.set(self.errors[0][2] if self.errors else calculation_errors[0] if calculation_errors
                        else '編集内容は「適用して閉じる」で反映します。')

    def commit(self):
        self.refresh()
        if self.errors:
            row, field, _ = self.errors[0]
            self.reveal(row)
            row[field].focus_set()
            return
        data = self.data()
        errors = self.validator(data) if self.validator else []
        if errors:
            self.status.set('\n'.join(errors[:3]))
            return
        if self.app.data != self.snapshot:
            self.status.set('プロジェクトが変更されました。閉じて開き直してください。')
            return
        self.result = data
        self.win.destroy()

    def cancel(self):
        self.win.destroy()

    def destroyed(self, event):
        if event.widget is self.win and self.job is not None:
            self.win.after_cancel(self.job)
            self.job = None
