"""Dimension variables shared by DXF/DWG import, setup and preview."""
FIELDS = [
    ('dimblk', '共通矢印 DIMBLK', ''),
    ('dimsah', '左右別の矢印 DIMSAH', '0'),
    ('dimblk1', '始点矢印 DIMBLK1', ''),
    ('dimblk2', '終点矢印 DIMBLK2', ''),
    ('dimpost', '接頭・接尾 DIMPOST', ''),
    ('dimtih', '内側文字を水平 DIMTIH', '0'),
    ('dimtoh', '外側文字を水平 DIMTOH', '0'),
    ('dimtolj', '公差位置 DIMTOLJ', '1'),
]
ARROWS = ('', '_OPEN', '_OPEN30', '_OPEN90', '_CLOSED', '_DOT', '_DOTSMALL',
          '_DOTBLANK', '_OBLIQUE', '_ARCHTICK', '_ORIGIN', '_ORIGIN2', '_BOXFILLED', '_BOXBLANK', '_NONE')


def cad_arrow(name):
    from ezdxf.render.arrows import ARROWS as known
    candidate=known.arrow_name(name)
    return '_'+candidate if candidate and known.is_acad_arrow(candidate) else name


def from_dxf(style):
    result = {}
    for field, _, default in FIELDS:
        if field.startswith('dimblk'):
            name = style.dxf.get(field, '')
            handle = style.dxf.get(field+'_handle', '')
            if handle:
                name = style.get_arrow_block_name(field+'_handle')
            if name:name=cad_arrow(name)
            result[field] = name
        else:
            result[field] = str(style.dxf.get(field, default))
    return result


def effective(rows, name):
    by_name = {row['name'].casefold(): row for row in rows}
    result, seen = {}, set()
    def merge(key):
        if key in seen or key not in by_name:
            return
        seen.add(key); row=by_name[key]
        merge(row.get('base','').casefold())
        result.update(row)
    merge(name.casefold())
    return result


def override(row):
    result = {key: row[key] for key, _, _ in FIELDS if key in row}
    for key in ('dimsah', 'dimtih', 'dimtoh', 'dimtolj'):
        if key in result: result[key]=int(float(result[key]))
    for key in ('dimblk', 'dimblk1', 'dimblk2'):
        if key in result:
            name=result[key]
            from ezdxf.render.arrows import ARROWS as known
            candidate=known.arrow_name(name)
            result[key]=candidate if known.is_acad_arrow(candidate) else name
    for key, native in (('scale','dimscale'),('text_height','dimtxt'),('arrow_size','dimasz')):
        if key in row: result[native]=float(row[key])
    if row.get('text_style'):result['dimtxsty']=row['text_style']
    return result
