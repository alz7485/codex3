"""Main-window controls; drawing and output remain owned by App."""
import tkinter as tk
from tkinter import ttk

from preview_row_ui import PreviewRowControls


def button(parent, text, command, *, primary=False, side="left"):
    control = ttk.Button(parent, text=text, command=command,
                         style="Compact.Primary.TButton" if primary else "Compact.TButton")
    control.icon_only = False
    control.pack(side=side, padx=3)
    return control


def build_header(app, header):
    actions = ttk.Frame(header)
    actions.pack(side="right")
    button(actions, "元に戻す", app.undo_project)
    button(actions, "やり直し", app.redo_project)
    app.settings_menu = tk.Menu(actions, tearoff=False)
    app.settings_menu.add_command(label="CAD設定", command=app.edit_cad_setup)
    app.settings_menu.add_command(label="プリセット", command=app.manage_settings_presets)
    app.settings_group = ttk.Menubutton(actions, text="設定", menu=app.settings_menu,
                                      style="Compact.TMenubutton")
    app.settings_group.pack(side="left", padx=3)
    app.settings_buttons = [app.settings_group]
    app.output_menu = tk.Menu(actions, tearoff=False)
    app.output_menu.add_command(label="プロジェクトを検査", command=app.audit)
    app.output_menu.add_command(label="SCRを表示", command=app.show_script)
    app.output_button = ttk.Menubutton(actions, text="出力の詳細", menu=app.output_menu,
                                     style="Compact.TMenubutton")
    app.output_button.pack(side="left", padx=3)
    app.export_button = button(actions, "SCRを書き出す", app.export, primary=True)
    button(header, "プロジェクト一覧…", app.show_project_list)
    button(header, "保存", app.save)
    title = ttk.Label(header, textvariable=app.document_status, style="Section.TLabel", width=1)
    title.pack(side="left", fill="x", expand=True, padx=8)
    title.bind("<Enter>", lambda e: app.icons.schedule(title, app.document_status.get()))
    title.bind("<Leave>", lambda e: app.icons.hide())


def build_preview_controls(app):
    context = app.sourcebar = app.preview_context = ttk.Frame(app.preview_panel, padding=(6, 5))
    app.canvas.space_tabs_anchor = context
    context.pack(fill="x")
    context.columnconfigure(0, weight=1)
    table = app.table_group = ttk.Frame(context)
    table.grid(row=0, column=0, sticky="ew")
    ttk.Label(table, text="入力表").pack(side="left", padx=(0, 6))
    app.drawing_table_picker = ttk.Combobox(table, textvariable=app.table_choice,
                                           state="readonly", width=19)
    app.drawing_table_picker.pack(side="left")
    app.drawing_table_picker.bind("<<ComboboxSelected>>", lambda e: app.switch_table_by_name())
    button(table, "表一覧…", app.show_input_table)
    app.preview_row_controls = PreviewRowControls(table, app)
    app.preview_row_controls.pack(side="left", fill="x", expand=True, padx=6)
    controls = app.preview_controls = ttk.Frame(context)
    controls.grid(row=0, column=1, sticky="e")
    button(controls, "全体を表示", lambda: app.canvas.fit())
    app.preview_display_menu = tk.Menu(controls, tearoff=False)
    menu = app.preview_display_menu
    # The checkbutton object is also used by the shared color-toggle API.
    app.actual_color_toggle = app.canvas.make_color_toggle(controls)
    menu.add_checkbutton(label="実色表示", variable=app.canvas.actual_color_mode)
    menu.add_checkbutton(label="選択を強調", variable=app.highlight_enabled, command=app.highlight_preview)
    menu.add_separator()
    menu.add_command(label="再生成  F5", command=app.preview)
    menu.add_command(label="範囲でフォルダ化…", command=app.start_figure_folder_selection)
    menu.add_command(label="作図対象をプレビューに表示", command=app.preview_row_controls.reset)
    app.display_button = ttk.Menubutton(controls, text="表示設定", menu=menu,
                                      style="Compact.TMenubutton")
    app.display_button.pack(side="left", padx=3)
    last = [None]

    def adapt(event):
        narrow = event.width < 800
        if narrow != last[0]:
            last[0] = narrow
            controls.grid_configure(row=1 if narrow else 0, column=0 if narrow else 1,
                                    columnspan=2 if narrow else 1, pady=(3, 0) if narrow else 0)
    context.bind("<Configure>", adapt)


def build_block_tools(app):
    for label, action in (("ブロック追加", app.add_block),
                          ("フォルダ追加", lambda: app.block_browser.new_folder(""))):
        button(app.block_actions, label, action)


def adapt_block_tools(app, width):
    """Keep labels at the normal width, falling back to icons in a narrow pane."""
    for widget in app.block_actions.winfo_children():
        if isinstance(widget, ttk.Button):
            narrow = width < 270
            widget.configure(compound="none" if narrow else "left", width=2 if narrow else -1)


def fit_block_columns(app):
    tree = app.block_list
    available = tree.winfo_width() - 4
    if available < 240:
        return
    first = min(int(tree.column('#0', 'width')), available - 144)
    tree.column('#0', width=first)
    tree.column('name', width=available - first - 44)

