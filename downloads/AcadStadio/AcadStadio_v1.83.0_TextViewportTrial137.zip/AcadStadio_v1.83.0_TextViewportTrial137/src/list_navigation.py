"""Jump to the first/last visible list item without modifying data."""
def bind_list_ends(tree):
    def jump(last):
        def visible(parent=''):
            for node in tree.get_children(parent):
                yield node
                if tree.item(node,'open'):yield from visible(node)
        nodes=list(visible())
        if nodes:
            node=nodes[-1] if last else nodes[0]
            tree.selection_set(node);tree.focus(node);tree.see(node)
        return 'break'
    tree.bind('<Control-Up>',lambda e:jump(False))
    tree.bind('<Control-Down>',lambda e:jump(True))
