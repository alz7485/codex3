"""Keep Japanese SCR in CP932, reconstructing other BMP characters in AutoLISP."""
import codecs
import json
import re


def _encodable(text):
    try:
        text.encode('cp932')
        return True
    except UnicodeEncodeError:
        return False


def unicode_string(value):
    parts, chunk = [], ''
    for index,char in enumerate(value):
        if _encodable(char):
            chunk += char
            continue
        if ord(char) > 0xffff or 0xd800 <= ord(char) <= 0xdfff:
            raise UnicodeEncodeError('cp932', value, index, index+1,
                                     'AutoLISP chr cannot represent this character')
        if chunk:
            parts.append(json.dumps(chunk, ensure_ascii=False)); chunk = ''
        parts.append(f'(chr {ord(char)})')
    if chunk:
        parts.append(json.dumps(chunk, ensure_ascii=False))
    return '(strcat ' + ' '.join(parts) + ')'


def _lisp(line):
    # Generated forms occupy one SCR line. Never guess at a custom multiline
    # Lisp expression or rewrite an executable symbol into a different name.
    tokens=re.findall(r'"(?:\\.|[^"\\])*"|;[^\n]*|[()\']|[^\s()\'";]+',line)
    index=0
    def read():
        nonlocal index
        if index>=len(tokens):raise ValueError('Unicodeを含むAutoLISP式は1行で完結させてください')
        token=tokens[index];index+=1
        if token=='(':
            children=[]
            while index<len(tokens) and tokens[index]!=')':children.append(read())
            if index>=len(tokens):raise ValueError('Unicodeを含むAutoLISP式の括弧が閉じていません')
            index+=1
            return ('list',children)
        if token=="'":return ('quote',read())
        if token==')':raise ValueError('AutoLISP式の括弧が不正です')
        return ('string' if token.startswith('"') else 'comment' if token.startswith(';') else 'atom',token)

    def original(node):
        kind,value=node
        if kind=='list':return '('+' '.join(original(n) for n in value)+')'
        if kind=='quote':return "'"+original(value)
        return value

    def render(node,data=False):
        kind,value=node
        source=original(node)
        if _encodable(source):return "'"+source if data else source
        if kind=='string':return unicode_string(json.loads(value))
        if kind=='comment':return value.encode('cp932',errors='backslashreplace').decode('cp932')
        if kind=='atom':value.encode('cp932')  # Unsupported Unicode code symbols fail before saving.
        if kind=='quote':
            return '(list \'quote '+render(value,True)+')' if data else render(value,True)
        if kind=='list':
            if not data and len(value)==2 and value[0]==('atom','quote'):return render(value[1],True)
            if not data:return '('+' '.join(render(n) for n in value)+')'
            dots=[i for i,n in enumerate(value) if n==('atom','.')]
            if not dots:return '(list '+' '.join(render(n,True) for n in value)+')'
            if dots!=[len(value)-2] or len(value)<3:raise ValueError('AutoLISP引用リストのドット対が不正です')
            tail=render(value[-1],True)
            for child in reversed(value[:-2]):tail='(cons '+render(child,True)+' '+tail+')'
            return tail
        raise ValueError('SJISへ変換できないAutoLISP式です')
    result=[]
    while index<len(tokens):result.append(render(read()))
    return ' '.join(result)


def cp932_script(script):
    if _encodable(script):return script
    output=[];converted=False
    for line in script.split('\n'):
        if _encodable(line):output.append(line);continue
        if line.lstrip().startswith(';'):
            output.append(line.encode('cp932',errors='backslashreplace').decode('cp932'));continue
        if line.lstrip().startswith('('):
            result=_lisp(line)
        else:
            value=line
            if value.startswith('"') and value.endswith('"'):
                try:value=json.loads(value)
                except ValueError:pass
            result=unicode_string(value)
        if len(result)>2048:raise ValueError('Unicode変換後のSCRの1行が2048文字を超えました。文字列や式を短くしてください')
        output.append(result);converted=True
    guard='(if (not (member (getvar "LISPSYS") (list 1 2))) (error "AcadStadio: Unicode characters require AutoCAD 2021+ and LISPSYS 1 or 2; restart AutoCAD after changing LISPSYS"))'
    return (guard+'\n' if converted else '')+'\n'.join(output)


def encode_script(script, encoding='cp932'):
    script=script.replace('\r\n','\n').replace('\r','\n')
    if codecs.lookup(encoding).name=='cp932':script=cp932_script(script)
    return script.replace('\n','\r\n').encode(encoding)
