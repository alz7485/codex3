"""Select the definition behind a main-preview figure before invoking an action."""
import math
import tkinter as tk
from tkinter import ttk

from flow import resolve
from preview_command_edit import command_address
from main_workspace_ui import button


class MainPreviewSelection:
    def __init__(self, app):
        self.app = app
        self.canvas = app.canvas
        self.item = None
        self.address = None
        self.snapshot = None
        self.pending = None
        self.menu = None
        self.press = None
        self.moved = False
        self.frame = ttk.Frame(app.preview_panel, padding=(6, 2))
        self.frame.pack(side="bottom", fill="x")
        self.frame.columnconfigure(0, weight=1)
        self.label = ttk.Label(self.frame, style="Muted.TLabel", width=1)
        self.label.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.label.bind("<Enter>", lambda e: app.icons.schedule(self.label, self.label.cget("text")))
        self.label.bind("<Leave>", lambda e: app.icons.hide())
        self.actions = ttk.Frame(self.frame)
        self.actions.grid(row=0, column=1)
        self.edit_button = button(self.actions, "コマンドを編集", self.edit)
        self.link_button = button(self.actions, "紐づけ支援", self.link)
        self.clear_button = button(self.actions, "選択解除", self.clear)
        self.frame.rowconfigure(0, minsize=max(control.winfo_reqheight() for control in
                                             (self.edit_button, self.link_button, self.clear_button)))
        self.canvas.bind("<ButtonPress-1>", self.pressed, add="+")
        self.canvas.bind("<B1-Motion>", self.motion, add="+")
        self.canvas.bind("<ButtonRelease-1>", self.released, add="+")
        self.canvas.bind("<Escape>", lambda e: self.clear())
        self.canvas.bind("<Destroy>", self.destroyed, add="+")
        self.canvas.cancel_pending_pick = self.cancel_pending
        self.clear()

    def cancel_pending(self):
        if self.pending is not None:
            self.canvas.after_cancel(self.pending)
            self.pending = None
        if self.menu is not None and self.menu.winfo_exists():
            self.menu.unpost()

    def destroyed(self, event):
        if event.widget is self.canvas:
            self.cancel_pending()

    def pressed(self, event):
        self.cancel_pending()
        self.press = (event.x, event.y)
        self.moved = False
        self.canvas.focus_set()

    def motion(self, event):
        if self.press and math.dist(self.press, (event.x, event.y)) > 4:
            self.moved = True

    def released(self, event):
        if self.press is None or self.moved or math.dist(self.press, (event.x, event.y)) > 4:
            return
        if self.app.root.grab_current() is not None:
            return
        items = self.canvas.editable_figures_at(event.x, event.y)
        if not items:
            self.clear()
        elif len(items) == 1:
            self.select(items[0])
        else:
            # Let a double-click invoke the existing editor without opening two menus.
            self.clear()
            snapshot = self.app._observed
            space = self.canvas.space_tabs.active

            def choose():
                self.pending = None
                if self.app.data != snapshot or self.canvas.space_tabs.active != space:
                    return
                if self.menu is not None:
                    self.menu.destroy()
                menu = self.menu = tk.Menu(self.canvas, tearoff=False)
                for item in items:
                    try:
                        label = self.describe(item, command_address(self.app.data, item))
                    except (ValueError, KeyError, IndexError):
                        continue
                    menu.add_command(label=label, command=lambda value=item: self.select(value))
                try:
                    menu.tk_popup(event.x_root, event.y_root)
                finally:
                    menu.grab_release()
            self.pending = self.canvas.after(300, choose)

    def describe(self, item, address):
        block = self.app.data['blocks'][address[1]]
        space = item.get('cad_space', block.get('drawing_space', 'Model'))
        space = 'モデル' if space == 'Model' else space
        path = '.'.join(str(value + 1) for value in address[3:] if type(value) is int)
        branch = '（条件外）' if 'else' in address else ''
        kind = resolve(self.app.data, address)['type']
        return f"{space} / {block['name']} / コマンド{path}{branch} {kind} / {item.get('row', 0)+1}行目"

    def select(self, item):
        self.cancel_pending()
        try:
            address = command_address(self.app.data, item)
            label = self.describe(item, address)
        except (ValueError, KeyError, IndexError):
            self.clear()
            return
        self.item, self.address = item, address
        self.snapshot = self.app._observed
        self.rows = self.app.preview_rows()
        self.space = self.canvas.space_tabs.active
        self.label.configure(text='選択中：' + label, style='Section.TLabel')
        self.actions.grid()
        self.edit_button.state(['!disabled'])
        self.link_button.state(['!disabled'])
        self.clear_button.state(['!disabled'])
        self.app.highlight_preview()

    def clear(self, *, highlight=True):
        self.cancel_pending()
        self.item = self.address = self.snapshot = None
        self.label.configure(text='プレビューで図形を選択して、編集・紐づけ支援へ', style='Muted.TLabel')
        self.actions.grid_remove()
        for control in (self.edit_button, self.link_button, self.clear_button):
            control.state(['disabled'])
        if highlight:
            self.app.highlight_preview()

    def valid(self):
        if (self.item is None or self.app.data != self.snapshot
                or self.app.preview_rows() != self.rows
                or self.canvas.space_tabs.active != self.space):
            self.clear()
            return False
        return True

    def edit(self):
        if self.valid():
            self.app.edit_preview_command(self.item)

    def link(self):
        if self.valid():
            self.app.show_link_assistance(self.address)
