"""Circle point by world angle: right=0 degrees, counterclockwise positive."""
import copy,math

def angle_pick(pick,expression,context,evaluate):
    value=evaluate(expression,context)
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
        raise ValueError('角度は有限の数値または数式で指定してください')
    source=pick.get('source') or {}
    if source.get('display_type',source.get('type'))!='CIRCLE':raise ValueError('円を指定してください')
    cx,cy,r=source['coords'][:3];a=math.radians(value%360)
    result=copy.copy(pick)
    result.update(xy=(cx+r*math.cos(a),cy+r*math.sin(a)),snap_name='右',curve_angle=expression,choose_source=False,ask_angle=False)
    result['x'],result['y']=(format(v,'.15g') for v in result['xy'])
    return result
