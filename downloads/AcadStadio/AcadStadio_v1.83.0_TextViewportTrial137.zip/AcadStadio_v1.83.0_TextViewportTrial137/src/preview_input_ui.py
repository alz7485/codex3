"""Direct preview gestures with a compact inspector; the compiler remains authoritative."""
import copy
import math
import tkinter as tk
from tkinter import ttk
from command_points import geometry_points,reference
from range_selection import entities


def literal(value):return format(float(value),'.15g')


def alt_pressed(event,windowing_system):
    # Windows Tk maps NumLock to Mod1Mask (0x8); Alt is ALT_MASK.
    mask=0x20000 if windowing_system=='win32' else 0x8
    return bool(getattr(event,'state',0)&mask)


class ViewportActions:
    @staticmethod
    def variable(command):return False
    @staticmethod
    def minimum(command):
        action=command.get('viewport_action','矩形を作成')
        return 3 if action=='矩形を作成' else 2 if action=='表示中心・尺度' else 1
    @staticmethod
    def hint(command,picks):
        if command.get('viewport_action','矩形を作成')=='矩形を作成':
            return ('用紙上で枠の最初の角を指定','用紙上で枠の対角を指定','モデルタブで表示中心を指定')[min(2,len(picks))]
        return 'モデルタブで表示中心を指定' if picks else '操作するビューポート枠をクリック'
    @staticmethod
    def build(command,picks):
        d=copy.deepcopy(command);action=d.get('viewport_action','矩形を作成')
        if action=='矩形を作成':
            for suffix,p in zip(('1','2'),picks):d.update({'x'+suffix:p['x'],'y'+suffix:p['y']})
            d.update(configure_view=True,view_x=picks[2]['x'],view_y=picks[2]['y'])
        else:
            source=picks[0].get('source') or {};number=source.get('viewport_number')
            if number is None:raise ValueError('この枠のCAD番号が不明です。詳細から番号を指定してください。')
            d['viewport_id']=str(number)
            if action=='表示中心・尺度':d.update(view_x=picks[1]['x'],view_y=picks[1]['y'])
        return d


def action_module(kind):
    from preview_shape_actions import KINDS as SHAPES
    from preview_edit_actions import KINDS as EDITS
    if kind in SHAPES:
        import preview_shape_actions
        return preview_shape_actions
    if kind in EDITS:
        import preview_edit_actions
        return preview_edit_actions
    if kind=='VIEWPORT':return ViewportActions
    return None


POINT_PLACEMENT=frozenset(('LINE','POLYLINE','CIRCLE','RECTANGLE','ARC','ELLIPSE','POINT','TEXT','MTEXT','SPLINE','LEADER','INSERT','COPY','MIRROR','ROTATE','ROTATECOPY','ARRAYRECT','CADBLOCK','SCALE'))

SCALARS={
 'CIRCLE':('r','diameter'),'HATCH':('pattern','scale','angle'),
 'TEXT':('text','height','angle','text_width'),'MTEXT':('text','height','angle','text_width'),
 'LEADER':('text','height'),'INSERT':('block_name','scale_x','scale_y','angle'),
 'OFFSET':('distance',),'MIRROR':('erase_source',),'ROTATE':('angle',),
 'ROTATECOPY':('angle','copy_count'),'ARRAYRECT':('columns','rows','column_spacing','row_spacing'),
 'CADBLOCK':('block_name',),'SCALE':('factor',),'PEDIT':('polyline_action','join_tolerance'),
 'CHAMFER':('distance1','distance2'),'FILLET':('radius',),'POLYLINE':('closed',),
 'VIEWPORT':('view_scale',),'DIMEDIT':('oblique_mode','angle'),
}


class PreviewInput(ttk.Frame):
    def __init__(self,parent,apply,identity,eligible,details,on_select=None,get_data=None,owner_space=None):
        super().__init__(parent,padding=(12,4))
        self.apply=apply;self.identity=identity;self.eligible=eligible;self.details=details;self.on_select=on_select;self.get_data=get_data;self.owner_space=owner_space
        self.canvas=None;self.command={};self.context={};self.picks=[];self.capturing=False
        self._kind=None;self._signature=None;self._started=set();self._details=True
        self.bar=ttk.Frame(self);self.bar.pack(fill='x')
        self.message=tk.StringVar(self,value='')
        self.label=ttk.Label(self.bar,textvariable=self.message,wraplength=750)
        self.label.pack(side='left',fill='x',expand=True)
        self.detail_button=ttk.Button(self.bar,text='数値・式の詳細',command=self.toggle_details);self.detail_button.pack(side='right')
        self.select_button=ttk.Button(self.bar,text='対象を変更',command=lambda:self.on_select() if self.on_select else None)
        self.start_button=ttk.Button(self.bar,text='画面で指定',command=self.start);self.start_button.pack(side='right',padx=4)
        self.finish_button=ttk.Button(self.bar,text='点を確定',command=self.finish)
        self.undo_button=ttk.Button(self.bar,text='1点戻す',command=self.undo)
        self.values=ttk.Frame(self);self.values.pack(fill='x',pady=(4,0))
        self.compact_entries={};self.readouts=[]
    def configure_command(self,command,canvas,entries,labels,context=None,creating=False):
        kind=command.get('type');mode=(kind,command.get('arc_mode'),command.get('circle_mode'),command.get('viewport_action'),command.get('polyline_action'),command.get('oblique_mode'),command.get('selection_ref'))
        changed=kind!=self._kind
        if getattr(self,'_mode',mode)!=mode:self.stop();self.picks=[]
        self._mode=mode
        if changed:
            self.stop();self.picks=[];self._signature=None;self._kind=kind
        self.command=copy.deepcopy(command);self.canvas=canvas;self.context=context or {};self.module=action_module(kind)
        canvas.preview_input_owner=self if self.module else None
        if not self.module:
            self.stop();self.start_button.pack_forget();self.detail_button.pack_forget();self.select_button.pack_forget()
            for child in self.values.winfo_children():child.destroy()
            self.compact_entries={};self._signature=None
            if kind=='SELECT':self.pack_forget();return
            from preview_input_feedback import status
            from engine import evaluate
            self.message.set(status(command,self.context,evaluate))
            if self.message.get():self.pack(fill='x',before=self.master.command_body)
            else:self.pack_forget()
            self.details(True);return
        self.pack(fill='x',before=self.master.command_body)
        self.detail_button.pack(side='right');self.start_button.pack(side='right',padx=4)
        self.start_button.configure(state='normal' if self.module.minimum(command) else 'disabled')
        from selection_sets import OPERATORS
        if kind in OPERATORS and self.on_select:self.select_button.pack(side='right',padx=4)
        else:self.select_button.pack_forget()
        keys=[k for k in SCALARS.get(kind,()) if k in entries]
        signature=(kind,tuple((k,str(entries[k])) for k in keys))
        if signature!=self._signature:
            for child in self.values.winfo_children():child.destroy()
            self.compact_entries={};self.readouts=[]
            for i,key in enumerate(keys):
                host=ttk.Frame(self.values);host.grid(row=i//4,column=i%4,sticky='ew',padx=(0,10),pady=2)
                title='補助線の方向（°）' if kind=='DIMEDIT' and key=='angle' else {'erase_source':'元図形','closed':'閉じる'}.get(key,labels.get(key,key))
                ttk.Label(host,text=title).pack(side='left',padx=(0,5))
                original=entries[key]
                if isinstance(original,tk.Text):
                    widget=tk.Text(host,height=2,width=32,wrap='word')
                    widget.insert('1.0',original.get('1.0','end-1c'))
                    def sync(event=None,w=widget,target=original):
                        value=w.get('1.0','end-1c')
                        if target.get('1.0','end-1c')!=value:target.delete('1.0','end');target.insert('1.0',value);target.event_generate('<KeyRelease>')
                    widget.bind('<KeyRelease>',sync)
                else:
                    var=original.cget('textvariable')
                    if isinstance(original,ttk.Combobox):
                        widget=ttk.Combobox(host,textvariable=var,values=original.cget('values'),state=original.cget('state'),width=18)
                        widget.bind('<<ComboboxSelected>>',lambda e,target=original:target.event_generate('<<ComboboxSelected>>'))
                    elif key in ('erase_source','closed'):
                        widget=ttk.Combobox(host,values=('元を残す','元を削除') if key=='erase_source' else ('開く','閉じる'),state='readonly',width=12)
                        widget.current(1 if str(original.get())=='1' else 0)
                        def sync_choice(event,w=widget,v=var):self.master.setvar(v,str(w.current()))
                        widget.bind('<<ComboboxSelected>>',sync_choice)
                    else:widget=ttk.Entry(host,textvariable=var,width=24 if key in ('text','block_name') else 12)
                widget.pack(side='left',fill='x',expand=True);self.compact_entries[key]=widget
                widget.bind('<FocusIn>',lambda e,target=original:target.event_generate('<FocusIn>'),add='+')
                if kind=='DIMEDIT' and key=='angle':
                    def numeric_angle(event=None):
                        self.stop();self.picks=[];self.message.set('角度を入力し、コマンドを反映してください。画面で指定し直すこともできます。')
                    widget.bind('<FocusIn>',numeric_angle,add='+')
                if key not in ('text','block_name','pattern','erase_source','closed','polyline_action','oblique_mode'):
                    readout=ttk.Label(host,text='',style='Muted.TLabel');readout.pack(side='left',padx=(4,0));self.readouts.append((key,readout))
            for i in range(4):self.values.columnconfigure(i,weight=1)
            self._signature=signature
        from engine import evaluate
        for key,label in self.readouts:
            try:
                value=evaluate(str(entries[key].get()),self.context);label.configure(text=('= '+format(value,'.6g')) if type(value) in (int,float) else '')
            except (ValueError,KeyError,TypeError,ArithmeticError):label.configure(text='')
        if changed:
            self._details=False
            self.details(self._details)
            self.detail_button.configure(text='数値・式を閉じる' if self._details else '数値・式の詳細')
        if not self.capturing:self.message.set('点指定済み：Enterでコマンドを確定します。' if self.picks else '画面で指定できます。数値・式の詳細も利用できます。' if self.module.minimum(command) else '操作を選んで結果を確認してください。')
        if not self.capturing and kind=='VIEWPORT':self.message.set('角の点：枠サイズ ／ 中心の点：枠移動 ／ 枠内ドラッグ：表示内容を移動')
        self.details(self._details)
        signature=kind
        if creating and signature not in self._started and self.module.minimum(command):
            self._started.add(signature);self.start()
        if self.capturing:self.advance_space()
        canvas.draw_markers()
        self._buttons()
    def show_details(self):
        self.stop();self._details=True;self.details(True);self.detail_button.configure(text='数値・式を閉じる')
    def toggle_details(self):
        self._details=not self._details
        if self._details:self.stop()
        self.details(self._details);self.detail_button.configure(text='数値・式を閉じる' if self._details else '数値・式の詳細')
    def start(self):
        if not self.canvas or not self.module:return
        self.reference_source=None;self.canvas.cancel_range();self.capturing=True;self.picks=[];self.press_position=None
        self.paper_space=self.owner_space() if callable(self.owner_space) else self.owner_space or 'Model'
        if self.paper_space=='モデル':self.paper_space='Model'
        if self.paper_space=='コマンドに従う':
            tabs=self.canvas.space_tabs
            self.paper_space=tabs.active if tabs else 'Model'
        if self.command.get('type')=='VIEWPORT' and self.paper_space=='Model':
            tabs=self.canvas.space_tabs
            self.paper_space=next((name for name in tabs.pages if name!='Model'),'Layout1') if tabs else 'Layout1'
        self.canvas.direct_input=self;self.canvas.configure(cursor='crosshair');self.canvas.focus_set()
        self._details=False;self.details(False);self.detail_button.configure(text='数値・式の詳細')
        self.advance_space();self.message.set(self.module.hint(self.command,self.picks)+'（Alt：スナップなし）');self._buttons();self.draw(None)
    def expected_space(self):
        if self.command.get('type')!='VIEWPORT':return self.paper_space
        frame_picks=2 if self.command.get('viewport_action','矩形を作成')=='矩形を作成' else 1
        return 'Model' if len(self.picks)>=frame_picks else self.paper_space
    def advance_space(self):
        tabs=self.canvas.space_tabs if self.canvas is not None else None
        space=self.expected_space()
        if tabs and space in tabs.pages and tabs.active!=space:tabs.select_space(space)
    def _buttons(self):
        for button in (self.finish_button,self.undo_button):button.pack_forget()
        if self.capturing:
            self.undo_button.pack(side='right',padx=4)
            if self.module.variable(self.command):self.finish_button.pack(side='right',padx=4)
    def stop(self):
        self.capturing=False;self.reference_source=None
        if self.canvas is not None:
            popup=getattr(self.canvas,'candidate_popup',None)
            if popup is not None and popup.winfo_exists():popup.close()
            self.canvas._selection_drag_active=False;self.canvas.delete('direct-input')
            if getattr(self.canvas,'direct_input',None) is self:self.canvas.direct_input=None
            try:self.canvas.configure(cursor='')
            except tk.TclError:pass
        self._buttons() if hasattr(self,'module') else None
    def undo(self):
        if self.picks:self.picks.pop()
        self.advance_space()
        self.message.set(self.module.hint(self.command,self.picks));self.draw(None)
    def escape(self):
        if not self.capturing:return False
        if getattr(self,'reference_source',None) is not None:
            self.reference_source=None;self.draw(None);self.message.set(self.module.hint(self.command,self.picks))
        elif self.picks:self.undo()
        else:self.stop();self.message.set('画面での指定を終了しました。')
        return True
    def press(self,event):
        self.press_position=(event.x,event.y);self.canvas._selection_drag_active=True
        return 'break'
    def drag(self,event):self.motion(event);return 'break'
    def release(self,event):
        self.canvas._selection_drag_active=False
        start=getattr(self,'press_position',None);self.press_position=None
        if start and not self.picks and math.dist(start,(event.x,event.y))>5 and self.module.minimum(self.command)>=2:
            if not self.add_pixel(*start,event=event):return 'break'
            if not self.capturing:return 'break'
        self.add_pixel(event.x,event.y,event=event);return 'break'
    def candidates(self,x,y,alt=False):
        c=self.canvas;xy=c.world_point(x,y);pool=[s for s in entities(c.items) if self.eligible(s)]
        pool_ids={id(item) for item in pool}
        nodes=set(c.find_overlapping(x-5,y-5,x+5,y+5));hits=[]
        for node,drawn,_ in reversed(c.geometry):
            item=drawn.get('_logical_parent',drawn)
            if node in nodes and id(item) in pool_ids and all(item is not old for old in hits):hits.append(item)
        nearby=[]
        if not alt:
            for item in pool:
                selected=getattr(self,'reference_source',None)
                if selected is not None and c.item_source_index(item)!=c.item_source_index(selected):continue
                try:points=geometry_points(item)
                except (ValueError,KeyError,TypeError):continue
                for name,p in points.items():
                    distance=math.dist(c.screen_point(p),(x,y))
                    if distance<=12:nearby.append((distance,item,name,p))
        if nearby:
            best=min(p[0] for p in nearby)
            result=[];seen=set()
            for dist,item,name,p in nearby:
                if dist>best+1 or name=='角度指定点':continue
                marker=(id(item),tuple(round(v,10) for v in p))
                if marker in seen:continue
                seen.add(marker)
                result.append(dict(xy=tuple(p),x=literal(p[0]),y=literal(p[1]),source=item,key=None,snap_name=name))
            if result:return result
        if not hits and self.command.get('type')=='HATCH' and not self.picks:
            for item in pool:
                kind=item.get('display_type',item['type']);coords=item['coords']
                if kind=='RECTANGLE':polygon=[coords[:2],(coords[2],coords[1]),coords[2:4],(coords[0],coords[3])]
                elif kind=='POLYLINE' and item.get('closed') and not any(item.get('bulges',[])):polygon=list(zip(coords[::2],coords[1::2]))
                else:continue
                inside=False
                for a,b in zip(polygon,polygon[1:]+polygon[:1]):
                    if (a[1]>xy[1])!=(b[1]>xy[1]) and xy[0]<(b[0]-a[0])*(xy[1]-a[1])/(b[1]-a[1])+a[0]:inside=not inside
                if inside:hits.append(item)
        if hits:
            result=[]
            for item in hits:
                point=xy;extra={};kind=item.get('display_type',item['type']);coords=item['coords']
                if not alt and kind=='LINE' and len(coords)==4 and not item.get('segments'):
                    from edit_preview import projection
                    t=max(0,min(1,projection(xy,coords)));point=(coords[0]+t*(coords[2]-coords[0]),coords[1]+t*(coords[3]-coords[1]));extra['fraction']=t
                elif not alt and kind=='CIRCLE':
                    cx,cy,r=coords[:3];angle=math.degrees(math.atan2(xy[1]-cy,xy[0]-cx));point=(cx+r*math.cos(math.radians(angle)),cy+r*math.sin(math.radians(angle)));extra.update(curve_angle=angle)
                selected=getattr(self,'reference_source',None)
                ask_angle=not alt and 'curve_angle' in extra and self.command.get('type') in POINT_PLACEMENT and selected is not None and c.item_source_index(selected)==c.item_source_index(item)
                result.append(dict(xy=point,x=literal(point[0]),y=literal(point[1]),source=item,key=None,snap_name='右' if 'curve_angle' in extra else None,ask_angle=ask_angle,choose_source=not ask_angle and not alt and self.command.get('type') in POINT_PLACEMENT,**extra))
            return result
        return [dict(xy=xy,x=literal(xy[0]),y=literal(xy[1]),source=None,key=None,snap_name=None)]
    def add_pixel(self,x,y,event=None):
        tabs=self.canvas.space_tabs
        if tabs and tabs.active!=self.expected_space():
            self.advance_space();self.message.set(self.module.hint(self.command,self.picks));return False
        alt=alt_pressed(event,self.canvas.tk.call('tk','windowingsystem'))
        choices=self.candidates(x,y,alt)
        if getattr(self,'reference_source',None) is not None and choices[0].get('source') is None and not alt:
            self.message.set('表示したコマンドの点をクリックしてください。Escで解除できます。');return False
        if len(choices)>1 and event is not None:
            from point_candidate_popup import PointCandidatePopup
            candidates=[]
            for p in choices:
                source=p['source'];index=self.canvas.item_source_index(source)
                candidates.append(dict(kind='point',primary=index,secondary=None,point=p['snap_name'] or '',position=p['xy'],label=self.canvas.source_labels.get(index,'図形')+' / '+('円周上' if p.get('curve_angle') is not None else p['snap_name'] or '図形上の点'),pick=p))
            previous=getattr(self.canvas,'candidate_popup',None)
            if previous is not None and previous.winfo_exists():previous.close()
            self.canvas.candidate_popup=PointCandidatePopup(self.canvas,candidates,event,lambda choice:self.add_pick(choice['pick']))
            return False
        self.add_pick(choices[0]);return True
    def choose_circle_angle(self,pick):
        from circle_angle_input import angle_pick
        from engine import evaluate
        from theme import fit_window
        parent=self.winfo_toplevel();previous=parent.grab_current()
        dialog=tk.Toplevel(parent);dialog.title('円周上の点の角度');dialog.transient(parent)
        self.master.circle_angle_dialog=dialog
        fit_window(dialog,390,220,340,200)
        frame=ttk.Frame(dialog,padding=14);frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='右向きが0°、反時計回りが正です。').pack(anchor='w')
        row=ttk.Frame(frame);row.pack(fill='x',pady=10)
        ttk.Label(row,text='角度（°）').pack(side='left')
        value=dialog.angle_var=tk.StringVar(value=format(float(pick['curve_angle'])%360,'.6g'))
        entry=dialog.angle_entry=ttk.Entry(row,textvariable=value);entry.pack(side='left',fill='x',expand=True)
        error=tk.StringVar();ttk.Label(frame,textvariable=error,wraplength=340).pack(anchor='w')
        result=[]
        def accept(event=None):
            try:result.append(angle_pick(pick,value.get().strip(),self.context,evaluate))
            except (ValueError,KeyError,TypeError,ArithmeticError) as exc:error.set(str(exc));return 'break'
            dialog.destroy();return 'break'
        bar=ttk.Frame(frame);bar.pack(fill='x',side='bottom')
        ttk.Button(bar,text='キャンセル',command=dialog.destroy).pack(side='left')
        ttk.Button(bar,text='この点を使用',command=accept).pack(side='right')
        dialog.bind('<Return>',accept);dialog.bind('<Escape>',lambda e:dialog.destroy())
        dialog.grab_set();entry.focus_set();entry.selection_range(0,'end')
        try:parent.wait_window(dialog)
        finally:
            if previous is not None and previous.winfo_exists():previous.grab_set()
        if result and self.winfo_exists() and self.capturing:self.add_pick(result[0])

    def add_pick(self,pick):
        if not self.capturing:return
        p=copy.copy(pick);source=p.get('source')
        if p.get('ask_angle'):
            self.choose_circle_angle(p);return
        if p.get('choose_source'):
            self.reference_source=source
            self.message.set('コマンドを選択しました。表示された始点・中点・中心などの点をクリックしてください。')
            if source.get('display_type',source['type'])=='CIRCLE':self.message.set('中心などの点を選ぶか、円周の途中をクリックして角度を指定してください。')
            self.draw(None);return
        self.reference_source=None
        if source is not None:
            p['key']=self.identity(source)
            if p.get('snap_name') and p['key']:
                p['x']=reference(p['key'],p['snap_name'],'X',p.get('curve_angle'));p['y']=reference(p['key'],p['snap_name'],'Y',p.get('curve_angle'))
        if p.get('fraction') is not None and p.get('key'):
            t=p['fraction']
            for axis in ('x','y'):p[axis]=f"({reference(p['key'],'始点',axis.upper())})*{1-t:.15g}+({reference(p['key'],'終点',axis.upper())})*{t:.15g}"
        if self.command.get('type')=='OFFSET' and source is None:
            # OFFSET's click is a side point, so it commonly misses the outline.
            selected=[s for s in entities(self.canvas.items) if id(s) in getattr(self.canvas,'selected_entity_ids',set())]
            if len(selected)==1:p['source']=selected[0]
        kind=self.command.get('type')
        if kind in ('DIMLINEAR','DIMALIGNED') and not self.picks and p.get('snap_name') in ('始点','終点','頂点1','頂点2'):p['source']=None
        if kind=='HATCH' and not self.picks:
            from preview_shape_actions import boundary_picks
            boundary=boundary_picks(p)
            if boundary:
                self.picks=boundary;self.finish();return
        if kind in ('HATCH','POLYLINE') and len(self.picks)>=self.module.minimum(self.command) and math.dist(self.canvas.screen_point(self.picks[0]['xy']),self.canvas.screen_point(p['xy']))<=9:
            self.picks.append(copy.copy(self.picks[0]));self.finish();return
        if self.module.variable(self.command) and self.picks and math.dist(p['xy'],self.picks[-1]['xy'])<1e-10:
            if len(self.picks)>=self.required_count():self.finish()
            return
        self.picks.append(p)
        self.advance_space()
        if not self.module.variable(self.command) and len(self.picks)>=self.required_count():self.finish();return
        self.message.set(self.module.hint(self.command,self.picks));self.draw(None)
    def required_count(self):
        if self.command.get("type") in ("DIMLINEAR","DIMALIGNED") and self.picks:
            from preview_shape_actions import _line_source
            if _line_source(self.picks[0]):return 2
        return self.module.minimum(self.command)
    def finish(self):
        if not self.capturing:return True
        if len(self.picks)<self.required_count():
            self.message.set(self.module.hint(self.command,self.picks));return False
        try:data=self.module.build(self.get_data() if self.get_data else self.command,self.picks)
        except (ValueError,KeyError,TypeError,ArithmeticError) as exc:
            self.message.set(str(exc));self.picks.pop();return False
        self.stop();self.apply(data)
        if self.command.get('type')=='VIEWPORT':
            tabs=self.canvas.space_tabs
            if tabs and self.paper_space in tabs.pages:tabs.select_space(self.paper_space)
        self.message.set('点指定済み：Enterでコマンドを確定します。');return True
    def handle_points(self):
        from command_points import geometry_points
        from vertex_points import read_vertices
        index=len(self.canvas.reference_candidate_indices)
        item=next((i for i in reversed(self.canvas.items) if self.canvas.item_source_index(i)==index and not i.get('operation_deleted')),None)
        if not item:return {}
        points=geometry_points(item);kind=self.command.get('type');c=item.get('coords',())
        if kind in ('DIMLINEAR','DIMALIGNED') and len(c)>=6:points=dict(測定点1=c[:2],測定点2=c[2:4],寸法位置=c[4:6])
        elif kind in ('DIMRADIUS','DIMDIAMETER') and len(c)>=5:points.update(中心=c[:2],寸法位置=c[3:5])
        elif kind in ('HATCH','SPLINE','LEADER','LINE','POLYLINE'):
            points.update({f'頂点{i+1}':p for i,p in enumerate(zip(c[::2],c[1::2]))})
        return points
    def handle_press(self,event):
        if not self.module or self.capturing:return False
        from preview_input_handles import move
        from engine import evaluate
        points=self.handle_points();choices=[]
        command=self.get_data() if self.get_data else self.command
        for name,p in points.items():
            distance=math.dist(self.canvas.screen_point(p),(event.x,event.y))
            if distance<=9:
                try:move(command,name,p,p,self.context,evaluate)
                except (ValueError,KeyError,TypeError):continue
                choices.append((distance,name,p))
        if choices:
            _,name,start=min(choices,key=lambda choice:choice[0])
        elif command.get('type')=='VIEWPORT':
            x,y=self.canvas.world_point(event.x,event.y)
            from engine import number
            try:bounds=[float(number(command[k],self.context)) for k in ('x1','y1','x2','y2')]
            except (ValueError,KeyError):return False
            if not (min(bounds[0],bounds[2])<x<max(bounds[0],bounds[2]) and min(bounds[1],bounds[3])<y<max(bounds[1],bounds[3])):return False
            name='表示内容';start=(x,y)
        else:return False
        self._handle_drag=(copy.deepcopy(command),name,tuple(start));self.canvas._selection_drag_active=True
        self.message.set(name+'をドラッグして変更');return True
    def handle_motion(self,event):
        if not getattr(self,'_handle_drag',None):return False
        _,name,start=self._handle_drag;c=self.canvas;end=c.world_point(event.x,event.y)
        c.delete('direct-input');a=c.screen_point(start);b=c.screen_point(end)
        c.create_line(*a,*b,fill='#fbbf24',dash=(5,3),tags='direct-input')
        c.create_oval(b[0]-5,b[1]-5,b[0]+5,b[1]+5,outline='#fbbf24',tags='direct-input');return True
    def handle_release(self,event):
        if not getattr(self,'_handle_drag',None):return False
        from preview_input_handles import move
        from engine import evaluate
        command,name,start=self._handle_drag;self._handle_drag=None;self.canvas._selection_drag_active=False
        if math.dist(self.canvas.screen_point(start),(event.x,event.y))<2:
            self.canvas.selected_point=name;self.canvas.delete('direct-input');self.canvas.draw_markers();self.message.set(name+'を選択しました。ドラッグで変更、詳細で式を編集できます。');return True
        try:
            data=move(command,name,start,self.canvas.world_point(event.x,event.y),self.context,evaluate)
            self.canvas.delete('direct-input');self.apply(data);self.message.set(name+'を変更しました。')
        except (ValueError,KeyError,TypeError,ArithmeticError) as exc:self.message.set(str(exc))
        return True
    def motion(self,event):
        if not self.capturing:return
        choices=self.candidates(event.x,event.y,alt_pressed(event,self.canvas.tk.call('tk','windowingsystem')));self.draw(choices[0])
    def draw(self,hover):
        c=self.canvas;c.delete('direct-input');points=[p['xy'] for p in self.picks]
        selected=getattr(self,'reference_source',None)
        if selected is not None and selected.get('display_type',selected['type'])=='CIRCLE':
            cx,cy,r=selected['coords'][:3]
            c.create_rectangle(*c.screen_point((cx-r,cy+r)),*c.screen_point((cx+r,cy-r)),outline='#67e8f9',dash=(5,4),tags='direct-input')
        # Reference targets are distinct from the edited command's handles.
        seen=set()
        for item in entities(c.items):
            if not self.eligible(item):continue
            selected=getattr(self,'reference_source',None)
            if selected is not None and c.item_source_index(item)!=c.item_source_index(selected):continue
            try:targets=geometry_points(item)
            except (ValueError,KeyError,TypeError):continue
            for name,point in targets.items():
                if name=='角度指定点':continue
                x,y=c.screen_point(point);key=(round(x),round(y))
                if key in seen or not (0<=x<=c.winfo_width() and 0<=y<=c.winfo_height()):continue
                seen.add(key)
                selected=getattr(self,'reference_source',None)
                if selected is not None and c.item_source_index(item)==c.item_source_index(selected):
                    c.create_oval(x-6,y-6,x+6,y+6,fill='#67e8f9',outline='#101d30',tags='direct-input')
                    right=x>c.winfo_width()/2
                    c.create_text(x-10 if right else x+10,y-12,text=name,anchor='e' if right else 'w',fill='#67e8f9',tags='direct-input')
                else:c.create_rectangle(x-2,y-2,x+2,y+2,outline='#67e8f9',tags='direct-input')
        if hover is not None:points.append(hover['xy'])
        kind=self.command.get('type')
        if kind=='VIEWPORT' and self.canvas.space_tabs and self.canvas.space_tabs.active=='Model':points=[hover['xy']] if hover is not None else []
        screen=[c.screen_point(p) for p in points]
        if len(screen)>=2 and kind=='CIRCLE':
            a=screen[0];r=math.dist(a,screen[-1]);c.create_oval(a[0]-r,a[1]-r,a[0]+r,a[1]+r,outline='#fbbf24',dash=(5,3),tags='direct-input')
        elif len(screen)>=2 and kind in ('RECTANGLE','MTEXT','VIEWPORT'):
            c.create_rectangle(*screen[0],*screen[1],outline='#fbbf24',dash=(5,3),tags='direct-input')
        elif len(screen)>=2:c.create_line(*[v for p in screen for v in p],fill='#fbbf24',dash=(5,3),tags='direct-input')
        for x,y in screen:c.create_oval(x-4,y-4,x+4,y+4,fill='#fbbf24',outline='#101d30',tags='direct-input')
        if hover and hover.get('snap_name'):
            x,y=c.screen_point(hover['xy'])
            c.create_rectangle(x-7,y-7,x+7,y+7,outline='#67e8f9',width=2,tags='direct-input')
            index=c.item_source_index(hover['source'])
            name='円周上の点（クリックで角度指定）' if hover.get('ask_angle') else hover['snap_name']+'（点参照）'
            if hover.get('choose_source') and hover.get('curve_angle') is not None:name='円（クリックして点を選択）'
            text=c.source_labels.get(index,'コマンド')+' / '+name
            right=x>c.winfo_width()/2
            c.create_text(x-12 if right else x+12,y-16,text=text,fill='#67e8f9',anchor='e' if right else 'w',tags='direct-input')
