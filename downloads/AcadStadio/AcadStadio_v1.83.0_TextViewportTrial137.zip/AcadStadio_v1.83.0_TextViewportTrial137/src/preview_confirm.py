"""Enter first ends preview point capture, then accepts the command on a new press."""
from preview_input_ui import alt_pressed


class PreviewConfirm:
    def __init__(self, win, canvas, direct, selecting, accept, accept_button):
        self.win, self.canvas = win, canvas
        self.direct, self.selecting, self.accept = direct, selecting, accept
        self.accept_button = accept_button
        self.windowing_system = win.tk.call('tk', 'windowingsystem')
        self.key_down = False
        canvas.on_confirm_input = self.press
        for key in ('Return', 'KP_Enter'):
            win.bind('<'+key+'>', self.press)
            win.bind('<KeyRelease-'+key+'>', self.release, add='+')
        win.bind('<FocusIn>', self.release, add='+')

    def release(self, event=None):
        self.key_down = False

    def press(self, event):
        # The reference-point panel owns Enter while it is open. Input widgets
        # keep their own Return handling, including multiline text and row pickers.
        if self.selecting() is not None:
            return None
        if event.widget not in (self.win, self.canvas, self.accept_button):
            return None
        if getattr(event, 'state', 0) & 0x5 or alt_pressed(event, self.windowing_system):
            return None
        direct = self.direct()
        if direct is None or direct.module is None:
            return None
        if self.key_down:
            return 'break'
        self.key_down = True
        if direct.capturing:
            direct.finish()
        else:
            self.accept()
        return 'break'
