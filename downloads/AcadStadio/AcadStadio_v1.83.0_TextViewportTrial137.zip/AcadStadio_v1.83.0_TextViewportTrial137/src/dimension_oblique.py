"""DIMEDIT Oblique: world-X direction, independent of dimension-line rotation."""
import copy
import math

LINEAR = frozenset(('DIMLINEAR','DIMALIGNED'))
MODES = ('角度を指定','直角に戻す')
FIELDS = [('oblique_mode',MODES[0]),('angle','60')]


def line_angle(item):
    c=item['coords']
    if item['type']=='DIMALIGNED':return math.degrees(math.atan2(c[3]-c[1],c[2]-c[0]))%180
    axis=item.get('dimension_axis','')
    return 90. if axis=='vertical' else 0. if axis=='horizontal' else 90. if abs(c[4]-(c[0]+c[2])/2)>abs(c[5]-(c[1]+c[3])/2) else 0.


def direction(item,angle=None):
    base=line_angle(item)
    if angle is None:return (base+90)%180
    if isinstance(angle,bool) or not isinstance(angle,(int,float)) or not math.isfinite(angle):raise ValueError('スライド角度は有限の数値にしてください')
    value=float(angle)%180
    if abs(math.sin(math.radians(value-base)))<1e-8:raise ValueError('寸法線と平行な方向にはスライドできません。別の角度を指定してください。')
    return value


def points(item):
    c=item['coords'];a,b,p=c[:2],c[2:4],c[4:6]
    base=math.radians(line_angle(item));target=math.radians(direction(item,item.get('oblique_angle')))
    u=(math.cos(base),math.sin(base));v=(math.cos(target),math.sin(target));den=v[0]*u[1]-v[1]*u[0]
    def crossing(q):
        t=((p[0]-q[0])*u[1]-(p[1]-q[1])*u[0])/den
        return (q[0]+t*v[0],q[1]+t*v[1])
    first,second=crossing(a),crossing(b)
    return {'測定点1':a,'測定点2':b,'寸法位置':p,'寸法線始点':first,'寸法線終点':second,'寸法線中点':tuple((x+y)/2 for x,y in zip(first,second))}


def native(selection,angle,count=None):
    """Validate every target before editing; roll back a CAD-side error as a group.

    Two angle points avoid AUNITS/ANGBASE/ANGDIR-dependent numeric input.
    """
    target='(+ rotation (/ pi 2.0))' if angle is None else f'{math.radians(angle):.15g}'
    body=f'(setq picked {selection} index 0 originals nil) '
    if count is not None:body+=f'(if (/= (sslength picked) {count}) (error "AcadStadio: Dimension selection differs from preview")) '
    body+='(repeat (sslength picked) (setq e (ssname picked index) index (1+ index) data (entget e)) '
    body+='(if (or (/= (cdr (assoc 0 data)) "DIMENSION") (not (member (logand 7 (cdr (assoc 70 data))) (list 0 1)))) (error "AcadStadio: Select linear or aligned dimensions only")) '
    body+='(if (and (assoc 210 data) (not (equal (cdr (assoc 210 data)) (list 0.0 0.0 1.0) 1e-10))) (error "AcadStadio: Tilted dimensions are not supported")) '
    body+='(setq rotation (if (= 0 (logand 7 (cdr (assoc 70 data)))) (cond ((cdr (assoc 50 data))) (T 0.0)) (angle (cdr (assoc 13 data)) (cdr (assoc 14 data))))) '
    body+=f'(setq target {target}) (if (< (abs (sin (- target rotation))) 1e-8) (error "AcadStadio: Extension lines cannot be parallel to the dimension line")) '
    body+='(setq originals (cons (list e target) originals))) '
    body+='(if (or (= 0 (logand 1 (getvar "UNDOCTL"))) (/= 0 (logand 8 (getvar "UNDOCTL")))) (error "AcadStadio: Enable undo and finish the current undo group")) '
    body+='(command-s "_.UNDO" "_Mark") (command-s "_.UNDO" "_Begin") '
    body+='(setq outcome (vl-catch-all-apply \'(lambda () (foreach entry originals (setq e (car entry) target (cadr entry)) '
    body+='(command-s "_.DIMEDIT" "_Oblique" e "" "_non" (list 0.0 0.0 0.0) "_non" (list (cos target) (sin target) 0.0)))) nil)) '
    body+='(command-s "_.UNDO" "_End") (if (vl-catch-all-error-p outcome) (progn (command-s "_.UNDO" "_Back") (error (vl-catch-all-error-message outcome)))) (princ))'
    return '((lambda (/ picked index e data rotation target originals entry outcome) '+body+')'


def emit(command,values,number,items):
    from selection_sets import selected_members,reference_lisp
    from dimension_preview import regenerate
    mode=command.get('oblique_mode',MODES[0])
    if mode not in MODES:raise ValueError('スライドの操作を選択してください')
    angle=float(number(command.get('angle','60'),values)) if mode==MODES[0] else None
    sources=selected_members(command,values)
    if not sources:raise ValueError('先にSELECTで寸法を選択してください')
    changed=[]
    for source in sources:
        if source.get('display_type',source['type']) not in LINEAR or source.get('entity_parent') is not None:raise ValueError('長さ寸法または平行寸法だけを選択してください')
        result=copy.deepcopy(source);result['oblique_angle']=direction(source,angle)
        data=result.get('_dimension_data')
        if not data:raise ValueError('寸法の詳細情報がありません。元図面から読み直してください')
        data=dict(data,preserve_text_position=True)
        result['block_geometry']=regenerate(data,result)
        changed.append((source,result))
    prefix=reference_lisp(command.get('selection_ref','@previous'),'chosen')
    script='((lambda (/ chosen) '+prefix+native('chosen',angle,len(sources))+'))'
    for source,result in changed:
        source.update(result);source['dimension_oblique_result']=True
    return [script],[source for source,result in changed]
