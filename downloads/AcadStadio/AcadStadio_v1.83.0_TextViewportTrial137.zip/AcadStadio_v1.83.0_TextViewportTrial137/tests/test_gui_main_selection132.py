"""Main-preview selection routes to the correct definition without changing SCR."""
import copy
import os
from pathlib import Path
import sys
import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui
from block_model import new_block


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform == 'win32', 'GUI unavailable')
class MainSelection(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def install(self, overlap=False, nested=False):
        p = copy.deepcopy(self.app.data)
        circle = dict(type='CIRCLE', x='50', y='30', r='20')
        commands = [circle, dict(circle) if overlap else dict(type='LINE', x1='0', y1='0', x2='100', y2='0')]
        if nested:
            commands = [dict(type='IF', condition='1', commands=commands, **{'else': []})]
        p['blocks'] = [new_block('図形', commands=commands)]
        self.app.replace_document(p)
        self.root.update()
        self.app.preview(quiet=True)
        self.root.update()
        return self.app.preview_selection

    def point(self):
        c = self.app.canvas
        node = next(n for n, item, color in c.geometry if item['type'] == 'CIRCLE')
        box = c.coords(node)
        return round(box[2]), round((box[1] + box[3]) / 2)

    def click(self, point=None, timestamp=10000):
        c = self.app.canvas
        x, y = point or self.point()
        c.event_generate('<ButtonPress-1>', x=x, y=y, time=timestamp)
        c.event_generate('<ButtonRelease-1>', x=x, y=y, time=timestamp + 10)
        self.root.update()

    def test_click_selects_definition_and_link_opens_with_that_target(self):
        s = self.install()
        before = copy.deepcopy(self.app.data); script = self.app.compile()[0]
        self.assertFalse(s.actions.winfo_ismapped())
        view = self.app.canvas.get_view(); height = self.app.canvas.winfo_height()
        self.click()
        self.assertEqual(s.address, ('blocks', 0, 'commands', 0))
        self.assertTrue(s.actions.winfo_ismapped())
        self.assertEqual(self.app.canvas.get_view(), view)
        self.assertEqual(self.app.canvas.winfo_height(), height)
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app.compile()[0], script)
        s.link_button.invoke(); self.root.update()
        win = gui.top(self.root, '紐づけ支援')
        self.assertEqual(win.address, s.address)
        win.close()
        self.assertEqual(self.app.data, before)

    def test_edit_button_updates_only_selected_command_with_undo(self):
        s = self.install(); before = copy.deepcopy(self.app.data)
        self.click()
        def edit():
            win = gui.top(self.root, 'コマンドの設定')
            entry = win.command_entries['r']; entry.delete(0, 'end'); entry.insert(0, '35')
            gui.button(win, 'コマンドを反映').invoke()
        self.root.after(80, edit)
        s.edit_button.invoke(); self.root.update()
        self.assertEqual(self.app.data['blocks'][0]['commands'][0]['r'], '35')
        self.assertEqual(self.app.data['blocks'][0]['commands'][1], before['blocks'][0]['commands'][1])
        self.assertIsNone(s.address)
        self.app.undo_project(); self.root.update()
        self.assertEqual(self.app.data, before)

    def test_pan_is_not_a_click_and_escape_clears_selection(self):
        s = self.install(); c = self.app.canvas
        x, y = self.point(); view = c.get_view()
        c.event_generate('<ButtonPress-1>', x=x, y=y, time=10000)
        c.event_generate('<B1-Motion>', x=x+30, y=y+15)
        c.event_generate('<ButtonRelease-1>', x=x+30, y=y+15, time=10500)
        self.root.update()
        self.assertIsNone(s.address)
        self.assertNotEqual(c.get_view(), view)
        self.click(timestamp=12000)
        self.assertIsNotNone(s.address)
        c.focus_force(); self.root.update(); c.event_generate('<Escape>'); self.root.update()
        self.assertIsNone(s.address)

    def test_overlap_chooses_intended_command_and_pending_pick_can_be_cancelled(self):
        s = self.install(overlap=True)
        self.click()
        self.assertIsNotNone(s.pending)
        s.cancel_pending()
        self.assertIsNone(s.pending)
        self.click(timestamp=12000)
        self.root.after(400, self.root.quit); self.root.mainloop()
        menu = s.menu
        self.assertIsNotNone(menu)
        menu.unpost(); menu.grab_release()
        index = next(i for i in range(menu.index('end')+1) if 'コマンド2 ' in menu.entrycget(i, 'label'))
        menu.invoke(index); self.root.update()
        self.assertEqual(s.address, ('blocks', 0, 'commands', 1))

    def test_stale_data_and_visibility_change_cannot_edit_old_selection(self):
        s = self.install(); self.click()
        self.app.data['blocks'][0]['commands'].reverse()
        with patch.object(self.app, 'edit_preview_command') as edit:
            s.edit_button.invoke()
        edit.assert_not_called(); self.assertIsNone(s.address)
        self.app.refresh(); self.app.preview(quiet=True); self.root.update(); self.click(timestamp=12000)
        self.assertIsNotNone(s.address)
        self.app.block_browser.set_preview_visibility({self.app.data['blocks'][0]['id']}, False)
        self.root.update()
        self.assertIsNone(s.address)
        self.assertFalse(s.actions.winfo_ismapped())

    def test_nested_command_is_link_target_and_row_change_clears_it(self):
        s = self.install(nested=True); self.click()
        self.assertEqual(s.address, ('blocks', 0, 'commands', 0, 'commands', 0))
        self.app.preview_row_controls.value.set('2'); self.app.preview_row_controls.apply()
        self.assertIsNone(s.address)
        self.app.preview(quiet=True); self.root.update(); self.click(timestamp=12000)
        self.assertIsNotNone(s.address)
        self.assertEqual(s.item['row'], 1)

    def test_compact_controls_fit_small_main_and_secondary_windows(self):
        s = self.install(); self.root.geometry('1040x680'); self.root.update()
        self.click()
        for w in gui.descendants(self.root):
            if isinstance(w, (ttk.Button, ttk.Menubutton)) and w.winfo_ismapped():
                self.assertLessEqual(w.winfo_rootx()+w.winfo_width(), w.winfo_toplevel().winfo_rootx()+w.winfo_toplevel().winfo_width())
                self.assertLessEqual(w.winfo_rooty()+w.winfo_height(), w.winfo_toplevel().winfo_rooty()+w.winfo_toplevel().winfo_height())
        first = gui.button(self.app.block_actions, 'ブロック追加')
        settings = self.app.manage_settings_presets(); self.root.update()
        close = gui.button(settings.win, '保存して閉じる')
        self.assertLessEqual(abs(first.winfo_height()-close.winfo_height()), 4)
        self.assertGreater(close.winfo_height(), 20)
        close.invoke(); self.root.update()
        self.assertEqual(self.messages, [])
