import os,unittest,copy
from unittest.mock import patch
import test_gui as gui
from macro_editor import edit_command
from cad_drawing_import import extract_drawing
import ezdxf

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI required')
class TextViewportGui137(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_text_codes_and_live_width_preview(self):
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    w.refresh_command_preview();self.root.update();c=w.command_preview.canvas
    from text_preview import layout
    original=layout(c.items[-1]);self.assertTrue(original.runs)
    e=w.preview_input.compact_entries['text_width'];e.delete(0,'end');e.insert(0,'0.5');e.event_generate('<KeyRelease>');w.refresh_command_preview();self.root.update()
    changed=layout(c.items[-1]);self.assertEqual(changed.width_factor,.5)
    self.assertTrue(c._text_nodes);w.preview_input.show_details();gui.button(w,'コマンドを反映').invoke()
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(200,inspect)
  result=edit_command(self.root,dict(type='TEXT',x='0',y='0',height='3',angle='0',text=r'%%C20{\H0.7x;\S+0.04^0;}'),self.app.data['blocks'],self.app.data)
  self.assertEqual(result['text_width'],'0.5');self.assertFalse(self.messages)
 def test_read_completion_and_close_restore_focus(self):
  doc=ezdxf.new();doc.modelspace().add_line((0,0),(10,0));snap=extract_drawing(doc)
  dialog=self.app.import_cad_drawing(True)
  with patch('window_focus.restore') as restore:
   dialog.result_queue.put((True,(snap,[])));dialog.poll();restore.assert_called_once_with(dialog.win)
   dialog.close();self.assertEqual(restore.call_args.args[0],self.root)
