import sys,unittest,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from selection_sets import batches,native_collect,resolve
from engine import compile_project,MacroError
from test_native_operations import project,command
from test_cad_state import read_form
class SelectionBatches(unittest.TestCase):
 def scene(self,count):
  lines=[dict(type='LINE',x1='0',y1=str(i*5),x2='10',y2=str(i*5)) for i in range(count)]
  qs=[dict(mode='point',x1='5',y1=str(i*5),entity_type='LINE') for i in range(count)]
  sid='p_'+'a'*32
  select=dict(type='SELECT',point_id=sid,selection_name='全体',selections=qs)
  copy=command('COPY',selection_ref=sid,x2='0',y2='0',x3='30',y3='0')
  return lines,select,copy
 def test_batch_boundaries_and_single_logical_select(self):
  for count,sizes in ((100,[100]),(101,[100,1]),(200,[100,100]),(201,[100,100,1])):
   with self.subTest(count=count):
    lines,s,c=self.scene(count)
    self.assertEqual([len(b) for b in batches(s['selections'])],sizes)
    p=json.loads(json.dumps(project(lines+[s,c])))
    script,items=compile_project(p,[0])
    self.assertEqual(items[-2]['selected_count'],count)
    self.assertEqual(items[-2]['selection_batch_count'],len(sizes))
    self.assertEqual(len(items[-1]['children']),count)
    self.assertEqual(sum(x['type']=='SELECT' for x in p['blocks'][0]['commands']),1)
    for line in script.splitlines():
     if line.startswith('('):read_form(line)
     self.assertLessEqual(len(line),2048)
 def test_subtraction_applies_to_previous_batch(self):
  lines,s,c=self.scene(101)
  s['selections'].insert(0,dict(mode='point',x1='5',y1='0',entity_type='LINE',operation='subtract'))
  script,items=compile_project(project(lines+[s,c]),[0])
  self.assertEqual(items[-2]['selected_count'],100)
  self.assertEqual(len(items[-1]['children']),100)
  self.assertIn('(setq selected chosen)',script)
  self.assertIn('(ssdel (ssname part index) selected)',script)
 def test_1000_supported_and_1001_rejected(self):
  _,s,_=self.scene(1000)
  resolved=resolve(s,{},lambda x,c:float(x));self.assertEqual(len(batches(resolved)),10)
  s['selections'].append(s['selections'][0])
  with self.assertRaises(ValueError):resolve(s,{},lambda x,c:float(x))
