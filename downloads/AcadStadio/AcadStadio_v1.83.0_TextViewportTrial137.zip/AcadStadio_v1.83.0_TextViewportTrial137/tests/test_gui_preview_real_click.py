import sys,os,unittest,ctypes
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import MacroEditor

@unittest.skipUnless(os.environ.get('DISPLAY') and sys.platform=='linux','X11 physical mouse test')
class RealClick(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_follow_commands_space_accepts_physical_clicks(self):self.check_space('コマンドに従う')
 def test_model_label_accepts_physical_clicks(self):self.check_space('モデル')
 def check_space(self,space):
  self.app.data['blocks'][0]['drawing_space']='Model'
  ed=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update()
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    self.assertIs(self.root.grab_current(),w,'追加画面のマウス入力が別画面に奪われています')
    self.assertTrue(w.preview_input.capturing)
    xlib=ctypes.CDLL('libX11.so.6');xtest=ctypes.CDLL('libXtst.so.6')
    xlib.XOpenDisplay.restype=ctypes.c_void_p;xlib.XOpenDisplay.argtypes=[ctypes.c_char_p]
    d=xlib.XOpenDisplay(os.environ['DISPLAY'].encode())
    xtest.XTestFakeMotionEvent.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_ulong]
    xtest.XTestFakeButtonEvent.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_ulong]
    xlib.XSync.argtypes=[ctypes.c_void_p,ctypes.c_int];xlib.XCloseDisplay.argtypes=[ctypes.c_void_p]
    c=w.command_preview.canvas
    try:
     for fraction in (.3,.65):
      x=c.winfo_rootx()+int(c.winfo_width()*fraction);y=c.winfo_rooty()+int(c.winfo_height()*fraction)
      xtest.XTestFakeMotionEvent(d,-1,x,y,0);xlib.XSync(d,0);self.root.update()
      xtest.XTestFakeButtonEvent(d,1,1,0);xtest.XTestFakeButtonEvent(d,1,0,0);xlib.XSync(d,0);self.root.update()
     self.assertEqual(len(w.preview_input.picks),2)
     gui.button(w,'追加して閉じる').invoke()
    finally:xlib.XCloseDisplay(d)
   except Exception as exc:self.errors.append(exc)
   finally:
    if w.winfo_exists():w.destroy()
  def choose():
   palette=gui.top(self.root,'追加するコマンド')
   self.root.after(300,inspect)
   gui.button(palette,'LINE').invoke()
  self.root.after(100,choose)
  watchdog=self.root.after(4000,lambda:[w.destroy() for w in gui.descendants(self.root) if isinstance(w,gui.tk.Toplevel)])
  try:
   ed.list.choose_add()
   self.assertEqual(ed.list.commands[-1]['type'],'LINE')
   self.assertEqual(len(ed.list.commands[-1]['vertices']),2)
  finally:
   self.root.after_cancel(watchdog);ed.win.destroy()
