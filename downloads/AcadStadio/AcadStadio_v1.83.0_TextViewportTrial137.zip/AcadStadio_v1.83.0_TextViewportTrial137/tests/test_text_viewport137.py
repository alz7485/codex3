import unittest,copy
from test_cad_output135 import project
from engine import compile_project
from text_preview import layout,raster
from cad_text_format import styled_tokens
from layout_commands import render
from test_cad_state import read_form,walk

class TextViewport137(unittest.TestCase):
 def test_text_command_formats_symbol_and_tolerance(self):
  for raw in (r'%%C20{\H0.7x;\S+0.04^0;}','%%c20{¥H0.7x;¥S+0.04^0;}'):
   s,items=compile_project(project([dict(type='TEXT',x='0',y='0',height='3',angle='0',text=raw)]),[0])
   d=layout(items[0]);self.assertIn('φ',''.join(r[0] for r in d.runs));self.assertTrue(any(r[0]=='+0.04' for r in d.runs))
   self.assertIn('vla-AddMText',s);self.assertLess(d.box[2]-d.box[0],100)
   for line in s.splitlines():
    if line.startswith('('):read_form(line)
 def test_width_factor_affects_text_without_changing_height(self):
  for kind in ('TEXT','MTEXT'):
   c=dict(type=kind,x='0',y='0',text='ABC',height='3',angle='0',width='80',text_width='1')
   _,a=compile_project(project([c]),[0]);c['text_width']='0.5';s,b=compile_project(project([c]),[0])
   aa,bb=layout(a[0]),layout(b[0]);self.assertEqual(aa.unit,bb.unit);self.assertEqual(bb.width_factor,.5)
   self.assertIn('(cons 41 0.5)',s) if kind=='TEXT' else self.assertIn(r'\\W0.5;',s)
 def test_inline_width_preserves_scope_and_rendered_pixels(self):
  item=dict(type='MTEXT',coords=(0,0,3),text=r'A{\W0.5;BB}C',width=50,text_anchor='center')
  data=layout(item);self.assertEqual(data.run_widths,(1.,.5,.5,1.))
  im,pos=raster(item,'white',lambda x,y:(300+x*10,100-y*10),10,(600,200));self.assertTrue(im.getchannel('A').getbbox())
 def test_lowercase_tolerance_codes(self):
  self.assertEqual(list(styled_tokens(r'{\h0.7x;\s+0.04^0;}',3)),[('+0.04','0',.7,1.)])
 def test_viewport_creation_uses_no_interactive_mview(self):
  lines=render(dict(type='VIEWPORT',viewport_action='矩形を作成',x1='10',y1='20',x2='110',y2='70'),{},lambda v,c:str(v))
  source='\n'.join(lines);self.assertIn('vla-AddPViewport',source);self.assertIn('(list 60 45 0.0)',source);self.assertIn('100 50)',source);self.assertNotIn('"_.MVIEW"',source)
  for line in lines:read_form(line)
 def test_diameter_is_independent_native_entity(self):
  s,it=compile_project(project([dict(type='DIMDIAMETER',x='0',y='0',r='10',x3='20',y3='0')]),[0])
  self.assertIn('vla-AddDimDiametric',s);self.assertIn('(list 10 0 0.0)',s);self.assertIn('(list -10 0 0.0)',s)
  self.assertNotIn('(entdel',s);self.assertNotIn('"_.DIMDIAMETER"',s);self.assertEqual(it[0]['coords'][2],10)
