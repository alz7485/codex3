import copy,sys,os,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import MacroEditor,CommandList,TYPE_LABELS
from block_model import new_block,unique_block_name
from command_types import COMMAND_GROUPS

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI unavailable')
class Workflow129(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_new_block_name_is_unique_and_cancel_keeps_project(self):
  self.app.data['blocks'].append(new_block('新しいブロック(1)'));self.app.data['blocks'].append(new_block('新しいブロック(2)'))
  before=copy.deepcopy(self.app.data);self.app.add_block();self.root.update();win=gui.top(self.root,'ブロック編集')
  from tkinter import ttk
  entries=[w for w in gui.descendants(win) if isinstance(w,ttk.Entry)]
  self.assertTrue(any(w.get()=='新しいブロック(3)' for w in entries));gui.button(win,'キャンセル').invoke();self.assertEqual(self.app.data,before)
 def test_space_is_fixed_to_owner_and_picker_removed(self):
  from space_folders import create_layout
  project,fid=create_layout(self.app.data,'A4');self.app.replace_document(project)
  b=new_block('用紙',commands=[]);b.update(folder_id=fid,drawing_space='A4');self.app.data['blocks'].append(b)
  e=MacroEditor(self.root,b,self.app.data['blocks'],lambda:None,self.app.data,[0]);self.root.update()
  self.assertFalse(hasattr(e,'space_picker'));self.assertEqual(e.list.current_space(),'A4');self.assertEqual(e.current()['drawing_space'],'A4');self.assertTrue(e.list.space_creation_reason('SPACE'));e.win.destroy()
 def test_ctrl_navigation_selects_last_first_without_reordering(self):
  cmds=[dict(type='POINT',x=str(i),y='0') for i in range(4)]
  listing=CommandList(self.root,cmds,self.app.data['blocks'],project=self.app.data);self.root.update();listing.tree.focus_force();self.root.update()
  listing.tree.event_generate('<Control-Down>');self.root.update();self.assertEqual(listing.indices(),[3]);self.assertEqual(listing.tree.focus(),'3')
  listing.tree.event_generate('<Control-Up>');self.root.update();self.assertEqual(listing.indices(),[0]);self.assertEqual(cmds[-1]['x'],'3')
 def test_reference_label_uses_master_command_and_reference_badge(self):
  identity='s_'+'a'*32;cmds=[dict(type='SYSVAR',name='USERR1',value='1',setting_id=identity),dict(type='SETTINGREF',setting_ref=identity)]
  listing=CommandList(self.root,cmds,self.app.data['blocks'],project=self.app.data);self.root.update()
  self.assertEqual(listing.tree.item('0','text'),'［正本］'+TYPE_LABELS['SYSVAR']);self.assertEqual(listing.tree.item('1','text'),'［参照］'+TYPE_LABELS['SYSVAR'])
 def test_categories_are_merged_and_space_creation_is_absent(self):
  groups=dict(COMMAND_GROUPS);self.assertIn('VIEWPORT',groups['線・形状を追加 ▾']);self.assertEqual(len(groups),4)
  self.assertFalse(any('SPACE' in types for types in groups.values()));self.assertIn('IF',groups['設定・制御を追加 ▾']);self.assertIn('APPEARANCE',groups['設定・制御を追加 ▾'])
 def test_input_table_window_uses_larger_screen_bounded_size(self):
  from unittest.mock import patch
  import main
  self.assertGreaterEqual(self.app.input_window.minsize()[0],1040);self.assertGreaterEqual(self.app.input_window.minsize()[1],640)
