"""DIMEDIT Oblique geometry, SCR, selection references and DXF import."""
import copy
import math
import unittest
import ezdxf
from engine import compile_project,MacroError
from block_model import new_block
from sample_project import EXAMPLE
from command_points import new_id,geometry_points
from dimension_oblique import emit,line_angle,points,native
from cad_drawing_import import extract_drawing,imported_project
from selection_sets import select_queries
from selection_pick_reference import exclusion_reference
from range_selection import select_range
from preview_edit_actions import build,minimum
from test_cad_state import read_form,walk
from audit import audit_project

SID='p_'+'b'*32

def dimension(kind='DIMLINEAR',axis='horizontal',**fields):
    return dict(type=kind,x1='0',y1='0',x2='100',y2='0',x3='50',y3='20',dimension_axis=axis,point_id='p_'+'a'*32,**fields)

def selector():return dict(type='SELECT',selection_name='寸法選択',point_id=SID,selections=[dict(mode='window',x1='-100',y1='-100',x4='200',y4='200')])

def edit(**fields):return dict(type='DIMEDIT',selection_ref=SID,angle='60',**fields)

def project(commands):
    p=copy.deepcopy(EXAMPLE);p['blocks']=[new_block('寸法',commands=commands)];return p


class DimensionOblique136(unittest.TestCase):
    def test_horizontal_slide_preserves_measurement_and_uses_world_direction(self):
        script,items=compile_project(project([dimension(),selector(),edit()]),[0])
        dim=items[0];p=geometry_points(dim)
        self.assertAlmostEqual(dim['oblique_angle'],60)
        self.assertAlmostEqual(p['寸法線始点'][0],20/math.tan(math.radians(60)))
        self.assertAlmostEqual(p['寸法線始点'][1],20)
        self.assertAlmostEqual(p['寸法線終点'][0]-p['寸法線始点'][0],100)
        self.assertTrue(any(g.get('text')=='100' for g in dim['block_geometry']))
        self.assertIn('"_.DIMEDIT" "_Oblique"',script)
        self.assertIn('"_non" (list 0.0 0.0 0.0) "_non" (list (cos target) (sin target) 0.0)',script)
        self.assertNotIn('(setvar "ANGBASE"',script)
        self.assertEqual(audit_project(project([dimension(),selector(),edit()])),[])
        for line in script.splitlines():
            if line.startswith('('):read_form(line)
            self.assertLessEqual(len(line),2048)

    def test_vertical_and_aligned_dimensions_keep_world_angle(self):
        for command,base in [(dict(dimension(axis='vertical'),x2='0',y2='100',x3='20',y3='50'),90),
                             (dict(dimension('DIMALIGNED'),x2='60',y2='80',x3='-16',y3='12'),math.degrees(math.atan2(80,60)))]:
            with self.subTest(command=command):
                _,items=compile_project(project([command,selector(),edit()]),[0]);item=items[0]
                self.assertAlmostEqual(line_angle(item),base)
                refs=points(item)
                for key,start in [('寸法線始点',item['coords'][:2]),('寸法線終点',item['coords'][2:4])]:
                    end=refs[key];dx,dy=end[0]-start[0],end[1]-start[1]
                    self.assertAlmostEqual(dx*math.sin(math.radians(60))-dy*math.cos(math.radians(60)),0)

    def test_reset_is_perpendicular_for_each_selected_dimension(self):
        horizontal=dimension();vertical=dict(dimension(axis='vertical'),x1='130',x2='130',y2='100',x3='150',y3='50',point_id=new_id())
        commands=[horizontal,vertical,selector(),edit(),edit(oblique_mode='直角に戻す')]
        script,items=compile_project(project(commands),[0])
        self.assertEqual([i['oblique_angle'] for i in items if i['type']=='DIMLINEAR'],[90,0])
        self.assertIn('(+ rotation (/ pi 2.0))',script)
        for actual,expected in zip(geometry_points(items[0])['寸法線始点'],(0.,20.)):self.assertAlmostEqual(actual,expected)

    def test_inactive_invalid_angle_is_audited_and_parallel_angle_rejected(self):
        for angle in ('0','180','1/0','True'):
            with self.subTest(angle=angle),self.assertRaises(MacroError):compile_project(project([dimension(),selector(),dict(edit(),angle=angle)]),[0])
        p=project([dict(type='IF',condition='False',commands=[dict(edit(),angle='evil()')])])
        self.assertTrue(audit_project(p));self.assertEqual(compile_project(p,[0])[1],[])

    def test_mixed_or_empty_selection_never_changes_any_source(self):
        _,items=compile_project(project([dimension(),dict(type='LINE',x1='0',y1='-10',x2='100',y2='-10')]),[0])
        before=copy.deepcopy(items)
        context={'__selection_state__':dict(last=SID,sets={SID:items})}
        with self.assertRaises(ValueError):emit(edit(),context,lambda v,c:float(v),items)
        self.assertEqual(items,before)
        with self.assertRaises(MacroError):compile_project(project([edit()]),[0])
        with self.assertRaises(MacroError):compile_project(project([dimension(),selector(),edit(oblique_mode='unknown')]),[0])

    def test_radius_dimension_is_rejected(self):
        with self.assertRaises(MacroError):compile_project(project([dict(type='DIMRADIUS',x='0',y='0',r='10',x3='20',y3='20'),selector(),edit()]),[0])

    def test_point_and_window_selection_identify_the_dimension_as_one_entity(self):
        _,items=compile_project(project([dimension()]),[0]);dim=items[0]
        members=select_queries(items,[dict(mode='point',point=(25,20),entity_type='DIMLINEAR')],.01)
        self.assertEqual(members,[dim])
        self.assertEqual(select_range(items,(-5,-5,105,30),'window'),[dim])
        self.assertEqual(select_range(items,(20,19,30,21),'crossing'),[dim])
        self.assertEqual(select_range(items,(20,100,30,101),'crossing'),[])

    def test_selection_reference_avoids_a_crossing_at_dimension_midpoint(self):
        _,items=compile_project(project([dimension(),dict(type='LINE',x1='50',y1='15',x2='50',y2='25')]),[0]);dim=items[0]
        ref=exclusion_reference(dim,items,(50,20),.01,lambda source:source.get('point_id'))
        self.assertTrue(ref['unique_pick']);self.assertEqual(ref['entity_type'],'DIMLINEAR')
        self.assertIn('点(',ref['x1'])
        # The saved reference resolves to a different point on the same dimension.
        commands=[dimension(),dict(type='LINE',x1='50',y1='15',x2='50',y2='25'),dict(type='SELECT',selection_name='寸法選択',point_id=SID,selections=[ref]),edit()]
        script,rendered=compile_project(project(commands),[0]);self.assertEqual(rendered[-1]['selected_count'],1)
        self.assertIn('dimhits',script);self.assertIn('"_Restore" name',script)
        for line in script.splitlines():self.assertLessEqual(len(line),2048)

    def test_preview_direction_picks_and_reset_require_no_coordinate_fields(self):
        changed=build(edit(),[dict(xy=(10,20)),dict(xy=(20,30))])
        self.assertAlmostEqual(float(changed['angle']),45)
        self.assertNotIn('x2',changed)
        self.assertEqual(minimum(edit(oblique_mode='直角に戻す')),0)
        self.assertEqual(build(edit(oblique_mode='直角に戻す'),[])['oblique_mode'],'直角に戻す')
        with self.assertRaises(ValueError):build(edit(),[dict(xy=(0,0)),dict(xy=(0,0))])

    def test_point_references_after_slide_use_updated_geometry(self):
        d=dimension();point=dict(type='POINT',x=f"点('{d['point_id']}', '寸法線始点', 'X')",y=f"点('{d['point_id']}', '寸法線始点', 'Y')")
        _,items=compile_project(project([d,selector(),edit(),point]),[0])
        for actual,expected in zip(items[-1]['coords'],geometry_points(items[0])['寸法線始点']):self.assertAlmostEqual(actual,expected,places=9)

    def test_dxf_oblique_import_export_and_coordinate_edit_keep_direction(self):
        doc=ezdxf.new(setup=True)
        d=doc.modelspace().add_linear_dim(base=(20,0),p1=(0,0),p2=(0,100),angle=90,override={'dimlfac':1})
        d.dimension.dxf.oblique_angle=150;d.render()
        p=imported_project(extract_drawing(doc));cmd=p['blocks'][1]['commands'][0]
        self.assertAlmostEqual(float(cmd['oblique_angle']),60)
        script,items=compile_project(p,[0]);self.assertEqual(items[0]['oblique_angle'],60)
        self.assertEqual(items[0]['block_geometry'],cmd['import_source']['dimension']['graphics'])
        self.assertIn('"_.DIMEDIT" "_Oblique"',script)
        cmd['y2']='120';_,items=compile_project(p,[0]);self.assertNotIn('preview_note',items[0])
        self.assertAlmostEqual(items[0]['oblique_angle'],60)

    def test_imported_manual_text_position_and_style_are_kept(self):
        doc=ezdxf.new(setup=True)
        d=doc.modelspace().add_linear_dim(base=(0,20),p1=(0,0),p2=(100,0),override=dict(dimlfac=1,dimclrd=4,dimblk='OPEN'))
        d.set_location((75,30));d.render()
        p=imported_project(extract_drawing(doc));commands=p['blocks'][1]['commands'];original=copy.deepcopy(commands)
        commands.extend([selector(),edit()]);script,items=compile_project(p,[0]);dim=items[0]
        label=next(g for g in dim['block_geometry'] if g['type']=='MTEXT')
        self.assertAlmostEqual(label['coords'][0],75);self.assertAlmostEqual(label['coords'][1],30)
        self.assertTrue(any(g.get('color')==4 for g in dim['block_geometry']))
        self.assertEqual(commands[:1],original)
        self.assertIn('"DIMBLK" "_OPEN"',script)

    def test_native_preflight_is_before_undo_and_restores_errors(self):
        script=native('chosen',60,2);read_form(script)
        self.assertLess(script.index('Select linear or aligned'),script.index('"_Begin"'))
        self.assertIn('"_Back"',script)
        nodes=list(walk(read_form(script)))
        self.assertTrue(any(n and n[0]=='vl-catch-all-apply' for n in nodes))

if __name__=='__main__':unittest.main()
