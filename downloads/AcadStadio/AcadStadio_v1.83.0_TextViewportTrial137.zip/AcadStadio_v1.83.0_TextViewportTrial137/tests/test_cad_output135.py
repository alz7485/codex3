"""Output, dimension rendering and imported resource regressions for Trial135."""
import copy
import tempfile
import unittest
from pathlib import Path
import ezdxf
from block_model import new_block
from sample_project import EXAMPLE
from engine import compile_project
from cad_drawing_import import extract_drawing, imported_project
from cad_setup import default_setup, initial_macro, validate_setup
from dimension_styles import from_dxf
from project_safety import atomic_write_script
from script_encoding import encode_script
from text_preview import layout, display_text, raster
from cad_text_format import encoded
from test_cad_state import read_form, walk
from test_dwg_resources import FakeDocument
from dwg_resources import extract_resources


def project(commands):
    p=copy.deepcopy(EXAMPLE)
    p['blocks']=[new_block('確認',commands=commands)]
    p['cad_setup']=default_setup()
    return p


class CadOutput135(unittest.TestCase):
    def test_ellipse_has_complete_native_geometry_without_command_prompts(self):
        p=project([dict(type='ELLIPSE',x='10',y='20',rx='8',ry='4',angle='90',color='2')])
        script,items=compile_project(p,[0])
        line=next(s for s in script.splitlines() if '(entmake' in s and '"ELLIPSE"' in s)
        nodes=list(walk(read_form(line)))
        self.assertTrue(any(n[:2]==['cons','10'] and n[2]==['list','10','20','0.0'] for n in nodes))
        major=next(n[2][1:] for n in nodes if n[:2]==['cons','11'])
        self.assertAlmostEqual(float(major[0]),0);self.assertAlmostEqual(float(major[1]),8)
        self.assertIn(['40','.','0.5'],nodes)
        self.assertIn('vla-put-Color',line)
        self.assertNotIn('_.ELLIPSE',script)
        self.assertEqual(items[0]['coords'],(10,20,8,4))

    def test_cp932_keeps_japanese_and_reconstructs_non_cp932_bmp(self):
        script='_.TEXT\n日本語⌀寸法\n(command-s "_.TEXT" "公差⌀")\n'
        text=encode_script(script,'cp932').decode('cp932')
        self.assertIn('日本語',text);self.assertIn('(chr 8960)',text)
        self.assertNotIn('⌀',text);self.assertIn('LISPSYS',text)
        self.assertIn('\r\n',text);self.assertNotIn('\n',text.replace('\r\n',''))
        for line in text.splitlines():
            if line.startswith('('):read_form(line)
        plain='_.TEXT\n日本語φ\n'
        self.assertEqual(encode_script(plain),plain.replace('\n','\r\n').encode('cp932'))
        self.assertEqual(encode_script(script,'utf-8').decode('utf-8'),script.replace('\n','\r\n'))

    def test_unconvertible_code_or_quoted_data_never_replaces_existing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'drawing.scr';target.write_bytes(b'original')
            for text,error in [('(setq ⌀ 1)',UnicodeEncodeError),('emoji 😀',UnicodeEncodeError),('(setq x "⌀"',ValueError)]:
                with self.subTest(text=text),self.assertRaises(error):atomic_write_script(target,text)
                self.assertEqual(target.read_bytes(),b'original')
            atomic_write_script(target,'日本語⌀\n')
            self.assertIn(b'(chr 8960)',target.read_bytes())

    def test_unicode_in_quoted_initialization_forms_stays_executable(self):
        setup=default_setup();setup.update(enabled=True,dim_styles=[dict(name='寸法',dimpost='⌀<>')])
        script=encode_script('\n'.join(initial_macro(setup))).decode('cp932')
        self.assertIn('(chr 8960)',script)
        for line in script.splitlines():
            if not line.startswith('('):continue
            nodes=list(walk(read_form(line)))
            for node in nodes:
                if node and node[0]=='quote':
                    self.assertFalse(any(n and n[0]=='chr' for n in walk(node[1:])))
        dotted=encode_script('(setq e \'(1 . "⌀"))').decode('cp932')
        self.assertIn('(cons \'1 (strcat (chr 8960)))',dotted)

    def test_formatted_center_uses_actual_text_width_and_decodes_symbols(self):
        item=dict(type='MTEXT',coords=(0,0,3),text=r'%%C20{\H0.7x;\S+0.04^0;}',width=40,text_anchor='center')
        data=layout(item)
        self.assertIn('φ',''.join(r[0] for r in data.runs))
        left=min(r[1] for r in data.runs)
        right=max(x+data.font.getlength(t)*data.unit*s for t,x,y,s in data.runs)
        self.assertAlmostEqual((left+right)/2,0)
        upper=next(r for r in data.runs if r[0]=='+0.04');lower=next(r for r in data.runs if r[0]=='0')
        self.assertGreater(upper[2],lower[2]);self.assertEqual(upper[3],.7)
        image,_=raster(item,'white',lambda x,y:(300+x*10,100-y*10),10,(600,200))
        self.assertIsNotNone(image.getchannel('A').getbbox())
        self.assertEqual(display_text(r'\U+03C6 %%C'),'φ φ')
        self.assertEqual(encoded('{¥H0.7x;¥S+0.04^0;}'),r'{\H0.7x;\S+0.04^0;}')

    def test_native_dimension_preview_contains_centered_formatted_text(self):
        p=project([dict(type='DIMLINEAR',x1='0',y1='0',x2='100',y2='0',x3='50',y3='20',dimension_axis='horizontal',dimension_text=r'%%C<>{\H0.7x;\S+0.04^0;}')])
        _,items=compile_project(p,[0]);item=items[0]
        self.assertNotIn('preview_note',item)
        self.assertTrue(all(g['layer']==item['layer'] for g in item['block_geometry']))
        self.assertTrue(all(g['color']==item.get('color',256) for g in item['block_geometry']))
        text=next(g for g in item['block_geometry'] if g['type']=='MTEXT')
        self.assertAlmostEqual(text['coords'][0],50)
        self.assertIn('φ',''.join(r[0] for r in layout(text).runs))
        self.assertTrue(any(r[0]=='+0.04' for r in layout(text).runs))

    def test_dxf_dimstyle_arrows_position_post_and_bigfont_survive_import(self):
        doc=ezdxf.new('R2000',setup=True)
        doc.styles.new('日本語',dxfattribs=dict(font='txt.shx',bigfont='extfont2.shx'))
        style=doc.dimstyles.new('確認寸法',dxfattribs=dict(dimtxt=3.5,dimasz=2.5,dimpost='%%C<> mm',dimtih=1,dimtoh=1,dimtolj=2,dimsah=1))
        style.set_arrows(blk='OPEN',blk1='DOT',blk2='OBLIQUE')
        values=from_dxf(style)
        self.assertEqual(values,dict(dimblk='_OPEN',dimblk1='_DOT',dimblk2='_OBLIQUE',dimsah='1',dimpost='%%C<> mm',dimtih='1',dimtoh='1',dimtolj='2'))
        doc.modelspace().add_line((0,0),(10,0))
        snapshot=extract_drawing(doc);setup=snapshot['cad_setup']
        text=next(s for s in setup['text_styles'] if s['name']=='日本語')
        self.assertTrue(text['use_bigfont']);self.assertEqual(text['bigfont'],'extfont2.shx')
        dim=next(s for s in setup['dim_styles'] if s['name']=='確認寸法')
        self.assertEqual({k:dim[k] for k in values},values)
        setup['enabled']=True;self.assertEqual(validate_setup(setup),[])
        macro='\n'.join(initial_macro(setup))
        self.assertIn('(cons 4 "extfont2.shx")',macro)
        for key,value in values.items():
            self.assertIn('(setvar "'+key.upper()+'" ',macro)
        for line in macro.splitlines():
            if line.startswith('('):read_form(line)
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'drawing.dxf';doc.encoding='cp932';doc.saveas(path)
            reread=extract_drawing(ezdxf.readfile(path))
            self.assertEqual(next(s for s in reread['cad_setup']['dim_styles'] if s['name']=='確認寸法'),dim)

    def test_dwg_activex_reads_optional_style_properties_and_restores_active(self):
        doc=FakeDocument();doc.TextStyles[0].BigFontFile='extfont2.shx'
        doc._styles['CF_DIM'].update(DIMBLK='_OPEN',DIMBLK1='_DOT',DIMBLK2='_OBLIQUE',DIMSAH=1,DIMPOST='%%C<>',DIMTIH=1,DIMTOH=0,DIMTOLJ=2)
        original=doc.ActiveDimStyle
        resources,issues=extract_resources(doc)
        self.assertEqual(issues,[]);self.assertIs(doc.ActiveDimStyle,original)
        self.assertTrue(resources['text_styles'][0]['values']['use_bigfont'])
        dim=resources['dim_styles'][1]['values']
        self.assertEqual(dim['dimblk1'],'_DOT');self.assertEqual(dim['dimtolj'],'2');self.assertEqual(dim['dimtoh'],'0')
        self.assertEqual(dim['dimpost'],'%%C<>')

    def test_dimension_style_arrows_change_preview_and_dimpost_is_exported(self):
        p=project([dict(type='DIMLINEAR',x1='0',y1='0',x2='100',y2='0',x3='50',y3='20',dim_style='寸法')])
        p['cad_setup']['dim_styles']=[dict(name='寸法',dimblk='_OPEN',dimpost='%%C<> mm',dimtih='1',dimtoh='1',dimtolj='2')]
        _,opened=compile_project(p,[0])
        self.assertNotIn('preview_note',opened[0])
        self.assertFalse(any(g['type']=='HATCH' for g in opened[0]['block_geometry']))
        label=next(g for g in opened[0]['block_geometry'] if g['type']=='MTEXT')
        self.assertEqual(label['text'],'%%C100 mm')
        p['cad_setup']['dim_styles'][0]['dimblk']=''
        _,closed=compile_project(p,[0])
        self.assertTrue(any(g['type']=='HATCH' for g in closed[0]['block_geometry']))
        doc=ezdxf.new(setup=True)
        dimension=doc.modelspace().add_linear_dim(base=(0,12),p1=(0,0),p2=(30,0),override={'dimpost':'%%C<> mm'})
        dimension.render()
        script,items=compile_project(imported_project(extract_drawing(doc)),[0])
        self.assertIn('"DIMPOST" "%%C<> mm"',script)

    def test_all_standard_arrow_overrides_use_autocad_names(self):
        for arrow in ('OBLIQUE','ARCHTICK','DOTSMALL','CLOSEDBLANK','OPEN'):
            with self.subTest(arrow=arrow):
                doc=ezdxf.new(setup=True)
                d=doc.modelspace().add_linear_dim(base=(0,12),p1=(0,0),p2=(30,0),override=dict(dimblk=arrow))
                d.render();script,_=compile_project(imported_project(extract_drawing(doc)),[0])
                self.assertIn('"DIMBLK" "_'+arrow+'"',script)

    def test_edited_imported_style_updates_preview_and_export_without_losing_other_overrides(self):
        doc=ezdxf.new(setup=True)
        dim=doc.modelspace().add_linear_dim(base=(0,12),p1=(0,0),p2=(100,0),override=dict(dimblk='OPEN',dimclrd=4,dimlfac=1,dimdec=0))
        dim.render();p=imported_project(extract_drawing(doc))
        command=next(c for b in p['blocks'] for c in b['commands'] if c['type']=='DIMLINEAR')
        original=copy.deepcopy(command['import_source'])
        row=next(r for r in p['cad_setup']['dim_styles'] if r['name']==command['dim_style'])
        row.update(dimpost='%%C<> mm',dimtih='1',dimtoh='1',dimtolj='2')
        script,items=compile_project(p,[0])
        self.assertNotIn('preview_note',items[0]);self.assertNotEqual(items[0]['block_geometry'],original['dimension']['graphics'])
        self.assertIn('"DIMPOST" "%%C<> mm"',script);self.assertIn('"DIMCLRD" 4',script)
        self.assertIn('"DIMBLK" "_OPEN"',script)
        self.assertTrue(any(g.get('text')=='%%C100 mm' for g in items[0]['block_geometry']))
        self.assertEqual(command['import_source'],original)

    def test_unknown_custom_arrow_falls_back_without_blocking_export(self):
        p=project([dict(type='DIMLINEAR',x1='0',y1='0',x2='100',y2='0',x3='50',y3='20',dim_style='寸法')])
        p['cad_setup']['dim_styles']=[dict(name='寸法',dimblk='CUSTOM_ARROW')]
        script,items=compile_project(p,[0])
        self.assertIn('概略表示',items[0]['preview_note'])
        self.assertIn('_.DIMLINEAR',script)

    def test_bigfont_requires_filename_only_when_enabled_and_flags_are_bounded(self):
        setup=default_setup();setup['text_styles']=[dict(name='J',font='txt.shx',use_bigfont=True)]
        self.assertTrue(validate_setup(setup))
        setup['text_styles'][0]['bigfont']='extfont2.shx';self.assertFalse(validate_setup(setup))
        setup['dim_styles']=[dict(name='D',dimtolj='3')];self.assertTrue(validate_setup(setup))
        setup['dim_styles'][0]['dimtolj']='2';self.assertFalse(validate_setup(setup))

if __name__=='__main__':unittest.main()
