"""Real Tk: preview-only selection, direction capture, reset and cancellation."""
import copy
import os
import sys
import unittest
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
import test_gui as gui
from macro_editor import edit_command,CommandList,MacroEditor
from engine import compile_project
from test_dimension_oblique136 import dimension,selector,edit,project,SID

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI unavailable')
class DimensionObliqueGui136(unittest.TestCase):
    def setUp(self):
        gui.Gui.setUp(self)
        def timeout():
            self.errors.append(TimeoutError('DIMEDIT GUI test did not finish: '+str(self.messages)))
            for w in list(gui.descendants(self.root)):
                if isinstance(w,gui.tk.Toplevel) and w.winfo_exists():w.destroy()
        self.watchdog=self.root.after(7000,timeout)

    def tearDown(self):
        self.root.after_cancel(self.watchdog)
        gui.Gui.tearDown(self)

    def stage(self,fn):
        try:fn(gui.top(self.root,'コマンドの設定'))
        except Exception as exc:
            self.errors.append(exc)
            for w in list(gui.descendants(self.root)):
                if hasattr(w,'command_preview') and w.winfo_exists():w.destroy()

    def dialog(self,fn,command=None,prior=None,creating=True):
        self.root.after(180,lambda:self.stage(fn))
        return edit_command(self.root,command or edit(),self.app.data['blocks'],self.app.data,
                            point_sources=prior or [dimension(),selector()],creating=creating)

    def click(self,canvas,p):
        x,y=canvas.screen_point(p)
        canvas.event_generate('<ButtonPress-1>',x=round(x),y=round(y))
        canvas.event_generate('<ButtonRelease-1>',x=round(x),y=round(y));self.root.update()

    def test_direction_points_update_dimension_and_enter_accepts(self):
        before=copy.deepcopy(self.app.data)
        def inspect(w):
            w.refresh_command_preview();self.root.update();c=w.command_preview.canvas
            self.assertTrue(w.preview_input.capturing)
            self.click(c,(10,-10));self.click(c,(40,20));self.root.update()
            self.assertFalse(w.preview_input.capturing)
            self.assertAlmostEqual(float(w.command_entries['angle'].get()),45,delta=1)
            w.refresh_command_preview();self.root.update()
            changed=next(i for i in c.items if i['type']=='DIMLINEAR')
            self.assertAlmostEqual(changed['oblique_angle'],45,delta=1)
            c.focus_force();c.event_generate('<KeyPress-Return>');self.root.update()
        result=self.dialog(inspect)
        self.assertEqual(result['type'],'DIMEDIT');self.assertEqual(self.app.data,before)
        _,items=compile_project(project([dimension(),selector(),result]),[0])
        self.assertAlmostEqual(items[0]['oblique_angle'],45,delta=1)
        self.assertFalse(self.messages)

    def test_reset_mode_hides_angle_and_needs_no_points(self):
        def inspect(w):
            picker=w.preview_input.compact_entries['oblique_mode']
            picker.set('直角に戻す');picker.event_generate('<<ComboboxSelected>>');self.root.update()
            w.refresh_command_preview();self.root.update()
            self.assertNotIn('angle',w.command_entries)
            self.assertFalse(w.preview_input.capturing)
            dim=next(i for i in w.command_preview.canvas.items if i['type']=='DIMLINEAR')
            self.assertAlmostEqual(dim['oblique_angle'],90)
            gui.button(w,'コマンドを反映').invoke()
        result=self.dialog(inspect)
        self.assertEqual(result['oblique_mode'],'直角に戻す');self.assertFalse(self.messages)

    def test_numeric_angle_and_editing_an_existing_slide(self):
        def inspect(w):
            entry=w.preview_input.compact_entries['angle'];entry.delete(0,'end');entry.insert(0,'120');entry.event_generate('<KeyRelease>')
            w.refresh_command_preview();self.root.update()
            self.assertAlmostEqual(next(i for i in w.command_preview.canvas.items if i['type']=='DIMLINEAR')['oblique_angle'],120)
            gui.button(w,'コマンドを反映').invoke()
        result=self.dialog(inspect,creating=False)
        self.assertEqual(result['angle'],'120');self.assertFalse(self.messages)

    def test_numeric_input_can_finish_creation_without_direction_points(self):
        def inspect(w):
            self.assertTrue(w.preview_input.capturing)
            entry=w.preview_input.compact_entries['angle'];entry.focus_force();self.root.update()
            self.assertFalse(w.preview_input.capturing)
            entry.delete(0,'end');entry.insert(0,'120');entry.event_generate('<KeyRelease>')
            w.refresh_command_preview();self.root.update()
            gui.button(w,'コマンドを反映').invoke()
        result=self.dialog(inspect)
        self.assertEqual(result['angle'],'120');self.assertFalse(self.messages)

    def test_auto_select_click_then_direction_and_commit(self):
        prior=[dimension()]
        def select(w):
            self.assertIsNotNone(w.select_editor);w.refresh_command_preview();self.root.update()
            self.click(w.command_preview.canvas,(25,20));w.refresh_command_preview();self.root.update()
            self.assertEqual(w.command_preview.canvas.selection_count,1)
            self.root.after(100,lambda:self.stage(slide));gui.button(w,'選択を確定').invoke()
        def slide(w):
            self.click(w.command_preview.canvas,(10,-10));self.click(w.command_preview.canvas,(40,20))
            gui.button(w,'コマンドを反映').invoke()
        result=self.dialog(select,command={'type':'DIMEDIT'},prior=prior)
        self.assertEqual([c['type'] for c in result],['SELECT','DIMEDIT'])
        self.assertEqual(result[1]['selection_ref'],result[0]['point_id'])
        _,items=compile_project(project(prior+result),[0]);self.assertIn('oblique_angle',items[0])
        self.assertFalse(self.messages)

    def test_auto_select_range_and_cancel_roll_back_draft(self):
        prior=[dimension()];original=copy.deepcopy(prior);before=copy.deepcopy(self.app.data)
        def select(w):
            w.refresh_command_preview();self.root.update()
            w.select_editor.simple_rectangle((-5,-5),(105,30));w.refresh_command_preview();self.root.update()
            self.assertEqual(w.command_preview.canvas.selection_count,1)
            self.root.after(100,lambda:self.stage(lambda child:gui.button(child,'キャンセル').invoke()))
            gui.button(w,'選択を確定').invoke()
        self.assertIsNone(self.dialog(select,command={'type':'DIMEDIT'},prior=prior))
        self.assertEqual(prior,original);self.assertEqual(self.app.data,before)

    def test_command_list_add_and_undo_redo_preserve_selection_pair(self):
        data=project([dimension()]);self.app.replace_document(data);self.root.update()
        editor=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update()
        before=copy.deepcopy(editor.list.commands)
        def select(w):
            w.refresh_command_preview();self.root.update();w.select_editor.simple_rectangle((-5,-5),(105,30))
            self.root.after(100,lambda:self.stage(slide))
            gui.button(w,'選択を確定').invoke()
        def slide(w):
            self.click(w.command_preview.canvas,(10,-10));self.click(w.command_preview.canvas,(40,20))
            gui.button(w,'コマンドを反映').invoke()
        self.root.after(180,lambda:self.stage(select));editor.list.add('DIMEDIT');self.root.update()
        self.assertEqual([c['type'] for c in editor.list.commands],['DIMLINEAR','SELECT','DIMEDIT'])
        editor.list.undo();self.root.update();self.assertEqual(editor.list.commands,before)
        editor.list.redo();self.root.update();self.assertEqual(len(editor.list.commands),3)
        editor.win.destroy();self.assertFalse(self.messages)

if __name__=='__main__':unittest.main()
