"""Point capture and command acceptance use separate Enter presses."""
import copy
import os
from pathlib import Path
import sys
import tkinter as tk
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui
from macro_editor import edit_command, MacroEditor
from engine import compile_project
from block_model import new_block


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform == 'win32', 'GUI unavailable')
class EnterConfirm(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def edit(self, inspect, kind='LINE', prior=None, creating=True, **options):
        def run():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                win.refresh_command_preview(); self.root.update()
                inspect(win)
            except Exception as exc:
                self.errors.append(exc)
            finally:
                if win.winfo_exists(): win.destroy()
        self.root.after(150, run)
        return edit_command(self.root, dict(type=kind), self.app.data['blocks'], self.app.data,
                            point_sources=prior or [], creating=creating, **options)

    def click(self, canvas, point):
        x, y = canvas.screen_point(point)
        canvas.event_generate('<ButtonPress-1>', x=round(x), y=round(y))
        canvas.event_generate('<ButtonRelease-1>', x=round(x), y=round(y))
        self.root.update()

    def enter(self, widget, key='Return', *, release=True, state=0):
        widget.focus_force(); self.root.update()
        widget.event_generate('<KeyPress-'+key+'>', state=state)
        self.root.update()
        if release and widget.winfo_exists():
            widget.event_generate('<KeyRelease-'+key+'>', state=state)
            self.root.update()

    def check_path(self, kind, key):
        before = copy.deepcopy(self.app.data)
        def inspect(win):
            canvas = win.command_preview.canvas
            for point in ((10, 10), (60, 30), (80, 60)): self.click(canvas, point)
            self.assertTrue(win.preview_input.capturing)
            self.enter(canvas, key)
            self.assertTrue(win.winfo_exists())
            self.assertFalse(win.preview_input.capturing)
            self.assertIn('Enter', win.preview_input.message.get())
            self.assertEqual(self.app.data, before)
            self.enter(canvas, key)
            self.assertFalse(win.winfo_exists())
        result = self.edit(inspect, kind=kind, allow_continue=True)
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
        result = result[0]
        self.assertEqual(result['type'], kind)
        self.assertEqual(len(result['vertices']), 3)
        p = copy.deepcopy(self.app.data); p['blocks']=[dict(p['blocks'][0], commands=[result])]
        self.assertEqual(len(compile_project(p, [0])[1]), 1)

    def test_line_two_enters_accept_three_clicked_vertices(self):
        self.check_path('LINE', 'Return')

    def test_polyline_keypad_enters_accept_three_clicked_vertices(self):
        self.check_path('POLYLINE', 'KP_Enter')

    def test_insufficient_points_never_accept_defaults(self):
        def inspect(win):
            c = win.command_preview.canvas
            self.enter(c); self.enter(c)
            self.assertTrue(win.preview_input.capturing)
            self.click(c, (10, 10)); self.enter(c); self.enter(c)
            self.assertTrue(win.winfo_exists())
            self.assertTrue(win.preview_input.capturing)
            self.click(c, (80, 50)); self.enter(c); self.enter(c)
        self.assertIsNotNone(self.edit(inspect))

    def test_repeat_press_without_release_does_not_accept(self):
        def inspect(win):
            c = win.command_preview.canvas
            self.click(c, (10, 10)); self.click(c, (80, 50))
            self.enter(c, release=False)
            self.assertFalse(win.preview_input.capturing)
            # Same focused widget and no key release: simulate Windows repeat.
            c.event_generate('<KeyPress-Return>'); self.root.update()
            self.assertTrue(win.winfo_exists())
            c.event_generate('<KeyRelease-Return>'); self.root.update()
            self.enter(c)
        self.assertIsNotNone(self.edit(inspect))

    def test_two_enters_preserve_snapped_point_references(self):
        prior = [dict(type='LINE', x1='-20', y1='0', x2='100', y2='0'),
                 dict(type='CIRCLE', x='30', y='30', r='5')]
        def inspect(win):
            c = win.command_preview.canvas
            self.click(c, (-20, 0)); self.click(c, (30, 30))
            self.enter(c); self.enter(c)
        result = self.edit(inspect, prior=prior)
        for vertex in result['vertices']:
            self.assertIn('点(', vertex['x']); self.assertIn('点(', vertex['y'])
        prior[0]['x1']='-40'; prior[1]['x']='60'
        p = copy.deepcopy(self.app.data); p['blocks']=[dict(p['blocks'][0], commands=prior+[result])]
        self.assertEqual(compile_project(p, [0])[1][-1]['coords'], (-40., 0., 60., 30.))

    def test_numeric_entry_enter_does_not_commit_and_numlock_enter_works(self):
        def inspect(win):
            c = win.command_preview.canvas
            self.click(c, (10, 10)); self.click(c, (40, 10))
            self.assertFalse(win.preview_input.capturing)
            entry = win.preview_input.compact_entries['r']
            entry.delete(0, 'end'); entry.insert(0, '17')
            self.enter(entry)
            self.assertTrue(win.winfo_exists())
            win.preview_confirmation.windowing_system = 'win32'
            self.enter(c, state=0x8)
        result = self.edit(inspect, kind='CIRCLE')
        self.assertEqual(result['r'], '17')

    def test_multiline_text_enter_inserts_newline_without_accepting(self):
        def inspect(win):
            text = win.preview_input.compact_entries['text']
            self.assertIsInstance(text, tk.Text)
            text.delete('1.0', 'end'); text.insert('1.0', '注記')
            text.mark_set('insert', 'end-1c')
            self.enter(text)
            self.assertTrue(win.winfo_exists())
            self.assertTrue(text.get('1.0', 'end-1c').endswith('\n'))
            gui.button(win, 'キャンセル').invoke()
        self.assertIsNone(self.edit(inspect, kind='MTEXT', creating=False))

    def test_cancel_after_first_enter_does_not_add_command(self):
        before = copy.deepcopy(self.app.data)
        def inspect(win):
            c = win.command_preview.canvas
            self.click(c, (10, 10)); self.click(c, (80, 50)); self.enter(c)
            gui.button(win, 'キャンセル').invoke()
        self.assertIsNone(self.edit(inspect))
        self.assertEqual(self.app.data, before)

    def test_block_add_accepts_on_second_enter_and_block_save_is_undoable(self):
        project = copy.deepcopy(self.app.data)
        project['blocks'] = [new_block('作図', commands=[])]
        self.app.replace_document(project); self.root.update()
        before = copy.deepcopy(self.app.data)
        editor = MacroEditor(self.root, self.app.data['blocks'][0], self.app.data['blocks'],
                             self.app.refresh, self.app.data, [0])
        self.root.update()
        def run():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                c = win.command_preview.canvas
                a = c.world_point(c.winfo_width()*.2, c.winfo_height()*.25)
                b = c.world_point(c.winfo_width()*.7, c.winfo_height()*.7)
                self.click(c, a); self.click(c, b)
                self.enter(c)
                self.assertEqual(editor.list.commands, [])
                self.assertEqual(self.app.data, before)
                self.enter(c)
            except Exception as exc:
                self.errors.append(exc)
            finally:
                if win.winfo_exists(): win.destroy()
        self.root.after(180, run)
        editor.list.add('LINE'); self.root.update()
        self.assertEqual(len(editor.list.commands), 1)
        self.assertEqual(self.app.data, before)
        editor.save(); self.root.update()
        self.assertEqual(self.app.data['blocks'][0]['commands'][0]['type'], 'LINE')
        self.app.undo_project(); self.root.update()
        self.assertEqual(self.app.data, before)
