"""The linking workflow selects a target and source before committing changes."""
import copy,sys,os,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
import test_gui_link_assistance as link_gui
from link_assistance_ui import LinkAssistanceWindow

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI unavailable')
class LinkWorkflow(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 prepare=link_gui.LinkAssistanceGui.prepare
 def open(self,address=None):
  self.prepare();w=LinkAssistanceWindow(self.app,address);self.root.update();return w
 def click(self,c,point):
  x,y=c.screen_point(point);c.event_generate('<ButtonPress-1>',x=round(x),y=round(y));c.event_generate('<ButtonRelease-1>',x=round(x),y=round(y));self.root.update()
 def test_start_has_no_automatic_target_and_details_are_collapsed(self):
  w=self.open();before=copy.deepcopy(self.app.data)
  self.assertIsNone(w.address);self.assertIsNone(w.trial);self.assertTrue(w.apply_button.instate(['disabled']));self.assertIn('①',w.step_message.get())
  for panel in (w.command_list_area,w.details_area,w.table_area):self.assertFalse(panel.winfo_ismapped())
  self.assertFalse(w.show_status.get());self.assertEqual(self.app.data,before);w.close()
 def test_preview_target_column_summary_then_apply_and_undo(self):
  w=self.open();before=copy.deepcopy(self.app.data);self.click(w.canvas,(50,50))
  self.assertEqual(w.address,('blocks',0,'commands',1))
  w.field_picker.current(next(i for i,f in enumerate(w.target_fields) if f.path==('r',)));w.target_changed();self.root.update()
  self.assertEqual(w.candidate_tree.item('0','values')[2],'÷ 2して使う')
  w.candidate_tree.selection_set('0');w.candidate_selected();self.root.update()
  self.assertEqual(self.app.data,before);self.assertIn('③',w.step_message.get());self.assertIn('変更前：50',w.proposal_label.cget('text'));self.assertIn('変更後：',w.proposal_label.cget('text'))
  gui.button(w,'この紐付けを適用').invoke();self.root.update();self.assertIn('@外径',self.app.data['blocks'][0]['commands'][1]['r'])
  w.undo();self.root.update();self.assertEqual(self.app.data,before);w.close()
 def test_point_source_requires_explicit_point_and_can_reselect_target(self):
  w=self.open(('blocks',0,'commands',2));before=copy.deepcopy(self.app.data)
  w.mode.set('コマンドの点');w.mode_changed();self.root.update();self.assertFalse(w.candidate_card.winfo_ismapped())
  w.source_picker.current(0);w.source_selected();self.root.update();self.assertEqual(w.point_name.get(),'');self.assertIsNone(w.trial);self.assertTrue(w.apply_button.instate(['disabled']))
  self.click(w.canvas,(0,0));self.assertEqual(w.point_name.get(),'始点');self.assertIsNotNone(w.trial);self.assertEqual(self.app.data,before)
  w.choose_target_button.invoke();self.click(w.canvas,(50,50));self.assertEqual(w.address,('blocks',0,'commands',1));self.assertIsNone(w.trial);w.close()
 def test_foldouts_and_small_window_keep_apply_accessible(self):
  w=self.open(('blocks',0,'commands',1));w.geometry('1100x740');self.root.update()
  self.assertLess(w.target_section.winfo_rooty(),w.source_section.winfo_rooty())
  w.field_picker.current(next(i for i,f in enumerate(w.target_fields) if f.path==('r',)));w.target_changed()
  w.candidate_tree.selection_set('0');w.candidate_selected();self.root.update()
  summary=w.proposal_label
  self.assertGreaterEqual(summary.winfo_rooty(),w.winfo_rooty())
  self.assertLessEqual(summary.winfo_rooty()+summary.winfo_height(),w.apply_button.winfo_rooty())
  w.left_scroller.yview_moveto(1);self.root.update()
  self.assertLessEqual(summary.winfo_rooty()+summary.winfo_height(),w.apply_button.winfo_rooty())
  w.toggle_commands();w.toggle_details();w.toggle_columns();self.root.update()
  for panel in (w.command_list_area,w.details_area,w.table_area):self.assertTrue(panel.winfo_ismapped())
  b=w.apply_button;self.assertGreaterEqual(b.winfo_rootx(),w.winfo_rootx());self.assertLessEqual(b.winfo_rootx()+b.winfo_width(),w.winfo_rootx()+w.winfo_width());self.assertLessEqual(b.winfo_rooty()+b.winfo_height(),w.winfo_rooty()+w.winfo_height())
  w.mode.set('コマンドの点');w.mode_changed();self.root.update();self.assertFalse(w.table_area.winfo_ismapped());w.toggle_point_matches();self.root.update();self.assertTrue(w.candidate_card.winfo_ismapped());w.close()
