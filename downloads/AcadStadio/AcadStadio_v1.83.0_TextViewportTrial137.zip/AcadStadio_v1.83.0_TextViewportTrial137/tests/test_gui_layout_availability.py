import os,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import CommandList
@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class LayoutAvailabilityGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_model_direct_add_rejected_before_opening_editor(self):
  blocks=[dict(id='owner',name='モデル',drawing_space='Model',commands=[])]
  listing=CommandList(self.root,[],blocks,project=self.app.data,owner_block_id='owner')
  listing.add('VIEWPORT');listing.add('LAYOUT')
  self.assertEqual(listing.commands,[])
  self.assertTrue(listing.space_creation_reason('VIEWPORT'))
  listing.space_provider=lambda:'A4'
  self.assertFalse(listing.space_creation_reason('VIEWPORT'))

 def test_viewport_button_disabled_only_for_model_and_layout_not_listed(self):
  listing=CommandList(self.root,[],[dict(id='owner',name='モデル',drawing_space='Model',commands=[])],project=self.app.data,owner_block_id='owner')
  for space,disabled in [('Model',True),('A4',False)]:
   listing.space_provider=lambda value=space:value
   def inspect(disabled=disabled):
    w=gui.top(self.root,'追加するコマンド')
    try:
     gui.button(w,'線・形状').invoke();self.root.update()
     button=gui.button(w,'VIEWPORT')
     self.assertEqual(button.instate(['disabled']),disabled)
     self.assertFalse(any(str(x.cget('text')).startswith('LAYOUT') for x in gui.descendants(w) if x.winfo_class()=='TButton'))
    except Exception as exc:self.errors.append(exc)
    finally:w.destroy()
   self.root.after(100,inspect);listing.choose_add()
