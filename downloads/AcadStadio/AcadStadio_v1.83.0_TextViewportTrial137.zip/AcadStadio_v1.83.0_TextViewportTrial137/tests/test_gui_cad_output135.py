"""Real-Tk regression: batch block deletion and imported CAD setup flags."""
import copy
import os
import sys
import unittest
from unittest.mock import patch
from tkinter import ttk
import ezdxf
import test_gui as gui
from block_model import new_block
from cad_drawing_import import extract_drawing


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CadOutputGui135(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def install(self):
        p=copy.deepcopy(self.app.data)
        p['blocks']=[new_block(name,commands=[dict(type='POINT',x=str(i*10),y='0')]) for i,name in enumerate(('A','B','C'))]
        self.app.replace_document(p);self.root.update()
        return copy.deepcopy(self.app.data)

    def test_batch_delete_non_adjacent_selection_is_atomic_and_undoable(self):
        before=self.install()
        removed={before['blocks'][i]['id'] for i in (0,2)}
        self.app.block_browser.hidden_preview_ids.update(removed)
        self.app.block_list.selection_set('0','2')
        with patch('tkinter.messagebox.askyesno',return_value=True) as confirm:self.app.del_block()
        self.root.update()
        self.assertIn('2件',confirm.call_args.args[1])
        self.assertEqual([b['name'] for b in self.app.data['blocks']],['B'])
        self.assertTrue(removed.isdisjoint(self.app.block_browser.hidden_preview_ids))
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,before)
        self.app.redo_project();self.root.update();self.assertEqual([b['name'] for b in self.app.data['blocks']],['B'])
        self.assertFalse(self.messages)

    def test_batch_delete_cancel_and_no_selection_preserve_document(self):
        before=self.install();self.app.block_list.selection_set('0','1','2')
        with patch('tkinter.messagebox.askyesno',return_value=False):self.app.del_block()
        self.assertEqual(self.app.data,before)
        self.app.block_list.selection_remove(*self.app.block_list.selection())
        with patch('tkinter.messagebox.askyesno') as confirm:self.app.del_block()
        confirm.assert_not_called();self.assertEqual(self.app.data,before)

    def test_imported_bigfont_checkbox_and_dimension_fields_roundtrip(self):
        doc=ezdxf.new(setup=True)
        doc.styles.new('日本語',dxfattribs=dict(font='txt.shx',bigfont='extfont2.shx'))
        dim=doc.dimstyles.new('入力寸法',dxfattribs=dict(dimpost='%%C<>',dimtih=1,dimtoh=1,dimtolj=2))
        dim.set_arrows(blk='OPEN')
        doc.modelspace().add_line((0,0),(10,0))
        self.app.data['cad_setup']=extract_drawing(doc)['cad_setup'];self.app.refresh()
        editor=self.app.edit_cad_setup();self.root.update()
        tree,variables=editor.forms['text_styles']
        index=next(i for i,r in enumerate(editor.data['text_styles']) if r['name']=='日本語')
        tree.selection_set(str(index));editor.select('text_styles')
        self.assertIs(variables['use_bigfont'].get(),True)
        self.assertEqual(variables['bigfont'].get(),'extfont2.shx')
        notebook=next(w for w in gui.descendants(editor.win) if isinstance(w,ttk.Notebook))
        editor.win.geometry('820x650');notebook.select(3);self.root.update()
        tree,variables=editor.forms['dim_styles']
        index=next(i for i,r in enumerate(editor.data['dim_styles']) if r['name']=='入力寸法')
        tree.selection_set(str(index));editor.select('dim_styles')
        self.assertEqual(variables['dimblk'].get(),'_OPEN');self.assertEqual(variables['dimpost'].get(),'%%C<>')
        self.assertEqual(variables['dimtolj'].get(),'2');self.assertEqual(variables['dimtih'].get(),'1')
        variables['dimtoh'].set('0');self.assertTrue(editor.upsert('dim_styles'))
        self.root.update()
        self.assertGreaterEqual(tree.winfo_height(),88)
        self.assertTrue(tree.bbox(str(index)))
        gui.button(editor.win,'設定を確定').invoke();self.root.update()
        row=next(r for r in self.app.data['cad_setup']['dim_styles'] if r['name']=='入力寸法')
        self.assertEqual(row['dimtoh'],'0');self.assertFalse(self.messages)

if __name__=='__main__':unittest.main()
