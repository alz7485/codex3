import sys,math,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from circle_angle_input import angle_pick
from engine import evaluate,MacroError
from command_points import reference
class CircleAngle(unittest.TestCase):
 def test_angle_expression_is_preserved_and_uses_world_axes(self):
  pick=dict(source=dict(type='CIRCLE',coords=(10,20,5)),curve_angle=45)
  result=angle_pick(pick,'@A',{'__row__':{'A':90}},evaluate)
  self.assertEqual(result['curve_angle'],'@A');self.assertAlmostEqual(result['xy'][0],10);self.assertAlmostEqual(result['xy'][1],25);self.assertEqual(pick['curve_angle'],45);self.assertAlmostEqual(float(result['y']),25)
  for angle,expected in [('-90',(10,15)),('450',(10,25)),('360',(15,20))]:
   p=angle_pick(pick,angle,{},evaluate);self.assertAlmostEqual(p['xy'][0],expected[0]);self.assertAlmostEqual(p['xy'][1],expected[1])
 def test_invalid_angle_does_not_mutate(self):
  p=dict(source=dict(type='CIRCLE',coords=(0,0,10)),curve_angle=45)
  for expr in ('True','"text"','2*'):
   with self.assertRaises((ValueError,MacroError)):angle_pick(p,expr,{},evaluate)
  self.assertEqual(p['curve_angle'],45)
