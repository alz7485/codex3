"""Adding a variable creates an editable row and never discards pending input."""
import copy
import os
from pathlib import Path
import sys
import tkinter as tk
from tkinter import ttk
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui
from main import EMPTY
from variable_editor import VariableEditor
from block_model import new_block
from engine import compile_project


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform == 'win32', 'GUI unavailable')
class VariablesGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def open(self, values=None):
        ed = VariableEditor(self.app, self.app.data['globals'] if values is None else values)
        self.root.update()
        return ed

    def set_entry(self, entry, value):
        entry.delete(0, 'end'); entry.insert(0, value)

    def test_plus_click_immediately_adds_unique_row_without_clearing_edits(self):
        ed = self.open({'新しい変数1': '10'})
        before = copy.deepcopy(self.app.data)
        button = ed.add_button
        for _ in range(2):
            button.event_generate('<Enter>')
            button.event_generate('<ButtonPress-1>', x=8, y=8)
            button.event_generate('<ButtonRelease-1>', x=8, y=8)
            self.root.update()
        self.assertEqual([r['name'].get() for r in ed.rows], ['新しい変数1', '新しい変数2', '新しい変数3'])
        self.set_entry(ed.rows[1]['value_entry'], '25 * 2')
        ed.add_button.invoke(); self.root.update()
        self.assertEqual(len(ed.rows), 4)
        self.assertEqual(ed.rows[1]['expression'].get(), '25 * 2')
        self.assertEqual(ed.rows[0]['expression'].get(), '10')
        self.assertEqual(self.app.data, before)
        ed.cancel()

    def test_empty_project_adds_and_evaluates_constant_without_input_rows(self):
        self.app.replace_document(EMPTY); self.root.update()
        ed = self.open(); self.assertTrue(ed.empty.winfo_ismapped())
        ed.add_button.invoke(); self.root.update(); ed.refresh()
        self.assertEqual(ed.rows[0]['expression'].get(), '0')
        self.assertEqual(ed.rows[0]['feedback'].cget('text'), '0')
        ed.commit(); self.assertEqual(ed.result, {'新しい変数1': '0'})

    def test_apply_commits_direct_cell_edit_and_addition_as_one_undoable_change(self):
        p = copy.deepcopy(self.app.data)
        p['globals'] = {'半径': '10'}
        p['blocks'] = [new_block('円', commands=[dict(type='CIRCLE', x='0', y='0', r='変数.半径')])]
        self.app.replace_document(p); self.root.update()
        before = copy.deepcopy(self.app.data)
        def run():
            win = gui.top(self.root, '変数'); ed = win.variable_editor
            try:
                self.set_entry(ed.rows[0]['value_entry'], '@OD / 2')
                ed.add_button.invoke(); self.root.update()
                self.set_entry(ed.rows[-1]['name_entry'], '注記')
                self.set_entry(ed.rows[-1]['value_entry'], '"フランジ"')
                ed.apply_button.invoke()
            except Exception as exc:
                self.errors.append(exc); win.destroy()
        self.root.after(120, run); self.app.edit_globals(); self.root.update()
        self.assertEqual(self.app.data['globals'], {'半径': '@OD / 2', '注記': '"フランジ"'})
        self.assertEqual(compile_project(self.app.data, [0])[1][0]['coords'][2], 50)
        self.app.undo_project(); self.root.update(); self.assertEqual(self.app.data, before)
        self.app.redo_project(); self.root.update()
        self.assertEqual(self.app.data['globals']['注記'], '"フランジ"')

    def test_cancel_discards_add_edit_and_delete(self):
        before = copy.deepcopy(self.app.data)
        def run():
            win = gui.top(self.root, '変数'); ed = win.variable_editor
            try:
                ed.rows[0]['expression'].set('123')
                ed.add_button.invoke(); self.root.update()
                ed.rows[0]['delete_button'].invoke()
                gui.button(win, 'キャンセル').invoke()
            except Exception as exc:
                self.errors.append(exc); win.destroy()
        self.root.after(120, run); self.app.edit_globals(); self.root.update()
        self.assertEqual(self.app.data, before)

    def test_duplicate_invalid_name_and_bad_expression_stay_inline(self):
        ed = self.open({'尺度': '1'}); row = ed.add()
        for name, expression, expected in [('尺度', '0', '重複'), ('1不正', '0', '名前'), ('追加', '2 *', '構文')]:
            row['name'].set(name); row['expression'].set(expression)
            ed.commit(); self.root.update()
            self.assertTrue(ed.win.winfo_exists())
            self.assertIn(expected, ed.status.get())
            self.assertIsNone(ed.result)
        row['expression'].set('2 * 3'); ed.commit()
        self.assertEqual(ed.result, {'尺度': '1', '追加': '2 * 3'})
        self.assertEqual(self.messages, [])

    def test_reference_menu_uses_current_draft_names_and_calculates(self):
        ed = self.open({'尺度': '3', '長さ': '0'}); row = ed.rows[1]
        ed.reference_menu(row)
        index = next(i for i in range(row['menu'].index('end')+1)
                     if row['menu'].type(i) == 'command' and row['menu'].entrycget(i, 'label') == '変数.尺度')
        row['menu'].invoke(index); ed.refresh()
        self.assertEqual(row['expression'].get(), '変数.尺度')
        self.assertEqual(row['feedback'].cget('text'), '3')
        ed.cancel()

    def test_table_reference_picker_restores_grab_and_does_not_edit_table(self):
        before = copy.deepcopy(self.app.data)
        ed = self.open({'半径': '0'}); row = ed.rows[0]
        def choose():
            win = gui.top(self.root, '表から参照を選ぶ')
            try:
                tree = next(w for w in gui.descendants(win) if isinstance(w, ttk.Treeview))
                self.root.update()
                x, y, width, height = tree.bbox('0', 'OD')
                tree.event_generate('<ButtonRelease-1>', x=x+width//2, y=y+height//2)
                gui.button(win, 'この参照を挿入').invoke()
            except Exception as exc:
                self.errors.append(exc); win.destroy()
        self.root.after(100, choose); ed.table_reference(row); self.root.update(); ed.refresh()
        self.assertIn('@OD', row['expression'].get())
        self.assertEqual(row['feedback'].cget('text'), '100')
        self.assertIs(self.root.grab_current(), ed.win)
        self.assertEqual(self.app.data, before)
        ed.cancel()

    def test_many_rows_scroll_and_footer_fits_minimum_size(self):
        ed = self.open({f'変数{i}': str(i) for i in range(40)})
        ed.win.geometry('760x440'); self.root.update()
        last = ed.add(); self.root.update()
        self.assertGreater(ed.canvas.yview()[0], 0)
        for widget in (last['name_entry'], last['value_entry'], last['delete_button'], ed.apply_button):
            self.assertTrue(widget.winfo_ismapped())
            self.assertLessEqual(widget.winfo_rootx()+widget.winfo_width(), ed.win.winfo_rootx()+ed.win.winfo_width())
            self.assertLessEqual(widget.winfo_rooty()+widget.winfo_height(), ed.win.winfo_rooty()+ed.win.winfo_height())
        ed.cancel()

    def test_stale_project_cannot_be_overwritten_and_pending_job_is_cancelled(self):
        ed = self.open(); ed.add()
        self.app.data['globals']['別の変更'] = '2'
        ed.commit(); self.assertIsNone(ed.result)
        self.assertIn('プロジェクトが変更', ed.status.get())
        ed.rows[0]['expression'].set('7')
        self.assertIsNotNone(ed.job)
        ed.cancel(); self.root.update()
        self.assertIsNone(ed.job)
        self.assertEqual(self.app.data['globals']['別の変更'], '2')

    def test_pending_table_cell_is_used_for_confirmation_value(self):
        before = copy.deepcopy(self.app.data['globals'])
        self.app.show_input_table(); self.root.update()
        editor = self.app.table_editor
        editor.begin(cell=(0, editor.keys().index('OD')))
        self.set_entry(editor.entry, '144')
        def run():
            win = gui.top(self.root, '変数'); ed = win.variable_editor
            try:
                row = ed.add(); row['expression'].set('@OD'); ed.refresh()
                self.assertEqual(row['feedback'].cget('text'), '144')
                ed.cancel()
            except Exception as exc:
                self.errors.append(exc); win.destroy()
        self.root.after(120, run); self.app.edit_globals(); self.root.update()
        self.assertEqual(self.app.rows[0]['OD'], '144')
        self.assertEqual(self.app.data['globals'], before)
