"""Category menus invoke real forms and new native shapes remain selectable."""
import copy
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import MacroEditor, TYPE_LABELS
from command_types import COMMAND_GROUPS
from engine import compile_project
from test_extended_drawing import COMMANDS

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CommandGroupsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_category_menus_and_all_actions_fit_in_one_row(self):
        ed=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0])
        self.root.update()
        controls=ed.list.toolbar.winfo_children()
        self.assertEqual(len(controls),9)
        self.assertEqual(controls[0].cget('text'),'＋ コマンド追加')
        def inspect():
            palette=gui.top(self.root,'追加するコマンド')
            for label,kinds in COMMAND_GROUPS:
                gui.button(palette,label.replace('を追加 ▾','')).invoke();self.root.update()
                for kind in kinds:self.assertTrue(gui.button(palette,TYPE_LABELS[kind]).winfo_ismapped())
            gui.button(palette,'キャンセル').invoke()
        self.root.after(50,inspect);controls[0].invoke()
        for geometry in ('1160x780','850x640'):
            ed.win.geometry(geometry);self.root.update()
            ed.command_panes.sashpos(0,320);self.root.update()
            self.assertEqual(len({w.winfo_y() for w in controls}),1)
            self.assertTrue(all(w.winfo_ismapped() and w.winfo_x()+w.winfo_width()<=ed.list.toolbar.winfo_width() for w in controls))
        ed.win.destroy()

    def test_menu_adds_each_new_command_and_undo_redo_remains_transactional(self):
        ed=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update()
        before=copy.deepcopy(self.app.data)
        for command in COMMANDS:
            kind=command['type']
            def choose(kind=kind):
                palette=gui.top(self.root,'追加するコマンド')
                category=next(label for label,kinds in COMMAND_GROUPS if kind in kinds)
                gui.button(palette,category.replace('を追加 ▾','')).invoke()
                self.root.after(50,lambda:(w:=gui.top(self.root,'コマンドの設定'),w.preview_input.show_details(),gui.button(w,'コマンドを反映').invoke()))
                gui.button(palette,TYPE_LABELS[kind]).invoke()
            self.root.after(50,choose);ed.list.choose_add();self.root.update()
            self.assertEqual(ed.list.commands[-1]['type'],kind)
            ed.list.undo();ed.list.redo();self.root.update()
            self.assertEqual(ed.list.commands[-1]['type'],kind)
            ed.list.tree.selection_remove(ed.list.tree.selection())
        self.assertEqual(self.app.data,before)
        ed.win.destroy()

    def test_extended_geometry_preview_fit_zoom_and_highlight(self):
        project=copy.deepcopy(self.app.data)
        project['blocks']=[dict(project['blocks'][0],commands=copy.deepcopy(COMMANDS))]
        script,items=compile_project(project,[0])
        self.app.canvas.set_items(items);self.root.update();self.app.canvas.fit()
        self.assertEqual(len(self.app.canvas.items),7)
        self.assertTrue(any(self.app.canvas.type(n)=='arc' for n,_,_ in self.app.canvas.geometry))
        self.assertTrue(any(item.get('text')=='R10' and self.app.canvas.type(n)=='image'
                            for n,item,_ in self.app.canvas._text_nodes))
        self.app.canvas.zoom(SimpleNamespace(x=150,y=150,delta=120),1.5)
        self.app.canvas.highlight([0],0)
        self.assertEqual(compile_project(project,[0])[0],script)

    def test_centerline_dash_survives_zoom_and_cad_editor_save(self):
        self.app.canvas.fit();self.root.update()
        center=[(n,i) for n,i,_ in self.app.canvas.geometry if i['layer']=='CENTER']
        self.assertGreater(len(center),4)
        self.assertTrue(all('cad-dash' in self.app.canvas.gettags(n) for n,_ in center))
        node,item=center[0];pattern=self.app.canvas.linetype_dash(item)
        self.assertEqual(len(pattern),4);self.assertGreater(pattern[0],pattern[2])
        self.app.canvas.zoom(SimpleNamespace(x=150,y=150,delta=120),1.5)
        changed=self.app.canvas.linetype_dash(item)
        self.assertGreater(changed[0],pattern[0])
        self.assertTrue(self.app.canvas.find_withtag('cad-dash'))
        editor=self.app.edit_cad_setup();self.root.update()
        self.assertFalse(editor.data['linetypes'][0]['existing_only'])
        self.assertEqual(editor.data['linetypes'][0]['builtin'],'CENTER')
        gui.button(editor.win,'設定を確定').invoke();self.root.update()
        self.assertIn('Center ____',self.app.compile()[0])
