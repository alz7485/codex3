"""Compact candidate list; selection previews, explicit acceptance commits."""
import tkinter as tk
from tkinter import ttk

class PointCandidatePopup(tk.Toplevel):
    def __init__(self,canvas,candidates,event,on_use):
        owner=canvas.winfo_toplevel();super().__init__(owner)
        self.transient(owner);self.title('参照点を選択');self.canvas=canvas;self.candidates=candidates
        self.old_source=canvas.source_index;self.old_related=set(getattr(canvas,'related_source_indices',set()))
        self.old_points=dict(canvas.snap_points);self.old_point=canvas.selected_point;self.old_shift=canvas.shifted_point
        self.previous_grab=self.grab_current();self.grab_set()
        ttk.Label(self,text='重なる参照点があります。候補を選ぶと図形を強調します。',padding=(10,8)).pack(anchor='w')
        self.list=ttk.Treeview(self,columns=('kind','name'),show='headings',height=min(7,len(candidates)),selectmode='browse')
        self.list.heading('kind',text='種類');self.list.heading('name',text='参照元と点')
        self.list.column('kind',width=115,stretch=False);self.list.column('name',width=445)
        self.list.pack(fill='both',expand=True,padx=10)
        for i,item in enumerate(candidates):self.list.insert('','end',iid=str(i),values=('コマンドの点' if item['kind']=='point' else '2コマンドの交点',item['label']))
        bar=ttk.Frame(self,padding=10);bar.pack(fill='x')
        ttk.Button(bar,text='キャンセル',command=self.close).pack(side='left')
        def use(event=None):
            if not self.list.selection():return
            candidate=candidates[int(self.list.selection()[0])];self.close();on_use(candidate)
            return 'break'
        ttk.Button(bar,text='この候補を選択',command=use,style='Primary.TButton').pack(side='right')
        def selected(event=None):
            if not self.list.selection():return
            candidate=candidates[int(self.list.selection()[0])]
            canvas.source_index=candidate['primary'];canvas.related_source_indices={candidate['secondary']} if candidate['kind']=='intersection' else set()
            from command_points import geometry_points
            primary=next((i for i in canvas.items if canvas.item_source_index(i)==candidate['primary']),None)
            canvas.snap_points={'交点':candidate['position']} if candidate['kind']=='intersection' else geometry_points(primary) if primary else {}
            canvas.selected_point='交点' if candidate['kind']=='intersection' else candidate['point'];canvas.shifted_point=None
            canvas.recolor()
        self.list.bind('<<TreeviewSelect>>',selected)
        self.list.bind('<Double-1>',use);self.bind('<Return>',use);self.bind('<Escape>',lambda e:self.close())
        self.protocol('WM_DELETE_WINDOW',self.close)
        self.update_idletasks();w=max(570,self.winfo_reqwidth());h=self.winfo_reqheight()
        x=max(0,min(event.x_root+10,self.winfo_screenwidth()-w));y=max(0,min(event.y_root+10,self.winfo_screenheight()-h-40))
        self.geometry(f'{w}x{h}+{x}+{y}')
        self.list.selection_set('0');selected();self.list.focus_set()
    def close(self):
        if not self.winfo_exists():return
        canvas=self.canvas
        try:
            canvas.source_index=self.old_source;canvas.related_source_indices=self.old_related
            canvas.snap_points=self.old_points;canvas.selected_point=self.old_point;canvas.shifted_point=self.old_shift;canvas.recolor()
            self.grab_release();self.destroy()
            if self.previous_grab is not None and self.previous_grab.winfo_exists():self.previous_grab.grab_set()
        except tk.TclError:pass
