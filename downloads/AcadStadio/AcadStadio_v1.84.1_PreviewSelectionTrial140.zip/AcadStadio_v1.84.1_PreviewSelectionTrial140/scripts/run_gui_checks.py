"""Run GUI files in isolated processes, with a timeout and retained logs."""
import argparse,json,os,re,subprocess,sys,tempfile,time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--files',nargs='+',help='Optional test_gui module names; default: all GUI files')
 parser.add_argument('--output',type=Path)
 parser.add_argument('--timeout',type=float,default=30)
 args=parser.parse_args()
 if sys.platform!='win32' and not os.environ.get('DISPLAY'):parser.error('GUI表示環境のDISPLAYが必要です')
 if args.timeout<=0:parser.error('timeout must be positive')
 available={p.stem for p in (ROOT/'tests').glob('test_gui*.py')}
 files=args.files if args.files else sorted(available)
 if set(files)-available:parser.error('Unknown GUI test module')
 output=args.output or Path(tempfile.mkdtemp(prefix='acadstadio-gui-'));output.mkdir(parents=True,exist_ok=True)
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
 env['PYTHONPATH']=os.pathsep.join([str(ROOT/'tests'),str(ROOT/'src'),env.get('PYTHONPATH','')])
 results=[]
 for name in files:
  started=time.monotonic()
  with (output/(name+'.log')).open('w',encoding='utf-8') as log:
   proc=subprocess.Popen([sys.executable,'-m','unittest',name,'-v'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
   try:code=proc.wait(timeout=args.timeout);status='PASS' if code==0 else 'FAIL'
   except subprocess.TimeoutExpired:proc.kill();proc.wait();code=None;status='TIMEOUT'
  content=(output/(name+'.log')).read_text(encoding='utf-8',errors='replace')
  counts=re.findall(r'^Ran (\d+) tests? in',content,re.M)
  results.append(dict(file=name,result=status,code=code,tests=int(counts[-1]) if counts else 0,seconds=round(time.monotonic()-started,2)))
  (output/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  print(name,status,flush=True)
 failed=[r['file'] for r in results if r['result']!='PASS']
 print(f'{len(results)} GUI files / {sum(r["tests"] for r in results)} tests; failed/timeouts: {failed}; logs: {output}')
 return 1 if failed else 0

if __name__=='__main__':raise SystemExit(main())
