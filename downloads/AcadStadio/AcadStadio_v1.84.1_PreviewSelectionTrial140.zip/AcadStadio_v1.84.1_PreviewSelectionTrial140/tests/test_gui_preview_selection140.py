"""Preview updates must be scheduled before expensive selection feedback."""
import os,time,unittest
from unittest.mock import patch
import test_gui as gui
import test_gui_linked_preview as linked

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI required')
class PreviewSelection140(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 settle=linked.LinkedPreviewGui.settle
 def test_clear_selection_updates_even_when_feedback_is_slow(self):
  app=self.app;app.show_input_table();self.root.update()
  app.table.selection_set('0','2');self.settle();app.preview(quiet=True)
  self.assertEqual({i['row'] for i in app.canvas.items},{0,2})
  before=app.compile()[0];original=app.update_drawing_summary
  def slow_feedback():
   original();time.sleep(.12)
  with patch.object(app,'update_drawing_summary',side_effect=slow_feedback):
   app.table.selection_remove(app.table.selection());self.settle()
  self.assertEqual({i['row'] for i in app.canvas.items},{0})
  self.assertEqual(app.target_rows(),[0]);self.assertEqual(app.compile()[0],before)

 def test_clear_selection_updates_even_when_highlighting_is_slow(self):
  app=self.app;app.show_input_table();self.root.update()
  app.table.selection_set('0','2');self.settle();app.preview(quiet=True)
  original=app.highlight_preview
  def slow_highlight(*args,**kwargs):
   original(*args,**kwargs);time.sleep(.12)
  with patch.object(app,'highlight_preview',side_effect=slow_highlight):
   app.table.selection_remove(app.table.selection());self.settle()
  self.assertEqual({i['row'] for i in app.canvas.items},{0})
  self.assertEqual(app.target_rows(),[0])
