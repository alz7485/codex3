# 1.83.1-beta138の検証

- コア全618件成功。関連GUI6ファイル・39件成功。スモーク成功。GUI全件の今回は再実行していません。
- 新規コア3件：新規作成と編集のZoomCenter API、WCSの3D中心点、枠高さ÷尺度、指定ビューポート番号、ActivePViewportの設定順、ロック復元、連続ビューポート作成後の線分出力を確認。
- 問題の両経路で対話ZOOM／MSPACEを出力しないこと、生成AutoLISPの括弧、通常の作成／編集1行が2048文字以下であることを確認。
- 関連GUI：test_gui_layout_commands（3）、test_gui_viewport_projection（2）、test_gui_layout_availability（2）、test_gui_preview_input（25）、test_gui_select_flow（5）、test_gui_text_viewport137（2）。すべて成功。
- 検証はLinux / Python 3.13 / Tkによる生成コードとGUI回帰です。AutoCAD実機で報告された停止を再現・実行したものではありません。
- Windows実操作・今回のAutoCAD上でのSCR実行・EXEビルドは未確認です。

```text
python scripts/run_checks.py --mode core
python -m unittest discover -s tests -p test_gui_layout_commands.py
python -m unittest discover -s tests -p test_gui_viewport_projection.py
python tests/smoke_test.py
```
