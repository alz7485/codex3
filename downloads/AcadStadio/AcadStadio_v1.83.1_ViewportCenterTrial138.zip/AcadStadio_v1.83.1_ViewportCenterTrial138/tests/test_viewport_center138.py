import unittest
from layout_commands import render
from test_cad_state import read_form,walk

class ViewportCenter138(unittest.TestCase):
 def source(self,action='矩形を作成',**extra):
  return '\n'.join(render(dict(type='VIEWPORT',viewport_action=action,x1='0',y1='0',x2='200',y2='100',view_x='120.5',view_y='-70',view_scale='0.02',configure_view=True,viewport_id='3',**extra),{},lambda v,c:str(v)))
 def test_creation_uses_wcs_api_center_and_model_height(self):
  s=self.source();read_form(s)
  self.assertIn('vla-ZoomCenter',s);self.assertIn('(list 120.5 -70 0.0)',s)
  self.assertIn('(/ (vla-get-Height object) 0.02)',s)
  self.assertNotIn('"_.ZOOM"',s);self.assertNotIn('"_.MSPACE"',s)
  self.assertLess(s.index('vla-put-ActivePViewport'),s.index('vla-ZoomCenter'))
  self.assertIn('(vla-put-MSpace doc :vlax-false)',s)
 def test_edit_uses_exact_viewport_number_and_restores_lock(self):
  s=self.source('表示中心・尺度');read_form(s)
  self.assertIn('(cons 69 3)',s);self.assertIn('vla-get-DisplayLocked',s)
  self.assertIn("vla-put-DisplayLocked (list object locked)",s)
  self.assertIn('vl-catch-all-error-p outcome',s);self.assertNotIn('"_Center"',s)
 def test_second_viewport_and_next_geometry_have_no_zoom_input(self):
  from test_layout_commands import LayoutCommands
  script,_=LayoutCommands().compile([dict(type='LAYOUT',layout_name='Sheet'),dict(type='VIEWPORT',x1='0',y1='0',x2='200',y2='100',configure_view=True,view_scale='.02'),dict(type='VIEWPORT',x1='210',y1='0',x2='410',y2='100',configure_view=True,view_scale='.01'),dict(type='LINE',x1='0',y1='0',x2='10',y2='10')])
  self.assertEqual(script.count('(vla-ZoomCenter '),2);self.assertIn('_.LINE',script)
  for line in script.splitlines():
   if line.startswith('('):read_form(line)
