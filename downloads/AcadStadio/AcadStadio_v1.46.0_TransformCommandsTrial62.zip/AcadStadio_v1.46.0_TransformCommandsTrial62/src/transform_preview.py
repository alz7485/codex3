"""Geometry-aware, non-destructive COPY/MIRROR previews."""
import copy
import math
from edit_preview import segments, distance


def general_distance(point,item):
    kind=item.get('display_type',item['type']);c=item['coords']
    basic=distance(point,item)
    if kind in ('CIRCLE','ARC','ELLIPSE','TEXT','INSERT','POINT'):
        basic=min(basic,math.dist(point,c[:2]))
    if kind=='ELLIPSE':
        a=math.radians(item.get('angle',0));dx,dy=point[0]-c[0],point[1]-c[1]
        x,y=dx*math.cos(a)+dy*math.sin(a),-dx*math.sin(a)+dy*math.cos(a)
        t=math.atan2(y/c[3],x/c[2]);q=(c[2]*math.cos(t),c[3]*math.sin(t))
        basic=min(basic,math.hypot(x-q[0],y-q[1]))
    if kind in ('HATCH','LEADER'):basic=min(math.dist(point,p) for p in zip(c[::2],c[1::2]))
    if kind=='SPLINE':basic=distance(point,dict(type='POLYLINE',coords=item.get('curve',c)))
    return basic


def transformed(item,source,tolerance):
    first=item['coords'][:2];base=item['coords'][2:4];end=item['coords'][4:6]
    kind=source.get('display_type',source['type']);original=copy.deepcopy(source)
    if kind=='LINE':
        matches=[line for line in segments(source) if distance(first,dict(type='LINE',coords=line))<=tolerance]
        if len(matches)!=1:return None
        original['coords']=matches[0];original.pop('segments',None)
    c=original['coords'];mirroring=item['type']=='MIRROR'
    axis=math.atan2(end[1]-base[1],end[0]-base[0]);cs,sn=math.cos(axis),math.sin(axis)
    def transform(p):
        if not mirroring:return (p[0]+end[0]-base[0],p[1]+end[1]-base[1])
        x,y=p[0]-base[0],p[1]-base[1];along=x*cs+y*sn
        return (base[0]+2*along*cs-x,base[1]+2*along*sn-y)
    flat=lambda values:tuple(z for p in zip(values[::2],values[1::2]) for z in transform(p))
    result={key:copy.deepcopy(value) for key,value in original.items() if key in ('layer','effective_layer','color','linetype','linetype_scale','closed','curve','text','height','angle','pattern','scale','start_angle','sweep')}
    result.update(display_type=kind,preview_note='',coords=())
    if kind in ('CIRCLE','ARC','ELLIPSE','TEXT'):
        result['coords']=(*transform(c[:2]),*c[2:])
    elif kind in ('POINT','INSERT'):
        result['coords']=transform(c[:2])
        if kind=='INSERT':result['preview_note']='コピー／ミラー：CADブロックの位置のみ'
    elif kind=='RECTANGLE':
        x,y,u,v=c;result.update(display_type='POLYLINE',closed=True,coords=flat((x,y,u,y,u,v,x,v)))
    elif kind in ('LINE','POLYLINE','SPLINE','HATCH','LEADER'):
        result['coords']=flat(c)
    else:return None
    if kind=='SPLINE':result.update(curve=flat(original.get('curve',c)),preview_note='スプライン：近似プレビュー')
    if mirroring:
        alpha=math.degrees(axis)
        if kind=='ARC':result['start_angle']=(2*alpha-original['start_angle']-original['sweep'])%360
        if kind=='ELLIPSE':result['angle']=(2*alpha-original.get('angle',0))%360
        if kind=='HATCH':result['angle']=(2*alpha-original.get('angle',0)-90)%360
        if kind=='TEXT':
            result['angle']=(2*alpha-original.get('angle',0))%360
            result['preview_note']='文字ミラー：概略表示（CADでは読める向きを維持）'
    if kind=='HATCH':result['preview_note']='ハッチング：境界・概略パターン'
    # Source properties are the default; only explicit command values override.
    for field in item.get('overrides',()):
        for key in (('layer','effective_layer') if field=='layer' else (field,)):
            if key in item:result[key]=item[key]
    return result


def apply_transform(item,items,tolerance):
    candidates=[s for s in items if not s.get('guide') and not s.get('operation_deleted') and general_distance(item['coords'][:2],s)<=tolerance]
    if len(candidates)!=1:return []
    source=candidates[0];geometry=transformed(item,source,tolerance)
    if geometry is None:return []
    for key in ('layer','effective_layer','color','linetype','linetype_scale'):
        if key not in geometry:item.pop(key,None)
    item.update(geometry)
    if item['type']=='MIRROR' and item.get('erase_source'):
        source['operation_deleted']=True
        return [source]
    return []
