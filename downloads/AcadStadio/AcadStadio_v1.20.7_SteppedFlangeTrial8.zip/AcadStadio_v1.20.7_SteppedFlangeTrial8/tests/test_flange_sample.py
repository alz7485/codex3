"""The plan, material section and hatch must agree when dimensions change."""

import copy
import json
import math
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from sample_project import EXAMPLE
from engine import compile_project
from project_model import normalize_project
from table_io import read_csv, read_excel, sheet_names
from audit import audit_project
from block_model import nested

ROOT = Path(__file__).resolve().parents[1]


class FlangeSample(unittest.TestCase):
    def test_sample_opens_one_row_and_has_two_views_without_local_variables(self):
        self.assertEqual(
            EXAMPLE["drawing"]["targets"][EXAMPLE["active_table"]]["selected"], [0]
        )
        self.assertEqual(audit_project(EXAMPLE), [])
        self.assertEqual(
            [b["name"] for b in EXAMPLE["blocks"][:2]], ["01 平面図", "02 断面図 A-A"]
        )
        for block in EXAMPLE["blocks"]:
            self.assertNotIn("variables", block)
            for command in nested(block["commands"]):
                self.assertNotIn(command["type"], ("BLOCK", "SET"))
                self.assertNotIn("local.", json.dumps(command))

    def test_dimensions_and_hatch_remain_inside_material(self):
        # The shoulder and plate must remain one continuous part when resized.
        cases = [copy.deepcopy(row) for row in EXAMPLE["input_tables"][0]["rows"]]
        cases.append(
            dict(
                cases[0],
                OD="160.5",
                ID="50.25",
                PCD="110",
                R="6.5",
                T="25.5",
                HUB_D="80.5",
                H="12.25",
            )
        )
        for row in cases:
            with self.subTest(row=row):
                project = copy.deepcopy(EXAMPLE)
                project["input_tables"][0]["rows"] = [row]
                script, items = compile_project(project, [0])
                x, y, od, bore, pcd, radius, thickness, hub, height = (
                    float(row[k])
                    for k in ("X", "Y", "OD", "ID", "PCD", "R", "T", "HUB_D", "H")
                )
                circles = [i for i in items if i["type"] == "CIRCLE"]
                self.assertEqual(len(circles), int(row["N"]) + 3)
                self.assertEqual(circles[0]["coords"], (x, y, od / 2))
                self.assertEqual(circles[1]["coords"], (x, y, bore / 2))
                self.assertIn((x, y, hub / 2), [i["coords"] for i in circles])
                holes = [i for i in circles if i["layer"] == "HOLES"]
                self.assertEqual(len(holes), int(row["N"]))
                for hole in holes:
                    hx, hy, hr = hole["coords"]
                    self.assertAlmostEqual(
                        math.hypot(hx - x, hy - y), pcd / 2, places=8
                    )
                    self.assertEqual(hr, radius)
                for sign in (-1, 1):
                    self.assertTrue(
                        any(
                            abs(i["coords"][0] - x) < 1e-8
                            and abs(i["coords"][1] - (y + sign * pcd / 2)) < 1e-8
                            for i in holes
                        )
                    )
                nose = x - od / 2 - float(project["settings"]["VIEW_GAP"])
                shoulder, rear = nose - height, nose - height - thickness
                bands = [
                    (y - od / 2, y - pcd / 2 - radius),
                    (y - pcd / 2 + radius, y - bore / 2),
                    (y + bore / 2, y + pcd / 2 - radius),
                    (y + pcd / 2 + radius, y + od / 2),
                ]
                material = [(rear, shoulder, low, high) for low, high in bands] + [
                    (shoulder, nose, y - hub / 2, y - bore / 2),
                    (shoulder, nose, y + bore / 2, y + hub / 2),
                ]
                rectangles = [i for i in items if i["type"] == "RECTANGLE"]
                self.assertEqual(
                    [i["coords"] for i in rectangles],
                    [
                        (rear, bands[0][0], shoulder, bands[0][1]),
                        (rear, bands[3][0], shoulder, bands[3][1]),
                    ],
                )
                contour = [
                    i
                    for i in items
                    if i["block_index"] == 1
                    and i["layer"] == "OUTLINE"
                    and i["type"] == "LINE"
                ]
                self.assertEqual(len(contour), 12)
                # A line across the join would falsely show separate joined parts.
                self.assertFalse(
                    any(
                        abs(i["coords"][0] - shoulder) < 1e-8
                        and abs(i["coords"][2] - shoulder) < 1e-8
                        and bore / 2
                        < abs((i["coords"][1] + i["coords"][3]) / 2 - y)
                        < hub / 2
                        for i in contour
                    )
                )
                hatch = [i for i in items if i["layer"] == "HATCH"]
                self.assertTrue(hatch)
                covered = set()
                for item in hatch:
                    x1, y1, x2, y2 = item["coords"]
                    self.assertGreater(math.hypot(x2 - x1, y2 - y1), 1e-8)
                    self.assertAlmostEqual(abs(x2 - x1), abs(y2 - y1), places=8)
                    matches = [
                        j
                        for j, (left, right, low, high) in enumerate(material)
                        if left - 1e-8 <= min(x1, x2) <= max(x1, x2) <= right + 1e-8
                        and low - 1e-8 <= min(y1, y2) <= max(y1, y2) <= high + 1e-8
                    ]
                    self.assertEqual(len(matches), 1)
                    covered.update(matches)
                    phase = (x1 + y1 - rear - y + od / 2) / float(
                        project["settings"]["HATCH_PITCH"]
                    )
                    self.assertAlmostEqual(phase, round(phase), places=8)
                self.assertEqual(covered, set(range(6)))
                dims = [i["coords"] for i in items if i["type"] == "DIMLINEAR"]
                self.assertEqual(len(dims), 5)
                for points, value in zip(dims[:3], (od, hub, bore)):
                    self.assertAlmostEqual(points[3] - points[1], value)
                for points, value in zip(dims[3:], (thickness, thickness + height)):
                    self.assertAlmostEqual(points[2] - points[0], value)
                self.assertLess(nose, x - od / 2)
                self.assertNotIn("_.-LINETYPE", script)
                self.assertIn("(c:CADFLOWRESTORE)", script)
                labels = [i["text"] for i in items if i["type"] == "TEXT"]
                self.assertTrue(
                    any("中心穴" in label and "通し" in label for label in labels)
                )
                self.assertFalse(
                    any("Rc" in label or "ねじ" in label for label in labels)
                )

    def test_shipped_json_csv_excel_and_script_match_default_sample(self):
        project = normalize_project(
            json.loads(
                (ROOT / "examples/flange_project.json").read_text(encoding="utf-8")
            )
        )
        self.assertEqual(project, EXAMPLE)
        rows = EXAMPLE["input_tables"][0]["rows"]
        self.assertEqual(read_csv(ROOT / "examples/flange_input.csv"), rows)
        excel = ROOT / "examples/flange_input.xlsx"
        self.assertEqual(read_excel(excel, sheet_names(excel)[0]), rows)
        expected, _ = compile_project(EXAMPLE, [0])
        self.assertEqual(
            (ROOT / "examples/flange_output.scr")
            .read_bytes()
            .decode("cp932")
            .replace("\r\n", "\n"),
            expected + "\n",
        )

    def test_organized_sample_changes_only_folder_organization(self):
        project = normalize_project(
            json.loads(
                (ROOT / "examples/folder_organization.json").read_text(encoding="utf-8")
            )
        )
        self.assertEqual(
            compile_project(project, [0, 1, 2]), compile_project(EXAMPLE, [0, 1, 2])
        )


if __name__ == "__main__":
    unittest.main()
