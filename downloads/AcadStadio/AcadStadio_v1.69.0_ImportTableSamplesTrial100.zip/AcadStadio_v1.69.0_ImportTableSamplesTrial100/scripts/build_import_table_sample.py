"""Own synthetic plate: fixed DXF/DWG, matching XLSX, import and linked projects.

Run with the optional --dwg-writer path to the write_sample_dwg helper to rebuild DWG.
PyMuPDF is optional and used only to rebuild the reference PDFs.
"""
import argparse,csv,json,subprocess,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import ezdxf
from ezdxf.enums import TextEntityAlignment
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from cad_drawing_import import read_cad_drawing,imported_project
from engine import compile_project
from project_data import add_input_table
from table_io import read_excel
from link_assistance import fields,read,checked_change,table_token

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'examples'/'DWG読込と表割当テスト'
COLUMNS=['品番','幅','高さ','穴径','端距離X','端距離Y','配置X','配置Y','寸法離れ','文字高']
VALUES=[['PLATE_A',160,100,12,24,18,0,0,15,4],['PLATE_B',200,120,16,28,22,240,0,20,5],['PLATE_C',120,80,10,16,14,0,170,12,3.5]]
TABLE='plate_values / 入力データ'


def document():
 d=ezdxf.new('R2000');d.header['$INSUNITS']=4;d.header['$LTSCALE']=1
 d.layers.new('PART',dxfattribs={'color':7});d.layers.new('HOLES',dxfattribs={'color':2})
 d.layers.new('AXIS',dxfattribs={'color':1});d.layers.new('DIMS',dxfattribs={'color':4})
 d.styles.new('SAMPLE_TEXT',dxfattribs={'font':'arial.ttf'})
 return d


def plate(doc,record):
 """Each entity's semantic role and exact parameter expressions are explicit."""
 m=doc.modelspace();v=dict(zip(COLUMNS,record));plan={}
 def val(expression):
  from engine import evaluate,convert
  return float(evaluate(expression,{k:convert(x) for k,x in v.items()}))
 def point(x,y):return val(x),val(y)
 def keep(entity,role,mapping):plan[entity.dxf.handle]={'role':role,'mapping':mapping};return entity
 x0,y0='配置X','配置Y';x1,y1='配置X + 幅','配置Y + 高さ'
 for role,ax,ay,bx,by in [('外形下辺',x0,y0,x1,y0),('外形右辺',x1,y0,x1,y1),('外形上辺',x1,y1,x0,y1),('外形左辺',x0,y1,x0,y0)]:
  keep(m.add_line(point(ax,ay),point(bx,by),dxfattribs={'layer':'PART'}),role,dict(x1=ax,y1=ay,x2=bx,y2=by))
 for role,x,y in [('左下穴','配置X + 端距離X','配置Y + 端距離Y'),('右下穴','配置X + 幅 - 端距離X','配置Y + 端距離Y'),('左上穴','配置X + 端距離X','配置Y + 高さ - 端距離Y'),('右上穴','配置X + 幅 - 端距離X','配置Y + 高さ - 端距離Y')]:
  keep(m.add_circle(point(x,y),val('穴径 / 2'),dxfattribs={'layer':'HOLES'}),role,dict(x=x,y=y,r='穴径 / 2'))
 for role,ax,ay,bx,by in [('横中心線','配置X - 5','配置Y + 高さ / 2','配置X + 幅 + 5','配置Y + 高さ / 2'),('縦中心線','配置X + 幅 / 2','配置Y - 5','配置X + 幅 / 2','配置Y + 高さ + 5')]:
  keep(m.add_line(point(ax,ay),point(bx,by),dxfattribs={'layer':'AXIS'}),role,dict(x1=ax,y1=ay,x2=bx,y2=by))
 # Dimension annotations are deliberately plain lines and numeric TEXT:
 # they are stable numeric fields for the table-assignment exercise.
 for role,ax,ay,bx,by in [
  ('幅寸法線',x0,'配置Y - 寸法離れ',x1,'配置Y - 寸法離れ'),
  ('幅始点目盛',x0,'配置Y - 寸法離れ - 2',x0,'配置Y - 寸法離れ + 2'),
  ('幅終点目盛',x1,'配置Y - 寸法離れ - 2',x1,'配置Y - 寸法離れ + 2'),
  ('高さ寸法線','配置X - 寸法離れ',y0,'配置X - 寸法離れ',y1),
  ('高さ始点目盛','配置X - 寸法離れ - 2',y0,'配置X - 寸法離れ + 2',y0),
  ('高さ終点目盛','配置X - 寸法離れ - 2',y1,'配置X - 寸法離れ + 2',y1)]:
  keep(m.add_line(point(ax,ay),point(bx,by),dxfattribs={'layer':'DIMS'}),role,dict(x1=ax,y1=ay,x2=bx,y2=by))
 for role,column,x,y in [('幅注記','幅','配置X + 幅 / 2 - 3','配置Y - 寸法離れ - 5'),('高さ注記','高さ','配置X - 寸法離れ - 8','配置Y + 高さ / 2')]:
  e=m.add_text(str(v[column]),dxfattribs={'height':3,'width':1,'layer':'DIMS','style':'SAMPLE_TEXT'}).set_placement(point(x,y),align=TextEntityAlignment.LEFT)
  keep(e,role,dict(x=x,y=y,text=column))
 text=m.add_text(v['品番'],dxfattribs={'height':v['文字高'],'layer':'DIMS','style':'SAMPLE_TEXT'}).set_placement(point('配置X','配置Y + 高さ + 寸法離れ'),align=TextEntityAlignment.LEFT)
 keep(text,'品番ラベル',dict(x='配置X',y='配置Y + 高さ + 寸法離れ',height='文字高',text='品番'))
 return plan


def save_json(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def render_pdf(doc,path):
 try:
  from ezdxf.addons.drawing import RenderContext,Frontend,layout,pymupdf,config
  backend=pymupdf.PyMuPdfBackend();ctx=RenderContext(doc)
  Frontend(ctx,backend,config=config.Configuration(background_policy=config.BackgroundPolicy.WHITE,color_policy=config.ColorPolicy.BLACK)).draw_layout(doc.modelspace(),finalize=True)
  path.write_bytes(backend.get_pdf_bytes(layout.Page(297,210,margins=layout.Margins.all(10))))
 except ImportError:print('PDF再作成にはPyMuPDFが必要です:',path.name)


def build(dwg_writer=None):
 OUT.mkdir(parents=True,exist_ok=True)
 wb=Workbook();ws=wb.active;ws.title='入力データ';ws.append(COLUMNS)
 for row in VALUES:ws.append(row)
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for cell in ws[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='245A81');cell.alignment=Alignment(horizontal='center')
 for i in range(1,len(COLUMNS)+1):ws.column_dimensions[ws.cell(1,i).column_letter].width=18
 wb.save(OUT/'plate_values.xlsx')
 with (OUT/'plate_values.csv').open('w',encoding='utf-8-sig',newline='') as f:
  writer=csv.writer(f);writer.writerow(COLUMNS);writer.writerows(VALUES)
 doc=document();plan=plate(doc,VALUES[0]);doc.saveas(OUT/'plate_base.dxf');render_pdf(doc,OUT/'plate_base.pdf')
 expected=document()
 for record in VALUES:plate(expected,record)
 expected.saveas(OUT/'expected_3rows.dxf');render_pdf(expected,OUT/'expected_3rows.pdf')
 if dwg_writer:
  for stem,drawing in [('plate_base',doc),('expected_3rows',expected)]:
   rows=[]
   for e in drawing.modelspace():
    color=int(drawing.layers.get(e.dxf.layer).color)
    head=f'{e.dxftype()} {e.dxf.layer} {color}'
    if e.dxftype()=='LINE':row=f'{head} {e.dxf.start.x} {e.dxf.start.y} {e.dxf.end.x} {e.dxf.end.y}'
    elif e.dxftype()=='CIRCLE':row=f'{head} {e.dxf.center.x} {e.dxf.center.y} {e.dxf.radius}'
    elif e.dxftype()=='TEXT':row=f'{head} {e.dxf.insert.x} {e.dxf.insert.y} {e.dxf.height} {e.dxf.text}'
    else:raise ValueError('Unsupported sample entity')
    rows.append(row)
   with tempfile.TemporaryDirectory() as directory:
    instructions=Path(directory)/'entities.txt';instructions.write_text('\n'.join(rows)+'\n')
    subprocess.run([str(dwg_writer),str(instructions),str(OUT/(stem+'.dwg'))],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 snapshot=read_cad_drawing(OUT/'plate_base.dxf');snapshot['source']='plate_base.dxf';p=imported_project(snapshot)
 save_json(OUT/'02_imported_unlinked.json',p)
 (OUT/'base_from_values.scr').write_text(compile_project(p,[0])[0],encoding='utf-8')
 rows=read_excel(OUT/'plate_values.xlsx','入力データ');table=add_input_table(p,TABLE,rows)
 save_json(OUT/'03_excel_loaded_unlinked.json',p)
 guide=[]
 for bi,block in enumerate(p['blocks']):
  for ci,command in enumerate(block['commands']):
   spec=plan[command['import_source']['handle']];changes=[]
   for key,expression in spec['mapping'].items():
    field=next(f for f in fields(command) if f.path==(key,))
    formula=expression
    # Parameter names are all distinct; replace longer names before short ones.
    import re
    formula=re.sub('|'.join(map(re.escape,sorted(COLUMNS,key=len,reverse=True))),lambda m:table_token(table,m[0]),formula)
    guide.append(dict(block=bi+1,command=ci+1,role=spec['role'],type=command['type'],field=key,value=read(command,(key,)),formula=formula))
    changes.append((field,formula))
   p=checked_change(p,('blocks',bi,'commands',ci),changes,row=0)
 save_json(OUT/'04_assigned_complete.json',p);save_json(OUT/'assignment_guide.json',guide)
 script,items=compile_project(p,[0,1,2]);(OUT/'assigned_3rows.scr').write_text(script,encoding='utf-8')
 save_json(OUT/'sample_manifest.json',dict(version=1,table=TABLE,columns=COLUMNS,rows=[dict(zip(COLUMNS,row)) for row in VALUES],source_counts=snapshot['counts'],source_figures=sum(snapshot['counts'].values()),assigned_figures=len(items),assignments=len(guide),files={'base':'plate_base.dwg','excel':'plate_values.xlsx','reference':'expected_3rows.dwg'}))
 return p,guide

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--dwg-writer',type=Path);args=parser.parse_args()
 p,guide=build(args.dwg_writer);print(OUT);print('assignments',len(guide),'figures',len(compile_project(p,[0,1,2])[1]))
