/* Build own numeric test fixtures with GNU LibreDWG's construction API.
 * gcc -I<libredwg>/include write_sample_dwg.c <libredwg>/src/.libs/libredwg.a -lm -o write_sample_dwg
 * Input: the generator's simple ASCII entity list, never user drawings. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dwg.h"
#include "dwg_api.h"
int main(int argc,char **argv) {
 if(argc!=3)return 2;
 FILE *in=fopen(argv[1],"r");if(!in)return 3;
 Dwg_Data *d=dwg_new_Document(R_2000,0,0);
 d->header_vars.INSUNITS=4;
 Dwg_Object_LAYER *layers[4];const char *names[]={"PART","HOLES","AXIS","DIMS"};
 unsigned long handles[4];
 for(int i=0;i<4;i++){layers[i]=dwg_add_LAYER(d,names[i]);handles[i]=d->object[layers[i]->parent->objid].handle.value;}
 Dwg_Object_STYLE *style=dwg_add_STYLE(d,"SAMPLE_TEXT");
 style->width_factor=1.;style->font_file=strdup("arial.ttf");
 unsigned long style_handle=d->object[style->parent->objid].handle.value;
 Dwg_Object_BLOCK_HEADER *b=dwg_model_space_object(d)->tio.object->tio.BLOCK_HEADER;
 char kind[20],layer[32],text[128];int color,count=0;
 while(fscanf(in,"%19s %31s %d",kind,layer,&color)==3){
  double x,y,u,v,r;Dwg_Object_Entity *parent=NULL;
  if(!strcmp(kind,"LINE")){
   if(fscanf(in,"%lf %lf %lf %lf",&x,&y,&u,&v)!=4)return 4;
   dwg_point_3d p={x,y,0},q={u,v,0};parent=dwg_add_LINE(b,&p,&q)->parent;
  }else if(!strcmp(kind,"CIRCLE")){
   if(fscanf(in,"%lf %lf %lf",&x,&y,&r)!=3)return 4;
   dwg_point_3d p={x,y,0};parent=dwg_add_CIRCLE(b,&p,r)->parent;
  }else if(!strcmp(kind,"TEXT")){
   if(fscanf(in,"%lf %lf %lf %127s",&x,&y,&r,text)!=4)return 4;
   dwg_point_3d p={x,y,0};Dwg_Entity_TEXT *e=dwg_add_TEXT(b,text,&p,r);
   e->style=dwg_add_handleref(d,5,style_handle,NULL);e->width_factor=1.;parent=e->parent;
  }else return 4;
  for(int i=0;i<4;i++)if(!strcmp(layer,names[i]))parent->layer=dwg_add_handleref(d,5,handles[i],NULL);
  parent->color.index=color;
  if(++count>1000)return 5;
 }
 fclose(in);remove(argv[2]);int error=dwg_write_file(argv[2],d);dwg_free(d);free(d);
 return error>=DWG_ERR_CRITICAL?6:0;
}
