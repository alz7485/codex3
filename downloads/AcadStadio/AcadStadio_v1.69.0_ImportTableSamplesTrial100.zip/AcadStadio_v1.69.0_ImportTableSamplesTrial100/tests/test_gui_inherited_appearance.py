"""Inheritance is a muted placeholder, stays empty, updates with preview row."""
import os
import sys
import unittest
import test_gui as gui
from macro_editor import edit_command
from theme import MUTED


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class InheritedAppearanceGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_dynamic_hints_preserve_empty_values_and_existing_font_style(self):
        prefix=[dict(type='TEXT',x='0',y='0',height='3',angle='0',text='文字',layer='OUTLINE',linetype='CENTER',color='2',linetype_scale='@OD / 100',text_style='FONT_A')]
        callback_failures=[]
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                for key,value in [('layer','OUTLINE'),('linetype','CENTER'),('color','2'),('text_style','FONT_A'),('linetype_scale','1')]:
                    entry=win.command_entries[key]
                    self.assertEqual(entry.get(),'');self.assertTrue(entry.hint_label.winfo_ismapped(),key)
                    self.assertTrue(entry.hint_full_text.startswith(value+'（') if key!='color' else entry.hint_full_text.startswith('2'), (key,entry.hint_full_text))
                    self.assertEqual(str(entry.hint_label.cget('foreground')),MUTED)
                    self.assertFalse(str(entry.hint_label.cget('font')))
                    self.assertTrue(entry.hint_full_text.endswith('（現在値）'),key)
                    self.assertTrue(entry.hint_label.cget('text'),key)
                self.assertTrue(win.command_entries['color'].hint_label.cget('text').startswith('2'))
                win.sample_row.set('2');win.refresh_command_preview();self.root.update()
                self.assertNotEqual(win.command_entries['linetype_scale'].hint_full_text,'1（現在値）')
                for width in (1320,980):
                    win.geometry(f'{width}x860');self.root.update()
                    entry=win.command_entries['layer'];hint=entry.hint_label
                    self.assertLessEqual(hint.winfo_x()+hint.winfo_width(),entry.winfo_width()-18)
                win.command_entries['layer'].set('PARTS');self.root.update()
                self.assertFalse(win.command_entries['layer'].hint_label.winfo_ismapped())
                win.command_entries['layer'].set('');win.refresh_command_preview();self.root.update()
                self.assertTrue(win.command_entries['layer'].hint_full_text.startswith('OUTLINE（'))
                gui.button(win,'コマンドを反映').invoke()
            except Exception:
                callback_failures.append(sys.exc_info());win.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='APPEARANCE',layer=''),self.app.data['blocks'],self.app.data,point_sources=prefix)
        if callback_failures:
            _,error,traceback=callback_failures[0]
            raise error.with_traceback(traceback)
        self.assertIsNotNone(result,'フォームの反映が結果を返しませんでした')
        self.assertEqual(result['layer'],'');self.assertEqual(result['color'],'');self.assertEqual(result['text_style'],'')

    def test_unknown_initial_value_is_not_filled_with_a_guess(self):
        callback_failures=[]
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                self.assertEqual(win.command_entries['layer'].hint_full_text,'未取得（現在値）')
                gui.button(win,'キャンセル').invoke()
            except Exception:
                callback_failures.append(sys.exc_info());win.destroy()
        self.root.after(80,inspect)
        edit_command(self.root,dict(type='APPEARANCE',layer=''),self.app.data['blocks'],self.app.data)
        if callback_failures:
            _,error,traceback=callback_failures[0]
            raise error.with_traceback(traceback)

    def test_inherited_values_remain_visible_at_large_scaling(self):
        previous=self.root.tk.call('tk','scaling')
        try:
            for scaling in (1.5,2.0):
                with self.subTest(scaling=scaling):
                    self.root.tk.call('tk','scaling',scaling)
                    self.test_dynamic_hints_preserve_empty_values_and_existing_font_style()
        finally:
            self.root.tk.call('tk','scaling',previous)
