import os,time,unittest
from pathlib import Path
from unittest.mock import patch
import test_gui as gui
from link_assistance_ui import LinkAssistanceWindow
from project_data import current_table
from engine import compile_project
ROOT=Path(__file__).resolve().parents[1]/'examples'/'DWG読込と表割当テスト'

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class ImportTableSampleGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def read_base(self):
  w=self.app.import_cad_drawing(True);w.path.set(str(ROOT/'plate_base.dxf'));w.read();deadline=time.monotonic()+15
  while w.job is not None and time.monotonic()<deadline:self.root.update();time.sleep(.01)
  self.assertIsNone(w.job);self.assertIsNotNone(w.snapshot)
  with patch.object(self.app,'confirm_discard',return_value=True):w.apply()
  self.root.update()
 def choose(self,w,path):
  w.field_picker.current(next(i for i,f in enumerate(w.target_fields) if f.path==path));w.target_changed();self.root.update()
 def apply_column(self,w,column,recipe=None):
  index=next(i for i,c in enumerate(w.candidates) if c['column']==column and (recipe is None or c['recipe']==recipe))
  w.candidate_tree.selection_set(str(index));w.candidate_selected();self.root.update();w.apply();self.root.update();w.close()
 def test_real_import_then_create_column_and_undo(self):
  self.read_base();w=LinkAssistanceWindow(self.app,('blocks',0,'commands',0));self.root.update();self.choose(w,('x2',))
  with patch('link_assistance_ui.simpledialog.askstring',return_value='幅'):w.add_column_button.invoke()
  self.root.update();self.assertEqual(current_table(self.app.data)['rows'][0]['幅'],'160');w.close()
  self.app.undo_project();self.root.update();self.assertNotIn('幅',current_table(self.app.data)['rows'][0])
  self.app.redo_project();self.root.update();self.assertEqual(current_table(self.app.data)['rows'][0]['幅'],'160')
 def test_real_excel_then_assign_diameter_and_part_text(self):
  self.read_base()
  with patch('main.simpledialog.askinteger',return_value=1):self.assertTrue(self.app.read_table(str(ROOT/'plate_values.xlsx')))
  self.root.update();self.assertEqual(len(current_table(self.app.data)['rows']),3)
  ci=next(i for i,c in enumerate(self.app.data['blocks'][0]['commands']) if c['type']=='CIRCLE')
  w=LinkAssistanceWindow(self.app,('blocks',0,'commands',ci));self.root.update();self.choose(w,('r',));self.apply_column(w,'穴径','値 / 2')
  self.assertEqual(next(i for i in compile_project(self.app.data,[1])[1] if i['type']=='CIRCLE')['coords'][2],8)
  ci=next(i for i,c in enumerate(self.app.data['blocks'][2]['commands']) if 'PLATE_A' in c['text'])
  w=LinkAssistanceWindow(self.app,('blocks',2,'commands',ci));self.root.update();self.choose(w,('text',));self.apply_column(w,'品番')
  self.assertIn('PLATE_B',[i.get('text') for i in compile_project(self.app.data,[1])[1]])
  self.assertEqual(self.messages,[])
