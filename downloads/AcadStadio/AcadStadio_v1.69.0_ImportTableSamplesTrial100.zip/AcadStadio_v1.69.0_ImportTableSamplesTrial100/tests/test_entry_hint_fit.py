import unittest
from entry_hints import fit_hint

class HintFitTests(unittest.TestCase):
 def test_full_hint_when_it_fits(self):
  self.assertEqual(fit_hint('OUTLINE（現在値）',40,len),'OUTLINE（現在値）')
 def test_aci_number_has_priority_over_status(self):
  shown=fit_hint('256：ByLayer（現在値）',7,len)
  self.assertTrue(shown.startswith('256'))
  self.assertLessEqual(len(shown),7)
 def test_short_status_preserves_numeric_token(self):
  shown=fit_hint('256：ByLayer（現在値）',9,len)
  self.assertTrue(shown.startswith('256'))
  self.assertTrue(shown.endswith('（現在値）'))
 def test_decimal_scale_stays_intact_when_status_wont_fit(self):
  self.assertTrue(fit_hint('1.25（現在値）',6,len).startswith('1.25'))
 def test_unknown_value_is_still_identifiable(self):
  self.assertTrue(fit_hint('未取得（現在値）',4,len).startswith('未'))
