import copy,json,unittest
from pathlib import Path
from cad_drawing_import import read_cad_drawing,imported_project
from engine import compile_project
from project_data import current_table,default_target
from table_io import read_excel
from link_assistance import fields,table_candidates,checked_change,add_field_column
ROOT=Path(__file__).resolve().parents[1]/'examples'/'DWG読込と表割当テスト'
def project(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
def signature(items):return sorted((i['type'],tuple(round(x,6) for x in i['coords']),i.get('text','')) for i in items)

class ImportTableSample(unittest.TestCase):
 def test_excel_and_base_drawing_values_agree(self):
  rows=read_excel(ROOT/'plate_values.xlsx','入力データ');manifest=project('sample_manifest.json')
  self.assertEqual(rows,manifest['rows'])
  _,items=compile_project(imported_project(read_cad_drawing(ROOT/'plate_base.dxf')),[0])
  self.assertEqual(len(items),19)
  self.assertEqual(items[0]['coords'],(0,0,rows[0]['幅'],0))
  self.assertEqual([i['coords'][2] for i in items if i['type']=='CIRCLE'],[rows[0]['穴径']/2]*4)
 def test_all_three_assigned_rows_match_independent_reference(self):
  _,actual=compile_project(project('04_assigned_complete.json'),[0,1,2])
  _,expected=compile_project(imported_project(read_cad_drawing(ROOT/'expected_3rows.dxf')),[0])
  self.assertEqual(len(actual),57);self.assertEqual(signature(actual),signature(expected))
 def test_add_column_creates_one_populated_row_without_excel(self):
  p=project('02_imported_unlinked.json');table=current_table(p);table['rows']=[];p['drawing']['targets'][table['id']]=default_target([])
  cmd=p['blocks'][0]['commands'][0];field=next(f for f in fields(cmd) if f.path==('x2',))
  trial=add_field_column(p,('blocks',0,'commands',0),field,'幅')
  self.assertEqual(current_table(p)['rows'],[])
  self.assertEqual(current_table(trial)['rows'],[{'幅':'160'}])
  self.assertEqual(compile_project(trial,[0])[1][0]['coords'],(0,0,160,0))
 def test_diameter_assignment_uses_half_and_remains_dynamic(self):
  p=project('03_excel_loaded_unlinked.json');ci=next(i for i,c in enumerate(p['blocks'][0]['commands']) if c['type']=='CIRCLE');cmd=p['blocks'][0]['commands'][ci]
  field=next(f for f in fields(cmd) if f.path==('r',));table=current_table(p)
  choice=next(c for c in table_candidates(p,cmd,field,table['id'],0) if c['column']=='穴径' and c['recipe']=='値 / 2')
  linked=checked_change(p,('blocks',0,'commands',ci),[(field,choice['formula'])])
  _,items=compile_project(linked,[1]);self.assertEqual(next(i for i in items if i['type']=='CIRCLE')['coords'][2],8)
 def test_imported_literal_text_matches_excel_display_value(self):
  p=project('03_excel_loaded_unlinked.json');table=current_table(p)
  for ci,cmd in enumerate(p['blocks'][2]['commands']):
   field=next(f for f in fields(cmd) if f.path==('text',));cs=table_candidates(p,cmd,field,table['id'],0)
   expected='品番' if 'PLATE_A' in cmd['text'] else '幅' if '160' in cmd['text'] else '高さ'
   choice=next(c for c in cs if c['column']==expected)
   if expected=='品番':
    linked=checked_change(p,('blocks',2,'commands',ci),[(field,choice['formula'])])
    self.assertIn('PLATE_B',[i.get('text') for i in compile_project(linked,[1])[1]])
 def test_dwg_files_are_binary_ac1015_and_reference_is_present(self):
  for stem in ('plate_base','expected_3rows'):
   data=(ROOT/(stem+'.dwg')).read_bytes();self.assertEqual(data[:6],b'AC1015');self.assertGreater(len(data),1024)
   self.assertTrue((ROOT/(stem+'.pdf')).read_bytes().startswith(b'%PDF'))
