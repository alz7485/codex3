"""Display empty-field guidance without inserting it into the input value."""

from tkinter import ttk, font
import re
from theme import MUTED


def fit_hint(full, available, measure):
    """Keep the inherited value before its status when space is scarce."""
    if measure(full)<=available or not full.endswith('（現在値）'):return full
    suffix='（現在値）';prefix=full[:-len(suffix)]
    number=re.match(r'[+-]?\d+(?:\.\d+)?',prefix)
    minimum=len(number[0]) if number else 1
    shown=prefix
    while len(shown)>minimum and measure(shown+'…'+suffix)>available:shown=shown[:-1]
    if measure(shown+'…'+suffix)<=available:return shown+'…'+suffix
    # The status remains available in hint_full_text and the hover tooltip.
    # Do not replace the value with an ellipsis just to retain the status.
    shown=prefix
    while len(shown)>1 and measure(shown+'…')>available:shown=shown[:-1]
    return shown+'…'


def add_entry_hint(entry, variable, text):
    hint = ttk.Label(entry, text=text() if callable(text) else text, foreground=MUTED, background="white",
                     cursor="xterm", takefocus=False)
    entry.hint_label = hint

    def refresh(*_):
        if variable.get() or entry.instate(("disabled",)):
            hint.place_forget()
        else:
            reserve = 28 if isinstance(entry, ttk.Combobox) else 14
            available=max(0,entry.winfo_width()-reserve)
            full=text() if callable(text) else text
            entry.hint_full_text=full
            shown=fit_hint(full,available,font.nametofont('TkDefaultFont').measure)
            hint.configure(text=shown)
            width = min(font.nametofont('TkDefaultFont').measure(shown)+2, available)
            hint.place(x=7, rely=0.5, anchor="w", width=width)

    def focus(event):
        entry.focus_set()
        entry.icursor(0)
        return "break"

    trace = variable.trace_add("write", refresh)

    def cleanup(event):
        if event.widget is entry:
            variable.trace_remove("write", trace)

    hint.bind("<Button-1>", focus)
    entry.bind("<Configure>", refresh, add="+")
    entry.bind("<Map>", refresh, add="+")
    entry.bind("<Destroy>", cleanup, add="+")
    entry.refresh_hint=refresh
    refresh()
    return hint
