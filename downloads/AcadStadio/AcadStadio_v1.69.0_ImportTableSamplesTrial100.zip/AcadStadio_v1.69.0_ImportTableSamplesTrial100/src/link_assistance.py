"""Table usage and reversible, compiler-checked linking of imported constants."""

import ast
import copy
import math
import re
from dataclasses import dataclass

from flow import walk, resolve
from project_data import current_table, input_tables
from reference_tokens import command_references
from table_references import REFERENCE, is_single_table_reference
from table_formulas import RowResolver, table_columns
from engine import convert, evaluate, MacroError, compile_project
from command_points import geometry_points, reference, new_id
from vertex_points import split_top_level


@dataclass(frozen=True)
class Field:
    path: tuple
    label: str
    numeric: bool = True


NUMERIC = {
    "x",
    "y",
    "x1",
    "y1",
    "x2",
    "y2",
    "x3",
    "y3",
    "r",
    "rx",
    "ry",
    "radius",
    "diameter",
    "height",
    "width",
    "angle",
    "start_angle",
    "end_angle",
    "scale",
    "scale_x",
    "scale_y",
    "distance",
    "distance1",
    "distance2",
    "factor",
    "column_spacing",
    "row_spacing",
}
LABELS = {
    "x": "中心・挿入X",
    "y": "中心・挿入Y",
    "x1": "始点X",
    "y1": "始点Y",
    "x2": "終点X",
    "y2": "終点Y",
    "x3": "寸法位置X",
    "y3": "寸法位置Y",
    "r": "半径",
    "rx": "長軸半径",
    "ry": "短軸半径",
    "diameter": "直径",
    "radius": "半径",
    "height": "文字高さ",
    "width": "文字枠幅",
    "angle": "回転角度",
    "start_angle": "開始角度",
    "end_angle": "終了角度",
    "text": "文字列",
}


def commands(project):
    for b, block in enumerate(project["blocks"]):
        for address, command in walk(block["commands"], ("blocks", b, "commands")):
            yield address, command


def command_label(project, address):
    cmd = resolve(project, address)
    path = ".".join(str(v + 1) for v in address[3:] if type(v) is int)
    return f"{project['blocks'][address[1]]['name']} / {path} {cmd['type']}"


def fields(command):
    result = []
    for key in command:
        if key in ("x1", "y1", "x2", "y2") and command.get("vertices"):
            continue
        if key in NUMERIC or key == "text":
            if type(command[key]) not in (str, int, float):
                continue
            label = LABELS.get(key, key)
            if command["type"] in ("DIMLINEAR", "DIMALIGNED") and key in (
                "x1",
                "y1",
                "x2",
                "y2",
            ):
                label = "測定点" + key[1] + key[0].upper()
            result.append(Field((key,), label, key != "text"))
    if isinstance(command.get("vertices"), list):
        for i, point in enumerate(command["vertices"]):
            for axis in ("x", "y"):
                if axis in point:
                    result.append(
                        Field(("vertices", i, axis), f"頂点{i + 1}{axis.upper()}")
                    )
    elif isinstance(command.get("points"), str):
        try:
            for i, point in enumerate(split_top_level(command["points"], ";")):
                if len(split_top_level(point, ",")) != 2:
                    break
                for j, axis in enumerate(("X", "Y")):
                    result.append(Field(("points", i, j), f"頂点{i + 1}{axis}"))
        except ValueError:
            pass
    return result


def read(command, path):
    if path[0] == "points" and len(path) == 3:
        return split_top_level(split_top_level(command["points"], ";")[path[1]], ",")[
            path[2]
        ]
    return resolve(command, path)


def write(command, path, value):
    if path[0] == "points" and len(path) == 3:
        points = [
            split_top_level(p, ",") for p in split_top_level(command["points"], ";")
        ]
        points[path[1]][path[2]] = value
        command["points"] = "; ".join(", ".join(p) for p in points)
    else:
        resolve(command, path[:-1])[path[-1]] = value


def field_references(command, field):
    if not field.numeric:
        raw = str(read(command, field.path))
        if not (raw.startswith("=") or is_single_table_reference(raw)):
            return []
    # Preserve literal TEXT semantics and skip metadata such as DWG handles/review marks.
    return command_references(
        {
            field.path[0] if len(field.path) == 1 else "value": str(
                read(command, field.path)
            )
        }
    )


def linked(command, field):
    raw = str(read(command, field.path))
    return bool(
        field_references(command, field)
        or (field.numeric and ("点(" in raw or "点位置(" in raw))
    )


def review_key(field):
    return "/".join(map(str, field.path))


def status(command):
    fs = fields(command)
    reviewed = command.get("link_review", {})
    if not isinstance(reviewed, dict):
        reviewed = {}
    done = sum(
        linked(command, f) or reviewed.get(review_key(f)) == str(read(command, f.path))
        for f in fs
    )
    return done, len(fs)


def table_usage(project):
    """Direct and variable-mediated usage, counted once per command definition."""
    tables = input_tables(project)
    by_name = {t["name"].casefold(): t for t in tables}
    active = current_table(project)
    usage = {}

    def dependencies(tokens, seen=None):
        result = set()
        seen = set() if seen is None else seen
        for token in tokens:
            match = REFERENCE.fullmatch(token)
            if match:
                tag = match["table"]
                name = (
                    tag[1:-1].replace(r"\]", "]").replace(r"\\", "\\")
                    if tag
                    else active["name"]
                )
                table = by_name.get(name.casefold())
                if table and match["column"] in table_columns(table):
                    result.add((table["id"], match["column"]))
            else:
                match = re.fullmatch(r"(?:変数|variable|global|settings)\.(\w+)", token)
                if match and token not in seen:
                    seen.add(token)
                    mapping = project.get(
                        "settings" if token.startswith("settings.") else "globals", {}
                    )
                    result.update(
                        dependencies(
                            command_references(
                                {"value": str(mapping.get(match[1], ""))}
                            ),
                            seen,
                        )
                    )
        return result

    for address, cmd in commands(project):
        shallow = {
            k: v
            for k, v in cmd.items()
            if k
            not in (
                "commands",
                "else",
                "link_review",
                "import_source",
                "guide_origin",
                "dimension_text",
                "linetype",
                "text_style",
                "dim_style",
                "pattern",
                "block_name",
                "selection_ref",
                "selection_name",
            )
        }
        raw = shallow.get("text")
        if isinstance(raw, str) and not (
            raw.startswith("=") or is_single_table_reference(raw)
        ):
            shallow.pop("text")
        raw = shallow.get("layer")
        if isinstance(raw, str) and not raw.startswith(("=", "settings.")):
            shallow.pop("layer")
        if cmd.get("type") == "SYSVAR" and cmd.get("value_kind", "number") == "text":
            if not str(cmd.get("value", "")).startswith("="):
                shallow.pop("value", None)
        if cmd.get("type") == "CUSTOM":
            definition = project.get("custom_commands", {}).get(cmd.get("name"), {})
            shallow["arguments"] = {
                p["name"]: cmd.get("arguments", {}).get(p["name"], p.get("default", ""))
                for p in definition.get("parameters", [])
                if p.get("kind") == "number"
                or str(
                    cmd.get("arguments", {}).get(p["name"], p.get("default", ""))
                ).startswith("=")
            }

        for table_id, column in dependencies(command_references(shallow)):
            usage.setdefault((table_id, column), []).append(address)
    return usage


def table_token(table, column):
    name = table["name"].replace("\\", r"\\").replace("]", r"\]")
    return f"[{name}]@{column}"


def add_field_column(project,address,field,column,table_id=None,row=0):
    """Populate a new column and link the field as a single validated change."""
    from table_io import headers
    from project_data import default_target
    cmd=resolve(project,address)
    if field not in fields(cmd) or not field.numeric or linked(cmd,field):raise ValueError('列へ追加する固定の数値項目を選択してください')
    column=headers([column])[0];trial=copy.deepcopy(project);table=current_table(trial,table_id)
    if column in table_columns(table):raise ValueError('同じ名前の列があります。別の列名を指定してください')
    value=evaluate(str(read(cmd,field.path)),{})
    if type(value) not in (int,float) or not math.isfinite(value):raise ValueError('固定の数値を選択してください')
    if not table['rows']:
        table['rows'].append({});trial.setdefault('drawing',{}).setdefault('targets',{})[table['id']]=default_target(table['rows'])
    for record in table['rows']:record[column]=str(value)
    return checked_change(trial,address,[(field,table_token(table,column))],row=row)


def numeric_value(project, raw, row):
    values = RowResolver(project, convert, evaluate, MacroError).context(
        current_table(project)["name"], row, eager=True
    )
    if "点(" in str(raw) or "点位置(" in str(raw):
        values = dict(values, __command_points__={}, __all_command_points__={})
        for item in scenes(project, row):
            if item.get("point_id"):
                points = geometry_points(item)
                values["__command_points__"][item["point_id"]] = points
                values["__all_command_points__"][
                    item["point_block_id"] + "/" + item["point_id"]
                ] = points
    value = evaluate(str(raw), values)
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError("数値を照合できません")
    return value


def same(a, b):
    return (
        type(a) in (int, float)
        and type(b) in (int, float)
        and math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-7)
    )


def recipe(expression, token):
    """A single placeholder; actual evaluation always uses the bounded interpreter."""
    expression = (
        expression.strip()
        .removeprefix("=")
        .strip()
        .translate(str.maketrans("÷×−", "/*-"))
    )
    if len(expression) > 512 or not re.search(r"(?<!\w)値(?!\w)", expression):
        raise ValueError("式に「値」を入れてください。例：値 / 2 + 5")
    # Reject extra unknown identifiers/functions before searching the table.
    trial = re.sub(r"(?<!\w)値(?!\w)", "(1)", expression)
    from engine import parse_expression, ALLOWED_FUNCS

    node = parse_expression(trial)
    if any(
        isinstance(n, ast.Name) and n.id not in ALLOWED_FUNCS for n in ast.walk(node)
    ):
        raise ValueError("照合式には「値」と数値・計算関数を使用してください")
    return re.sub(r"(?<!\w)値(?!\w)", lambda m: token, expression)


def table_candidates(
    project, command, field, table_id, row, custom="", *, target_row=0
):
    table = current_table(project, table_id)
    if not 0 <= row < len(table["rows"]):
        raise ValueError("基準行を選択してください")
    raw = read(command, field.path)
    resolver = RowResolver(project, convert, evaluate, MacroError)
    if field.numeric:
        target=numeric_value(project,raw,target_row)
    elif str(raw).startswith('=') or is_single_table_reference(str(raw)):
        # Imported TEXT is stored as a literal expression (='PLATE_A').
        # Match the displayed value, as the TEXT compiler does, not its syntax.
        context=resolver.context(current_table(project)['name'],target_row)
        target=str(evaluate(str(raw)[1:] if str(raw).startswith('=') else str(raw),context))
    else:
        target=str(raw)
    recipes = (
        [custom]
        if custom
        else (
            ["値", "値 / 2", "値 * 2"]
            if field.numeric and field.path[-1] in ("r", "radius", "diameter")
            else ["値"]
        )
    )
    if custom:
        recipe(custom, "1")
    result = []
    for column in table_columns(table):
        try:
            value = resolver.cell(table["name"], row, column)
        except (ValueError, MacroError):
            continue
        for expression in recipes:
            if field.numeric:
                try:
                    calculated = evaluate(recipe(expression, "値"), {"値": value})
                except (ValueError, MacroError):
                    continue
                matches = same(target, calculated)
            else:
                calculated = value
                matches = str(target) == str(value)
            if matches:
                token = table_token(table, column)
                formula = recipe(expression, token) if field.numeric else token
                result.append(
                    dict(
                        column=column,
                        value=value,
                        calculated=calculated,
                        recipe=expression,
                        formula=formula,
                    )
                )
    return result


def coordinate_pairs(command):
    fs = fields(command)
    by_path = {f.path: f for f in fs}
    result = []
    for f in fs:
        p = f.path
        if len(p) == 1 and str(p[0]).startswith("x"):
            other = ("y" + p[0][1:],)
        elif len(p) == 3 and p[0] == "vertices" and p[2] == "x":
            other = (*p[:2], "y")
        elif len(p) == 3 and p[0] == "points" and p[2] == 0:
            other = (*p[:2], 1)
        else:
            continue
        if other in by_path:
            label = f.label.removesuffix("X").removesuffix("x")
            result.append((label, f, by_path[other]))
    return result


def scenes(project, row):
    return compile_project(project, [row])[1]


def source_candidates(project, address, row):
    """Earlier visible geometry only; never introduce forward/self references."""
    ordered = [a for a, c in commands(project)]
    stop = ordered.index(address)
    allowed = set(ordered[:stop])
    from preview_command_edit import command_address

    result = []
    seen = set()
    for item in scenes(project, row):
        try:
            at = command_address(project, item)
        except (ValueError, KeyError, IndexError):
            continue
        if at not in allowed or not geometry_points(item):
            continue
        # One candidate per visible instance. A repeated source can be ambiguous.
        key = (at, tuple(item.get("coords", ())))
        if key in seen:
            continue
        seen.add(key)
        result.append(
            dict(
                address=at,
                item=item,
                points=geometry_points(item),
                label=command_label(project, at),
            )
        )
    return result


def point_candidates(project, address, pair, row):
    command = resolve(project, address)
    x = numeric_value(project, read(command, pair[1].path), row)
    y = numeric_value(project, read(command, pair[2].path), row)
    result = []
    for source in source_candidates(project, address, row):
        for name, point in source["points"].items():
            if same(x, point[0]) and same(y, point[1]):
                result.append(dict(source=source, point=name))
    return result


def checked_change(project, address, changes, row=0, source=None):
    """Validate on a copy so failures/cancel cannot modify the original."""
    trial = copy.deepcopy(project)
    cmd = resolve(trial, address)
    if source is not None:
        source_at, name, axis, offsets = source
        sources = source_candidates(trial, address, row)
        allowed = [
            s for s in sources if s["address"] == source_at and name in s["points"]
        ]
        if not allowed:
            raise ValueError(
                "参照元は、この行に表示される先行コマンドから選んでください"
            )
        # Stable point references resolve the latest emitted instance. Do not silently
        # link one of several repeat instances with the same definition identity.
        if len([s for s in sources if s["address"] == source_at]) > 1:
            raise ValueError(
                "繰り返し内の参照元が複数あります。コマンド編集で参照関係を指定してください"
            )
        source_cmd = resolve(trial, source_at)
        identity = source_cmd.setdefault("point_id", new_id())
        if source_at[1] != address[1]:
            identity = trial["blocks"][source_at[1]]["id"] + "/" + identity
        pair = changes
        for i, (field, component) in enumerate(zip(pair[1:], ("X", "Y"))):
            if axis in ("XY", component):
                expression = reference(identity, name, component)
                if offsets[i].strip() not in ("", "0"):
                    expression += f" + ({offsets[i]})"
                write(cmd, field.path, expression)
    else:
        for field, value in changes:
            write(cmd, field.path, value)
    from project_model import validate_sequential_project

    errors = validate_sequential_project(trial)
    if errors:
        raise ValueError("\n".join(errors[:5]))
    compile_project(trial, [row])
    return trial
