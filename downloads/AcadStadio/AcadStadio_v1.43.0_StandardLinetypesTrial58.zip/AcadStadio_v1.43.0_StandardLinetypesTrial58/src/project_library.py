"""A folder-backed JSON project library with persistent external-file history."""

import json
import os
import sys
from pathlib import Path
from project_safety import atomic_save


def data_directory():
    override = os.environ.get("ACADSTADIO_DATA_DIR") or os.environ.get("CADFLOW_DATA_DIR")
    if override:
        return Path(override).expanduser()
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local" / "share"))
    legacy = base / "CADFlowStudio"
    return legacy if legacy.is_dir() else base / "AcadStadio"


def canonical(path):
    return str(Path(path).expanduser().resolve())


class ProjectLibrary:
    def __init__(self, state_path=None):
        self.portable = state_path is None
        self.state_path = (
            Path(state_path) if state_path else data_directory() / "library.json"
        )
        self.state_path = self.state_path.expanduser().resolve()
        self.directory = self.state_path.parent / "Projects" if state_path else (Path(sys.executable).parent if getattr(sys,"frozen",False) else Path(__file__).resolve().parents[1]) / "Data"
        self.recent = []
        self.warning = ""
        try:
            if self.state_path.exists():
                if self.state_path.stat().st_size > 1024 * 1024:
                    raise ValueError("一覧設定は1MBまでです")
                state = json.loads(self.state_path.read_text(encoding="utf-8-sig"))
                if not isinstance(state, dict) or state.get("version") != 1:
                    raise ValueError("一覧設定の形式が不正です")
                directory = state.get("directory")
                recent = state.get("recent", [])
                if (
                    not isinstance(directory, str)
                    or not directory
                    or not isinstance(recent, list)
                    or len(recent) > 100
                ):
                    raise ValueError("保存フォルダーまたは履歴の形式が不正です")
                if any(
                    not isinstance(p, str) or not p or len(p) > 4096 for p in recent
                ):
                    raise ValueError("プロジェクト履歴の形式が不正です")
                selected = Path(canonical(directory))
                history = list(dict.fromkeys(canonical(p) for p in recent))
                if state_path:self.directory = selected
                self.recent = history
        except (OSError, ValueError, RuntimeError) as exc:
            self.warning = "一覧設定を読めないため既定のフォルダーを表示します: " + str(
                exc
            )

        if self.portable:
            try:self.ensure_directory()
            except OSError as exc:self.warning="Dataフォルダを作成できません: "+str(exc)

    def persist(self, directory, recent):
        atomic_save(
            self.state_path,
            {"version": 1, "directory": str(directory), "recent": recent},
            backup_count=1,
        )

    def select_directory(self, path):
        directory = Path(canonical(path))
        if not directory.is_dir():
            raise ValueError("存在するフォルダーを選択してください")
        # Check accessibility before changing the persisted selection.
        with os.scandir(directory):
            pass
        self.persist(directory, self.recent)
        self.directory = directory

    def remember(self, path):
        path = canonical(path)
        self.recent = [path] + [p for p in self.recent if p != path]
        self.recent = self.recent[:100]
        self.persist(self.directory, self.recent)

    def files(self, current=None):
        paths = {p for p in self.recent if Path(p).is_file() and (not self.portable or Path(p).resolve().is_relative_to(self.directory.resolve()))}
        if self.directory.exists():
            for path in self.directory.rglob("*"):
                if (
                    path.suffix.lower() == ".json"
                    and path.is_file()
                    and not any(p.startswith(".") or p.endswith("_backups") for p in path.relative_to(self.directory).parts[:-1])
                    and not path.is_symlink()
                    and path.resolve() != self.state_path
                ):
                    paths.add(canonical(path))
        if current and Path(current).is_file():
            paths.add(canonical(current))
        return sorted(
            paths,
            key=lambda p: (
                Path(p).parent != self.directory,
                Path(p).stem.casefold(),
                p,
            ),
        )

    def ensure_directory(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        return self.directory
