"""Simple linetypes supplied with AutoCAD's standard LIN libraries."""

FAMILIES = {
    'BORDER':('境界線','━ ━ · ━ ━ ·'), 'CENTER':('中心線（一点鎖線）','━━ · ━━ ·'),
    'DASHDOT':('一点鎖線','━ · ━ ·'), 'DASHED':('破線','━ ━ ━ ━'),
    'DIVIDE':('二点鎖線','━━ · · ━━'), 'DOT':('点線','· · · · ·'),
    'HIDDEN':('隠れ線','─ ─ ─ ─'), 'PHANTOM':('想像線','━━ ─ ─ ━━'),
}
EXTRA = {
    **{f'ACAD_ISO{i:02d}W100':(label,pattern) for i,label,pattern in [(2,'ISO 破線','─ ─ ─'),(3,'ISO 長間隔破線','─   ─   ─'),(4,'ISO 長破線・点','━━ · ━━'),(5,'ISO 長破線・2点','━━ · · ━━'),(6,'ISO 長破線・3点','━━ · · ·'),(7,'ISO 点線','· · · ·'),(8,'ISO 長短破線','━━ ─ ━━'),(9,'ISO 長破線・2短破線','━━ ─ ─'),(10,'ISO 破線・点','─ · ─ ·'),(11,'ISO 2破線・点','─ ─ ·'),(12,'ISO 破線・2点','─ · ·'),(13,'ISO 2破線・2点','─ ─ · ·'),(14,'ISO 破線・3点','─ · · ·'),(15,'ISO 2破線・3点','─ ─ · · ·')]},
    'FENCELINE1':('フェンス（円）','─ ○ ─ ○ ─'),
    'FENCELINE2':('フェンス（四角）','─ □ ─ □ ─'),
    'TRACKS':('軌道','─ ┼ ─ ┼ ─'),
    'BATTING':('断熱材','∿∿∿∿'),
    'HOT_WATER_SUPPLY':('温水配管','─ HW ─ HW ─'),
    'GAS_LINE':('ガス配管','─ GAS ─ GAS ─'),
    'ZIGZAG':('ジグザグ','╱╲╱╲╱╲'),
}
STANDARD_NAMES = frozenset([name+suffix for name in FAMILIES for suffix in ('','2','X2')]+list(EXTRA))


def choose_standard_linetypes(parent, existing):
    import tkinter as tk
    from tkinter import ttk
    from table_grid import GridTreeview
    from theme import fit_window
    win=tk.Toplevel(parent);win.title('AutoCAD標準線種から追加');win.transient(parent);win.grab_set()
    fit_window(win,760,640,620,500)
    frame=ttk.Frame(win,padding=12);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='AutoCAD標準線種',style='Section.TLabel').pack(anchor='w')
    ttk.Label(frame,text='CAD初期設定がONの場合、未登録の線種だけをSCR冒頭で読み込みます。Continuousは常時選択できます。',wraplength=680,style='Muted.TLabel').pack(fill='x',pady=(6,8))
    library=tk.StringVar(value='メートル系（acadiso.lin）')
    ttk.Combobox(frame,textvariable=library,values=('メートル系（acadiso.lin）','インチ系（acad.lin）'),state='readonly').pack(fill='x',pady=(0,8))
    search=tk.StringVar();entry=ttk.Entry(frame,textvariable=search);entry.pack(fill='x',pady=(0,8))
    from entry_hints import add_entry_hint
    add_entry_hint(entry,search,'線種名・用途で検索')
    body=ttk.Frame(frame);body.pack(fill='both',expand=True)
    tree=GridTreeview(body,columns=('name','pattern','description'),show='tree headings',selectmode='none',height=10)
    tree.heading('#0',text='追加');tree.column('#0',width=45,stretch=False)
    for key,title,width in [('name','線種名',150),('pattern','イメージ',180),('description','用途・倍率',230)]:
        tree.heading(key,text=title);tree.column(key,width=width,minwidth=80)
    tree.pack(side='left',fill='both',expand=True)
    scrollbar=ttk.Scrollbar(body,command=tree.yview);scrollbar.pack(side='right',fill='y');tree.configure(yscrollcommand=scrollbar.set)
    selected=set();result=[]
    footer=ttk.Frame(win,padding=12);footer.pack(side='bottom',fill='x',before=frame)
    ttk.Button(footer,text='キャンセル',command=win.destroy).pack(side='left')
    def confirm():
        file='acadiso.lin' if library.get().startswith('メートル') else 'acad.lin'
        result.extend(dict(name=name,file=file,standard=True,existing_only=False) for name in sorted(selected))
        win.destroy()
    add=ttk.Button(footer,text='選択した線種を追加',command=confirm,style='Compact.Primary.TButton');add.pack(side='right')
    def redraw(*_):
        tree.delete(*tree.get_children())
        query=search.get().casefold()
        for family,(description,pattern) in FAMILIES.items():
            for suffix,scale in [('','標準'),('2','0.5倍'),('X2','2倍')]:
                name=family+suffix
                if query and query not in (name+' '+description).casefold():continue
                tree.insert('','end',iid=name,text='☑' if name in selected else '☐',values=(name,pattern,description+' / '+scale+('（登録済み）' if name.casefold() in existing else '')))
        for name,(description,pattern) in EXTRA.items():
            if query and query not in (name+' '+description).casefold():continue
            tree.insert('','end',iid=name,text='☑' if name in selected else '☐',values=(name,pattern,description+('（登録済み）' if name.casefold() in existing else '')))
        add.configure(text=f'選択した線種を追加（{len(selected)}件）',state='normal' if selected else 'disabled')
    def toggle(event):
        name=tree.identify_row(event.y)
        if name:
            if name in selected:selected.remove(name)
            else:selected.add(name)
            redraw()
    tree.bind('<ButtonRelease-1>',toggle);search.trace_add('write',redraw);redraw()
    win.bind('<Escape>',lambda e:win.destroy())
    parent.wait_window(win)
    from command_workbench import restore_parent_grab
    restore_parent_grab(parent)
    return result
