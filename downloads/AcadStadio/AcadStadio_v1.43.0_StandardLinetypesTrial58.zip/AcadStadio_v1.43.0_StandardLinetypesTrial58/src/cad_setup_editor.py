from table_grid import GridTreeview
"""Transactional forms for layer, text/dimension-style and linetype initialization."""

import copy
import tkinter as tk
from tkinter import ttk, messagebox
from cad_setup import SECTIONS, default_setup, validate_setup, initial_macro
from theme import fit_window
from cad_colors import ColorPicker, color_label, color_code, swatch
from dwg_import_editor import DWGImportDialog


LINEWEIGHT_CHOICES = {
    "既定（LWDEFAULT）": "-3",
    **{
        f"{v / 100:.2f} mm": str(v)
        for v in (
            0,
            5,
            9,
            13,
            15,
            18,
            20,
            25,
            30,
            35,
            40,
            50,
            53,
            60,
            70,
            80,
            90,
            100,
            106,
            120,
            140,
            158,
            200,
            211,
        )
    },
}


def display_value(field, value):
    if field == "plot":
        return value
    if field == "color":
        return color_label(value)
    if field == "lineweight":
        return next(
            (
                label
                for label, code in LINEWEIGHT_CHOICES.items()
                if float(code) == float(value)
            ),
            str(value),
        )
    return str(value)


def model_row(key, row):
    result = {
        field: row.get(field, default) if field == "plot" else str(row.get(field, default))
        for field, _, default in SECTIONS[key][1]
        if key != "linetypes" or field != "file"
    }
    if key == "linetypes":
        result.update(file="", existing_only=True)
        if row.get("standard"):result.update(standard=True,file=row["file"],existing_only=False)
        elif row.get("builtin")=="CENTER":result.update(builtin="CENTER",existing_only=False)
    return result



class CadSetupEditor:
    def __init__(self, app):
        self.app = app
        self.data = copy.deepcopy(app.data.get("cad_setup", default_setup()))
        self.data["legacy_make_layers"] = False
        for row in self.data.get("linetypes", []):
            
            if not row.get("standard"):row.update(file="", existing_only=row.get("builtin") != "CENTER")
        self.win = tk.Toplevel(app.root)
        self.win.title("CAD初期設定")
        fit_window(self.win, 1000, 780, 820, 650)
        self.win.transient(app.root)
        self.win.grab_set()
        self.win.bind("<Escape>", lambda e: self.win.destroy())
        self.enabled = tk.BooleanVar(value=self.data.get("enabled", False))
        heading = ttk.Frame(self.win)
        heading.pack(fill="x", padx=14, pady=12)
        ttk.Checkbutton(
            heading,
            text="不足するレイヤー・スタイルを作成する（SCR冒頭に組み込む）",
            variable=self.enabled,
        ).pack(side="left")
        ttk.Button(
            heading, text="DWGから読み込み…", command=lambda: DWGImportDialog(self),
        ).pack(side="right")
        ttk.Label(
            self.win,
            text="既存CADの設定を使う場合はOFFにします。OFFでも名前をフローで選択できます。\nONでは未作成の定義だけを作成し、同名の既存定義は維持します。",
            wraplength=900,
            padding=(14, 0),
            style="Muted.TLabel",
        ).pack(anchor="w")
        footer = ttk.Frame(self.win, padding=14)
        footer.pack(side="bottom", fill="x")
        ttk.Button(footer, text="キャンセル", command=self.win.destroy).pack(
            side="left"
        )
        ttk.Button(footer, text="マクロを確認", command=self.preview).pack(
            side="left", padx=8
        )
        ttk.Button(
            footer, text="設定を確定", style="Primary.TButton", command=self.commit
        ).pack(side="right")
        tabs = ttk.Notebook(self.win)
        tabs.pack(fill="both", expand=True, padx=14, pady=10)
        self.forms = {}
        self.resource_widgets = {}
        for key, (title, fields) in SECTIONS.items():
            if key == "linetypes":
                fields = [field for field in fields if field[0] != "file"]
            self.data.setdefault(key, [])
            page = ttk.Frame(tabs, padding=10)
            tabs.add(page, text=title)
            editor = ttk.Frame(page)
            editor.pack(side="bottom", fill="x")
            variables = {}
            for i, (field, label, default) in enumerate(fields):
                ttk.Label(editor, text=label).grid(row=i, column=0, sticky="w", pady=3)
                var = (
                    tk.BooleanVar(value=default)
                    if field == "plot"
                    else tk.StringVar(value=display_value(field, default))
                )
                if field == "color":
                    widget = ttk.Frame(editor)
                    combo = ttk.Combobox(
                        widget,
                        textvariable=var,
                        values=[color_label(i) for i in range(1, 10)],
                        state="readonly",
                        width=22,
                    )
                    combo.pack(side="left", fill="x", expand=True)
                    chip = tk.Label(widget, width=3, relief="solid", borderwidth=1)
                    chip.pack(side="left", padx=6)

                    def update_chip(*_, variable=var, label=chip):
                        try:
                            label.configure(
                                bg=swatch(int(float(color_code(variable.get()))))
                            )
                        except (ValueError, IndexError):
                            label.configure(bg="#f3f5f9")

                    var.trace_add("write", update_chip)
                    update_chip()
                    ttk.Button(
                        widget,
                        text="色見本…",
                        command=lambda v=var: ColorPicker(self.win, v),
                    ).pack(side="left")
                elif field == "plot":
                    widget = ttk.Checkbutton(
                        editor, text="ON: 印刷する / OFF: 印刷しない", variable=var
                    )
                elif field == "lineweight":
                    widget = ttk.Combobox(
                        editor,
                        textvariable=var,
                        values=list(LINEWEIGHT_CHOICES),
                        state="readonly",
                    )
                elif (key, field) in (
                    ("layers", "linetype"),
                    ("dim_styles", "text_style"),
                    ("dim_styles", "base"),
                ):
                    widget = ttk.Combobox(editor, textvariable=var)
                    self.resource_widgets[(key, field)] = widget
                    widget.configure(postcommand=self.refresh_resources)
                else:
                    widget = ttk.Entry(editor, textvariable=var)
                widget.grid(row=i, column=1, sticky="ew", padx=10, pady=3)
                variables[field] = var
            editor.columnconfigure(1, weight=1)
            actions = ttk.Frame(page, padding=(0, 4))
            actions.pack(fill="x", pady=(0, 6), before=editor)
            if key == "linetypes":
                ttk.Button(actions,text="標準線種から追加…",command=self.add_standard_linetypes,style="Compact.TButton").pack(side="right")
            ttk.Button(
                actions,
                text="入力値を追加 / 更新",
                command=lambda k=key: self.upsert(k),
            ).pack(side="left")
            ttk.Button(
                actions, text="新規入力", command=lambda k=key: self.clear(k)
            ).pack(side="left", padx=8)
            ttk.Button(
                actions, text="選択を削除", command=lambda k=key: self.delete(k)
            ).pack(side="left")
            frame = ttk.Frame(page)
            frame.pack(fill="both", expand=True)
            tree = GridTreeview(
                frame,
                columns=[f[0] for f in fields],
                show="headings",
                selectmode="browse",
                height=5,
            )
            for field, label, default in fields:
                tree.heading(field, text=label)
                tree.column(
                    field,
                    width=180
                    if field == "color"
                    else 210
                    if field == "lineweight"
                    else 100
                    if field == "plot"
                    else 140,
                    minwidth=85,
                    stretch=False,
                )
            tree.grid(row=0, column=0, sticky="nsew")
            ys = ttk.Scrollbar(frame, command=tree.yview)
            xs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
            ys.grid(row=0, column=1, sticky="ns")
            xs.grid(row=1, column=0, sticky="ew")
            tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
            frame.rowconfigure(0, weight=1)
            frame.columnconfigure(0, weight=1)
            from secondary_style import surface
            surface(page, border=True)
            self.forms[key] = (tree, variables)
            tree.bind("<<TreeviewSelect>>", lambda e, k=key: self.select(k))
            self.reload(key)
        self.refresh_resources()
        ttk.Label(
            self.win,
            text="名前は半角・全角スペースに対応。文字スタイルの固定高さは0。線の太さの「既定」はLWDEFAULTの値を使用。印刷OFFでも画面には表示します。LIN・フォントはCAD側で解決できるファイル名を指定。\n文字/寸法スタイルの作成後は、フローのTEXT / DIMLINEARのスタイル欄で選択してください。",
            padding=(14, 0),
            wraplength=930,
            style="Muted.TLabel",
        ).pack(fill="x", before=footer)

    def add_standard_linetypes(self):
        from standard_linetypes import choose_standard_linetypes
        tree,_=self.forms["linetypes"]
        selection=tree.selection()
        original=model_row("linetypes",self.data["linetypes"][int(selection[0])] if selection else {})
        if self.read_values("linetypes")!=original and not self.upsert("linetypes"):return
        rows=choose_standard_linetypes(self.win,{r['name'].casefold() for r in self.data['linetypes']})
        if not rows:return
        trial=copy.deepcopy(self.data)
        for row in rows:
            index=next((i for i,r in enumerate(trial['linetypes']) if r['name'].casefold()==row['name'].casefold()),None)
            if index is None:trial['linetypes'].append(row)
            else:trial['linetypes'][index]=row
        errors=validate_setup(trial)
        if errors:
            messagebox.showerror("標準線種の追加", "\n".join(errors[:10]),parent=self.win);return
        self.data=trial
        self.reload('linetypes');self.refresh_resources()
        if rows:
            tree,_=self.forms['linetypes']
            index=next(i for i,r in enumerate(self.data['linetypes']) if r['name']==rows[-1]['name'])
            tree.selection_set(str(index));self.select('linetypes')

    def reload(self, key):
        tree, variables = self.forms[key]
        tree.delete(*tree.get_children())
        for i, row in enumerate(self.data[key]):
            tree.insert(
                "",
                "end",
                iid=str(i),
                values=[
                    ("する" if row.get(f, default) else "しない")
                    if f == "plot"
                    else display_value(f, row.get(f, default))
                    for f, _, default in SECTIONS[key][1] if key != "linetypes" or f != "file"
                ],
            )
        self.refresh_resources()

    def refresh_resources(self):
        references = {
            ("layers", "linetype"): ("linetypes", ["Continuous", "ByLayer", "ByBlock"]),
            ("dim_styles", "text_style"): ("text_styles", ["", "Standard"]),
            ("dim_styles", "base"): ("dim_styles", ["", "Standard"]),
        }
        for identity, widget in self.resource_widgets.items():
            section, builtins = references[identity]
            excluded = self.forms.get("dim_styles", (None, {}))[1].get("name")
            current = excluded.get() if excluded is not None else ""
            choices = builtins + [
                row["name"]
                for row in self.data.get(section, [])
                if identity != ("dim_styles", "base") or row["name"] != current
            ]
            widget.configure(values=list(dict.fromkeys(choices)))

    def clear(self, key):
        tree, variables = self.forms[key]
        tree.selection_remove(tree.selection())
        for field, _, default in SECTIONS[key][1]:
            if field not in variables: continue
            variables[field].set(display_value(field, default))

    def select(self, key):
        tree, variables = self.forms[key]
        if tree.selection():
            row = self.data[key][int(tree.selection()[0])]
            for field, _, default in SECTIONS[key][1]:
                if field not in variables: continue
                variables[field].set(display_value(field, row.get(field, default)))

    def read_values(self, key):
        _, variables = self.forms[key]
        result = {
            k: v.get()
            if k == "plot"
            else color_code(v.get())
            if k == "color"
            else LINEWEIGHT_CHOICES.get(v.get(), v.get().strip())
            if k == "lineweight"
            else v.get().strip()
            for k, v in variables.items()
        }

        if key == "linetypes":
            result.update(file="", existing_only=True)
            tree, _ = self.forms[key]
            selected=self.data[key][int(tree.selection()[0])] if tree.selection() else {}
            if selected.get("standard") and result["name"].casefold()==selected["name"].casefold():
                result.update(standard=True,file=selected["file"],existing_only=False)
            if tree.selection() and self.data[key][int(tree.selection()[0])].get("builtin") == "CENTER":
                result.update(builtin="CENTER", existing_only=False)
        return result

    def upsert(self, key):
        tree, variables = self.forms[key]
        row = self.read_values(key)
        trial = copy.deepcopy(self.data)
        selection = tree.selection()
        if selection:
            trial[key][int(selection[0])] = row
        else:
            trial[key].append(row)
        errors = validate_setup(trial)
        if errors:
            messagebox.showerror(
                "CAD初期設定の確認", "\n".join(errors[:10]), parent=self.win
            )
            return False
        self.data = trial
        index = int(selection[0]) if selection else len(trial[key]) - 1
        self.reload(key)
        tree.selection_set(str(index))
        return True

    def delete(self, key):
        tree, _ = self.forms[key]
        if tree.selection():
            del self.data[key][int(tree.selection()[0])]
            self.reload(key)
            self.clear(key)

    def finalize_pending(self):
        for key, (tree, variables) in self.forms.items():
            row = self.read_values(key)
            selected = tree.selection()
            original = (
                model_row(key, self.data[key][int(selected[0])])
                if selected
                else model_row(key, {})
            )
            if row != original and not self.upsert(key):
                return False
        self.data["enabled"] = self.enabled.get()
        return True

    def preview(self):
        if self.finalize_pending():
            win = self.app.show_text(
                "初期設定マクロ（組込OFFでも定義を確認）",
                "\n".join(initial_macro(self.data, force=True)),
            )
            win.transient(self.win)
            win.grab_set()
            win.bind(
                "<Destroy>",
                lambda e: self.win.grab_set()
                if e.widget is win and self.win.winfo_exists()
                else None,
            )

    def commit(self):
        if not self.finalize_pending():
            return
        self.app.data["cad_setup"] = copy.deepcopy(self.data)
        self.win.destroy()
        self.app.refresh()
        self.app.status.set(
            "CAD初期設定を反映しました（冒頭マクロ: "
            + ("ON" if self.data["enabled"] else "OFF")
            + "）"
        )
