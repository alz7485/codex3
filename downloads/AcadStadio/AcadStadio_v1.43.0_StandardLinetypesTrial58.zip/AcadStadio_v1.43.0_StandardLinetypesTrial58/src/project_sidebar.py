from ui_icons import standard_toolbar
from table_grid import GridTreeview
"""Project selection and JSON save controls for the project-list window."""

from pathlib import Path
from datetime import datetime
import shutil
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from project_library import canonical


class ProjectSidebar(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, width=220, padding=(0, 0, 8, 0))
        self.app = app
        self.query = tk.StringVar()
        self.folder_text = tk.StringVar()
        self.details = tk.StringVar()
        self.count = tk.StringVar()
        self._signature = None
        self._opening = False
        ttk.Label(self, text="プロジェクト", style="Section.TLabel").pack(
            anchor="w", pady=(0, 8)
        )
        tools = ttk.Frame(self)
        tools.pack(fill="x")
        for i, (text, action) in enumerate(
            (
                ("＋ 新規", app.new),
                ("保存", app.save),
                ("JSONを開く", app.load),
                ("別名で保存", app.save_as),
            )
        ):
            ttk.Button(tools, text=text, command=action).grid(
                row=0, column=i, sticky="ew", padx=(0, 4), pady=(0, 4)
            )
        standard_toolbar(tools, grid=True)
        ttk.Label(self, text="名前で絞り込み", style="Muted.TLabel").pack(
            anchor="w", pady=(6, 2)
        )
        self.search = ttk.Entry(self, textvariable=self.query)
        self.search.pack(fill="x")
        self.query.trace_add("write", lambda *_: self.refresh(force=True))
        frame = ttk.Frame(self)
        frame.pack(fill="both", expand=True, pady=(8, 0))
        self.tree = GridTreeview(frame, show="tree", selectmode="browse", height=8)
        self.tree.column("#0", width=185, minwidth=80)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(frame, command=self.tree.yview)
        ys.grid(row=0, column=1, sticky="ns")
        xs = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.tree.tag_configure("active", foreground="#2463eb")
        self.tree.tag_configure("external", foreground="#67788d")
        self.tree.bind("<ButtonRelease-1>", self.clicked)
        self.tree.bind("<Return>", lambda e: self.open_selected())
        self.tree.bind("<<TreeviewSelect>>", self.describe)
        footer = ttk.Frame(self)
        footer.pack(side="bottom", fill="x", before=frame)
        ttk.Label(footer, textvariable=self.count, style="Muted.TLabel").pack(
            anchor="w", pady=(4, 0)
        )
        self.detail_label = ttk.Label(
            footer, textvariable=self.details, wraplength=205, style="Muted.TLabel"
        )
        self.detail_label.pack(fill="x", pady=(4, 8))
        ttk.Label(footer, text="保存フォルダー", style="Section.TLabel").pack(
            anchor="w"
        )
        self.folder_label = ttk.Label(
            footer, textvariable=self.folder_text, wraplength=205, style="Muted.TLabel"
        )
        self.folder_label.pack(fill="x", pady=(4, 6))
        bottom = ttk.Frame(footer)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Dataを開く" if self.app.project_library.portable else "フォルダー変更", command=self.open_data if self.app.project_library.portable else self.choose_directory).pack(
            side="left"
        )
        ttk.Button(bottom, text="更新", command=lambda: self.refresh(force=True)).pack(
            side="right"
        )
        from secondary_style import surface
        surface(self, border=True)
        self.configure(padding=10)
        self._wrap_width = 205
        self.bind("<Configure>", self.resize_labels)
        ttk.Button(tools,text="フォルダ追加",command=self.create_folder).grid(row=0,column=4,sticky='ew')
        ttk.Button(tools,text="削除",command=self.delete_entry).grid(row=0,column=5,sticky='ew')
        self.tree.bind('<ButtonPress-1>',self.drag_begin,add='+')
        self.tree.bind('<ButtonRelease-1>',self.drag_finish,add='+')
        self.tree.bind('<F2>',self.rename_entry)
        self.tree.bind('<Delete>',lambda e:self.delete_entry())
        self.tree.bind('<Double-1>',lambda e:self.open_selected())
        self.refresh(force=True)
        self._poll_job=self.after(1000,self.poll_files)
        self.bind('<Destroy>',self.stop_poll,add='+')

    def stop_poll(self,event):
        if event.widget is self and self._poll_job:
            self.after_cancel(self._poll_job);self._poll_job=None

    def poll_files(self):
        if self.winfo_ismapped():
            if self.app.path and not Path(self.app.path).exists():
                identity=getattr(self,'_file_identities',{}).get(canonical(self.app.path)) or getattr(self,'_active_file_identity',None)
                found=None
                if identity:
                    for path in self.app.project_library.files():
                        try:
                            st=Path(path).stat()
                            if (st.st_dev,st.st_ino)==identity:found=Path(path);break
                        except OSError:pass
                self.app.path=canonical(found) if found else None
                self.app.update_title()
            self.refresh()
        self._poll_job=self.after(1000,self.poll_files)

    def selected_directory(self):
        selected=self.tree.selection()
        if selected and selected[0]!='unsaved':
            path=Path(selected[0])
            if path.is_dir():return path
            if path.is_file():return path.parent
        return self.app.project_library.ensure_directory()

    def checked_path(self,path):
        path=Path(path)
        root=self.app.project_library.directory.resolve()
        if path.is_symlink() or not path.resolve().is_relative_to(root) or path.resolve()==root:
            raise ValueError('Data内の項目を選択してください')
        return path

    def create_folder(self):
        name=simpledialog.askstring('フォルダを作成','フォルダ名',parent=self.winfo_toplevel())
        if name is None:return
        try:
            if not name.strip() or name in ('.','..') or any(c in name for c in '/\\:*?"<>|') or name.endswith((' ','.')):raise ValueError('使用できないフォルダ名です')
            path=self.checked_path(self.selected_directory()/name)
            path.mkdir()
            self.refresh(force=True);self.tree.selection_set(str(path.resolve()));self.tree.see(str(path.resolve()))
        except (OSError,ValueError) as exc:messagebox.showerror('フォルダを作成できません',str(exc),parent=self.winfo_toplevel())

    def relocate(self,source,destination):
        source=self.checked_path(source);destination=self.checked_path(destination)
        if destination.exists():raise ValueError('移動先に同じ名前があります')
        if destination.resolve().is_relative_to(source.resolve()):raise ValueError('自身の中には移動できません')
        current=Path(self.app.path) if self.app.path else None
        relative=current.resolve().relative_to(source.resolve()) if current and current.resolve().is_relative_to(source.resolve()) else None
        source.rename(destination)
        if relative is not None:self.app.path=canonical(destination/relative);self.app.update_title()
        self.refresh(force=True)

    def rename_entry(self,event=None):
        selected=self.tree.selection()
        if not selected or selected[0]=='unsaved':return
        source=Path(selected[0]);name=simpledialog.askstring('名前を変更','新しい名前',initialvalue=source.stem if source.is_file() else source.name,parent=self.winfo_toplevel())
        if name is None:return
        try:
            if not name.strip() or name in ('.','..') or any(c in name for c in '/\\:*?"<>|') or name.endswith((' ','.')):raise ValueError('使用できない名前です')
            if source.is_file() and not name.lower().endswith('.json'):name+='.json'
            self.relocate(source,source.with_name(name))
        except (OSError,ValueError) as exc:messagebox.showerror('名前を変更できません',str(exc),parent=self.winfo_toplevel())

    def delete_entry(self):
        selected=self.tree.selection()
        if not selected or selected[0]=='unsaved':return
        try:
            path=self.checked_path(selected[0])
            if not messagebox.askyesno('削除',f'{path.name} とその中のデータを実際の保存先から削除しますか？',parent=self.winfo_toplevel()):return
            if self.app.path and Path(self.app.path).resolve().is_relative_to(path.resolve()):
                if self.app.has_unsaved_changes() and not messagebox.askyesno('未保存の変更','未保存の変更も破棄して削除しますか？',parent=self.winfo_toplevel()):return
                from main import EMPTY
                self.app.replace_document(EMPTY)
            if path.is_dir():shutil.rmtree(path)
            else:path.unlink()
            self.refresh(force=True)
        except (OSError,ValueError) as exc:messagebox.showerror('削除できません',str(exc),parent=self.winfo_toplevel())

    def drag_begin(self,event):
        self._drag_source=self.tree.identify_row(event.y)

    def drag_finish(self,event):
        source=getattr(self,'_drag_source','');target=self.tree.identify_row(event.y)
        self._drag_source=''
        if not source or source=='unsaved' or source==target:return
        try:
            folder=Path(target) if target and target!='unsaved' else self.app.project_library.directory
            if not folder.is_dir():folder=folder.parent
            path=Path(source)
            if path.parent.resolve()!=folder.resolve():self.relocate(path,folder/path.name)
        except (OSError,ValueError) as exc:messagebox.showerror('移動できません',str(exc),parent=self.winfo_toplevel())

    def resize_labels(self, event):
        width = max(205, event.width - 12)
        if event.widget is self and width != self._wrap_width:
            self._wrap_width = width
            self.detail_label.configure(wraplength=width)
            self.folder_label.configure(wraplength=width)

    def refresh(self, force=False):
        library = self.app.project_library
        current = canonical(self.app.path) if self.app.path else None
        try:
            paths = library.files(current)
        except OSError as exc:
            self.app.status.set("プロジェクト一覧を読めません: " + str(exc))
            paths = list(
                dict.fromkeys([*library.recent, *([current] if current else [])])
            )
        self._file_identities={}
        for p in paths:
            try:
                st=Path(p).stat();self._file_identities[p]=(st.st_dev,st.st_ino)
            except OSError:pass
        if current in self._file_identities:self._active_file_identity=self._file_identities[current]
        query = self.query.get().strip().casefold()
        visible = [p for p in paths if query in Path(p).stem.casefold()]
        directories=sorted((p for p in library.directory.rglob('*') if p.is_dir() and not p.is_symlink() and not any(q.startswith('.') or q.endswith('_backups') for q in p.relative_to(library.directory).parts)),key=lambda p:(len(p.parts),str(p).casefold())) if library.directory.exists() else []
        dirty = self.app.has_unsaved_changes()
        signature = (
            tuple(visible),tuple(str(p) for p in directories),
            current,
            dirty,
            self.app.document_name,
            str(library.directory),
        )
        if signature == self._signature and not force:
            return
        self._signature = signature
        old = self.tree.selection()
        expanded={n for n in self.all_nodes() if self.tree.item(n,"open")}
        self.tree.delete(*self.tree.get_children())
        if not current:
            self.tree.insert(
                "",
                "end",
                iid="unsaved",
                text=("● " if dirty else "") + self.app.document_name + "（未保存）",
                tags=("active",),
            )
        for folder in directories:
            identity=str(folder.resolve());parent=str(folder.parent.resolve()) if folder.parent!=library.directory else ''
            self.tree.insert(parent,'end',iid=identity,text=folder.name,image=self.app.icons.get('folder'),open=identity in expanded)
        for path in visible:
            external = not Path(path).resolve().is_relative_to(library.directory.resolve())
            label = Path(path).stem + ("（外部）" if external else "")
            if path == current:
                label = ("● " if dirty else "▶ ") + label
            self.tree.insert(
                str(Path(path).parent.resolve()) if not external and Path(path).parent!=library.directory else "",
                "end",
                iid=path,
                text=label,
                tags=("active",)
                if path == current
                else ("external",)
                if external
                else (),
            )
        preferred = current or "unsaved"
        if force and old and self.tree.exists(old[0]):
            preferred = old[0]
        if self.tree.exists(preferred):
            self.tree.selection_set(preferred)
            self.tree.see(preferred)
        folder = str(library.directory)
        self.folder_text.set(folder if len(folder) <= 100 else "…" + folder[-99:])
        self.count.set(
            f"{len(visible)}件のJSON"
            + ("（絞り込み中）" if query else "")
            + " · ● 未保存の変更"
        )
        self.describe()

    def all_nodes(self,parent=""):
        for node in self.tree.get_children(parent):
            yield node
            yield from self.all_nodes(node)

    def describe(self, *_):
        selected = self.tree.selection()
        if not selected or selected[0] == "unsaved":
            self.details.set(
                "「保存」でJSONファイルを作成します。" if not self.app.path else ""
            )
        else:
            path = Path(selected[0])
            if path.is_dir():
                self.details.set("フォルダ："+path.name+"\nドラッグで項目を移動できます。F2で名前を変更。")
                return
            try:
                stamp = datetime.fromtimestamp(path.stat().st_mtime).strftime(
                    "%Y/%m/%d %H:%M"
                )
                text = "更新: " + stamp
                if path.parent != self.app.project_library.directory:
                    folder = str(path.parent)
                    text += "\n" + (folder if len(folder) <= 90 else "…" + folder[-89:])
                self.details.set(text)
            except OSError:
                self.details.set(
                    "ファイルが見つかりません。移動先のJSONを開いてください。"
                )

    def clicked(self, event):
        if getattr(self,"_drag_source",None) and self._drag_source!=self.tree.identify_row(event.y):return
        if self.tree.identify_row(event.y):
            self.open_selected()

    def open_selected(self):
        selected = self.tree.selection()
        if self._opening or not selected or selected[0] == "unsaved":
            return
        path = selected[0]
        if Path(path).is_dir():return
        if self.app.path and canonical(self.app.path) == path:
            return
        self._opening = True
        try:
            if not self.app.open_project(path):
                current = canonical(self.app.path) if self.app.path else "unsaved"
                if self.tree.exists(current):
                    self.tree.selection_set(current)
                self.describe()
        finally:
            self._opening = False

    def open_data(self):
        import os,sys,subprocess
        try:
            path=self.app.project_library.ensure_directory()
            if sys.platform=="win32":os.startfile(path)
            else:subprocess.Popen(["open" if sys.platform=="darwin" else "xdg-open",str(path)])
        except OSError as exc:messagebox.showerror("Dataを開けません",str(exc),parent=self.winfo_toplevel())

    def choose_directory(self):
        path = filedialog.askdirectory(
            parent=self.winfo_toplevel(),
            title="プロジェクトJSONの保存フォルダー",
            initialdir=str(self.app.project_library.directory),
        )
        if not path:
            return
        try:
            self.app.project_library.select_directory(path)
        except (OSError, ValueError) as exc:
            return messagebox.showerror(
                "保存フォルダーを変更できません", str(exc), parent=self.winfo_toplevel()
            )
        self.refresh(force=True)
        self.app.status.set("プロジェクトの保存フォルダーを変更しました。")
