from workbench_style import paint_card, SegmentedChoice, PointResultCard, VerticalForm
from arc_modes import MODES as ARC_MODES
from vertex_points import read_vertices, points_text, vertex_id, MAX_VERTICES
from guide_blocks import copy_to_guide, forward_links, confirm_reference_order
from point_preview_ui import PointReferencePreview
from command_points import read_point_reference, POINTS, new_id, reference, clone_commands, rewrite_references
from table_grid import GridTreeview
"""Transactional preset/block editors and nested IF/REPEAT command forms."""

from project_data import get_rows
import copy
import tkinter as tk
from tkinter import ttk, messagebox, font
from engine import compile_project, parse_expression, MacroError, polyline_expressions
from command_types import DRAWING_TYPES, DIMENSION_TYPES, COMMAND_GROUPS
from project_model import validate_project, validate_sequential_project, walk_commands, valid_name
from preview import DrawingCanvas
from theme import fit_window
from cad_setup import STYLE_FIELDS, names as resource_names
from expression_sample import sample_value
from block_model import index_of, replace_collection
from input_assist import reference_groups, show_condition_builder, show_table_reference_picker
from cad_colors import ColorPicker, entity_color_code, entity_color_label, swatch
from ui_icons import icons_for, ICONS, layout_icon_toolbar
from entry_hints import add_entry_hint
from reference_colors import add_reference_color

def field_label(parent, **kwargs):
    width=kwargs.get('width')
    if width and 'wraplength' not in kwargs:
        kwargs['wraplength']=max(40,font.nametofont('TkDefaultFont').measure('0')*width-4)
    return ttk.Label(parent,**kwargs)


FIELDS = {
    "LINE": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y"),
    ],
    "CIRCLE": [("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "@OD / 2")],
    "RECTANGLE": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y + 50"),
    ],
    "TEXT": [
        ("layer", ""),
        ("x", "@X"),
        ("y", "@Y"),
        ("height", "settings.TEXT_HEIGHT"),
        ("angle", "0"),
        ("text", "@TYPE"),
    ],
    "DIMLINEAR": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y"),
        ("x3", "@X + 50"),
        ("y3", "@Y + 30"),
    ],
    "SET": [("name", "VALUE"), ("value", "0")],
    "IF": [("condition", '@TYPE == "A"')],
    "REPEAT": [("count", "3")],
    "SYSVAR": [
        ("name", "OSMODE"),
        ("value_kind", "number"),
        ("value", "0"),
        ("execution", "per_row"),
    ],
    "CUSTOM": [],
}
FIELDS.update(
    POLYLINE=[("layer", ""), ("points", "@X,@Y; @X+100,@Y"), ("closed", "0")],
    ARC=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("start_angle", "0"), ("end_angle", "90")],
    ELLIPSE=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("rx", "40"), ("ry", "20"), ("angle", "0")],
    POINT=[("layer", ""), ("x", "@X"), ("y", "@Y")],
    DIMALIGNED=list(FIELDS["DIMLINEAR"]),
    DIMRADIUS=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("x3", "@X+40"), ("y3", "@Y+30")],
    DIMDIAMETER=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("x3", "@X+40"), ("y3", "@Y+30")],
)
TYPE_LABELS = {
    "LINE": "LINE · 線分",
    "POLYLINE": "POLYLINE · ポリライン",
    "ARC": "ARC · 円弧",
    "ELLIPSE": "ELLIPSE · 楕円",
    "POINT": "POINT · 点",
    "DIMALIGNED": "DIMALIGNED · 平行寸法",
    "DIMRADIUS": "DIMRADIUS · 半径寸法",
    "DIMDIAMETER": "DIMDIAMETER · 直径寸法",
    "CIRCLE": "CIRCLE · 円",
    "RECTANGLE": "RECTANGLE · 長方形",
    "TEXT": "TEXT · 文字",
    "DIMLINEAR": "DIMLINEAR · 長さ寸法",
    "SET": "SET · 旧形式の変数代入",
    "IF": "IF / ELSE · 条件分岐",
    "REPEAT": "REPEAT · 繰り返し",
    "SYSVAR": "SYSVAR · システム変数変更",
    "CUSTOM": "登録済みコマンド",
}
LABELS = {
    "diameter": "直径",
    "text_style": "文字スタイル",
    "dim_style": "寸法スタイル",
    "linetype": "線種",
    "color": "色（ACI）",
    "linetype_scale": "線種尺度（個別）",
    "points": "頂点（X,Y; X,Y; …）",
    "closed": "閉じる（0/1）",
    "rx": "長軸半径",
    "ry": "短軸半径",
    "start_angle": "開始角度（°）",
    "end_angle": "終了角度（°）",
    "layer": "レイヤー",
    "x": "中心 / 挿入 X",
    "y": "中心 / 挿入 Y",
    "x1": "始点 X",
    "y1": "始点 Y",
    "x2": "終点 X",
    "y2": "終点 Y",
    "x3": "寸法位置 X",
    "y3": "寸法位置 Y",
    "r": "半径",
    "height": "文字高さ",
    "angle": "回転角度（°）",
    "text": "文字列",
    "name": "名前",
    "value": "代入する式",
    "condition": "実行条件（式）",
    "count": "反復回数（式）",
    "value_kind": "値の種類",
    "execution": "実行回数",
}


def command_summary(cmd):
    typ = cmd.get("type", "?").upper()
    if typ == "IF":
        return f"{cmd.get('condition', '')}  → {len(cmd.get('commands', []))}件 / ELSE {len(cmd.get('else', []))}件"
    if typ == "REPEAT":
        return f"{cmd.get('count', '')} 回 × {len(cmd.get('commands', []))}件"
    hidden = {"type", "commands", "else", "point_id", "guide_origin", "vertices"}
    prefix = ""
    if typ in ("LINE", "POLYLINE") and "vertices" in cmd:
        points = read_vertices(cmd)
        start, end = points[0], points[-1]
        prefix = f"{len(points)}点: ({start['x']}, {start['y']}) → ({end['x']}, {end['y']})"
        hidden.update(("x1", "y1", "x2", "y2", "points"))
    detail = ", ".join(
        f"{LABELS.get(k, k)}: {v}"
        for k, v in cmd.items()
        if k not in hidden
    )
    return ", ".join(part for part in (prefix, detail) if part)


def edit_command(
    parent, current, blocks, project=None, local_names=(), *, sample_locals=None,
    folder_id="", point_sources=(), previous_blocks=(), owner_block_id=None, allow_continue=False,
):
    if current.get("type", "LINE").upper() not in FIELDS:
        messagebox.showerror("コマンドの確認", "このコマンドは追加・編集できません", parent=parent)
        return None
    win = tk.Toplevel(parent)
    win.title("コマンドの設定")
    fit_window(win, 1320, 860, 980, 620)
    win.transient(parent.winfo_toplevel())
    win.grab_set()
    working = copy.deepcopy(current)
    result = []
    queued = []
    point_sources = list(point_sources)
    live = [None]
    selecting = [None]
    refresh_job = [None]
    redrawing = [True]
    batching = [False]
    undo_stack, redo_stack = [], []
    history_current = [None]
    mode_drafts = {}
    pending_point_ids = {}
    external_point_ids = {}
    point_labels = {cmd['point_id']: f"コマンド{i+1}" for i,cmd in enumerate(point_sources) if cmd.get('point_id')}
    if isinstance(blocks,list):
        for block in blocks:
            for ci,command in enumerate(block.get("commands",[])):
                if command.get("point_id"):
                    point_labels[block["id"]+"/"+command["point_id"]]=f"{block['name']} / コマンド{ci+1}"
    source_defs = []
    for bi, block in enumerate(previous_blocks):
        for ci, command in enumerate(block.get("commands", [])):
            if command.get("type") in POINTS:
                descriptor=dict(command=command,block_index=bi,command_index=ci,block_id=block["id"],local=False,
                                label=f"{block['name']} / コマンド{ci+1}")
                source_defs.append(descriptor)
                if command.get("point_id"):
                    point_labels[block["id"]+"/"+command["point_id"]]=descriptor["label"]
    for ci, command in enumerate(point_sources):
        if command.get("type") in POINTS:
            source_defs.append(dict(command=command,block_index=len(previous_blocks),command_index=ci,block_id="",local=True,label=f"コマンド{ci+1}"))
    entries = {}
    win.command_entries = entries
    variables = {}
    argument_vars = {}
    selected_custom = [current.get("name", "")]
    focused = [None]
    old_type = current.get("type", "LINE").upper()
    drafts = {old_type: copy.deepcopy(current)}
    choice = tk.StringVar(value=TYPE_LABELS.get(old_type, TYPE_LABELS["LINE"]))
    guide_owner=isinstance(blocks,list) and any(b.get('id')==owner_block_id and b.get('guide') for b in blocks)
    kind_groups=tuple((label,tuple(k for k in kinds if not guide_owner or k in DRAWING_TYPES)) for label,kinds in COMMAND_GROUPS if not guide_owner or any(k in DRAWING_TYPES for k in kinds))
    header = ttk.Frame(win, padding=(12, 8))
    header.pack(fill="x")
    picker = ttk.Combobox(
        header,
        textvariable=choice,
        values=[TYPE_LABELS[kind] for _, kinds in kind_groups for kind in kinds],
        state="readonly",
        width=20,
    )
    picker.pack(side="left")
    win.command_picker = picker
    mode_host = ttk.Frame(header)
    mode_host.pack(side="left", padx=(12, 0))
    body = ttk.Frame(win, padding=(12, 0))
    body.pack(fill="both", expand=True)
    body.columnconfigure(0, weight=5, minsize=390)
    body.columnconfigure(1, weight=7)
    body.rowconfigure(0, weight=1)
    left = ttk.Frame(body)
    left.pack_propagate(False)
    left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
    viewport = tk.Canvas(left, highlightthickness=0, bg="#f3f5f9")
    scroll = ttk.Scrollbar(left, command=viewport.yview)
    viewport.pack(side="left", fill="both", expand=True)

    def update_scroll(first, last):
        scroll.set(first, last)
        if selecting[0] is not None:
            scroll.pack_forget();return
        bounds=viewport.bbox('all')
        fits=bounds is not None and bounds[3]-bounds[1]<=viewport.winfo_height()
        if fits or (float(first) <= 0 and float(last) >= 1):
            if fits and float(first)>0:viewport.yview_moveto(0)
            if scroll.winfo_manager():
                scroll.pack_forget()
        elif not scroll.winfo_manager():
            scroll.pack(side="right", fill="y", before=viewport)

    viewport.configure(yscrollcommand=update_scroll)
    win.command_scrollbar, win.command_viewport = scroll, viewport
    form = ttk.Frame(viewport)
    form_window = viewport.create_window(0, 0, window=form, anchor="nw")
    viewport.bind(
        "<Configure>", lambda e: viewport.itemconfigure(form_window, width=e.width)
    )
    def form_changed(event=None):
        viewport.configure(scrollregion=viewport.bbox('all'))
        update_scroll(*viewport.yview())
    form.bind('<Configure>',form_changed)


    refs = ttk.LabelFrame(win, text="参照一覧・式の試算", padding=10)
    refs.columnconfigure(0, weight=1)
    refs.rowconfigure(2, weight=1)
    ttk.Label(
        refs,
        text="入力欄を選び、候補をダブルクリック",
        style="Muted.TLabel",
        wraplength=250,
    ).grid(row=0, column=0, sticky="w")
    query = tk.StringVar()
    ttk.Entry(refs, textvariable=query).grid(row=1, column=0, sticky="ew", pady=7)
    listing = tk.Listbox(
        refs,
        exportselection=False,
        relief="flat",
        bg="white",
        activestyle="none",
        height=10,
    )
    listing.grid(row=2, column=0, sticky="nsew")
    project = project or {}
    sample_frame = ttk.LabelFrame(refs, text="選択した入力欄の試算", padding=8)
    sample_frame.grid(row=5, column=0, sticky="ew", pady=(6, 0))
    sample_row = tk.StringVar(value="1")
    sample_picker = ttk.Combobox(
        sample_frame,
        textvariable=sample_row,
        values=[str(i + 1) for i in range(len(get_rows(project)))],
        state="readonly",
        width=8,
    )
    ttk.Label(sample_frame, text="試算する行:").pack(side="left")
    sample_picker.pack(side="left", padx=5)
    sample_result = tk.StringVar(value="数値・条件の入力欄を選択してください")
    ttk.Label(refs, textvariable=sample_result, wraplength=250).grid(
        row=6, column=0, sticky="ew", pady=6
    )
    # Expose state for keyboard/accessibility tooling and real-widget regression tests.
    win.sample_result, win.sample_row = sample_result, sample_row

    def update_sample(*_):
        key = next((k for k, widget in entries.items() if widget is focused[0]), None)
        var = variables.get(key)
        if key and key.startswith("arg:"):
            var = argument_vars.get(key[4:])
            kind = next(
                (
                    p["kind"]
                    for p in project.get("custom_commands", {})
                    .get(selected_custom[0], {})
                    .get("parameters", [])
                    if p["name"] == key[4:]
                ),
                "text",
            )
            if kind != "number":
                sample_result.set("文字引数です。数値欄を選ぶと試算できます。")
                return
        if key in STYLE_FIELDS:
            sample_result.set(
                "空欄は直前の設定を引き継ぎます。先頭ではCADの現在の設定を使います。"
            )
            return
        if key in ("name", "text", "execution", "value_kind") or var is None:
            sample_result.set("数値・条件の入力欄を選択してください")
            return
        text = var.get().strip()
        if "点(" in text or "点位置(" in text:
            sample_result.set("点参照の値はブロックのプレビューで確認できます")
            return
        if key == "color":
            text = entity_color_code(text)
        if key in ("color", "linetype_scale") and not text:
            sample_result.set("空欄は直前の設定を引き継ぎます。先頭ではCADの現在値を使います。")
            return
        if not text and key == "condition":
            sample_result.set("条件なし: 常に実行")
            return
        if (
            key == "value"
            and active[0] == "SYSVAR"
            and variables.get("value_kind").get() == "text"
        ):
            sample_result.set("文字列の値です")
            return
        try:
            if key == "points":
                points = polyline_expressions(text)
                shown = [tuple(sample_value(project, expression, max(0, int(sample_row.get())-1), sample_locals) for expression in point) for point in points[:3]]
                sample_result.set(f"{len(points)}頂点: {shown}" + (" …" if len(points) > 3 else ""))
                return
            value = sample_value(
                project, text, max(0, int(sample_row.get()) - 1), sample_locals
            )
            rendered = f"{value:.12g}" if type(value) in (int, float) else str(value)
            sample_result.set(
                f"{sample_row.get()}行目 → {rendered}\n繰り返しの値は実行時に確定します。"
            )
        except (MacroError, ValueError, IndexError) as exc:
            sample_result.set("試算できません: " + str(exc))

    def focus_sample(event):
        focused[0] = event.widget
        update_sample()
        focus_marker()

    sample_row.trace_add("write", update_sample)
    sample_row.trace_add("write", lambda *_: schedule_preview())
    ref_groups = reference_groups(project, local_names)
    candidates = [ref for _, group in ref_groups for ref in group]

    def filter_refs(*_):
        listing.delete(0, "end")
        for ref in dict.fromkeys(candidates):
            if query.get().lower() in ref.lower():
                listing.insert("end", ref)

    query.trace_add("write", filter_refs)
    filter_refs()

    def scene_blocks():
        earlier=list(copy.deepcopy(previous_blocks))
        for (bi,ci),identity in external_point_ids.items():earlier[bi]['commands'][ci]['point_id']=identity
        prefix=copy.deepcopy(point_sources)
        for index,identity in pending_point_ids.items():
            if index<len(prefix):prefix[index]['point_id']=identity
        return earlier+[dict(id=owner_block_id or 'command_preview',name='編集中ブロック',commands=prefix+[gather()],guide=any(b.get('id')==owner_block_id and b.get('guide') for b in blocks) if isinstance(blocks,list) else False)]

    def capture_state():
        return copy.deepcopy((gather(),pending_point_ids,external_point_ids,point_labels))

    def record_edit(*_):
        if redrawing[0] or batching[0]:return
        state=capture_state()
        if history_current[0] is not None and state!=history_current[0]:
            undo_stack.append(history_current[0]);del undo_stack[:-100];redo_stack.clear()
        history_current[0]=state
        schedule_preview()

    def restore_state(state):
        working.clear();working.update(copy.deepcopy(state[0]));active[0]=working['type'];choice.set(TYPE_LABELS[active[0]])
        for target,data in zip((pending_point_ids,external_point_ids,point_labels),state[1:]):target.clear();target.update(copy.deepcopy(data))
        redraw(False);history_current[0]=capture_state();schedule_preview()

    def undo_draft(event=None):
        if selecting[0] is not None:return 'break'
        if undo_stack:
            redo_stack.append(capture_state());restore_state(undo_stack.pop())
        return 'break'

    def redo_draft(event=None):
        if selecting[0] is not None:return 'break'
        if redo_stack:
            undo_stack.append(capture_state());restore_state(redo_stack.pop())
        return 'break'
    win.undo_draft=undo_draft;win.redo_draft=redo_draft
    win.bind('<Control-z>',undo_draft);win.bind('<Control-y>',redo_draft)

    def schedule_preview(*_):
        if redrawing[0] or selecting[0] is not None:return
        if refresh_job[0]:win.after_cancel(refresh_job[0])
        refresh_job[0]=win.after(130,refresh_preview)

    def refresh_preview():
        if refresh_job[0]:win.after_cancel(refresh_job[0])
        refresh_job[0]=None
        if live[0] is None or not win.winfo_exists() or selecting[0] is not None:return
        visual=live[0]
        visual.preview_blocks=scene_blocks
        visual.source_refs=source_defs+[dict(label='編集中',block_index=len(previous_blocks),command_index=len(point_sources))]
        visual.canvas.on_source=lambda i:None
        visual.on_pick=focus_point;visual.canvas.on_pick=focus_point
        visual.row.set(sample_row.get());visual.load(len(source_defs))
        visual.status.set(visual.warning if visual.warning else 'このコマンドは図形を作成しません' if active[0] == 'SYSVAR' else '設定はSCRに出力します。プレビューには反映しません。' if active[0] == 'CUSTOM' else '')
        update_field_results()
        focus_marker()

    def focus_point(name):
        key=next((k for k,title in point_titles.items() if title==name),None)
        if key and key in entries:entries[key].focus_set();focused[0]=entries[key];focus_marker()

    def focus_marker():
        if live[0] is None or selecting[0] is not None:return
        key=next((k for k,e in entries.items() if e is focused[0]),'')
        name=point_titles.get('x'+key[1:],'')
        for suffix,card in coordinate_cards.items():paint_card(card,bool('x'+suffix=='x'+key[1:] and name))
        visual=live[0];visual.canvas.selected_point=name;visual.canvas.shifted_point=None;visual.canvas.draw_markers()

    def update_field_results():
        from command_workbench import evaluated_fields
        try:values=evaluated_fields(project,scene_blocks(),live[0].canvas.items,int(sample_row.get())-1,sample_locals)
        except (MacroError,ValueError,KeyError,TypeError):values={}
        for key,label in field_results.items():
            value_var = argument_vars[key[4:]] if key.startswith("arg:") else variables[key]
            text=value_var.get().strip()
            try:
                float(text);shown=''
            except ValueError:
                try:
                    raw=rewrite_references(text,{v:k for k,v in point_labels.items()})
                    from engine import evaluate
                    value=evaluate(raw,values)
                    shown='= '+(f'{value:.12g}' if type(value) in (int,float) else str(value))
                except (MacroError,ValueError,KeyError,TypeError):shown='入力を確認' if text else ''
            label.configure(text=shown)
            if shown:label.pack(anchor='w',padx=(16,0),pady=(2,0))
            else:label.pack_forget()
        for suffix,label in reference_summaries.items():
            refs=[]
            for axis in ('x','y'):
                parsed=read_point_reference(variables[axis+suffix].get())
                if parsed:refs.append((axis.upper(),point_labels.get(parsed['identity'],parsed['identity'])+' / '+parsed['point']))
            label.configure(text=('↗ '+refs[0][1]+' · XY  ✎') if len(refs)==2 and refs[0][1]==refs[1][1] else '   '.join(axis+': '+name for axis,name in refs))
            if refs:label.pack(fill='x',pady=(3,0))
            else:label.pack_forget()
        markers={}
        if any(item.get('block_index',item.get('preset_index',0))==len(previous_blocks) and item.get('command_index')==len(point_sources) for item in live[0].canvas.items):
            for key,title in point_titles.items():
                try:
                    from engine import evaluate
                    raw=[rewrite_references(variables[axis+key[1:]].get(),{v:k for k,v in point_labels.items()}) for axis in ('x','y')]
                    markers[title]=tuple(float(evaluate(expression,values)) for expression in raw)
                except (MacroError,ValueError,KeyError,TypeError):pass
            live[0].canvas.snap_points=markers

    def place_ref(entry, key, value, replace=False):
        if entry is None or not entry.winfo_exists():
            return
        batching[0]=True
        if replace:
            entry.delete(0, "end")
        param_kind = next(
            (
                p["kind"]
                for p in project.get("custom_commands", {})
                .get(selected_custom[0], {})
                .get("parameters", [])
                if "arg:" + p["name"] == key
            ),
            None,
        )
        is_sysvar_text = (
            key == "value"
            and active[0] == "SYSVAR"
            and variables.get("value_kind") is not None
            and variables["value_kind"].get() == "text"
        )
        if (
            key in ("text", "layer") or param_kind == "text" or is_sysvar_text
        ) and not entry.get():
            if key == "text" and value.startswith("@"):
                pass
            else:
                entry.insert(0, "=")
        if entry.selection_present():
            entry.delete(tk.SEL_FIRST, tk.SEL_LAST)
        entry.insert(tk.INSERT, value)
        entry.focus_set()
        batching[0]=False;record_edit()

    def choose_command_point(key, both=False):
        is_argument = key.startswith("arg:")
        param = next((p for p in project.get("custom_commands", {}).get(selected_custom[0], {}).get("parameters", []) if "arg:"+p["name"] == key), {})
        suffix = key[1:]
        xkey, ykey = "x"+suffix, "y"+suffix
        if not is_argument and (xkey not in variables or ykey not in variables):
            return
        candidates=list(enumerate(source_defs))
        if not candidates:
            messagebox.showinfo("コマンドの点", "前の作図ブロック、または同じリストで、このコマンドより前に線・円などを追加してください。", parent=win)
            return
        if selecting[0] is not None:return
        dialog=ttk.Frame(left)
        viewport.pack_forget();scroll.pack_forget()
        dialog.pack(fill='both',expand=True)
        selecting[0]=dialog
        normal_bar.pack_forget()
        buttons=ttk.Frame(win,padding=(12,10));buttons.pack(side='bottom',fill='x',before=body)
        dialog.action_bar=buttons
        selection_scroll=VerticalForm(dialog);selection_scroll.pack(fill='both',expand=True)
        dialog.selection_scroll=selection_scroll
        area=ttk.Frame(selection_scroll.content,padding=(4,8));area.pack(fill='x')
        picker.configure(state='disabled')
        for frame in mode_host.winfo_children():
            for child in frame.winfo_children():
                if isinstance(child,ttk.Combobox):child.configure(state='disabled')
        win.point_panel=dialog
        visual=None
        ttk.Label(area,text="入力先: "+(point_titles.get(xkey,field_caption(key)) if not is_argument else param.get('label',key)),style="Section.TLabel").pack(anchor="w",pady=(0,8))
        source_card=ttk.Frame(area,style='PointCard.TFrame',padding=10)
        source_card.pack(fill='x',pady=(0,10))
        ttk.Label(source_card,text='参照元のコマンド',style='CardTitle.TLabel').pack(anchor='w',pady=(0,6))
        source=ttk.Combobox(source_card,state="readonly",values=[d['label']+' · '+TYPE_LABELS[d['command']['type']].split(' · ')[-1] for i,d in candidates])
        source.pack(fill="x",pady=(6,12));source.current(0)
        ttk.Label(source_card,text='使用する点',style='CardMuted.TLabel').pack(anchor='w')
        point=ttk.Combobox(source_card,state="readonly")
        point_segments=SegmentedChoice(source_card,point);point_segments.pack(fill="x",pady=6)
        def sync(*_):
            point.configure(values=POINTS[candidates[source.current()][1]['command']['type']]);point.current(0);point_segments.sync()
            if visual is not None:
                visual.load(candidates[source.current()][0]);update_visual()
        source.bind("<<ComboboxSelected>>",sync);sync()
        combined = is_argument and param.get("kind") == "text"
        axis = None
        offsets = {}
        axis_segments=None
        result_card=[None]
        coordinate_card=ttk.Frame(area,style='PointCard.TFrame',padding=10)
        coordinate_card.pack(fill='x',pady=(0,10))
        ttk.Label(coordinate_card,text='移動量' if combined else '取得する座標',style='CardTitle.TLabel').pack(anchor='w',pady=(0,6))
        if not combined:
            axis=ttk.Combobox(coordinate_card,state='readonly',values=('X','Y') if is_argument else ('XY','X','Y'))
            axis.set('X' if is_argument else 'XY' if both else key[0].upper())
            dialog.axis_picker=axis
            axis_segments=SegmentedChoice(coordinate_card,axis);axis_segments.pack(fill='x',pady=4)
        if not combined:ttk.Label(coordinate_card,text='移動量',style='CardMuted.TLabel').pack(anchor='w',pady=(7,0))
        shifts_area=ttk.Frame(coordinate_card,style='Card.TFrame')
        shifts_area.pack(fill='x',pady=(4,0))
        offset_rows={}
        offset_entries={}
        active_offset=["X"]
        shifts_area.columnconfigure((0,1),weight=1,uniform='offset')
        for i,axis_name in enumerate(('X','Y')):
            row=ttk.Frame(shifts_area);row.grid(row=0,column=i,sticky='ew',padx=(0,8) if i==0 else 0,pady=3)
            head=ttk.Frame(row);head.pack(fill='x',pady=(0,4))
            ttk.Label(head,text=axis_name,width=3).pack(side='left')
            offsets[axis_name]=tk.StringVar(value='0')
            entry=ttk.Entry(row,textvariable=offsets[axis_name],width=1);entry.pack(side='bottom',fill='x',expand=True)
            offset_entries[axis_name]=entry
            entry.bind('<FocusIn>',lambda event,n=axis_name:active_offset.__setitem__(0,n),add='+')
            def choose_offset(kind,variable=offsets[axis_name],entry=entry,axis_name=axis_name):
                active_offset[0]=axis_name
                if kind=='table':
                    show_table_reference_picker(win,project,on_select=lambda text:(variable.set(text),entry.focus_set()),on_replace=lambda text:(variable.set(text),entry.focus_set()))
                else:
                    from command_workbench import show_reference_list
                    groups=reference_groups(project)
                    show_reference_list(win,[(label,refs) for label,refs in groups if '変数' in label or '設定' in label],lambda text:(variable.set(text),entry.focus_set()))
            ttk.Button(head,text='表',image=icons_for(win).get('table'),compound='left',style='WorkbenchRef.TButton',command=lambda f=choose_offset:f('table')).pack(side='left',padx=(3,0))
            ttk.Button(head,text='変数',image=icons_for(win).get('variables'),compound='left',style='WorkbenchRef.TButton',command=lambda f=choose_offset:f('variable')).pack(side='left',padx=(3,0))
            offset_rows[axis_name]=row
        effect=tk.StringVar();ttk.Label(coordinate_card,textvariable=effect,wraplength=380,style='Muted.TLabel').pack(fill='x',pady=6)
        references_card=ttk.Frame(area,style='PointCard.TFrame',padding=10)
        references_card.pack(fill='x',pady=(0,10))
        ttk.Label(references_card,text='参照元コマンドで使用している表・変数',style='CardTitle.TLabel').pack(anchor='w')
        refs_body=ttk.Frame(references_card);refs_body.pack(fill='x',pady=(6,0))
        def insert_reference(text):
            chosen=axis.get() if axis else 'XY'
            target=active_offset[0] if chosen=='XY' else chosen
            entry=offset_entries[target]
            if offsets[target].get().strip()=='0':entry.delete(0,'end')
            elif entry.selection_present():entry.delete(tk.SEL_FIRST,tk.SEL_LAST)
            entry.insert(tk.INSERT,text);entry.focus_set()
        def refresh_source_references():
            from reference_tokens import command_references
            from engine import row_values,evaluate
            for child in refs_body.winfo_children():child.destroy()
            command=candidates[source.current()][1]['command']
            refs=command_references(command)
            try:context=row_values(project,int(visual.row.get())-1)
            except (MacroError,ValueError,IndexError):context={}
            for text in refs:
                try:value=evaluate(text,context);label=f'{text} = {value}'
                except (MacroError,ValueError,TypeError,KeyError):label=text
                ttk.Button(refs_body,text=label,style='WorkbenchRef.TButton',command=lambda t=text:insert_reference(t)).pack(anchor='w',fill='x',pady=2)
            if not refs:ttk.Label(refs_body,text='表・変数の参照はありません',style='CardMuted.TLabel').pack(anchor='w')
            paint_card(references_card)
        def update_visual(*_):
            chosen=axis.get() if axis else 'XY'
            refresh_source_references()
            point_segments.sync()
            if axis_segments:axis_segments.sync()
            for name,row in offset_rows.items():
                if chosen in ('XY',name):row.grid(row=0,column=0 if chosen!='XY' or name=='X' else 1,columnspan=1 if chosen=='XY' else 2,sticky='ew',padx=(0,8) if chosen=='XY' and name=='X' else 0,pady=3)
                else:row.grid_remove()
            effect.set(('X・Yを上書きします' if chosen=='XY' else (chosen+'を上書きします' if both else key[0].upper()+'欄へ'+chosen+'座標を入力します') if not is_argument else chosen+'座標を入力します'))
            if visual is not None:
                shifts={k:v.get() for k,v in offsets.items() if chosen in ('XY',k)}
                visual.update_selection(point.get(),None if chosen=='XY' else chosen,shifts)
                if result_card[0]:result_card[0].update_values(visual.points.get(point.get()),visual.canvas.shifted_point,chosen,visual.status.get())
        def pick_visual(name):
            point.set(name);update_visual()
        def pick_source(index):
            selected=next((j for j,(i,cmd) in enumerate(candidates) if i==index),None)
            if selected is not None:
                source.current(selected);sync()
        visual=live[0]
        visual.status_visible=False
        result_card[0]=PointResultCard(area);result_card[0].pack(fill="x",pady=(0,10))
        paint_card(source_card);paint_card(coordinate_card)
        for child in source_card.winfo_children():
            if isinstance(child,ttk.Combobox):
                child.bind('<FocusIn>',lambda event:paint_card(source_card,True),add='+')
                child.bind('<FocusOut>',lambda event:paint_card(source_card),add='+')
        for row in offset_rows.values():
            for child in row.winfo_children():
                if isinstance(child,ttk.Entry):
                    child.bind('<FocusIn>',lambda event:paint_card(coordinate_card,True),add='+')
                    child.bind('<FocusOut>',lambda event:paint_card(coordinate_card),add='+')
        visual.source_refs=source_defs
        visual.on_pick=pick_visual;visual.canvas.on_pick=pick_visual;visual.canvas.on_source=pick_source
        dialog.source_picker=source
        dialog.point_preview=visual
        existing=read_point_reference((argument_vars[key[4:]] if is_argument else variables[key]).get())
        if existing:
            for candidate_index,(_,descriptor) in enumerate(candidates):
                cmd=descriptor['command'];ci=descriptor['command_index']
                identity=cmd.get('point_id') or (pending_point_ids.get(ci) if descriptor['local'] else external_point_ids.get((descriptor['block_index'],ci)))
                if not descriptor['local'] and identity:identity=descriptor['block_id']+'/'+identity
                if existing['identity'] not in (identity,descriptor['label']):continue
                if existing['point'] not in POINTS[cmd['type']]:continue
                source.current(candidate_index);sync();point.set(existing['point'])
                if combined and existing['axis'] is None:
                    for name,value in zip(('X','Y'),existing['offsets']):offsets[name].set(value)
                elif axis is not None and existing['axis']:
                    axis.set(existing['axis']);offsets[existing['axis']].set(existing['offsets'][0])
                    if not is_argument:
                        other=read_point_reference(variables[ykey if key==xkey else xkey].get())
                        if other and other['identity']==existing['identity'] and other['point']==existing['point'] and existing['axis']==key[0].upper() and other['axis']==('Y' if key[0]=='x' else 'X'):
                            axis.set('XY');offsets[other['axis']].set(other['offsets'][0])
                break
        dialog.point_picker=point;dialog.point_offsets=offsets
        dialog.axis_segments=axis_segments;dialog.point_segments=point_segments;dialog.result_card=result_card[0]
        visual.load(candidates[source.current()][0]);update_visual()
        point.bind("<<ComboboxSelected>>",update_visual)
        if axis:axis.bind("<<ComboboxSelected>>",update_visual)
        for variable in offsets.values():variable.trace_add("write",update_visual)
        row_job=[None]
        def refresh_row():
            row_job[0]=None
            if dialog.winfo_exists():update_visual()
        def queue_row(*_):
            if row_job[0]:win.after_cancel(row_job[0])
            row_job[0]=win.after_idle(refresh_row)
        row_trace=visual.row.trace_add('write',queue_row)
        def clear_row_trace(event):
            if event.widget is dialog:
                visual.row.trace_remove('write',row_trace)
                if row_job[0]:win.after_cancel(row_job[0]);row_job[0]=None
        dialog.bind('<Destroy>',clear_row_trace,add='+')
        def close():
            buttons.destroy();dialog.destroy();selecting[0]=None
            visual.status_visible=True
            viewport.pack(side='left',fill='both',expand=True)
            normal_bar.pack(side='bottom',fill='x',before=body)
            picker.configure(state='readonly')
            for frame in mode_host.winfo_children():
                for child in frame.winfo_children():
                    if isinstance(child,ttk.Combobox):child.configure(state='readonly')
            refresh_preview()

        def apply():
            i,descriptor=candidates[source.current()]
            cmd=descriptor["command"];ci=descriptor["command_index"]
            if descriptor["local"]:
                identity=cmd.get("point_id") or pending_point_ids.setdefault(ci,new_id())
            else:
                identity=descriptor["block_id"]+"/"+(cmd.get("point_id") or external_point_ids.setdefault((descriptor["block_index"],ci),new_id()))
            point_labels[identity] = descriptor["label"]
            shifts={key:var.get().strip() or "0" for key,var in offsets.items()}
            try:
                for name,expression in shifts.items():
                    if combined or axis.get() in ('XY',name):parse_expression(expression)
            except MacroError as exc:
                messagebox.showerror("移動量の確認",str(exc),parent=dialog);return
            batching[0]=True
            if combined:
                argument_vars[key[4:]].set(f"=点位置({identity!r}, {point.get()!r}, {shifts['X']}, {shifts['Y']})")
            elif axis.get()=="XY":
                for coordinate,target in (("X",xkey),("Y",ykey)):
                    expression=reference(identity,point.get(),coordinate)
                    if shifts[coordinate] != "0":expression += " + ("+shifts[coordinate]+")"
                    variables[target].set(rewrite_references(expression,point_labels))
            else:
                expression=reference(identity,point.get(),axis.get())
                if shifts[axis.get()] != "0":
                    expression += " + ("+shifts[axis.get()]+")"
                if is_argument:
                    argument_vars[key[4:]].set(expression)
                else:
                    target=axis.get().lower()+suffix if both else key
                    variables[target].set(rewrite_references(expression,point_labels))
            if is_argument:
                var=argument_vars[key[4:]]
            else:
                var=variables[key]
            var.set(rewrite_references(var.get(),point_labels))
            batching[0]=False;record_edit()
            close()
        ttk.Button(buttons,text="キャンセル",command=close).pack(side="left")
        ttk.Button(buttons,text="この点を使用",style="WorkbenchPrimary.TButton",command=apply).pack(side="right")
        win.close_point_panel=close

    win.choose_command_point = choose_command_point

    def add_reference_menu(row, entry, key):
        """Let every applicable field use a table picker or the old quick menu."""
        if coordinate_key(key):return
        menu_button = ttk.Menubutton(row, text="表・変数 ▾", width=2, style="MainIcon.TMenubutton")
        menu_button.icon_button_style = "MainIcon.TMenubutton"
        entry.reference_button = menu_button
        menu = tk.Menu(menu_button, tearoff=0)
        menu.add_command(
            label="表の列・セルから選ぶ…",
            command=lambda e=entry, k=key: show_table_reference_picker(
                win, project,
                lambda ref: place_ref(e, k, ref),
                on_replace=lambda ref: place_ref(e, k, ref, replace=True),
            ),
        )
        if coordinate_key(key) or key.startswith("arg:"):
            menu.add_command(label="別コマンドの始点・中点・終点から選ぶ…", command=lambda k=key: choose_command_point(k))
        menu.add_separator()
        for group_title, group_refs in ref_groups:
            group_menu = tk.Menu(menu, tearoff=0)
            for ref in group_refs:
                group_menu.add_command(
                    label=ref,
                    command=lambda e=entry, k=key, r=ref: place_ref(e, k, r),
                )
            menu.add_cascade(label=group_title, menu=group_menu)
        menu_button.configure(menu=menu)
        menu_button.pack(side="left", padx=(3, 0))

    def insert_ref(*_):
        selected = listing.curselection()
        if not selected:
            return
        entry = focused[0]
        key = next((k for k, e in entries.items() if e is entry), "")
        place_ref(entry, key, listing.get(selected[0]))

    listing.bind("<Double-1>", insert_ref)
    ttk.Button(
        refs, text="選択した参照を挿入", command=insert_ref, style="Compact.TButton"
    ).grid(row=3, column=0, sticky="ew", pady=(6, 0))
    ttk.Label(
        refs,
        text="loop.index: 0始まり / number: 1始まり\nloop.count: 反復回数（繰り返し内のみ）",
        style="Muted.TLabel",
        wraplength=250,
    ).grid(row=4, column=0, sticky="w", pady=(6, 0))
    def toggle_refs():
        from command_workbench import show_reference_list
        show_reference_list(win, ref_groups, lambda value: place_ref(focused[0], next((k for k,e in entries.items() if e is focused[0]), ''), value))

    ref_button = ttk.Button(header, text='列・変数の一覧', command=toggle_refs, style='Compact.TButton')
    ref_button.pack(side='right', padx=(8,0))
    active = [old_type]
    point_titles = {}
    field_results = {}
    coordinate_cards = {}
    win.field_results=field_results
    win.coordinate_cards=coordinate_cards
    point_buttons = {}
    reference_summaries = {}
    win.reference_summaries=reference_summaries
    vertex_count = [0]
    vertex_ids = []

    def coordinate_key(key):
        return key in ("x","y") or (key[:1] in ("x","y") and key[1:].isdigit())

    def field_caption(key):
        if active[0] in ("LINE","POLYLINE") and coordinate_key(key) and key[1:].isdigit():
            i=int(key[1:]);name="始点" if i==1 else "終点" if i==vertex_count[0] else f"中間点{i-1}"
            return name+" "+key[0].upper()
        if coordinate_key(key) and "x"+key[1:] in point_titles:return point_titles["x"+key[1:]]+" "+key[0].upper()
        return LABELS.get(key,key)

    def gather():
        data = {
            "type": active[0],
            **working,
            **{k: v.get() for k, v in variables.items()},
        }
        if active[0] in ("LINE","POLYLINE") and vertex_count[0]:
            vertices=[dict(id=vertex_ids[i],x=variables[f"x{i+1}"].get(),y=variables[f"y{i+1}"].get()) for i in range(vertex_count[0])]
            for key in list(data):
                if coordinate_key(key) and key[1:].isdigit():data.pop(key,None)
            if "vertices" in working:data["vertices"]=vertices
            if active[0]=="LINE":
                data.update(x1=vertices[0]["x"],y1=vertices[0]["y"],x2=vertices[-1]["x"],y2=vertices[-1]["y"])
            else:
                old=read_vertices(working)
                unchanged=[(p['x'],p['y']) for p in old]==[(p['x'],p['y']) for p in vertices]
                data['points']=working.get('points',points_text(vertices)) if unchanged else points_text(vertices)
        if active[0]=="CIRCLE":data.setdefault("r","@OD / 2")
        if active[0]=="ARC":
            for k,v in FIELDS["ARC"]:data.setdefault(k,v)
        if "color" in data:
            data["color"] = entity_color_code(data["color"])
        if active[0] == "CUSTOM":
            data.update(
                name=selected_custom[0],
                arguments={k: v.get() for k, v in argument_vars.items()},
            )
        return rewrite_references(data, {label: identity for identity,label in point_labels.items()})

    def switch_input_mode(field,new_mode):
        before=gather();typ=active[0]
        old_mode=before.get(field,'radius' if typ=='CIRCLE' else 'center_angles')
        mode_drafts[(typ,old_mode)]=copy.deepcopy(before)
        geometry={'x','y','x1','y1','x2','y2','x3','y3','r','diameter','start_angle','end_angle'}
        saved=mode_drafts.get((typ,new_mode),{})
        data={k:v for k,v in before.items() if k not in geometry}
        data.update({k:v for k,v in saved.items() if k in geometry});data[field]=new_mode
        working.clear();working.update(data);redraw(False);record_edit()

    def add_point_actions(head,suffix):
        tools=ttk.Frame(head);tools.pack(side='right')
        def target_key():
            focused_key=next((k for k,e in entries.items() if e is focused[0]),None)
            return focused_key if focused_key in ('x'+suffix,'y'+suffix) else 'x'+suffix
        def table():
            axis=tk.StringVar(value=target_key()[0].upper())
            def apply(ref):place_ref(entries[axis.get().lower()+suffix],axis.get().lower()+suffix,ref,replace=True)
            show_table_reference_picker(win,project,apply,on_replace=apply,target_axis=axis)
        def variable():
            dialog=tk.Toplevel(win);dialog.title('変数を選択');dialog.transient(win);dialog.grab_set()
            fit_window(dialog,460,430,360,300)
            axis=tk.StringVar(value=target_key()[0].upper())
            bar=ttk.Frame(dialog,padding=12);bar.pack(fill='x')
            ttk.Label(bar,text='入力先').pack(side='left')
            ttk.Combobox(bar,textvariable=axis,values=('X','Y'),state='readonly',width=6).pack(side='left',padx=8)
            choices=tk.Listbox(dialog,exportselection=False,activestyle='dotbox');choices.pack(fill='both',expand=True,padx=12)
            values=[r for title,refs_ in ref_groups if title in ('変数','共通設定','繰り返し') for r in refs_]
            for value in values:choices.insert('end',value)
            current=variables[target_key()].get()
            if current in values:choices.selection_set(values.index(current));choices.see(values.index(current))
            def apply(*_):
                if not choices.curselection():return
                key=axis.get().lower()+suffix;place_ref(entries[key],key,values[choices.curselection()[0]],replace=True)
                dialog.destroy();win.grab_set()
            choices.bind('<Double-1>',apply)
            footer=ttk.Frame(dialog,padding=12);footer.pack(fill='x')
            ttk.Button(footer,text='キャンセル',command=lambda:(dialog.destroy(),win.grab_set())).pack(side='left')
            ttk.Button(footer,text='この変数を使用',command=apply,style='Primary.TButton').pack(side='right')
        buttons=[]
        for label,icon,action in (('表','table',table),('コマンド','tree',lambda:choose_command_point(target_key(),both=True)),('変数','variables',variable)):
            button=ttk.Button(tools,text=label,image=icons_for(win).get(icon),compound='left',style='WorkbenchRef.TButton',width=0,command=action)
            button.icon_only=False
            button.pack(side='left',padx=(3,0));button.tooltip_text=label+'から選択';buttons.append(button)
        head.reference_buttons=buttons
        point_buttons[suffix]=buttons

    def connect_point_buttons(suffix,buttons):
        if not buttons[0].winfo_exists():return
        for key in ('x'+suffix,'y'+suffix):
            if key in entries:entries[key].reference_buttons=buttons;entries[key].reference_button=buttons[0]

    def change_vertex(remove=None):
        if remove is None and vertex_count[0]>=MAX_VERTICES:
            return messagebox.showinfo("点数の上限","1コマンドは1000点までです",parent=win)
        if remove is not None and vertex_count[0]<=2:return
        data=gather()
        vertices=[dict(id=vertex_ids[i],x=variables[f"x{i+1}"].get(),y=variables[f"y{i+1}"].get()) for i in range(vertex_count[0])]
        vertices=rewrite_references(vertices,{label:identity for identity,label in point_labels.items()})
        if remove is None:vertices.append(dict(id=vertex_id(),x="",y=""))
        else:vertices.pop(remove)
        data['vertices']=vertices
        working.clear();working.update(data)
        redraw(False);record_edit()
        if remove is None:
            entry=entries[f"x{len(vertices)}"]
            win.after_idle(lambda: (viewport.yview_moveto(min(1, max(0, (entry.winfo_rooty()-form.winfo_rooty()-40)/max(1,form.winfo_height())))),entry.focus_set()) if entry.winfo_exists() else None)
    win.add_vertex=lambda:change_vertex()
    win.remove_vertex=lambda index:change_vertex(index)

    def branch(key):
        working.update({k: v.get() for k, v in variables.items()})
        staged = copy.deepcopy(working.get(key, []))
        before_blocks = copy.deepcopy(blocks)
        sub = tk.Toplevel(win)
        sub.title(
            "IF: 実行する側"
            if key == "commands" and active[0] == "IF"
            else "ELSE: 条件に合わない側"
            if key == "else"
            else "繰り返すコマンド"
        )
        sub.geometry("880x540")
        sub.transient(win)
        sub.grab_set()
        ttk.Label(
            sub, text="ここに追加したコマンドを、上から順番に実行します。", padding=12
        ).pack(anchor="w")
        editor = CommandList(
            sub,
            staged,
            blocks,
            project=project,
            local_names=sample_locals or local_names,
            folder_id=folder_id,
            previous_blocks=previous_blocks, owner_block_id=owner_block_id,
        )

        def cancel():
            if (
                staged != working.get(key, []) or blocks != before_blocks
            ) and not messagebox.askyesno(
                "変更の破棄", "この階層の変更を破棄しますか？", parent=sub
            ):
                return
            replace_collection(blocks, before_blocks)
            sub.destroy()

        def commit():
            working[key] = copy.deepcopy(editor.commands)
            sub.destroy()

        bar = ttk.Frame(sub, padding=10)
        bar.pack(side="bottom", fill="x", before=editor.frame)
        ttk.Button(bar, text="キャンセル", command=cancel).pack(side="left")
        ttk.Button(
            bar, text="この階層を確定", style="Primary.TButton", command=commit
        ).pack(side="right")
        sub.protocol("WM_DELETE_WINDOW", cancel)
        sub.bind("<Escape>", lambda e: cancel())
        win.wait_window(sub)
        win.grab_set()
        redraw(False)

    def redraw(changed=True):
        redrawing[0]=True
        if changed:
            drafts[active[0]] = gather()
            typ = next(k for k, v in TYPE_LABELS.items() if v == choice.get())
            active[0] = typ
            working.clear()
            working.update(copy.deepcopy(drafts.get(typ, {"type": typ})))
        for widget in mode_host.winfo_children():widget.destroy()
        point_titles.clear();field_results.clear();coordinate_cards.clear();point_buttons.clear();reference_summaries.clear()
        for widget in form.winfo_children():
            widget.destroy()
        entries.clear()
        variables.clear()
        argument_vars.clear()
        focused[0] = None
        typ = active[0]
        if typ == "CUSTOM":
            catalog = project.get("custom_commands", {})
            if selected_custom[0] not in catalog:
                selected_custom[0] = next(iter(catalog), "")
            custom_header = ttk.Frame(form, style="PointCard.TFrame", padding=10)
            custom_header.pack(fill="x", pady=(0,8))
            ttk.Label(custom_header,text="使用するコマンド",style="CardTitle.TLabel").pack(anchor="w",pady=(0,8))
            row = ttk.Frame(custom_header)
            row.pack(fill="x", pady=4)
            field_label(row, text="登録したコマンド", width=18).pack(side="left")
            names = {k: d["name"] for k, d in catalog.items()}
            custom_choice = tk.StringVar(value=names.get(selected_custom[0], ""))
            combo = ttk.Combobox(
                row,
                textvariable=custom_choice,
                values=list(names.values()),
                state="readonly",
            )
            combo.pack(side="left", fill="x", expand=True)

            def choose_custom(_=None):
                working["condition"] = variables.get(
                    "condition", tk.StringVar(value="")
                ).get()
                selected_custom[0] = next(
                    (k for k, v in names.items() if v == custom_choice.get()), ""
                )
                working["name"] = selected_custom[0]
                working["arguments"] = {}
                redraw(False)

            combo.bind("<<ComboboxSelected>>", choose_custom)
            if not catalog:
                ttk.Label(
                    custom_header,
                    text="メイン画面のブロック一覧「…」→「登録コマンド」で新規登録できます。",
                    wraplength=400,
                ).pack(anchor="w", pady=12)
            definition = catalog.get(selected_custom[0], {})
            ttk.Label(
                custom_header,
                text=definition.get("description", ""),
                style="Muted.TLabel",
                wraplength=400,
            ).pack(anchor="w", pady=8)
            ttk.Label(
                custom_header,
                text="実行: "
                + (
                    "生成全体で1回"
                    if definition.get("execution") == "once"
                    else "対象の各行"
                )
                + " / 図形プレビュー対象外",
                style="Muted.TLabel",
                wraplength=400,
            ).pack(anchor="w", pady=(0, 7))
            values_card = ttk.Frame(form, style="PointCard.TFrame", padding=10)
            values_card.pack(fill="x", pady=(0,8))
            ttk.Label(values_card,text="設定する値",style="CardTitle.TLabel").pack(anchor="w",pady=(0,8))
            for param in definition.get("parameters", []):
                row = ttk.Frame(values_card)
                row.pack(fill="x", pady=4)
                field_label(row, text=param.get("label", param["name"]), width=18).pack(
                    side="left"
                )
                original = (
                    working.get("arguments", {})
                    if working.get("name") == selected_custom[0]
                    else {}
                )
                value = tk.StringVar(
                    value=rewrite_references(str(original.get(param["name"], param.get("default", ""))), point_labels)
                )
                from parameter_inputs import argument_entry
                entry = argument_entry(row, param, value, project, win)
                add_reference_color(entry,value,project.get("globals",{}),literal=param.get("kind")=="text")
                argument_vars[param["name"]] = value
                entries["arg:" + param["name"]] = entry
                entry.bind("<FocusIn>", focus_sample)
                value.trace_add("write", update_sample)
                value.trace_add("write", record_edit)
                add_reference_menu(row, entry, "arg:" + param["name"])
                if param["kind"] == "number":
                    label=ttk.Label(values_card,text="",style="CardMuted.TLabel")
                    field_results["arg:"+param["name"]]=label
            paint_card(custom_header);paint_card(values_card)
        vertex_count[0]=0;vertex_ids.clear();win.vertex_rows=[]
        if typ in ("LINE","POLYLINE"):
            chain=read_vertices(working)
            vertex_count[0]=len(chain);vertex_ids.extend(p['id'] for p in chain)
            fields=[("layer","")]+[(key+str(i+1),point[key]) for i,point in enumerate(chain) for key in ('x','y')]
            if typ=='POLYLINE':fields.append(('closed',working.get('closed','0')))
        else:
            fields = list(FIELDS[typ])
        if typ == 'CIRCLE':
            size_row=ttk.Frame(mode_host);size_row.pack(fill='x')
            ttk.Label(size_row,text='サイズ指定',width=9).pack(side='left')
            size_picker=ttk.Combobox(size_row,state='readonly',values=('半径','直径'))
            size_picker.set('直径' if working.get('circle_mode')=='diameter' else '半径');size_picker.pack(side='left',fill='x',expand=True)
            def change_circle_mode(event):
                switch_input_mode('circle_mode','diameter' if size_picker.get()=='直径' else 'radius')
            size_picker.bind('<<ComboboxSelected>>',change_circle_mode);win.circle_mode_picker=size_picker
            if working.get('circle_mode')=='diameter':fields=[(k,v) if k!='r' else ('diameter',working.get('diameter','@OD')) for k,v in fields]
        if typ == 'ARC':
            mode=working.get('arc_mode','center_angles')
            modes_row=ttk.Frame(mode_host);modes_row.pack(fill='x')
            ttk.Label(modes_row,text='入力方式',width=9).pack(side='left')
            mode_picker=ttk.Combobox(modes_row,state='readonly',width=27,values=list(ARC_MODES.values()))
            mode_picker.set(ARC_MODES.get(mode,ARC_MODES['center_angles']));mode_picker.pack(side='left',fill='x',expand=True)
            def change_arc_mode(event):
                switch_input_mode('arc_mode',next(k for k,v in ARC_MODES.items() if v==mode_picker.get()))
            mode_picker.bind('<<ComboboxSelected>>',change_arc_mode)
            win.arc_mode_picker=mode_picker
            if mode!='center_angles':
                fields=[('layer',''),('x1','@X+25'),('y1','@Y'),('x2','@X' if mode=='start_center_end' else '@X+25'),('y2','@Y' if mode=='start_center_end' else '@Y+25'),('x3','@X'),('y3','@Y+25')]
        if typ in DRAWING_TYPES:
            fields.insert(1, ("linetype", ""))
            fields.extend([("color", ""), ("linetype_scale", "")])
        if typ == "TEXT":
            fields.insert(2, ("text_style", ""))
        if typ in DIMENSION_TYPES:
            fields.insert(2, ("dim_style", ""))
        if typ != "IF":
            fields.append(("condition", ""))
        advanced_keys = {"layer", "linetype", "color", "linetype_scale", "text_style", "dim_style", "condition"}
        if typ == "IF":
            advanced_keys.discard("condition")
        basic_section = ttk.Frame(form)
        basic_section.pack(fill="x")
        advanced_section = ttk.LabelFrame(
            form, text="詳細設定", padding=(10, 4, 10, 6), style="Group.TLabelframe"
        )
        win.advanced_section = advanced_section
        advanced_rows = {}
        win.advanced_rows = advanced_rows

        coordinate_rows = {}
        field_names = {key for key, _ in fields}
        for key, default in fields:
            optional = key in advanced_keys
            is_coordinate = coordinate_key(key) and "x"+key[1:] in field_names and "y"+key[1:] in field_names
            if is_coordinate:
                suffix = key[1:]
                if suffix not in coordinate_rows:
                    group = ttk.Frame(basic_section,style="PointCard.TFrame",padding=8)
                    group.pack(fill="x", pady=(0,8))
                    if typ in ("LINE","POLYLINE"):
                        i=int(suffix)
                        title="始点" if i==1 else "終点" if i==vertex_count[0] else f"中間点{i-1}"
                    elif suffix == "":
                        title = "挿入点" if typ == "TEXT" else "位置" if typ == "POINT" else "中心"
                    elif typ == "ARC" and working.get("arc_mode","center_angles") != "center_angles":
                        title={"1":"始点","2":"中心" if working["arc_mode"]=="start_center_end" else "通過点","3":"終点"}[suffix]
                    elif suffix == "3":
                        title = "寸法位置"
                    elif typ in ("DIMLINEAR", "DIMALIGNED"):
                        title = "測定点" + suffix
                    elif typ == "RECTANGLE":
                        title = "対角点" + suffix
                    else:
                        title = "始点" if suffix == "1" else "終点"
                    point_titles['x'+suffix]=title
                    coordinate_cards[suffix]=group
                    head=ttk.Frame(group);head.pack(fill='x',pady=(0,5))
                    ttk.Label(head,text=title,style='Section.TLabel').pack(side='left')
                    add_point_actions(head,suffix)
                    axes = ttk.Frame(group)
                    axes.pack(fill='x',expand=True)
                    axes.columnconfigure((0, 1), weight=1, uniform='coordinate')
                    coordinate_rows[suffix] = axes
                    summary=ttk.Label(group,text='',style='ReferenceChip.TLabel',cursor='hand2',wraplength=450)
                    group.bind('<Configure>',lambda event,label=summary:label.configure(wraplength=max(80,event.width-16)))
                    summary.bind('<Button-1>',lambda event,k='x'+suffix:choose_command_point(k,both=True))
                    reference_summaries[suffix]=summary
                    if typ in ("LINE","POLYLINE"):
                        win.vertex_rows.append(title)
                        delete=ttk.Button(head,text="点を削除",command=lambda index=int(suffix)-1:change_vertex(index),width=2,style="MainIcon.TButton")
                        delete.icon_button_style="MainIcon.TButton"
                        delete.pack(side="right",padx=(3,0));delete.configure(state="normal" if vertex_count[0]>2 else "disabled")
                axes = coordinate_rows[suffix]
                row = ttk.Frame(axes)
                row.grid(row=0, column=0 if key[0] == "x" else 1, sticky="nsew", padx=(0, 8) if key[0] == "x" else (0, 0))
                column=row
                row=ttk.Frame(column);row.pack(fill='x')
                label=ttk.Label(column,text='',style='Muted.TLabel')
                label.pack(anchor='w',padx=(16,0),pady=(2,0))
                field_results[key]=label
                field_label(row, text=key[0].upper(), width=2).pack(side='left')
            elif optional and key != "condition":
                tile = ttk.Frame(advanced_section)
                advanced_rows[key] = tile
                field_label(tile, text="線種尺度" if key == "linetype_scale" else LABELS.get(key, key), width=12).pack(side="left")
                row = tile
            else:
                row = ttk.Frame(advanced_section if optional else basic_section)
                if optional:
                    advanced_rows[key] = row
                else:
                    row.pack(fill="x", pady=4)
                field_label(row, text=LABELS.get(key, key), width=14).pack(side="left")
            value = tk.StringVar(value=rewrite_references(str(default if is_coordinate and typ in ("LINE","POLYLINE") else working.get(key, default)), point_labels))
            if key == "color":
                value.set(entity_color_label(value.get()))
                entry = ttk.Combobox(
                    row, textvariable=value,
                    width=1, values=["", entity_color_label(256), entity_color_label(0), *[entity_color_label(i) for i in range(1, 10)]],
                )
            elif key in STYLE_FIELDS:
                entry = ttk.Combobox(
                    row,
                    textvariable=value,
                    values=["", *resource_names(project, STYLE_FIELDS[key])], width=1,
                )
            elif key in ("value_kind", "execution"):
                entry = ttk.Combobox(
                    row,
                    textvariable=value,
                    values=["number", "text"]
                    if key == "value_kind"
                    else ["per_row", "once"],
                    state="readonly",
                )
            else:
                entry = ttk.Entry(row, textvariable=value, width=1 if is_coordinate or optional else 20)
            entry.pack(side="left", fill="x", expand=True)
            if key == "color":
                chip = tk.Label(row, width=2, relief="solid", borderwidth=1)
                chip.pack(side="left", padx=5)

                def update_color_chip(*_, variable=value, label=chip):
                    try:
                        index = int(entity_color_code(variable.get()))
                        label.configure(bg=swatch(index) if 1 <= index <= 255 else "#f3f5f9")
                    except (ValueError, IndexError):
                        label.configure(bg="#f3f5f9")

                value.trace_add("write", update_color_chip)
                update_color_chip()
                palette = ttk.Button(row, text="色見本…", image=icons_for(win).get("colors"), compound="none", width=2,
                                     style="MainIcon.TButton", command=lambda v=value: ColorPicker(win, v, title="作図する図形の色を選択"))
                palette.pack(side="left")
                palette.tooltip_text = "色見本から選ぶ"
                palette.bind("<Enter>", lambda e, b=palette: icons_for(win).schedule(b, b.tooltip_text))
                palette.bind("<Leave>", lambda e: icons_for(win).hide())
            if key not in STYLE_FIELDS and key not in ("name","color","value_kind","execution"):
                add_reference_color(entry,value,project.get("globals",{}),literal=key=="text")
            variables[key] = value
            entries[key] = entry
            if key in (*STYLE_FIELDS, "color", "linetype_scale"):
                add_entry_hint(entry, value, "現在の設定を引き継ぐ")
            elif key == "condition" and typ != "IF":
                add_entry_hint(entry, value, "条件なし（常に実行）")
            entry.bind("<FocusIn>", focus_sample)
            if is_coordinate:
                entry.bind("<Enter>", lambda event, e=entry, k=key: icons_for(win).schedule(e, field_caption(k)+": "+e.get()))
                entry.bind("<Leave>", lambda event: icons_for(win).hide())
            value.trace_add("write", update_sample)
            value.trace_add("write", record_edit)
            if (isinstance(entry, ttk.Entry)
                    and not isinstance(entry, ttk.Combobox)
                    and key not in ("name", "value_kind", "execution")):
                add_reference_menu(row, entry, key)
            if typ in ("LINE","POLYLINE") and key==f"y{vertex_count[0]}":
                tools=ttk.Frame(basic_section);tools.pack(fill="x",pady=(2,6))
                ttk.Button(tools,text="点を追加",command=lambda:change_vertex(),width=2,style="MainIcon.TButton").pack(side="left")
                ttk.Label(tools,text=f"{vertex_count[0]}点 · ＋で終点を追加",style="Muted.TLabel").pack(side="left",padx=8)
            if key == "condition":
                ttk.Button(
                    row,
                    text="条件を作る…",
                    command=lambda v=value: show_condition_builder(win, v, project, local_names),
                ).pack(side="left", padx=(6, 0))
        def arrange_details(event=None):
            columns = 2 if advanced_section.winfo_width() >= 540 else 1
            for column in (0, 1):
                advanced_section.columnconfigure(column, weight=1 if column < columns else 0, uniform="details" if column < columns else "")
            order = [key for key in ("layer", "linetype", "color", "linetype_scale", "text_style", "dim_style") if key in advanced_rows]
            for i, key in enumerate(order):
                advanced_rows[key].grid(row=i//columns, column=i%columns, columnspan=1, sticky="new",
                                        padx=(0, 12) if columns == 2 and i%columns == 0 else (0, 0), pady=(5, 5))
            if "condition" in advanced_rows:
                advanced_rows["condition"].grid(row=(len(order)+columns-1)//columns, column=0, columnspan=columns, sticky="ew", pady=(6, 4))
        advanced_section.bind("<Configure>", arrange_details)
        arrange_details()
        if advanced_keys.intersection(key for key, _ in fields):
            advanced_section.pack(fill="x", pady=(10, 0))
        if typ in ("IF", "REPEAT"):
            for key, label in [
                ("commands", "実行するコマンド" if typ == "IF" else "繰り返すコマンド")
            ] + ([("else", "ELSE のコマンド")] if typ == "IF" else []):
                ttk.Button(
                    form,
                    text=f"{label}を編集（{len(working.get(key, []))}件）",
                    command=lambda k=key: branch(k),
                ).pack(fill="x", pady=(12, 0))
        for suffix,buttons in point_buttons.items():connect_point_buttons(suffix,buttons)
        for card in coordinate_cards.values():paint_card(card)
        paint_card(advanced_section)
        win.update_idletasks();form_changed()
        redrawing[0]=False
        if history_current[0] is None:history_current[0]=capture_state()
        schedule_preview()

    redraw(False)
    picker.bind("<<ComboboxSelected>>", lambda e: redraw())
    original_blocks = copy.deepcopy(blocks)
    cancel_baseline=[copy.deepcopy(gather())]

    def cancel():
        if selecting[0] is not None:
            win.close_point_panel();return
        if (
            gather() != cancel_baseline[0] or blocks != original_blocks
        ) and not messagebox.askyesno(
            "変更の破棄", "コマンドの変更を破棄しますか？", parent=win
        ):
            return
        replace_collection(blocks, original_blocks)
        win.destroy()

    def accept(keep_open=False):
        d = gather()
        d["type"] = active[0]
        if d["type"] == "SET" and not valid_name(d.get("name")):
            return messagebox.showerror(
                "変数名",
                "英数字と_の名前を指定してください。予約名は使えません",
                parent=win,
            )
        try:
            for k, v in variables.items():
                text = v.get().strip()
                if k == "color":
                    text = entity_color_code(text)
                if k in (
                    "name",
                    "layer",
                    "text",
                    "value_kind",
                    "execution",
                    "linetype",
                    "text_style",
                    "dim_style",
                ):
                    continue
                if (
                    k == "value"
                    and d["type"] == "SYSVAR"
                    and d.get("value_kind") == "text"
                ):
                    if text.startswith("="):
                        parse_expression(text[1:])
                    continue
                if k in ("name", "layer", "text"):
                    continue
                if not text:
                    if k in ("color", "linetype_scale") or (k == "condition" and d["type"] != "IF"):
                        continue
                    raise MacroError(field_caption(k) + " を入力してください")
                if k == "points":
                    polyline_expressions(text)
                else:
                    parse_expression(text)
        except MacroError as exc:
            return messagebox.showerror("入力内容の確認", str(exc), parent=win)
        if d["type"] == "CUSTOM":
            catalog = project.get("custom_commands", {})
            if d.get("name") not in catalog:
                return messagebox.showerror(
                    "登録コマンド", "コマンドを登録・選択してください", parent=win
                )
            try:
                for param in catalog[d["name"]].get("parameters", []):
                    value = d["arguments"][param["name"]]
                    if param.get("control") == "layer" and not value.strip():
                        raise MacroError("レイヤー名を選択または入力してください")
                    if param.get("control") in ("color", "entity_color") and not value.startswith("="):
                        try:
                            code=float(entity_color_code(value))
                        except ValueError:
                            if param["kind"] != "number":raise MacroError("色はACI番号0〜256、BYLAYER、BYBLOCKで指定してください")
                        else:
                            low,high=(0,256) if param.get("control")=="entity_color" else (1,255)
                            if not code.is_integer() or not low<=code<=high:raise MacroError(f"色のACI番号は{low}〜{high}で指定してください")
                    if param["kind"] == "number":
                        parse_expression(value)
                    elif value.startswith("="):
                        parse_expression(value[1:])
            except MacroError as exc:
                return messagebox.showerror("引数の確認", str(exc), parent=win)
        if d["type"] == "SYSVAR":
            import re

            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", d["name"]):
                return messagebox.showerror(
                    "システム変数名", "例: OSMODE / CMDECHO", parent=win
                )
        for index, identity in pending_point_ids.items():
            point_sources[index]["point_id"] = identity
        for (bi,ci),identity in external_point_ids.items():
            previous_blocks[bi]["commands"][ci]["point_id"]=identity
        if keep_open:
            queued.append(d);point_sources.append(d)
            source_defs.append(dict(command=d,block_index=len(previous_blocks),command_index=len(point_sources)-1,block_id='',local=True,label=f'コマンド{len(point_sources)}'))
            replace_collection(original_blocks,copy.deepcopy(blocks))
            pending_point_ids.clear();external_point_ids.clear()
            undo_stack.clear();redo_stack.clear();history_current[0]=None
            working.clear();working.update(copy.deepcopy(d));working.pop('point_id',None)
            redraw(False);cancel_baseline[0]=copy.deepcopy(gather())
            return
        result.append(d)
        win.destroy()

    bar = normal_bar = ttk.Frame(win, padding=(12,10))
    bar.pack(side="bottom", fill="x", before=body)
    ttk.Button(bar, text="キャンセル", command=cancel).pack(side="left")
    ttk.Button(
        bar, text="追加して閉じる" if allow_continue else "コマンドを反映", style="WorkbenchPrimary.TButton", command=accept
    ).pack(side="right")
    if allow_continue:ttk.Button(bar,text='追加して続ける',style='WorkbenchSecondary.TButton',command=lambda:accept(True)).pack(side='right',padx=8)
    redo_button=ttk.Button(header,text='やり直す',image=icons_for(win).get('redo'),compound='none',style='WorkbenchRef.TButton',width=2,command=redo_draft)
    redo_button.icon_button_style='WorkbenchRef.TButton';redo_button.icon_button_width=2;redo_button.pack(side='right')
    undo_button=ttk.Button(header,text='元に戻す',image=icons_for(win).get('undo'),compound='none',style='WorkbenchRef.TButton',width=2,command=undo_draft)
    undo_button.icon_button_style='WorkbenchRef.TButton';undo_button.icon_button_width=2;undo_button.pack(side='right')
    win.protocol("WM_DELETE_WINDOW", cancel)
    win.bind("<Escape>", lambda e: cancel())
    from command_workbench import choose_kind
    def open_kind(event=None):
        choose_kind(win,kind_groups,TYPE_LABELS,lambda kind:(choice.set(TYPE_LABELS[kind]),redraw()),icons_for(win))
        return 'break'
    picker.bind('<Button-1>',open_kind);picker.bind('<space>',open_kind)
    live[0]=PointReferencePreview(body,project,point_sources,focus_point,0,sample_locals,preview_blocks=scene_blocks,source_refs=source_defs,compact=True)
    live[0].grid(row=0,column=1,sticky='nsew')
    live[0].row.trace_add('write',lambda *_:sample_row.set(live[0].row.get()) if live[0].row.get()!=sample_row.get() else None)
    win.command_preview=live[0];win.refresh_command_preview=refresh_preview
    schedule_preview()
    def shutdown(event):
        if event.widget is win and refresh_job[0]:win.after_cancel(refresh_job[0]);refresh_job[0]=None
    win.bind('<Destroy>',shutdown,add='+')
    parent.wait_window(win)
    try:
        parent.winfo_toplevel().grab_set() if parent.winfo_toplevel() is not parent._root() else None
    except tk.TclError:
        pass
    return queued+result if allow_continue and (queued or result) else result[0] if result else None


class CommandList:
    def __init__(
        self,
        parent,
        commands,
        blocks,
        on_select=None,
        on_change=None,
        project=None,
        local_names=(),
        folder_id="",
        previous_blocks=(), owner_block_id=None,
    ):
        self.owner_block_id=owner_block_id
        self.previous_block_ids=[block["id"] for block in previous_blocks]
        self.commands = commands
        self.blocks = blocks
        self.on_select = on_select
        self.on_change = on_change
        self.project = project
        self.local_names = local_names
        self.folder_id = folder_id
        self.undo_stack = []
        self.redo_stack = []
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.frame.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)
        self.icons = icons_for(parent)
        self.command_images = {kind: self.icons.get(ICONS[label][0]) for label, kinds in COMMAND_GROUPS for kind in kinds}
        self.tree = GridTreeview(
            self.frame,
            columns=("detail",),
            show="tree headings",
            selectmode="extended",
            height=7,
            style="Command.Treeview",
        )
        for key, label, width in [
            ("#0", "コマンド", 220),
            ("detail", "設定 / 条件", 480),
        ]:
            self.tree.heading(key, text=label)
            self.tree.column(
                key, width=width, minwidth=190 if key == "#0" else 120,
                stretch=key != "#0",
            )
        self.tree.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(self.frame, command=self.tree.yview)
        ys.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=ys.set)
        xs = ttk.Scrollbar(self.frame, orient="horizontal", command=self.tree.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.tree.configure(xscrollcommand=xs.set)
        self.tree.bind("<Double-1>", lambda e: self.edit())
        self.tree.bind("<Return>", lambda e: self.edit())
        self.tree.bind(
            "<<TreeviewSelect>>",
            lambda e: self.on_select(self.indices()) if self.on_select else None,
        )
        self.tree.bind("<Alt-Up>", lambda e: self.move(-1))
        self.tree.bind("<Alt-Down>", lambda e: self.move(1))
        self.tree.bind("<Delete>", lambda e: self.delete())
        self.tree.bind("<Control-d>", lambda e: self.duplicate())
        self.tree.bind("<Control-z>", lambda e: (self.undo(), "break")[-1])
        self.tree.bind("<Control-y>", lambda e: (self.redo(), "break")[-1])
        self.toolbar = bar = ttk.Frame(parent, padding=(0, 4))
        bar.pack(fill="x", padx=10, before=self.frame)
        add_button = ttk.Button(bar, text="＋ コマンド追加", command=self.choose_add, style="Compact.TButton")
        add_button.toolbar_labelled=True
        add_button.toolbar_full_label="＋ コマンド追加";add_button.toolbar_compact_label="＋ 追加"
        add_button.grid(row=0,column=0,padx=(0,4),sticky="nsew")
        actions = [("編集", self.edit), ("複製", self.duplicate), ("ガイド化", self.make_guide), ("削除", self.delete),
                   ("↑", lambda:self.move(-1)), ("↓", lambda:self.move(1)),
                   ("元に戻す", self.undo), ("やり直し", self.redo)]
        for i,(label, action) in enumerate(actions,1):
            button=ttk.Button(bar,text=label,command=action,width=2,style="MainIcon.TButton")
            button.icon_only=True;button.icon_button_width=2;button.icon_button_style="MainIcon.TButton"
            button.grid(row=0,column=i,padx=(0,2),sticky="nsew")
        self.empty_help=ttk.Frame(self.tree,style="Surface.TFrame",padding=10)
        ttk.Label(self.empty_help,text="線や円などのコマンドを追加して作図します。",style="SurfaceMuted.TLabel",wraplength=250).pack(pady=(0,8))
        ttk.Button(self.empty_help,text="＋ コマンドを追加",command=self.choose_add,style="Compact.TButton").pack()
        bar.bind("<Configure>", lambda event: layout_icon_toolbar(bar, event.width, grid=True))
        self.tree.bind("<<TreeviewSelect>>",self.update_guide_actions,add="+")
        self.refresh()

    def snapshot(self):
        self.undo_stack.append(
            (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
        )
        self.undo_stack = self.undo_stack[-100:]
        self.redo_stack.clear()

    def restore(self, state):
        self.commands[:] = state[0]
        replace_collection(self.blocks, state[1])
        self.refresh()

    def undo(self):
        if self.undo_stack:
            self.redo_stack.append(
                (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
            )
            self.restore(self.undo_stack.pop())

    def redo(self):
        if self.redo_stack:
            self.undo_stack.append(
                (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
            )
            self.restore(self.redo_stack.pop())

    def indices(self):
        return sorted(int(i) for i in self.tree.selection())

    def refresh(self, selection=None):
        self.tree.delete(*self.tree.get_children())
        point_names={c["point_id"]:f"コマンド{j+1}" for j,c in enumerate(self.commands) if c.get("point_id")}
        for block in (self.blocks if isinstance(self.blocks,list) else []):
            for j,command in enumerate(block.get("commands",[])):
                if command.get("point_id"):
                    point_names[block["id"]+"/"+command["point_id"]]=f"{block['name']} / コマンド{j+1}"
        warning_indices=set()
        if isinstance(self.blocks,list) and self.owner_block_id:
            context=dict(self.project or {},blocks=copy.deepcopy(self.blocks))
            owner=next((b for b in context["blocks"] if b["id"]==self.owner_block_id),None)
            if owner is not None:
                owner["commands"]=copy.deepcopy(self.commands)
                warning_indices={x["target_index"] for x in forward_links(context) if x["target_block"]==self.owner_block_id}
        self.tree.tag_configure("reference_warning",background="#fff0cf",foreground="#9a4800")
        for i, cmd in enumerate(self.commands):
            display = rewrite_references(dict(cmd), point_names)
            self.tree.insert(
                "",
                "end",
                iid=str(i),
                text=("⚠ " if i in warning_indices else "")+TYPE_LABELS.get(cmd.get("type"), cmd.get("type", "?")),
                tags=("reference_warning",) if i in warning_indices else (),
                image=self.command_images.get(cmd.get("type"), self.icons.get("commands")),
                values=(
                    (self.project or {})
                    .get("custom_commands", {})
                    .get(cmd.get("name"), {})
                    .get("name", command_summary(cmd))
                    if cmd.get("type") == "CUSTOM"
                    else command_summary(display),
                ),
            )
        if selection is not None and 0 <= selection < len(self.commands):
            self.tree.selection_set(str(selection))
            self.tree.see(str(selection))
        self.update_guide_actions()
        if self.commands:self.empty_help.place_forget()
        else:self.empty_help.place(relx=.5,rely=.48,anchor="center",relwidth=.94)
        if self.on_change:
            self.on_change()

    def names(self):
        return list(
            dict.fromkeys(
                list(self.local_names)
                + [
                    c["name"]
                    for c in walk_commands(self.commands)
                    if c.get("type", "").upper() == "SET"
                ]
            )
        )

    def prior_blocks(self):
        return [block for block in self.blocks if block.get("id") in self.previous_block_ids or (block.get("guide") and block.get("id") != self.owner_block_id)] if isinstance(self.blocks,list) else []

    def update_guide_actions(self, event=None):
        guide_owner=isinstance(self.blocks,list) and any(b.get("id")==self.owner_block_id and b.get("guide") for b in self.blocks)
        selected=self.indices()
        allowed=bool(self.owner_block_id and selected and not guide_owner and all(self.commands[i].get("type") in DRAWING_TYPES for i in selected))
        for button in self.toolbar.winfo_children():
            if str(button.cget("text")) == "ガイド化":button.configure(state="normal" if allowed else "disabled")
            if str(button.cget("text")) == COMMAND_GROUPS[-1][0]:button.configure(state="disabled" if guide_owner else "normal")

    def make_guide(self):
        indices=self.indices()
        if not indices:return
        if not isinstance(self.blocks,list) or not self.owner_block_id:
            return messagebox.showinfo("ガイド化", "作図ブロックの編集からガイド化してください", parent=self.frame)
        trial=copy.deepcopy(self.project or {})
        trial["blocks"]=copy.deepcopy(self.blocks)
        try:
            added=copy_to_guide(trial,self.owner_block_id,[self.commands[i] for i in indices],local_commands=self.commands)
            errors=validate_project(trial)
            if errors:raise ValueError("\n".join(errors[:8]))
        except ValueError as exc:
            return messagebox.showerror("ガイド化の確認",str(exc),parent=self.frame)
        if added:
            self.snapshot();replace_collection(self.blocks,trial["blocks"]);self.refresh(indices[0])

    def choose_add(self):
        from command_workbench import choose_kind
        groups=COMMAND_GROUPS
        if isinstance(self.blocks,list) and any(b.get('id')==self.owner_block_id and b.get('guide') for b in self.blocks):
            groups=[(label,[k for k in kinds if k in DRAWING_TYPES]) for label,kinds in groups]
            groups=[(label,kinds) for label,kinds in groups if kinds]
        choose_kind(self.frame,groups,TYPE_LABELS,self.add,self.icons)

    def add(self, kind="LINE"):
        before = copy.deepcopy(self.blocks)
        before_commands = copy.deepcopy(self.commands)
        selected = self.indices()
        insert_at = selected[-1] + 1 if selected else len(self.commands)
        d = edit_command(
            self.frame,
            {"type": kind},
            self.blocks,
            self.project,
            self.names(),
            sample_locals=self.local_names
            if isinstance(self.local_names, dict)
            else None,
            folder_id=self.folder_id,
            allow_continue=True, point_sources=self.commands[:insert_at],
            previous_blocks=self.prior_blocks(), owner_block_id=self.owner_block_id,
        )
        if d is not None:
            changed = copy.deepcopy(self.blocks)
            replace_collection(self.blocks, before)
            changed_commands = copy.deepcopy(self.commands)
            self.commands[:] = before_commands
            self.snapshot()
            self.commands[:] = changed_commands
            replace_collection(self.blocks, changed)
            ids = self.indices()
            at = ids[-1] + 1 if ids else len(self.commands)
            self.commands[at:at] = d if isinstance(d,list) else [d]
            self.refresh(at)

    def edit(self):
        ids = self.indices()
        if len(ids) != 1:
            return messagebox.showinfo(
                "コマンドの選択",
                "編集するコマンドを1件選択してください",
                parent=self.frame,
            )
        before = copy.deepcopy(self.blocks)
        i = ids[0]
        before_commands = copy.deepcopy(self.commands)
        d = edit_command(
            self.frame,
            self.commands[i],
            self.blocks,
            self.project,
            self.names(),
            sample_locals=self.local_names
            if isinstance(self.local_names, dict)
            else None,
            folder_id=self.folder_id,
            point_sources=self.commands[:i],
            previous_blocks=self.prior_blocks(), owner_block_id=self.owner_block_id,
        )
        if d is not None:
            changed = copy.deepcopy(self.blocks)
            replace_collection(self.blocks, before)
            changed_commands = copy.deepcopy(self.commands)
            self.commands[:] = before_commands
            self.snapshot()
            self.commands[:] = changed_commands
            replace_collection(self.blocks, changed)
            self.commands[i] = d
            self.refresh(i)

    def duplicate(self):
        ids = self.indices()
        if not ids:
            return
        self.snapshot()
        for i in reversed(ids):
            self.commands.insert(i + 1, clone_commands([self.commands[i]])[0])
        self.refresh(ids[0] + 1)

    def delete(self):
        ids = self.indices()
        if not ids:
            return
        self.snapshot()
        for i in reversed(ids):
            self.commands.pop(i)
        self.refresh(min(ids[0], len(self.commands) - 1))

    def move(self, delta):
        ids = self.indices()
        if len(ids) == 1 and 0 <= ids[0] + delta < len(self.commands):
            i=ids[0];j=i+delta
            if self.owner_block_id and isinstance(self.blocks,list):
                trial=dict(self.project or {},blocks=copy.deepcopy(self.blocks))
                owner=next(b for b in trial["blocks"] if b["id"]==self.owner_block_id)
                owner["commands"]=copy.deepcopy(self.commands)
                owner["commands"][i],owner["commands"][j]=owner["commands"][j],owner["commands"][i]
                if not confirm_reference_order(self.frame,trial):return
                commands=next(b for b in trial["blocks"] if b["id"]==self.owner_block_id)["commands"]
                self.snapshot();replace_collection(self.blocks,trial["blocks"]);self.commands[:]=commands
            else:
                self.snapshot();self.commands[i],self.commands[j]=self.commands[j],self.commands[i]
            self.refresh(j)



class MacroEditor:
    def __init__(
        self, parent, preset, blocks, on_close, project=None, selected_rows=None
    ):
        self.unified = isinstance(blocks, list)
        self.win = tk.Toplevel(parent)
        self.win.title(
            ("ブロック編集 · " if self.unified else "プリセット編集 · ")
            + preset.get("name", "")
        )
        fit_window(self.win, 1320, 860, 850, 640)
        self.win.transient(parent)
        self.win.grab_set()
        self.preset = preset
        self.blocks = blocks
        self.working_blocks = copy.deepcopy(blocks)
        self.on_close = on_close
        self.project = project
        self._preview_job = None
        self.win.bind("<Destroy>", self.cancel_preview_job, add="+")
        self.selected_rows = list(selected_rows) if selected_rows is not None else (
            [0] if project and get_rows(project) else []
        )
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        self.win.bind("<Escape>", lambda e: self.cancel())
        self.command_panes = ttk.Panedwindow(self.win, orient="horizontal")
        self.command_panes.pack(fill="both", expand=True, padx=12, pady=(12, 8))
        self._split_initialized = False
        self.command_panes.bind("<Configure>", self.fit_command_panes)
        command_page = ttk.Frame(self.command_panes)
        self.command_panes.add(command_page, weight=1)
        meta = ttk.Frame(command_page, padding=(10, 0, 10, 8))
        meta.pack(fill="x")
        self.name = tk.StringVar(value=preset.get("name", ""))
        self.cond = tk.StringVar(value=preset.get("condition", ""))
        if not self.unified:
            self.enabled = tk.BooleanVar(value=preset.get("enabled", True))
        name_row = ttk.Frame(meta)
        name_row.pack(fill="x", pady=(2, 7))
        ttk.Label(name_row, text="名前", width=6).pack(side="left")
        ttk.Entry(name_row, textvariable=self.name).pack(side="left", fill="x", expand=True)
        if not self.unified:
            ttk.Checkbutton(meta, text="このプリセットを有効にする", variable=self.enabled).pack(anchor="w")
        self.conditions_panel = ttk.Frame(command_page, padding=(10, 8))
        self.conditions_panel.pack(side="bottom", fill="x")
        conditions = ttk.Frame(self.conditions_panel)
        condition_row = ttk.Frame(conditions)
        condition_row.pack(fill="x", pady=(3, 0))
        ttk.Label(condition_row, text="条件", width=6).pack(side="left")
        ttk.Entry(condition_row, textvariable=self.cond).pack(
            side="left", fill="x", expand=True
        )
        ttk.Button(
            condition_row,
            text="条件を作る…",
            command=lambda: show_condition_builder(
                self.win, self.cond, self.project or {}, preset.get("variables", {})
            ),
        ).pack(side="left", padx=(6, 0))
        condition_hint = ttk.Label(
            conditions,
            text='例: @TYPE == "A"。空欄なら作図対象の行に適用。',
            style="Muted.TLabel", wraplength=350,
        )
        condition_hint.pack(anchor="w", pady=(4, 0))
        conditions.bind("<Configure>", lambda e: condition_hint.configure(wraplength=max(160, e.width)))
        condition_open = [bool(self.cond.get().strip())]

        def toggle_conditions():
            condition_open[0] = not condition_open[0]
            if condition_open[0]:
                conditions.pack(fill="x", pady=(6, 0))
            else:
                conditions.pack_forget()
            condition_button.configure(
                text="▾ 条件" if condition_open[0] else
                ("▸ 条件あり" if self.cond.get().strip() else "▸ 条件を追加")
            )

        self.conditions_actions = ttk.Frame(self.conditions_panel)
        self.conditions_actions.pack(fill="x", pady=(8, 0))
        self.condition_button = condition_button = ttk.Button(self.conditions_actions, command=toggle_conditions, style="Compact.TButton")
        condition_button.pack(side="left", fill="x", expand=True)
        self.preview_through = tk.BooleanVar(
            value=getattr(self.win._root(), "_command_preview_through", False)
        )
        self.preview_through_button = ttk.Checkbutton(
            self.conditions_actions,
            text="選択したコマンドまで表示",
            variable=self.preview_through,
            command=self.change_preview_mode,
        )
        self.preview_through_button.pack(side="right", padx=(8, 0))
        if condition_open[0]:
            conditions.pack(fill="x", pady=(6, 0))
        condition_button.configure(
            text="▾ 条件" if condition_open[0] else "▸ 条件を追加"
        )
        self.cond.trace_add(
            "write",
            lambda *_: condition_button.configure(
                text="▾ 条件" if condition_open[0] else
                ("▸ 条件あり" if self.cond.get().strip() else
                 "▸ 条件を追加")
            ),
        )
        bar = ttk.Frame(self.win, padding=12)
        bar.pack(side="bottom", fill="x", before=self.command_panes)
        ttk.Button(bar, text="キャンセル", command=self.cancel).pack(side="left")
        ttk.Button(
            bar,
            text="ブロックを反映" if self.unified else "プリセットを確定",
            style="Primary.TButton",
            command=self.save,
        ).pack(side="right")
        self.preview_frame = preview_frame = ttk.Frame(self.command_panes)
        self.command_panes.add(preview_frame, weight=1)
        self.preview_label = ttk.Label(
            preview_frame, text="選択したコマンドのプレビュー",
            style="Muted.TLabel", padding=(8, 4), wraplength=400,
        )
        self.preview_label.pack(side="bottom", fill="x")
        self.preview_canvas = DrawingCanvas(preview_frame, width=320, height=320)
        self.preview_canvas.pack(fill="both", expand=True, padx=(8, 0))
        self.preview_tools = ttk.Frame(self.preview_canvas, padding=4, style="Preview.TFrame")
        self.preview_tools.place(relx=1, rely=1, x=-12, y=-10, anchor="se")
        self.preview_canvas.set_overlay_controls(self.preview_tools)
        self.actual_color_toggle = self.preview_canvas.make_color_toggle(self.preview_tools)
        self.actual_color_toggle.pack(side="left", padx=3)
        preview_frame.bind(
            "<Configure>",
            lambda event: self.preview_label.configure(wraplength=max(120, event.width - 16)),
        )
        self.list = CommandList(
            command_page,
            copy.deepcopy(preset.get("commands", [])),
            self.working_blocks,
            self.show_preview,
            self.queue_preview,
            project,
            dict(preset.get("variables", {})),
            folder_id=preset.get("folder_id", ""),
            previous_blocks=self.working_blocks[:next((i for i,b in enumerate(self.working_blocks) if b.get("id")==preset.get("id")),0)] if self.unified else (),
            owner_block_id=preset.get("id"),
        )
        self.list.tree.tag_configure("previewed", background="#edf3ff")
        for var in (self.name, self.cond, *((self.enabled,) if not self.unified else ())):
            var.trace_add("write", lambda *_: self.queue_preview())
        self.queue_preview()

    def fit_command_panes(self, event):
        if event.width < 650:
            return
        position = self.command_panes.sashpos(0) if self._split_initialized else int(event.width * 0.52)
        self.command_panes.sashpos(0, max(320, min(position, event.width - 320)))
        self._split_initialized = True

    def change_preview_mode(self):
        self.win._root()._command_preview_through = self.preview_through.get()
        self.show_preview(self.list.indices())

    def queue_preview(self):
        if hasattr(self, "preview_canvas") and self._preview_job is None and self.win.winfo_exists():
            self._preview_job = self.win.after_idle(self.run_queued_preview)

    def run_queued_preview(self):
        self._preview_job = None
        if self.win.winfo_exists():
            self.show_preview(self.list.indices())

    def cancel_preview_job(self, event):
        if event.widget is self.win and self._preview_job is not None:
            self.win.after_cancel(self._preview_job)
            self._preview_job = None

    def current(self):
        result = dict(
            self.preset,
            name=self.name.get().strip(),
            condition=self.cond.get().strip(),
            commands=copy.deepcopy(self.list.commands),
        )

        if self.unified:
            result.pop("enabled", None)
            result.pop("draw", None)
        else:
            result["enabled"] = self.enabled.get()
        return result

    def trial(self):
        trial = copy.deepcopy(self.project)
        if self.unified:
            trial["blocks"] = copy.deepcopy(self.working_blocks)
            index = index_of(trial, self.preset["id"])
            trial["blocks"][index] = self.current()
        else:
            index = next(
                i for i, p in enumerate(self.project["presets"]) if p is self.preset
            )
            trial["presets"][index] = self.current()
            trial["blocks"] = copy.deepcopy(self.working_blocks)
        return trial, index

    def show_preview(self, indices):
        if not hasattr(self, "preview_canvas") or not self.win.winfo_exists():
            return
        self.preview_canvas.set_color_resources(self.project or {})
        self.preview_canvas.set_items([])
        through = self.preview_through.get()
        end = max(indices) if indices else None
        for node in self.list.tree.get_children():
            active = through and end is not None and int(node) <= end
            tags=[tag for tag in self.list.tree.item(node,"tags") if tag != "previewed"]
            if active:tags.append("previewed")
            self.list.tree.item(node,tags=tuple(tags))
        if through and end is None:
            self.preview_canvas.set_items([], message="確認するコマンドを選択してください")
            self.preview_label.configure(text="先頭から選択したコマンドまでを表示")
            return
        if not self.project or not self.selected_rows:
            self.preview_label.configure(text="入力表の「SCR出力」列にチェックしてください")
            return
        try:
            trial, pi = self.trial()
            preview_indices = list(range(end + 1)) if through else indices
            if through:
                # Later unfinished commands must not prevent checking this stage.
                collection = "blocks" if self.unified else "presets"
                trial[collection][pi]["commands"] = trial[collection][pi]["commands"][:end + 1]
            if self.unified:
                for i, block in enumerate(trial["blocks"]):
                    block["draw"] = i <= pi
            events = []
            _, items = compile_project(
                trial, self.selected_rows[:1], diagnostics=events
            )
            events = [
                e
                for e in events
                if e.get("block_index" if self.unified else "preset_index") == pi
                and (not preview_indices or e.get("command_index") in preview_indices)
            ]
            items = [
                a
                for a in items
                if (a.get("guide") and a["block_index" if self.unified else "preset_index"] != pi) or (a["block_index" if self.unified else "preset_index"] == pi
                and (not preview_indices or a["command_index"] in preview_indices))
            ]
            custom_count = sum(e["type"] == "CUSTOM" for e in events)
            self.preview_canvas.set_items(
                items,
                message="登録コマンドの図形はプレビュー対象外です。生成SCRで確認してください。"
                if custom_count
                else None,
            )
            self.preview_label.configure(
                text=(f"ここまで {end + 1}/{len(self.list.commands)}コマンド · " if through else "編集中の値を反映 · ")
                + f"{self.selected_rows[0] + 1}行目 / 標準{sum(not a.get('guide') for a in items)}図形"
                + (f" / ガイド{sum(bool(a.get('guide')) for a in items)}図形" if any(a.get("guide") for a in items) else "")
                + (f" / 登録{custom_count}件はSCRのみ" if custom_count else "")
            )
        except Exception as exc:
            self.preview_label.configure(text="プレビュー: " + str(exc)[:110])

    def cancel(self):
        if (
            self.current() != self.preset or self.working_blocks != self.blocks
        ) and not messagebox.askyesno(
            "変更の破棄",
            "ブロックの変更を破棄しますか？"
            if self.unified
            else "プリセットの変更を破棄しますか？",
            parent=self.win,
        ):
            return
        self.win.destroy()

    def save(self):
        current = self.current()
        if not current["name"]:
            return messagebox.showerror(
                "名前",
                "ブロック名を入力してください"
                if self.unified
                else "プリセット名を入力してください",
                parent=self.win,
            )
        if self.project:
            trial, _ = self.trial()
            errors = validate_sequential_project(trial) if self.unified else validate_project(trial)
            if errors:
                return messagebox.showerror(
                    "構成の確認", "\n".join(errors[:8]), parent=self.win
                )
        if self.unified:
            if self.project:
                replace_collection(self.blocks, trial["blocks"])
            else:
                index = next(
                    i
                    for i, block in enumerate(self.working_blocks)
                    if block["id"] == current["id"]
                )
                self.working_blocks[index] = current
                replace_collection(self.blocks, self.working_blocks)
        else:
            self.preset.clear()
            self.preset.update(current)
            replace_collection(self.blocks, self.working_blocks)
        self.win.destroy()
        self.on_close()

