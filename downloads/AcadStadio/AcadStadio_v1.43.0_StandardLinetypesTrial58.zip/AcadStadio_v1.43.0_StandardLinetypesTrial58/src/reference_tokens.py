"""Referenced inputs in a command, excluding quoted literal text."""
import re
from table_references import _map_references
from table_formulas import QUOTED


def command_references(command):
    found=[]
    def text(value):
        def table(match):
            found.append(match.group(0))
            if match.group('row'):text(match.group('row')[1:-1])
            return ' '
        remaining=_map_references(value,table)
        for part in QUOTED.split(remaining)[::2]:
            found.extend(re.findall(r'(?<![\w.])(?:変数|variable|global|settings)\.\w+',part))
    def scan(item):
        for key,value in item.items():
            if key in ('type','name','point_id'):continue
            if isinstance(value,dict):scan(value)
            elif isinstance(value,list):
                for child in value:
                    if isinstance(child,dict):scan(child)
            elif isinstance(value,str):
                if key=='text' and not value.startswith(('=','@','[')):continue
                if key=='layer' and not value.startswith(('=','@','[','settings.','変数.','variable.','global.')):continue
                text(value)
    scan(command)
    return list(dict.fromkeys(found))
