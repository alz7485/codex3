from table_grid import GridTreeview
"""Small, optional helpers for entering CADFlow expressions.

The helper only writes an expression into the existing text variable.  All
expressions can still be edited manually; the compiler and JSON model are
unchanged.
"""

import ast
import json
import re
import tkinter as tk
from tkinter import messagebox, ttk

from engine import MacroError, parse_expression
from project_data import get_rows, input_tables


COMPARISONS = {"等しい": "==", "異なる": "!=", "より大きい": ">", "以上": ">=", "より小さい": "<", "以下": "<="}
RIGHT_MODES = ("文字", "数値・計算式")
SIMPLE_COMPARISON = re.compile(
    r"^((?:\[(?:\\.|[^\]\\])+\])?@[^\W\d]\w*(?:[{｛][^{}｛｝]+[}｝])?"
    r"|(?:settings|variable|global|local|loop)\.[A-Za-z_][A-Za-z_0-9]*"
    r"|変数\.\w+)\s*"
    r"(==|!=|>=|<=|>|<)\s*(.+)$"
)


def table_columns(table):
    """Return columns in display order, including columns absent from row one."""
    return list(dict.fromkeys(key for row in table.get("rows", []) for key in row))


def selected_table_reference(table_name, column, row_mode="current", row_number=None, variable=None):
    """Build one editable expression from a table header/cell/variable selection."""
    if not table_name or not isinstance(table_name, str):
        raise ValueError("入力表を選択してください")
    if not isinstance(column, str) or not re.fullmatch(r"[^\W\d]\w*", column):
        raise ValueError("参照する列を選択してください")
    escaped = table_name.replace("\\", r"\\").replace("]", r"\]")
    reference = f"[{escaped}]@{column}"
    if row_mode == "current":
        return reference
    if row_mode == "fixed":
        if type(row_number) is not int or row_number < 1:
            raise ValueError("固定行のセルを選択してください")
        return f"{reference}{{{row_number}}}"
    if row_mode == "variable":
        if not variable or not isinstance(variable, str) or not variable.isidentifier():
            raise ValueError("行番号を持つ変数を選択してください")
        return f"{reference}{{変数.{variable}}}"
    raise ValueError("行の指定方法が不正です")


def show_table_reference_picker(parent, project, on_select, on_replace=None, *, target_axis=None):
    """Pick a column (current row), a cell (fixed row), or a variable row.

    This intentionally uses a child dialog: the command form can retain its
    existing modal and cancel/confirm behavior, and no project data is changed.
    Large tables are paged instead of creating thousands of Tk widgets.
    """
    tables = input_tables(project)
    if not tables:
        messagebox.showinfo("表から選択", "入力表がありません。", parent=parent)
        return
    win = tk.Toplevel(parent)
    win.title("表から参照を選ぶ")
    win.geometry("930x580")
    win.minsize(700, 420)
    host = parent.winfo_toplevel()
    win.transient(host)
    win.grab_set()

    names = [table["name"] for table in tables]
    active_id = project.get("active_table", tables[0]["id"])
    active = next((t for t in tables if t["id"] == active_id), tables[0])
    table_name = tk.StringVar(value=active["name"])
    variable_names = list(project.get("globals", {}))
    row_variable = tk.StringVar(value=variable_names[0] if variable_names else "")
    jump_row = tk.StringVar(value="1")
    page = [0]
    page_size = 100
    chosen = {"column": None, "row": None}

    outer = ttk.Frame(win, padding=14)
    outer.pack(fill="both", expand=True)
    footer = ttk.Frame(outer)
    footer.pack(side="bottom", fill="x")
    heading = ttk.Frame(outer)
    heading.pack(fill='x',pady=(0,8));heading.columnconfigure(1,weight=1)
    ttk.Label(heading,text='入力表').grid(row=0,column=0,sticky='w')
    table_choice=ttk.Combobox(heading,textvariable=table_name,values=names,state='readonly',width=20)
    table_choice.grid(row=0,column=1,sticky='ew',padx=(8,16))
    if target_axis is not None:
        ttk.Label(heading,text='入力先').grid(row=0,column=2)
        ttk.Combobox(heading,textvariable=target_axis,values=('X','Y'),state='readonly',width=5).grid(row=0,column=3,padx=(6,0))
    explanation=ttk.Label(heading,text='列見出し：作図対象と同じ行 ／ セル：クリックした行で固定',style='Muted.TLabel')
    explanation.grid(row=1,column=0,columnspan=4,sticky='w',pady=(6,0))
    heading.bind('<Configure>',lambda event:explanation.configure(wraplength=max(100,event.width-8)))

    frame = ttk.Frame(outer)
    frame.pack(fill="both", expand=True)
    frame.columnconfigure(0, weight=1)
    frame.rowconfigure(0, weight=1)
    tree = GridTreeview(frame, show="tree headings", selectmode="none")
    tree.grid(row=0, column=0, sticky="nsew")
    vert = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    vert.grid(row=0, column=1, sticky="ns")
    horizontal = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
    horizontal.grid(row=1, column=0, sticky="ew")
    tree.configure(yscrollcommand=vert.set, xscrollcommand=horizontal.set)
    tree.heading("#0", text="行番号")
    tree.column("#0", width=70, minwidth=60, stretch=False, anchor="center")

    page_bar = ttk.Frame(footer)
    page_bar.pack(fill="x", pady=(9, 0))
    back = ttk.Button(page_bar, text="◀ 前の100行")
    back.pack(side="left")
    page_info = tk.StringVar()
    ttk.Label(page_bar, textvariable=page_info).pack(side="left", padx=12)
    forward = ttk.Button(page_bar, text="次の100行 ▶")
    forward.pack(side="left")
    ttk.Label(page_bar, text="行へ移動").pack(side="left", padx=(22, 6))
    jump = ttk.Entry(page_bar, textvariable=jump_row, width=9)
    jump.pack(side="left")

    modes = {
        "作図対象と同じ行": "current",
        "クリックした固定行": "fixed",
        "変数で行を指定": "variable",
    }
    mode_names = {value: key for key, value in modes.items()}
    selected_mode = tk.StringVar(value=mode_names["current"])
    opts = ttk.Frame(footer)
    opts.pack(fill="x", pady=(12, 2))
    ttk.Label(opts, text="行の指定").pack(side="left")
    mode_combo = ttk.Combobox(
        opts, textvariable=selected_mode, values=list(modes), state="readonly", width=22
    )
    mode_combo.pack(side="left", padx=8)
    ttk.Label(opts, text="行番号を入れた変数").pack(side="left", padx=(16, 8))
    variable_combo = ttk.Combobox(
        opts, textvariable=row_variable, values=variable_names, state="disabled", width=22
    )
    variable_combo.pack(side="left")
    expression = tk.StringVar(value="表の列見出し、またはセルをクリックしてください")
    ttk.Label(footer, textvariable=expression, style="Section.TLabel", wraplength=860).pack(
        fill="x", anchor="w", pady=(10, 0)
    )
    buttons = ttk.Frame(footer)
    buttons.pack(fill="x", pady=(12, 0))
    ttk.Button(buttons, text="キャンセル", command=win.destroy).pack(side="left")
    insert = ttk.Button(buttons, text="この参照を挿入", style="Primary.TButton", state="disabled")
    insert.pack(side="right")

    def current_table():
        return next(table for table in tables if table["name"] == table_name.get())

    def refresh_expression(*_):
        mode = modes[selected_mode.get()]
        variable_combo.configure(state="readonly" if mode == "variable" and variable_names else "disabled")
        try:
            text = selected_table_reference(
                table_name.get(), chosen["column"], mode, chosen["row"], row_variable.get()
            )
        except ValueError as exc:
            expression.set(str(exc) if chosen["column"] else "表の列見出し、またはセルをクリックしてください")
            insert.configure(state="disabled")
        else:
            expression.set("挿入する式: " + text)
            insert.configure(state="normal")

    highlights=[]
    original_draw=tree._draw_grid
    def draw_selection():
        original_draw()
        used=0
        if not chosen['column']:
            for label in highlights:label.place_forget()
            return
        for item in tree.get_children():
            if chosen['row'] is not None and int(item)+1!=chosen['row']:continue
            bounds=tree.bbox(item,chosen['column'])
            if not bounds:continue
            x,y,w,h=bounds
            if y<25:continue
            if used==len(highlights):
                label=tk.Label(tree,bg='#dce8ff',fg='#1759a6',anchor='w',padx=4,borderwidth=0)
                for seq in ('<ButtonPress-1>','<ButtonRelease-1>'):
                    label.bind(seq,lambda event,s=seq:tree._forward(event,s))
                label.bind('<MouseWheel>',lambda event:tree.yview_scroll(-1 if event.delta>0 else 1,'units'))
                highlights.append(label)
            label=highlights[used];used+=1
            label.configure(text=tree.set(item,chosen['column']))
            label.place(x=x+1,y=y+1,width=max(1,w-2),height=max(1,h-2));label.lift()
        for label in highlights[used:]:label.place_forget()
    tree._draw_grid=draw_selection

    def choose_column(column):
        tree.selection_remove(tree.selection())
        chosen.update(column=column, row=None)
        tree._queue_grid()
        selected_mode.set(mode_names["current"])
        refresh_expression()

    def choose_cell(event):
        if tree.identify_region(event.x, event.y) != "cell":
            return
        column_id = tree.identify_column(event.x)
        item = tree.identify_row(event.y)
        if column_id == "#0" or not item:
            return
        column_index = int(column_id[1:]) - 1
        columns = table_columns(current_table())
        if column_index < 0 or column_index >= len(columns):
            return
        tree.selection_remove(tree.selection())
        chosen.update(column=columns[column_index], row=int(item) + 1)
        tree._queue_grid()
        selected_mode.set(mode_names["fixed"])
        refresh_expression()

    def draw_page():
        table = current_table()
        cols = table_columns(table)
        rows = table["rows"]
        tree.delete(*tree.get_children())
        tree.configure(columns=cols)
        for col in cols:
            tree.heading(col, text=col, command=lambda c=col: choose_column(c))
            tree.column(col, width=120, minwidth=65, stretch=False)
        start = page[0] * page_size
        end = min(start + page_size, len(rows))
        for index in range(start, end):
            row = rows[index]
            tree.insert("", "end", iid=str(index), text=str(index + 1), values=[row.get(k, "") for k in cols])
        page_info.set(f"{start + 1}〜{end} / 全{len(rows)}行" if rows else "0行")
        back.configure(state="normal" if page[0] > 0 else "disabled")
        forward.configure(state="normal" if end < len(rows) else "disabled")

    def change_table(_=None):
        page[0] = 0
        chosen.update(column=None, row=None)
        selected_mode.set(mode_names["current"])
        jump_row.set("1")
        draw_page()
        refresh_expression()

    def shift_page(direction):
        page[0] += direction
        draw_page()

    def go_to_row(_=None):
        try:
            number = int(jump_row.get())
        except ValueError:
            number = 0
        if not 1 <= number <= len(current_table()["rows"]):
            messagebox.showerror("行番号", "存在する行番号を指定してください。", parent=win)
            return
        page[0] = (number - 1) // page_size
        draw_page()
        tree.selection_set(str(number - 1))
        tree.see(str(number - 1))

    def confirm():
        try:
            value = selected_table_reference(
                table_name.get(), chosen["column"], modes[selected_mode.get()],
                chosen["row"], row_variable.get(),
            )
        except ValueError:
            return
        win.destroy()
        if on_replace is not None:
            on_replace(value)
        else:
            on_select(value)

    table_choice.bind("<<ComboboxSelected>>", change_table)
    tree.bind("<ButtonRelease-1>", choose_cell)
    selected_mode.trace_add("write", refresh_expression)
    row_variable.trace_add("write", refresh_expression)
    back.configure(command=lambda: shift_page(-1))
    forward.configure(command=lambda: shift_page(1))
    ttk.Button(page_bar, text="移動", command=go_to_row).pack(side="left", padx=6)
    jump.bind("<Return>", go_to_row)
    insert.configure(command=confirm)
    win.bind("<Escape>", lambda _: win.destroy())
    draw_page()
    refresh_expression()
    parent.wait_window(win)
    try:
        if host.winfo_exists() and host is not host._root():
            host.grab_set()
    except tk.TclError:
        pass


def reference_groups(project, local_names=()):
    """Return available reference names grouped by where they come from."""
    if not isinstance(project, dict):
        project = {}

    def columns(rows):
        seen = set()
        for row in rows:
            for key in row:
                if key not in seen:
                    seen.add(key)
                    yield key

    groups = [
        ("入力表の列", ["@" + k for k in columns(get_rows(project))]),
        ("共通設定", ["settings." + k for k in project.get("settings", {})]),
        ("変数", ["変数." + k for k in project.get("globals", {})]),
        ("繰り返し", ["loop.index", "loop.number", "loop.count"]),
    ]
    for table in input_tables(project):
        escaped = table["name"].replace("\\", r"\\").replace("]", r"\]")
        groups.append((
            "表: " + table["name"],
            ["[" + escaped + "]@" + k for k in columns(table["rows"])],
        ))
    return [(name, list(dict.fromkeys(items))) for name, items in groups if items]


def comparison_expression(left, operator, right, right_mode):
    """Build a safe literal comparison or retain a user-entered numeric expression."""
    left, right = left.strip(), right.strip()
    if not left or not right:
        raise ValueError("比較する項目と値の両方を入力してください")
    if operator not in COMPARISONS.values():
        raise ValueError("比較演算子を選択してください")
    if right_mode not in RIGHT_MODES:
        raise ValueError("値の種類を選択してください")
    operand = json.dumps(right, ensure_ascii=False) if right_mode == "文字" else right
    result = f"{left} {operator} {operand}"
    parse_expression(result)
    return result


def parse_simple_comparison(expression):
    """Populate the assistant only when an existing formula is unambiguous."""
    match = SIMPLE_COMPARISON.fullmatch(expression.strip())
    if not match:
        return None
    left, operator, operand = match.groups()
    if operand.startswith(("'", '"')):
        try:
            literal = ast.literal_eval(operand)
        except (SyntaxError, ValueError):
            return None
        if not isinstance(literal, str):
            return None
        return left, operator, literal, "文字"
    return left, operator, operand, "数値・計算式"


def show_condition_builder(parent, variable, project, local_names=()):
    """Open a non-destructive guided editor for a common one-comparison condition."""
    groups = reference_groups(project, local_names)
    refs = [reference for _, items in groups for reference in items]
    existing = variable.get().strip()
    parsed = parse_simple_comparison(existing)
    left = tk.StringVar(value=parsed[0] if parsed else (refs[0] if refs else ""))
    operator = tk.StringVar(value=parsed[1] if parsed else "==")
    right = tk.StringVar(value=parsed[2] if parsed else "")
    mode = tk.StringVar(value=parsed[3] if parsed else "文字")
    win = tk.Toplevel(parent)
    win.title("かんたん条件入力")
    win.transient(parent.winfo_toplevel())
    win.resizable(False, False)
    win.grab_set()
    content = ttk.Frame(win, padding=18)
    content.pack(fill="both", expand=True)
    ttk.Label(content, text="どの値が、何と一致するかを指定します", style="Section.TLabel").pack(anchor="w")
    ttk.Label(
        content,
        text="AND / ORなど複雑な式は、元の入力欄へ直接記入できます。",
        style="Muted.TLabel",
    ).pack(anchor="w", pady=(4, 12))
    grid = ttk.Frame(content)
    grid.pack(fill="x")
    for i, (label, var, values) in enumerate(
        [
            ("比較する列・変数", left, refs),
            ("比較方法", operator, list(COMPARISONS.values())),
            ("値の種類", mode, list(RIGHT_MODES)),
        ]
    ):
        ttk.Label(grid, text=label).grid(row=i, column=0, sticky="w", padx=(0, 10), pady=5)
        ttk.Combobox(grid, textvariable=var, values=values, width=35, state="readonly" if i else "normal").grid(
            row=i, column=1, sticky="ew", pady=5
        )
    ttk.Label(grid, text="比較する値").grid(row=3, column=0, sticky="w", pady=5)
    right_entry = ttk.Entry(grid, textvariable=right, width=38)
    right_entry.grid(row=3, column=1, sticky="ew", pady=5)
    grid.columnconfigure(1, weight=1)
    preview = tk.StringVar()

    def update_preview(*_):
        try:
            preview.set("生成する条件: " + comparison_expression(left.get(), operator.get(), right.get(), mode.get()))
        except (ValueError, MacroError):
            preview.set("比較する値を入力すると条件式を確認できます。")

    for var in (left, operator, right, mode):
        var.trace_add("write", update_preview)
    update_preview()
    ttk.Label(content, textvariable=preview, wraplength=420, style="Muted.TLabel").pack(
        anchor="w", pady=(12, 4)
    )
    if existing and parsed is None:
        ttk.Label(
            content,
            text="現在の複雑な条件式はそのまま保持しています。「適用」を押すまで変更しません。",
            style="Muted.TLabel",
            wraplength=420,
        ).pack(anchor="w", pady=(0, 6))

    def apply():
        try:
            expression = comparison_expression(left.get(), operator.get(), right.get(), mode.get())
        except (ValueError, MacroError) as exc:
            messagebox.showerror("条件式の確認", str(exc), parent=win)
            return
        variable.set(expression)
        win.destroy()

    actions = ttk.Frame(content)
    actions.pack(fill="x", pady=(10, 0))
    ttk.Button(actions, text="キャンセル", command=win.destroy).pack(side="left")
    ttk.Button(actions, text="条件なし（全行）", command=lambda: (variable.set(""), win.destroy())).pack(
        side="left", padx=8
    )
    ttk.Button(actions, text="この条件を適用", style="Primary.TButton", command=apply).pack(side="right")
    win.bind("<Escape>", lambda _: win.destroy())
    right_entry.focus_set()
    parent.wait_window(win)
    try:
        if parent.winfo_toplevel().winfo_exists():
            parent.winfo_toplevel().grab_set()
    except tk.TclError:
        pass
