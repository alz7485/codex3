# Windows EXEの作成（onedir）

Windows上で、Python 3.11以上とPython Launcher（`py`）を用意してください。
ZIPを展開し、`AcadStadio.spec` があるフォルダをPowerShellで開いて実行します。
出力するEXEのビット数は、ビルドに使うPythonのビット数に従います。

## コピーして実行するコマンド

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt pyinstaller
.\.venv\Scripts\python.exe -m PyInstaller --clean --noconfirm AcadStadio.spec
```

仮想環境の有効化やPowerShellの実行ポリシー変更は不要です。
同梱のspecがonedir構成を指定しているため、`--onedir` の追加は不要です。
アプリ名、アイコン、Excel読込、同梱画像・ガイド・サンプルもspecで設定しています。

## 起動と配布

ビルド後は次のコマンドで起動します。

```powershell
.\dist\AcadStadio\AcadStadio.exe
```

配布するときは **`dist\AcadStadio` フォルダ全体** をZIPにしてください。
EXEの隣にある `_internal` などのファイル・フォルダも必要です。
配布先ではZIPを展開してからEXEを起動します。Pythonのインストールは不要です。

配布前に、EXEからの起動、サンプル読込、作図プレビュー、JSON保存・再読込、
登録コマンド一覧、SCR書出、Excel読込をWindows上で確認してください。
再ビルド時は `--noconfirm` により同名のビルド出力が置き換わります。
プロジェクトの保存先には `build`・`dist` フォルダ以外を選んでください。

この配布物にはソースとビルド設定を同梱しています。EXE自体は含みません。
今回の検証環境はLinuxのため、WindowsでのEXEビルド・実行は未検証です。

## プロジェクトの保存先

Trial55から、EXEと同じフォルダの `Data` 内にプロジェクトJSONを保存します。書き込み可能な場所へonedirフォルダ一式を展開してください。Data内のフォルダ階層がプロジェクト一覧に対応します。
