"""Folder discovery and project-list preferences without touching user files."""

from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from project_library import ProjectLibrary, canonical, data_directory


class ProjectLibraryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.state = self.base / "settings" / "library.json"
        self.library = ProjectLibrary(self.state)

    def test_startup_does_not_write_files(self):
        self.assertEqual(self.library.files(), [])
        self.assertFalse(self.state.exists())
        self.assertFalse(self.library.directory.exists())

    def test_folder_and_external_history_survive_restart(self):
        folder = self.base / "図面JSON"
        folder.mkdir()
        (folder / "加工用.json").write_text("{}")
        outside = self.base / "外部.json"
        outside.write_text("{}")
        self.library.select_directory(folder)
        self.library.remember(outside)
        restarted = ProjectLibrary(self.state)
        self.assertEqual(restarted.directory, folder)
        self.assertEqual(
            restarted.files(), [canonical(folder / "加工用.json"), canonical(outside)]
        )

    def test_non_json_and_backups_are_not_projects(self):
        folder = self.library.ensure_directory()
        (folder / "a.JSON").write_text("{}")
        (folder / "notes.txt").write_text("a")
        (folder / "a_backups").mkdir()
        (folder / "a_backups" / "old.json").write_text("{}")
        self.assertEqual(self.library.files(), [canonical(folder / "a.JSON")])
        self.library.select_directory(self.state.parent)
        self.assertNotIn(canonical(self.state), self.library.files())

    def test_history_is_deduplicated_and_bounded(self):
        for i in range(105):
            self.library.remember(self.base / f"{i}.json")
        self.library.remember(self.base / "104.json")
        reloaded = ProjectLibrary(self.state)
        self.assertEqual(len(reloaded.recent), 100)
        self.assertEqual(reloaded.recent[0], canonical(self.base / "104.json"))
        self.assertNotIn(canonical(self.base / "0.json"), reloaded.recent)

    def test_corrupt_preferences_fall_back_without_deleting_projects(self):
        self.state.parent.mkdir()
        for payload in (
            "broken",
            "[]",
            '{"version": 2}',
            '{"version":1,"directory":"x","recent":[null]}',
        ):
            self.state.write_text(payload)
            library = ProjectLibrary(self.state)
            self.assertTrue(library.warning)
            self.assertEqual(library.directory, self.state.parent / "Projects")
            self.assertEqual(self.state.read_text(), payload)

    def test_failed_folder_change_keeps_previous_selection(self):
        folder = self.base / "selected"
        folder.mkdir()
        before = self.library.directory
        with patch(
            "project_library.atomic_save", side_effect=PermissionError("denied")
        ):
            with self.assertRaises(PermissionError):
                self.library.select_directory(folder)
        self.assertEqual(self.library.directory, before)
        with self.assertRaises(ValueError):
            self.library.select_directory(self.base / "missing")

    def test_deleted_external_file_is_removed_from_list(self):
        missing = self.base / "gone.json"
        self.library.remember(missing)
        self.assertNotIn(canonical(missing), self.library.files())
        self.assertNotIn(
            canonical(self.base / "current.json"),
            self.library.files(self.base / "current.json"),
        )

    def test_user_data_directory_is_independent_of_exe_resources(self):
        with patch.dict("os.environ", {"CADFLOW_DATA_DIR": str(self.base)}):
            self.assertEqual(data_directory(), self.base)
            self.assertEqual(ProjectLibrary().state_path, self.base / "library.json")


if __name__ == "__main__":
    unittest.main()
