import os,sys,unittest
from pathlib import Path
from tkinter import ttk
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class InputLayout(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_table_list_buttons_share_one_row_and_fit_at_minimum(self):
        win=self.app.show_input_table();self.root.update()
        self.assertGreater(self.app.table_list_frame.winfo_width(),200)
        buttons=[w for w in gui.descendants(self.app.table_actions) if isinstance(w,ttk.Button)]
        self.assertEqual(len(buttons),6)
        for size in ['1360x820','780x460']:
            win.geometry(size);self.root.update()
            self.assertEqual(len({w.winfo_rooty() for w in buttons}),1)
            for w in buttons:
                self.assertTrue(w.winfo_ismapped())
                self.assertGreaterEqual(w.winfo_width(), 34)
                self.assertGreaterEqual(w.winfo_height(), 32)
                self.assertLessEqual(w.winfo_rootx()+w.winfo_width(),self.app.table_list_frame.winfo_rootx()+self.app.table_list_frame.winfo_width())
