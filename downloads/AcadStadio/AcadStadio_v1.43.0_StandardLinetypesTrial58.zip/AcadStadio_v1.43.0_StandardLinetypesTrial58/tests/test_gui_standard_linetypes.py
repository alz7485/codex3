import sys,os,unittest
from pathlib import Path
from tkinter import ttk
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from cad_setup import initial_macro

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class StandardLinetypesGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_bulk_add_survives_commit_and_reopen_without_losing_load_settings(self):
        editor=self.app.edit_cad_setup();self.root.update()
        def choose():
            win=gui.top(self.root,'AutoCAD標準線種から追加')
            tree=next(w for w in gui.descendants(win) if isinstance(w,ttk.Treeview));self.root.update()
            for name in ['HIDDEN','DASHED2']:
                tree.see(name);self.root.update();box=tree.bbox(name)
                tree.event_generate('<ButtonRelease-1>',x=15,y=box[1]+8);self.root.update()
            gui.button(win,'選択した線種を追加').invoke()
        self.root.after(80,choose);editor.add_standard_linetypes();self.root.update()
        editor.enabled.set(True);gui.button(editor.win,'設定を確定').invoke();self.root.update()
        rows=self.app.data['cad_setup']['linetypes']
        self.assertTrue(next(r for r in rows if r['name']=='HIDDEN')['standard'])
        reopened=self.app.edit_cad_setup();self.root.update();gui.button(reopened.win,'設定を確定').invoke();self.root.update()
        macro='\n'.join(initial_macro(self.app.data['cad_setup']))
        self.assertIn('acadiso.lin',macro);self.assertIn('"HIDDEN"',macro);self.assertIn('"DASHED2"',macro)

    def test_cancel_preserves_selected_resource_and_editor_grab(self):
        editor=self.app.edit_cad_setup();self.root.update()
        tree,_=editor.forms['linetypes'];tree.selection_set('0');editor.select('linetypes')
        before=list(editor.data['linetypes'])
        self.root.after(60,lambda:gui.button(gui.top(self.root,'AutoCAD標準線種から追加'),'キャンセル').invoke())
        editor.add_standard_linetypes();self.root.update()
        self.assertEqual(tree.selection(),('0',));self.assertIs(self.root.grab_current(),editor.win)
        self.assertEqual(editor.data['linetypes'],before)
        gui.button(editor.win,'設定を確定').invoke();self.root.update();self.assertFalse(editor.win.winfo_exists())
