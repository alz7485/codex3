import os,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import MacroEditor

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class BlockModalGrab(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def editor(self):
        ed=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update()
        return ed

    def click_apply(self,ed):
        self.assertIs(self.root.grab_current(),ed.win)
        button=gui.button(ed.win,'ブロックを反映')
        button.event_generate('<Enter>')
        button.event_generate('<ButtonPress-1>',x=8,y=8)
        button.event_generate('<ButtonRelease-1>',x=8,y=8)
        self.root.update()
        self.assertFalse(ed.win.winfo_exists())

    def test_cancel_palette_restores_whole_editor_and_footer_click_closes(self):
        ed=self.editor();ed.name.set('反映後')
        self.root.after(50,lambda:gui.button(gui.top(self.root,'追加するコマンド'),'キャンセル').invoke())
        ed.list.choose_add();self.root.update();self.click_apply(ed)
        self.assertEqual(self.app.data['blocks'][0]['name'],'反映後')

    def test_add_command_restores_whole_editor_and_footer_click_closes(self):
        ed=self.editor();count=len(ed.list.commands)
        def choose():
            palette=gui.top(self.root,'追加するコマンド')
            self.root.after(50,lambda:gui.button(gui.top(self.root,'コマンドの設定'),'コマンドを反映').invoke())
            gui.button(palette,'LINE').invoke()
        self.root.after(50,choose);ed.list.choose_add();self.root.update()
        self.assertEqual(len(ed.list.commands),count+1)
        self.click_apply(ed)
        self.assertEqual(len(self.app.data['blocks'][0]['commands']),count+1)
