import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from reference_tokens import command_references

class References(unittest.TestCase):
    def test_only_used_expressions_are_listed_without_quoted_literals(self):
        command=dict(type='LINE',x1='@X + 変数.幅',y1='[別表]@高さ{2}',x2='@X + settings.尺度',y2='変数.幅',text='注記 @文字の見本')
        self.assertEqual(command_references(command),['@X','変数.幅','[別表]@高さ{2}','settings.尺度'])
        self.assertEqual(command_references(dict(type='TEXT',text='="@例 変数.例"',x='10',y='20')),[])

    def test_variables_inside_table_row_expressions_are_available(self):
        self.assertEqual(command_references({'x':'[別表]@幅{変数.行}'}),['[別表]@幅{変数.行}','変数.行'])
