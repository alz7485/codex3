import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from cad_setup import default_setup,initial_macro,validate_setup
from standard_linetypes import STANDARD_NAMES

class StandardLinetypes(unittest.TestCase):
    def test_standard_library_is_loaded_only_when_missing_and_has_lt_fallback(self):
        setup=default_setup();setup['enabled']=True
        setup['linetypes']=[dict(name='HIDDEN',standard=True,file='acadiso.lin',existing_only=False)]
        self.assertEqual(validate_setup(setup),[])
        macro='\n'.join(initial_macro(setup))
        self.assertIn('tblsearch "LTYPE" "HIDDEN"',macro)
        self.assertIn('findfile "acadiso.lin"',macro);self.assertIn('findfile "acadltiso.lin"',macro)
        self.assertIn('"_.-LINETYPE" "_Load" "HIDDEN"',macro)
        setup['enabled']=False;self.assertEqual(initial_macro(setup),[])
    def test_all_simple_standard_names_and_only_standard_files(self):
        self.assertEqual(len(STANDARD_NAMES),45)
        setup=default_setup();setup['linetypes']=[dict(name='CUSTOM',standard=True,file='acad.lin')]
        self.assertTrue(validate_setup(setup))
        setup['linetypes'][0]['name']='hidden';self.assertEqual(validate_setup(setup),[])
        setup['linetypes'][0]['name']=[];self.assertTrue(validate_setup(setup))
