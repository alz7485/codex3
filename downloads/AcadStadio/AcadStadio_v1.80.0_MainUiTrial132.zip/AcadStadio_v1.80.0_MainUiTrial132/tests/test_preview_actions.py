"""Gesture results compile; formulas, identities and sequential selection survive."""
import copy,math,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from engine import compile_project,evaluate
from macro_editor import FIELDS
from sample_project import EXAMPLE
from command_points import reference
import preview_shape_actions as shape
import preview_edit_actions as edit
from preview_input_handles import move
from preview_input_modes import preserve_input_mode
from preview_input_feedback import status
from system_variables_ui import validate_items
SID='p_'+'a'*32
PID='p_'+'b'*32
def pick(px,py,**extra):return dict(xy=(px,py),x=str(px),y=str(py),source=None,key=None,snap_name=None)|extra
def command(kind,**extra):return dict(type=kind,**dict(FIELDS[kind]))|extra
def compile(cmds,rows=None):
 p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=cmds)];return compile_project(p,[0] if rows is None else rows)
def selector(x=10,y=0):return dict(type='SELECT',point_id=SID,selection_name='対象',selections=[dict(mode='point',x1=str(x),y1=str(y))])
def line(**extra):return dict(type='LINE',x1='0',y1='0',x2='20',y2='0')|extra

class PreviewActions(unittest.TestCase):
 def test_all_seventeen_drawing_commands_compile(self):
  cases={'LINE':[(0,0),(20,0),(20,10)],'POLYLINE':[(0,0),(20,0),(20,10)],'CIRCLE':[(0,0),(10,0)],'RECTANGLE':[(0,0),(20,10)],'ARC':[(0,0),(10,0),(0,20)],'ELLIPSE':[(0,0),(20,0),(5,10)],'POINT':[(2,3)],'HATCH':[(0,0),(20,0),(20,10)],'SPLINE':[(0,0),(10,10),(20,0)],'LEADER':[(0,0),(10,10),(20,10)],'TEXT':[(2,3)],'MTEXT':[(0,0),(20,10)],'DIMLINEAR':[(0,0),(20,0),(10,15)],'DIMALIGNED':[(0,0),(20,10),(10,15)],'DIMRADIUS':[(10,0),(20,15)],'DIMDIAMETER':[(10,0),(20,15)],'INSERT':[(2,3)]}
  self.assertEqual(set(cases),set(shape.KINDS))
  for kind,positions in cases.items():
   with self.subTest(kind=kind):
    ps=[pick(*p) for p in positions]
    if kind in ('DIMRADIUS','DIMDIAMETER'):ps[0]['source']=dict(type='CIRCLE',coords=(0,0,10))
    c=command(kind,**({'block_name':'PART'} if kind=='INSERT' else {}));saved=copy.deepcopy(c);built=shape.build(c,ps)
    self.assertEqual(c,saved);self.assertEqual(compile([built])[1][-1]['type'],kind)
 def test_circle_tracks_table_rows_and_keeps_inputs(self):
  plain=shape.build(command('CIRCLE',circle_mode='diameter'),[pick(1,2),pick(4,6)])
  self.assertEqual(plain['r'],'5');self.assertEqual(plain['diameter'],'10')
  ps=[pick(100,100,x='@X',y='@Y'),pick(150,100,x='@X+@OD/2',y='@Y')]
  for mode in ('radius','diameter'):
   c=shape.build(command('CIRCLE',circle_mode=mode),ps);items=compile([c],[0,1])[1]
   self.assertEqual(items[0]['coords'],(100,100,50));self.assertEqual(items[1]['coords'],compile([command('CIRCLE')],[0,1])[1][1]['coords'])
 def test_variable_paths_keep_vertex_ids_and_closed_boundaries(self):
  c=command('POLYLINE',vertices=[dict(id='v_a',x='0',y='0'),dict(id='v_b',x='2',y='0')]);old=copy.deepcopy(c)
  built=shape.build(c,[pick(0,0),pick(20,0),pick(20,10),pick(0,0)])
  self.assertEqual(c,old);self.assertEqual(built['vertices'][0]['id'],'v_a');self.assertEqual(len(built['vertices']),3);self.assertTrue(compile([built])[1][-1]['closed'])
  with self.assertRaises(ValueError):shape.build(command('HATCH'),[pick(0,0),pick(10,10),pick(0,10),pick(10,0)])
 def test_arc_modes_and_ellipse_constraints(self):
  for mode,points in [('center_angles',[(0,0),(10,0),(0,30)]),('three_points',[(10,0),(0,10),(-10,0)]),('start_center_end',[(10,0),(0,0),(0,30)])]:
   c=shape.build(command('ARC',arc_mode=mode),[pick(*p) for p in points]);self.assertAlmostEqual(compile([c])[1][-1]['coords'][2],10)
  c=shape.build(command('ELLIPSE'),[pick(0,0),pick(10,10),pick(10,0)]);item=compile([c])[1][-1];self.assertAlmostEqual(item['coords'][2],math.sqrt(200));self.assertAlmostEqual(item['coords'][3],math.sqrt(50));self.assertAlmostEqual(item['angle'],45)
  with self.assertRaises(ValueError):shape.build(command('ELLIPSE'),[pick(0,0),pick(10,0),pick(0,20)])
 def test_line_dimension_shortcut_and_circle_dimension_keep_refs(self):
  src=line(point_id=PID);item=compile([src])[1][0]
  d=shape.build(command('DIMALIGNED'),[pick(10,0,source=item,key=PID),pick(10,20)]);self.assertIn(PID,d['x1']);compile([src,d])
  src=dict(type='CIRCLE',point_id=PID,x='@X',y='@Y',r='@OD/2');item=compile([src])[1][0]
  d=shape.build(command('DIMDIAMETER'),[pick(150,100,source=item,key=PID),pick(200,180)]);self.assertIn(PID,d['r']);items=compile([src,d],[0,1])[1];self.assertEqual(items[1]['coords'][:3],(100,100,50));self.assertEqual(items[3]['coords'][:3],items[2]['coords'][:3])
 def test_mtext_width_projects_and_closed_boundary_shortcut_has_refs(self):
  for angle,width in [('0',20),('90',10)]:
   c=shape.build(command('MTEXT',angle=angle),[pick(0,0),pick(20,10)]);self.assertAlmostEqual(compile([c])[1][-1]['width'],width)
  source=dict(type='RECTANGLE',coords=(0,0,20,10));ps=shape.boundary_picks(pick(0,0,source=source,key=PID));self.assertEqual(len(ps),4);self.assertIn(PID,ps[0]['x'])
 def test_fourteen_edit_actions_registered_and_compile(self):
  self.assertEqual(len(edit.KINDS),14)
  cases={'COPY':[(0,0),(30,40)],'MIRROR':[(0,-10),(0,10)],'ROTATE':[(0,0),(0,10)],'ROTATECOPY':[(0,0),(0,10)],'SCALE':[(0,0),(10,0),(25,0)],'ARRAYRECT':[(0,0),(-10,0),(0,20)],'CADBLOCK':[(3,4)],'PEDIT':[]}
  for kind,pts in cases.items():
   with self.subTest(kind=kind):
    c=command(kind,selection_ref=SID);before=copy.deepcopy(c);built=edit.build(c,[pick(*p) for p in pts]);self.assertEqual(c,before);script,items=compile([line(),selector(),built]);self.assertTrue(items);self.assertIn('_.',script)
  source=dict(type='POLYLINE',points='0,0;20,0;20,20',closed='0');compile([source,selector(),edit.build(command('EXPLODE',selection_ref=SID),[])])
 def test_offset_distances_and_origin_are_valid(self):
  c=command('OFFSET',selection_ref=SID);c.pop('x1');c.pop('y1')
  d=edit.build(c,[pick(0,0,source=dict(type='LINE',coords=(0,10,20,10)))]);self.assertEqual(d['distance'],'10')
  items=compile([line(y1='10',y2='10'),selector(10,10),d])[1];g=items[-1].get('children',[items[-1]])[0];self.assertEqual(g['coords'],(0.,0.,20.,0.))
  d=edit.build(c,[pick(15,0,source=dict(type='CIRCLE',coords=(0,0,10)))]);self.assertEqual(d['distance'],'5')
 def test_trim_extend_keep_boundary_selection(self):
  for kind,extent,boundary,target,expect in [('TRIM',100,40,80,40),('EXTEND',50,100,40,100)]:
   d=edit.build(command(kind,selection_ref=SID),[pick(target,0)]);self.assertEqual(d['selection_ref'],SID)
   items=compile([line(x2=str(extent)),line(x1=str(boundary),y1='-20',x2=str(boundary),y2='20'),selector(boundary,10),d])[1];self.assertEqual(items[0]['coords'],(0.,0.,float(expect),0.))
 def test_chamfer_fillet_select_two_valid_lines(self):
  points=[pick(50,0,source=dict(type='LINE',coords=(0,0,100,0))),pick(0,50,source=dict(type='LINE',coords=(0,0,0,100)))]
  for kind in ('CHAMFER','FILLET'):
   d=edit.build(command(kind),points);items=compile([line(x2='100'),line(x2='0',y2='100'),d])[1];self.assertAlmostEqual(items[0]['coords'][0],10)
  with self.assertRaises(ValueError):edit.build(command('FILLET'),[pick(1,0),pick(0,1)])
 def test_scale_and_array_expressions_remain_dynamic(self):
  c=edit.build(command('SCALE'),[pick(0,0),pick(20,0,x='@WIDTH'),pick(40,0)]);self.assertAlmostEqual(evaluate(c['factor'],{'__row__':{'WIDTH':10}}),4)
  c=edit.build(command('ARRAYRECT'),[pick(0,0),pick(20,0,x='@WIDTH'),pick(0,30,y='@HEIGHT')]);self.assertEqual(evaluate(c['column_spacing'],{'__row__':{'WIDTH':50}}),50)
 def test_invalid_gestures_do_not_mutate(self):
  for kind,ps in [('COPY',[pick(1,1),pick(1,1)]),('SCALE',[pick(0,0),pick(0,0),pick(1,0)]),('ARRAYRECT',[pick(0,0),pick(0,1),pick(1,1)])]:
   c=command(kind);saved=copy.deepcopy(c)
   with self.assertRaises(ValueError):edit.build(c,ps)
   self.assertEqual(c,saved)
 def test_handles_preserve_formulas_and_identity(self):
  ctx={'__row__':{'X':10,'Y':20,'R':5}}
  c=dict(type='POLYLINE',vertices=[dict(id='v_a',x='@X',y='@Y'),dict(id='v_b',x='前点.X+10',y='前点.Y')]);before=copy.deepcopy(c)
  d=move(c,'頂点2',(20,20),(23,18),ctx,evaluate);self.assertEqual(c,before);self.assertEqual(d['vertices'][1]['id'],'v_b');self.assertIn('前点.X',d['vertices'][1]['x'])
  c=dict(type='CIRCLE',x='@X',y='@Y',r='@R');d=move(c,'右',(15,20),(18,20),ctx,evaluate);self.assertEqual(evaluate(d['r'],ctx),8);self.assertIn('@R',d['r'])
  d=move(dict(type='VIEWPORT',view_x='@X',view_y='@Y',view_scale='.5'),'表示内容',(0,0),(2,3),ctx,evaluate);self.assertEqual(evaluate(d['view_x'],ctx),6);self.assertEqual(evaluate(d['view_y'],ctx),14)
 def test_handles_preserve_text_and_reject_invalid_sizes(self):
  c=dict(type='MTEXT',x='@X',y='@Y',text='本文',width='80');ctx={'__row__':{'X':10,'Y':20}}
  d=move(c,'挿入点',(10,20),(13,18),ctx,evaluate);self.assertEqual(d['text'],'本文');self.assertEqual(evaluate(d['x'],ctx),13)
  with self.assertRaises(ValueError):move(dict(type='CIRCLE',x='0',y='0',r='5'),'右',(5,0),(0,0),{},evaluate)
 def test_mode_changes_preserve_geometry_and_metadata(self):
  c=dict(type='COPY',selection_ref='first',x2='123',y2='456',x3='789',y3='321',metadata={'keep':1});saved=copy.deepcopy(c);d=preserve_input_mode(c,'selection_ref','second');self.assertEqual(c,saved)
  for k in ('x2','y2','x3','y3'):self.assertEqual(c[k],d[k])
  c=dict(type='CIRCLE',x='@X',y='@Y',r='@R');d=preserve_input_mode(c,'circle_mode','diameter');self.assertEqual(d['x'],'@X');self.assertEqual(evaluate(d['diameter'],{'__row__':{'R':7}}),14)
 def test_arc_mode_preserves_symbolic_reference_or_refuses_without_mutation(self):
  c=dict(type='ARC',x='@X',y='@Y',r='@R',start_angle='0',end_angle='90');d=preserve_input_mode(c,'arc_mode','three_points');self.assertIn('@X',d['x1']);self.assertIn('@R',d['y2']);saved=copy.deepcopy(d)
  with self.assertRaises(ValueError):preserve_input_mode(d,'arc_mode','center_angles',context={'__row__':{'X':1,'Y':2,'R':5}},evaluate=evaluate)
  self.assertEqual(d,saved)
 def test_control_feedback_and_batch_validation(self):
  ctx={'__row__':{'TYPE':'A','N':3}}
  self.assertIn('成立',status(dict(type='IF',condition='@TYPE=="A"',commands=[]),ctx,evaluate));self.assertIn('3回',status(dict(type='REPEAT',count='@N',commands=[]),ctx,evaluate));self.assertIn('入力を確認',status(dict(type='REPEAT',count='1.5'),ctx,evaluate))
  items=[dict(name='USERR1',value_kind='number',value='@N*2'),dict(name='USERS1',value_kind='text',value='=@TYPE')];saved=copy.deepcopy(items)
  self.assertEqual(validate_items(items,ctx),['6','A']);self.assertEqual(items,saved)
  for bad in [[dict(name='A',value='2*')],[dict(name='A',value='1'),dict(name='a',value='2')]]:
   with self.assertRaises(ValueError):validate_items(bad)

 def test_viewport_frame_center_move_preserves_model_center_and_zero_size_is_rejected(self):
  c=dict(type='VIEWPORT',x1='0',y1='0',x2='100',y2='80',view_x='50',view_y='60',view_scale='1')
  d=move(c,'中心',(50,40),(55,47),{},evaluate)
  self.assertEqual(tuple(evaluate(d[k],{}) for k in ('x1','y1','x2','y2')),(5,7,105,87))
  self.assertEqual((d['view_x'],d['view_y']),('50','60'))
  with self.assertRaises(ValueError):move(c,'対角点2',(100,80),(0,80),{},evaluate)

 def test_windows_numlock_does_not_disable_snap(self):
  from preview_input_ui import alt_pressed
  from types import SimpleNamespace
  for state in (0,8,9,10,12):self.assertFalse(alt_pressed(SimpleNamespace(state=state),'win32'))
  for state in (0x20000,0x20008):self.assertTrue(alt_pressed(SimpleNamespace(state=state),'win32'))
  self.assertTrue(alt_pressed(SimpleNamespace(state=8),'x11'))
  self.assertFalse(alt_pressed(SimpleNamespace(state=16),'x11'))
