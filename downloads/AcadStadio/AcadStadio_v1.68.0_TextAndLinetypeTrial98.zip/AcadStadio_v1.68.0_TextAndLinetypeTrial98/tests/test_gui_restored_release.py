import os,unittest,copy
from types import SimpleNamespace
from unittest.mock import patch
from PIL import ImageTk
import test_gui as gui
from preview import DrawingCanvas
from project_data import current_table
from block_model import new_block
from link_assistance_ui import LinkAssistanceWindow

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class RestoredGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def pixels(self,c):
        n,_,_=c._text_nodes[0];return ImageTk.getimage(c._text_images[n]).getbbox(),c.coords(n)
    def test_pixel_size_zoom_baseline_and_pan_return(self):
        c=DrawingCanvas(self.root,width=800,height=600);c.pack();self.root.update()
        c.set_items([dict(type='LINE',coords=(-100,0,100,0)),dict(type='TEXT',coords=(0,0,10),text='H')]);self.root.update();c.fit()
        for factor in (1,2,.1,10):
            c.zoom(SimpleNamespace(x=c.winfo_width()/2,y=c.winfo_height()/2,delta=120),factor)
            b,pos=self.pixels(c);self.assertAlmostEqual(b[3]-b[1],10*c.scale_value,delta=3)
            line=next(n for n,i,_ in c.geometry if i['type']=='LINE');self.assertAlmostEqual(pos[1]+b[3],c.coords(line)[1],delta=3)
        c.drag_point=(0,0);c.drag(SimpleNamespace(x=2000,y=0));self.assertIsNone(self.pixels(c)[0]);c.drag(SimpleNamespace(x=0,y=0));self.assertIsNotNone(self.pixels(c)[0])
        old=c.tk.call('tk','scaling');b,_=self.pixels(c)
        try:c.tk.call('tk','scaling',2);c.fit(preserve=True,preserve_camera=True);self.assertEqual(self.pixels(c)[0],b)
        finally:c.tk.call('tk','scaling',old)
        c.destroy()
    def test_column_button_cancel_context_menu_and_atomic_undo_redo(self):
        current_table(self.app.data)['rows']=[];self.app.data['blocks']=[new_block('円',commands=[dict(type='CIRCLE',x='0',y='0',r='50')])];self.app.refresh();self.root.update();before=copy.deepcopy(self.app.data)
        w=LinkAssistanceWindow(self.app,('blocks',0,'commands',0));self.root.update();index=next(i for i,f in enumerate(w.target_fields) if f.path==('r',));w.field_picker.current(index);w.target_changed()
        with patch('link_assistance_ui.simpledialog.askstring',return_value=None):w.add_column_button.invoke()
        self.assertEqual(self.app.data,before)
        x,y,width,height=w.detail_tree.bbox(str(index));w.field_menu(SimpleNamespace(y=y+height//2,x_root=w.winfo_rootx()+10,y_root=w.winfo_rooty()+10));self.root.update();w.field_context_menu.unpost()
        with patch('link_assistance_ui.simpledialog.askstring',return_value='円半径'):w.field_context_menu.invoke(0)
        self.root.update();self.assertEqual(current_table(self.app.data)['rows'],[{'円半径':'50'}]);self.assertIn('@円半径',self.app.data['blocks'][0]['commands'][0]['r'])
        w.undo();self.root.update();self.assertEqual(self.app.data,before);w.close();self.app.redo_project();self.root.update();self.assertEqual(current_table(self.app.data)['rows'],[{'円半径':'50'}])
    def test_text_table_usage_highlight_and_mtext(self):
        current_table(self.app.data)['rows']=[{'文字高':'10'}];self.app.data['blocks']=[new_block('文字',commands=[dict(type='TEXT',x='0',y='0',height='@文字高',angle='0',text='Hg'),dict(type='MTEXT',x='50',y='0',height='10',angle='30',text='Hg\n漢字',width='50',attachment='3')])];self.app.refresh();self.root.update()
        w=LinkAssistanceWindow(self.app,('blocks',0,'commands',0));self.root.update();w.table_view.selection_set(str(w.table_columns.index('文字高')));w.column_selected();self.root.update();self.assertIsNotNone(self.pixels(w.canvas)[0]);w.close()
