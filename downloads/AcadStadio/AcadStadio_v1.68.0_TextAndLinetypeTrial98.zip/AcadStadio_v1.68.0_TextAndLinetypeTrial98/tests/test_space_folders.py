"""Drawing-space folders, transactional CRUD and identity-safe copies."""
import copy,json,unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from block_model import new_block,nested
from project_model import normalize_sequential_project,validate_sequential_project
from project_data import current_table
from engine import compile_project
from command_points import new_id,reference
from block_folders import create_folder,assign_blocks,delete_folder,move_folder,rename_folder,folder
from space_folders import ensure_space_folders,space_roots,root_for,folder_space,create_layout,rename_layout,delete_layout,copy_layout,copy_blocks


def project(blocks=None):
    return normalize_sequential_project(dict(version=11,rows=[{'名称':'基準'}],settings={},globals={},blocks=blocks or [new_block('モデル円',commands=[dict(type='CIRCLE',x='0',y='0',r='10')])]))

class SpaceFolders(unittest.TestCase):
    def test_model_exists_without_unfiled_and_cannot_be_modified(self):
        p=project();m=root_for(p);self.assertEqual(m['name'],'モデル');self.assertEqual(p['blocks'][0]['folder_id'],m['id'])
        before=copy.deepcopy(p)
        for action in (lambda:delete_folder(p,m['id']),lambda:rename_folder(p,m['id'],'改名'),lambda:move_folder(p,m['id'],'')):
            with self.assertRaises(ValueError):action()
            self.assertEqual(p,before)
        self.assertEqual(normalize_sequential_project(json.loads(json.dumps(p))),p)
    def test_legacy_folders_and_spaces_migrate_without_changing_commands_or_geometry(self):
        model=new_block('モデル',commands=[dict(type='LINE',x1='0',y1='0',x2='10',y2='0')]);paper=new_block('用紙',commands=[dict(type='LAYOUT',layout_name='A4'),dict(type='CIRCLE',x='20',y='0',r='5')])
        p=project([model,paper]);p['block_folders']=[dict(id='old',name='以前の分類',parent_id='')]
        for b in p['blocks']:b['folder_id']='old'
        before=copy.deepcopy(p);script,items=compile_project(p,[0]);ensure_space_folders(p)
        self.assertEqual([b['commands'] for b in p['blocks']],[b['commands'] for b in before['blocks']])
        self.assertEqual([b['id'] for b in p['blocks']],[b['id'] for b in before['blocks']])
        self.assertEqual(compile_project(p,[0]),(script,items))
        self.assertEqual([folder_space(p,b['folder_id']) for b in p['blocks']],['Model','A4'])
        self.assertEqual(len([f for f in p['block_folders'] if f['name']=='以前の分類']),2)
        stable=copy.deepcopy(p);ensure_space_folders(p);self.assertEqual(p,stable)
    def test_empty_layout_create_export_rename_delete_and_atomic_invalid_names(self):
        p=project();before=copy.deepcopy(p);q,identity=create_layout(p,'A4');self.assertEqual(p,before)
        self.assertIn('"_New" "A4"',compile_project(q,[0])[0])
        q=rename_layout(q,identity,'A3');self.assertEqual(folder(q,identity)['space'],'A3');self.assertNotIn('"_New" "A4"',compile_project(q,[0])[0])
        q=delete_layout(q,identity);self.assertEqual([f['space'] for f in space_roots(q)],['Model'])
        for name in ('Model','モデル','','a\nb','a/b'):
            with self.assertRaises(ValueError):create_layout(p,name)
        q,identity=create_layout(p,'A4')
        with self.assertRaises(ValueError):create_layout(q,'a4')
    def test_layout_rename_updates_only_used_space_fields_not_literal_text(self):
        p=project();p,identity=create_layout(p,'A4');fid=root_for(p,'A4')['id']
        block=new_block('用紙',commands=[dict(type='SPACE',space_mode='レイアウト空間',layout_name='A4'),dict(type='TEXT',x='0',y='0',height='3',text='A4'),dict(type='SYSVARS',items=[dict(name='CTAB',value='A4',value_kind='text')])]);block.update(folder_id=fid,drawing_space='A4');p['blocks'].append(block)
        q=rename_layout(p,identity,'A3');b=q['blocks'][-1]
        self.assertEqual(b['commands'][0]['layout_name'],'A3');self.assertEqual(b['commands'][1]['text'],'A4');self.assertEqual(b['commands'][2]['items'][0]['value'],'A3');self.assertEqual(b['drawing_space'],'A3')
        self.assertEqual({i['cad_space'] for i in compile_project(q,[0])[1]}, {'Model','A3'})
    def test_block_copies_remap_internal_and_cross_block_points_and_preserve_originals(self):
        pid=new_id();a=new_block('元線',commands=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0',point_id=pid)]);b=new_block('参照点',commands=[dict(type='POINT',x=reference(a['id']+'/'+pid,'終点','X'),y='0')]);p=project([a,b]);before=copy.deepcopy(p)
        q,ids=copy_blocks(p,[a['id'],b['id']]);self.assertEqual(p,before);self.assertEqual(len(set(x['id'] for x in q['blocks'])),4)
        ca,cb=q['blocks'][-2:];self.assertNotEqual(ca['commands'][0]['point_id'],pid)
        self.assertIn(ca['id']+'/'+ca['commands'][0]['point_id'],cb['commands'][0]['x'])
        ca['commands'][0]['x2']='200';items=compile_project(q,[0])[1]
        self.assertEqual(items[1]['coords'],(100,0));self.assertEqual(items[-1]['coords'],(200,0))
    def test_layout_copy_preserves_nested_folders_geometry_and_independent_point_links(self):
        p=project();p,identity=create_layout(p,'A4');child=create_folder(p,'寸法',identity);pid=new_id()
        a=new_block('用紙線',commands=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0',point_id=pid)]);a.update(folder_id=child['id'],drawing_space='A4')
        b=new_block('用紙点',commands=[dict(type='POINT',x=reference(a['id']+'/'+pid,'終点','X'),y='0')]);b.update(folder_id=child['id'],drawing_space='A4');p['blocks'] += [a,b]
        before=copy.deepcopy(p);q,copied,newids=copy_layout(p,identity,'A4 コピー');self.assertEqual(p,before)
        self.assertEqual(folder(q,copied)['space'],'A4 コピー');self.assertEqual(len(newids),2)
        copied_blocks=[b for b in q['blocks'] if b['id'] in newids];self.assertTrue(all(folder_space(q,b['folder_id'])=='A4 コピー' for b in copied_blocks));self.assertEqual(folder(q,copied_blocks[0]['folder_id'])['name'],'寸法')
        items=compile_project(q,[0])[1];self.assertEqual(len([i for i in items if i['cad_space']=='A4']),2);self.assertEqual(len([i for i in items if i['cad_space']=='A4 コピー']),2)
        copied_blocks[0]['commands'][0]['x2']='250';items=compile_project(q,[0])[1];self.assertEqual(items[-1]['coords'],(250,0));self.assertEqual(next(i for i in items if i['type']=='POINT' and i['cad_space']=='A4')['coords'],(100,0))
    def test_delete_layout_removes_its_blocks_but_rejects_external_point_references(self):
        p=project();p,identity=create_layout(p,'A4');pid=new_id();a=new_block('紙の線',commands=[dict(type='LINE',point_id=pid,x1='0',y1='0',x2='10',y2='0')]);a.update(folder_id=identity,drawing_space='A4');p['blocks'].append(a)
        q=delete_layout(p,identity);self.assertEqual(len(q['blocks']),1);self.assertNotIn(identity,[f['id'] for f in q['block_folders']])
        b=new_block('外部参照',commands=[dict(type='POINT',x=reference(a['id']+'/'+pid,'終点','X'),y='0')]);b.update(drawing_space='Model',folder_id=root_for(p)['id']);p['blocks'].append(b);before=copy.deepcopy(p)
        with self.assertRaises(ValueError):delete_layout(p,identity)
        self.assertEqual(p,before)
    def test_normal_folder_delete_rehomes_to_space_root_and_move_cycle_is_atomic(self):
        p=project();parent=create_folder(p,'分類');child=create_folder(p,'子',parent['id']);assign_blocks(p,[p['blocks'][0]['id']],child['id']);before=copy.deepcopy(p)
        with self.assertRaises(ValueError):move_folder(p,parent['id'],child['id'])
        self.assertEqual(p,before);delete_folder(p,parent['id']);self.assertEqual(p['blocks'][0]['folder_id'],root_for(p)['id'])
    def test_select_identity_is_remapped_in_copy(self):
        pid=new_id();p=project([new_block('選択',commands=[dict(type='SELECT',point_id=pid,selection_name='選択1',selections=[dict(mode='point',x1='10',y1='0')]),dict(type='COPY',selection_ref=pid,x1='10',y1='0',x2='0',y2='0',x3='20',y3='0',pick_tolerance='.01')])])
        q,_=copy_blocks(p,[p['blocks'][0]['id']]);c=q['blocks'][-1]['commands'];self.assertNotEqual(c[0]['point_id'],pid);self.assertEqual(c[1]['selection_ref'],c[0]['point_id'])
