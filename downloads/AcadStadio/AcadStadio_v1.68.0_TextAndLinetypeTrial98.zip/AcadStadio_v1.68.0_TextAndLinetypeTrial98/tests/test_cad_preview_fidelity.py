"""CAD alignment and dimension regressions using real ezdxf geometry."""
import copy
import math
import unittest
import ezdxf
from cad_drawing_import import extract_drawing, imported_project
from engine import compile_project, MacroError
from text_preview import layout, corners
from affine_geometry import transform, visual_entities


class CadPreviewFidelityTests(unittest.TestCase):
    def text_project(self,mode=5):
        doc=ezdxf.new()
        doc.modelspace().add_text('FIT TEXT',dxfattribs=dict(insert=(10,20),align_point=(70,100),height=4,halign=mode))
        return imported_project(extract_drawing(doc))

    def test_fit_keeps_endpoints_nominal_height_and_native_alignment(self):
        project=self.text_project();script,items=compile_project(project,[0]);item=items[0]
        self.assertEqual(item['coords'],(10,20,4));self.assertEqual(item['text_fit_length'],100)
        self.assertAlmostEqual(item['angle'],math.degrees(math.atan2(80,60)))
        data=layout(item);self.assertAlmostEqual(data.font.getlength(item['text'])*data.unit*data.width_factor,100)
        self.assertIn('(72 . 5)',script);self.assertIn('(cons 11 (list 70 100 0.0))',script)
        self.assertAlmostEqual(data.unit*(-data.font.getbbox('H',anchor='ls')[1]),4)

    def test_aligned_scales_height_and_width_together(self):
        _,items=compile_project(self.text_project(3),[0]);data=layout(items[0])
        self.assertEqual(data.width_factor,1)
        self.assertAlmostEqual(data.font.getlength(items[0]['text'])*data.unit,100)
        self.assertGreater(data.unit*(-data.font.getbbox('H',anchor='ls')[1]),4)

    def test_fit_evaluates_edited_endpoint_and_affine_scale(self):
        project=self.text_project();command=project['blocks'][2]['commands'][0]
        command['text_align_x']='10+120';command['text_align_y']='20'
        _,items=compile_project(project,[0]);item=items[0]
        self.assertEqual(item['text_fit_length'],120);self.assertEqual(item['angle'],0)
        moved=transform(item,lambda p:(p[0]*2,p[1]*2),scale=2)
        self.assertEqual(moved['text_fit_length'],240)
        data=layout(moved)
        self.assertAlmostEqual(data.font.getlength(moved['text'])*data.unit*data.width_factor,240)

    def test_coincident_fit_endpoints_rejected(self):
        project=self.text_project();command=project['blocks'][2]['commands'][0]
        command.update(text_align_x='10',text_align_y='20')
        with self.assertRaises(MacroError):compile_project(project,[0])

    def test_dimension_mtext_center_is_neither_north_nor_east(self):
        item=dict(type='MTEXT',coords=(100,50,3.5),text='20',width=20,text_anchor='center')
        data=layout(item);x,y=data.origins[0]
        advance=data.font.getlength('20')*data.unit
        self.assertAlmostEqual(x+advance/2,0)
        bbox=data.font.getbbox('20',anchor='ls')
        self.assertAlmostEqual(y-(bbox[1]+bbox[3])*data.unit/2,0,delta=item['coords'][2]*.05)

    def test_multiline_middle_uses_cap_height_and_line_spacing(self):
        item=dict(type='MTEXT',coords=(0,0,4),text='20\n40',width=20,text_anchor='center')
        data=layout(item)
        top=data.origins[0][1]+4;bottom=data.origins[-1][1]
        self.assertAlmostEqual((top+bottom)/2,0)

    def dimension_project(self):
        doc=ezdxf.new(setup=True)
        dim=doc.modelspace().add_linear_dim(base=(0,12),p1=(0,0),p2=(30,0),override=dict(dimclrd=4,dimclre=4,dimclrt=7,dimblk='OPEN',dimtxt=2.5,dimexo=1,dimexe=2,dimlfac=1,dimdec=0))
        dim.render()
        return imported_project(extract_drawing(doc))

    def test_dimension_preserves_cached_geometry_and_native_overrides(self):
        project=self.dimension_project();command=project['blocks'][1]['commands'][0]
        script,items=compile_project(project,[0]);item=items[0]
        self.assertEqual(item['block_geometry'],command['import_source']['dimension']['graphics'])
        rendered=list(visual_entities(items));self.assertGreater(len(rendered),3)
        self.assertTrue(any(p['type']=='LINE' and p['color']==4 for p in rendered))
        self.assertFalse(any(p['type']=='POINT' for p in rendered))
        self.assertIn('"_.DIMOVERRIDE"',script);self.assertIn('"DIMCLRD" 4',script)
        self.assertTrue(all(p['_logical_parent'] is item for p in rendered))

    def test_dimension_changes_regenerate_measurement_and_position(self):
        project=self.dimension_project();command=project['blocks'][1]['commands'][0]
        before=copy.deepcopy(command['import_source']['dimension']['graphics'])
        command.update(x2='45',y3='22')
        _,items=compile_project(project,[0]);item=items[0]
        self.assertNotEqual(item['block_geometry'],before)
        self.assertNotIn('preview_note',item)
        self.assertTrue(any(p.get('text')=='45' for p in item['block_geometry']))
        self.assertEqual(command['import_source']['dimension']['graphics'],before)

    def test_changing_dimension_style_never_uses_stale_graphics(self):
        project=self.dimension_project();command=project['blocks'][1]['commands'][0]
        command['dim_style']='Standard';script,items=compile_project(project,[0])
        self.assertNotIn('block_geometry',items[0]);self.assertIn('概略',items[0]['preview_note'])
        self.assertNotIn('"_.DIMOVERRIDE"',script)

    def test_editor_appearance_migration_keeps_dimension_graphics(self):
        from appearance_commands import extract_appearance
        project=self.dimension_project()
        project['blocks'][1]['commands']=extract_appearance(project['blocks'][1]['commands'])
        _,items=compile_project(project,[0])
        self.assertTrue(items[0].get('block_geometry'))

    def test_radius_and_diameter_edits_regenerate(self):
        for method in ('add_radius_dim','add_diameter_dim'):
            with self.subTest(method=method):
                doc=ezdxf.new(setup=True)
                dimension=getattr(doc.modelspace(),method)((0,0),radius=10,angle=20,location=(20,20),override=dict(dimlfac=1,dimdec=0))
                dimension.render()
                project=imported_project(extract_drawing(doc))
                command=project['blocks'][1]['commands'][0];command['r']='15'
                _,items=compile_project(project,[0]);item=items[0]
                self.assertNotIn('preview_note',item);self.assertTrue(item['block_geometry'])
                self.assertNotEqual(item['block_geometry'],command['import_source']['dimension']['graphics'])

    def test_manual_dimension_text_position_is_exported_only_for_original_coordinates(self):
        doc=ezdxf.new(setup=True)
        dimension=doc.modelspace().add_linear_dim(base=(0,12),p1=(0,0),p2=(30,0))
        dimension.set_location((18,16));dimension.render()
        project=imported_project(extract_drawing(doc));script,_=compile_project(project,[0])
        self.assertIn('vla-put-TextPosition',script)
        project['blocks'][1]['commands'][0]['x2']='40'
        script,items=compile_project(project,[0])
        self.assertNotIn('vla-put-TextPosition',script)
        self.assertTrue(items[0].get('block_geometry'))


if __name__=='__main__':unittest.main()
