"""Space-folder and tab workflows exercised with real Tk widgets."""
import os,sys,copy,json,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from unittest.mock import patch
from tkinter import ttk
import test_gui as gui
from block_model import new_block
from space_folders import create_layout,root_for,space_roots,folder_space
from project_model import normalize_sequential_project
from main import EMPTY
from macro_editor import MacroEditor

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class SpaceFolderGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def install(self):
        p=copy.deepcopy(self.app.data);p['blocks']=[new_block('モデル円',commands=[dict(type='CIRCLE',x='0',y='0',r='10')])]
        p['block_folders']=[];p=normalize_sequential_project(p);p,fid=create_layout(p,'A4')
        b=new_block('レイアウト円',commands=[dict(type='CIRCLE',x='100',y='0',r='20')]);b.update(drawing_space='A4',folder_id=fid);p['blocks'].append(b)
        self.app.replace_document(p);self.root.update();self.app.preview(quiet=True);self.root.update()
        return self.app.block_browser,self.app.canvas.space_tabs
    def test_model_exists_from_start_protected_and_no_unfiled(self):
        self.app.replace_document(EMPTY);self.root.update();self.app.preview(quiet=True);self.root.update()
        b=self.app.block_browser;root=root_for(self.app.data);node='folder:'+root['id'];self.assertTrue(b.tree.exists(node));b.select_folder(root['id'])
        before=copy.deepcopy(self.app.data)
        with patch('tkinter.messagebox.askyesno') as ask:self.assertFalse(b.delete_folder());ask.assert_not_called()
        self.assertFalse(b.rename_folder());self.assertEqual(self.app.data,before)
        self.assertTrue(all(b.tree.item(n,'values')[0]!='未分類' for n in b._folder_nodes()))
        self.app.open_navigator();self.root.update();nav=self.app.navigator
        self.assertFalse(any(nav.tree.item(n,'text')=='未分類' for n in nav.view_keys))
        self.app.close_navigator()
    def test_ctrl_a_selects_blocks_under_all_folders_and_respects_search(self):
        b,t=self.install();b.collapse_all();b.tree.focus_force();self.root.update();b.tree.event_generate('<Control-a>');self.root.update()
        self.assertEqual(b.selected_indices(),[0,1]);self.assertTrue(all(n.isdigit() for n in b.tree.selection()))
        b.search.set('モデル円');self.root.update();b.tree.event_generate('<Control-a>');self.root.update();self.assertEqual(b.selected_indices(),[0])
    def test_space_tabs_only_expand_corresponding_folder_and_preserve_script(self):
        b,t=self.install();before=self.app.compile()[0]
        m='folder:'+root_for(self.app.data)['id'];paper='folder:'+root_for(self.app.data,'A4')['id']
        self.assertTrue(b.tree.item(m,'open'));self.assertFalse(b.tree.item(paper,'open'));self.assertTrue(b.tree.exists('0'));self.assertTrue(b.tree.exists('1'))
        t.select_space('A4');self.root.update();self.assertFalse(b.tree.item(m,'open'));self.assertTrue(b.tree.item(paper,'open'))
        self.assertEqual({i['cad_space'] for i in self.app.canvas.items},{'A4'})
        t.select_space('Model');self.root.update();self.assertTrue(b.tree.item(m,'open'));self.assertFalse(b.tree.item(paper,'open'));self.assertEqual(self.app.compile()[0],before)
        self.assertLessEqual(t.notebook.winfo_height(),34)
        b.tree.item(paper,open=True);b.tree.item(m,open=False)
        t.notebook.event_generate('<ButtonRelease-1>',x=10,y=5);self.root.update()
        self.assertTrue(b.tree.item(m,'open'));self.assertFalse(b.tree.item(paper,'open'))
    def test_plus_creates_empty_layout_folder_and_tab_cancel_does_not_modify(self):
        self.app.replace_document(EMPTY);self.root.update();self.app.preview(quiet=True);self.root.update();t=self.app.canvas.space_tabs;before=copy.deepcopy(self.app.data)
        self.assertIsNotNone(t.add_page)
        with patch('tkinter.simpledialog.askstring',return_value=None):t.notebook.select(t.add_page);self.root.update()
        self.assertEqual(self.app.data,before);self.assertEqual(t.active,'Model')
        with patch('tkinter.simpledialog.askstring',return_value='図面 A3'):t.notebook.select(t.add_page);self.root.update()
        self.assertIn('図面 A3',t.pages);self.assertEqual(t.active,'図面 A3');self.assertEqual(root_for(self.app.data,'図面 A3')['name'],'図面 A3');self.assertEqual(self.app.data['blocks'],[])
        self.app.undo_project();self.root.update();self.assertNotIn('図面 A3',t.pages);self.app.redo_project();self.root.update();self.assertIn('図面 A3',t.pages)
    def test_layout_rename_follows_active_tab_and_folder_identity(self):
        b,t=self.install();t.select_space('A4');self.root.update();f=root_for(self.app.data,'A4');old_page=t.pages['A4'];b.select_folder(f['id']);self.root.update();self.assertTrue(b.rename_folder());b.rename_entry.delete(0,'end');b.rename_entry.insert(0,'A3');b.finish_folder_rename();self.root.update()
        self.assertNotIn('A4',t.pages);self.assertIn('A3',t.pages);self.assertIs(t.pages['A3'],old_page);self.assertEqual(t.active,'A3');self.assertEqual(self.app.data['blocks'][1]['drawing_space'],'A3');self.assertEqual(root_for(self.app.data,'A3')['id'],f['id'])
    def test_layout_delete_confirms_removes_blocks_tab_and_is_undoable(self):
        b,t=self.install();t.select_space('A4');self.root.update();fid=root_for(self.app.data,'A4')['id'];b.select_folder(fid);self.root.update();before=copy.deepcopy(self.app.data)
        with patch('tkinter.messagebox.askyesno',return_value=False) as ask:self.assertFalse(b.delete_folder());self.assertIn('1件',ask.call_args.args[1])
        self.assertEqual(self.app.data,before);self.assertIn('A4',t.pages)
        with patch('tkinter.messagebox.askyesno',return_value=True):self.assertTrue(b.delete_folder())
        self.root.update();self.assertNotIn('A4',t.pages);self.assertEqual(t.active,'Model');self.assertEqual(len(self.app.data['blocks']),1)
        self.app.undo_project();self.root.update();self.assertIn('A4',t.pages);self.assertEqual(self.app.data,before)
        self.app.redo_project();self.root.update();self.assertNotIn('A4',t.pages)
    def test_copy_layout_folder_and_block_unit_via_menu_and_ctrl_d(self):
        b,t=self.install();fid=root_for(self.app.data,'A4')['id'];b.select_folder(fid);self.root.update();b.prepare_menu()
        self.assertIn('レイアウトをコピー…',[b.menu.entrycget(i,'label') for i in range(b.menu.index('end')+1) if b.menu.type(i)=='command'])
        with patch('tkinter.simpledialog.askstring',return_value='A4 コピー'):self.assertTrue(b.copy_selection())
        self.root.update();self.assertIn('A4 コピー',t.pages);self.assertEqual(t.active,'A4 コピー');self.assertEqual(len(self.app.data['blocks']),3)
        copyblock=self.app.data['blocks'][-1];self.assertEqual(folder_space(self.app.data,copyblock['folder_id']),'A4 コピー');original_id=copyblock['id']
        b.tree.selection_set('2');b.tree.focus_force();self.root.update();b.tree.event_generate('<Control-d>');self.root.update();self.assertEqual(len(self.app.data['blocks']),4);self.assertNotEqual(self.app.data['blocks'][-1]['id'],original_id)
        self.app.undo_project();self.root.update();self.assertEqual(len(self.app.data['blocks']),3)
    def test_editor_has_no_split_join_buttons_and_new_block_uses_layout_folder(self):
        b,t=self.install();t.select_space('A4');self.root.update();self.app.add_block();self.root.update();w=gui.top(self.root,'ブロック編集')
        labels=[x.cget('text') for x in gui.descendants(w) if isinstance(x,ttk.Button)]
        self.assertNotIn('分割',labels);self.assertNotIn('結合',labels);gui.button(w,'ブロックを反映').invoke();self.root.update();new=self.app.data['blocks'][-1]
        self.assertEqual(new['drawing_space'],'A4');self.assertEqual(folder_space(self.app.data,new['folder_id']),'A4')
        rebuilt=normalize_sequential_project(json.loads(json.dumps(self.app.data)));self.assertEqual(rebuilt,self.app.data)
    def test_empty_created_layout_is_an_editor_destination_and_creation_clears_search(self):
        b,t=self.install();b.search.set('モデル円');self.root.update()
        with patch('tkinter.simpledialog.askstring',return_value='空の用紙'):identity=self.app.create_layout()
        self.root.update();self.assertEqual(b.search.get(),'');self.assertTrue(b.tree.exists('folder:'+identity));self.assertEqual(t.active,'空の用紙')
        self.app.edit_block_index(0);self.root.update();w=gui.top(self.root,'ブロック編集')
        picker=next(x for x in gui.descendants(w) if isinstance(x,ttk.Combobox) and 'コマンドに従う' in x.cget('values'))
        self.assertIn('空の用紙',picker.cget('values'));picker.set('空の用紙');gui.button(w,'ブロックを反映').invoke();self.root.update()
        self.assertEqual(self.app.data['blocks'][0]['drawing_space'],'空の用紙');self.assertEqual(folder_space(self.app.data,self.app.data['blocks'][0]['folder_id']),'空の用紙')
