import tkinter as tk
import unittest
from preview import DrawingCanvas
from cad_drawing_import import extract_drawing, imported_project
from engine import compile_project
import ezdxf


class CadPreviewCanvasTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.addCleanup(self.root.destroy)
        self.root.geometry('800x600');self.canvas=DrawingCanvas(self.root)
        self.canvas.pack(fill='both',expand=True);self.root.update()

    def project(self):
        doc=ezdxf.new(setup=True)
        doc.linetypes.new('TestChain',dxfattribs=dict(pattern=[8,4,-1,1,-2]))
        doc.layers.new('DashedLayer',dxfattribs=dict(linetype='TestChain'))
        doc.modelspace().add_line((0,0),(100,0),dxfattribs=dict(layer='DashedLayer'))
        doc.modelspace().add_text('FIT',dxfattribs=dict(insert=(0,20),align_point=(100,20),height=8,halign=5))
        dim=doc.modelspace().add_linear_dim(base=(0,-10),p1=(0,0),p2=(100,0),override=dict(dimclrd=4,dimblk='OPEN'))
        dim.render();doc.header['$LTSCALE']=2
        return imported_project(extract_drawing(doc))

    def test_dashed_bylayer_fit_and_dimension_primitives_draw(self):
        self.assertTrue(self.canvas.actual_color_mode.get())
        project=self.project();_,items=compile_project(project,[0])
        self.canvas.set_color_resources(project);self.canvas.items=items;self.canvas.fit();self.root.update()
        line=next(i for i in items if i['type']=='LINE')
        self.assertEqual(len(self.canvas.linetype_dash(line)),4)
        nodes=[node for node,item,color in self.canvas.geometry if item is line]
        self.assertTrue(nodes);self.assertIn('cad-dash',self.canvas.gettags(nodes[0]))
        self.assertGreater(len(self.canvas._text_nodes),1)
        self.assertTrue(any(item.get('_logical_parent',{}).get('type')=='DIMLINEAR' for _,item,_ in self.canvas.geometry))
        before=self.canvas.linetype_dash(line);self.canvas.scale_value*=2;self.canvas.update_dash_patterns()
        after=self.canvas.linetype_dash(line);self.assertGreater(sum(after),sum(before))


if __name__=='__main__':unittest.main()
