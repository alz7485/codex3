import unittest
from unittest.mock import patch
from text_preview import layout,resolve_font,font_files
from dash_preview import strokes

class Metrics98(unittest.TestCase):
 def test_cad_symbols_keep_raw_item_but_measure_display_text(self):
  item=dict(type='TEXT',coords=(0,0,3.5),text='%%c80 %%p0.1 45%%d')
  data=layout(item)
  self.assertEqual(data.lines,('Ø80 ±0.1 45°',))
  self.assertEqual(item['text'],'%%c80 %%p0.1 45%%d')
 def test_fit_uses_decoded_symbol_width(self):
  d=layout(dict(type='TEXT',coords=(0,0,4),text='%%c80',text_halign=5,text_fit_length=30))
  self.assertAlmostEqual(d.font.getlength('Ø80')*d.unit*d.width_factor,30)
 def test_strokes_above_tk_limit_are_not_truncated(self):
  s=list(strokes([(0,10),(1000,10)],[3,-.75],100,(1000,30)))
  self.assertAlmostEqual(s[0][2]-s[0][0],300)
  self.assertAlmostEqual(s[1][0]-s[0][2],75)
 def test_clipping_preserves_phase(self):
  s=list(strokes([(-10000,10),(1000,10)],[3,-.75],100,(1000,30)))
  self.assertAlmostEqual(s[0][2],50)
  self.assertAlmostEqual(s[1][0],125)
 def test_phase_continues_across_polyline_vertices(self):
  s=list(strokes([(0,0),(2,0),(2,4)],[3,-1],1,(100,100)))
  self.assertEqual(s[:2],[(0.,0.,2.,0.),(2.,0.,2.,1.)])
 def test_font_without_extension_resolves_installed_face(self):
  path=next(iter(font_files().values()))
  with patch('text_preview.font_files',return_value={'exact.ttf':path}):
   resolve_font.cache_clear()
   self.assertEqual(resolve_font('EXACT'),(path,False))
  resolve_font.cache_clear()
 def test_small_technical_text_keeps_ink_when_reduced(self):
  from text_preview import raster
  item=dict(type='TEXT',coords=(10,10,2.5),text='100 ±0.1',text_font='isocpeur.ttf')
  image,_=raster(item,'#ffffff',lambda x,y:(x*2,80-y*2),2,(300,100))
  self.assertGreater(sum(image.getchannel('A').getdata()),500)
