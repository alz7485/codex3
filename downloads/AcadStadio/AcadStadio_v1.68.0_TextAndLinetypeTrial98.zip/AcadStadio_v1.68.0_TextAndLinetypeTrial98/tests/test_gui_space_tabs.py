import copy,os,sys,unittest
import test_gui as gui
from block_model import new_block

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class SpaceTabsGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_tabs_switch_block_list_and_geometry_without_changing_output(self):
  p=copy.deepcopy(self.app.data)
  p['blocks']=[new_block('モデル図形',commands=[dict(type='CIRCLE',x='0',y='0',r='10')]),new_block('A4作成',commands=[dict(type='LAYOUT',layout_name='A4')]),new_block('A4図形',commands=[dict(type='CIRCLE',x='100',y='100',r='20')])]
  self.app.replace_document(p);self.root.update();self.app.preview(quiet=True);self.root.update()
  before=self.app.compile()[0];canvas=self.app.canvas;tabs=canvas.space_tabs
  self.assertEqual(tabs.active,'Model');self.assertEqual({i.get('cad_space') for i in canvas.items},{'Model'})
  self.assertTrue(self.app.block_list.exists('0'));self.assertTrue(self.app.block_list.exists('2'))
  self.assertFalse(self.app.block_list.item(self.app.block_list.parent('2'),'open'))
  tabs.notebook.select(tabs.pages['A4']);self.root.update()
  self.assertEqual(tabs.active,'A4');self.assertEqual({i['cad_space'] for i in canvas.items},{'A4'})
  self.assertTrue(self.app.block_list.exists('0'));self.assertTrue(self.app.block_list.exists('2'))
  self.assertFalse(self.app.block_list.item(self.app.block_list.parent('0'),'open'));self.assertTrue(self.app.block_list.item(self.app.block_list.parent('2'),'open'))
  self.assertEqual(self.app.compile()[0],before)
  self.assertEqual(self.errors,[])
 def test_model_camera_restored_after_layout_tab_switch(self):
  self.app.data['blocks'].append(new_block('紙',commands=[dict(type='CIRCLE',x='1000',y='1000',r='10')]))
  self.app.data['blocks'][-1]['drawing_space']='A4'
  self.app.refresh();self.app.preview(quiet=True);self.root.update()
  canvas=self.app.canvas;canvas.pan=[21.,32.];canvas.view_ratio=1.5;canvas.fit(preserve=True)
  before=(canvas.view_ratio,list(canvas.pan));tabs=canvas.space_tabs
  tabs.notebook.select(tabs.pages['A4']);self.root.update();tabs.notebook.select(tabs.pages['Model']);self.root.update()
  self.assertEqual((canvas.view_ratio,list(canvas.pan)),before)
 def test_new_block_uses_selected_layout(self):
  self.app.data['blocks'].append(new_block('A4',commands=[dict(type='LAYOUT',layout_name='A4')]))
  self.app.refresh();self.app.preview(quiet=True);self.root.update()
  tabs=self.app.canvas.space_tabs;tabs.notebook.select(tabs.pages['A4']);self.root.update()
  self.app.add_block();self.root.update();win=gui.top(self.root,'ブロック編集')
  gui.button(win,'ブロックを反映').invoke();self.root.update()
  self.assertEqual(self.app.data['blocks'][-1]['drawing_space'],'A4')
