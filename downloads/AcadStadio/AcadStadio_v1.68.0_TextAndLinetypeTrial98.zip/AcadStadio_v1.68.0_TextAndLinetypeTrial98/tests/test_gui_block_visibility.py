"""Preview visibility must never change drawing output, data, or edit targets."""
import copy
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui
from block_model import new_block

@unittest.skipUnless(sys.platform == 'win32' or os.environ.get('DISPLAY'), 'GUI display unavailable')
class BlockVisibilityGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def click_display(self, node):
        tree = self.app.block_list
        tree.see(node); self.root.update()
        x, y, w, h = tree.bbox(node, 'visible')
        self._click_time = getattr(self, '_click_time', 1000) + 1000
        tree.event_generate('<ButtonPress-1>', x=x+w//2, y=y+h//2, time=self._click_time)
        tree.event_generate('<ButtonRelease-1>', x=x+w//2, y=y+h//2, time=self._click_time+1)
        self.root.update()

    def test_real_checkbox_click_preserves_project_script_history_and_selection(self):
        self.app.block_list.selection_set('1'); self.root.update()
        before = copy.deepcopy(self.app.data)
        history = copy.deepcopy(self.app._history)
        script, all_items = self.app.compile()
        self.click_display('0')
        self.assertEqual(self.app.block_list.set('0', 'visible'), '☐')
        self.assertTrue(self.app.canvas.items)
        self.assertTrue(all(i['block_index'] != 0 for i in self.app.canvas.items))
        self.assertEqual(self.app.selected_block(), 1)
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app._history, history)
        self.assertFalse(self.app.has_unsaved_changes())
        self.assertEqual(self.app._script_text, script)
        self.assertEqual(self.app.compile(), (script, all_items))
        self.click_display('0')
        self.assertEqual(self.app.canvas.items, all_items)

    def test_display_double_click_never_opens_block_editor(self):
        tree = self.app.block_list
        x, y, w, h = tree.bbox('0', 'visible')
        with patch.object(self.app, 'edit_block') as edit:
            for _ in range(2):
                tree.event_generate('<ButtonPress-1>', x=x+w//2, y=y+h//2)
                tree.event_generate('<ButtonRelease-1>', x=x+w//2, y=y+h//2)
            self.root.update()
            edit.assert_not_called()

    def test_bulk_menu_covers_search_hidden_rows_and_empty_preview_still_exports_all(self):
        browser = self.app.block_browser
        script, items = self.app.compile()
        browser.search.set('平面'); self.root.update()
        browser.prepare_visibility_menu()
        browser.visibility_menu.invoke(1); self.root.update()
        self.assertEqual(len(browser.hidden_preview_ids), 3)
        self.assertEqual(self.app.canvas.items, [])
        self.assertIn('すべてOFF', self.app.canvas.empty_message)
        self.app.show_script(); self.root.update()
        self.assertEqual(self.app.script.get('1.0', 'end-1c'), script)
        self.assertEqual(self.app.compile()[1], items)
        export_path = Path(self.library_dir.name) / 'hidden-preview.scr'
        self.app.export(); self.root.update()
        export_window = gui.top(self.root, 'SCRを書き出す')
        with patch('tkinter.filedialog.asksaveasfilename', return_value=str(export_path)):
            gui.button(export_window, '保存先を選んで書き出す').invoke()
        self.assertEqual(export_path.read_text(encoding=self.app.encoding.get()), script)
        self.assertEqual(self.app.canvas.items, [])
        browser.prepare_visibility_menu(); browser.visibility_menu.invoke(0)
        self.assertEqual(self.app.canvas.items, items)

    def test_folder_checkbox_and_selected_bulk_include_nested_descendants(self):
        browser = self.app.block_browser
        self.app.data['block_folders'] = [*[f for f in self.app.data['block_folders'] if f.get("space")],
            {'id':'outer', 'name':'外側', 'parent_id':''},
            {'id':'inner', 'name':'内側', 'parent_id':'outer'},
        ]
        self.app.data['blocks'][0]['folder_id'] = 'outer'
        self.app.data['blocks'][1]['folder_id'] = 'inner'
        self.app.refresh(); self.app.preview(quiet=True); self.root.update()
        self.click_display('folder:outer')
        self.assertEqual(len(browser.hidden_preview_ids), 2)
        self.assertEqual(self.app.block_list.set('folder:outer', 'visible'), '☐')
        self.assertTrue(all(i['block_index'] == 2 for i in self.app.canvas.items))
        browser.set_preview_visibility({self.app.data['blocks'][0]['id']}, True)
        self.assertEqual(self.app.block_list.set('folder:outer', 'visible'), '▣')
        browser.select_folder('outer'); browser.prepare_visibility_menu()
        browser.visibility_menu.invoke(3)
        self.assertEqual(browser.hidden_preview_ids, set())
        browser.select_folder('outer'); browser.prepare_visibility_menu()
        browser.visibility_menu.invoke(4)
        self.assertEqual(len(browser.hidden_preview_ids), 2)

    def test_visibility_follows_identity_after_reorder_rename_and_resets_for_new_project(self):
        browser = self.app.block_browser
        identity = self.app.data['blocks'][0]['id']
        browser.set_preview_visibility({identity}, False)
        self.app.block_list.selection_set('0'); self.app.move_block(1)
        self.app.data['blocks'][1]['name'] = '名前を変更'
        self.app.refresh(); self.app.preview(quiet=True); self.root.update()
        self.assertEqual(self.app.block_list.set('1', 'visible'), '☐')
        self.assertTrue(all(i['block_index'] != 1 for i in self.app.canvas.items))
        saved_view = browser.get_view()
        browser.hidden_preview_ids.clear(); browser.restore_view(saved_view)
        self.assertEqual(browser.hidden_preview_ids, {identity})
        self.app.replace_document(self.app.data)
        self.assertEqual(browser.hidden_preview_ids, set())

    def test_each_ordered_block_hides_only_its_own_geometry_without_changing_scr(self):
        self.app.data['blocks'] = [new_block(str(i), commands=[{'type':'CIRCLE','x':str(i),'y':'0','r':'3'}]) for i in range(3)]
        self.app.refresh(); result = self.app.preview(quiet=True)
        self.assertEqual(len(result[1]), 3)
        for index,block in enumerate(self.app.data['blocks']):
            self.app.block_browser.set_preview_visibility({block['id']}, False)
            self.assertEqual({item['block_index'] for item in self.app.canvas.items}, set(range(3))-{index})
            self.assertEqual(self.app.compile()[0], result[0])
            self.app.block_browser.set_preview_visibility({block['id']}, True)
            self.assertEqual(self.app.canvas.items, result[1])


    def test_hidden_layers_do_not_reassign_colors_of_remaining_layers(self):
        def colors():
            return {item['layer']: color for _, item, color in self.app.canvas.geometry}
        before = colors()
        self.app.block_browser.set_preview_visibility({self.app.data['blocks'][0]['id']}, False)
        self.assertTrue(self.app.canvas.geometry)
        for layer, color in colors().items():
            self.assertEqual(color, before[layer])

    def test_space_toggles_multiselection_and_invalid_drawing_row_remains_error(self):
        tree = self.app.block_list
        tree.selection_set('0', '2'); tree.focus_force(); self.root.update()
        tree.event_generate('<space>'); self.root.update()
        self.assertEqual(len(self.app.block_browser.hidden_preview_ids), 2)
        tree.event_generate('<space>'); self.root.update()
        self.assertEqual(self.app.block_browser.hidden_preview_ids, set())
        self.app.row_range.set('999'); self.app.preview(quiet=True)
        error = self.app.status.get()
        self.app.block_browser.set_preview_visibility({self.app.data['blocks'][0]['id']}, False)
        self.assertEqual(self.app._script_text, '')
        self.assertEqual(self.app.canvas.items, [])
        self.assertEqual(self.app.status.get(), error)
