"""Checks for features restored before publishing the downloadable release."""
import copy,json,unittest
import test_link_assistance as fixtures
from flow import resolve
from project_data import current_table
from engine import compile_project
from range_selection import geometry_bounds
from affine_geometry import transform
import link_assistance as model
from text_preview import layout,raster

class RestoredRelease(unittest.TestCase):
    address=('blocks',0,'commands',0)
    def project(self):return fixtures.LinkAssistance().project([dict(type='CIRCLE',x='0',y='0',r='12.75')])
    def field(self,p):return next(f for f in model.fields(resolve(p,self.address)) if f.path==('r',))
    def test_empty_table_one_row_dynamic_reference_and_json(self):
        p=self.project();current_table(p)['rows']=[];before=copy.deepcopy(p)
        result=model.add_field_column(p,self.address,self.field(p),'円半径')
        self.assertEqual(p,before);self.assertEqual(current_table(result)['rows'],[{'円半径':'12.75'}])
        result=json.loads(json.dumps(result));current_table(result)['rows'][0]['円半径']='25'
        self.assertEqual(model.scenes(result,0)[0]['coords'][2],25)
        self.assertEqual(result['drawing']['targets'][current_table(result)['id']]['selected'],[0])
    def test_duplicate_name_and_invalid_geometry_are_atomic(self):
        p=self.project();before=copy.deepcopy(p)
        for name in ('外径','','1円半径','半 径'):
            with self.assertRaises(ValueError):model.add_field_column(p,self.address,self.field(p),name)
            self.assertEqual(p,before)
        resolve(p,self.address)['r']='-3';before=copy.deepcopy(p)
        with self.assertRaises((ValueError,model.MacroError)):model.add_field_column(p,self.address,self.field(p),'円半径')
        self.assertEqual(p,before)
    def test_existing_rows_keep_cells_and_can_change_independently(self):
        p=self.project();before=copy.deepcopy(current_table(p)['rows'])
        result=model.add_field_column(p,self.address,self.field(p),'円半径')
        for i,r in enumerate(current_table(result)['rows']):
            self.assertEqual({k:v for k,v in r.items() if k!='円半径'},before[i]);self.assertEqual(r['円半径'],'12.75')
        current_table(result)['rows'][1]['円半径']='30'
        self.assertEqual(model.scenes(result,0)[0]['coords'][2],12.75);self.assertEqual(model.scenes(result,1)[0]['coords'][2],30)
    def test_font_cap_height_baseline_width_and_rotation(self):
        item=dict(type='TEXT',coords=(0,0,10),text='Hg');data=layout(item)
        self.assertAlmostEqual(data.box[3],10);self.assertLess(data.box[1],0)
        b=geometry_bounds(item);w=geometry_bounds(dict(item,text_width=2))
        self.assertAlmostEqual(w[2]-w[0],2*(b[2]-b[0]))
        rot=geometry_bounds(dict(item,angle=90));self.assertAlmostEqual(rot[2]-rot[0],b[3]-b[1])
        for scale in (.4,10):
            im,pos=raster(dict(item,text='H'),'#ffffff',lambda x,y:(100+x*scale,300-y*scale),scale,(1000,600));box=im.getbbox()
            self.assertAlmostEqual(box[3]-box[1],10*scale,delta=3);self.assertAlmostEqual(pos[1]+box[3],300,delta=3)
    def test_mtext_alignment_wrapping_and_transform_metadata(self):
        item=dict(type='MTEXT',coords=(0,0,10),text='漢字漢字漢字',width=22,text_anchor='ne',text_font='',text_width=1,text_oblique=10)
        d=layout(item);self.assertGreater(len(d.lines),1)
        for line,origin in zip(d.lines,d.origins):self.assertAlmostEqual(origin[0],-d.font.getlength(line)*d.unit)
        self.assertAlmostEqual(d.origins[0][1]-d.origins[1][1],10*5/3)
        translated=transform(item,lambda p:(p[0]+20,p[1]+30));self.assertEqual(translated['text_anchor'],'ne');self.assertEqual(translated['text_oblique'],10)
        a=geometry_bounds(item);b=geometry_bounds(translated)
        for i in range(4):self.assertAlmostEqual(b[i]-a[i],20 if i%2==0 else 30)
    def test_dxf_import_line_spacing_and_column_without_spreadsheet(self):
        import ezdxf
        from cad_drawing_import import extract_drawing,imported_project
        doc=ezdxf.new();doc.modelspace().add_circle((15,20),12.75)
        doc.modelspace().add_mtext('H\\PH',dxfattribs=dict(char_height=10,width=100,line_spacing_factor=1.5,line_spacing_style=2,attachment_point=9))
        p=imported_project(extract_drawing(doc));at,c=next((a,c) for a,c in model.commands(p) if c['type']=='CIRCLE')
        f=next(f for f in model.fields(c) if f.path==('r',));result=model.add_field_column(p,at,f,'円半径')
        self.assertEqual(len(current_table(result)['rows']),1);self.assertEqual(current_table(result)['rows'][0]['円半径'],'12.75')
        script,items=compile_project(result,[0]);m=next(i for i in items if i['type']=='MTEXT')
        self.assertEqual(m['text_anchor'],'se');self.assertAlmostEqual(m['text_line_spacing'],2.5)
        self.assertIn('(vla-put-LineSpacingFactor result 1.5)',script)
