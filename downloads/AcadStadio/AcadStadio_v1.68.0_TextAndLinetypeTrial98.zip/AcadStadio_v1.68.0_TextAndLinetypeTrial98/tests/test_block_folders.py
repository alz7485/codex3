"""Folder persistence and organization must never change drawing semantics."""

import copy
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from block_folders import (
    assign_blocks,
    create_folder,
    delete_folder,
    descendant_ids,
    folder,
    folder_path,
    folders,
    move_folder,
    rename_folder,
)
from engine import compile_project
from project_model import normalize_project, validate_project


def circle(x):
    return {"type": "CIRCLE", "x": str(x), "y": "0", "r": "2"}


def project():
    return normalize_project({
        "version": 11,
        "rows": [{"X": "10"}],
        "settings": {},
        "globals": {},
        "custom_commands": {},
        "blocks": [
            {"id": "first", "name": "一つ目", "commands": [circle(1)]},
            {"id": "second", "name": "二つ目", "commands": [{"type": "BLOCK", "name": "helper"}, circle(2)]},
            {"id": "helper", "name": "共通処理", "draw": False, "commands": [circle(3)]},
        ],
    })


class FolderMetadata(unittest.TestCase):
    def test_old_version_11_loads_unfiled_without_mutation(self):
        old = project()
        old.pop("block_folders")
        before = copy.deepcopy(old)
        new = normalize_project(old)
        self.assertEqual(old, before)
        self.assertEqual(new["block_folders"], [])
        self.assertTrue(all(not b.get("folder_id") for b in new["blocks"]))
        self.assertEqual(compile_project(old, [0]), compile_project(new, [0]))

    def test_legacy_version_5_migrates_with_empty_folder_metadata(self):
        old = {
            "version": 5, "rows": [{"X": "1"}], "settings": {}, "globals": {},
            "blocks": {}, "presets": [{"name": "以前の作図", "commands": [circle(1)]}],
        }
        before = copy.deepcopy(old)
        new = normalize_project(old)
        self.assertEqual(old, before)
        self.assertEqual(new["block_folders"], [])
        self.assertEqual(new["version"], 11)
        self.assertEqual(compile_project(old, [0])[0], compile_project(new, [0])[0])

    def test_nested_folders_and_membership_roundtrip(self):
        data = project()
        parent = create_folder(data, "外形")
        child = create_folder(data, "加工", parent["id"])
        assign_blocks(data, ["first", "helper"], child["id"])
        rebuilt = normalize_project(json.loads(json.dumps(data, ensure_ascii=False)))
        self.assertEqual(rebuilt, data)
        self.assertEqual(folder_path(rebuilt, child["id"]), "外形 / 加工")
        self.assertEqual(folder_path(rebuilt, ""), "モデル")
        self.assertEqual(validate_project(rebuilt), [])

    def test_folder_fields_are_optional_in_existing_json(self):
        data = project()
        data["block_folders"] = [{"id": "root", "name": "外形"}]
        data["blocks"][0]["folder_id"] = "root"
        self.assertEqual(validate_project(data), [])
        self.assertEqual(folder_path(data, "root"), "外形")

    def test_invalid_folder_shapes_and_ids_are_rejected(self):
        for bad in (None, {}, "folders", [None], [{"name": "外形"}], [{"id": [], "name": "外形"}], [{"id": "bad-id", "name": "外形"}]):
            with self.subTest(value=bad):
                data = project()
                data["block_folders"] = bad
                before = copy.deepcopy(data)
                self.assertTrue(validate_project(data))
                with self.assertRaises(ValueError):
                    normalize_project(data)
                self.assertEqual(data, before)

    def test_empty_names_controls_and_non_string_parents_are_rejected(self):
        for name, parent in (("", ""), (" \t ", ""), ("a\nb", ""), ("a\x7fb", ""), ([], ""), ("外形", None), ("外形", [])):
            with self.subTest(name=name, parent=parent):
                data = project()
                data["block_folders"] = [{"id": "root", "name": name, "parent_id": parent}]
                self.assertTrue(validate_project(data))

    def test_duplicate_ids_and_casefolded_sibling_names_are_rejected(self):
        for second in ({"id": "root", "name": "別名"}, {"id": "other", "name": " ROOT "}):
            with self.subTest(second=second):
                data = project()
                data["block_folders"] = [{"id": "root", "name": "Root"}, second]
                self.assertTrue(validate_project(data))

    def test_missing_parent_and_cycles_are_rejected(self):
        cases = [
            [{"id": "root", "name": "外形", "parent_id": "missing"}],
            [{"id": "root", "name": "外形", "parent_id": "root"}],
            [{"id": "a", "name": "外形", "parent_id": "b"}, {"id": "b", "name": "加工", "parent_id": "a"}],
        ]
        for items in cases:
            with self.subTest(items=items):
                data = project()
                data["block_folders"] = items
                self.assertTrue(validate_project(data))
                with self.assertRaises(ValueError):
                    normalize_project(data)

    def test_missing_folder_or_wrong_membership_type_is_rejected(self):
        for identity in ("missing", None, [], 1, True):
            with self.subTest(identity=identity):
                data = project()
                data["blocks"][0]["folder_id"] = identity
                self.assertTrue(validate_project(data))

    def test_deep_folder_graph_does_not_use_recursive_validation(self):
        data = project()
        data["block_folders"] = [
            {"id": f"f{i}", "name": str(i), "parent_id": f"f{i + 1}" if i < 1499 else ""}
            for i in range(1500)
        ]
        data["blocks"][0]["folder_id"] = "f0"
        self.assertEqual(validate_project(data), [])
        self.assertEqual(len(descendant_ids(data, "f1499")), 1500)
        data["block_folders"][-1]["parent_id"] = "f0"
        self.assertTrue(validate_project(data))


class FolderOperations(unittest.TestCase):
    def setUp(self):
        self.data = project()
        self.original_drawing = compile_project(self.data, [0])
        self.block_objects = list(self.data["blocks"])

    def assert_unchanged_execution(self):
        self.assertEqual([b["id"] for b in self.data["blocks"]], ["first", "second", "helper"])
        self.assertTrue(all(a is b for a, b in zip(self.block_objects, self.data["blocks"])))
        self.assertEqual(compile_project(self.data, [0]), self.original_drawing)

    def assert_atomic_error(self, operation, *args):
        before = copy.deepcopy(self.data)
        with self.assertRaises(ValueError):
            operation(self.data, *args)
        self.assertEqual(self.data, before)

    def test_create_trims_names_and_uses_stable_unique_ids(self):
        a = create_folder(self.data, " 外形 ")
        b = create_folder(self.data, "加工")
        self.assertEqual(a["name"], "外形")
        self.assertNotEqual(a["id"], b["id"])
        self.assertIs(folder(self.data, a["id"]), a)
        self.assert_unchanged_execution()

    def test_same_name_is_allowed_under_different_parents(self):
        a = create_folder(self.data, "A")
        b = create_folder(self.data, "B")
        first = create_folder(self.data, "共通", a["id"])
        second = create_folder(self.data, "共通", b["id"])
        self.assertNotEqual(first["id"], second["id"])
        self.assertEqual(folder_path(self.data, first["id"]), "A / 共通")
        self.assertEqual(folder_path(self.data, second["id"]), "B / 共通")

    def test_create_rejects_blank_duplicate_or_missing_parent_atomically(self):
        create_folder(self.data, "Outline")
        self.assert_atomic_error(create_folder, "")
        self.assert_atomic_error(create_folder, " OUTLINE ")
        self.assert_atomic_error(create_folder, "外形", "missing")

    def test_rename_keeps_membership_children_and_block_references(self):
        a = create_folder(self.data, "外形")
        child = create_folder(self.data, "加工", a["id"])
        assign_blocks(self.data, ["first", "helper"], child["id"])
        rename_folder(self.data, a["id"], " 基本形 ")
        self.assertEqual(a["name"], "基本形")
        self.assertEqual(folder_path(self.data, child["id"]), "基本形 / 加工")
        self.assertEqual(self.data["blocks"][0]["folder_id"], child["id"])
        self.assert_unchanged_execution()

    def test_rename_duplicate_is_atomic(self):
        a = create_folder(self.data, "A")
        create_folder(self.data, "B")
        self.assert_atomic_error(rename_folder, a["id"], "b")
        self.assert_atomic_error(rename_folder, a["id"], "")
        self.assert_atomic_error(rename_folder, "missing", "C")

    def test_move_folder_preserves_descendant_membership_and_output(self):
        a = create_folder(self.data, "外形")
        b = create_folder(self.data, "加工")
        child = create_folder(self.data, "共通", a["id"])
        assign_blocks(self.data, ["first"], child["id"])
        move_folder(self.data, a["id"], b["id"])
        self.assertEqual(folder_path(self.data, child["id"]), "加工 / 外形 / 共通")
        self.assertEqual(self.data["blocks"][0]["folder_id"], child["id"])
        move_folder(self.data, a["id"], "")
        self.assertEqual(folder_path(self.data, child["id"]), "外形 / 共通")
        self.assert_unchanged_execution()

    def test_move_into_self_descendant_or_duplicate_is_atomic(self):
        a = create_folder(self.data, "外形")
        b = create_folder(self.data, "加工", a["id"])
        other = create_folder(self.data, "加工")
        self.assert_atomic_error(move_folder, a["id"], a["id"])
        self.assert_atomic_error(move_folder, a["id"], b["id"])
        self.assert_atomic_error(move_folder, a["id"], "missing")
        self.assert_atomic_error(move_folder, b["id"], "")
        self.assertIn(other, folders(self.data))

    def test_assign_multiple_blocks_and_return_to_unfiled(self):
        a = create_folder(self.data, "外形")
        assign_blocks(self.data, ["first", "helper"], a["id"])
        self.assertEqual([b.get("folder_id", "") for b in self.data["blocks"]], [a["id"], "", a["id"]])
        assign_blocks(self.data, ["first", "helper"], "")
        self.assertTrue(all(not b.get("folder_id", "") for b in self.data["blocks"]))
        self.assert_unchanged_execution()

    def test_assign_missing_block_or_folder_has_no_partial_effect(self):
        a = create_folder(self.data, "外形")
        self.assert_atomic_error(assign_blocks, ["first", "missing"], a["id"])
        self.assert_atomic_error(assign_blocks, ["first"], "missing")
        self.assert_atomic_error(assign_blocks, ["first"], None)
        self.assert_atomic_error(assign_blocks, "first", a["id"])
        self.assert_atomic_error(assign_blocks, None, a["id"])
        self.assert_atomic_error(assign_blocks, [{}], a["id"])
        self.assert_atomic_error(assign_blocks, [1], a["id"])

    def test_delete_subtree_unfiles_blocks_and_keeps_other_folder(self):
        a = create_folder(self.data, "外形")
        child = create_folder(self.data, "加工", a["id"])
        other = create_folder(self.data, "寸法")
        assign_blocks(self.data, ["first"], a["id"])
        assign_blocks(self.data, ["helper"], child["id"])
        assign_blocks(self.data, ["second"], other["id"])
        self.assertEqual(descendant_ids(self.data, a["id"], include_self=False), {child["id"]})
        self.assertEqual(delete_folder(self.data, a["id"]), {a["id"], child["id"]})
        self.assertEqual(folders(self.data), [other])
        self.assertEqual([b.get("folder_id", "") for b in self.data["blocks"]], ["", other["id"], ""])
        self.assert_unchanged_execution()

    def test_delete_missing_folder_or_unfiled_is_atomic(self):
        self.assert_atomic_error(delete_folder, "missing")
        self.assert_atomic_error(delete_folder, "")


if __name__ == "__main__":
    unittest.main()
