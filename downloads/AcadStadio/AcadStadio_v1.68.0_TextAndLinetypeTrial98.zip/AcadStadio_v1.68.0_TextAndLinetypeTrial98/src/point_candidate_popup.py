"""Compact candidate list; selection previews, explicit acceptance commits."""
import tkinter as tk
from tkinter import ttk

class PointCandidatePopup(tk.Toplevel):
    def __init__(self,canvas,candidates,event,on_use):
        owner=canvas.winfo_toplevel();super().__init__(owner)
        self.withdraw();self.transient(owner);self.overrideredirect(True)
        self.configure(borderwidth=1,relief='solid');self.canvas=canvas;self.candidates=candidates
        self.old_source=canvas.source_index;self.old_related=set(getattr(canvas,'related_source_indices',set()))
        self.old_points=dict(canvas.snap_points);self.old_point=canvas.selected_point;self.old_shift=canvas.shifted_point
        self.previous_grab=self.grab_current();self.grab_set()
        self.list=ttk.Treeview(self,columns=('name',),show='',height=min(12,len(candidates)),selectmode='browse')
        from tkinter import font
        label_font=font.nametofont('TkDefaultFont')
        width=max(label_font.measure(item['label']) for item in candidates)+28
        self.list.column('name',width=min(width,self.winfo_screenwidth()-24),stretch=True)
        self.list.pack(fill='both',expand=True)
        for i,item in enumerate(candidates):self.list.insert('','end',iid=str(i),values=(item['label'],))
        def use(event=None):
            if not self.list.selection():return
            candidate=candidates[int(self.list.selection()[0])];self.close();on_use(candidate)
            return 'break'
        self.use=use
        def selected(event=None):
            if not self.list.selection():return
            candidate=candidates[int(self.list.selection()[0])]
            canvas.source_index=candidate['primary'];canvas.related_source_indices={candidate['secondary']} if candidate['kind']=='intersection' else set()
            from command_points import geometry_points
            primary=next((i for i in canvas.items if canvas.item_source_index(i)==candidate['primary']),None)
            canvas.snap_points={'交点':candidate['position']} if candidate['kind']=='intersection' else geometry_points(primary) if primary else {}
            canvas.selected_point='交点' if candidate['kind']=='intersection' else candidate['point'];canvas.shifted_point=None
            canvas.recolor()
        def hover(event):
            row=self.list.identify_row(event.y)
            if row:self.list.selection_set(row);self.list.focus(row);selected()
        def click(event):
            row=self.list.identify_row(event.y)
            if row:self.list.selection_set(row);use()
            return 'break'
        def outside(event):
            if not (self.winfo_rootx()<=event.x_root<self.winfo_rootx()+self.winfo_width() and self.winfo_rooty()<=event.y_root<self.winfo_rooty()+self.winfo_height()):
                self.close();return 'break'
        self.list.bind('<<TreeviewSelect>>',selected)
        self.list.bind('<Motion>',hover);self.list.bind('<ButtonRelease-1>',click)
        self.bind('<ButtonPress-1>',outside);self.bind('<ButtonPress-3>',lambda e:self.close())
        self.bind('<Return>',use);self.bind('<Escape>',lambda e:self.close())
        self.update_idletasks();w=self.winfo_reqwidth();h=self.winfo_reqheight()
        x=max(0,min(event.x_root,self.winfo_screenwidth()-w));y=max(0,min(event.y_root,self.winfo_screenheight()-h))
        self.geometry(f'{w}x{h}+{x}+{y}');self.deiconify()
        self.list.selection_set('0');self.list.focus('0');selected();self.list.focus_set()
    def close(self):
        if not self.winfo_exists():return
        canvas=self.canvas
        try:
            canvas.source_index=self.old_source;canvas.related_source_indices=self.old_related
            canvas.snap_points=self.old_points;canvas.selected_point=self.old_point;canvas.shifted_point=self.old_shift;canvas.recolor()
            self.grab_release();self.destroy()
            if self.previous_grab is not None and self.previous_grab.winfo_exists():self.previous_grab.grab_set()
        except tk.TclError:pass
