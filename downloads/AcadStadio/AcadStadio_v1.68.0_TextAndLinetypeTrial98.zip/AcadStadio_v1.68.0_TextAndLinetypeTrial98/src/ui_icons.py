"""Bundled toolbar icons and tooltips for mouse and keyboard navigation."""

import tkinter as tk
from tkinter import ttk
from theme import ROOT


# Text stays on the widget for accessibility and automated UI navigation.
ICONS = {
    "設定を追加 ▾": ("gear", True, "作図属性・レイヤー変更・システム変数・再作図"),
    "空間・レイアウトを追加 ▾": ("blocks", True, "モデル／レイアウトの切り替え・レイアウト・ビューポート"),
    "ガイド化": ("guide", True, "選択した作図コマンドをガイドへコピー（SCRには出力しません）"),
    "線・形状を追加 ▾": ("blocks", True, "線・形状を追加: 線分 / ポリライン / 円 / 円弧 / 楕円 / 長方形 / 点 / スプライン / ハッチング"),
    "編集・複写を追加 ▾": ("edit", True, "編集・複写: 選択 / オフセット / トリム / 延長 / コピー / ミラー / 回転 / 配列 / CADブロック / 分解 / 尺度"),
    "文字・寸法を追加 ▾": ("script", True, "文字・寸法を追加: 単一行文字 / マルチテキスト / 引出線 / 長さ寸法 / 平行寸法 / 半径寸法 / 直径寸法"),
    "制御を追加 ▾": ("tree", True, "設定・制御を追加: 作図属性 / 条件分岐 / 繰り返し / システム変数 / 登録コマンド"),
    "＋ コマンドを追加 ▾": ("add", True, "作図コマンドを追加（線・円・文字・条件分岐など）"),
    "選択行…": ("table", False, "作図する行をチェックリストで選ぶ"),
    "SCRを表示": ("script", False, "生成SCRを別ウィンドウで表示"),
    "開く": ("folder", True, "プロジェクトを開く  Ctrl+O"),
    "保存": ("save", True, "保存  Ctrl+S"),
    "プロジェクトを保存": ("save", False, "プロジェクトをJSONファイルに保存  Ctrl+S"),
    "プロジェクトを検査": ("check", True, "全入力表と作図フローを検査"),
    "SCRを書き出す": ("export", False, "SCRを書き出す  Ctrl+E"),
    "プロジェクト一覧…": ("projects", False, "プロジェクト一覧を別ウィンドウで開く"),
    "CAD初期設定…": ("gear", False, "レイヤー・線種・文字/寸法スタイルの設定"),
    "入力表を編集…": ("table", False, "入力表を別ウィンドウで開く"),
    "表一覧…": ("table", False, "入力表の一覧と編集を別ウィンドウで開く"),
    "表示 ▾": ("eye", True, "プレビューの表示・非表示をまとめて変更"),
    "CAD設定": ("gear", False, "CADのレイヤー・線種・文字/寸法スタイルを設定"),
    "プリセット": ("save", False, "設定プリセットとサイズ設定"),
    "作図設定": ("check", False, "SCRへ出力する行を指定"),
    "表を追加": ("add", True, "入力表を追加"),
    "表を読込": ("folder", True, "Excel / CSVを新しい表として読み込む"),
    "表を置換": ("refresh", True, "現在の表をファイルで置き換える"),
    "式・変数 ▾": ("variables", True, "式・変数を入力"),
    "実色表示": ("colors", True, "実色表示 ON / OFF：登録レイヤーとコマンドのACI色（未定義の色は色分け表示）"),
    "CAD設定…": ("gear", False, "レイヤー・線種・文字/寸法スタイルの設定"),
    "作図対象を表示": ("refresh", True, "作図設定の対象行をプレビューに表示"),
    "ブロック追加": ("add", False, "選択フォルダにブロックを追加"),
    "フォルダ追加": ("folder_add", True, "最上位へフォルダを即時追加。名前は一覧上のダブルクリックで変更"),
    "登録コマンド": ("commands", True, "ユーザーコマンドを登録・編集"),
    "編集": ("edit", True, "選択項目を編集"),
    "名前を変更": ("edit", True, "選択した入力表の名前を変更  F2"),
    "↑": ("up", True, "上へ移動  Alt+↑"),
    "↓": ("down", True, "下へ移動  Alt+↓"),
    "削除": ("trash", True, "選択項目を削除"),
    "複製": ("duplicate", True, "選択項目を複製"),
    "設定・変数": ("variables", True, "設定・変数"),
    "変数": ("variables", True, "作図に使う変数を編集"),
    "構成ツリー": ("tree", True, "プロジェクト構成を別ウィンドウで開く"),
    "再生成  F5": ("refresh", True, "プレビューとSCRを再生成  F5"),
    "全体を表示": ("fit", True, "図形全体を表示（プレビューのダブルクリックでも可）"),
    "選択を強調": ("eye", True, "選択行・ブロックの強調 ON / OFF"),
    "SCRをコピー": ("copy", False, "生成SCRをクリップボードへコピー"),
    "行を追加": ("add", True, "入力表に行を追加"),
    "元に戻す": ("undo", True, "元に戻す  Ctrl+Z"),
    "やり直し": ("redo", True, "やり直す  Ctrl+Y"),
}


SECONDARY_ICONS = {
    "点を追加": ("add", True, "点を追加：現在の終点を中間点にし、新しい終点を追加"),
    "点を削除": ("trash", True, "この点を削除（最低2点を保持）"),
    "表・変数 ▾": ("variables", True, "参照を入力：表の列・セル / 変数 / コマンドの始点・中点・終点"),
    "入力した値を追加 / 更新": ("check", False, "入力した設定値を追加・更新"),
    "新しい項目": ("add", True, "新しい設定項目を入力"),
    "参照…": ("folder", False, "DWGファイルを選択"),
    "読み取る": ("refresh", False, "DWGファイルから設定を読み取る"),
    "新規登録": ("add", True, "新しいコマンドを登録"),
    "現在値から新規作成": ("add", True, "現在の設定からプリセットを作成"),
    "名前変更": ("edit", True, "プリセットの名前を変更"),
    "値を編集": ("variables", True, "共通設定の値を編集"),
    "JSON読込": ("folder", True, "JSONを読み込む"),
    "JSON書出": ("export", True, "JSONを書き出す"),
    "＋ 新規": ("add", True, "プロジェクトを新規作成"),
    "JSONを開く": ("folder", True, "プロジェクトJSONを開く"),
    "別名で保存": ("save", True, "別名で保存"),
    "フォルダー変更": ("folder", False, "プロジェクト保存フォルダーを変更"),
    "更新": ("refresh", True, "一覧を更新"),
    "コマンド追加": ("add", True, "選択位置にコマンドを追加"),
    "コピー": ("copy", True, "選択した項目をコピー"),
    "切り取り": ("copy", True, "選択したコマンドを切り取り"),
    "貼り付け": ("table", True, "コマンドを貼り付け"),
    "入力値を追加 / 更新": ("check", False, "入力した設定を一覧へ追加・更新"),
    "新規入力": ("add", True, "選択を解除して新規入力"),
    "選択を削除": ("trash", True, "選択した設定を削除"),
    "追加 / 更新": ("check", False, "入力した引数を追加・更新"),
    "新しい引数": ("add", True, "新しい引数を入力"),
    "再検査": ("refresh", True, "プロジェクトを再検査"),
    "マクロを確認": ("script", False, "CAD初期設定のマクロを確認"),
}


class IconTheme:
    def __init__(self, root):
        self.root = root
        root._acadstadio_icons = self
        self.images = {}
        self.tooltip = None
        self.job = None
        root.bind_all("<Map>", self.mapped, add="+")
        root.bind("<Destroy>", self.destroyed, add="+")

    def get(self, name, white=False):
        key = name + ("_white" if white else "")
        if key not in self.images:
            if name == "guide":
                icon = tk.PhotoImage(master=self.root,width=20,height=20)
                ink = "white" if white else "#52657d"
                for x in (1,6,11,16):icon.put(ink,to=(x,9,min(x+3,20),11))
                icon.put(ink,to=(9,2,11,7));icon.put(ink,to=(9,13,11,18))
                self.images[key]=icon;return icon
            if name == "colors":
                icon = tk.PhotoImage(master=self.root, width=20, height=20)
                for color, x, y in (("#ff5252", 2, 2), ("#30dc80", 11, 2), ("#ffd54f", 2, 11), ("#5aa6ff", 11, 11)):
                    icon.put(color, to=(x, y, x+7, y+7))
                self.images[key] = icon
                return icon
            if name == "folder_add":
                icon = self.get("folder", white).copy()
                edge = icon.width()
                ink, paper = ("white", "#2463eb") if white else ("#2463eb", "white")
                icon.put(paper, to=(edge-10, edge-10, edge, edge))
                icon.put(ink, to=(edge-6, edge-9, edge-4, edge-1))
                icon.put(ink, to=(edge-9, edge-6, edge-1, edge-4))
                self.images[key] = icon
                return icon
            self.images[key] = tk.PhotoImage(
                master=self.root, file=str(ROOT / "assets" / "toolbar" / (key + ".png"))
            )
        return self.images[key]

    def mapped(self, event):
        widget = event.widget
        if not isinstance(widget, (ttk.Button, ttk.Checkbutton, ttk.Menubutton)) or getattr(
            widget, "_icon_ready", False
        ):
            return
        secondary = widget.winfo_toplevel() is not self.root
        if secondary and isinstance(widget, (ttk.Button, ttk.Menubutton)):
            current_style = str(widget.cget("style"))
            if current_style in ("", "TButton", "Primary.TButton"):
                widget.configure(style="Compact.Primary.TButton" if current_style == "Primary.TButton" else "Compact.TMenubutton" if isinstance(widget, ttk.Menubutton) else "Compact.TButton")
        label = str(widget.cget("text"))
        spec = SECONDARY_ICONS.get(label) if secondary else None
        spec = spec or ICONS.get(label)
        if spec is None:
            for prefix, name in (
                ("＋ Excel", "folder"),
                ("設定プリセット", "save"),
                ("サイズ・共通設定", "gear"),
                ("作図設定…", "gear"),
                ("選択した参照", "add"),
            ):
                if label.startswith(prefix):
                    spec = name, False, label
                    break
        if spec is None:
            return
        name, icon_only, tip = spec
        icon_only = getattr(widget, "icon_only", icon_only)
        try:
            widget.configure(
                image=self.get(name, getattr(widget, "icon_white", "Primary" in widget.cget("style"))),
                compound="none" if icon_only else "left",
            )
        except tk.TclError:
            return
        if icon_only:
            if isinstance(widget, ttk.Checkbutton):
                widget.configure(style=getattr(widget, "icon_button_style", "Toggle.Toolbutton"))
            else:
                widget.configure(width=getattr(widget, "icon_button_width", 3),
                                 style=getattr(widget, "icon_button_style", "Compact.TButton"))
        widget._icon_ready = True
        widget.tooltip_text = tip
        widget.bind("<Enter>", lambda e: self.schedule(widget, tip), add="+")
        widget.bind("<FocusIn>", lambda e: self.schedule(widget, tip), add="+")
        for sequence in ("<Leave>", "<FocusOut>", "<ButtonPress>", "<Escape>"):
            widget.bind(sequence, lambda e: self.hide(), add="+")

    def schedule(self, widget, text):
        self.hide()
        self.job = self.root.after(450, lambda: self.show(widget, text))

    def show(self, widget, text):
        if self.job:
            self.root.after_cancel(self.job)
        self.job = None
        if not widget.winfo_exists() or not widget.winfo_ismapped():
            return
        win = self.tooltip = tk.Toplevel(self.root)
        win.overrideredirect(True)
        ttk.Label(
            win,
            text=text,
            padding=(9, 5),
            background="#233950",
            foreground="white",
            wraplength=350,
        ).pack()
        win.update_idletasks()
        x = min(
            widget.winfo_rootx(),
            self.root.winfo_screenwidth() - win.winfo_reqwidth() - 8,
        )
        y = widget.winfo_rooty() + widget.winfo_height() + 5
        if y + win.winfo_reqheight() > self.root.winfo_screenheight():
            y = widget.winfo_rooty() - win.winfo_reqheight() - 5
        win.geometry(f"+{max(0, x)}+{max(0, y)}")

    def hide(self):
        if self.job:
            self.root.after_cancel(self.job)
            self.job = None
        if self.tooltip is not None:
            try:
                self.tooltip.destroy()
            except tk.TclError:
                pass
            self.tooltip = None

    def destroyed(self, event):
        if event.widget is self.root:
            self.hide()


def icons_for(widget):
    root = widget._root()
    return getattr(root, "_acadstadio_icons", None) or IconTheme(root)


def layout_icon_toolbar(frame, width, *, grid=False):
    controls = [w for w in frame.winfo_children() if isinstance(w, (ttk.Button, ttk.Menubutton))]
    required = sum(118 if getattr(w,"toolbar_labelled",False) else 44 if isinstance(w, ttk.Menubutton) else 38 for w in controls) + 2*len(controls)
    compact = width < max(330, required)
    dense_required = sum(106 if getattr(w,"toolbar_labelled",False) else 39 if isinstance(w, ttk.Menubutton) else 22 for w in controls) + len(controls)
    gap = 0 if compact and width < dense_required else 1 if compact else 2
    for button in controls:
        if getattr(button,"toolbar_labelled",False):
            if hasattr(button,"toolbar_compact_label"):
                button.configure(text=button.toolbar_compact_label if compact else button.toolbar_full_label)
            button.configure(style="Compact.TButton",width=0)
            if grid:button.grid_configure(padx=(0,gap),pady=0)
            else:button.pack_configure(fill="y",padx=(0,gap))
            continue
        # A dense row keeps the same outlined buttons with an 18px icon.
        # Cache both sizes so resizing never compounds the scaling.
        current_image = button.tk.splitlist(button.cget('image'))
        if current_image:
            if not hasattr(button, '_toolbar_full_image'):
                button._toolbar_full_image = current_image[0]
            if compact:
                if not hasattr(button, '_toolbar_small_image'):
                    expanded = tk.PhotoImage(master=button)
                    expanded.tk.call(str(expanded), 'copy', button._toolbar_full_image, '-zoom', 9, 9)
                    button._toolbar_small_image = expanded.subsample(10, 10)
                button.configure(image=button._toolbar_small_image)
            else:
                button.configure(image=button._toolbar_full_image)
        suffix = "TMenubutton" if isinstance(button, ttk.Menubutton) else "TButton"
        style = ("DenseMainIcon." if compact else "MainIcon.") + suffix
        button.icon_button_style = style
        button.configure(style=style, width=2)
        if grid:
            button.grid_configure(padx=(0, gap), pady=0)
        else:
            button.pack_configure(fill="y", padx=(0, gap))


def standard_toolbar(frame, *, grid=False):
    """Use main button sizes, reducing them only when the actions cannot fit."""
    def arrange(width):
        controls = [w for w in frame.winfo_children() if isinstance(w, (ttk.Button, ttk.Menubutton))]
        required = sum(44 if isinstance(w, ttk.Menubutton) else 38 for w in controls) + 2*len(controls)
        layout_icon_toolbar(frame, max(330, width) if width >= required else width, grid=grid)
    frame.bind("<Configure>", lambda e: arrange(e.width), add="+")
    frame.after_idle(lambda: arrange(frame.winfo_width()) if frame.winfo_exists() else None)
