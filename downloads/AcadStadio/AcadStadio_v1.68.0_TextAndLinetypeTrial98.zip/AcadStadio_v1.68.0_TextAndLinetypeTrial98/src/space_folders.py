"""Persistent drawing-space folders and transactional layout/block operations."""
import copy
import uuid
from block_model import nested, new_block
from block_folders import folders, folder, descendant_ids, validate_folders
from cad_setup import cad_name
from command_points import new_id, rewrite_references

MODEL = 'Model'


def space_roots(project):
    return [f for f in folders(project) if f.get('space')]


def folder_space(project, identity):
    by_id={f['id']:f for f in folders(project)};seen=set()
    while identity and identity not in seen and identity in by_id:
        seen.add(identity);f=by_id[identity]
        if f.get('space'):return f['space']
        identity=f.get('parent_id','')
    return None


def _literal(value):
    return isinstance(value,str) and bool(value.strip()) and not value.startswith('=') and cad_name(value)


def root_for(project, space=MODEL):
    return next(f for f in space_roots(project) if f['space'].casefold()==space.casefold())


def _add_root(project, space):
    existing=next((f for f in folders(project) if not f.get('parent_id') and not f.get('space') and f['name']==('モデル' if space==MODEL else space)),None)
    if existing is None:
        existing=dict(id='space_'+uuid.uuid4().hex,name='モデル' if space==MODEL else space,parent_id='')
        project.setdefault('block_folders',[]).append(existing)
    existing.update(space=space,parent_id='')
    return existing


def ensure_space_folders(project):
    """Migrate classification without changing commands, identities or draw order."""
    if not isinstance(project.get('blocks'),list):return
    errors=validate_folders(project)
    if errors:raise ValueError('\n'.join(errors[:6]))
    from preview_spaces import block_spaces
    destinations=block_spaces(project)
    names=[MODEL]
    for f in space_roots(project):
        if f['space'] not in names:names.append(f['space'])
    for b,spaces in zip(project['blocks'],destinations):
        for name in [b.get('drawing_space',''),*sorted(spaces)]:
            if _literal(name) and name.casefold()!='model' and not any(n.casefold()==name.casefold() for n in names):names.append(name)
    roots={f['space'].casefold():f for f in space_roots(project)}
    for name in names:
        if name.casefold() not in roots:roots[name.casefold()]=_add_root(project,name)
    model=roots['model'];model.update(name='モデル',space=MODEL,parent_id='')
    # Preserve old category paths below the model root. Categories shared by
    # multiple drawing spaces are mirrored below each destination as needed.
    for f in folders(project):
        if not f.get('space') and not f.get('parent_id'):f['parent_id']=model['id']
    def category_path(identity):
        by_id={f['id']:f for f in folders(project)};path=[];seen=set()
        while identity in by_id and identity not in seen:
            seen.add(identity);f=by_id[identity]
            if f.get('space'):break
            path.append(f['name']);identity=f.get('parent_id','')
        return list(reversed(path))
    def under(root,path):
        parent=root['id']
        for name in path:
            child=next((f for f in folders(project) if f.get('parent_id','')==parent and f['name'].casefold()==name.casefold()),None)
            if child is None:
                child=dict(id='folder_'+uuid.uuid4().hex,name=name,parent_id=parent);project['block_folders'].append(child)
            parent=child['id']
        return parent
    for b,spaces in zip(project['blocks'],destinations):
        if b.get('guide'):b.pop('folder_id',None);continue
        declared=b.get('drawing_space')
        destination=declared or (next(iter(spaces)) if len(spaces)==1 else MODEL if MODEL in spaces else sorted(spaces)[0])
        target=roots.get(str(destination).casefold(),model)
        old=b.get('folder_id','')
        if folder_space(project,old)!=target['space']:b['folder_id']=under(target,category_path(old))
    project['block_folders']=[model,*[f for f in folders(project) if f is not model and f.get('space')],*[f for f in folders(project) if not f.get('space')]]


def _checked(trial):
    from project_model import validate_sequential_project
    errors=validate_sequential_project(trial)
    if errors:raise ValueError('\n'.join(errors[:6]))
    return trial


def _layout_name(project,name,exclude=None):
    name=name.strip() if isinstance(name,str) else ''
    if not cad_name(name) or name.casefold() in ('model','モデル'):raise ValueError('レイアウト名を入力してください。Model／モデルは使用できません。')
    if any(f['id']!=exclude and f['space'].casefold()==name.casefold() for f in space_roots(project)):raise ValueError('同じ名前のレイアウトがあります。')
    return name


def create_layout(project,name):
    trial=copy.deepcopy(project);ensure_space_folders(trial);name=_layout_name(trial,name)
    f=_add_root(trial,name)
    return _checked(trial),f['id']


def unique_layout_name(project,base='Layout'):
    names={f['space'].casefold() for f in space_roots(project)};name=base;i=1
    while name.casefold() in names:name=f'{base} ({i})';i+=1
    return name


def _rewrite_space(block,old,new):
    if block.get('drawing_space')==old:block['drawing_space']=new
    for c in nested(block.get('commands',[])):
        kind=c.get('type')
        keys=[]
        if kind=='SPACE' and c.get('space_mode','モデル空間')!='モデル空間':keys=['layout_name']
        if kind=='LAYOUT':keys=['layout_name']+(['source_layout'] if c.get('layout_action') in ('複製','名前を変更') else [])
        for key in keys:
            value=c.get(key,'Layout1')
            if isinstance(value,str) and value.casefold()==old.casefold():c[key]=new
        if c.get('type')=='SYSVAR' and c.get('name','').upper()=='CTAB' and str(c.get('value','')).strip('"').casefold()==old.casefold():c['value']=new
        if c.get('type')=='SYSVARS':
            for value in c.get('items',[]):
                if value.get('name','').upper()=='CTAB' and str(value.get('value','')).strip('"').casefold()==old.casefold():value['value']=new


def rename_layout(project,identity,name):
    trial=copy.deepcopy(project);ensure_space_folders(trial);f=folder(trial,identity);old=f.get('space')
    if not old or old==MODEL:raise ValueError('モデルフォルダの名前は変更できません。')
    name=_layout_name(trial,name,identity);f.update(name=name,space=name)
    for b in trial['blocks']:_rewrite_space(b,old,name)
    return _checked(trial)


def delete_layout(project,identity):
    trial=copy.deepcopy(project);ensure_space_folders(trial);f=folder(trial,identity);name=f.get('space')
    if not name or name==MODEL:raise ValueError('モデルフォルダは削除できません。')
    members=descendant_ids(trial,identity);removed=[b for b in trial['blocks'] if b.get('folder_id') in members]
    removed_ids={b['id'] for b in removed}
    from guide_blocks import point_references
    removed_selections={c['point_id'] for b in removed for c in nested(b['commands']) if c.get('type')=='SELECT' and c.get('point_id')}
    for b in trial['blocks']:
        if b['id'] in removed_ids:continue
        probe=copy.deepcopy(b);_rewrite_space(probe,name,'__removed_layout__')
        if probe!=b:raise ValueError(f'「{b["name"]}」からこのレイアウトへの指定があります。先に作図先を変更してください。')
        # Do not leave cross-block point links pointing into deleted content.
        if any(ref.split('/',1)[0] in removed_ids for ref in point_references(b) if '/' in ref) or any(c.get('selection_ref') in removed_selections for c in nested(b['commands'])):
            raise ValueError(f'「{b["name"]}」が削除対象のブロックを参照しています。参照を変更してから削除してください。')
    if any(ref.split('/',1)[0] in removed_ids for ref in point_references(project.get('globals',{})) if '/' in ref):
        raise ValueError('プロジェクト変数が削除対象を参照しています。先に参照を変更してください。')
    trial['blocks']=[b for b in trial['blocks'] if b['id'] not in removed_ids]
    trial['block_folders']=[f for f in folders(trial) if f['id'] not in members]
    return _checked(trial)


def copy_blocks(project,identities,folder_id=None,*,space_rewrite=None):
    """New block/point/selection IDs; internal cross-block links target the copy."""
    trial=copy.deepcopy(project);ensure_space_folders(trial);wanted=set(identities)
    if not wanted<={b['id'] for b in trial['blocks']}:raise ValueError('コピーするブロックが見つかりません。')
    selected=[b for b in trial['blocks'] if b['id'] in wanted and not b.get('guide')]
    if not selected:raise ValueError('コピーする作図ブロックを選択してください。')
    copies=copy.deepcopy(selected);block_map={b['id']:new_block()['id'] for b in selected};point_maps={};absolute={};selection={}
    for b in selected:
        mapping={}
        for c in nested(b['commands']):
            if c.get('point_id'):
                mapping[c['point_id']]=new_id();absolute[b['id']+'/'+c['point_id']]=block_map[b['id']]+'/'+mapping[c['point_id']]
                if c.get('type')=='SELECT':selection[c['point_id']]=mapping[c['point_id']]
        point_maps[b['id']]=mapping
    from block_operations import suggested_name
    inserted=[];last=max(i for i,b in enumerate(trial['blocks']) if b['id'] in wanted)
    for offset,(old,new) in enumerate(zip(selected,copies),1):
        mapping={**absolute,**point_maps[old['id']]}
        new=rewrite_references(new,mapping);new.update(id=block_map[old['id']],name=suggested_name(trial,old['name']+' コピー'))
        for before,after in zip(nested(old['commands']),nested(new['commands'])):
            if before.get('point_id'):after['point_id']=point_maps[old['id']][before['point_id']]
            if before.get('selection_ref') in selection:after['selection_ref']=selection[before['selection_ref']]
        if folder_id is not None:
            new['folder_id']=folder_id;new['drawing_space']=folder_space(trial,folder_id) or MODEL
        if space_rewrite:_rewrite_space(new,*space_rewrite)
        trial['blocks'].insert(last+offset,new);inserted.append(new['id'])
    return _checked(trial),inserted


def copy_layout(project,identity,name):
    trial=copy.deepcopy(project);ensure_space_folders(trial);source=folder(trial,identity)
    if not source.get('space') or source['space']==MODEL:raise ValueError('コピーするレイアウトフォルダを選択してください。')
    name=_layout_name(trial,name);ids=descendant_ids(trial,identity);old_space=source['space'];mapping={}
    originals=[copy.deepcopy(f) for f in folders(trial) if f['id'] in ids]
    for f in originals:mapping[f['id']]='folder_'+uuid.uuid4().hex
    for f in originals:
        new=dict(f,id=mapping[f['id']],parent_id=mapping.get(f.get('parent_id',''),'') )
        if f['id']==identity:new.update(name=name,space=name)
        trial['block_folders'].append(new)
    blocks=[b for b in trial['blocks'] if b.get('folder_id') in ids];new_ids=[]
    if blocks:
        trial,new_ids=copy_blocks(trial,[b['id'] for b in blocks],space_rewrite=(old_space,name))
        by_id={b['id']:b for b in trial['blocks']}
        for old,new in zip(blocks,new_ids):by_id[new].update(folder_id=mapping[old['folder_id']],drawing_space=name)
        for block_identity in new_ids:
            for c in nested(by_id[block_identity]['commands']):
                if c.get('type')=='LAYOUT' and c.get('layout_name')==name and c.get('layout_action') in ('複製','名前を変更'):
                    c['layout_action']='作成して選択';c.pop('source_layout',None)
    return _checked(trial),mapping[identity],new_ids
