"""Simple CAD linetypes as viewport-clipped vector strokes, without Tk's 255px limit."""
import math


def paths(item):
    c=item['coords'];kind=item.get('display_type',item['type'])
    if item.get('segments'):return [[p[:2],p[2:4]] for p in item['segments']]
    if kind in ('LINE','POLYLINE'):
        p=list(zip(c[::2],c[1::2]))
        if item.get('closed') and p:p.append(p[0])
        return [p]
    if kind=='RECTANGLE':
        x,y,u,v=c;return [[(x,y),(u,y),(u,v),(x,v),(x,y)]]
    if kind in ('CIRCLE','ARC','ELLIPSE'):
        start=item.get('start_angle',0) if kind=='ARC' else 0
        sweep=item.get('sweep',360) if kind=='ARC' else 360
        count=max(24,math.ceil(abs(sweep)*2));a=math.radians(item.get('angle',0));ca,sa=math.cos(a),math.sin(a)
        rx=c[2];ry=c[3] if kind=='ELLIPSE' else rx
        points=[]
        for i in range(count+1):
            t=math.radians(start+sweep*i/count);x,y=rx*math.cos(t),ry*math.sin(t)
            points.append((c[0]+x*ca-y*sa,c[1]+x*sa+y*ca))
        return [points]
    return []


def clip(a,b,width,height):
    dx,dy=b[0]-a[0],b[1]-a[1];low,high=0.,1.
    for p,q in ((-dx,a[0]+2),(dx,width+2-a[0]),(-dy,a[1]+2),(dy,height+2-a[1])):
        if p==0:
            if q<0:return None
        elif p<0:low=max(low,q/p)
        else:high=min(high,q/p)
        if low>high:return None
    return low,high


def strokes(points,pattern,ratio,viewport):
    runs=[(n>=0,abs(n)*ratio if n else .7) for n in pattern]
    period=sum(n for _,n in runs)
    if period<=0:return
    phase=0.;count=0
    for a,b in zip(points,points[1:]):
        length=math.dist(a,b)
        if not length:continue
        visible=clip(a,b,*viewport)
        if visible is not None:
            low,high=(n*length for n in visible)
            if period<2:
                yield (a[0]+(b[0]-a[0])*visible[0],a[1]+(b[1]-a[1])*visible[0],a[0]+(b[0]-a[0])*visible[1],a[1]+(b[1]-a[1])*visible[1])
            else:
                offset=(phase+low)%period;index=0
                while offset>=runs[index][1] and index<len(runs)-1:offset-=runs[index][1];index+=1
                pos=low
                while pos<high:
                    drawn,size=runs[index];end=min(high,pos+size-offset)
                    if drawn and end>pos:
                        yield (a[0]+(b[0]-a[0])*pos/length,a[1]+(b[1]-a[1])*pos/length,a[0]+(b[0]-a[0])*end/length,a[1]+(b[1]-a[1])*end/length)
                        count+=1
                        if count>=20000:return
                    pos=end;offset=0.;index=(index+1)%len(runs)
        phase=(phase+length)%period
