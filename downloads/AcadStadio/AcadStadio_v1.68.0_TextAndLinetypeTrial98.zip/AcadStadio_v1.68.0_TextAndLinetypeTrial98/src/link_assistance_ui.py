"""Compact table/point linking workspace and ordinary-table usage navigation."""

import copy
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from theme import fit_window
from table_grid import GridTreeview
from project_data import input_tables, current_table
from table_formulas import table_columns
from flow import resolve
from preview_command_edit import command_address
from point_preview_ui import PointCanvas
from engine import MacroError
import link_assistance as model


def card(parent, title):
    frame = ttk.LabelFrame(parent, text=title, padding=8)
    frame.pack(fill="x", pady=(0, 8))
    return frame


def tree(parent, columns, height=4):
    frame = ttk.Frame(parent)
    frame.pack(fill="both", expand=True)
    view = GridTreeview(
        frame,
        columns=[c[0] for c in columns],
        show="headings",
        height=height,
        selectmode="browse",
    )
    for key, label, width in columns:
        view.heading(key, text=label)
        view.column(key, width=width, minwidth=45)
    view.pack(side="left", fill="both", expand=True)
    scroll = ttk.Scrollbar(frame, command=view.yview)
    scroll.pack(side="right", fill="y")

    def scroll_changed(first, last):
        scroll.set(first, last)
        if float(first) > 0 or float(last) < 1:
            scroll.pack(side="right", fill="y")
        else:
            scroll.pack_forget()

    view.configure(yscrollcommand=scroll_changed)
    return view


class TableUsageWindow(tk.Toplevel):
    def __init__(self, app, table_id, column):
        super().__init__(app.input_window)
        self.app = app
        self.table_id = table_id
        self.column = column
        self.title("列の使用先")
        self.transient(app.root)
        fit_window(self, 780, 430, 620, 340)
        body = ttk.Frame(self, padding=12)
        body.pack(fill="both", expand=True)
        self.heading = ttk.Label(body, style="Section.TLabel")
        self.heading.pack(anchor="w", pady=(0, 8))
        self.view = tree(
            body,
            [
                ("command", "使用コマンド", 320),
                ("field", "項目", 160),
                ("formula", "式", 250),
            ],
            7,
        )
        self.view.bind("<<TreeviewSelect>>", lambda e: self.locate())
        bar = ttk.Frame(body)
        bar.pack(fill="x", pady=(10, 0))
        ttk.Button(bar, text="紐づけ支援", command=self.assist).pack(side="left")
        ttk.Button(bar, text="コマンドを編集", command=self.edit).pack(
            side="left", padx=6
        )
        ttk.Button(bar, text="閉じる", command=self.destroy).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        self.reload()

    def reload(self):
        table = current_table(self.app.data, self.table_id)
        self.addresses = model.table_usage(self.app.data).get(
            (self.table_id, self.column), []
        )
        self.heading.configure(
            text=f"🔗 {table['name']} / {self.column} — {len(self.addresses)}コマンド"
        )
        self._snapshot = copy.deepcopy(self.app.data)
        self.view.delete(*self.view.get_children())
        for i, at in enumerate(self.addresses):
            cmd = resolve(self.app.data, at)
            fs = []
            for f in model.fields(cmd):
                probe = dict(
                    self.app.data,
                    blocks=[
                        dict(
                            commands=[
                                {
                                    f.path[0]
                                    if len(f.path) == 1
                                    else "value": model.read(cmd, f.path)
                                }
                            ]
                        )
                    ],
                )
                if (self.table_id, self.column) in model.table_usage(probe):
                    fs.append(f)
            self.view.insert(
                "",
                "end",
                iid=str(i),
                values=(
                    model.command_label(self.app.data, at),
                    ", ".join(f.label for f in fs) or "条件・引数など",
                    "; ".join(str(model.read(cmd, f.path)) for f in fs)
                    or ", ".join(model.command_references(cmd)),
                ),
            )
        if self.addresses:
            self.view.selection_set("0")

    def selected(self):
        rows = self.view.selection()
        if not rows:
            return None
        if self.app.data != self._snapshot:
            self.reload()
            return None
        old = self.addresses[int(rows[0])]
        # A changed project must not turn an old row into a different command.
        current = model.table_usage(self.app.data).get((self.table_id, self.column), [])
        if old not in current:
            self.reload()
            return None
        return old

    def locate(self):
        at = self.selected()
        if at is None:
            return
        self.app.preview(quiet=True)
        self.app.canvas.highlight(preset=at[1], address=at)
        self.app.root.lift()
        self.lift()

    def assist(self):
        at = self.selected()
        self.destroy()
        self.app.show_link_assistance(at)

    def edit(self):
        at = self.selected()
        if at is None:
            return
        self.app.preview(quiet=True)
        item = next(
            (
                i
                for i in self.app.canvas.items
                if command_address(self.app.data, i) == at
            ),
            None,
        )
        if item is None:
            messagebox.showinfo(
                "使用コマンド",
                "この確認行には図形がありません。紐づけ支援の一覧から確認できます。",
                parent=self,
            )
            return
        self.destroy()
        self.app.edit_preview_command(item)


class LinkAssistanceWindow(tk.Toplevel):
    def __init__(self, app, address=None):
        super().__init__(app.root)
        self.app = app
        self.project = copy.deepcopy(app.data)
        self.address = address
        self.source = None
        self.proposal = None
        self._sync = False
        self.target_fields = []
        self.pairs = []
        self.trial = None
        self.title("紐づけ支援")
        self.transient(app.root)
        fit_window(self, 1500, 980, 1100, 740)
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.bind("<Escape>", lambda e: self.close())
        self.mode = tk.StringVar(value="入力表")
        self.show_status = tk.BooleanVar(value=True)
        self.message = tk.StringVar(value="図形を選択し、候補を確認して適用します。")
        top = ttk.Frame(self, padding=(12, 8))
        top.pack(fill="x")
        ttk.Label(top, text="紐づけ支援", style="Section.TLabel").pack(
            side="left", padx=(0, 20)
        )
        for mode in ("入力表", "コマンドの点"):
            ttk.Radiobutton(
                top,
                text=mode,
                value=mode,
                variable=self.mode,
                style="Toggle.Toolbutton",
                command=self.mode_changed,
            ).pack(side="left", padx=2)
        ttk.Checkbutton(
            top, text="状況を表示", variable=self.show_status, command=self.draw
        ).pack(side="left", padx=12)
        ttk.Button(top, text="元に戻す", command=self.undo).pack(side="right")
        footer = ttk.Frame(self, padding=(12, 8))
        footer.pack(side="bottom", fill="x")
        ttk.Label(footer, textvariable=self.message, wraplength=950).pack(
            side="left", fill="x", expand=True
        )
        ttk.Button(footer, text="閉じる", command=self.close).pack(side="right")
        self.apply_button = ttk.Button(
            footer, text="紐づけを適用", command=self.apply, style="Primary.TButton"
        )
        self.apply_button.pack(side="right", padx=8)
        body = ttk.Panedwindow(self, orient="horizontal")
        body.pack(fill="both", expand=True, padx=12, pady=(0, 6))
        scroll_area = ttk.Frame(body, width=460)
        body.add(scroll_area, weight=0)
        scroll_area.rowconfigure(0, weight=1)
        scroll_area.columnconfigure(0, weight=1)
        scroller = tk.Canvas(scroll_area, highlightthickness=0, bg="#f3f5f9", width=440)
        scroller.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(scroll_area, command=scroller.yview)
        left = ttk.Frame(scroller)
        left_node = scroller.create_window(0, 0, window=left, anchor="nw")

        def resize_left(event=None):
            scroller.itemconfigure(left_node, width=scroller.winfo_width())
            scroller.configure(scrollregion=scroller.bbox("all"))
            if left.winfo_reqheight() > scroller.winfo_height():
                scrollbar.grid(row=0, column=1, sticky="ns")
            else:
                scrollbar.grid_remove()

        scroller.configure(yscrollcommand=scrollbar.set)
        left.bind("<Configure>", resize_left)
        scroller.bind("<Configure>", resize_left)

        def wheel(event):
            widget = event.widget
            try:
                inside = str(widget).startswith(str(left)) or widget is scroller
            except tk.TclError:
                return
            if inside and left.winfo_reqheight() > scroller.winfo_height():
                scroller.yview_scroll(
                    (-1 if event.delta > 0 else 1)
                    if event.num not in (4, 5)
                    else (-1 if event.num == 4 else 1),
                    "units",
                )

        for sequence in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.bind(sequence, wheel, add="+")
        self.left_scroller = scroller
        right = ttk.Frame(body)
        body.add(right, weight=1)
        status = card(left, "コマンドの状況")
        self.command_tree = tree(
            status, [("command", "コマンド", 275), ("status", "確認状況", 100)], 3
        )
        self.command_tree.bind("<<TreeviewSelect>>", self.command_selected)
        ttk.Label(
            status, text="✓ 確認済み　◐ 一部確認　○ 未確認", style="Muted.TLabel"
        ).pack(anchor="w")
        self.table_card = card(left, "照合の基準")
        row = ttk.Frame(self.table_card)
        row.pack(fill="x")
        self.table_name = tk.StringVar(value=current_table(self.project)["name"])
        self.table_picker = ttk.Combobox(
            row,
            textvariable=self.table_name,
            values=[t["name"] for t in input_tables(self.project)],
            state="readonly",
            width=20,
        )
        self.table_picker.pack(side="left", fill="x", expand=True)
        self.table_picker.bind("<<ComboboxSelected>>", lambda e: self.table_changed())
        ttk.Button(row, text="表を開く", command=self.open_table).pack(
            side="left", padx=(6, 0)
        )
        row = ttk.Frame(self.table_card)
        row.pack(fill="x", pady=(6, 0))
        ttk.Label(row, text="基準行").pack(side="left")
        self.base_row = tk.StringVar(value="1")
        self.base_picker = ttk.Combobox(
            row, textvariable=self.base_row, width=7, state="readonly"
        )
        self.base_picker.pack(side="left", padx=8)
        self.base_picker.bind("<<ComboboxSelected>>", lambda e: self.base_changed())
        self.base_title = ttk.Label(row, style="Muted.TLabel")
        self.base_title.pack(side="left")
        self.target_card = card(left, "置き換える項目")
        self.target_title = ttk.Label(self.target_card, wraplength=410)
        self.target_title.pack(anchor="w")
        row = ttk.Frame(self.target_card)
        row.pack(fill="x", pady=(6, 0))
        self.field_name = tk.StringVar()
        self.field_picker = ttk.Combobox(
            row, textvariable=self.field_name, state="readonly", width=17
        )
        self.field_picker.pack(side="left", fill="x", expand=True)
        self.field_picker.bind("<<ComboboxSelected>>", lambda e: self.target_changed())
        self.value_label = ttk.Label(row, width=20, anchor="e")
        self.value_label.pack(side="left", padx=6)
        self.add_column_button=ttk.Button(self.target_card,text='表の列に追加…',command=self.add_column)
        self.add_column_button.pack(anchor='w',pady=(6,0))
        self.candidate_card = card(left, "一致する候補")
        self.candidate_tree = tree(
            self.candidate_card,
            [
                ("name", "列名・コマンド", 180),
                ("value", "基準値・点", 95),
                ("result", "照合結果", 100),
            ],
            2,
        )
        self.candidate_tree.bind(
            "<<TreeviewSelect>>", lambda e: self.candidate_selected()
        )
        self.formula_button = ttk.Button(
            self.candidate_card, text="ƒ 式で探す…", command=self.toggle_formula
        )
        self.formula_button.pack(anchor="w", pady=(6, 0))
        self.formula_row = ttk.Frame(self.candidate_card)
        self.formula = tk.StringVar(value="値 / 2")
        self.use_formula = tk.BooleanVar(value=False)
        ttk.Entry(self.formula_row, textvariable=self.formula).pack(
            side="left", fill="x", expand=True
        )
        ttk.Button(self.formula_row, text="検索", command=self.find_candidates).pack(
            side="left", padx=(6, 0)
        )
        self.point_card = card(left, "参照先")
        self.source_name = tk.StringVar()
        self.point_name = tk.StringVar()
        self.axis = tk.StringVar(value="XY")
        self.source_picker = ttk.Combobox(
            self.point_card, textvariable=self.source_name, state="readonly", width=34
        )
        self.source_picker.pack(fill="x")
        self.source_picker.bind(
            "<<ComboboxSelected>>", lambda e: self.source_selected()
        )
        row = ttk.Frame(self.point_card)
        row.pack(fill="x", pady=(6, 0))
        self.point_picker = ttk.Combobox(
            row, textvariable=self.point_name, state="readonly", width=14
        )
        self.point_picker.pack(side="left", fill="x", expand=True)
        self.point_picker.bind("<<ComboboxSelected>>", lambda e: self.point_changed())
        for axis in ("XY", "X", "Y"):
            ttk.Radiobutton(
                row,
                text=axis,
                value=axis,
                variable=self.axis,
                style="Toggle.Toolbutton",
                command=self.point_changed,
            ).pack(side="left", padx=(4, 0))
        self.offset_visible = False
        ttk.Button(
            self.point_card, text="▸ 移動量を指定", command=self.toggle_offsets
        ).pack(anchor="w", pady=(6, 0))
        self.offset_row = ttk.Frame(self.point_card)
        self.offsets = [tk.StringVar(value="0"), tk.StringVar(value="0")]
        for name, var in zip(("X", "Y"), self.offsets):
            ttk.Label(self.offset_row, text=name).pack(side="left")
            ttk.Entry(self.offset_row, textvariable=var, width=12).pack(
                side="left", fill="x", expand=True, padx=4
            )
            var.trace_add("write", lambda *_: self.point_changed())
        result = card(left, "設定・適用内容")
        self.detail_tree = tree(
            result,
            [("field", "項目", 110), ("value", "設定", 200), ("state", "状態", 95)],
            3,
        )
        self.detail_tree.bind("<Button-3>",self.field_menu)
        tools = ttk.Frame(result)
        tools.pack(fill="x", pady=(6, 0))
        ttk.Button(tools, text="固定値のまま確認", command=self.confirm_fixed).pack(
            side="left"
        )
        self.batch = tk.BooleanVar(value=False)
        self.batch_check = ttk.Checkbutton(
            self.point_card,
            text="測定点2も終点へまとめて紐づける",
            variable=self.batch,
            command=self.make_proposal,
        )
        self.proposal_label = ttk.Label(result, wraplength=415, style="Muted.TLabel")
        self.proposal_label.pack(fill="x", pady=(6, 0))
        self.canvas = PointCanvas(right, self.pick_point, self.pick_source)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Double-1>", lambda e: "break")
        self.canvas.bind("<Map>", lambda e: self.after_idle(self.canvas.fit), add="+")
        self.canvas.display_color = self.figure_color
        self.canvas.draw_markers_original = self.canvas.draw_markers
        self.canvas.draw_markers = self.draw_markers
        controls = ttk.Frame(right)
        controls.pack(fill="x", pady=5)
        ttk.Label(controls, text="確認行").pack(side="left")
        self.preview_row = tk.StringVar(value="1")
        self.preview_picker = ttk.Combobox(
            controls,
            textvariable=self.preview_row,
            state="readonly",
            width=5,
            values=[
                str(i + 1) for i in range(len(current_table(self.project)["rows"]))
            ],
        )
        self.preview_picker.pack(side="left", padx=6)
        self.preview_picker.bind(
            "<<ComboboxSelected>>", lambda e: self.preview_changed()
        )
        ttk.Button(controls, text="全体を表示", command=self.canvas.fit).pack(
            side="right"
        )
        table_area = ttk.Frame(right, height=165)
        table_area.pack(fill="x")
        table_area.pack_propagate(False)
        self.table_view = tree(
            table_area,
            [
                ("column", "入力表の列", 180),
                ("value", "基準行の値", 160),
                ("usage", "リンク数", 100),
            ],
            3,
        )
        self.table_view.bind("<<TreeviewSelect>>", lambda e: self.column_selected())
        self.table_view.bind("<Double-1>", lambda e: self.column_usage())
        self.after_idle(lambda: body.sashpos(0, 460))
        self.after_idle(lambda: self.canvas.fit())
        self.reload()
        self.mode_changed()
        self.grab_set()

    def row(self):
        return max(0, int(self.preview_row.get() or "1") - 1)

    def table(self):
        return next(
            t for t in input_tables(self.project) if t["name"] == self.table_name.get()
        )

    def field(self):
        i = self.field_picker.current()
        return self.target_fields[i] if 0 <= i < len(self.target_fields) else None

    def command(self):
        return resolve(self.project, self.address) if self.address else None

    def reload(self):
        old = self.address
        old_field=self.field() if self.mode.get()=="入力表" else None
        self.project = copy.deepcopy(self.app.data)
        names = [t["name"] for t in input_tables(self.project)]
        self.table_picker["values"] = names
        if self.table_name.get() not in names:
            self.table_name.set(current_table(self.project)["name"])
        rows = [str(i + 1) for i in range(len(current_table(self.project)["rows"]))]
        self.preview_picker["values"] = rows
        if self.preview_row.get() not in rows:
            self.preview_row.set(rows[0] if rows else "1")
        self.entries = [
            (a, c) for a, c in model.commands(self.project) if model.fields(c)
        ]
        self.command_tree.delete(*self.command_tree.get_children())
        for i, (at, cmd) in enumerate(self.entries):
            done, total = model.status(cmd)
            icon = "✓" if done == total else "◐" if done else "○"
            self.command_tree.insert(
                "",
                "end",
                iid=str(i),
                values=(
                    model.command_label(self.project, at),
                    f"{icon} {done}/{total}",
                ),
            )
        index = next((i for i, (a, c) in enumerate(self.entries) if a == old), 0)
        self.address = self.entries[index][0] if self.entries else None
        if self.entries:
            self.command_tree.selection_set(str(index))
            self.command_tree.see(str(index))
        self.table_changed()
        self.select_command()
        if old==self.address and old_field in self.target_fields:
            self.field_picker.current(self.target_fields.index(old_field));self.target_changed()

    def command_selected(self, event=None):
        rows = self.command_tree.selection()
        if rows:
            at = self.entries[int(rows[0])][0]
            if at != self.address:
                self.address = at
                self.select_command()

    def select_command(self):
        self.source = None
        self.proposal = None
        self.batch.set(False)
        cmd = self.command()
        self.target_fields = []
        self.pairs = []
        if cmd:
            self.target_title.configure(
                text=model.command_label(self.project, self.address)
            )
            self.target_fields = model.fields(cmd)
            self.pairs = model.coordinate_pairs(cmd)
        choices = (
            [f.label for f in self.target_fields]
            if self.mode.get() == "入力表"
            else [p[0] for p in self.pairs]
        )
        self.field_picker["values"] = choices
        if choices:
            self.field_picker.current(0)
        else:
            self.field_name.set("対象の項目がありません")
        self.update_details()
        self.target_changed()

    def update_details(self):
        self.detail_tree.delete(*self.detail_tree.get_children())
        cmd = self.command()
        if not cmd:
            return
        for i, f in enumerate(model.fields(cmd)):
            raw = str(model.read(cmd, f.path))
            state = (
                "紐づけ済み"
                if model.linked(cmd, f)
                else "固定値確認済み"
                if cmd.get("link_review", {}).get(model.review_key(f)) == raw
                else "未確認"
            )
            self.detail_tree.insert("", "end", iid=str(i), values=(f.label, raw, state))

    def mode_changed(self):
        point = self.mode.get() == "コマンドの点"
        self.table_card.pack_forget()
        self.point_card.pack_forget()
        self.formula_button.pack_forget()
        self.formula_row.pack_forget()
        if point:
            self.point_card.pack(fill="x", pady=(0, 8), after=self.candidate_card)
        else:
            self.table_card.pack(fill="x", pady=(0, 8), before=self.target_card)
            self.formula_button.pack(anchor="w", pady=(6, 0))
            if self.use_formula.get():
                self.formula_row.pack(fill="x", pady=(6, 0))
        self.select_command()

    def table_changed(self):
        table = self.table()
        values = [str(i + 1) for i in range(len(table["rows"]))]
        self.base_picker["values"] = values
        if self.base_row.get() not in values:
            self.base_row.set(values[0] if values else "")
        self.base_changed()

    def base_changed(self):
        table = self.table()
        i = int(self.base_row.get() or "1") - 1
        self.base_title.configure(
            text=str(next(iter(table["rows"][i].values()), ""))[:24]
            if table["rows"]
            else "行がありません"
        )
        self.refresh_table()
        self.find_candidates()

    def refresh_table(self):
        table = self.table()
        usage = model.table_usage(self.project)
        self.table_columns = table_columns(table)
        self.table_view.delete(*self.table_view.get_children())
        resolver = model.RowResolver(
            self.project, model.convert, model.evaluate, MacroError
        )
        for i, col in enumerate(self.table_columns):
            try:
                value = resolver.cell(
                    table["name"], int(self.base_row.get() or "1") - 1, col
                )
            except (ValueError, MacroError):
                value = "—"
            n = len(usage.get((table["id"], col), []))
            self.table_view.insert(
                "", "end", iid=str(i), values=(col, value, f"🔗 {n}" if n else "")
            )

    def target_changed(self):
        self.proposal = None
        self.source = None
        self.batch.set(False)
        self.batch_check.pack_forget()
        self.point_name.set("")
        self.source_name.set("")
        self.sources = []
        f=self.field() if self.mode.get()=='入力表' else None
        enabled=f is not None and f.numeric and not model.linked(self.command(),f)
        self.add_column_button.state(['!disabled'] if enabled else ['disabled'])
        self.find_candidates()


    def field_menu(self,event):
        item=self.detail_tree.identify_row(event.y)
        if not item:return
        field=model.fields(self.command())[int(item)];self.detail_tree.selection_set(item)
        if self.mode.get()=='入力表':self.field_picker.current(self.target_fields.index(field));self.target_changed()
        previous=getattr(self,'field_context_menu',None)
        if previous is not None:previous.destroy()
        menu=self.field_context_menu=tk.Menu(self,tearoff=False)
        menu.add_command(label='表の列に追加…',state='normal' if field.numeric and not model.linked(self.command(),field) else 'disabled',command=lambda:self.add_column(field))
        menu.bind('<Unmap>',lambda e:self.after_idle(self.grab_set));menu.tk_popup(event.x_root,event.y_root)

    def add_column(self,field=None):
        field=field or (self.field() if self.mode.get()=='入力表' else None)
        if field is None or not field.numeric or model.linked(self.command(),field):
            self.message.set('列へ追加する固定の数値項目を選択してください。');return
        if self.app.data!=self.project:self.reload();self.message.set('プロジェクトが変更されました。項目を選び直してください。');return
        import re
        initial=re.sub(r'\W','_',field.label);base=initial;number=2
        while initial in model.table_columns(self.table()):initial=f'{base}_{number}';number+=1
        name=simpledialog.askstring('表の列に追加',f"{field.label} = {model.read(self.command(),field.path)}\n追加先：{self.table()['name']}\n列名を入力してください。値をセルへ入れ、この項目を列へ紐づけます。\n行がなければ1行作成します。既存の複数行には同じ初期値を入れます。",initialvalue=initial,parent=self)
        self.grab_set()
        if name is None:return
        if self.app.data!=self.project:self.reload();self.message.set('プロジェクトが変更されました。項目を選び直してください。');return
        try:
            trial=model.add_field_column(self.project,self.address,field,name,self.table()['id'],self.row())
            self.commit(trial,f'「{name.strip()}」列を追加し、値を入力して紐づけました',tables=True)
        except (ValueError,MacroError,KeyError,IndexError) as exc:messagebox.showerror('表の列に追加',str(exc),parent=self)

    def find_candidates(self):
        self.candidate_tree.delete(*self.candidate_tree.get_children())
        self.candidates = []
        cmd = self.command()
        self.proposal = None
        if cmd is None:
            self.draw()
            return
        try:
            if self.mode.get() == "入力表":
                f = self.field()
                if f is None:
                    return
                self.value_label.configure(text=str(model.read(cmd, f.path))[:24])
                self.candidates = model.table_candidates(
                    self.project,
                    cmd,
                    f,
                    self.table()["id"],
                    int(self.base_row.get() or "1") - 1,
                    self.formula.get() if self.use_formula.get() else "",
                    target_row=self.row(),
                )
                for i, c in enumerate(self.candidates):
                    self.candidate_tree.insert(
                        "",
                        "end",
                        iid=str(i),
                        values=(
                            c["column"],
                            c["value"],
                            c["recipe"].replace("値", "") or "そのまま",
                        ),
                    )
            else:
                index = self.field_picker.current()
                if not 0 <= index < len(self.pairs):
                    return
                pair = self.pairs[index]
                self.value_label.configure(
                    text=f"X:{model.read(cmd, pair[1].path)} Y:{model.read(cmd, pair[2].path)}"[
                        :32
                    ]
                )
                self.sources = model.source_candidates(
                    self.project, self.address, self.row()
                )
                self.source_picker["values"] = [s["label"] for s in self.sources]
                self.source_name.set("")
                self.point_name.set("")
                self.candidates = model.point_candidates(
                    self.project, self.address, pair, self.row()
                )
                for i, c in enumerate(self.candidates):
                    self.candidate_tree.insert(
                        "",
                        "end",
                        iid=str(i),
                        values=(c["source"]["label"], c["point"], "位置一致"),
                    )
            self.message.set(
                "候補を選ぶか、プレビューの図形をクリックしてください。"
                if self.candidates
                else "一致候補はありません。式で検索、または参照元を直接選択できます。"
            )
        except (ValueError, MacroError, KeyError, IndexError) as exc:
            self.message.set(str(exc))
        self.draw()
        self.make_proposal()

    def candidate_selected(self):
        selected = self.candidate_tree.selection()
        if not selected:
            return
        c = self.candidates[int(selected[0])]
        if self.mode.get() == "入力表":
            self.proposal = c
            i = self.table_columns.index(c["column"])
            self.table_view.selection_set(str(i))
            self.table_view.see(str(i))
            self.make_proposal()
        else:
            self.source = c["source"]
            self.source_picker.current(
                next(
                    i
                    for i, s in enumerate(self.sources)
                    if s["address"] == self.source["address"]
                    and s["item"] == self.source["item"]
                )
            )
            self.source_selected(c["point"])

    def source_selected(self, point=None):
        i = self.source_picker.current()
        if not 0 <= i < len(getattr(self, "sources", [])):
            return
        self.source = self.sources[i]
        names = list(self.source["points"])
        self.point_picker["values"] = names
        self.point_name.set(point if point in names else names[0])
        self.batch.set(False)
        self.point_changed()

    def point_changed(self):
        if self._sync:
            return
        self.make_proposal()
        self.draw()

    def make_proposal(self):
        self.apply_button.state(["disabled"])
        self.proposal_label.configure(text="候補を選択してください。")
        self.trial = None
        if self.address is None:
            return
        try:
            if self.mode.get() == "入力表":
                if not self.proposal:
                    return
                self.trial = model.checked_change(
                    self.project,
                    self.address,
                    [(self.field(), self.proposal["formula"])],
                    self.row(),
                )
                text = f"{self.field().label} → {self.proposal['formula']}"
            else:
                if not self.source or not self.point_name.get():
                    return
                pair = self.pairs[self.field_picker.current()]
                self.trial = model.checked_change(
                    self.project,
                    self.address,
                    pair,
                    self.row(),
                    source=(
                        self.source["address"],
                        self.point_name.get(),
                        self.axis.get(),
                        [v.get() for v in self.offsets],
                    ),
                )
                text = f"{pair[0]} → {self.source['label']}・{self.point_name.get()} [{self.axis.get()}]"
                can_batch = (
                    self.command()["type"] in ("DIMLINEAR", "DIMALIGNED")
                    and pair[1].path == ("x1",)
                    and self.source["item"].get("type") == "LINE"
                    and self.point_name.get() == "始点"
                    and self.axis.get() == "XY"
                    and all(v.get().strip() in ("", "0") for v in self.offsets)
                )
                self.batch_check.pack_forget()
                if can_batch:
                    second = next((p for p in self.pairs if p[1].path == ("x2",)), None)
                    end = self.source["points"].get("終点")
                    matched = (
                        second
                        and end
                        and all(
                            model.same(
                                model.numeric_value(
                                    self.project,
                                    model.read(self.command(), f.path),
                                    self.row(),
                                ),
                                v,
                            )
                            for f, v in zip(second[1:], end)
                        )
                    )
                    if matched:
                        self.batch_check.pack(anchor="w", pady=(6, 0))
                        if self.batch.get():
                            self.trial = model.checked_change(
                                self.trial,
                                self.address,
                                second,
                                self.row(),
                                source=(
                                    self.source["address"],
                                    "終点",
                                    "XY",
                                    ["0", "0"],
                                ),
                            )
                            text += " / 測定点2 → 終点"
            self.proposal_label.configure(text=text)
            self.apply_button.state(["!disabled"])
            self.message.set("適用予定：" + text)
        except (ValueError, MacroError, KeyError, IndexError) as exc:
            self.proposal_label.configure(text=str(exc))
        self.draw(proposed=True)

    def draw(self, proposed=False):
        project = (
            self.trial
            if proposed and getattr(self, "trial", None) is not None
            else self.project
        )
        try:
            items = model.scenes(project, self.row())
        except (ValueError, MacroError, KeyError, IndexError) as exc:
            self.message.set(str(exc))
            return
        self.canvas.source_map = None
        self.canvas.source_labels = {}
        self.canvas.snap_points = {}
        self.canvas.selected_point = None
        for i, item in enumerate(items):
            try:
                at = command_address(project, item)
            except (KeyError, ValueError, IndexError):
                continue
            item["_link_index"] = i
            self.canvas.source_labels[i] = model.command_label(project, at)
        address_indices = {}
        for i, item in enumerate(items):
            try:
                address_indices[command_address(project, item)] = i
            except (ValueError, KeyError, IndexError):
                pass

        def source_index(item):
            try:
                return address_indices.get(command_address(project, item))
            except (ValueError, KeyError, IndexError):
                return None

        self.canvas.item_source_index = source_index
        self.canvas.source_index = None
        self.canvas.related_source_indices = set()
        self.scene_addresses = []
        for i, item in enumerate(items):
            try:
                at = command_address(project, item)
            except (KeyError, ValueError, IndexError):
                at = None
            self.scene_addresses.append(at)
            if at == self.address:
                self.canvas.related_source_indices.add(i)
            if self.source and at == self.source["address"]:
                self.canvas.source_index = i
                self.canvas.snap_points = self.source["points"]
                self.canvas.selected_point = self.point_name.get()
        self.canvas.set_color_resources(project)
        self.canvas.set_items(items, preserve_camera=self.canvas._camera_ready)
        self.draw_markers()

    def figure_color(self, item, fallback):
        try:
            at = command_address(self.project, item)
        except (ValueError, KeyError, IndexError):
            return "#34465c"
        if self.source and at == self.source["address"]:
            return "#60a5fa"
        if at == self.address:
            return "#c4b5fd" if self.mode.get() == "コマンドの点" else "#60a5fa"
        if self.show_status.get():
            done, total = model.status(resolve(self.project, at))
            if total and done == total:
                return "#86cfa3"
        return "#34465c"

    def draw_markers(self):
        self.canvas.draw_markers_original()
        self.canvas.delete("link-status")
        if not self.show_status.get() or not hasattr(self.canvas, "_base_offset"):
            return
        seen = set()
        occupied = []
        for i, item in enumerate(self.canvas.items):
            try:
                at = command_address(self.project, item)
            except (ValueError, KeyError, IndexError):
                at = None
            if at is None or at in seen:
                continue
            seen.add(at)
            done, total = model.status(resolve(self.project, at))
            if not total:
                continue
            x, y = self.canvas.screen_point(item["coords"][:2])
            icon = "✓" if done == total else "◐" if done else "○"
            x = max(10, min(self.canvas.winfo_width() - 75, x + 10))
            y = max(22, y - 28)
            while any(abs(x - a) < 85 and abs(y - b) < 22 for a, b in occupied):
                y += 24
            occupied.append((x, y))
            node = self.canvas.create_text(
                x,
                y,
                text=f"{icon} {done}/{total}",
                fill="#86efac" if done == total else "#cbd5e1",
                anchor="w",
                tags="link-status",
            )
            box = self.canvas.bbox(node)
            if box:
                bg = self.canvas.create_rectangle(
                    box[0] - 3,
                    box[1] - 2,
                    box[2] + 3,
                    box[3] + 2,
                    fill="#101d30",
                    outline="",
                    tags="link-status",
                )
                self.canvas.tag_lower(bg, node)

    def pick_source(self, index):
        if not 0 <= index < len(self.scene_addresses):
            return
        at = self.scene_addresses[index]
        if self.mode.get() == "コマンドの点" and at != self.address:
            source = next(
                (
                    i
                    for i, s in enumerate(getattr(self, "sources", []))
                    if s["address"] == at
                ),
                None,
            )
            if source is not None:
                self.source_picker.current(source)
                self.source_selected()
                return
            self.message.set(
                "この図形は先行する参照元に選べません。後方参照はコマンド編集で確認してください。"
            )
            return
        i = next(
            (i for i, (address, c) in enumerate(self.entries) if address == at), None
        )
        if i is not None:
            self.command_tree.selection_set(str(i))
            self.command_tree.see(str(i))
            self.command_selected()

    def pick_point(self, name):
        if (
            self.mode.get() == "コマンドの点"
            and self.source
            and name in self.source["points"]
        ):
            self.point_name.set(name)
            self.point_changed()

    def column_selected(self):
        selected = self.table_view.selection()
        if not selected:
            return
        col = self.table_columns[int(selected[0])]
        self.draw(proposed=True)
        uses = model.table_usage(self.project).get((self.table()["id"], col), [])
        for node, item, color in self.canvas.geometry:
            try:
                at = command_address(self.project, item)
            except (ValueError, KeyError, IndexError):
                continue
            if at in uses:
                if self.canvas.type(node)=='image':self.canvas._text_colors[node]='#60a5fa';continue
                option = (
                    "outline"
                    if self.canvas.type(node) in ("oval", "rectangle")
                    else "fill"
                )
                self.canvas.itemconfigure(node, **{option: "#60a5fa"})
        self.canvas.redraw_text()
        if self.mode.get() == "入力表":
            candidates = [
                i for i, c in enumerate(self.candidates) if c.get("column") == col
            ]
            if candidates and not self.candidate_tree.selection():
                self.candidate_tree.selection_set(str(candidates[0]))

    def column_usage(self):
        rows = self.table_view.selection()
        if not rows:
            return
        col = self.table_columns[int(rows[0])]
        usage = model.table_usage(self.project).get((self.table()["id"], col), [])
        messagebox.showinfo(
            "列の使用先",
            "\n".join(model.command_label(self.project, a) for a in usage)
            or "この列はコマンドで使用されていません。",
            parent=self,
        )

    def toggle_formula(self):
        self.use_formula.set(not self.use_formula.get())
        if self.use_formula.get():
            self.formula_row.pack(fill="x", pady=(6, 0))
            self.formula_button.configure(text="ƒ 式による検索を閉じる")
        else:
            self.formula_row.pack_forget()
            self.formula_button.configure(text="ƒ 式で探す…")
            self.find_candidates()

    def toggle_offsets(self):
        self.offset_visible = not self.offset_visible
        if self.offset_visible:
            self.offset_row.pack(fill="x", pady=(6, 0))
        else:
            self.offset_row.pack_forget()

    def preview_changed(self):
        # Preview the pending replacement with another active-table row before committing.
        self.make_proposal()
        self.draw(proposed=True)

    def commit(self, trial, message, tables=False):
        if tables:
            self.app.data['input_tables']=trial['input_tables'];self.app.data['drawing']=trial['drawing']
        self.app.data["blocks"] = trial["blocks"]
        self.app.refresh()
        self.app.preview(quiet=True)
        self.reload()
        self.message.set(message + "（元に戻せます）")

    def apply(self):
        self.make_proposal()
        if self.trial is not None:
            self.commit(self.trial, "紐づけを適用しました")

    def confirm_fixed(self):
        selected = self.detail_tree.selection()
        if not selected:
            self.message.set("内訳から確認する固定値の項目を選んでください。")
            return
        f = model.fields(self.command())[int(selected[0])]
        if model.linked(self.command(), f):
            self.message.set("この項目は紐づけ済みです。")
            return
        trial = copy.deepcopy(self.project)
        cmd = resolve(trial, self.address)
        cmd.setdefault("link_review", {})[model.review_key(f)] = str(
            model.read(cmd, f.path)
        )
        self.commit(trial, "固定値のまま使う項目として確認しました")

    def undo(self):
        self.app.undo_project()
        self.reload()
        self.message.set("変更を元に戻しました")

    def open_table(self):
        self.close()
        self.app.show_input_table()

    def close(self):
        self.grab_release()
        self.destroy()
        self.app.root.lift()
