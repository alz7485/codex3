"""Native object transforms, CAD block creation and true multiline text."""
import math
from cad_setup import cad_name
from range_selection import MODES, RANGE_TYPES, box_points, native_selection

TYPES=frozenset(('ROTATE','ROTATECOPY','ARRAYRECT','EXPLODE','CADBLOCK','SCALE','MTEXT'))
SELECTION_TYPES=TYPES-{'MTEXT'}
PICK=[('layer',''),('x1','@X+50'),('y1','@Y')]
BASE=[('x2','@X'),('y2','@Y')]
FIELDS={
    'ROTATE':PICK+BASE+[('angle','90'),('pick_tolerance','0.01')],
    'ROTATECOPY':PICK+BASE+[('angle','30'),('copy_count','3'),('pick_tolerance','0.01')],
    'ARRAYRECT':PICK+[('columns','3'),('rows','2'),('column_spacing','100'),('row_spacing','80'),('pick_tolerance','0.01')],
    'EXPLODE':PICK+[('pick_tolerance','0.01')],
    'CADBLOCK':PICK+BASE+[('block_name','PART'),('pick_tolerance','0.01')],
    'SCALE':PICK+BASE+[('factor','2'),('pick_tolerance','0.01')],
    'MTEXT':[('layer',''),('x','@X'),('y','@Y'),('text','部品名\n仕様・注記'),('height','settings.TEXT_HEIGHT'),('width','80'),('angle','0')],
}


def text_value(raw,values):
    from engine import evaluate
    from table_references import is_single_table_reference
    raw=str(raw)
    return str(evaluate(raw[1:] if raw.startswith('=') else raw,values)) if raw.startswith('=') or is_single_table_reference(raw) else raw


def count(value,label):
    if not value.is_integer() or not 1<=value<=1000:raise ValueError(label+'は1〜1000の整数で指定してください')
    return int(value)


def render(command,values,number):
    from extended_commands import quoted,selection_lisp,current_properties_lisp
    typ=command['type'];n=lambda key,default='0':float(number(command.get(key,default),values))
    pt=lambda suffix='':(n('x'+suffix),n('y'+suffix))
    lp=lambda p:f'(list {p[0]:.12g} {p[1]:.12g} 0.0)'
    overrides={key for key in ('layer','color','linetype','linetype_scale') if str(command.get(key,'')).strip()}
    item={};lines=[]
    if typ=='MTEXT':
        p=pt();height=n('height','settings.TEXT_HEIGHT');width=n('width','80');angle=n('angle')%360
        content=text_value(command.get('text',''),values).replace('\r\n','\n').replace('\r','\n')
        if not content.strip() or any(ord(c)<32 and c not in '\n\t' for c in content) or '\x7f' in content:raise ValueError('マルチテキストに文字を入力してください。制御文字は使用できません')
        if len(content)>16384:raise ValueError('マルチテキストは16384文字までです')
        if height<=0 or width<=0:raise ValueError('文字高さと幅は正数にしてください')
        escaped=content.replace('\\','\\\\').replace('{','\\{').replace('}','\\}').replace('\n','\\P').replace('\t','    ')
        body='((lambda (/ doc space result cc rgb clr) (vl-load-com) '
        body+='(setq doc (vla-get-ActiveDocument (vlax-get-acad-object)) space (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))) '
        body+=f'(setq result (vl-catch-all-apply \'vla-AddMText (list space (vlax-3d-point {lp(p)}) {width:.12g} {quoted(escaped)}))) '
        body+='(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
        body+=f'(vla-put-Height result {height:.12g}) (vla-put-Rotation result {math.radians(angle):.12g}) (vla-put-StyleName result (getvar "TEXTSTYLE")) '
        attachment=n('attachment','1')
        if attachment not in range(1,10):raise ValueError('マルチテキストの配置は1〜9です')
        if 'attachment' in command:body+=f'(vla-put-AttachmentPoint result {int(attachment)}) (vla-put-InsertionPoint result (vlax-3d-point {lp(p)})) '
        spacing=n('line_spacing','1');spacing_style=n('line_spacing_style','1')
        if not .25<=spacing<=4 or spacing_style not in (1,2):raise ValueError('マルチテキストの行間隔を確認してください')
        if 'line_spacing' in command or 'line_spacing_style' in command:body+=f'(vla-put-LineSpacingFactor result {spacing:.12g}) (vla-put-LineSpacingStyle result {int(spacing_style)}) '
        body+=current_properties_lisp('result')+'))' 
        return [body],dict(coords=(*p,height),text=content,width=width,angle=angle,text_anchor={1:'nw',2:'n',3:'ne',4:'w',5:'center',6:'e',7:'sw',8:'s',9:'se'}[int(attachment)],text_line_spacing=5/3*spacing,preview_note='マルチテキスト：部分書式は再現対象外')
    first=pt('1');base=pt('2') if typ not in ('ARRAYRECT','EXPLODE') else (0.,0.)
    tolerance=n('pick_tolerance','0.01')
    if not 0<tolerance<=100:raise ValueError('選択許容差は0より大きく100以下にしてください')
    mode=command.get('selection_mode','point')
    if mode not in MODES:raise ValueError('選択方法が不正です')
    named='selection_ref' in command
    box=box_points(command,number,values) if mode!='point' and not named else None
    locals_='ss i e p q found source target result before cc rgb clr data kind anchor boundary pair chosen obj made step row column doc definition arr objects name space object moved'
    prefix='((lambda (/ '+locals_+') (vl-load-com) '
    if named:
        from selection_sets import reference_lisp
        prefix+=reference_lisp(command['selection_ref'],'chosen')
    elif box:
        prefix+=native_selection(box,mode,'chosen')
    else:
        prefix+=selection_lisp(*first,tolerance,'source',general=True)+'(setq chosen (ssadd source)) '
    metadata=dict(coords=(*first,*base),overrides=tuple(sorted(overrides)),preview_note='操作結果はCADで確認')
    if box:metadata.update(selection_mode=mode,selection_box=box)
    if named:metadata['selection_ref']=command['selection_ref']
    if typ in ('ROTATE','ROTATECOPY'):
        angle=n('angle');metadata['angle']=angle
        if typ=='ROTATECOPY':metadata['copy_count']=count(n('copy_count','1'),'追加個数')
        radians=math.radians(angle)
    if typ=='SCALE':
        factor=n('factor','1')
        if factor<=0:raise ValueError('尺度の倍率は正数にしてください')
        metadata['factor']=factor
    if typ=='ARRAYRECT':
        columns=count(n('columns','1'),'列数');rows=count(n('rows','1'),'行数')
        if rows*columns<2 or rows*columns>1000:raise ValueError('配列の行数×列数は2〜1000にしてください（元図形を含む）')
        dx=n('column_spacing');dy=n('row_spacing')
        if (columns>1 and dx==0) or (rows>1 and dy==0):raise ValueError('複数行・列を並べる間隔は0以外にしてください')
        metadata.update(columns=columns,rows=rows,column_spacing=dx,row_spacing=dy)
    if typ in ('ROTATECOPY','ARRAYRECT'):
        copies=metadata.get('copy_count',metadata.get('rows',1)*metadata.get('columns',1)-1)
        prefix+=f'(if (> (* (sslength chosen) {copies}) 1000) (error "AcadStadio: Created copies exceed 1000 entities")) '
    if typ=='CADBLOCK':
        name=text_value(command.get('block_name',''),values)
        if not cad_name(name) or name.startswith('*'):raise ValueError('CADブロック名を指定してください。匿名名や記号は使用できません')
        metadata.update(block_name=name)
        body=f'(setq name {quoted(name)}) (if (tblsearch "BLOCK" name) (error "AcadStadio: CAD block name already exists")) '
        body+='(setq doc (vla-get-ActiveDocument (vlax-get-acad-object)) space (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))) '
        body+='(setq definition (vla-Add (vla-get-Blocks doc) (vlax-3d-point (list 0.0 0.0 0.0)) name)) '
        body+='(setq arr (vlax-make-safearray vlax-vbObject (cons 0 (1- (sslength chosen)))) i 0) '
        body+='(repeat (sslength chosen) (vlax-safearray-put-element arr i (vlax-ename->vla-object (ssname chosen i))) (setq i (1+ i))) '
        body+='(setq result (vl-catch-all-apply \'vla-CopyObjects (list doc (vlax-make-variant arr) definition))) '
        body+='(if (vl-catch-all-error-p result) (progn (vl-catch-all-apply \'vla-Delete (list definition)) (error (vl-catch-all-error-message result)))) '
        body+='(setq objects (vlax-safearray->list (vlax-variant-value result))) '
        body+=f'(foreach object objects (vla-Move object (vlax-3d-point {lp(base)}) (vlax-3d-point (list 0.0 0.0 0.0)))) '
        body+=f'(setq result (vl-catch-all-apply \'vla-InsertBlock (list space (vlax-3d-point {lp(base)}) name 1.0 1.0 1.0 0.0))) '
        body+='(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
        body+=current_properties_lisp('result')
        body+='(setq i 0) (repeat (sslength chosen) (vla-Delete (vlax-ename->vla-object (ssname chosen i))) (setq i (1+ i))) '
        return [prefix+body+'))'],metadata
    prefix+='(setq i 0) (repeat (sslength chosen) (setq e (ssname chosen i) obj (vlax-ename->vla-object e)) '
    if typ=='EXPLODE':
        body='(setq before (entlast) result (vl-catch-all-apply \'command-s (list "_.EXPLODE" e ""))) '
        body+='(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
        body+='(if (entget e) (error "AcadStadio: Selected entity could not be exploded")) '
        if overrides:
            body+='(setq made (entnext before)) (while made (if (not (member (cdr (assoc 0 (entget made))) (list "ATTRIB" "VERTEX" "SEQEND"))) '+current_properties_lisp('(vlax-ename->vla-object made)',overrides)+') (setq made (entnext made))) '
    elif typ in ('ROTATE','SCALE'):
        fn='vla-Rotate' if typ=='ROTATE' else 'vla-ScaleEntity';value=radians if typ=='ROTATE' else factor
        body=f'(setq result (vl-catch-all-apply \'{fn} (list obj (vlax-3d-point {lp(base)}) {value:.12g}))) '
        body+='(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '+current_properties_lisp('obj',overrides)
    else:
        copy='(setq made (vla-Copy obj)) '
        if typ=='ROTATECOPY':
            body=f'(setq step 1) (repeat {metadata["copy_count"]} '+copy
            body+=f'(setq result (vl-catch-all-apply \'vla-Rotate (list made (vlax-3d-point {lp(base)}) (* step {radians:.12g})))) '
            body+='(if (vl-catch-all-error-p result) (progn (vla-Delete made) (error (vl-catch-all-error-message result)))) '+current_properties_lisp('made',overrides)+'(setq step (1+ step))) '
        else:
            body=f'(setq row 0) (repeat {rows} (setq column 0) (repeat {columns} (if (or (> row 0) (> column 0)) (progn '+copy
            body+=f'(setq result (vl-catch-all-apply \'vla-Move (list made (vlax-3d-point (list 0.0 0.0 0.0)) (vlax-3d-point (list (* column {dx:.12g}) (* row {dy:.12g}) 0.0))))) '
            body+='(if (vl-catch-all-error-p result) (progn (vla-Delete made) (error (vl-catch-all-error-message result)))) '+current_properties_lisp('made',overrides)+')) (setq column (1+ column))) (setq row (1+ row))) '
    return [prefix+body+'(setq i (1+ i)))) )'],metadata
