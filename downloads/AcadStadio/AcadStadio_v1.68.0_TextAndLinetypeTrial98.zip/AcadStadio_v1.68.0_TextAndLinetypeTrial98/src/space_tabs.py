"""Compact drawing-space tabs with a layout creation action beside Model."""
from tkinter import ttk,TclError

class SpaceTabs:
 def __init__(self,canvas):
  self.canvas=canvas;self.active='Model';self.pages={};self.cameras={};self.items=[];self.options={};self.camera_items=None;self.syncing=False;self.identities={}
  style=ttk.Style(canvas);style.configure('Space.TNotebook',borderwidth=0,padding=0)
  style.configure('Space.TNotebook.Tab',padding=(9,2),font=('TkDefaultFont',9))
  style.map('Space.TNotebook.Tab',padding=[('selected',(9,2)),('!selected',(9,2))])
  self.notebook=ttk.Notebook(canvas.master,height=0,style='Space.TNotebook')
  self.notebook.bind('<<NotebookTabChanged>>',self.changed)
  self.notebook.bind('<ButtonRelease-1>',self.reselect)
  self.add_page=None
  if getattr(canvas,'on_create_layout',None):
   self.add_page=ttk.Frame(self.notebook,height=0);self.notebook.add(self.add_page,text='＋',padding=0)
 def set_items(self,items,options,camera_items):
  previous=self.active;self.items=items;self.options=options;self.camera_items=camera_items
  if options.get('recenter'):self.cameras.clear()
  names=list(dict.fromkeys(['Model',*getattr(self.canvas,'known_spaces',[]),*(i.get('cad_space','Model') for i in items)]))
  identities=getattr(self.canvas,'space_ids',{})
  self.syncing=True
  for name in list(self.pages):
   if name not in names:
    same=next((n for n in names if n not in self.pages and self.identities.get(name) and identities.get(n)==self.identities[name]),None)
    if same:
     self.pages[same]=self.pages.pop(name);self.notebook.tab(self.pages[same],text='モデル' if same=='Model' else same)
     if name in self.cameras:self.cameras[same]=self.cameras.pop(name)
     if self.active==name:self.active=same
    else:
     page=self.pages.pop(name);self.notebook.forget(page);page.destroy();self.cameras.pop(name,None)
  for name in names:
   if name not in self.pages:
    page=ttk.Frame(self.notebook,height=0);self.notebook.add(page,text='モデル' if name=='Model' else name,padding=0);self.pages[name]=page
  for i,name in enumerate(names):self.notebook.insert(i+(1 if self.add_page is not None and i>0 else 0),self.pages[name])
  if self.add_page is not None:self.notebook.insert(1,self.add_page)
  if self.active not in self.pages:self.active='Model'
  self.notebook.select(self.pages[self.active]);self.syncing=False;self.identities=dict(identities)
  if self.canvas.winfo_manager()=='pack':self.notebook.pack(fill='x',before=self.canvas)
  self.render(preserve=True)
  if previous!=self.active and getattr(self.canvas,'on_space_changed',None):self.canvas.on_space_changed(self.active)
 def render(self,preserve=False):
  c=self.canvas;items=[i for i in self.items if i.get('cad_space','Model')==self.active];options=dict(self.options)
  if self.active in self.cameras and not preserve:
   c.scale_value,c.offset,c.view_ratio,pan,c._camera_ready=self.cameras[self.active];c.pan=list(pan);options.update(preserve_camera=True,recenter=False)
  elif not preserve:options.update(preserve_camera=False,recenter=True);c._camera_ready=False
  camera=None if self.camera_items is None else [i for i in self.camera_items if i.get('cad_space','Model')==self.active]
  c._space_rendering=True
  try:c.set_items(items,camera_items=camera,**options)
  finally:c._space_rendering=False
 def select_space(self,name):
  if name in self.pages:self.notebook.select(self.pages[name]);self.changed()
 def reselect(self,event):
  try:selected=self.notebook.tabs()[self.notebook.index(f'@{event.x},{event.y}')]
  except (TclError,IndexError):return
  if self.active in self.pages and selected==str(self.pages[self.active]):
   callback=getattr(self.canvas,'on_space_changed',None)
   if callback:callback(self.active)
 def changed(self,event=None):
  if self.syncing:return
  selected=self.notebook.select()
  if self.add_page is not None and selected==str(self.add_page):
   self.syncing=True;self.notebook.select(self.pages[self.active]);self.syncing=False
   self.canvas.after_idle(self.canvas.on_create_layout);return
  name=next((n for n,p in self.pages.items() if str(p)==selected),None)
  if name is None or name==self.active:return
  c=self.canvas;self.cameras[self.active]=(c.scale_value,c.offset,c.view_ratio,list(c.pan),c._camera_ready)
  self.active=name;self.render()
  callback=getattr(c,'on_space_changed',None)
  if callback:callback(name)
