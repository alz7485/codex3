"""Optional block organization metadata, independent of drawing execution order.

The ordered ``blocks`` array remains the source of execution order. Folder IDs
are stable references; names and parent folders can change without touching any
block ID, command, or BLOCK call. Legacy missing membership is assigned to a drawing-space folder on migration.
"""

import copy
import re
import uuid


UNFILED = ""
UNFILED_LABEL = "モデル"
_ID = re.compile(r"[A-Za-z_][A-Za-z_0-9]{0,99}\Z")


def folders(project):
    """Return the stored folder list; older projects behave as an empty list."""
    return project.get("block_folders", [])


def folder(project, identity):
    """Find a real folder by stable ID; the unfiled group is not a folder."""
    result = next((f for f in folders(project) if f.get("id") == identity), None)
    if result is None:
        raise ValueError("フォルダがありません: " + str(identity))
    return result


def validate_folders(project):
    """Validate optional metadata without recursing or modifying the project."""
    items = project.get("block_folders", [])
    if not isinstance(items, list):
        return ["ブロックフォルダは配列で指定してください"]
    errors, by_id, sibling_names = [], {}, set()
    for number, item in enumerate(items, 1):
        location = f"ブロックフォルダ {number}"
        if not isinstance(item, dict):
            errors.append(location + ": 形式が不正です")
            if len(errors) >= 100:
                return errors
            continue
        identity = item.get("id")
        if not isinstance(identity, str) or not _ID.fullmatch(identity) or identity in by_id:
            errors.append(location + ": IDが不正または重複しています")
        else:
            by_id[identity] = item
        name, parent = item.get("name"), item.get("parent_id", "")
        if 'space' in item:
            from cad_setup import cad_name
            space=item['space']
            if not isinstance(space,str) or not cad_name(space) or parent or name!=('モデル' if space=='Model' else space):
                errors.append(location+': 作図空間フォルダの名前・親が不正です')
            elif space.casefold()=='model' and space!='Model':
                errors.append(location+': モデル空間名はModelです')
        if (
            not isinstance(name, str)
            or not name.strip()
            or any(ord(c) < 32 or ord(c) == 127 for c in name)
        ):
            errors.append(location + ": 名前が空欄または不正です")
        elif isinstance(parent, str):
            key = (parent, name.strip().casefold())
            if key in sibling_names:
                errors.append(location + ": 同じ階層に同名のフォルダがあります")
            sibling_names.add(key)
        if not isinstance(parent, str):
            errors.append(location + ": 親フォルダIDは文字列で指定してください")
        if len(errors) >= 100:
            return errors[:100]
    # Stop here if IDs/field types are invalid: following graph edges is unsafe.
    if errors:
        return errors[:100]
    roots=[f for f in items if f.get('space')]
    if roots:
        names=[f['space'].casefold() for f in roots]
        if len(set(names))!=len(names) or names.count('model')!=1:
            return ['モデルフォルダは1つ、レイアウト名は重複なしにしてください']
    for item in items:
        parent = item.get("parent_id", "")
        if parent and parent not in by_id:
            errors.append("親フォルダがありません: " + item["name"])
            if len(errors) >= 100:
                return errors
    if errors:
        return errors[:100]
    # Each node has at most one parent. Completed paths are memoized so a long
    # valid chain is checked in linear time and cannot overflow Python's stack.
    complete = set()
    for identity in by_id:
        path, seen, current = [], set(), identity
        while current and current not in complete:
            if current in seen:
                errors.append("ブロックフォルダの循環参照: " + by_id[current]["name"])
                break
            path.append(current)
            seen.add(current)
            current = by_id[current].get("parent_id", "")
        complete.update(path)
    blocks = project.get("blocks", [])
    # Legacy drawing containers may carry this additive metadata as well.
    if not isinstance(blocks, list):
        blocks = project.get("presets", [])
    if isinstance(blocks, list):
        for number, block in enumerate(blocks, 1):
            if not isinstance(block, dict):
                continue  # The project validator reports the malformed block.
            identity = block.get("folder_id", "")
            if not isinstance(identity, str) or (identity and identity not in by_id):
                errors.append(f"ブロック {number}: 参照先フォルダがありません")
            if len(errors) >= 100:
                break
    return list(dict.fromkeys(errors))[:100]


def _check(project):
    errors = validate_folders(project)
    if errors:
        raise ValueError("\n".join(errors[:12]))


def folder_path(project, identity):
    """Return a readable path, with Model as the legacy empty-ID fallback."""
    if identity == "":
        return UNFILED_LABEL
    by_id = {f["id"]: f for f in folders(project)}
    parts, visited = [], set()
    while identity:
        if identity not in by_id:
            raise ValueError("フォルダがありません: " + str(identity))
        if identity in visited:
            raise ValueError("ブロックフォルダが循環しています")
        visited.add(identity)
        item = by_id[identity]
        parts.append(item["name"])
        identity = item.get("parent_id", "")
    return " / ".join(reversed(parts))


def descendant_ids(project, identity, include_self=True):
    """Return the subtree IDs of a real folder (iteratively)."""
    _check(project)
    folder(project, identity)
    children = {}
    for item in folders(project):
        children.setdefault(item.get("parent_id", ""), []).append(item["id"])
    result, pending = set(), [identity]
    while pending:
        current = pending.pop()
        result.add(current)
        pending.extend(children.get(current, []))
    if not include_self:
        result.discard(identity)
    return result


def create_folder(project, name, parent_id=""):
    """Create a folder after validation and return the stored definition."""
    _check(project)
    if not parent_id and any(f.get('space') for f in folders(project)):
        from space_folders import root_for
        parent_id=root_for(project)['id']
    item = {
        "id": "folder_" + uuid.uuid4().hex,
        "name": name.strip() if isinstance(name, str) else name,
        "parent_id": parent_id,
    }
    trial = dict(project, block_folders=[*folders(project), item])
    _check(trial)
    project.setdefault("block_folders", []).append(item)
    return item


def rename_folder(project, identity, name):
    """Rename without changing membership, descendants, or execution order."""
    _check(project)
    original = folder(project, identity)
    if original.get('space'):
        from space_folders import rename_layout
        trial=rename_layout(project,identity,name);project.clear();project.update(trial)
        return folder(project,identity)
    candidate = copy.deepcopy(folders(project))
    target = next(f for f in candidate if f["id"] == identity)
    target["name"] = name.strip() if isinstance(name, str) else name
    _check(dict(project, block_folders=candidate))
    original["name"] = target["name"]
    return original


def move_folder(project, identity, parent_id=""):
    """Reparent atomically; moving into one's own descendants is rejected."""
    _check(project)
    original = folder(project, identity)
    if original.get('space'):
        raise ValueError('モデル・レイアウトのフォルダは移動できません。')
    moved=[];before=after=None
    if any(f.get('space') for f in folders(project)):
        from space_folders import folder_space,root_for
        parent_id=parent_id or root_for(project)['id']
        before=folder_space(project,identity);after=folder_space(project,parent_id)
        if before!=after:
            members=descendant_ids(project,identity)
            moved=[b for b in project['blocks'] if b.get('folder_id') in members]
    candidate = copy.deepcopy(folders(project))
    target = next(f for f in candidate if f["id"] == identity)
    target["parent_id"] = parent_id
    _check(dict(project, block_folders=candidate))
    original["parent_id"] = parent_id
    from space_folders import _rewrite_space
    for block in moved:
        block['drawing_space']=after
        if before:_rewrite_space(block,before,after)
    return original


def assign_blocks(project, block_ids, folder_id=""):
    """Move selected stable block IDs without replacing or reordering blocks."""
    _check(project)
    managed=any(f.get('space') for f in folders(project))
    if not isinstance(folder_id,str):raise ValueError('フォルダIDは文字列で指定してください')
    if managed and folder_id=='':
        from space_folders import root_for
        folder_id=root_for(project)['id']
    if not isinstance(folder_id, str):
        raise ValueError("フォルダIDは文字列で指定してください")
    if folder_id:
        folder(project, folder_id)
    if isinstance(block_ids, (str, bytes)):
        raise ValueError("ブロックIDは一覧で指定してください")
    try:
        identities = set(block_ids)
    except TypeError as exc:
        raise ValueError("ブロックIDは文字列の一覧で指定してください") from exc
    if any(not isinstance(identity, str) for identity in identities):
        raise ValueError("ブロックIDは文字列で指定してください")
    by_id = {b["id"]: b for b in project["blocks"]}
    if not identities <= by_id.keys():
        raise ValueError("移動するブロックがありません")
    if managed and any(by_id[i].get('guide') for i in identities):raise ValueError('ガイドはフォルダへ移動できません。')
    for identity in identities:
        block = by_id[identity]
        if managed:
            from space_folders import folder_space,_rewrite_space
            old=folder_space(project,block.get('folder_id',''));new=folder_space(project,folder_id)
            if old!=new:
                block['drawing_space']=new
                if old:_rewrite_space(block,old,new)
        if folder_id:
            block["folder_id"] = folder_id
        else:
            block.pop("folder_id", None)


def delete_folder(project, identity):
    """Delete a category subtree and retain its blocks in the drawing-space root."""
    target=folder(project,identity)
    if target.get('space'):
        from space_folders import delete_layout
        identities=descendant_ids(project,identity)
        trial=delete_layout(project,identity);project.clear();project.update(trial)
        return identities
    identities = descendant_ids(project, identity)
    managed=any(f.get('space') for f in folders(project))
    destination=None
    if managed:
        from space_folders import folder_space,root_for
        destination=root_for(project,folder_space(project,identity))['id']
    remaining = [f for f in folders(project) if f["id"] not in identities]
    for block in project["blocks"]:
        if block.get("folder_id", "") in identities:
            if destination:block['folder_id']=destination
            else:block.pop("folder_id", None)
    project["block_folders"] = remaining
    return identities
