import os
import sys
import unittest
from tkinter import ttk
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CompactDetailsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_related_fields_share_rows_and_reflow_without_losing_values(self):
        command=dict(type='LINE',x1='0',y1='0',x2='100',y2='0',layer='OUTLINE',linetype='CENTER',color='1',linetype_scale='@OD/100',condition='@OD > 0')
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.geometry('760x580');self.root.update()
                self.assertIsInstance(win.advanced_section,ttk.LabelFrame)
                self.assertTrue(win.advanced_section.winfo_ismapped())
                self.assertEqual(win.advanced_section.cget('text'),'詳細設定')
                self.assertFalse(any(isinstance(w,ttk.Button) and '詳細設定' in str(w.cget('text'))
                                     for w in gui.descendants(win)))
                rows=win.advanced_rows
                for a,b in [('layer','linetype'),('color','linetype_scale')]:
                    self.assertEqual(rows[a].winfo_rooty(),rows[b].winfo_rooty())
                    self.assertLess(rows[a].winfo_rootx(),rows[b].winfo_rootx())
                    self.assertLess(rows[a].winfo_width(),win.winfo_width()*.6)
                self.assertEqual(rows['condition'].grid_info()['columnspan'],2)
                before={k:win.command_entries[k].get() for k in rows}
                gui.button(win,'列・変数の一覧').invoke();self.root.update()
                self.assertLess(rows['layer'].winfo_rooty(),rows['linetype'].winfo_rooty())
                for key in rows:
                    entry=win.command_entries[key]
                    self.assertGreater(entry.winfo_width(),30)
                    self.assertEqual(entry.get(),before[key])
                gui.button(win,'参照一覧を閉じる').invoke();self.root.update()
                self.assertEqual(rows['layer'].winfo_rooty(),rows['linetype'].winfo_rooty())
                gui.button(win,'コマンドを確定').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,inspect)
        result=edit_command(self.root,command,self.app.data['blocks'],self.app.data)
        for key,value in command.items():self.assertEqual(result[key],value)
