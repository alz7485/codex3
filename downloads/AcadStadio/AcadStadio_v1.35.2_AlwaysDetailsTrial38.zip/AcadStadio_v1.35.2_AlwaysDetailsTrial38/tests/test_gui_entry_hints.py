import copy
import os
import sys
import unittest
from pathlib import Path
from tkinter import ttk
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform == 'win32', 'GUI display unavailable')
class EntryHintsGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_scrollbar_only_appears_for_overflow_and_disappears_after_removing_points(self):
        def inspect():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                self.root.update()
                self.assertFalse(win.command_scrollbar.winfo_ismapped())
                self.root.update()
                self.assertFalse(win.command_scrollbar.winfo_ismapped())
                for _ in range(10):
                    win.add_vertex()
                self.root.update()
                self.assertTrue(win.command_scrollbar.winfo_ismapped())
                win.command_viewport.yview_moveto(1)
                for _ in range(10):
                    win.remove_vertex(1)
                self.root.update()
                self.assertFalse(win.command_scrollbar.winfo_ismapped())
                self.assertEqual(win.command_viewport.yview()[0], 0)
            except Exception as exc:
                self.errors.append(exc)
            finally:
                win.destroy()
        self.root.after(50, inspect)
        edit_command(self.root, dict(type='LINE'), self.app.data['blocks'], self.app.data)

    def test_hints_do_not_become_values_and_follow_typing_clearing_and_focus(self):
        def inspect():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                self.root.update()
                for key in ('layer', 'linetype', 'color', 'linetype_scale', 'condition'):
                    entry = win.command_entries[key]
                    hint = entry.hint_label
                    self.assertEqual(entry.get(), '')
                    self.assertTrue(hint.winfo_ismapped())
                    hint.event_generate('<Button-1>', x=2, y=2)
                    self.root.update()
                    self.assertTrue(hint.winfo_ismapped())
                    self.assertEqual(entry.get(), '')
                    entry.insert(0, '2' if key == 'linetype_scale' else '1')
                    self.root.update()
                    self.assertFalse(hint.winfo_ismapped())
                    entry.delete(0, 'end')
                    self.root.update()
                    self.assertTrue(hint.winfo_ismapped())
                gui.button(win, 'コマンドを確定').invoke()
            except Exception as exc:
                self.errors.append(exc)
                win.destroy()
        original = dict(type='LINE', x1='0', y1='0', x2='100', y2='0',
                        layer='', linetype='', color='', linetype_scale='', condition='')
        self.root.after(50, inspect)
        result = edit_command(self.root, original, self.app.data['blocks'], self.app.data)
        for key in ('layer', 'linetype', 'color', 'linetype_scale', 'condition'):
            self.assertEqual(result[key], '')
        before = copy.deepcopy(self.app.data)
        before['blocks'] = [dict(before['blocks'][0], commands=[original])]
        after = copy.deepcopy(before)
        after['blocks'][0]['commands'] = [result]
        self.assertEqual(compile_project(before, [0]), compile_project(after, [0]))

    def test_style_hints_fit_both_layouts_and_bottom_explanation_is_removed(self):
        for kind, style in [('TEXT', 'text_style'), ('DIMLINEAR', 'dim_style')]:
            def inspect(style=style):
                win = gui.top(self.root, 'コマンドの設定')
                try:
                    for width in (860, 760):
                        win.geometry(f'{width}x640')
                        self.root.update()
                        self.assertEqual(len({e.winfo_height() for e in win.command_entries.values()
                                              if e.winfo_ismapped()}), 1)
                        entry = win.command_entries[style]
                        hint = entry.hint_label
                        self.assertTrue(hint.winfo_ismapped())
                        self.assertLessEqual(hint.winfo_x()+hint.winfo_width(), entry.winfo_width()-18)
                    entry.set('MS明朝 縦')
                    self.root.update()
                    self.assertFalse(hint.winfo_ismapped())
                    self.assertEqual(entry.get(), 'MS明朝 縦')
                    labels = [w for w in gui.descendants(win) if isinstance(w, ttk.Label)]
                    self.assertFalse(any('行指定:' in str(w.cget('text')) for w in labels))
                    result_labels = [w for w in labels if str(w.cget('textvariable')) == str(win.sample_result)]
                    self.assertEqual(len(result_labels), 1)
                    gui.button(win, 'キャンセル').invoke()
                except Exception as exc:
                    self.errors.append(exc)
                    win.destroy()
            self.root.after(50, inspect)
            edit_command(self.root, dict(type=kind), self.app.data['blocks'], self.app.data)
