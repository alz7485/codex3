import copy
import os
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command, command_summary
from engine import compile_project
from tkinter import ttk

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class VertexRowsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_plus_relabels_existing_end_and_saves_continuous_geometry(self):
        for kind in ('LINE','POLYLINE'):
            def inspect():
                win=gui.top(self.root,'コマンドの設定')
                try:
                    self.assertEqual(win.vertex_rows,['始点','終点'])
                    gui.button(win,'点を追加').invoke();self.root.update()
                    self.assertEqual(win.vertex_rows,['始点','中間点1','終点'])
                    self.assertEqual(win.command_entries['x2'].get(),'@X + 100')
                    self.assertEqual(win.command_entries['x3'].get(),'')
                    for key,value in [('x3','@X+100'),('y3','@Y+50')]:
                        e=win.command_entries[key];e.insert(0,value)
                    gui.button(win,'点を追加').invoke();self.root.update()
                    self.assertEqual(win.vertex_rows,['始点','中間点1','中間点2','終点'])
                    for key,value in [('x4','@X+150'),('y4','@Y+50')]:win.command_entries[key].insert(0,value)
                    win.geometry('760x580');self.root.update()
                    self.assertTrue(win.command_entries['x4'].reference_button.winfo_ismapped())
                    gui.button(win,'コマンドを確定').invoke()
                except Exception as exc:self.errors.append(exc);win.destroy()
            self.root.after(50,inspect)
            result=edit_command(self.root,dict(type=kind),self.app.data['blocks'],self.app.data)
            self.assertEqual(len(result['vertices']),4);self.assertNotIn('x3',result)
            summary=command_summary(result)
            self.assertIn('4点:',summary);self.assertNotIn('vertices',summary)
            self.assertNotIn(result['vertices'][0]['id'],summary)
            p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[result])]
            _,items=compile_project(p,[0]);self.assertEqual(items[0]['coords'],(100,100,200,100,200,150,250,150))

    def test_remove_renumbers_without_losing_remaining_coordinates_and_type_drafts(self):
        command=dict(type='LINE',x1='0',y1='0',x2='20',y2='10',vertices=[dict(id='a',x='0',y='0'),dict(id='b',x='10',y='0'),dict(id='c',x='20',y='10')])
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.remove_vertex(1);self.root.update();self.assertEqual(win.vertex_rows,['始点','終点'])
                self.assertEqual(win.command_entries['x2'].get(),'20')
                buttons=[w for w in gui.descendants(win) if isinstance(w,ttk.Button) and w.cget('text')=='点を削除']
                self.assertTrue(all('disabled' in b.state() for b in buttons))
                gui.button(win,'コマンドを確定').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,inspect)
        result=edit_command(self.root,command,self.app.data['blocks'],self.app.data)
        self.assertEqual([p['id'] for p in result['vertices']],['a','c']);self.assertEqual(result['x2'],'20')

    def test_reference_picker_supports_added_endpoint_and_cancel_keeps_original(self):
        source=dict(type='LINE',x1='0',y1='0',x2='100',y2='0')
        original=dict(type='LINE',x1='0',y1='0',x2='10',y2='0')
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.add_vertex();self.root.update();win.choose_command_point('x3');self.root.update()
                dialog=gui.top(self.root,'コマンドの点を選択')
                self.assertIn('始点',dialog.point_preview.points)
                gui.button(dialog,'この点を使用').invoke()
                self.assertIn('点(',win.command_entries['x3'].get())
                gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        before=copy.deepcopy(original);self.root.after(50,inspect)
        self.assertIsNone(edit_command(self.root,original,self.app.data['blocks'],self.app.data,point_sources=[source]))
        self.assertEqual(original,before);self.assertNotIn('point_id',source)
