"""Stable references to previously drawn command geometry across ordered blocks."""
import ast
import copy
import math
import io
import tokenize
import uuid

POINTS = {
    'LINE': ('始点', '中点', '終点'),
    'POLYLINE': ('始点', '中点', '終点'),
    'ARC': ('始点', '中点', '終点', '中心'),
    'CIRCLE': ('中心',), 'ELLIPSE': ('中心',),
    'POINT': ('位置',), 'TEXT': ('挿入点',),
    'RECTANGLE': ('対角点1', '中心', '対角点2'),
}


def new_id():
    return 'p_' + uuid.uuid4().hex


def geometry_points(item):
    c = item['coords']; typ = item['type']
    if typ in ('LINE','POLYLINE'):
        from vertex_points import path_midpoint
        return {'始点': c[:2], '中点': path_midpoint(c,item.get('closed',False)), '終点': c[-2:]}
    if typ == 'RECTANGLE':
        return {'対角点1': c[:2], '中心': ((c[0]+c[2])/2, (c[1]+c[3])/2), '対角点2': c[2:4]}
    if typ == 'ARC':
        result = {'中心': c[:2]}
        for name, fraction in [('始点',0),('中点',.5),('終点',1)]:
            a=math.radians(item['start_angle']+item['sweep']*fraction)
            result[name]=(c[0]+c[2]*math.cos(a),c[1]+c[2]*math.sin(a))
        return result
    name = {'CIRCLE':'中心','ELLIPSE':'中心','POINT':'位置','TEXT':'挿入点'}.get(typ)
    return {name: c[:2]} if name else {}


def reference(identity, point, axis):
    return f'点({identity!r}, {point!r}, {axis!r})'


def clone_commands(commands):
    """Give copied definitions new identities; remap references within the copy."""
    result=copy.deepcopy(commands); mapping={}
    def walk(items):
        for cmd in items:
            yield cmd
            yield from walk(cmd.get('commands',[]))
            yield from walk(cmd.get('else',[]))
    for cmd in walk(result):
        if cmd.get('point_id'):
            old=cmd['point_id'];mapping[old]=new_id();cmd['point_id']=mapping[old]
    return rewrite_references(result, mapping)


def rewrite_references(value, mapping):
    """Change only literal identities inside point functions, even beside @ columns."""
    if isinstance(value,str) and ('点(' in value or '点位置(' in value):
        try:
            tokens=list(tokenize.generate_tokens(io.StringIO(value).readline))
            for i, token in enumerate(tokens[:-2]):
                if token.type == tokenize.NAME and token.string in ('点', '点位置') and tokens[i+1].string == '(' and tokens[i+2].type == tokenize.STRING:
                    identity=ast.literal_eval(tokens[i+2].string)
                    if identity in mapping:
                        tokens[i+2]=tokens[i+2]._replace(string=repr(mapping[identity]))
            return tokenize.untokenize(tokens)
        except (SyntaxError, ValueError, tokenize.TokenError):
            return value
    if isinstance(value,dict):
        literal_fields={"text","layer","linetype","text_style","dim_style","guide_origin"}
        return {k:(v if k in literal_fields and isinstance(v,str) and not v.startswith("=") else rewrite_references(v,mapping)) for k,v in value.items()}
    if isinstance(value,list):return [rewrite_references(v,mapping) for v in value]
    return value
