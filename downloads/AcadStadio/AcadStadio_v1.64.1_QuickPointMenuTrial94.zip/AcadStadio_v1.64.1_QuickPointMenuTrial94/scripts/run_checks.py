"""Reproduce complete core/GUI checks; GUI mode requires an actual display."""
import argparse
import os
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--mode',choices=('core','gui','all'),default='core')
 args=parser.parse_args()
 if args.mode in ('gui','all') and sys.platform!='win32' and not os.environ.get('DISPLAY'):
  parser.error('GUI検証にはDISPLAYを設定してください。表示なしでGUIを合格扱いにはしません。')
 sys.path[:0]=[str(ROOT/'tests'),str(ROOT/'src')]
 suite=unittest.TestSuite()
 for path in sorted((ROOT/'tests').glob('test_*.py')):
  is_gui=path.stem.startswith('test_gui')
  if args.mode=='core' and is_gui or args.mode=='gui' and not is_gui:continue
  suite.addTests(unittest.defaultTestLoader.loadTestsFromName(path.stem))
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 return 0 if result.wasSuccessful() else 1

if __name__=='__main__':raise SystemExit(main())
