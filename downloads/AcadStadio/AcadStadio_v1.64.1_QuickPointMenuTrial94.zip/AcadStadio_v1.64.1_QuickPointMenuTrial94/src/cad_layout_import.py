"""Read paper-space viewports without flattening the displayed model geometry."""
import math

def viewport_commands(entity,reader):
 from cad_drawing_import import number,point_fields
 dxf=entity.dxf
 if int(dxf.get('id',1))==1:return []
 width=float(dxf.get('width',0));height=float(dxf.get('height',0));center=dxf.get('center',(0,0,0))
 if width<=0 or height<=0:reader.note(entity,'ビューポートの幅または高さが0のため未登録');return []
 command=dict(type='VIEWPORT',viewport_action='矩形を作成',x1=number(center[0]-width/2),y1=number(center[1]-height/2),x2=number(center[0]+width/2),y2=number(center[1]+height/2))
 direction=dxf.get('view_direction_vector',(0,0,1));twist=float(dxf.get('view_twist_angle',0));target=dxf.get('view_target_point',(0,0,0));view_height=float(dxf.get('view_height',0))
 top=abs(direction[0])+abs(direction[1])<1e-8 and direction[2]>0 and abs(twist%360)<1e-8 and abs(target[2])<1e-8
 if top and view_height>0:
  view=dxf.get('view_center_point',(0,0));command.update(configure_view=True,view_x=number(target[0]+view[0]),view_y=number(target[1]+view[1]),view_scale=number(height/view_height),viewport_locked=bool(int(dxf.get('flags',0)) & 16384))
 else:reader.note(entity,'ビューポート枠のみ読込：傾いた視線・ねじれ・3D投影は未対応です')
 if dxf.get('clipping_boundary_handle',''):reader.note(entity,'非矩形クリップは未対応のため矩形の枠を使用します')
 if int(dxf.get('status',1))<=0:reader.note(entity,'ビューポートの非表示状態は再現せず、作成後は表示します')
 reader.total+=2
 props=reader.properties(entity)
 return [dict(type='APPEARANCE',**props),command]
