"""A tab strip above an existing canvas, retaining camera state per space."""
from tkinter import ttk

class SpaceTabs:
 def __init__(self,canvas):
  self.canvas=canvas;self.active='Model';self.pages={};self.cameras={};self.items=[];self.options={};self.camera_items=None;self.syncing=False
  self.notebook=ttk.Notebook(canvas.master,height=0)
  self.notebook.bind('<<NotebookTabChanged>>',self.changed)
 def set_items(self,items,options,camera_items):
  previous=self.active
  self.items=items;self.options=options;self.camera_items=camera_items
  if options.get("recenter"):self.cameras.clear()
  names=list(dict.fromkeys(['Model',*getattr(self.canvas,'known_spaces',[]),*(i.get('cad_space','Model') for i in items)]))
  self.syncing=True
  for name in list(self.pages):
   if name not in names:
    page=self.pages.pop(name);self.notebook.forget(page);page.destroy();self.cameras.pop(name,None)
  for name in names:
   if name not in self.pages:
    page=ttk.Frame(self.notebook,height=0);self.notebook.add(page,text='モデル' if name=='Model' else name);self.pages[name]=page
  if self.active not in self.pages:self.active='Model'
  self.notebook.select(self.pages[self.active]);self.syncing=False
  if self.canvas.winfo_manager()=='pack':self.notebook.pack(fill='x',before=self.canvas)
  self.render(preserve=True)
  if previous!=self.active and getattr(self.canvas,"on_space_changed",None):self.canvas.on_space_changed(self.active)
 def render(self,preserve=False):
  c=self.canvas;items=[i for i in self.items if i.get('cad_space','Model')==self.active]
  options=dict(self.options)
  if self.active in self.cameras and not preserve:
   c.scale_value,c.offset,c.view_ratio,pan,c._camera_ready=self.cameras[self.active];c.pan=list(pan)
   options.update(preserve_camera=True,recenter=False)
  elif not preserve:options.update(preserve_camera=False,recenter=True);c._camera_ready=False
  camera=None if self.camera_items is None else [i for i in self.camera_items if i.get('cad_space','Model')==self.active]
  c._space_rendering=True
  try:c.set_items(items,camera_items=camera,**options)
  finally:c._space_rendering=False
 def changed(self,event=None):
  if self.syncing:return
  selected=self.notebook.select();name=next((n for n,p in self.pages.items() if str(p)==selected),None)
  if name is None or name==self.active:return
  c=self.canvas;self.cameras[self.active]=(c.scale_value,c.offset,c.view_ratio,list(c.pan),c._camera_ready)
  self.active=name;self.render()
  callback=getattr(c,'on_space_changed',None)
  if callback:callback(name)
