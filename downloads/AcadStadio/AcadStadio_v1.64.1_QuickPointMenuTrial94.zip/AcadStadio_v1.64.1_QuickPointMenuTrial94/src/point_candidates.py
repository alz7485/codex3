"""Hit-test stable reference points and supported finite two-source intersections."""
from itertools import combinations
from command_points import geometry_points
from derived_points import intersection_candidates

def candidates_at(items,source_index,labels,screen,click,radius=10):
    def near(point):
        x,y=screen(point);return (x-click[0])**2+(y-click[1])**2<=radius*radius
    names={'LINE':'線分','POLYLINE':'ポリライン','CIRCLE':'円','ARC':'円弧','RECTANGLE':'長方形','ELLIPSE':'楕円','TEXT':'文字','MTEXT':'マルチテキスト','POINT':'点','CHAMFER':'面取り','FILLET':'角丸め','SPLINE':'スプライン','INSERT':'挿入'}
    def label(index,item):return labels[index]+'（'+names.get(item['type'],item['type'])+'）'
    sources={};result=[]
    for item in items:
        index=source_index(item)
        if index not in labels or item.get('operation_deleted'):continue
        sources.setdefault(index,[]).append(item)
    for index,figures in sources.items():
        # Repeated instances cannot be expressed by one command reference.
        if len(figures)!=1:continue
        try:points=geometry_points(figures[0])
        except (ValueError,KeyError,TypeError):continue
        seen=set()
        for name,point in points.items():
            if name=='角度指定点' or not near(point):continue
            # Aliases such as rectangle corner/diagonal refer to the same point.
            key=tuple(round(v,10) for v in point)
            if key in seen:continue
            seen.add(key)
            result.append(dict(kind='point',primary=index,point=name,position=point,label=label(index,figures[0])+'・'+name))
    def shape(item):
        kind=item.get('display_type',item['type']);p=geometry_points(item)
        if kind=='CIRCLE':return 'C',(p['中心'],p['右'])
        if kind in ('LINE','POLYLINE') and len(item['coords'])==4:return 'L',(p['始点'],p['終点'])
        return None
    shapes=[]
    for index,figures in sources.items():
        if len(figures)!=1:continue
        try:resolved=shape(figures[0])
        except (ValueError,KeyError,TypeError):continue
        if resolved:
            kind,(a,b)=resolved;ax,ay=screen(a);bx,by=screen(b);cx,cy=click
            if kind=='C':
                import math
                distance=abs(math.hypot(cx-ax,cy-ay)-math.hypot(bx-ax,by-ay))
            else:
                dx,dy=bx-ax,by-ay;length=dx*dx+dy*dy
                t=max(0,min(1,((cx-ax)*dx+(cy-ay)*dy)/length)) if length else 0
                distance=((cx-ax-t*dx)**2+(cy-ay-t*dy)**2)**.5
            if distance<=radius:shapes.append((index,*resolved))
    if len(shapes)>64:raise ValueError('候補が多いため、プレビューを拡大して点を選び直してください。')
    for first,second in combinations(shapes,2):
        a,ka,pa=first;b,kb,pb=second
        try:points=intersection_candidates(ka+kb,*pa,*pb)
        except ValueError:continue
        seen=set()
        for branch,point in points.items():
            if not near(point):continue
            key=tuple(round(v,10) for v in point)
            if key in seen:continue
            seen.add(key)
            result.append(dict(kind='intersection',primary=a,secondary=b,point=branch,position=point,label=label(a,sources[a][0])+' × '+label(b,sources[b][0])+'・交点'))
    if result:
        def distance(candidate):
            x,y=screen(candidate['position']);return ((x-click[0])**2+(y-click[1])**2)**.5
        closest=min(map(distance,result))
        result=[candidate for candidate in result if distance(candidate)<=closest+min(2,radius*.2)]
    return result
