"""Native menu-style point choices with hover preview and one-click acceptance."""
import tkinter as tk
from command_points import geometry_points


class PointCandidatePopup(tk.Menu):
    def __init__(self,canvas,candidates,event,on_use):
        self.owner=canvas.winfo_toplevel()
        super().__init__(self.owner,tearoff=False)
        self.canvas=canvas;self.candidates=candidates;self.closed=False;self._dismiss_job=None
        self.previous_grab=self.grab_current()
        self.old_source=canvas.source_index;self.old_related=set(getattr(canvas,'related_source_indices',set()))
        self.old_points=dict(canvas.snap_points);self.old_point=canvas.selected_point;self.old_shift=canvas.shifted_point
        for index,item in enumerate(candidates):
            prefix='交点：' if item['kind']=='intersection' else '点：'
            label=item['label'].removesuffix('・交点') if item['kind']=='intersection' else item['label']
            self.add_command(label=prefix+label,command=lambda index=index:self.use(index,on_use))
        self.bind('<<MenuSelect>>',self.preview)
        self.bind('<Escape>',lambda event:(self.close(),'break')[-1])
        self.bind('<Unmap>',self.dismissed)
        self.bind('<Destroy>',self.destroyed)
        self.tk_popup(event.x_root,event.y_root)

    def preview(self,event=None):
        if self.closed:return
        index=self.index('active')
        if index is None:return
        candidate=self.candidates[int(index)];canvas=self.canvas
        canvas.source_index=candidate['primary']
        canvas.related_source_indices={candidate['secondary']} if candidate['kind']=='intersection' else set()
        primary=next((i for i in canvas.items if canvas.item_source_index(i)==candidate['primary']),None)
        canvas.snap_points={'交点':candidate['position']} if candidate['kind']=='intersection' else geometry_points(primary) if primary else {}
        canvas.selected_point='交点' if candidate['kind']=='intersection' else candidate['point'];canvas.shifted_point=None
        canvas.recolor()

    def dismissed(self,event=None):
        if not self.closed and self._dismiss_job is None:
            self._dismiss_job=self.owner.after_idle(self.close)

    def destroyed(self,event):
        if event.widget is not self:return
        self.closed=True
        if self._dismiss_job is not None:
            try:self.owner.after_cancel(self._dismiss_job)
            except tk.TclError:pass
            self._dismiss_job=None

    def use(self,index,on_use):
        candidate=self.candidates[index]
        self.close()
        on_use(candidate)

    def close(self):
        if self.closed:return
        self.closed=True
        if self._dismiss_job is not None:
            self.owner.after_cancel(self._dismiss_job);self._dismiss_job=None
        try:
            canvas=self.canvas
            canvas.source_index=self.old_source;canvas.related_source_indices=self.old_related
            canvas.snap_points=self.old_points;canvas.selected_point=self.old_point;canvas.shifted_point=self.old_shift;canvas.recolor()
            self.unpost();self.grab_release();self.destroy()
            if self.previous_grab is not None and self.previous_grab.winfo_exists():self.previous_grab.grab_set()
        except tk.TclError:pass
