"""Clickable point markers on a compiler-backed preview; never writes project data."""
import copy
import tkinter as tk
from tkinter import ttk
from command_points import geometry_points, rotated_circle_point
from engine import compile_project, MacroError
from expression_sample import sample_value
from project_data import get_rows
from preview import DrawingCanvas


class PointCanvas(DrawingCanvas):
    def __init__(self, parent, on_pick, on_source=None):
        self.snap_points = {}; self.selected_point = None; self.shifted_point = None
        self.on_pick = on_pick
        self.on_source = on_source
        self.source_index = None
        self.source_labels = {}
        self.source_map = None
        super().__init__(parent, width=340, height=260, space_tabs=True)
        self.bind('<ButtonPress-1>', self.press, add='+')
        self.bind('<ButtonRelease-1>', self.pick, add='+')

    def item_source_index(self, item):
        if self.source_map is None:
            return item.get("command_index")
        return self.source_map.get((item.get("block_index",item.get("preset_index",0)),item.get("command_index")))

    def display_color(self, item, fallback):
        if getattr(self,'selection_active',False):
            logical=item.get('_logical_parent',item)
            if id(logical) in getattr(self,'selected_entity_ids',set()):return super().display_color(item,fallback)
        if "command_index" in item and self.item_source_index(item) not in {self.source_index,*getattr(self,'related_source_indices',set())}:
            return "#34465c"
        return super().display_color(item, fallback)

    def screen_point(self, point):
        w,h=self.winfo_width(),self.winfo_height()
        bx=self._base_offset[0]+point[0]*self._base_scale
        by=self._base_offset[1]-point[1]*self._base_scale
        return (w/2+(bx-w/2)*self.view_ratio+self.pan[0], h/2+(by-h/2)*self.view_ratio+self.pan[1])

    def draw_markers(self):
        self.delete('snap_overlay')
        if self.space_tabs is not None and self.source_index is not None and not any(self.item_source_index(i)==self.source_index for i in self.items):return
        if not hasattr(self,'_base_offset'):return
        for name,position in self.snap_points.items():
            x,y=self.screen_point(position);selected=name==self.selected_point
            color='#fbbf24' if selected else '#f8fafc'
            self.create_oval(x-6,y-6,x+6,y+6,fill=color,outline='#101d30',width=2,tags='snap_overlay')
            right=x>self.winfo_width()/2
            if len(self.snap_points)<=40 or selected:
                self.create_text(x-9 if right else x+9,y-13,text=name,fill=color,anchor='e' if right else 'w',tags='snap_overlay')
        if self.shifted_point is not None:
            x,y=self.screen_point(self.shifted_point)
            self.create_line(x-9,y,x+9,y,fill='#fb7185',width=2,tags='snap_overlay')
            self.create_line(x,y-9,x,y+9,fill='#fb7185',width=2,tags='snap_overlay')
            self.create_text(x+10,y+14,text=getattr(self,'shifted_label','移動後'),anchor='w',fill='#fb7185',tags='snap_overlay')

    def bounds(self, items=None):
        if items is None:
            items = self.items + ([dict(type="POINT", coords=self.shifted_point)] if self.shifted_point is not None else [])
            box=getattr(self,"range_box",None)
            items += [dict(type="POINT",coords=p) for p in getattr(self,"reference_bounds",[])]
            if box:items += [dict(type="POINT",coords=box[:2]),dict(type="POINT",coords=box[2:])]
        return super().bounds(items)

    def begin_range(self,callback,mode='window'):
        self._range_previous_box=getattr(self,'range_box',None)
        self.range_callback=callback;self.range_mode=mode;self._range_start=None
        self.configure(cursor='crosshair')
    def begin_point_selection(self,callback):
        self.point_callback=callback;self.range_callback=None;self.configure(cursor='crosshair')
    def cancel_range(self,restore=True):
        if restore and getattr(self,'range_callback',None):self.range_box=getattr(self,'_range_previous_box',None)
        self.range_callback=None;self.point_callback=None;self._range_start=None;self.configure(cursor='');self.draw_range()
    def world_point(self,x,y):
        w,h=self.winfo_width(),self.winfo_height()
        px=(x-w/2-self.pan[0])/self.view_ratio+w/2
        py=(y-h/2-self.pan[1])/self.view_ratio+h/2
        return ((px-self._base_offset[0])/self._base_scale,(self._base_offset[1]-py)/self._base_scale)
    def draw_range(self):
        self.delete('range-overlay')
        box=getattr(self,'range_box',None)
        boxes=list(getattr(self,'selection_rectangles',None) or [])
        if box and (getattr(self,'range_callback',None) or getattr(self,'selection_rectangles',None) is None):
            candidate=(box,getattr(self,'range_mode','window'))
            if candidate not in boxes:boxes.append(candidate)
        if hasattr(self,'_base_offset'):
            for rectangle,mode in boxes:
                self.create_rectangle(*self.screen_point(rectangle[:2]),*self.screen_point(rectangle[2:]),outline='#34d399' if mode=='crossing' else '#60a5fa',width=2,dash=(5,3) if mode=='crossing' else (),tags='range-overlay')
            for segment in getattr(self,'selected_segments',[]):
                self.create_line(*self.screen_point(segment[:2]),*self.screen_point(segment[2:]),fill='#e2e8f0',width=2,tags='range-overlay')
            for position in getattr(self,'selection_points',[]):
                x,y=self.screen_point(position);self.create_oval(x-4,y-4,x+4,y+4,outline='#60a5fa',width=2,tags='range-overlay')
    def fit(self, **kwargs):
        super().fit(**kwargs);self.draw_markers();self.draw_range()
    def zoom(self,event,factor=None):
        if getattr(self,"range_callback",None):return
        super().zoom(event,factor);self.draw_markers();self.draw_range()
    def drag(self,event):
        if getattr(self,'point_callback',None):return 'break'
        if getattr(self,'range_callback',None) and getattr(self,'_range_start',None):
            self.range_box=(*self._range_start,*self.world_point(event.x,event.y));self.draw_range();return 'break'
        super().drag(event);self.draw_markers();self.draw_range()
    def press(self,event):
        self._snap_press=(event.x,event.y)
        if getattr(self,'range_callback',None):self._range_start=self.world_point(event.x,event.y)
    def pick(self,event):
        if getattr(self,'point_callback',None):
            from selection_sets import DXF_TYPES
            under=set(self.find_overlapping(event.x-4,event.y-4,event.x+4,event.y+4));candidates=[];seen=set()
            for node,drawn,_ in self.geometry:
                item=drawn.get('_logical_parent',drawn)
                if node in under and not item.get('guide') and item.get('display_type',item['type']) in DXF_TYPES and id(item) not in seen:
                    candidates.append(item);seen.add(id(item))
            for item in self.items:
                if item.get('display_type',item['type']) in ('CIRCLE','ARC','ELLIPSE','TEXT','MTEXT','POINT','INSERT') and not item.get('guide'):
                    x,y=self.screen_point(item['coords'][:2])
                    if (x-event.x)**2+(y-event.y)**2<=64 and id(item) not in seen:candidates.append(item);seen.add(id(item))
            position=self.world_point(event.x,event.y);callback=self.point_callback
            if len(candidates)==1:callback(position,candidates[0])
            elif candidates:
                menu=tk.Menu(self,tearoff=False)
                for item in candidates:menu.add_command(label=item.get('display_type',item['type'])+f" / コマンド{item.get('command_index',0)+1}",command=lambda s=item:callback(position,s))
                menu.tk_popup(event.x_root,event.y_root)
            return 'break'
        if getattr(self,'range_callback' ,None):
            start=getattr(self,'_range_start',None)
            if start:
                end=self.world_point(event.x,event.y)
                if abs(start[0]-end[0])>1e-9 and abs(start[1]-end[1])>1e-9:
                    callback=self.range_callback;self.range_box=(*start,*end);self.cancel_range(restore=False);self.draw_range();callback(start,end)
            return 'break'
        press=getattr(self,'_snap_press',(event.x,event.y))
        if (press[0]-event.x)**2+(press[1]-event.y)**2>16:return
        callback=getattr(self,'on_reference_candidate',None)
        if callback is not None:
            from point_candidates import candidates_at
            eligible=getattr(self,'reference_candidate_indices',set(self.source_labels))
            labels={i:label for i,label in self.source_labels.items() if i in eligible}
            try:choices=candidates_at(self.items,self.item_source_index,labels,self.screen_point,(event.x,event.y))
            except ValueError as exc:
                status=getattr(self,'on_reference_error',None)
                if status:status(str(exc))
                return 'break'
            if len(choices)==1:
                callback(choices[0]);return 'break'
            if choices:
                from point_candidate_popup import PointCandidatePopup
                previous=getattr(self,'candidate_popup',None)
                if previous is not None and previous.winfo_exists():previous.close()
                self.candidate_popup=PointCandidatePopup(self,choices,event,callback)
                return 'break'
        hits=[]
        for name,point in self.snap_points.items():
            x,y=self.screen_point(point)
            if (x-event.x)**2+(y-event.y)**2<=144:hits.append(name)
        if len(hits)==1:self.on_pick(hits[0])
        elif hits:
            menu=tk.Menu(self,tearoff=False)
            for name in hits:menu.add_command(label=name,command=lambda n=name:self.on_pick(n))
            menu.tk_popup(event.x_root,event.y_root)
        else:
            under=set(self.find_overlapping(event.x-5,event.y-5,event.x+5,event.y+5))
            indices=sorted({self.item_source_index(item) for node,item,_ in self.geometry if node in under and self.item_source_index(item) in self.source_labels})
            if len(indices)==1 and self.on_source:
                self.on_source(indices[0])
            elif indices:
                menu=tk.Menu(self,tearoff=False)
                for index in indices:
                    menu.add_command(label=self.source_labels[index],command=lambda i=index:self.on_source(i))
                menu.tk_popup(event.x_root,event.y_root)
            elif any(node in under for node, item, color in self.geometry) and hasattr(self, "on_unavailable"):
                self.on_unavailable()


class PointReferencePreview(ttk.Frame):
    def __init__(self,parent,project,commands,on_pick,initial_row=0,local_values=None, *, preview_commands=None, on_source=None, preview_blocks=None, source_refs=None, compact=False, repeat_counts=()):
        super().__init__(parent)
        self.project=project;self.commands=commands;self.local_values=local_values
        self.preview_commands=preview_commands;self.warning=""
        self.preview_blocks=preview_blocks;self.source_refs=source_refs
        self.repeat_counts=tuple(repeat_counts)
        self.on_pick=on_pick;self.source_index=0;self.point_name='';self.axis='X';self.shifts={}
        self.status=tk.StringVar();self.row=tk.StringVar(value=str(initial_row+1))
        self.compact=compact
        self.status_visible=True
        self.canvas=PointCanvas(self,on_pick,on_source);self.canvas.pack(fill='both',expand=True)
        self.canvas.set_color_resources(project)
        bar=ttk.Frame(self.canvas if compact else self)
        if compact:bar.place(relx=1,x=-10,y=10,anchor='ne')
        else:bar.pack(fill='x',before=self.canvas,pady=(0,6))
        ttk.Label(bar,text='確認行 / 繰り返し1回目' if self.repeat_counts else '確認行').pack(side='left')
        rows=get_rows(project)
        choice=ttk.Combobox(bar,textvariable=self.row,values=[str(i+1) for i in range(len(rows))],state='readonly',width=5)
        choice.pack(side='left',padx=6);choice.bind('<<ComboboxSelected>>',lambda e:self.load(self.source_index))
        title=tk.StringVar()
        def row_title(*_):
            try:
                row=rows[int(self.row.get())-1];title.set(str(next(iter(row.values()),'')))
            except (ValueError,IndexError):title.set('')
        self.row.trace_add('write',row_title);row_title()
        if compact:
            ttk.Label(bar,textvariable=title).pack(side='left',padx=5)
            tools=ttk.Frame(self.canvas,style='Preview.TFrame',padding=4)
            tools.place(relx=1,rely=1,x=-8,y=-8,anchor='se')
            fit_button=ttk.Button(tools,text='全体を表示',command=lambda:self.canvas.fit(),style='Preview.Primary.TButton')
            fit_button.icon_only=False;fit_button.pack(side='left')
            self.canvas.make_color_toggle(tools).pack(side='left',padx=(4,0))
        else:ttk.Button(bar,text='全体を表示',command=lambda:self.canvas.fit()).pack(side='right')
        self.canvas.on_unavailable=lambda:self.status.set('この図形は参照元に選べません。編集中コマンドは表示のみです。')
        if not compact:
            ttk.Label(self,text='図形または一覧で参照元を選択 → 白い点をクリック。',style='Muted.TLabel',wraplength=360).pack(fill='x',pady=6)
        status_label=ttk.Label(self.canvas if compact else self,textvariable=self.status,wraplength=500,style='Muted.TLabel')
        if compact:status_label.configure(background='#101d30',foreground='#91a5bf')
        if compact:
            def status_changed(*_):
                if self.status.get() and self.status_visible:status_label.place(x=12,rely=1,y=-44,anchor='sw')
                else:status_label.place_forget()
            self.status.trace_add('write',status_changed)
        else:status_label.pack(fill='x')
        self.points={}

    def load(self,index):
        self.source_index=index;self.points={};self.canvas.snap_points={};self.canvas.shifted_point=None
        self.appearance_state={}
        self.canvas.source_index=index
        if self.source_refs is not None:
            self.canvas.source_labels={i:descriptor["label"] for i,descriptor in enumerate(self.source_refs)}
            self.canvas.source_map={(d["block_index"],d["command_index"]):i for i,d in enumerate(self.source_refs)}
        else:
            self.canvas.source_labels={i:f"{i+1}: {command.get('type','')}" for i,command in enumerate(self.commands) if command.get('type') in ('LINE','POLYLINE','ARC','CIRCLE','ELLIPSE','RECTANGLE','TEXT','POINT','SPLINE','HATCH','INSERT','LEADER','OFFSET','COPY','MIRROR','CHAMFER','FILLET','MTEXT','CADBLOCK')}
            self.canvas.source_map=None
        self.warning=""
        try:
            probe=copy.deepcopy(self.project)
            if self.preview_blocks:
                blocks=copy.deepcopy(self.preview_blocks())
            else:
                commands=copy.deepcopy(self.preview_commands() if self.preview_commands else self.commands)
                blocks=[dict(id='point_preview',name='点の確認',commands=commands)]
            def compile_scene(sequence):
                probe['blocks']=sequence
                return compile_project(probe,[int(self.row.get())-1],validate=False,preview_repeat_counts=self.repeat_counts,appearance_out=self.appearance_state)[1]
            try:
                items=compile_scene(blocks)
            except MacroError as exc:
                path=str(exc.location.get('command_path',''))
                try:
                    stop=int(path.split('/')[0])-1
                    block_index=int(exc.location.get('block_index',exc.location.get('preset_index',0)) or 0)
                except (ValueError,TypeError):raise exc
                if stop <= 0 and block_index == 0:raise exc
                partial=copy.deepcopy(blocks[:block_index+1])
                partial[-1]['commands']=partial[-1]['commands'][:stop]
                items=compile_scene(partial)
                self.warning=f"{blocks[block_index]['name']} / コマンド{stop+1}以降は未表示（入力を確認）"
            source=next((item for item in reversed(items) if self.canvas.item_source_index(item)==index),None)
            # Keep the complete scene even when the chosen source is absent in this row.
            self.canvas.set_items(items,preserve_camera=bool(self.canvas.items) and getattr(self,'_loaded_row',None)==self.row.get())
            self._loaded_row=self.row.get()
            if source is not None and self.canvas.space_tabs is not None:
                tabs=self.canvas.space_tabs;destination=source.get('cad_space','Model')
                if destination in tabs.pages and tabs.active!=destination:
                    tabs.notebook.select(tabs.pages[destination]);tabs.changed()
            if source is None:
                self.status.set('この行では参照元が作図されません。条件や確認行を確認してください。')
                return
            self.points=geometry_points(source)
            self.canvas.snap_points=self.points
            self.update_selection(self.point_name,self.axis,self.shifts,getattr(self,'angle',None))
        except (MacroError,ValueError,KeyError,TypeError) as exc:
            self.canvas.set_items([],message='この行のプレビューを表示できません',preserve_camera=self.canvas._camera_ready)
            self.status.set(str(exc))

    def update_selection(self,name,axis,shifts,angle=None):
        self.point_name=name;self.axis=axis;self.shifts=shifts
        self.angle=angle
        self.canvas.selected_point=name;self.canvas.shifted_point=None
        if name in self.points:
            try:
                x,y=self.points[name];dx=dy=0
                if angle is not None:
                    degrees=sample_value(self.project,angle or '0',int(self.row.get())-1,self.local_values,repeat_counts=self.repeat_counts)
                    x,y=rotated_circle_point(self.points,name,degrees)
                for key,expression in shifts.items():
                    value=sample_value(self.project,expression or '0',int(self.row.get())-1,self.local_values,repeat_counts=self.repeat_counts)
                    if type(value) not in (int,float):raise ValueError('移動量は数値で指定してください')
                    if key=='X' or (key=='value' and axis=='X'):dx=value
                    else:dy=value
                self.canvas.shifted_point=(x+dx,y+dy)
                output=f'{x+dx:.12g}, {y+dy:.12g}' if axis is None else f'{(x+dx) if axis=="X" else (y+dy):.12g}'
                self.status.set(f'{name}：X={x:.12g} / Y={y:.12g}\n取得値：{output}'+('（'+axis+'のみ）' if axis else '')+('\n'+self.warning if self.warning else ''))
            except (MacroError,ValueError,KeyError,TypeError) as exc:self.status.set(str(exc))
        self.canvas._camera_items = self.canvas.items + ([dict(type="POINT", coords=self.canvas.shifted_point)] if self.canvas.shifted_point is not None else [])
        self.canvas.draw_markers()
