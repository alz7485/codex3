"""Grouped edits to layer definitions, distinct from current entity properties."""
from cad_setup import cad_name
from extended_commands import quoted
from advanced_commands import text_value

FIELDS=[('target_layer','0'),('layer_color',''),('layer_linetype',''),('layer_weight',''),('layer_plot',''),('layer_on',''),('layer_frozen',''),('layer_locked',''),('layer_transparency',''),('layer_description',''),('new_layer_name',''),('execution','per_row')]
LABELS={'target_layer':'対象レイヤー','layer_color':'色（ACI）','layer_linetype':'線種','layer_weight':'線の太さ','layer_plot':'印刷','layer_on':'表示','layer_frozen':'フリーズ','layer_locked':'ロック','layer_transparency':'透明度（0〜90）','layer_description':'説明','new_layer_name':'変更後の名前'}
CHOICES={'layer_plot':('','印刷する','印刷しない'),'layer_on':('','表示','非表示'),'layer_frozen':('','フリーズ','解除'),'layer_locked':('','ロック','解除')}

def render(command,values,number):
 target=text_value(command.get('target_layer',''),values)
 if not cad_name(target):raise ValueError('対象レイヤー名を入力してください')
 props={}
 def raw(key):return str(command.get(key,'')).strip()
 def numeric(key):return float(number(weight_value(command[key]) if key=='layer_weight' else command[key],values))
 if raw('layer_color'):
  color=numeric('layer_color')
  if not color.is_integer() or not 1<=color<=255:raise ValueError('レイヤーの色はACI 1〜255で指定してください')
  props['color']=int(color)
 if raw('layer_linetype'):
  line=text_value(command['layer_linetype'],values)
  if not cad_name(line) or line.upper() in ('BYLAYER','BYBLOCK'):raise ValueError('読み込み済みの線種名を指定してください')
  props['linetype']=line
 if raw('layer_weight'):
  from dwg_resources import LINEWEIGHTS
  weight=numeric('layer_weight')
  if weight not in LINEWEIGHTS|{-3}:raise ValueError('レイヤーの線の太さが不正です（既定は-3）')
  props['lineweight']=int(weight)
 if raw('layer_transparency'):
  transparency=numeric('layer_transparency')
  if not transparency.is_integer() or not 0<=transparency<=90:raise ValueError('透明度は0〜90の整数で指定してください')
  props['transparency']=int(transparency)
 for key,choices in CHOICES.items():
  value=raw(key)
  if value not in choices:raise ValueError(LABELS[key]+'を選択してください')
  if value:props[key]=value==choices[1]
 if raw('layer_description'):
  description=text_value(command['layer_description'],values)
  if len(description)>200 or any(ord(c)<32 for c in description):raise ValueError('説明は改行なしの200文字以内です')
  props['description']=description
 renamed=text_value(command.get('new_layer_name',''),values)
 if renamed:
  if not cad_name(renamed) or target.casefold() in ('0','defpoints') or renamed.casefold() in ('0','defpoints'):raise ValueError('このレイヤー名には変更できません')
  props['rename']=renamed
 body=f'(setq en (tblobjname "LAYER" {quoted(target)})) (if (not en) (error "AcadStadio: Layer does not exist")) (setq data (entget en)) '
 body+='(setq put \'(lambda (code value / p) (setq p (assoc code data)) (setq data (if p (subst (cons code value) p data) (append data (list (cons code value))))))) '
 if 'linetype' in props:body+=f'(if (not (tblsearch "LTYPE" {quoted(props["linetype"])})) (error "AcadStadio: Load linetype in CAD settings first")) '
 if props.get('layer_frozen'):body+=f'(if (= (strcase (getvar "CLAYER")) (strcase {quoted(target)})) (error "AcadStadio: Cannot freeze current layer")) '
 if renamed:body+=f'(if (tblsearch "LAYER" {quoted(renamed)}) (error "AcadStadio: Layer name already exists")) '
 if 'color' in props:
  body+='(setq data (vl-remove-if \'(lambda (p) (member (car p) \'(420 430))) data)) '
 if 'color' in props or 'layer_on' in props:
  body+=f'(setq aci {props["color"]}) ' if 'color' in props else '(setq aci (abs (cdr (assoc 62 data)))) '
  sign='1' if props.get('layer_on') is True else '-1' if props.get('layer_on') is False else '(if (< (cdr (assoc 62 data)) 0) -1 1)'
  body+=f'(apply put (list 62 (* aci {sign}))) '
 for key,code in [('linetype',6),('lineweight',370),('layer_plot',290),('transparency',440)]:
  if key not in props:continue
  value=quoted(props[key]) if key=='linetype' else ('1' if props[key] else '0') if key=='layer_plot' else str(33554432+round(255*(100-props[key])/100)) if key=='transparency' else str(props[key])
  body+=f'(apply put (list {code} {value})) '
 for key,bit in [('layer_frozen',1),('layer_locked',4)]:
  if key in props:body+=f'(apply put (list 70 (boole {7 if props[key] else 1} (cdr (assoc 70 data)) {bit if props[key] else -1-bit}))) '
 body+='(if (not (entmod data)) (error "AcadStadio: Cannot update layer")) '
 if 'description' in props:body+=f'(vl-load-com) (vla-put-Description (vlax-ename->vla-object en) {quoted(props["description"])}) '
 if renamed:body+=f'(command-s "_.-RENAME" "_Layer" {quoted(target)} {quoted(renamed)}) '
 if renamed:
  body+='(if (and (boundp \'*cadflow-state*) *cadflow-state*) (progn (setq saved (cdr (assoc \'vars *cadflow-state*))) '
  body+='(foreach key \'("CLAYER" "DIMLAYER" "HPLAYER") (if (and (setq pair (assoc key saved)) '
  body+=f'(= (strcase (cdr pair)) (strcase {quoted(target)}))) (setq saved (subst (cons key {quoted(renamed)}) pair saved)))) '
  body+='(setq *cadflow-state* (subst (cons \'vars saved) (assoc \'vars *cadflow-state*) *cadflow-state*)))) '
 return ['((lambda (/ en data put aci saved key pair) '+body+' (princ)))'],target,props

WEIGHTS={'既定（LWDEFAULT）':'-3',**{f'{v/100:.2f} mm':str(v) for v in (0,5,9,13,15,18,20,25,30,35,40,50,53,60,70,80,90,100,106,120,140,158,200,211)}}
def weight_value(value):return WEIGHTS.get(str(value),str(value))
