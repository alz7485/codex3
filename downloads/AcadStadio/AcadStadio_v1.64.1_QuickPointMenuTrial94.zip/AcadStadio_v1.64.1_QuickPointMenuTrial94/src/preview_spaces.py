"""Track the explicit drawing destination without projecting viewport contents."""
def update_space(command,state,values,number):
 from advanced_commands import text_value
 kind=command['type']
 if kind=='SPACE':
  mode=command.get('space_mode','モデル空間')
  state['mode']='model' if mode=='モデル空間' else 'viewport' if mode=='ビューポート内' else 'paper'
  if mode!='モデル空間':state['layout']=text_value(command.get('layout_name','Layout1'),values)
 elif kind=='LAYOUT':state.update(mode='paper',layout=text_value(command.get('layout_name','Layout1'),values))
 elif kind=='VIEWPORT':state['mode']='viewport' if command.get('viewport_action','矩形を作成') in ('アクティブにする','表示中心・尺度') else 'paper'

def space_name(state):
 return state.get('layout','Layout1') if state.get('mode')=='paper' else 'Model'

def update_variable(name,value,state):
 name=name.upper();value=str(value).strip().strip('"')
 if name=='TILEMODE':state['mode']='model' if float(value)==1 else 'paper'
 elif name=='CTAB':state.update(layout=value,mode='model' if value.casefold()=='model' else 'paper')
 elif name=='CVPORT' and state.get('mode')!='model':state['mode']='paper' if float(value)==1 else 'viewport'

def block_spaces(project):
 """Conservative destination sets for blocks not executed in the current row."""
 state=dict(mode='model',layout='Layout1');result=[]
 from block_model import nested
 for block in project.get('blocks',[]):
  declared=block.get('drawing_space')
  if declared:state.update(mode='model' if declared=='Model' else 'paper',layout=declared if declared!='Model' else state.get('layout','Layout1'))
  found=set()
  for command in nested(block.get('commands',[])):
   if command.get('type') in ('SPACE','LAYOUT','VIEWPORT'):
    try:update_space(command,state,{},lambda text,values:str(text))
    except Exception:pass
   found.add(space_name(state))
  result.append(found or {declared or space_name(state)})
 return result
