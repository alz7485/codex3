"""Review actual CAD geometry before replacing a project or adding drawing blocks."""
import queue
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from cad_drawing_import import read_cad_drawing, imported_project, append_drawing
from engine import compile_project
from macro_editor import command_summary, TYPE_LABELS
from table_grid import GridTreeview
from preview import DrawingCanvas
from file_drop import enable_file_drop
from theme import fit_window


class DrawingImportDialog:
    def __init__(self, app, *, project_mode=True):
        self.app=app;self.project_mode=project_mode;self.snapshot=None;self.worker=None;self.job=None
        self.result_queue=queue.Queue()
        self.win=tk.Toplevel(app.root);self.win.title('DWG／DXFからプロジェクトを作成' if project_mode else 'DWG／DXFの作図だけ追加')
        self.win.transient(app.root);self.win.grab_set();fit_window(self.win,1260,820,1000,640)
        self.win.protocol('WM_DELETE_WINDOW',self.close);self.win.bind('<Escape>',lambda event:self.close())
        self.path=tk.StringVar();self.status=tk.StringVar(value='DWG／DXFをこの画面へドラッグ、または「参照…」から選択してください。')
        header=ttk.Frame(self.win,padding=12);header.pack(fill='x')
        ttk.Entry(header,textvariable=self.path,state='readonly').pack(side='left',fill='x',expand=True)
        self.browse_button=ttk.Button(header,text='参照…',command=self.browse);self.browse_button.pack(side='left',padx=6)
        self.read_button=ttk.Button(header,text='読み取る',command=self.read);self.read_button.pack(side='left')
        self.include_layouts=tk.BooleanVar(value=False)
        self.layouts_check=ttk.Checkbutton(self.win,text='レイアウトも含める（用紙上の図形・対応するビューポート）',variable=self.include_layouts)
        self.layouts_check.pack(anchor='w',padx=12,pady=(0,6))
        hint='選択した空間の2D図形と設定を読み込み、新しいプロジェクトにします。入力表の寸法列は自動作成しません。' if project_mode else '選択した空間の2D図形を作図・寸法・テキストのブロックに整理して追加します。設定・入力表は変更しません。レイヤー・スタイルはCAD側の同名定義を使用します。'
        ttk.Label(self.win,text=hint,padding=(12,0),wraplength=1150).pack(anchor='w')
        line=ttk.Frame(self.win,padding=12);line.pack(fill='x')
        ttk.Label(line,textvariable=self.status,wraplength=1050).pack(side='left',fill='x',expand=True)
        self.busy=ttk.Progressbar(line,mode='indeterminate',length=120);
        footer=ttk.Frame(self.win,padding=12);footer.pack(side='bottom',fill='x')
        ttk.Button(footer,text='キャンセル',command=self.close).pack(side='left')
        self.apply_button=ttk.Button(footer,text='プロジェクトを作成' if project_mode else '作図ブロックを追加',command=self.apply,style='Primary.TButton',state='disabled');self.apply_button.pack(side='right')
        if not project_mode:
            ttk.Label(self.win,text='数値は固定です。複数行を作図すると、各行で同じ位置に描画されます。',padding=(12,3)).pack(side='bottom',anchor='w')
        panes=ttk.Panedwindow(self.win,orient='horizontal');panes.pack(fill='both',expand=True,padx=12,pady=(0,8))
        left=ttk.Frame(panes);panes.add(left,weight=1)
        tabs=ttk.Notebook(left);tabs.pack(fill='both',expand=True)
        commands=ttk.Frame(tabs);tabs.add(commands,text='登録するコマンド')
        self.command_tree=GridTreeview(commands,columns=('kind','detail'),show='tree headings',selectmode='browse')
        self.command_tree.heading('#0',text='ブロック／順');self.command_tree.column('#0',width=140,stretch=False)
        for key,title,width in [('kind','種類',100),('detail','実際の値',350)]:
            self.command_tree.heading(key,text=title);self.command_tree.column(key,width=width)
        self.command_tree.pack(side='left',fill='both',expand=True)
        scroll=ttk.Scrollbar(commands,command=self.command_tree.yview);scroll.pack(side='right',fill='y');self.command_tree.configure(yscrollcommand=scroll.set)
        issues=ttk.Frame(tabs);tabs.add(issues,text='注意・未対応の項目')
        self.report=tk.Text(issues,wrap='word',state='disabled',width=40);self.report.pack(side='left',fill='both',expand=True)
        scroll=ttk.Scrollbar(issues,command=self.report.yview);scroll.pack(side='right',fill='y');self.report.configure(yscrollcommand=scroll.set)
        preview_host=ttk.Frame(panes);panes.add(preview_host,weight=1)
        self.canvas=DrawingCanvas(preview_host,space_tabs=True);self.canvas.pack(fill='both',expand=True)
        self.drop_enabled=enable_file_drop(self.win,self.accept_drop)
        self.win.update_idletasks();panes.sashpos(0,self.win.winfo_width()//2)

    def browse(self):
        path=filedialog.askopenfilename(parent=self.win,title='読み取る図面',filetypes=[('AutoCAD図面','*.dwg *.dxf'),('DWG','*.dwg'),('DXF','*.dxf')])
        if path:self.path.set(path);self.read()

    def accept_drop(self, paths):
        if self.job is not None or (self.worker and self.worker.is_alive()):return
        files=[p for p in paths if Path(p).suffix.lower() in ('.dwg','.dxf')]
        if len(files)!=1:
            messagebox.showinfo('図面を選択','DWGまたはDXFを1つ選んでください。',parent=self.win);return
        self.path.set(files[0]);self.read()

    def read(self):
        if self.job is not None or (self.worker and self.worker.is_alive()):return
        path=self.path.get()
        if not path:return self.browse()
        self.snapshot=None;self.apply_button.configure(state='disabled')
        self.command_tree.delete(*self.command_tree.get_children());self.canvas.set_items([])
        self.report.configure(state='normal');self.report.delete('1.0','end');self.report.configure(state='disabled')
        self.status.set('AutoCADでDWGのコピーを変換しています…' if Path(path).suffix.lower()=='.dwg' else 'DXFを読み取っています…');self.busy.pack(side='right');self.busy.start()
        self.browse_button.configure(state='disabled');self.read_button.configure(state='disabled');self.layouts_check.configure(state='disabled')
        include_layouts=self.include_layouts.get()
        def work():
            try:
                snapshot=read_cad_drawing(path,include_settings=self.project_mode,**({"include_layouts":True} if include_layouts else {}))
                preview=imported_project(snapshot)
                items=compile_project(preview,[0])[1]
                self.result_queue.put((True,(snapshot,items)))
            except Exception as exc:self.result_queue.put((False,str(exc)))
        # Non-daemon: allow AutoCAD's finally/Close cleanup to finish even if UI closes.
        self.worker=threading.Thread(target=work,daemon=False);self.worker.start();self.job=self.win.after(80,self.poll)

    def poll(self):
        self.job=None
        try:ok,payload=self.result_queue.get_nowait()
        except queue.Empty:self.job=self.win.after(80,self.poll);return
        self.busy.stop();self.busy.pack_forget();self.layouts_check.configure(state='normal');self.read_button.configure(state='normal');self.browse_button.configure(state='normal')
        if not ok:
            self.status.set('読み取れませんでした。');messagebox.showerror('図面の読込',payload,parent=self.win);return
        snapshot,items=payload;self.snapshot=snapshot
        self.status.set(' ／ '.join(f'{name} {count}件' for name,count in snapshot['counts'].items())+f" ／ 注意 {len(snapshot['issues'])}件")
        for bi,block in enumerate(snapshot['blocks']):
            parent=self.command_tree.insert('','end',iid='block'+str(bi),text=block['name'],values=('',str(len(block['commands']))+'件'),open=True)
            for ci,command in enumerate(block['commands']):
                self.command_tree.insert(parent,'end',text=str(ci+1),values=(TYPE_LABELS.get(command['type'],command['type']).split(' · ')[-1],command_summary(command)))
        notes='\n\n'.join(f"{note['type']} {note['handle']}\n{note['reason']}" for note in snapshot['issues']) or '注意・未対応の項目はありません。'
        self.report.configure(state='normal');self.report.insert('1.0',notes);self.report.configure(state='disabled')
        self.canvas.set_color_resources({'cad_setup':snapshot['cad_setup'] or {},'blocks':snapshot['blocks']});self.canvas.set_items(items);self.canvas.fit()
        self.apply_button.configure(state='normal')

    def apply(self):
        if self.snapshot is None:return
        try:
            if self.project_mode:
                trial=imported_project(self.snapshot)
                if not self.app.confirm_discard('図面からプロジェクトを作成'):return
                self.app.replace_document(trial,name=self.snapshot['name'])
                self.app._saved={}  # Imported project needs an explicit JSON save.
                self.app.update_title()
            else:
                self.app.table_editor.finish()
                trial=append_drawing(self.app.data,self.snapshot)
                self.app.data['blocks']=trial['blocks'];self.app.refresh();self.app.preview(quiet=True)
        except ValueError as exc:messagebox.showerror('図面の登録',str(exc),parent=self.win);return
        self.app.status.set('図面を読み込みました。表・変数・点参照への置換は後から編集できます。')
        self.close()

    def close(self):
        if self.job is not None:
            self.win.after_cancel(self.job);self.job=None
        self.win.destroy()
