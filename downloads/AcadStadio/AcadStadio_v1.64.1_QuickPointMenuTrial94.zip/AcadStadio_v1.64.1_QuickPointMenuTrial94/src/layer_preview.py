"""Apply known layer-definition overrides without changing explicit entity colors."""
def apply_layer_state(item,state):
 if not state:return
 if 'rename' in state:
  item['effective_layer']=state['rename'];item['layer']=state['rename']
 if 'color' in state:item['resolved_layer_color']=state['color']
 if 'linetype' in state and str(item.get('linetype','BYLAYER')).upper()=='BYLAYER':item['resolved_layer_linetype']=state['linetype']
 item['preview_layer_hidden']=state.get('layer_on') is False or state.get('layer_frozen') is True
 for child in item.get('children',[]):apply_layer_state(child,state)
