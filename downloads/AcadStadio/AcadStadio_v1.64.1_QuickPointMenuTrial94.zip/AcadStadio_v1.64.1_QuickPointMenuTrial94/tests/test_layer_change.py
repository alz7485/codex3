import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from sample_project import EXAMPLE
from command_catalog import load_default_catalog
from engine import compile_project,MacroError
from test_cad_state import read_form,walk
from layer_change import render

class LayerChange(unittest.TestCase):
 def compile(self,commands,rows=[0]):
  p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=commands)];return compile_project(p,rows)
 def test_initial_catalog_empty_and_regenerate_is_standard(self):
  self.assertEqual(load_default_catalog(),{})
  for scope,token in [('現在のビュー','_.REGEN'),('全ビュー','_.REGENALL')]:
   script,items=self.compile([dict(type='REGEN',regen_scope=scope)]);self.assertIn(token,script);self.assertEqual(items,[])
 def test_all_layer_properties_compile_as_one_atomic_form(self):
  command=dict(type='LAYEREDIT',target_layer='PARTS',layer_color='2',layer_linetype='CENTER',layer_weight='0.25 mm',layer_plot='印刷しない',layer_on='非表示',layer_frozen='フリーズ',layer_locked='ロック',layer_transparency='50',layer_description='部品',new_layer_name='PARTS2')
  lines,target,props=render(command,{},lambda value,context:str(value))
  self.assertEqual(len(lines),1);self.assertEqual(props['lineweight'],25);self.assertEqual(props['color'],2)
  for node in walk(read_form(lines[0])):
   if node and node[0]=='if':self.assertIn(len(node),(3,4))
  self.assertIn('(boole 7',lines[0]);self.assertIn('440',lines[0]);self.assertIn('"_.-RENAME"',lines[0])
 def test_invalid_values_and_duplicate_layer_names_not_silently_overwritten(self):
  for key,value in [('layer_color','0'),('layer_transparency','91'),('layer_weight','-1'),('layer_linetype','BYLAYER')]:
   with self.subTest(key=key),self.assertRaises(MacroError):self.compile([dict(type='LAYEREDIT',target_layer='PARTS',**{key:value})])
  script,_=self.compile([dict(type='LAYEREDIT',target_layer='PARTS',new_layer_name='PARTS2')]);self.assertIn('Layer name already exists',script)
 def test_layer_change_updates_existing_and_future_preview_entities(self):
  circle=dict(type='CIRCLE',layer='PARTS',color='256',x='0',y='0',r='10')
  commands=[circle,dict(type='LAYEREDIT',target_layer='PARTS',layer_color='3',layer_on='非表示'),dict(circle,x='20')]
  _,items=self.compile(commands)
  self.assertTrue(all(i['resolved_layer_color']==3 and i['preview_layer_hidden'] for i in items))
 def test_once_and_unlock_preserve_other_flag_bits(self):
  script,_=self.compile([dict(type='LAYEREDIT',target_layer='PARTS',layer_locked='解除',execution='once')],[0,1])
  self.assertEqual(script.count('Layer does not exist'),1);self.assertIn('(boole 1 (cdr (assoc 70 data)) -5)',script)

 def test_only_unused_unchanged_builtins_are_removed_on_load(self):
  import json
  from project_model import normalize_project
  catalog=json.loads((Path(__file__).parent/'fixtures'/'legacy_default_commands.json').read_text())['commands']
  p=copy.deepcopy(EXAMPLE);p['custom_commands']=catalog
  self.assertEqual(normalize_project(p)['custom_commands'],{})
  p['blocks'][0]['commands']=[dict(type='CUSTOM',name='set_osmode')]
  catalog['regenerate']['description']='ユーザーによる変更'
  self.assertEqual(set(normalize_project(p)['custom_commands']),{'set_osmode','regenerate'})
  self.assertEqual(len(p['custom_commands']),15)
