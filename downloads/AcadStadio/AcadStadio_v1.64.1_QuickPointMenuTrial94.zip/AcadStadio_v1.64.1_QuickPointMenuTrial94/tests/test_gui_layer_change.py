import os,sys,unittest
import test_gui as gui
from macro_editor import edit_command
from catalog_editor import CommandCatalogManager

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class LayerChangeGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_new_project_has_no_registered_builtin_commands(self):
  self.assertEqual(self.app.data['custom_commands'],{})
  manager=CommandCatalogManager(self.root,self.app.data,self.app.refresh)
  self.root.update();self.assertEqual(manager.tree.get_children(),());manager.cancel()
 def test_grouped_layer_fields_save_friendly_weight_and_color(self):
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    self.assertIn('layer_color',w.advanced_rows)
    def put(key,value):
     entry=w.command_entries[key];entry.delete(0,'end');entry.insert(0,value)
    put('target_layer','OUTLINE');put('layer_color','3');put('layer_weight','0.25 mm')
    w.command_entries['layer_plot'].set('印刷しない')
    gui.button(w,'コマンドを反映').invoke()
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(100,inspect)
  result=edit_command(self.root,dict(type='LAYEREDIT'),self.app.data['blocks'],self.app.data)
  self.assertEqual(self.errors,[]);self.assertEqual(result['layer_weight'],'25');self.assertEqual(result['layer_color'],'3')
  self.assertEqual(result['layer_plot'],'印刷しない')
 def test_regen_scope_is_selectable(self):
  def inspect():
   w=gui.top(self.root,'コマンドの設定');w.command_entries['regen_scope'].set('全ビュー');gui.button(w,'コマンドを反映').invoke()
  self.root.after(100,inspect)
  result=edit_command(self.root,dict(type='REGEN'),self.app.data['blocks'],self.app.data)
  self.assertEqual(result['regen_scope'],'全ビュー')
