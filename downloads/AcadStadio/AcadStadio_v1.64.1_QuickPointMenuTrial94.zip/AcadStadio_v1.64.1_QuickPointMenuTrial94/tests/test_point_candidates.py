import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from point_candidates import candidates_at
class PointCandidates(unittest.TestCase):
 def candidates(self,items,position):return candidates_at(items,lambda i:i['command_index'],{i:'コマンド'+str(i+1) for i in range(len(items))},lambda p:p,position,radius=.1)
 def line(self,index,a,b):return dict(type='LINE',coords=(*a,*b),command_index=index)
 def test_unambiguous_endpoint_selects_single_command_point(self):
  result=self.candidates([self.line(0,(0,0),(100,0))],(100,0));self.assertEqual(len(result),1);self.assertEqual(result[0]['point'],'終点')
 def test_overlapping_vertex_offers_each_source_and_intersection(self):
  result=self.candidates([self.line(0,(0,0),(100,0)),self.line(1,(100,0),(100,100))],(100,0))
  self.assertEqual([c['kind'] for c in result].count('point'),2);self.assertEqual([c['kind'] for c in result].count('intersection'),1)
  self.assertIn('線分',result[0]['label'])
 def test_interior_intersection_without_vertex_is_selectable(self):
  result=self.candidates([self.line(0,(0,30),(100,30)),self.line(1,(20,0),(20,100))],(20,30));self.assertEqual(len(result),1);self.assertEqual(result[0]['kind'],'intersection')
 def test_line_circle_intersection_and_no_extended_line_snap(self):
  items=[self.line(0,(-20,0),(20,0)),dict(type='CIRCLE',coords=(0,0,10),command_index=1)]
  self.assertTrue(any(c['kind']=='intersection' for c in self.candidates(items,(10,0))))
  self.assertEqual(self.candidates([self.line(0,(0,0),(10,0)),self.line(1,(20,-10),(20,10))],(20,0))[0]['kind'],'point')
 def test_nearest_point_is_auto_selected_when_other_points_are_separate(self):
  items=[self.line(0,(0,0),(100,0)),self.line(1,(105,0),(105,100))]
  result=candidates_at(items,lambda i:i['command_index'],{0:'線分1',1:'線分2'},lambda p:p,(100,0),radius=10)
  self.assertEqual(len(result),1);self.assertEqual(result[0]['primary'],0);self.assertEqual(result[0]['point'],'終点')
 def test_dense_overlapping_geometry_requests_zoom_instead_of_quadratic_scan(self):
  items=[self.line(i,(0,-100),(0,100)) for i in range(65)]
  with self.assertRaisesRegex(ValueError,'拡大'):
   candidates_at(items,lambda i:i['command_index'],{i:str(i) for i in range(65)},lambda p:p,(0,0))
