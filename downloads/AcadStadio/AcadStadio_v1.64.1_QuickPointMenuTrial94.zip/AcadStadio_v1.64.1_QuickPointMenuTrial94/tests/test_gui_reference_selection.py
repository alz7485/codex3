import os,sys,unittest,tkinter as tk
from tkinter import ttk
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from input_assist import show_table_reference_picker
from macro_editor import edit_command

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class ReferenceSelection(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_cell_highlights_only_cell_and_header_highlights_column(self):
        selected=[]
        def inspect():
            win=gui.top(self.root,'表から参照を選ぶ')
            try:
                tree=next(w for w in gui.descendants(win) if isinstance(w,ttk.Treeview))
                tree.tk.call(tree.heading('OD','command'));self.root.update()
                active=lambda:[w for w in tree.winfo_children() if isinstance(w,tk.Label) and w.place_info()]
                self.assertEqual(len(active()),3);self.assertFalse(tree.selection())
                box=tree.bbox('0','OD')
                tree.event_generate('<ButtonPress-1>',x=box[0]+8,y=box[1]+8)
                tree.event_generate('<ButtonRelease-1>',x=box[0]+8,y=box[1]+8);self.root.update()
                self.assertEqual(len(active()),1);self.assertFalse(tree.selection())
                gui.button(win,'この参照を挿入').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(100,inspect);show_table_reference_picker(self.root,self.app.data,selected.append)
        self.assertIn('@OD{1}',selected[0])

    def test_used_references_follow_parent_reference_and_insert_into_movement(self):
        from macro_editor import edit_command
        from tkinter import ttk
        sources=[dict(type='LINE',x1='@OD',y1='変数.SCALE',x2='@OD + 10',y2='変数.SCALE'),dict(type='CIRCLE',x='0',y='0',r='@PCD / 2')]
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.choose_command_point('x1',both=True);self.root.update();panel=win.point_panel
                gui.use_reference_and_finish(panel);self.root.update()
                win.movement_entries['y1'].focus_force();self.root.update()
                picker=win.used_reference_picker
                self.assertTrue(picker.winfo_ismapped())
                values=list(picker.cget('values'));picker.current(next(i for i,v in enumerate(values) if str(v).startswith('変数.SCALE')));picker.event_generate('<<ComboboxSelected>>')
                self.assertEqual(win.coordinate_values['y1'].movement.get(),'変数.SCALE')
                self.assertEqual(win.coordinate_values['x1'].movement.get(),'0')
                win.sample_row.set('2');self.root.update()
                self.assertTrue(any(str(v).startswith('@OD = 120') for v in picker.cget('values')))
            except Exception as exc:self.errors.append(exc)
            finally:win.destroy()
        self.root.after(100,inspect)
        edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='100',y2='10'),self.app.data['blocks'],self.app.data,point_sources=sources)
