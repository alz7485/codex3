"""Grouped main controls, preview-only row selection, and integrated size editing."""
import copy
import os
import sys
import unittest
from pathlib import Path
from tkinter import ttk
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from settings_preset_editor import CURRENT
from settings_presets import create_preset


@unittest.skipUnless(sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display unavailable")
class GroupedControlsGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_settings_and_table_groups_have_the_expected_controls_and_fit(self):
        self.assertEqual(next(w.cget("text") for w in self.app.settings_group.winfo_children() if isinstance(w, ttk.Label)), "設定")
        self.assertEqual(next(w.cget("text") for w in self.app.table_group.winfo_children() if isinstance(w, ttk.Label)), "入力表")
        self.assertEqual([w.cget("text") for w in self.app.settings_buttons],
                         ["CAD設定", "プリセット"])
        self.assertTrue(gui.button(self.app.table_group, "表一覧").winfo_ismapped())
        self.assertTrue(self.app.drawing_table_picker.winfo_ismapped())
        self.assertEqual(self.app._target_controls, [])
        self.assertFalse(hasattr(self.app, "edit_drawing_settings"))
        for geometry, sash in (("1320x840", 430), ("1040x680", 430), ("1040x680", 300)):
            self.root.geometry(geometry); self.root.update()
            self.app.drawing_panes.sashpos(0, sash); self.root.update()
            for widget in self.app.settings_buttons:
                self.assertTrue(widget.winfo_ismapped())
                self.assertGreaterEqual(widget.winfo_width(), widget.winfo_reqwidth())
            self.assertEqual(self.app.canvas.space_tabs.notebook.winfo_rooty(), self.app.drawing_page.winfo_rooty())
            self.assertGreater(self.app.block_list.winfo_height(), 100)

    def test_display_spin_changes_preview_without_changing_scr_project_or_history(self):
        before = copy.deepcopy(self.app.data); history = len(self.app._history)
        script = self.app.compile()[0]; scale = self.app.canvas.scale_value
        controls = self.app.preview_row_controls; spin = controls.spin
        up = next((x, y) for x in range(spin.winfo_width()-1, -1, -1)
                  for y in range(spin.winfo_height()) if spin.identify(x, y).endswith("uparrow"))
        spin.event_generate("<ButtonPress-1>", x=up[0], y=up[1])
        spin.event_generate("<ButtonRelease-1>", x=up[0], y=up[1]); self.root.update()
        self.app.preview(quiet=True)
        self.assertEqual(self.app.preview_rows(), [1])
        self.assertEqual({item["row"] for item in self.app.canvas.items}, {1})
        self.assertIn("FL-120", controls.title.get())
        self.assertEqual(self.app.table.selection(), ("1",))
        self.assertEqual(self.app.target_rows(), [0])
        self.assertEqual(self.app.compile()[0], script)
        self.assertEqual(self.app.data, before)
        self.assertEqual(len(self.app._history), history)
        self.assertAlmostEqual(self.app.canvas.scale_value, scale)

    def test_invalid_display_row_keeps_valid_script_and_previous_preview(self):
        script = self.app.compile()[0]; before = copy.deepcopy(self.app.data)
        controls = self.app.preview_row_controls
        for raw in ("0", "99", "1,2", ""):
            controls.value.set(raw); controls.apply()
            self.assertEqual(self.app.preview_rows(), [0])
            self.assertEqual(self.app.compile()[0], script)
            self.assertEqual(self.app.data, before)
        controls.value.set("２"); controls.apply()
        self.assertEqual(controls.value.get(), "2")
        self.assertEqual(self.app.preview_rows(), [1])

    def test_input_selection_and_display_row_are_linked_and_reset_returns_to_drawing_targets(self):
        self.app.show_input_table(); self.root.update()
        controls = self.app.preview_row_controls
        self.app.table.selection_set("2"); self.root.update()
        self.assertEqual(controls.value.get(), "3")
        self.assertEqual(self.app.preview_rows(), [2])
        self.app.table.selection_set(("1", "2")); self.root.update()
        self.assertEqual(controls.value.get(), "")
        self.assertIn("2行", controls.title.get())
        controls.reset(); self.root.update(); self.app.preview(quiet=True)
        self.assertEqual(self.app.preview_rows(), [0])
        self.assertEqual(controls.value.get(), "1")
        self.assertEqual(self.app.target_rows(), [0])

    def test_current_size_edits_are_staged_cancelled_and_saved_with_undo(self):
        before = copy.deepcopy(self.app.data)
        editor = self.app.manage_settings_presets(); self.root.update()
        self.assertEqual(editor.selected(), CURRENT)
        editor.size_vars["TEXT_HEIGHT"].set("7")
        gui.button(editor.win, "キャンセル").invoke()
        self.assertEqual(self.app.data, before)
        editor = self.app.manage_settings_presets(); self.root.update()
        editor.size_vars["TEXT_HEIGHT"].set("3 + 4")
        gui.button(editor.win, "保存して閉じる").invoke(); self.root.update()
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], "7")
        self.assertTrue(self.app.compile()[0])
        self.assertEqual(self.app.data["drawing"], before["drawing"])
        self.app.undo_project(); self.root.update()
        self.assertEqual(self.app.data, before)
        editor = self.app.manage_settings_presets(); self.root.update()
        with patch.object(self.app, "edit_key_values", return_value=dict(self.app.data["settings"], TEXT_HEIGHT="3 + 4")):
            editor.edit()
        gui.button(editor.win, "保存して閉じる").invoke()
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], "7")
        self.assertTrue(self.app.compile()[0])

    def test_invalid_pending_size_blocks_selection_without_losing_input(self):
        before = copy.deepcopy(self.app.data)
        editor = self.app.manage_settings_presets(); self.root.update()
        editor.size_vars["TEXT_HEIGHT"].set("-1")
        editor.list.selection_set("small"); self.root.update()
        self.assertEqual(editor.selected(), CURRENT)
        self.assertEqual(editor.size_vars["TEXT_HEIGHT"].get(), "-1")
        self.assertTrue(self.messages)
        self.assertEqual(self.app.data, before)
        editor.size_vars["TEXT_HEIGHT"].set("")
        gui.button(editor.win, "保存して閉じる").invoke()
        self.assertTrue(editor.win.winfo_exists())
        self.assertEqual(self.app.data, before)
        editor.size_vars["TEXT_HEIGHT"].set("7")
        editor.list.selection_set("small"); self.root.update()
        self.assertEqual(editor.size_vars["TEXT_HEIGHT"].get(), "2.5")
        gui.button(editor.win, "保存して閉じる").invoke()
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], "7")

    def test_standard_sizes_are_readonly_and_custom_sizes_can_be_applied(self):
        before = copy.deepcopy(self.app.data)
        editor = self.app.manage_settings_presets(); self.root.update()
        editor.list.selection_set("default"); self.root.update()
        self.assertTrue(all("readonly" in w.state() for w in editor.size_entries.values()))
        with patch("tkinter.simpledialog.askstring", return_value="文字7"):
            gui.button(editor.win, "複製").invoke()
        self.root.update()
        custom = editor.selected()
        editor.size_vars["TEXT_HEIGHT"].set("7")
        self.assertEqual(self.app.data, before)
        gui.button(editor.win, "選択を適用").invoke()
        self.assertEqual(self.app.data["active_settings_preset"], custom)
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], "7")
        self.assertEqual(self.app.data["settings_presets"][custom]["values"]["TEXT_HEIGHT"], "7")

    def test_partial_preset_keeps_unspecified_size_values_and_does_not_apply_on_save(self):
        custom = create_preset(self.app.data, "文字のみ", {"TEXT_HEIGHT": "4"})
        self.app.refresh(); before = copy.deepcopy(self.app.data["settings"])
        editor = self.app.manage_settings_presets(); editor.list.selection_set(custom); self.root.update()
        self.assertEqual(editor.size_vars["ARROW_SIZE"].get(), "")
        editor.size_vars["TEXT_HEIGHT"].set("6")
        gui.button(editor.win, "保存して閉じる").invoke()
        self.assertEqual(self.app.data["settings"], before)
        self.assertEqual(self.app.data["settings_presets"][custom]["values"], {"TEXT_HEIGHT": "6"})

    def test_size_fields_and_preset_actions_fit_the_minimum_dialog(self):
        editor = self.app.manage_settings_presets(); self.root.update()
        for geometry in ("900x700", "760x600"):
            editor.win.geometry(geometry); self.root.update()
            for widget in (*editor.size_entries.values(), gui.button(editor.win, "保存して閉じる"),
                           gui.button(editor.win, "選択を適用"), gui.button(editor.win, "現在値から新規")):
                self.assertTrue(widget.winfo_ismapped())
                self.assertGreaterEqual(widget.winfo_width(), widget.winfo_reqwidth())
                self.assertLessEqual(widget.winfo_rooty()+widget.winfo_height(),
                                     editor.win.winfo_rooty()+editor.win.winfo_height())
            self.assertTrue(editor.list.bbox("large"))
        editor.win.destroy()
