"""Non-line construction defaults must remain valid after zero-start changes."""
import copy,os,sys,unittest
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CoordinateDefaults(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_hatch_spline_and_leader_default_paths_preview_and_compile(self):
  for kind in ('HATCH','SPLINE','LEADER'):
   with self.subTest(kind=kind):
    def inspect():
     w=gui.top(self.root,'コマンドの設定')
     try:
      w.refresh_command_preview();self.root.update()
      self.assertTrue(w.command_preview.canvas.items,kind)
      self.assertGreaterEqual(len(w.vertex_rows),3)
      gui.button(w,'コマンドを反映').invoke()
     except Exception as exc:self.errors.append(exc);w.destroy()
    self.root.after(100,inspect)
    result=edit_command(self.root,dict(type=kind),self.app.data['blocks'],self.app.data)
    self.assertIsNotNone(result)
    p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[result])]
    self.assertTrue(compile_project(p,[0])[1]);self.assertEqual(self.errors,[])
