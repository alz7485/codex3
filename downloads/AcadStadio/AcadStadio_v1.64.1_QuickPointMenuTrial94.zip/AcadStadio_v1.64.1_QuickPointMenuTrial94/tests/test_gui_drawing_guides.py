import copy
import json
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import MacroEditor
from guide_blocks import forward_links
from command_points import new_id, reference
from engine import MacroError

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class DrawingGuidesGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def linked(self):
        p=copy.deepcopy(self.app.data);pid=new_id()
        p['blocks']=[dict(id='source',name='元',commands=[dict(type='LINE',point_id=pid,x1='0',y1='0',x2='100',y2='0')]),dict(id='target',name='使用',commands=[dict(type='POINT',x=reference('source/'+pid,'中点','X'),y='0')])]
        self.app.replace_document(p);self.root.update();return copy.deepcopy(self.app.data)

    def test_guide_copy_is_staged_undoable_preview_only_and_json_saved(self):
        original=copy.deepcopy(self.app.data);script=self.app.compile()[0]
        e=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);e.list.refresh(next(i for i,c in enumerate(e.list.commands) if c["type"]=="CIRCLE"))
        gui.button(e.list.toolbar,'ガイド化').invoke();self.root.update()
        self.assertEqual(self.app.data,original);self.assertTrue(e.working_blocks[0]['guide'])
        self.assertTrue(any(i.get('guide') for i in e.preview_canvas.items))
        self.assertTrue(all(float(e.preview_canvas.itemcget(n,'width'))==1 for n,i,_ in e.preview_canvas.geometry if i.get('guide') and e.preview_canvas.type(n)!='text'))
        e.list.undo();self.assertFalse(any(b.get('guide') for b in e.working_blocks))
        e.list.redo();self.assertTrue(e.working_blocks[0]['guide']);e.save();self.root.update()
        self.assertEqual(self.app.compile()[0],script)
        self.app.preview(quiet=True);self.assertIn("ガイド1",self.app.preview_metrics.get())
        path=Path(self.library_dir.name)/'guide.json'
        with patch('tkinter.filedialog.asksaveasfilename',return_value=str(path)):self.assertTrue(self.app.save())
        self.assertTrue(json.loads(path.read_text())['blocks'][0]['guide'])
        self.assertTrue(self.app.open_project(path));self.assertEqual(self.app.compile()[0],script)
        self.app.block_browser.reveal(0);self.app.move_block(1);self.assertTrue(self.app.data['blocks'][0]['guide'])
        self.app.block_browser.reveal(1);self.app.move_block(-1);self.assertTrue(self.app.data['blocks'][0]['guide'])

    def test_reorder_can_keep_link_warning_then_repair_with_guide_and_undo(self):
        original=self.linked();reference_text=self.app.data['blocks'][1]['commands'][0]['x']
        self.app.block_browser.reveal(0)
        with patch('tkinter.messagebox.askyesnocancel',return_value=False):self.app.move_block(1)
        self.root.update();self.assertEqual(self.app.data['blocks'][0]['commands'][0]['x'],reference_text)
        self.assertTrue(forward_links(self.app.data));self.assertIn('reference_warning',self.app.block_list.item('0','tags'))
        with self.assertRaises(MacroError):self.app.compile()
        editor=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0])
        editor.list.refresh(0);self.root.update();editor.show_preview([0])
        self.assertIn('reference_warning',editor.list.tree.item('0','tags'))
        def inspect_reference():
            window=gui.top(self.root,'コマンドの設定')
            try:self.assertIn('元 / コマンド1',window.command_entries['x'].get())
            except Exception as exc:self.errors.append(exc)
            gui.button(window,'キャンセル').invoke()
        self.root.after(50,inspect_reference);editor.list.edit();editor.win.destroy()
        with patch('tkinter.messagebox.askyesnocancel',return_value=True):self.app.block_browser.review_reference_order()
        self.root.update();self.assertTrue(self.app.data['blocks'][0]['guide']);self.assertFalse(forward_links(self.app.data))
        self.assertEqual(self.app.compile()[0].count('_.LINE\n'),1)
        self.app.undo_project();self.assertTrue(forward_links(self.app.data))
        self.app.undo_project();self.assertEqual(self.app.data,original)

    def test_reorder_cancel_and_guide_stays_above_folder_roots(self):
        original=self.linked();self.app.block_browser.reveal(0)
        with patch('tkinter.messagebox.askyesnocancel',return_value=None):self.app.move_block(1)
        self.assertEqual(self.app.data,original)
        with patch('tkinter.messagebox.askyesnocancel',return_value=True):self.app.move_block(1)
        self.app.data['block_folders']=[dict(id='folder',name='分類',parent_id='')]
        self.app.data['blocks'][1]['folder_id']='folder';self.app.refresh();self.root.update()
        self.assertEqual(self.app.block_list.get_children()[0],'0');self.assertEqual(self.app.block_list.parent('0'),'')
        self.assertEqual(self.app.block_list.item('0','text'),'G')

    def test_navigator_reorder_offers_the_same_guide_repair(self):
        self.linked();self.app.open_navigator();self.root.update();nav=self.app.navigator
        nav.choose_block(0)
        with patch('tkinter.messagebox.askyesnocancel',return_value=True):nav.move(1)
        self.root.update();self.assertTrue(self.app.data['blocks'][0]['guide']);self.assertFalse(forward_links(self.app.data))
        self.assertEqual(self.app.compile()[0].count('_.LINE\n'),1)
        nav.choose_block(0);nav.move(1);self.assertTrue(self.app.data['blocks'][0]['guide'])
