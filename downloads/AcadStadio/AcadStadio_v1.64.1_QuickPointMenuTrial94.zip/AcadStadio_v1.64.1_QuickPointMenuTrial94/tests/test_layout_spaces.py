import copy,sys,unittest,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from sample_project import EXAMPLE
from engine import compile_project
from block_model import new_block
from cad_drawing_import import extract_drawing,imported_project,read_cad_drawing
from preview_spaces import block_spaces

class LayoutSpaces(unittest.TestCase):
 def test_space_routes_geometry_and_block_metadata(self):
  p=copy.deepcopy(EXAMPLE)
  p['blocks']=[new_block('モデル',commands=[dict(type='CIRCLE',x='0',y='0',r='10')]),new_block('レイアウト作成',commands=[dict(type='LAYOUT',layout_name='A4')]),new_block('注記',commands=[dict(type='TEXT',x='10',y='20',text='TEST')])]
  script,items=compile_project(p,[0]);self.assertEqual([i['cad_space'] for i in items],['Model','A4'])
  self.assertEqual(block_spaces(p),[{'Model'},{'A4'},{'A4'}])
  p['blocks'][2]['drawing_space']='Model';script,items=compile_project(p,[0]);self.assertEqual(items[-1]['cad_space'],'Model')
 def test_layout_import_and_model_only_option(self):
  import ezdxf
  d=ezdxf.new();d.modelspace().add_line((0,0),(10,0))
  paper=d.layouts.new('A4');paper.add_text('PAPER',dxfattribs={'insert':(20,20)})
  paper.add_viewport(center=(100,80),size=(150,100),view_center_point=(0,0),view_height=100)
  model=extract_drawing(d,include_settings=False);self.assertEqual(len(model['blocks']),3)
  full=extract_drawing(d,include_settings=False,include_layouts=True)
  self.assertIn('A4',full['layout_names'])
  p=imported_project(full);script,items=compile_project(p,[0]);self.assertEqual({i['cad_space'] for i in items},{'Model','A4'})
  viewports=[c for b in p['blocks'] for c in b['commands'] if c['type']=='VIEWPORT']
  self.assertEqual(len(viewports),1);self.assertTrue(viewports[0]['configure_view'])
  with tempfile.TemporaryDirectory() as td:
   path=Path(td)/'layout.dxf';d.saveas(path)
   self.assertIn('A4',read_cad_drawing(path,include_settings=False,include_layouts=True)['layout_names'])
 def test_viewport_model_geometry_belongs_to_model_tab(self):
  p=copy.deepcopy(EXAMPLE);p['blocks']=[new_block('作図',commands=[dict(type='SPACE',space_mode='ビューポート内',layout_name='A4',viewport_id='2'),dict(type='CIRCLE',x='0',y='0',r='5')])]
  self.assertEqual(compile_project(p,[0])[1][0]['cad_space'],'Model')
