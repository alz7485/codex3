"""Old definitions are test data for compatibility, never application defaults."""
import json
from pathlib import Path

def legacy_catalog():
 catalog=json.loads((Path(__file__).parent/'fixtures'/'legacy_default_commands.json').read_text(encoding='utf-8'))['commands']
 for item in catalog.values():item['description']+='（ユーザー編集済みの互換テスト用定義）'
 return catalog
