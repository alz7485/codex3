import copy,os,sys,unittest
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class DirectPointCandidates(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def click(self,canvas,point):
  x,y=canvas.screen_point(point)
  canvas.event_generate('<ButtonPress-1>',x=round(x),y=round(y));canvas.event_generate('<ButtonRelease-1>',x=round(x),y=round(y));self.root.update()
 def edit(self,sources,inspect):
  def run():
   win=gui.top(self.root,'コマンドの設定')
   try:win.refresh_command_preview();self.root.update();inspect(win,win.command_preview.canvas)
   except Exception as exc:self.errors.append(exc);win.destroy()
  self.root.after(100,run)
  result=edit_command(self.root,dict(type='POINT',x='30',y='50'),self.app.data['blocks'],self.app.data,point_sources=sources)
  self.assertEqual(self.errors,[]);return result
 def line(self,a,b):return dict(type='LINE',x1=str(a[0]),y1=str(a[1]),x2=str(b[0]),y2=str(b[1]))
 def test_unique_point_selects_source_and_endpoint_without_command_click(self):
  sources=[self.line((0,0),(100,0))]
  def inspect(w,c):
   self.click(c,(100,0));panel=w.point_panel
   self.assertEqual(panel.source_picker.current(),0);self.assertEqual(panel.point_picker.get(),'終点')
   self.assertFalse(getattr(c,'candidate_popup',None))
   gui.use_reference_and_finish(panel);gui.button(w,'コマンドを反映').invoke()
  result=self.edit(sources,inspect)
  p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=sources+[result])]
  self.assertEqual(compile_project(p,[0])[1][-1]['coords'],(100,0))
 def test_overlap_list_previews_pair_then_commits_dynamic_intersection(self):
  sources=[self.line((0,0),(100,0)),self.line((100,0),(100,100))]
  def inspect(w,c):
   self.click(c,(100,0));popup=c.candidate_popup
   single=next(i for i,choice in enumerate(popup.candidates) if choice['kind']=='point')
   popup.event_generate('<Motion>',x=20,y=popup.yposition(single)+5);self.root.update()
   chosen=popup.candidates[single]['primary']
   for item in c.items:
    source=c.item_source_index(item)
    if source in (0,1):self.assertEqual(c.display_color(item,'#ffffff')=='#34465c',source!=chosen)
   index=next(i for i,choice in enumerate(popup.candidates) if choice['kind']=='intersection')
   popup.event_generate('<Motion>',x=20,y=popup.yposition(index)+5);self.root.update()
   self.assertEqual({c.source_index,*c.related_source_indices},{0,1})
   for item in c.items:
    if c.item_source_index(item) in (0,1):self.assertNotEqual(c.display_color(item,'#ffffff'),'#34465c')
   self.assertTrue(all('線分' in choice['label'] for choice in popup.candidates))
   popup.event_generate('<ButtonPress-1>',x=20,y=popup.yposition(index)+5)
   popup.event_generate('<ButtonRelease-1>',x=20,y=popup.yposition(index)+5);self.root.update()
   panel=w.point_panel;self.assertEqual(panel.relation_controls.mode.get(),'交点')
   self.assertEqual(panel.point_picker.get(),'候補A')
   gui.use_reference_and_finish(panel);gui.button(w,'コマンドを反映').invoke()
  result=self.edit(sources,inspect);self.assertIn('交点(',result['x'])
  p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=sources+[result])]
  self.assertEqual(compile_project(p,[0])[1][-1]['coords'],(100,0))
 def test_candidate_cancel_restores_highlight_and_does_not_register_ids(self):
  sources=[self.line((0,0),(100,0)),self.line((100,0),(100,100))];before=copy.deepcopy(sources)
  def inspect(w,c):
   selected=c.source_index;self.click(c,(100,0));popup=c.candidate_popup
   popup.event_generate('<Escape>');self.root.update()
   self.assertEqual(c.source_index,selected);self.assertEqual(sources,before)
   gui.button(w,'キャンセル').invoke()
  self.assertIsNone(self.edit(sources,inspect))

 def test_dismissed_menu_restores_highlight_and_editor_grab(self):
  sources=[self.line((0,0),(100,0)),self.line((100,0),(100,100))]
  def inspect(w,c):
   selected=c.source_index;self.click(c,(100,0));popup=c.candidate_popup
   popup.event_generate('<Motion>',x=20,y=popup.yposition(0)+5);self.root.update()
   popup.unpost();self.root.update()
   self.assertFalse(popup.winfo_exists());self.assertEqual(c.source_index,selected)
   self.assertIs(self.root.grab_current(),w)
   gui.button(w,'キャンセル').invoke()
  self.assertIsNone(self.edit(sources,inspect))
