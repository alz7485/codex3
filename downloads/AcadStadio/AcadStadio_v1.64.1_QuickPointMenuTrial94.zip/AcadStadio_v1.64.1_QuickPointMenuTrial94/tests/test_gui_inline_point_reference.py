"""Floating point picker shares the editor preview and preserves draft isolation."""
import copy
import os
import sys
import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project


@unittest.skipUnless(sys.platform == 'win32' or os.environ.get('DISPLAY'), 'GUI display unavailable')
class InlinePointReferenceGui(unittest.TestCase):
    def setUp(self):
        gui.Gui.setUp(self)
        from legacy_catalog_fixture import legacy_catalog
        self.app.data['custom_commands']=legacy_catalog()
        self.app.refresh()
    tearDown = gui.Gui.tearDown

    def test_preview_line_click_then_point_click_applies_and_exits(self):
        sources = [dict(type='LINE', x1='0', y1='0', x2='100', y2='0'),
                   dict(type='LINE', x1='0', y1='40', x2='100', y2='40')]
        def inspect():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                win.geometry('1320x860');win.refresh_command_preview();self.root.update()
                canvas = win.command_preview.canvas
                camera = (canvas.view_ratio, list(canvas.pan))
                preview_bounds=(canvas.winfo_rootx(),canvas.winfo_rooty(),canvas.winfo_width(),canvas.winfo_height())
                tops = [w for w in gui.descendants(self.root) if isinstance(w, tk.Toplevel)]
                def click(point):
                    x, y = canvas.screen_point(point)
                    canvas.event_generate('<ButtonPress-1>', x=round(x), y=round(y))
                    canvas.event_generate('<ButtonRelease-1>', x=round(x), y=round(y))
                    self.root.update()
                click((30, 0));panel = win.point_panel
                self.assertIsInstance(panel,tk.Toplevel)
                self.assertEqual(str(panel.transient()),str(win))
                self.assertIs(win.grab_current(),win)
                self.assertEqual(set(tops)|{panel},{w for w in gui.descendants(self.root) if isinstance(w,tk.Toplevel)})
                self.assertEqual((canvas.winfo_rootx(),canvas.winfo_rooty(),canvas.winfo_width(),canvas.winfo_height()),preview_bounds)
                self.assertTrue(win.command_viewport.winfo_ismapped())
                self.assertIsInstance(panel.point_picker, ttk.Combobox)
                self.assertFalse(hasattr(panel, 'point_segments'))
                self.assertFalse(panel.axis_picker.winfo_ismapped())
                self.assertEqual(tuple(panel.axis_segments.buttons),('XY','X','Y'))
                for button in panel.axis_segments.buttons.values():
                    self.assertTrue(button.winfo_ismapped())
                    self.assertLessEqual(button.winfo_rootx()+button.winfo_width(),panel.winfo_rootx()+panel.winfo_width())
                self.assertLessEqual(panel.winfo_width(),380)
                self.assertGreaterEqual(panel.winfo_rootx(),canvas.winfo_rootx())
                self.assertGreater(panel.winfo_rooty(),canvas.winfo_rooty()+canvas.winfo_height()/4)
                click((30, 40))
                self.assertEqual(panel.source_picker.current(), 1)
                click((100, 40))
                self.assertEqual(panel.point_picker.get(), '終点')
                win.coordinate_values['x'].movement.set('-10')
                gui.use_reference_and_finish(panel);self.root.update()
                self.assertFalse(panel.winfo_exists())
                self.assertEqual((canvas.view_ratio, list(canvas.pan)), camera)
                self.assertEqual(str(win.command_entries['x'].cget('state')), 'normal')
                gui.button(win, 'コマンドを反映').invoke()
            except Exception as exc:
                self.errors.append(exc);win.destroy()
        self.root.after(100, inspect)
        result = edit_command(self.root, dict(type='POINT', x='150', y='100'),
                              self.app.data['blocks'], self.app.data, point_sources=sources)
        project = copy.deepcopy(self.app.data)
        project['blocks'] = [dict(project['blocks'][0], commands=sources + [result])]
        self.assertEqual(compile_project(project, [0])[1][-1]['coords'], (90, 40))

    def test_shared_table_action_targets_parent_movement_field(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.movement_entries['y'].focus_force();self.root.update()
                with patch('macro_editor.show_table_reference_picker',side_effect=lambda parent,project,*args,**kw:args[0]('@OD')):
                    win.movement_entries['y'].reference_buttons[0].invoke()
                self.assertEqual(win.coordinate_values['y'].movement.get(),'@OD')
                self.assertEqual(win.command_entries['y'].get(),'100')
                win.choose_command_point('x',both=True);self.root.update();panel=win.point_panel
                self.assertFalse(hasattr(panel,'point_offsets'))
                panel.source_picker.focus_force();panel.event_generate('<Escape>');self.root.update()
                self.assertFalse(panel.winfo_exists())
                self.assertEqual(win.coordinate_values['y'].movement.get(),'@OD')
            except Exception as exc:self.errors.append(exc)
            finally:win.destroy()
        self.root.after(100,inspect)
        edit_command(self.root,dict(type='POINT',x='150',y='100'),self.app.data['blocks'],self.app.data,point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')])

    def test_non_coordinate_focus_uses_last_coordinate_and_main_apply_commits_reference(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                win.command_entries['r'].focus_force();self.root.update()
                canvas=win.command_preview.canvas;x,y=canvas.screen_point((30,0))
                canvas.event_generate('<ButtonPress-1>',x=round(x),y=round(y))
                canvas.event_generate('<ButtonRelease-1>',x=round(x),y=round(y));self.root.update()
                panel=win.point_panel
                panel.point_picker.set('終点');panel.point_picker.event_generate('<<ComboboxSelected>>')
                win.coordinate_values['y'].movement.set('5')
                self.assertTrue(gui.button(win,'コマンドを反映').instate(('disabled',)))
                gui.use_reference_and_finish(panel);self.root.update()
                self.assertFalse(panel.winfo_exists())
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='CIRCLE',x='150',y='100',r='7'),
                            self.app.data['blocks'],self.app.data,point_sources=sources)
        project=copy.deepcopy(self.app.data)
        project['blocks']=[dict(project['blocks'][0],commands=sources+[result])]
        self.assertEqual(compile_project(project,[0])[1][-1]['coords'],(100,5,7))

    def test_custom_argument_reference_selects_only_source_point(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                self.root.update();self.assertFalse(win.coordinate_toolbar.winfo_ismapped())
                win.choose_command_point('arg:VALUE');self.root.update();panel=win.point_panel
                self.assertFalse(hasattr(panel,'point_offsets'))
                panel.point_picker.set('終点');panel.point_picker.event_generate('<<ComboboxSelected>>')
                gui.use_reference_and_finish(panel);self.root.update()
                self.assertIn('点(',win.command_entries['arg:VALUE'].get())
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='CUSTOM',name='set_ltscale',arguments={'VALUE':'1'}),self.app.data['blocks'],self.app.data,point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')])
        self.assertIn('点(',result['arguments']['VALUE'])

    def test_accept_button_enter_and_context_menu_advance_to_next_x(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]
        for method in ('button','enter','keypad','editor_enter','editor_keypad','menu'):
            def inspect(method=method):
                win=gui.top(self.root,'コマンドの設定')
                try:
                    win.refresh_command_preview();self.root.update()
                    win.choose_command_point('x1',both=True);self.root.update()
                    panel=win.point_panel
                    panel.point_picker.set('始点')
                    if method=='button':gui.use_reference_and_finish(panel)
                    elif method in ('enter','keypad','editor_enter','editor_keypad'):
                        panel.source_picker.focus_force();self.root.update()
                        target=win if method.startswith('editor_') else panel.source_picker
                        target.event_generate('<KP_Enter>' if 'keypad' in method else '<Return>')
                    else:
                        with patch.object(tk.Menu,'tk_popup',lambda menu,*args:menu.invoke(0)):
                            win.command_preview.canvas.event_generate('<Button-3>',x=50,y=50)
                    self.root.update()
                    gui.finish_reference_session(win)
                    self.root.update()
                    self.assertFalse(panel.winfo_exists())
                    self.assertIs(win.focus_get(),win.command_entries['x2'])
                    gui.button(win,'キャンセル').invoke()
                except Exception as exc:self.errors.append(exc);win.destroy()
            self.root.after(80,inspect)
            edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='50',y2='50'),self.app.data['blocks'],self.app.data,point_sources=sources)

    def test_axis_highlights_and_adding_vertex_collapses_previous_points(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                win.choose_command_point('x1',both=True);self.root.update();panel=win.point_panel
                self.assertIsInstance(panel,tk.Toplevel)
                for axis in ('X','Y','XY'):
                    panel.axis_segments.choose(axis);self.root.update()
                    for component in ('x','y'):
                        self.assertEqual(win.coordinate_axis_frames[component+'1']._card_focused,axis in ('XY',component.upper()))
                win.close_point_panel();self.root.update()
                win.add_vertex();self.root.update()
                self.assertFalse(win.command_entries['x1'].winfo_ismapped())
                self.assertFalse(win.command_entries['x2'].winfo_ismapped())
                self.assertTrue(win.command_entries['x3'].winfo_ismapped())
                gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='50',y2='50'),self.app.data['blocks'],self.app.data,point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')])

    def test_window_close_cancels_and_reopening_restores_parent_bindings(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]
        baseline=copy.deepcopy(sources)
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                canvas=win.command_preview.canvas
                parent_return=win.bind('<Return>').strip()
                parent_keypad=win.bind('<KP_Enter>').strip()
                canvas_context=canvas.bind('<Button-3>').strip()
                for _ in range(2):
                    win.choose_command_point('x1',both=True);self.root.update();panel=win.point_panel
                    panel.point_picker.set('終点')
                    panel.tk.eval(panel.protocol('WM_DELETE_WINDOW'));self.root.update()
                    self.assertFalse(panel.winfo_exists())
                    self.assertTrue(win.winfo_exists())
                    self.assertEqual(win.command_entries['x1'].get(),'0')
                    self.assertEqual(win.command_entries['y1'].get(),'0')
                    self.assertEqual(win.bind('<Return>').strip(),parent_return)
                    self.assertEqual(win.bind('<KP_Enter>').strip(),parent_keypad)
                    self.assertEqual(canvas.bind('<Button-3>').strip(),canvas_context)
                    self.assertIs(win.grab_current(),win)
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='50',y2='50'),self.app.data['blocks'],self.app.data,point_sources=sources)
        self.assertEqual(result['x1'],'0')
        self.assertEqual(sources,baseline)

    def test_cancel_intersection_draft_does_not_register_source_ids(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),dict(type='LINE',x1='50',y1='-50',x2='50',y2='50')]
        baseline=copy.deepcopy(sources)
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                win.choose_command_point('x',both=True);self.root.update();panel=win.point_panel
                controls=panel.relation_controls
                controls.mode.set('交点');controls.mode.event_generate('<<ComboboxSelected>>');self.root.update()
                self.assertTrue(panel.point_preview.points)
                panel.source_picker.focus_force();self.root.update()
                panel.source_picker.event_generate('<Escape>');self.root.update()
                self.assertFalse(panel.winfo_exists())
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x='150',y='100'),self.app.data['blocks'],self.app.data,point_sources=sources)
        self.assertEqual(result['x'],'150');self.assertEqual(result['y'],'100')
        self.assertEqual(sources,baseline)

    def test_destroying_editor_with_point_window_pending_cleans_up(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                win.choose_command_point('x',both=True);self.root.update();panel=win.point_panel
                panel.point_preview.row.set('2')
                win.destroy();self.root.update()
                self.assertFalse(panel.winfo_exists())
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x='150',y='100'),self.app.data['blocks'],self.app.data,point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')])
        self.assertIsNone(result)

    def test_single_axis_selection_from_y_field_updates_selected_x_only(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                win.choose_command_point('y1',both=False);self.root.update();panel=win.point_panel
                panel.point_picker.set('終点');panel.axis_segments.choose('X');self.root.update()
                gui.use_reference_and_finish(panel);self.root.update()
                self.assertIn('点(',win.command_entries['x1'].get())
                self.assertEqual(win.command_entries['y1'].get(),'25')
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='0',y1='25',x2='50',y2='50'),self.app.data['blocks'],self.app.data,point_sources=sources)
        project=copy.deepcopy(self.app.data);project['blocks']=[dict(project['blocks'][0],commands=sources+[result])]
        self.assertEqual(compile_project(project,[0])[1][-1]['coords'][:2],(100,25))

    def test_nested_reference_pickers_return_grab_to_editor_for_preview(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                win.choose_command_point('x',both=True);self.root.update();panel=win.point_panel
                panel.point_picker.set('上');panel.point_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                for kind,title in [('table','表から参照を選ぶ'),('variable','列・変数の一覧')]:
                    def cancel_picker(title=title):
                        picker=gui.top(self.root,title)
                        try:
                            self.assertIs(picker.grab_current(),picker)
                            gui.button(picker,'キャンセル').invoke()
                        except Exception as exc:self.errors.append(exc);picker.destroy()
                    self.root.after(80,cancel_picker)
                    panel.choose_angle(kind);self.root.update()
                    self.assertTrue(panel.winfo_exists())
                    self.assertIs(win.grab_current(),win)
                win.close_point_panel();self.root.update()
                gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        edit_command(self.root,dict(type='POINT',x='150',y='100'),self.app.data['blocks'],self.app.data,point_sources=[dict(type='CIRCLE',x='0',y='0',r='50')])

    def test_invalid_point_keeps_window_and_draft_unchanged(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')];baseline=copy.deepcopy(sources)
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.choose_command_point('x',both=True);self.root.update();panel=win.point_panel
                panel.point_picker.set('存在しない点');panel.point_picker.event_generate('<<ComboboxSelected>>')
                gui.button(panel,'この点を使用').invoke();self.root.update()
                self.assertTrue(panel.winfo_exists());self.assertEqual(win.command_entries['x'].get(),'150')
                gui.button(panel,'キャンセル').invoke();gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x='150',y='100'),self.app.data['blocks'],self.app.data,point_sources=sources)
        self.assertEqual(result['x'],'150');self.assertEqual(result['y'],'100');self.assertEqual(sources,baseline)

    def test_picker_readout_is_source_point_without_parent_movement(self):
        sources=[dict(type='LINE',x1='0',y1='10',x2='100',y2='40')]
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.coordinate_values['x'].movement.set('-10');win.coordinate_values['y'].movement.set('5')
                win.choose_command_point('x',both=True);self.root.update();panel=win.point_panel
                panel.point_picker.set('終点');panel.point_picker.event_generate('<<ComboboxSelected>>')
                panel.axis_segments.choose('X');self.root.update()
                self.assertEqual(panel.result_card.values['X'].cget('text'),'100')
                self.assertFalse(panel.result_card.rows['Y'].winfo_ismapped())
                panel.axis_segments.choose('XY');self.root.update()
                self.assertEqual(panel.result_card.values['Y'].cget('text'),'40')
                gui.use_reference_and_finish(panel);gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x='25',y='60'),self.app.data['blocks'],self.app.data,point_sources=sources)
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=sources+[result])]
        self.assertEqual(compile_project(p,[0])[1][-1]['coords'],(90,45))

    def test_accept_unfolds_next_point_before_moving_focus(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.add_vertex();self.root.update()
                self.assertFalse(win.command_entries['x1'].winfo_ismapped())
                self.assertFalse(win.command_entries['x2'].winfo_ismapped())
                win.coordinate_cards['1'].point_header.set_expanded(True);self.root.update()
                self.assertTrue(win.command_entries['x1'].winfo_ismapped())
                win.choose_command_point('x1',both=True);self.root.update();panel=win.point_panel
                panel.point_picker.set('始点')
                gui.use_reference_and_finish(panel);self.root.update()
                self.assertFalse(panel.winfo_exists())
                self.assertTrue(win.command_entries['x2'].winfo_ismapped())
                self.assertIs(win.focus_get(),win.command_entries['x2'])
                gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='50',y2='50'),self.app.data['blocks'],self.app.data,point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')])

    def test_basic_x_window_is_compact_and_starts_lower_on_preview(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.geometry('1320x860');win.refresh_command_preview();self.root.update()
                canvas=win.command_preview.canvas
                bounds=(canvas.winfo_rootx(),canvas.winfo_rooty(),canvas.winfo_width(),canvas.winfo_height())
                win.choose_command_point('x',both=False);self.root.update();panel=win.point_panel
                self.assertEqual(panel.axis_picker.get(),'X')
                self.assertLessEqual(panel.winfo_width(),380)
                self.assertLessEqual(panel.winfo_height(),250)
                self.assertGreaterEqual(panel.winfo_rootx(),canvas.winfo_rootx())
                self.assertGreater(panel.winfo_rooty(),canvas.winfo_rooty()+canvas.winfo_height()/4)
                self.assertLessEqual(panel.winfo_rooty()+panel.winfo_height(),canvas.winfo_rooty()+canvas.winfo_height())
                self.assertEqual((canvas.winfo_rootx(),canvas.winfo_rooty(),canvas.winfo_width(),canvas.winfo_height()),bounds)
                for label in ('キャンセル','この点を使用'):
                    button=gui.button(panel,label)
                    self.assertTrue(button.winfo_ismapped())
                    self.assertLessEqual(button.winfo_rooty()+button.winfo_height(),panel.winfo_rooty()+panel.winfo_height())
                win.close_point_panel();gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,inspect)
        edit_command(self.root,dict(type='POINT',x='150',y='100'),self.app.data['blocks'],self.app.data,point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')])
