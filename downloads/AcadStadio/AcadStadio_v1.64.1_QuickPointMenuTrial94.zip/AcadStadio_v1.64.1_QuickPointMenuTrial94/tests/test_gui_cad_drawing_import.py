"""Real Tk review/apply/cancel with an actual synthetic DXF extraction snapshot.

The parser itself is tested with ezdxf in test_cad_drawing_import; the GUI fixture
runs on a separate Python installation and only mocks the background file reader.
"""
import copy
import json
import os
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import patch
import test_gui as gui
from cad_setup_editor import CadSetupEditor
from cad_setup import initial_macro


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class DrawingImportGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def snapshot(self):
        return json.loads((Path(__file__).resolve().parents[1]/'examples'/'CAD読込サンプル'/'import_snapshot.json').read_text(encoding='utf-8'))

    def wait(self, dialog):
        deadline=time.monotonic()+3
        while dialog.job is not None and time.monotonic()<deadline:
            self.root.update();time.sleep(0.01)
        self.assertIsNone(dialog.job)

    def read(self, project_mode):
        dialog=self.app.import_cad_drawing(project_mode)
        snapshot=self.snapshot()
        if not project_mode:snapshot['cad_setup']=None
        with patch('cad_drawing_import_ui.read_cad_drawing',return_value=snapshot) as reader:
            dialog.path.set('CAD_import_example.dxf');dialog.read();self.wait(dialog)
        reader.assert_called_once_with('CAD_import_example.dxf',include_settings=project_mode)
        self.assertIsNotNone(dialog.snapshot);return dialog

    def test_new_project_three_blocks_dirty_and_actual_preview(self):
        before=copy.deepcopy(self.app.data);dialog=self.read(True)
        self.assertEqual(self.app.data,before);self.assertEqual(len(dialog.command_tree.get_children()),3)
        self.assertEqual(len(dialog.canvas.items),16)
        with patch.object(self.app,'confirm_discard',return_value=True):dialog.apply()
        self.root.update()
        self.assertEqual(len(self.app.data['blocks']),3);self.assertTrue(self.app.has_unsaved_changes())
        self.assertIsNone(self.app.path);self.assertEqual(self.app.data['cad_setup']['drawing_variables']['LTSCALE'],'2.5')
        self.assertEqual(len(self.app.rows),1);self.assertEqual(self.messages,[])

    def test_append_leaves_settings_tables_and_variables_unchanged_and_can_undo(self):
        before=copy.deepcopy(self.app.data);tables=self.app.data['input_tables'];setup=self.app.data['cad_setup']
        dialog=self.read(False);dialog.apply();self.root.update()
        self.assertIs(self.app.data['input_tables'],tables);self.assertIs(self.app.data['cad_setup'],setup)
        for key in before:
            if key!='blocks':self.assertEqual(self.app.data[key],before[key])
        self.assertEqual(len(self.app.data['blocks']),len(before['blocks'])+3)
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,before)
        self.assertEqual(self.messages,[])

    def test_cancel_failed_read_and_stale_read_guard(self):
        before=copy.deepcopy(self.app.data);dialog=self.read(True);dialog.close();self.assertEqual(self.app.data,before)
        dialog=self.app.import_cad_drawing(False);dialog.path.set('broken.dxf')
        with patch('cad_drawing_import_ui.read_cad_drawing',side_effect=ValueError('invalid')):
            dialog.read();self.wait(dialog)
        self.assertIsNone(dialog.snapshot);self.assertEqual(str(dialog.apply_button.cget('state')),'disabled')
        self.assertEqual(self.app.data,before);dialog.close()

    def test_imported_settings_editor_retains_pattern_and_edits_drawing_values(self):
        self.app.data['cad_setup']=self.snapshot()['cad_setup'];editor=CadSetupEditor(self.app);self.root.update()
        row=next(r for r in editor.data['linetypes'] if r['name']=='IMPORTED_DASH')
        self.assertFalse(row['existing_only']);self.assertEqual(row['pattern'],['8','-4'])
        editor.drawing_variables['LTSCALE'].set('3.25');editor.commit();self.root.update()
        self.assertEqual(self.app.data['cad_setup']['drawing_variables']['LTSCALE'],'3.25')
        self.assertIn('(49 . -4)','\n'.join(initial_macro(self.app.data['cad_setup'])))
        self.assertEqual(self.messages,[])

    def test_layout_option_is_forwarded_and_tabs_show_imported_layout(self):
        from block_model import new_block
        snapshot=self.snapshot()
        for block in snapshot['blocks']:block['drawing_space']='Model'
        snapshot['blocks'].append(new_block('A4作成',commands=[dict(type='LAYOUT',layout_name='A4')]))
        dialog=self.app.import_cad_drawing(True);dialog.include_layouts.set(True)
        with patch('cad_drawing_import_ui.read_cad_drawing',return_value=snapshot) as reader:
            dialog.path.set('layout.dxf');dialog.read();self.wait(dialog)
        reader.assert_called_once_with('layout.dxf',include_settings=True,include_layouts=True)
        self.assertIn('A4',dialog.canvas.space_tabs.pages)
        dialog.close()
