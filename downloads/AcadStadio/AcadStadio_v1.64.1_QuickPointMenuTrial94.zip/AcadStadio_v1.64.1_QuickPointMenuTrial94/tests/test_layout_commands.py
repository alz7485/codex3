import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from layout_commands import render,validate_batch
from sample_project import EXAMPLE
from engine import compile_project,MacroError
from test_cad_state import read_form,walk

class LayoutCommands(unittest.TestCase):
 def compile(self,commands,rows=[0]):
  p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=commands)];return compile_project(p,rows)
 def test_all_layout_modes_are_complete_single_line_lisp(self):
  commands=[dict(type='SPACE',space_mode='モデル空間'),dict(type='SPACE',space_mode='レイアウト空間',layout_name='図面 1'),dict(type='SPACE',space_mode='ビューポート内',layout_name='図面 1',viewport_id='3')]
  commands += [dict(type='LAYOUT',layout_action=action,layout_name='図面 2',source_layout='図面 1') for action in ('作成して選択','選択','複製','名前を変更')]
  commands += [dict(type='VIEWPORT',viewport_action=action,x1='0',y1='0',x2='200',y2='100',viewport_id='3',view_scale='1/50') for action in ('矩形を作成','アクティブにする','ロック','ロック解除','表示中心・尺度')]
  for command in commands:
   with self.subTest(command=command):
    script,items=self.compile([command]);self.assertEqual(len(items),1 if command['type']=='VIEWPORT' and command.get('viewport_action')=='矩形を作成' else 0)
    for line in script.splitlines():
     if line.startswith('('):
      for node in walk(read_form(line)):
       if node and node[0]=='if':self.assertIn(len(node),(3,4))
 def test_batch_resolves_expressions_and_includes_snapshot_names(self):
  command=dict(type='SYSVARS',items=[dict(name='PICKFIRST',value_kind='number',value='1'),dict(name='USERR1',value_kind='number',value='2*3'),dict(name='USERS1',value_kind='text',value='a b')])
  script,items=self.compile([command]);self.assertEqual(len(items),1 if command['type']=='VIEWPORT' and command.get('viewport_action')=='矩形を作成' else 0)
  self.assertIn('_.SETVAR\nUSERR1\n6',script);self.assertIn('"USERR1"',script);self.assertIn('"USERS1"',script)
 def test_batch_once_vs_per_row(self):
  base=dict(type='SYSVARS',items=[dict(name='USERR1',value='5')])
  self.assertEqual(self.compile([dict(base,execution='once')],[0,1])[0].count('_.SETVAR\nUSERR1\n5'),1)
  self.assertEqual(self.compile([base],[0,1])[0].count('_.SETVAR\nUSERR1\n5'),2)
 def test_bad_batch_and_viewport_are_rejected(self):
  for items in ([],[dict(name='A B',value='1')],[dict(name='OSMODE',value='1'),dict(name='osmode',value='0')]):
   with self.assertRaises(ValueError):validate_batch(items)
  for command in [dict(type='VIEWPORT',viewport_action='ロック',viewport_id='1'),dict(type='VIEWPORT',x1='0',y1='0',x2='0',y2='5'),dict(type='SPACE',space_mode='誤り')]:
   with self.assertRaises(MacroError):self.compile([command])
 def test_creating_layout_reuses_existing_name_and_does_not_delete(self):
  script,_=self.compile([dict(type='LAYOUT',layout_name='図面')])
  self.assertIn('(if (not (member "図面" (layoutlist)))',script)
  self.assertNotIn('"_Delete"',script)
