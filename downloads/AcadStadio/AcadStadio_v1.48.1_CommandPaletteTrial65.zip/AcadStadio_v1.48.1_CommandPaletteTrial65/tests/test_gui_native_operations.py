"""Real command-editor forms and editing-result previews for the six additions."""
import copy,os,sys,unittest
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project
from test_native_operations import command

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class NativeOperationsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_six_forms_apply_with_references_and_vertex_addition(self):
        for kind in ('HATCH','SPLINE','INSERT','LEADER','OFFSET','TRIM'):
            def inspect(kind=kind):
                w=gui.top(self.root,'コマンドの設定')
                try:
                    if kind=='HATCH':
                        w.remove_vertex(1);self.root.update();self.assertEqual(len(w.vertex_rows),3)
                        w.remove_vertex(1);self.root.update();self.assertEqual(len(w.vertex_rows),3)
                        w.refresh_command_preview();self.root.update()
                        canvas=w.command_preview.canvas
                        polygons=[n for n in canvas.find_withtag('geometry') if canvas.type(n)=='polygon']
                        self.assertTrue(polygons);self.assertTrue(all(canvas.itemcget(n,'fill')=='' for n in polygons))
                    if kind=='INSERT':w.command_entries['block_name'].insert(0,'機械部品')
                    if kind in ('SPLINE','LEADER'):
                        old=len(w.vertex_rows);w.add_vertex();self.root.update();self.assertEqual(len(w.vertex_rows),old+1)
                        for axis in ('x','y'):w.command_entries[axis+str(old+1)].insert(0,'@X+100' if axis=='x' else '@Y+60')
                    self.assertTrue(w.command_entries['x2' if kind in ('OFFSET','TRIM') else 'x' if kind=='INSERT' else 'x1'].reference_button.winfo_ismapped())
                    gui.button(w,'コマンドを反映').invoke()
                except Exception as exc:self.errors.append(exc);w.destroy()
            self.root.after(100,inspect)
            result=edit_command(self.root,command(kind),self.app.data['blocks'],self.app.data)
            self.assertIsNotNone(result,kind)
            p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=result if isinstance(result,list) else [result])]
            _,items=compile_project(p,[0]);self.assertEqual(items[-1]['type'],kind)
    def test_trim_preview_replaces_line_and_offset_preview_is_a_curve(self):
        source=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),dict(type='LINE',x1='40',y1='-20',x2='40',y2='20')]
        for kind,extra in [('TRIM',{}),('OFFSET',dict(distance='10'))]:
            current=dict(type=kind,x1='40' if kind=='TRIM' else '50',y1='10' if kind=='TRIM' else '0',x2='80',y2='0' if kind=='TRIM' else '20',pick_tolerance='0.01',**extra)
            def inspect(kind=kind):
                w=gui.top(self.root,'コマンドの設定')
                try:
                    w.refresh_command_preview();self.root.update()
                    items=w.command_preview.canvas.items
                    if kind=='TRIM':self.assertEqual(items[0]['coords'],(0.,0.,40.,0.))
                    else:self.assertEqual(items[-1]['display_type'],'LINE')
                    self.assertTrue(w.command_preview.canvas.find_withtag('geometry'))
                except Exception as exc:self.errors.append(exc)
                w.destroy()
            self.root.after(180,inspect);edit_command(self.root,current,self.app.data['blocks'],self.app.data,point_sources=source)
