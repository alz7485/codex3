"""Additional native CAD commands and their honest preview geometry."""
import json
import math
from cad_setup import cad_name
from vertex_points import read_vertices

from advanced_commands import TYPES as ADVANCED_TYPES

TYPES = ADVANCED_TYPES | frozenset(('HATCH', 'SPLINE', 'INSERT', 'LEADER', 'OFFSET', 'TRIM', 'EXTEND', 'COPY', 'MIRROR'))
VERTEX_TYPES = ('LINE', 'POLYLINE', 'HATCH', 'SPLINE', 'LEADER')


def quoted(value):
    return json.dumps(str(value), ensure_ascii=False)


def fit_curve(points):
    """Interpolating Catmull-Rom preview; CAD's native fit spline may differ."""
    result=[]
    for i in range(len(points)-1):
        a,b,c,d=points[max(0,i-1)],points[i],points[i+1],points[min(len(points)-1,i+2)]
        for step in range(16):
            t=step/16
            result.append(tuple(.5*((2*b[k])+(-a[k]+c[k])*t+(2*a[k]-5*b[k]+4*c[k]-d[k])*t*t+(-a[k]+3*b[k]-3*c[k]+d[k])*t*t*t) for k in (0,1)))
    return result+[points[-1]]


def polygon_valid(points):
    if len(points)<3 or len(points)>500:
        raise ValueError('ハッチング境界は3〜500点で指定してください')
    if len(set(points))!=len(points):
        raise ValueError('ハッチング境界の頂点は重複できません。最後に始点を再入力する必要はありません')
    area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(points,points[1:]+points[:1]))
    if abs(area)<1e-10:raise ValueError('ハッチング境界の面積が0です')
    def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    def touches(a,b,c,d):
        ca,cb,cc,cd=cross(a,b,c),cross(a,b,d),cross(c,d,a),cross(c,d,b)
        if ca*cb<0 and cc*cd<0:return True
        return any(abs(v)<1e-10 and min(p[0],q[0])-1e-10<=r[0]<=max(p[0],q[0])+1e-10 and min(p[1],q[1])-1e-10<=r[1]<=max(p[1],q[1])+1e-10 for v,p,q,r in [(ca,a,b,c),(cb,a,b,d),(cc,c,d,a),(cd,c,d,b)])
    edges=list(zip(points,points[1:]+points[:1]))
    for i,(a,b) in enumerate(edges):
        for j in range(i+1,len(edges)):
            if j==i+1 or (i==0 and j==len(edges)-1):continue
            if touches(a,b,*edges[j]):raise ValueError('ハッチング境界は交差・接触しない単一の閉じた形にしてください')


def selection_lisp(x,y,tolerance,destination, *, general=False, entity_types=None):
    # Find curves by geometry rather than screen pixels or current zoom. Abort
    # on ambiguity instead of silently choosing the first overlapping entity.
    extra = ''
    if general:
        extra = (
            '(setq data (entget e) kind (cdr (assoc 0 data))) '
            '(cond ((member kind (list "INSERT" "TEXT" "MTEXT" "POINT" "CIRCLE" "ARC" "ELLIPSE")) '
            '(setq anchor (cdr (assoc 10 data))) '
            f'(if (and anchor (<= (distance (trans anchor e 0) p) {tolerance:.12g})) (setq q p))) '
            '((member kind (list "HATCH" "LEADER")) (setq boundary nil) '
            '(foreach pair data (cond ((= (car pair) 92) (setq boundary T)) ((= (car pair) 97) (setq boundary nil))) '
            f'(if (and (= (car pair) 10) (or boundary (= kind "LEADER")) (<= (distance (trans (cdr pair) e 0) p) {tolerance:.12g})) (setq q p))))) '
        )
    kinds=entity_types or ('LINE,ARC,CIRCLE,LWPOLYLINE,POLYLINE,SPLINE,ELLIPSE'+(',INSERT,TEXT,MTEXT,POINT,HATCH,LEADER' if general else ''))
    return (
        f'(setq ss (ssget "_X" (list (cons 0 "{kinds}") (cons 410 (if (= (getvar "CVPORT") 1) (getvar "CTAB") "Model"))))) '
        f'(setq found nil i 0 p (list {x:.12g} {y:.12g} 0.0)) '
        '(if ss (repeat (sslength ss) (setq e (ssname ss i) i (1+ i)) '
        '(setq q (vl-catch-all-apply \'vlax-curve-getClosestPointTo (list e p))) '
        + extra +
        f'(if (and (not (vl-catch-all-error-p q)) q (<= (distance q p) {tolerance:.12g})) (setq found (cons e found))))) '
        '(if (/= (length found) 1) (error "AcadStadio: Selection must identify exactly one curve; adjust pick point or tolerance")) '
        f'(setq {destination} (car found)) '
    )


def current_properties_lisp(destination, fields=None):
    fields = {"layer", "color", "linetype", "linetype_scale"} if fields is None else fields
    color = (
        f'(setq cc (strcase (getvar "CECOLOR"))) '
        '(if (wcmatch cc "RGB:*") '
        f'(progn (setq rgb (read (strcat "(" (vl-string-translate "," " " (substr cc 5)) ")")) clr (vla-get-TrueColor {destination})) '
        '(vla-SetRGB clr (car rgb) (cadr rgb) (caddr rgb)) '
        f'(vla-put-TrueColor {destination} clr)) '
        f'(vla-put-Color {destination} (cond ((= cc "BYLAYER") 256) ((= cc "BYBLOCK") 0) (T (atoi cc))))) '
    )
    return (
        (f'(vla-put-Layer {destination} (getvar "CLAYER")) ' if 'layer' in fields else '')
        + (color if 'color' in fields else '')
        + (f'(vla-put-Linetype {destination} (getvar "CELTYPE")) ' if 'linetype' in fields else '')
        + (f'(vla-put-LinetypeScale {destination} (getvar "CELTSCALE")) ' if 'linetype_scale' in fields else '')
    )


def render(command, values, number):
    typ=command['type'].upper()
    if typ in ADVANCED_TYPES:
        from advanced_commands import render as render_advanced
        return render_advanced(command,values,number)
    n=lambda key,default='0':float(number(command.get(key,default),values))
    point=lambda suffix='':(n('x'+suffix),n('y'+suffix))
    flat=lambda points:tuple(c for p in points for c in p)
    lp=lambda p:f'(list {p[0]:.12g} {p[1]:.12g} 0.0)'
    token=lambda p:f'{p[0]:.12g},{p[1]:.12g}'
    lines=[];item={}
    from range_selection import MODES, RANGE_TYPES, box_points, native_selection
    mode=command.get('selection_mode','point')
    if not isinstance(mode,str) or mode not in MODES:raise ValueError('選択方式が不正です')
    if mode!='point' and typ not in RANGE_TYPES:raise ValueError('このコマンドは範囲選択に対応していません')
    ranged=typ in RANGE_TYPES and mode!='point'
    named='selection_ref' in command
    if named:ranged=False
    box=box_points(command,number,values) if ranged else None
    if typ in ('HATCH','SPLINE','LEADER'):
        vertices=read_vertices(command)
        points=[(float(number(p['x'],values)),float(number(p['y'],values))) for p in vertices]
        if any(a==b for a,b in zip(points,points[1:])):raise ValueError('隣り合う点は異なる位置にしてください')
        item['coords']=flat(points)
        if typ=='SPLINE':
            lines=['_.SETVAR','SPLMETHOD','0','_.SETVAR','SPLKNOTS','0','_.SPLINE','_Method','_Fit','_Knots','_Chord']
            for p in points:lines+=['_non',token(p)]
            lines+=['','','']
            item.update(curve=flat(fit_curve(points)),preview_note='スプライン：近似プレビュー')
        elif typ=='LEADER':
            text=str(command.get('text','注記'))
            from table_references import is_single_table_reference
            if text.startswith('=') or is_single_table_reference(text):
                from engine import evaluate
                text=str(evaluate(text[1:] if text.startswith('=') else text,values))
            if not text or text[0].isspace() or any(ord(c)<32 or ord(c)==127 for c in text):raise ValueError('引出線の注記は空欄・先頭空白・改行を使用できません')
            height=n('height','settings.TEXT_HEIGHT')
            if height<=0:raise ValueError('文字高さは正数にしてください')
            lines=['_.SETVAR','DIMTXT',f'{height:.12g}','_.LEADER']
            lines+=['_non',token(points[0]),'_Format','_Straight','_Arrow','_Exit']
            for p in points[1:]:lines+=['_non',token(p)]
            lines+=['',text,'']
            item.update(text=text,height=height)
        else:
            polygon_valid(points)
            pattern=str(command.get('pattern','ANSI31'))
            import re
            if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,63}',pattern):raise ValueError('ハッチングパターン名を指定してください（例：ANSI31 / SOLID）')
            scale=n('scale','1');angle=n('angle')
            if scale<=0:raise ValueError('ハッチング尺度は正数にしてください')
            poly='(list \'(0 . "LWPOLYLINE") \'(100 . "AcDbEntity") \'(100 . "AcDbPolyline") '+f'(cons 90 {len(points)}) \'(70 . 1) '+' '.join(f'(cons 10 (list {x:.12g} {y:.12g}))' for x,y in points)+')'
            args='"_.-HATCH" "_Properties" '+quoted('_Solid' if pattern.upper()=='SOLID' else pattern)
            if pattern.upper()!='SOLID':args+=f' {scale:.12g} {angle:.12g}'
            args+=' "_Select" e "" ""'
            lines=['_.SETVAR','HPASSOC','0','_.SETVAR','HPLAYER','.', '_.SETVAR','HPCOLOR','.',
                '_.SETVAR','HPBACKGROUNDCOLOR','.', '_.SETVAR','HPANNOTATIVE','0',
                '((lambda (/ e before made result) '
                f'(if (not (entmake {poly})) (error "AcadStadio: Cannot create hatch boundary")) '
                '(setq e (entlast) before e) '
                f'(setq result (vl-catch-all-apply \'command-s (list {args}))) '
                '(setq made (entlast)) (entdel e) (if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
                '(if (or (eq before made) (not (equal (cdr (assoc 0 (entget made))) "HATCH"))) (error "AcadStadio: Hatch creation failed"))))']
            item.update(pattern=pattern,scale=scale,angle=angle,closed=True,preview_note='ハッチング：境界・概略パターン')
    elif typ=='INSERT':
        name=str(command.get('block_name',''))
        if name.startswith('='):
            from advanced_commands import text_value
            name=text_value(name,values)
        if not cad_name(name):raise ValueError('CADブロック名を指定してください')
        x,y=point();sx=n('scale_x','1');sy=n('scale_y','1');angle=n('angle')
        if sx<=0 or sy<=0:raise ValueError('ブロック挿入のX/Y尺度は正数にしてください')
        # A native insertion prompts differently for uniform and annotative
        # blocks. InsertBlock avoids those prompts and creates default attributes.
        lines=['((lambda (/ doc space result cc rgb clr) (vl-load-com) '
            f'(if (not (tblsearch "BLOCK" {quoted(name)})) (error "AcadStadio: CAD block definition is missing")) '
            '(setq doc (vla-get-ActiveDocument (vlax-get-acad-object))) '
            '(setq space (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))) '
            f'(setq result (vl-catch-all-apply \'vla-InsertBlock (list space (vlax-3d-point {lp((x,y))}) {quoted(name)} {sx:.12g} {sy:.12g} 1.0 {math.radians(angle):.12g}))) '
            '(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
            + current_properties_lisp('result') + '))']
        item.update(coords=(x,y),text=name,block_name=name,scale_x=sx,scale_y=sy,angle=angle,preview_note='ブロック挿入：位置のみ（形状はCADで確認）')
    else:
        first,second=point('1'),point('2');tolerance=n('pick_tolerance','0.01')
        if not 0<tolerance<=100:raise ValueError('選択許容差は0より大きく100以下にしてください')
        prefix='((lambda (/ ss i e p q found source target result before cc rgb clr) (vl-load-com) '+selection_lisp(*first,tolerance,'source')
        if typ in ('COPY','MIRROR'):
            third=point('3')
            if second==third:raise ValueError('基点と移動先／ミラー軸の2点は異なる位置にしてください')
            erase=n('erase_source','0')
            if erase not in (0,1):raise ValueError('元の図形を削除は0または1で指定してください')
            overrides={key for key in ('layer','color','linetype','linetype_scale') if str(command.get(key,'')).strip()}
            prefix='((lambda (/ ss i e p q found source target result before cc rgb clr data kind anchor boundary pair) (vl-load-com) '+selection_lisp(*first,tolerance,'source',general=True)
            if named:
                from selection_sets import reference_lisp
                prefix='((lambda (/ source target result before cc rgb clr data kind anchor boundary pair e) (vl-load-com) '+reference_lisp(command['selection_ref'],'source')
            elif ranged:
                prefix='((lambda (/ source target result before cc rgb clr data kind anchor boundary pair e) (vl-load-com) '+native_selection(box,mode,'source')
            if typ=='COPY':
                args=f'"_.COPY" source "" "_Mode" "_Single" "_non" {lp(second)} "_non" {lp(third)}'
            else:
                args=f'"_.MIRROR" source "" "_non" {lp(second)} "_non" {lp(third)} "_Yes"' if erase else f'"_.MIRROR" source "" "_non" {lp(second)} "_non" {lp(third)} "_No"'
                lines=['_.SETVAR','MIRRTEXT','0']
            lines += [prefix+'(setq before (entlast)) '
                f'(setq result (vl-catch-all-apply \'command-s (list {args}))) '
                '(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
                '(if (eq before (entlast)) (error "AcadStadio: Copy/mirror did not create an entity")) '
                + (('(setq e (entnext before)) (while e '+'(if (not (member (cdr (assoc 0 (entget e))) (list \"ATTRIB\" \"VERTEX\" \"SEQEND\"))) '+current_properties_lisp('(vlax-ename->vla-object e)',overrides)+') (setq e (entnext e))) ') if (ranged or named) and overrides else current_properties_lisp('(vlax-ename->vla-object (entlast))',overrides)) + '))']
            item.update(coords=flat([first,second,third]),erase_source=bool(erase),overrides=tuple(sorted(overrides)),preview_note=('コピー' if typ=='COPY' else 'ミラー')+'：対象と操作点（結果はCADで確認）')
        elif typ=='OFFSET':
            if named:
                from selection_sets import reference_lisp
                prefix='((lambda (/ ss i e p q found source target result before cc rgb clr chosen index) (vl-load-com) '+reference_lisp(command['selection_ref'],'chosen')+'(setq index 0) (repeat (sslength chosen) (setq source (ssname chosen index)) '
            distance=n('distance','10')
            if distance<=0 or first==second:raise ValueError('オフセット距離は正数、方向点は対象上の点と異なる位置にしてください')
            lines=[prefix+'(setq before (entlast)) '
                f'(setq result (vl-catch-all-apply \'command-s (list "_.OFFSET" "_Erase" "_No" "_Layer" "_Current" {distance:.12g} source "_non" {lp(second)} ""))) '
                '(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
                '(if (eq before (entlast)) (error "AcadStadio: Offset did not create a curve")) '
                + current_properties_lisp('(vlax-ename->vla-object (entlast))') + ('(setq index (1+ index)))) )' if named else '))')]
            item.update(distance=distance,coords=flat([first,second]),preview_note='オフセット：対象点→方向点（結果はCADで確認）')
        else:
            operation='EXTEND' if typ=='EXTEND' else 'TRIM'
            if named:
                from selection_sets import reference_lisp
                prefix='((lambda (/ ss i e p q found source target result before cc rgb clr) (vl-load-com) '+reference_lisp(command['selection_ref'],'source')
            elif ranged:
                prefix='((lambda (/ ss i e p q found source target result before cc rgb clr) (vl-load-com) '+native_selection(box,mode,'source',curves=True)
            lines=['_.SETVAR','TRIMEXTENDMODE','0','_.SETVAR','EDGEMODE','0','_.SETVAR','PROJMODE','0',
                prefix+selection_lisp(*second,tolerance,'target')+
                '(if (eq source target) (error "AcadStadio: Cutting edge and trimmed curve must differ")) '
                '(setq before (entget target)) '
                f'(setq result (vl-catch-all-apply \'command-s (list "_.{operation}" source "" (list target {lp(second)}) ""))) '
                '(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
                '(if (equal before (entget target)) (error "AcadStadio: Trim/extend did not modify target"))))']
            item.update(coords=flat([first,second]),preview_note=('延長：境界点→延長側の点' if typ=='EXTEND' else 'トリム：切断境界点→削除側の点')+'（結果はCADで確認）')
    if ranged:item.update(selection_box=box,selection_mode=mode)
    if named:item['selection_ref']=command['selection_ref']
    return lines,item


def hatch_segments(points, angle, scale):
    """Bounded, clipped parallel strokes for an indicative pattern preview."""
    a=math.radians(angle+45);u=(math.cos(a),math.sin(a));v=(-u[1],u[0])
    local=[(x*u[0]+y*u[1],x*v[0]+y*v[1]) for x,y in points]
    low=min(p[1] for p in local);high=max(p[1] for p in local)
    spacing=max(scale*3.175,(high-low)/200,1e-9);level=math.floor(low/spacing)*spacing;result=[]
    edges=list(zip(local,local[1:]+local[:1]))
    for _ in range(203):
        level+=spacing
        if level>high:break
        cuts=[]
        for p,q in edges:
            if (p[1]<=level<q[1]) or (q[1]<=level<p[1]):cuts.append(p[0]+(level-p[1])*(q[0]-p[0])/(q[1]-p[1]))
        cuts.sort()
        for l,r in zip(cuts[::2],cuts[1::2]):
            result.append(((l*u[0]+level*v[0],l*u[1]+level*v[1]),(r*u[0]+level*v[0],r*u[1]+level*v[1])))
    return result
