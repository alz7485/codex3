"""Uniform affine transforms of preview geometry, preserving CAD block contents."""
import copy,math,textwrap


def mtext_lines(text,width,height):
    columns=max(1,int(width/max(height*.7,1e-9)))
    return [line for paragraph in text.replace('\t','    ').split('\n') for line in (textwrap.wrap(paragraph,width=columns,replace_whitespace=False,drop_whitespace=True) or [''])]


def transform(source,point,scale=1.,turn=0.):
    kind=source.get('display_type',source['type']);c=source['coords']
    result={key:copy.deepcopy(value) for key,value in source.items() if key in ('layer','effective_layer','color','linetype','linetype_scale','text','height','width','angle','closed','pattern','scale','start_angle','sweep','block_name','block_definition','preview_note','reference_points')}
    result.update(type=kind,display_type=kind)
    flat=lambda values:tuple(z for p in zip(values[::2],values[1::2]) for z in point(p))
    if kind in ('CIRCLE','ARC'):
        result['coords']=(*point(c[:2]),c[2]*scale)
        if kind=='ARC':result['start_angle']=(source['start_angle']+turn)%360
    elif kind=='ELLIPSE':result.update(coords=(*point(c[:2]),c[2]*scale,c[3]*scale),angle=(source.get('angle',0)+turn)%360)
    elif kind in ('TEXT','MTEXT'):
        result.update(coords=(*point(c[:2]),c[2]*scale),angle=(source.get('angle',0)+turn)%360)
        if 'width' in source:result['width']=source['width']*scale
    elif kind in ('INSERT','POINT'):result['coords']=point(c[:2])
    elif kind=='RECTANGLE':
        x,y,u,v=c;result.update(display_type='POLYLINE',coords=flat((x,y,u,y,u,v,x,v)),closed=True,
            reference_points={'対角点1':point(c[:2]),'中心':point(((x+u)/2,(y+v)/2)),'対角点2':point(c[2:])})
    else:result['coords']=flat(c)
    if source.get('segments'):result['segments']=[flat(segment) for segment in source['segments']]
    if source.get('curve'):result['curve']=flat(source['curve'])
    if source.get('reference_points'):result['reference_points']={key:point(p) for key,p in source['reference_points'].items()}
    if kind=='HATCH':result.update(angle=(source.get('angle',0)+turn)%360,scale=source.get('scale',1)*scale)
    if kind=='LEADER':result['height']=source.get('height',3.5)*scale
    if source.get('block_geometry'):result['block_geometry']=[transform(child,point,scale,turn) for child in source['block_geometry']]
    return result


def visual_entities(items):
    """Explode only for display; the logical block remains one selectable entity."""
    for item in items:
        if item.get('block_geometry'):
            for child in visual_entities(item['block_geometry']):
                display=dict(child,_logical_parent=item)
                for key in ('row','block_index','command_index','command_path','command_addresses','definition_block_index','guide'):
                    if key in item:display[key]=item[key]
                yield display
        else:yield item
