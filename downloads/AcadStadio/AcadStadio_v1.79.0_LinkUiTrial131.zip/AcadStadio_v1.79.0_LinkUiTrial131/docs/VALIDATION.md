# 1.79.0-beta131の検証

- コア全583件成功。関連GUI4ファイル・12件成功。スモーク成功。GUI全件の今回の再実行はしていません。
- GUI対象：test_gui_link_workflow131（新規4件）、test_gui_link_assistance（3件）、test_gui_import_table_sample（2件）、test_gui_restored_release（3件）。
- 対象を指定せずに開いたときにコマンドを自動選択しないこと、初期表示で一覧・詳細・表の全列表示が閉じていることを確認。
- 実際のプレビューマウスイベントで円を選択し、半径を表の外径÷2へ紐づけ、変更前後の表示・適用前のデータ不変・適用・Undoを検証。
- 参照元の図形だけでは点を自動確定しないこと、表示された始点のクリックで試算を作り、別の対象を選び直せることを確認。
- 1100×740の窓で確認欄と適用ボタンが表示範囲に残り、左側をスクロールしても変更前後を確認できることを検証。各詳細欄の展開とモード切替も確認。
- 列の新規作成、入力取消、既存の固定値確認、表の使用先表示、文字参照の従来GUI回帰も成功。
- Linux / Python 3.13 / Tkで表の列・コマンドの点の実画面を確認。計算処理はlink_assistance.pyの既存実装を維持。
- Windows実操作・AutoCAD実機・EXEビルドは未確認です。

再実行例：

```text
python scripts/run_checks.py --mode core
python -m unittest discover -s tests -p test_gui_link_workflow131.py
python -m unittest discover -s tests -p test_gui_link_assistance.py
python -m unittest discover -s tests -p test_gui_import_table_sample.py
python -m unittest discover -s tests -p test_gui_restored_release.py
python tests/smoke_test.py
```

GUI検証にはTkと表示環境が必要です。依存のネイティブ拡張は使用するPythonの版に合わせてください。
