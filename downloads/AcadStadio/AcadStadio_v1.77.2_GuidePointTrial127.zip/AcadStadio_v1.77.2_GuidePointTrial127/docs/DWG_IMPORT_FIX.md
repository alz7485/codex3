# 1.74.1-beta115

公開DWGの検証で見つかった読込後のプレビュー停止を修正しました。

- 中心と同じ文字位置を持つ半径・直径寸法は、保存された寸法描画の文字位置をコマンドの位置に使用します。描画情報がないときは円周の定義点を使います。元の描画情報と指定済み文字位置は保持します。
- 自己交差するSOLID/TRACEは交点で2つの塗り潰しへ分割します。一般の不正ハッチングは読込時に理由を表示して除外し、他の図形の生成を止めません。明示的な終点と連続重複頂点は正規化します。
- 式入力の上限2048文字を超えるTEXT/MTEXTは、理由を表示して未登録とします。途中で切り詰めません。
- 無効なクリップ境界ハンドル「0」で非矩形クリップの案内が出る問題を修正しました。

## 確認

- コア554件成功（追加の回帰テスト7件を含む）。
- 関連GUI11件成功（CAD読込、寸法描画、ビューポート、レイアウト操作）。
- 公開データの変換後DXFを再読込し、example_2000は3804図形、sample_AC1027は142図形でコンパイル成功。
- sample_AC1027のLayout1、Layout2、MyLayoutを実Tkで開き、それぞれ空でない投影画像1枚を確認しました。
- baseline-sampleとmechanicalも再コンパイル成功。baseline-sampleの誤った非矩形クリップ案内が解消しました。

## 公開サンプル

- https://github.com/LibreDWG/libredwg/blob/master/test/test-data/example_2000.dwg
- https://github.com/monozukuri-ai/ezdwg/blob/main/test_dwg/acadsharp/sample_AC1027.dwg
- https://github.com/mlightcad/cad-data/blob/main/data/baseline-sample.dwg
- https://github.com/monozukuri-ai/ezdwg/blob/main/examples/data/mechanical_example-imperial.dwg

## 制約

今回の実データ検証はLinuxでGNU LibreDWG 0.14.9086によるDWG→DXF変換後の読込です。Windows/AutoCAD COMによるDWG直接読込、AutoCAD実機の表示との完全一致、SCR実行、EXEビルドは未確認です。

3D、非矩形クリップ、ねじれ、未対応図形の追加対応は含みません。canteen.dwgの変換後DXFにあるACISの文字コードエラーは解消していません。対応範囲外の図形は読込結果の案内を確認してください。
