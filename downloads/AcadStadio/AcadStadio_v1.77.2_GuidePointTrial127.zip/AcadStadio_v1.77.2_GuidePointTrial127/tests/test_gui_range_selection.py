"""Real drag selection and editing legacy range conditions without a form."""
import os,sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project
@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class RangeSelectionGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_drag_keeps_camera_and_saves_dynamic_figure_references(self):
  prior=[dict(type='LINE',x1='0',y1='0',x2='20',y2='0'),dict(type='CIRCLE',x='40',y='0',r='5')]
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    w.refresh_command_preview();self.root.update();canvas=w.command_preview.canvas
    canvas.view_ratio=.6;canvas.fit(preserve=True,preserve_camera=True);before=canvas.get_view()
    a=canvas.screen_point((-5,-6));b=canvas.screen_point((46,6))
    canvas.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]))
    canvas.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]),state=256)
    canvas.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]));self.root.update();w.refresh_command_preview();self.root.update()
    self.assertEqual(canvas.selection_count,2);self.assertEqual(canvas.get_view(),before)
    self.assertEqual(w.command_entries,{})
    gui.button(w,'選択を確定').invoke()
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(180,inspect)
  result=edit_command(self.root,dict(type='SELECT',selection_name='範囲選択'),self.app.data['blocks'],self.app.data,point_sources=prior)
  self.assertIsNotNone(result);self.assertEqual(len(result['selections']),2)
  self.assertTrue(all('点(' in q['x1'] for q in result['selections']))
 def test_legacy_range_edit_keeps_conditions_and_undo_restores_members(self):
  prior=[dict(type='LINE',x1='0',y1='0',x2='20',y2='0')]
  old=dict(type='SELECT',selection_name='旧範囲',selections=[dict(mode='crossing',x1='-5',y1='-5',x4='25',y4='5')])
  def inspect():
   w=gui.top(self.root,'コマンドの設定')
   try:
    w.refresh_command_preview();self.root.update();canvas=w.command_preview.canvas
    self.assertEqual(canvas.selection_count,1)
    w.select_editor.clear();self.root.update();w.refresh_command_preview();self.root.update()
    self.assertEqual(canvas.selection_count,0)
    w.undo_draft();self.root.update();w.refresh_command_preview();self.root.update()
    self.assertEqual(canvas.selection_count,1)
    gui.button(w,'選択を確定').invoke()
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(180,inspect)
  result=edit_command(self.root,old,self.app.data['blocks'],self.app.data,point_sources=prior)
  self.assertEqual(result['selections'],old['selections'])
