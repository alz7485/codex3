import os,sys,unittest
import test_gui as gui
from macro_editor import edit_command
from tkinter import ttk

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class AppearanceGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_setting_command_shows_attributes_and_saves(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            self.assertEqual(set(w.advanced_rows),{'layer','color','linetype','linetype_scale','text_style','dim_style'})
            gui.button(w,'コマンドを反映').invoke()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='APPEARANCE',layer='OUTLINE',color='1'),self.app.data['blocks'],self.app.data)
        self.assertEqual(result['type'],'APPEARANCE');self.assertEqual(result['color'],'1')
        self.assertEqual(self.errors,[])
    def test_line_editor_has_no_appearance_inputs(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            self.assertEqual(set(w.advanced_rows),set())
            gui.button(w,'コマンドを反映').invoke()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),self.app.data['blocks'],self.app.data)
        self.assertNotIn('layer',result);self.assertEqual(self.errors,[])
    def test_imported_attributes_remain_until_explicit_sort_and_survive_reopen(self):
        from pathlib import Path
        from cad_drawing_import import read_cad_drawing, imported_project
        from engine import compile_project
        from macro_editor import MacroEditor
        sample=Path(__file__).resolve().parents[1]/'examples'/'DWG読込と表割当テスト'/'plate_base.dxf'
        self.app.replace_document(imported_project(read_cad_drawing(sample)))
        def signature():
            return [(i['type'],i['coords'],i.get('color'),i.get('effective_layer'),i.get('linetype'),i.get('linetype_scale'),i.get('text')) for i in compile_project(self.app.data,[0])[1]]
        before=signature()
        editor=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update()
        settings=[c for c in editor.list.commands if c['type']=='APPEARANCE']
        self.assertEqual(len(settings),16)
        self.assertEqual(len(editor.list.commands),32)  # Keep one attribute command per imported figure.
        gui.button(editor.win,'ブロックを反映').invoke();self.root.update()
        self.assertEqual(signature(),before)
        identity=self.app.data['blocks'][0]['id']
        self.assertTrue(self.app.sort_figure_blocks([identity]));self.root.update()
        self.assertEqual(signature(),before)
        editor=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update()
        self.assertEqual(len(editor.list.commands),20)
        gui.button(editor.win,'ブロックを反映').invoke();self.root.update()
        self.assertEqual(signature(),before);self.assertEqual(self.messages,[])
