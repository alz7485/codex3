import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import ezdxf
from cad_drawing_import import extract_drawing,imported_project,solid_boundaries
from engine import compile_project
from extended_commands import polygon_valid

class ImportEdgeCases(unittest.TestCase):
 def compile(self,doc):
  snapshot=extract_drawing(doc,include_layouts=True)
  return snapshot,compile_project(imported_project(snapshot),[0])[1]
 def test_crossed_solid_preserves_both_filled_lobes(self):
  doc=ezdxf.new();doc.modelspace().add_solid([(0,0),(2,2),(2,0),(0,2)])
  s,items=self.compile(doc);h=[i for i in items if i['type']=='HATCH'];self.assertEqual(len(h),2);area=0
  for i in h:
   pts=list(zip(i['coords'][::2],i['coords'][1::2]));polygon_valid(pts)
   area+=abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1])))/2
  self.assertAlmostEqual(area,2);self.assertTrue(any('分割' in i['reason'] for i in s['issues']))
 def test_normal_solid_not_reordered(self):
  self.assertEqual(solid_boundaries([(0,0),(3,0),(3,2),(0,2)]),[[(0,0),(3,0),(3,2),(0,2)]])
 def test_invalid_hatch_reported_without_stopping_other_geometry(self):
  doc=ezdxf.new();m=doc.modelspace();m.add_circle((0,0),2);h=m.add_hatch();h.paths.add_polyline_path([(0,0),(2,2),(0,2),(2,0)])
  s,items=self.compile(doc);self.assertEqual([i['type'] for i in items],['CIRCLE']);self.assertTrue(any(i['type']=='HATCH' for i in s['issues']))
 def test_explicit_closing_vertex_is_accepted(self):
  doc=ezdxf.new();h=doc.modelspace().add_hatch();h.paths.add_polyline_path([(0,0),(2,0),(2,2),(0,2),(0,0)])
  _,items=self.compile(doc);self.assertEqual(items[0]['type'],'HATCH')
 def test_centered_diameter_text_compiles(self):
  doc=ezdxf.new(setup=True);dim=doc.modelspace().add_diameter_dim((10,20),radius=5,angle=0);dim.render();dim.dimension.dxf.text_midpoint=(10,20,0)
  s,items=self.compile(doc);item=items[0];self.assertEqual(item['type'],'DIMDIAMETER');self.assertNotEqual(item['coords'][:2],item['coords'][3:5]);self.assertTrue(any('中心と一致' in i['reason'] for i in s['issues']))
 def test_oversize_text_is_reported_before_compile(self):
  doc=ezdxf.new();doc.modelspace().add_circle((0,0),1);doc.modelspace().add_mtext('x'*3000)
  s,items=self.compile(doc);self.assertEqual(len(items),1);self.assertTrue(any('2048' in i['reason'] for i in s['issues']))
 def test_null_clip_handle_does_not_warn(self):
  doc=ezdxf.new();doc.modelspace().add_circle((0,0),1);vp=doc.layouts.new('Sheet').add_viewport((50,50),(80,80),(0,0),10);vp.dxf.clipping_boundary_handle='0'
  s,items=self.compile(doc);self.assertFalse(any('非矩形' in i['reason'] for i in s['issues']));self.assertTrue(any(i.get('viewport_view') for i in items))
