import sys, unittest, copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from selection_reference_bounds import reference_window
from engine import compile_project
from test_native_operations import project, command

class SelectionReferenceBounds(unittest.TestCase):
    def test_reference_window_follows_moving_and_resizing_sources(self):
        line=dict(type='LINE',point_id='p_'+'a'*32,x1='0',y1='0',x2='20',y2='10')
        circle=dict(type='CIRCLE',point_id='p_'+'b'*32,x='40',y='0',r='5')
        _,items=compile_project(project([line,circle]),[0])
        query=reference_window(items,lambda item:item['point_id'])
        selector=dict(type='SELECT',point_id='p_'+'c'*32,selection_name='範囲',selections=[query])
        operation=command('COPY',selection_ref='p_'+'c'*32,x2='0',y2='0',x3='0',y3='50')
        for x,r in [('40','5'),('-70','12')]:
            moved=dict(circle,x=x,r=r)
            _,result=compile_project(project([line,moved,selector,operation]),[0])
            self.assertEqual(result[2]['selected_count'],2)
            self.assertEqual(len(result[-1]['children']),2)
        self.assertIn('点(',query['x1']);self.assertIn('min(',query['x1'])
    def test_empty_or_unreferenceable_geometry_explains_fallback(self):
        for members in ([],[dict(type='TEXT',coords=(0,0),text='abc',height=5)], [dict(type='LINE',coords=(0,0,1,1),entity_parent={})]):
            with self.subTest(members=members),self.assertRaises(ValueError):
                reference_window(members,lambda item:'p_source')
    def test_missing_identity_is_rejected(self):
        with self.assertRaises(ValueError):reference_window([dict(type='LINE',coords=(0,0,10,10))],lambda item:None)
    def test_horizontal_line_gets_nonzero_window_height(self):
        query=reference_window([dict(type='LINE',coords=(0,0,10,0))],lambda item:'p_source')
        self.assertTrue(query['y1'].endswith('-0.0000001'))
        self.assertTrue(query['y4'].endswith('+0.0000001'))
    def test_circle_extrema_include_full_radius(self):
        from command_points import selection_geometry_points
        p=selection_geometry_points(dict(type='CIRCLE',coords=(10,20,7)))
        self.assertEqual(p['外接範囲最小'],(3,13))
        self.assertEqual(p['外接範囲最大'],(17,27))
    def test_rotated_ellipse_uses_true_extrema(self):
        import math
        from command_points import selection_geometry_points
        p=selection_geometry_points(dict(type='ELLIPSE',coords=(0,0,10,2),angle=45))
        extent=math.sqrt(52)
        self.assertAlmostEqual(p['外接範囲最大'][0],extent)
        self.assertAlmostEqual(p['外接範囲最大'][1],extent)
        q=reference_window([dict(type='ELLIPSE',coords=(0,0,10,2),angle=45)],lambda item:'p_source')
        self.assertIn('外接範囲最小',q['x1'])
    def test_arc_extrema_cover_only_sweep(self):
        from command_points import selection_geometry_points
        p=selection_geometry_points(dict(type='ARC',coords=(0,0,10),start_angle=0,sweep=90))
        self.assertAlmostEqual(p['外接範囲最小'][0],0)
        self.assertAlmostEqual(p['外接範囲最小'][1],0)
        self.assertEqual(p['外接範囲最大'],(10,10))
