import copy,unittest
import test_gui as gui
import test_folder_release as release_tests
from space_folders import root_for
from block_folders import create_folder

class FolderReleaseGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_right_click_release_visual_slot_undo_redo_and_script(self):
        p,root,before,target,after,child=release_tests.FolderRelease().sample();self.app.replace_document(p);self.root.update();b=self.app.block_browser;t=b.tree
        b.select_folder(target['id']);self.root.update();baseline=copy.deepcopy(self.app.data);script=self.app.compile()[0]
        old=list(t.get_children('folder:'+root));slot=old.index('folder:'+target['id']);members=list(t.get_children('folder:'+target['id']))
        b.prepare_menu();index=next(i for i in range(b.menu.index('end')+1) if b.menu.type(i)=='command' and b.menu.entrycget(i,'label')=='フォルダを解放');b.menu.invoke(index);self.root.update()
        self.assertFalse(t.exists('folder:'+target['id']));self.assertEqual(list(t.get_children('folder:'+root)),old[:slot]+members+old[slot+1:]);self.assertEqual(self.app.compile()[0],script)
        released=copy.deepcopy(self.app.data);self.app.undo_project();self.root.update();self.assertEqual(self.app.data,baseline);self.assertTrue(t.exists('folder:'+target['id']))
        self.app.redo_project();self.root.update();self.assertEqual(self.app.data,released)
    def test_dedicated_root_icons_and_normal_folder_are_distinct(self):
        from space_folders import create_layout
        p,root,*_=release_tests.FolderRelease().sample();p,layout=create_layout(p,'A4');category=create_folder(p,'分類',root)
        self.app.replace_document(p);self.root.update();b=self.app.block_browser;t=b.tree
        model=t.item('folder:'+root,'image');paper=t.item('folder:'+layout,'image');ordinary=t.item('folder:'+category['id'],'image')
        self.assertTrue(model);self.assertTrue(paper);self.assertNotEqual(model,paper);self.assertNotEqual(model,ordinary);self.assertNotEqual(paper,ordinary)
        for identity in (root,layout):
            b.select_folder(identity);b.prepare_menu();index=next(i for i in range(b.menu.index('end')+1) if b.menu.type(i)=='command' and b.menu.entrycget(i,'label')=='フォルダを解放');self.assertEqual(b.menu.entrycget(index,'state'),'disabled')
    def test_folderized_and_released_blocks_follow_execution_order_with_parent_prefix(self):
        import json
        from pathlib import Path
        p=Path(__file__).resolve().parents[1]/'examples'/'範囲フォルダ化テスト'/'02_部品Aをフォルダ化.json'
        data=json.loads(p.read_text())
        root=root_for(data)['id'];part=next(f['id'] for f in data['block_folders'] if f['name']=='部品A')
        # Simulate the folder-first mixed order saved by Trial105.
        data['block_tree_order']={root:['folder:'+part,*['block:'+b['id'] for b in data['blocks'] if b.get('folder_id')==root]]}
        self.app.replace_document(data);self.root.geometry('1280x900');self.root.update();b=self.app.block_browser;t=b.tree
        baseline=copy.deepcopy(self.app.data);script=self.app.compile()[0]
        columns=tuple(t.cget('columns'));self.assertEqual(columns,('name','visible'))
        def rows():
            result=[]
            def visit(parent=''):
                for node in t.get_children(parent):
                    if node.isdigit():result.append(node)
                    visit(node)
            visit();return result
        self.assertEqual(rows(),[str(i) for i in range(6)])
        for index,block in enumerate(self.app.data['blocks']):
            text=t.item(str(index),'text');parent=next(f['name'] for f in self.app.data['block_folders'] if f['id']==block['folder_id'])
            self.assertTrue(text.startswith(parent));self.assertEqual(int(text.split()[-1]),index+1)
        self.assertEqual(self.app.data,baseline);self.assertEqual(self.app.compile()[0],script)
        identity=next(f['id'] for f in self.app.data['block_folders'] if f['name']=='部品A');b.select_folder(identity);b.release_selected_folder();self.root.update()
        self.assertEqual(rows(),[str(i) for i in range(6)]);self.assertEqual(self.app.compile()[0],script)
        self.assertTrue(all(t.item(str(i),'text').startswith('モデル') for i in range(6)))
