import copy,json,unittest
from test_native_operations import project,command
from setting_references import add_reference, registry, validate, delete_commands, localize, new_id
from engine import compile_project
from block_operations import split_block,join_blocks
from command_points import clone_commands
from project_model import validate_project
from script_preview import ScriptPreviewModel

class SettingReferences(unittest.TestCase):
    def commands(self):
        commands=add_reference([dict(type='APPEARANCE',color='1')],0)
        return commands+[dict(commands[1]),command('CIRCLE',x='0',y='0',r='10')]
    def test_reference_runs_current_master_at_each_call_and_tracks_scr_lines(self):
        commands=self.commands();commands.insert(1,dict(type='APPEARANCE',color='2'))
        p=project(commands);before=copy.deepcopy(p);script,items=compile_project(p,[0])
        self.assertEqual(items[0]['color'],1);self.assertEqual(p,before)
        commands[0]['color']='4';self.assertEqual(compile_project(project(commands),[0])[1][0]['color'],4)
        self.assertEqual(script.count('_.SETVAR\nCECOLOR\n1\n'),3)
        model=ScriptPreviewModel(p,[0]);self.assertEqual(len([s for s in model.steps if s['type']=='SETTINGREF']),2)
    def test_all_supported_settings_emit_identical_content_to_copies(self):
        for master in [dict(type='APPEARANCE',color='1'),command('SYSVAR',name='LTSCALE',value='2'),command('SYSVARS',items=[dict(name='LTSCALE',value='2',value_kind='number')]),command('LAYEREDIT',target_layer='OUTLINE')]:
            with self.subTest(type=master['type']):
                refs=add_reference([master],0)
                self.assertEqual(compile_project(project(refs),[0])[0],compile_project(project([master,master]),[0])[0])
    def test_cross_block_missing_cyclic_and_wrong_kind_rejected(self):
        commands=self.commands();p=project(commands)
        p['blocks'].append(dict(p['blocks'][0],id='second',name='Second',commands=[commands[1]]))
        self.assertTrue(any('同じブロック' in e for e in validate_project(p)))
        bad=copy.deepcopy(commands);bad[0]['type']='REGEN';self.assertTrue(validate(bad))
        bad=copy.deepcopy(commands);bad[0]['type']='SETTINGREF';bad[0]['setting_ref']=bad[0]['setting_id'];self.assertTrue(validate(bad))
        self.assertTrue(validate(commands+[dict(commands[0])]))
    def test_split_promotes_first_then_retargets_and_preserves_original(self):
        p=project(self.commands());before=copy.deepcopy(p)
        split=split_block(p,0,1,'Second');tail=split['blocks'][1]['commands']
        self.assertEqual([c['type'] for c in tail],['APPEARANCE','SETTINGREF','CIRCLE'])
        self.assertEqual(tail[1]['setting_ref'],tail[0]['setting_id']);self.assertNotEqual(tail[0]['setting_id'],p['blocks'][0]['commands'][0]['setting_id'])
        self.assertEqual(validate_project(split),[]);self.assertEqual(compile_project(split,[0])[1][0]['color'],1);self.assertEqual(p,before)
        rejoined=join_blocks(split,[0,1],'Joined');self.assertEqual(validate_project(rejoined),[])
    def test_split_localizes_forward_reference_too(self):
        commands=self.commands();commands=[commands[1],commands[0],commands[2],commands[3]]
        split=split_block(project(commands),0,1,'Second')
        self.assertEqual(split['blocks'][0]['commands'][0]['type'],'APPEARANCE');self.assertEqual(validate_project(split),[])
    def test_delete_choices_and_selected_references_are_atomic(self):
        commands=self.commands();before=copy.deepcopy(commands)
        first=delete_commands(commands,[0],'first');self.assertEqual([c['type'] for c in first],['APPEARANCE','SETTINGREF','CIRCLE']);self.assertEqual(first[1]['setting_ref'],first[0]['setting_id'])
        all_=delete_commands(commands,[0],'all');self.assertEqual([c['type'] for c in all_],['APPEARANCE','APPEARANCE','CIRCLE']);self.assertNotEqual(all_[0]['setting_id'],all_[1]['setting_id'])
        self.assertEqual(validate(all_),[]);self.assertEqual(commands,before)
        for changed in (first,all_):self.assertEqual(compile_project(project(changed),[0])[1][0]['color'],1)
        self.assertEqual(delete_commands(commands,[0,1],'first')[0]['type'],'APPEARANCE')
    def test_nested_definitions_localized_without_crossing_block_scope(self):
        commands=self.commands();nested=[dict(type='IF',condition='1',commands=commands[:2],**{'else':[]}),commands[2],commands[3]]
        self.assertEqual(validate(nested),[])
        changed=delete_commands(nested,[0],'first');self.assertEqual(changed[0]['type'],'APPEARANCE');self.assertEqual(validate(changed),[])
        self.assertEqual(json.loads(json.dumps(changed)),changed)
    def test_command_copy_rebinds_internal_links_but_single_ref_keeps_target(self):
        commands=self.commands();cloned=clone_commands(commands)
        self.assertNotEqual(cloned[0]['setting_id'],commands[0]['setting_id']);self.assertEqual(cloned[1]['setting_ref'],cloned[0]['setting_id'])
        self.assertEqual(clone_commands([commands[1]])[0],commands[1])
        duplicate_block=project(commands);other=copy.deepcopy(duplicate_block['blocks'][0]);other.update(id='other',name='Other');duplicate_block['blocks'].append(other)
        joined=join_blocks(duplicate_block,[0,1],'Combined');self.assertEqual(validate_project(joined),[])
    def test_materialization_does_not_optimize_away_referenced_master(self):
        from appearance_commands import extract_appearance
        commands=self.commands();changed=extract_appearance(commands);self.assertEqual(changed[:3],commands[:3]);self.assertEqual(compile_project(project(changed),[0])[1][0]["color"],1)

    def test_promoted_system_variable_keeps_point_reference_scope_on_split(self):
        from command_points import new_id as point_id, reference
        pid=point_id()
        commands=[command('LINE',x1='0',y1='0',x2='100',y2='0',point_id=pid),dict(type='SYSVAR',name='LTSCALE',value=reference(pid,'終点','X'),value_kind='number')]
        commands=add_reference(commands,1)
        commands += [command('CIRCLE',x='0',y='0',r='5')]
        p=project(commands);split=split_block(p,0,2,'Second')
        promoted=split['blocks'][1]['commands'][0]
        self.assertIn(split['blocks'][0]['id']+'/'+pid,promoted['value'])
        self.assertEqual(validate_project(split),[])
        self.assertEqual(compile_project(p,[0])[0].count('_.SETVAR\nLTSCALE\n100\n'),2)
        self.assertEqual(compile_project(split,[0])[0].count('_.SETVAR\nLTSCALE\n100\n'),2)
