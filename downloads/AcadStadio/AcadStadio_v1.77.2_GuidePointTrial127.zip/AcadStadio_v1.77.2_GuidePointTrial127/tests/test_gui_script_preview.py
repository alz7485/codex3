import unittest
import test_gui as gui
from tkinter import ttk
from test_native_operations import project,command
from cad_colors import swatch

class ScriptPreviewGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_script_line_click_final_reset_and_regeneration(self):
        self.app.replace_document(project([command('LINE',x1='0',y1='0',x2='100',y2='0'),command('CIRCLE',x='20',y='10',r='5')]))
        win=self.app.show_script();win.geometry('1200x800');self.root.update()
        text=self.app.script;self.assertEqual(text.get('1.0','end-1c'),self.app._script_text)
        pane=self.app.script_preview_pane;pane.toggle();self.root.update();pane.update();self.root.update()
        self.assertEqual(len(pane.canvas.items),2)
        line=pane.model.steps[0]['start_line'];text.see(f'{line}.0');self.root.update()
        bbox=text.bbox(f'{line}.0');self.assertIsNotNone(bbox)
        text.event_generate('<ButtonPress-1>',x=bbox[0]+3,y=bbox[1]+3)
        text.event_generate('<ButtonRelease-1>',x=bbox[0]+3,y=bbox[1]+3)
        self.root.update();pane.update();self.root.update()
        self.assertEqual(len(pane.canvas.items),1);self.assertTrue(pane.canvas.items[0]['scr_selected'])
        self.assertTrue(any(gui.rendered_color(pane.canvas,n)=='#ffdb59' for n,i,c in pane.canvas.geometry))
        self.app.set_script(self.app._script_text);self.assertTrue(text.tag_ranges('sel'))
        pane.clear();pane.update();self.root.update();self.assertEqual(len(pane.canvas.items),2)
        self.assertFalse(any(i.get('scr_selected') for i in pane.canvas.items))
        pane.toggle();self.root.update();self.assertFalse(pane.frame.winfo_ismapped())
        pane.toggle();self.root.update();pane.update();self.assertEqual(len(pane.canvas.items),2)

    def test_layer_swatch_tracks_color_and_selection(self):
        setup=self.app.edit_cad_setup();tree,_=setup.forms['layers']
        tabs=next(w for w in setup.win.winfo_children() if isinstance(w,ttk.Notebook))
        tabs.select(2);self.root.update()
        self.assertTrue(tree._color_cells)
        self.assertEqual(tree._color_cells[0].cget('bg'),swatch(int(setup.data['layers'][0]['color'])))
        setup.data['layers'][0]['color']=1;setup.reload('layers');self.root.update()
        self.assertEqual(tree._color_cells[0].cget('bg'),swatch(1))
        tree._color_cells[0].event_generate('<ButtonPress-1>',x=4,y=4)
        tree._color_cells[0].event_generate('<ButtonRelease-1>',x=4,y=4);self.root.update()
        self.assertEqual(tree.selection(),('0',))
        setup.win.destroy()
