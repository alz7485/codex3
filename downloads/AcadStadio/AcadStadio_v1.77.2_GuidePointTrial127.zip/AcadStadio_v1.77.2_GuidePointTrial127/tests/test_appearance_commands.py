import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from appearance_commands import extract_appearance
from sample_project import EXAMPLE
from engine import compile_project,MacroError
from project_model import validate_project

class AppearanceCommands(unittest.TestCase):
    def project(self,commands):
        p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=commands)];return p
    def test_settings_emit_no_geometry_and_following_drawings_inherit(self):
        p=self.project([dict(type='APPEARANCE',layer='OUTLINE',color='1',linetype='Continuous',linetype_scale='2',text_style='Standard',dim_style='Standard'),dict(type='CIRCLE',x='0',y='0',r='10')])
        self.assertEqual(validate_project(p),[])
        script,items=compile_project(p,[0])
        self.assertEqual(len(items),1)
        self.assertEqual(items[0]['color'],1)
        self.assertEqual(items[0]['linetype_scale'],2)
        self.assertEqual(items[0]['effective_layer'],'OUTLINE')
        for name in ('CECOLOR','CELTYPE','CELTSCALE','TEXTSTYLE'):self.assertIn(name,script)
        self.assertIn('_.-DIMSTYLE',script)
    def test_extract_preserves_geometry_and_explicit_zero_color(self):
        original=[dict(type='LINE',layer='OUTLINE',color='0',x1='0',y1='0',x2='100',y2='0')]
        changed=extract_appearance(original)
        self.assertEqual(changed[0]['color'],'0');self.assertNotIn('layer',changed[1])
        a=compile_project(self.project(original),[0])[1];b=compile_project(self.project(changed),[0])[1]
        for key in ('coords','color','effective_layer'):self.assertEqual(a[0][key],b[0][key])
        self.assertEqual(extract_appearance(changed),changed)
    def test_invalid_scale_fails_and_blank_settings_leave_current(self):
        compile_project(self.project([dict(type='APPEARANCE')]),[0])
        with self.assertRaises(MacroError):compile_project(self.project([dict(type='APPEARANCE',linetype_scale='0')]),[0])

    def test_repeated_settings_omitted_but_changes_and_return_are_kept(self):
        def line(color):return dict(type='LINE',layer='OUTLINE',color=color,linetype='BYLAYER',linetype_scale='1',x1='0',y1='0',x2='100',y2='0')
        original=[line('1'),line('1'),line('2'),line('2'),line('1')]
        baseline=copy.deepcopy(original);changed=extract_appearance(original)
        self.assertEqual([c['color'] for c in changed if c['type']=='APPEARANCE'],['1','2','1'])
        self.assertEqual(len([c for c in changed if c['type']=='LINE']),5)
        self.assertEqual(original,baseline);self.assertEqual(extract_appearance(changed),changed)
        before_script,before=compile_project(self.project(original),[0]);after_script,after=compile_project(self.project(changed),[0])
        for a,b in zip(before,after):
            for key in ('coords','color','effective_layer','linetype','linetype_scale'):self.assertEqual(a.get(key),b.get(key))
        self.assertEqual(after_script.count('_.SETVAR\nCECOLOR\n'),3)
        self.assertEqual(before_script.count('_.SETVAR\nCECOLOR\n'),5)

    def test_partial_settings_keep_style_state_and_zero_color(self):
        commands=[dict(type='APPEARANCE',layer='OUTLINE',color='0',linetype_scale='1'),dict(type='LINE',layer='OUTLINE',color='ByBlock',linetype_scale='1.0',x1='0',y1='0',x2='1',y2='0'),dict(type='TEXT',text='A',x='0',y='0',height='2',angle='0',text_style='Standard'),dict(type='TEXT',text='B',x='0',y='0',height='2',angle='0',text_style='Standard')]
        changed=extract_appearance(commands)
        self.assertEqual(len([c for c in changed if c['type']=='APPEARANCE']),2)
        self.assertEqual(changed[0]['color'],'0')

    def test_expressions_and_state_changing_commands_are_not_assumed_equal(self):
        for barrier in [dict(type='SET',name='C',value='2'),dict(type='SYSVAR',name='CECOLOR',value='2'),dict(type='BLOCK',name='unknown'),dict(type='CUSTOM',name='unknown')]:
            original=[dict(type='APPEARANCE',color='1'),barrier,dict(type='APPEARANCE',color='1')]
            self.assertEqual(extract_appearance(original),original)
        original=[dict(type='APPEARANCE',color='@OD'),dict(type='APPEARANCE',color='@OD')]
        self.assertEqual(extract_appearance(original),original)

    def test_conditionals_and_repeat_entry_keep_required_settings(self):
        attrs=dict(type='APPEARANCE',color='1')
        guarded=dict(attrs,condition='@OD > 100')
        commands=[attrs,guarded,attrs,dict(type='REPEAT',count='2',commands=[attrs,attrs]),attrs]
        changed=extract_appearance(commands)
        self.assertEqual([c['type'] for c in changed],['APPEARANCE','APPEARANCE','APPEARANCE','REPEAT','APPEARANCE'])
        self.assertEqual(changed[3]['commands'],[attrs])
        self.assertEqual(extract_appearance(changed),changed)

    def test_real_dxf_import_keeps_geometry_while_compacting_editor_settings(self):
        import ezdxf
        from cad_drawing_import import extract_drawing, imported_project
        doc=ezdxf.new();doc.layers.new('OUTLINE')
        for i,color in enumerate((1,1,2,2,1)):
            doc.modelspace().add_line((i,0),(i,10),dxfattribs=dict(layer='OUTLINE',color=color))
        p=imported_project(extract_drawing(doc));before=compile_project(p,[0])[1]
        for block in p['blocks']:block['commands']=extract_appearance(block['commands'])
        self.assertEqual(len([c for c in p['blocks'][0]['commands'] if c['type']=='APPEARANCE']),3)
        after=compile_project(p,[0])[1]
        self.assertEqual([(i['coords'],i['color'],i['effective_layer'],i.get('lineweight')) for i in before],[(i['coords'],i['color'],i['effective_layer'],i.get('lineweight')) for i in after])

    def test_non_import_migration_can_preserve_existing_output(self):
        commands=[dict(type='LINE',color='1',x1='0',y1='0',x2='10',y2='0')]*2
        expanded=extract_appearance(commands,deduplicate=False)
        self.assertEqual(len([c for c in expanded if c['type']=='APPEARANCE']),2)
        self.assertEqual(compile_project(self.project(commands),[0])[0],compile_project(self.project(expanded),[0])[0])
