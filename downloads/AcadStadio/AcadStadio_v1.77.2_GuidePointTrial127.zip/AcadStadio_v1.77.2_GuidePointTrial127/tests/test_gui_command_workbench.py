import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command
from arc_modes import MODES

class WorkbenchGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    # Only the new workbench tests, not the base fixture's test methods.
    def test_point_window_xy_offsets_undo_restore_and_camera(self):
        source=dict(type='LINE',x1='0',y1='0',x2='100',y2='0')
        current=dict(type='LINE',x1='1',y1='2',x2='150',y2='50')
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            w.preview_input.show_details();self.root.update()
            try:
                w.refresh_command_preview();self.root.update()
                preview=w.command_preview;c=preview.canvas
                c.view_ratio=2;c.pan=[12,18]
                before=c.screen_point((100,0))
                w.choose_command_point('x1',both=True);self.root.update()
                panel=w.point_panel
                self.assertIs(panel.point_preview,preview)
                self.assertEqual(panel.axis_picker.get(),'XY')
                self.assertEqual(c.screen_point((100,0)),before)
                panel.point_picker.set('終点');w.coordinate_values['x1'].movement.set('-10');w.coordinate_values['y1'].movement.set('7')
                gui.use_reference_and_finish(panel);self.root.update()
                self.assertEqual(c.view_ratio,2);self.assertEqual(c.pan,[12,18])
                self.assertEqual(w.coordinate_values['x1'].movement.get(),'-10');self.assertEqual(w.coordinate_values['y1'].movement.get(),'7')
                w.undo_draft();self.root.update()
                self.assertEqual(w.command_entries['x1'].get(),'1');self.assertEqual(w.command_entries['y1'].get(),'2')
                w.redo_draft();self.root.update();w.choose_command_point('y1');self.root.update()
                self.assertEqual(w.point_panel.axis_picker.get(),'XY')
                self.assertEqual(w.coordinate_values['x1'].movement.get(),'-10')
                self.assertEqual(w.coordinate_values['y1'].movement.get(),'7')
                gui.button(w.point_panel,'キャンセル').invoke();gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(150,inspect)
        result=edit_command(self.root,current,self.app.data['blocks'],self.app.data,point_sources=[source])
        self.assertIsNotNone(result)

    def test_arc_and_circle_modes_preserve_current_geometry(self):
        def circle():
            w=gui.top(self.root,'コマンドの設定')
            w.preview_input.show_details();self.root.update()
            try:
                w.circle_mode_picker.set('直径');w.circle_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                self.assertEqual(w.command_entries['x'].get(),'12');self.assertEqual(w.command_entries['diameter'].get(),'182')
                w.command_entries['diameter'].delete(0,'end');w.command_entries['diameter'].insert(0,'123')
                w.circle_mode_picker.set('半径');w.circle_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                self.assertEqual(w.command_entries['r'].get(),'61.5');w.destroy()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(100,circle);edit_command(self.root,dict(type='CIRCLE',x='12',y='34',r='91'),self.app.data['blocks'],self.app.data)
        def arc():
            w=gui.top(self.root,'コマンドの設定')
            w.preview_input.show_details();self.root.update()
            try:
                w.arc_mode_picker.set(MODES['three_points']);w.arc_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                w.command_entries['x2'].delete(0,'end');w.command_entries['x2'].insert(0,'123');w.refresh_command_preview();self.root.update()
                before=w.command_preview.canvas.items[-1]
                w.arc_mode_picker.set(MODES['center_angles']);w.arc_mode_picker.event_generate('<<ComboboxSelected>>');w.refresh_command_preview();self.root.update()
                after=w.command_preview.canvas.items[-1]
                for a,b in zip(before['coords'],after['coords']):self.assertAlmostEqual(a,b,places=6)
                self.assertAlmostEqual(before['sweep'],after['sweep'],places=6);w.destroy()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(100,arc);edit_command(self.root,dict(type='ARC',x='0',y='0',r='91',start_angle='0',end_angle='90'),self.app.data['blocks'],self.app.data)

    def test_continue_additions_return_ordered_queue_even_on_cancel(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            w.preview_input.show_details();self.root.update()
            try:
                gui.button(w,'追加して続ける').invoke();self.root.update()
                w.command_entries['x2'].delete(0,'end');w.command_entries['x2'].insert(0,'300')
                gui.button(w,'追加して閉じる').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),self.app.data['blocks'],self.app.data,allow_continue=True)
        self.assertEqual(len(result),2);self.assertEqual(result[1]['x2'],'300')

    def test_queued_commands_can_be_referenced_and_cancel_keeps_added_commands(self):
        from macro_editor import TYPE_LABELS
        from engine import compile_project
        import copy
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            w.preview_input.show_details();self.root.update()
            try:
                gui.button(w,'追加して続ける').invoke();self.root.update()
                w.command_picker.set(TYPE_LABELS['POINT']);w.command_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                w.choose_command_point('x',both=True);self.root.update()
                gui.use_reference_and_finish(w.point_panel)
                gui.button(w,'追加して閉じる').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),self.app.data['blocks'],self.app.data,allow_continue=True)
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=result)]
        _,items=compile_project(p,[0]);self.assertEqual(items[1]['coords'],items[0]['coords'][:2])
        def cancel_after_add():
            w=gui.top(self.root,'コマンドの設定')
            w.preview_input.show_details();self.root.update()
            gui.button(w,'追加して続ける').invoke();self.root.update();gui.button(w,'キャンセル').invoke()
        self.root.after(100,cancel_after_add)
        kept=edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),self.app.data['blocks'],self.app.data,allow_continue=True)
        self.assertEqual(len(kept),1)

    def test_category_search_selects_command_and_live_results_follow_input(self):
        from macro_editor import TYPE_LABELS
        from tkinter import ttk
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            w.preview_input.show_details();self.root.update()
            try:
                def choose():
                    palette=gui.top(self.root,'追加するコマンド')
                    entry=next(e for e in gui.descendants(palette) if isinstance(e,ttk.Entry))
                    entry.insert(0,'DIMRADIUS');self.root.update();gui.button(palette,'DIMRADIUS').invoke()
                self.root.after(60,choose);w.command_picker.event_generate('<Button-1>');self.root.update()
                self.assertEqual(w.command_picker.get(),TYPE_LABELS['DIMRADIUS'])
                w.refresh_command_preview();self.root.update()
                self.assertIn('100',w.field_results['x'].cget('text'))
                self.assertTrue(w.command_preview.canvas.items)
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),self.app.data['blocks'],self.app.data)
        self.assertEqual(result['type'],'DIMRADIUS')

    def test_visible_axis_buttons_apply_to_matching_field_and_footer_fits(self):
        source=dict(type='LINE',x1='0',y1='0',x2='100',y2='50')
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            w.preview_input.show_details();self.root.update()
            try:
                w.geometry('980x620');self.root.update()
                w.choose_command_point('x1',both=True);self.root.update();panel=w.point_panel
                panel.axis_segments.buttons['Y'].invoke()
                panel.point_picker.set('終点');panel.point_picker.event_generate('<<ComboboxSelected>>')
                w.coordinate_values['y1'].movement.set('7');self.root.update()
                self.assertEqual(panel.point_preview.points['終点'], (100.,50.))
                self.assertFalse(hasattr(panel, 'result_card'))
                self.assertFalse(hasattr(panel, 'details_button'))
                self.assertEqual(panel.axis_picker.get(),'Y');self.assertEqual(panel.axis_segments.buttons['Y'].cget('style'),'WorkbenchSegmentOn.TButton')
                for label in ('キャンセル','この点を使用'):
                    b=gui.button(panel,label);self.assertTrue(b.winfo_ismapped())
                    self.assertLessEqual(b.winfo_rooty()+b.winfo_height(),panel.winfo_rooty()+panel.winfo_height())
                gui.use_reference_and_finish(panel);self.root.update()
                self.assertEqual(w.command_entries['x1'].get(),'1')
                self.assertEqual(w.coordinate_values['y1'].movement.get(),'7')
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='1',y1='2',x2='100',y2='0'),self.app.data['blocks'],self.app.data,point_sources=[source])
        self.assertIn("'Y'",result['y1'])
