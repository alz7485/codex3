import sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from text_preview import display_text,layout,raster
from cad_text_format import tokens,encoded,normalize
from cad_drawing_import import extract_drawing,imported_project
from engine import compile_project
import ezdxf

class CadText(unittest.TestCase):
 def test_symbols_for_text_and_mtext(self):
  for code in ('%%C','%%c'):
   self.assertEqual(display_text(code),'φ')
   self.assertEqual(layout(dict(type='MTEXT',coords=(0,0,3),text=code,width=30)).lines,('φ',))
 def test_tolerance_scale_and_scope(self):
  result=list(tokens(r'A{\H0.7x;\S+0.04^0;}B',3))
  self.assertEqual(result,[('A',None,1.),('+0.04','0',.7),('B',None,1.)])
  self.assertEqual(list(tokens(' {¥H0.7x;¥S+0.04^0;}',3))[1],('+0.04','0',.7))
 def test_stack_layout_and_raster(self):
  item=dict(type='MTEXT',coords=(0,0,3),text=r'{\H0.7x;\S+0.04^0;}',width=30)
  data=layout(item);upper,lower=data.runs
  self.assertEqual((upper[0],lower[0]),('+0.04','0'));self.assertGreater(upper[2],lower[2]);self.assertEqual(upper[3],.7)
  image,pos=raster(item,'white',lambda x,y:(50+x*12,100-y*12),12,(500,300))
  self.assertIsNotNone(image.getchannel('A').getbbox())
 def test_raw_format_survives_import_compile_and_export(self):
  doc=ezdxf.new();text=r'%%C20{\H0.7x;\S+0.04^0;}'
  doc.modelspace().add_mtext(text,dxfattribs={'char_height':3,'width':50})
  snap=extract_drawing(doc);project=imported_project(snap);script,items=compile_project(project,[0])
  self.assertEqual(items[0]['text'],text);self.assertIn(r'\\H0.7x;',script);self.assertNotIn(r'\\\\H0.7x;',script)
 def test_literal_text_remains_literal_in_cad(self):
  self.assertEqual(encoded(r'part {A} C:\test'),r'part \{A\} C:\\test')
 def test_leader_arrow_and_annotation_import(self):
  doc=ezdxf.new();m=doc.modelspace();m.add_leader([(0,0),(10,10),(20,10)],dxfattribs={'has_arrowhead':1});m.add_mtext('%%C10',dxfattribs={'insert':(20,10),'char_height':3,'width':30})
  snap=extract_drawing(doc);commands=[c for b in snap['blocks'] for c in b['commands']]
  self.assertTrue(any(c['type']=='HATCH' for c in commands));self.assertTrue(any(c['type']=='LINE' for c in commands));self.assertFalse(any(x['type']=='LEADER' for x in snap['issues']))
  script,items=compile_project(imported_project(snap),[0]);self.assertTrue(items)
 def test_multileader_contains_arrow_and_formatted_annotation(self):
  from ezdxf.math import Vec2
  doc=ezdxf.new();builder=doc.modelspace().add_multileader_mtext('Standard')
  text=r'%%C20{\H0.7x;\S+0.04^0;}'
  builder.quick_leader(text,Vec2(0,0),Vec2(10,10))
  snap=extract_drawing(doc);self.assertFalse([i for i in snap['issues'] if i['type'] in ('MULTILEADER','LEADER')],snap['issues'])
  script,items=compile_project(imported_project(snap),[0])
  self.assertTrue(any(i['type']=='HATCH' for i in items));self.assertTrue(any(i.get('text')==text for i in items))
