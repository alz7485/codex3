import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from engine import compile_project
from script_preview import ScriptPreviewModel
from test_native_operations import project,command

class ScriptPreviewTests(unittest.TestCase):
    def test_physical_lines_and_export_unchanged(self):
        p=project([command('LINE',x1='0',y1='0',x2='100',y2='0'),command('CIRCLE',x='20',y='10',r='5')])
        original=copy.deepcopy(p)
        script,items=compile_project(p,[0]);m=ScriptPreviewModel(p,[0])
        self.assertEqual(m.script,script);self.assertEqual(m.final,items);self.assertEqual(p,original)
        lines=script.splitlines()
        self.assertEqual(lines[m.steps[0]['start_line']-1],'_.LINE')
        self.assertEqual(lines[m.steps[1]['start_line']-1],'_.CIRCLE')
        self.assertEqual(m.state(1)[0],[])
        first=m.steps[0]
        for line in range(first['start_line'],first['end_line']+1):
            state,_=m.state(line);self.assertEqual(len(state),1);self.assertTrue(state[0]['scr_selected'])
        state,_=m.state(m.steps[1]['start_line'])
        self.assertEqual(len(state),2);self.assertFalse(state[0].get('scr_selected'));self.assertTrue(state[1]['scr_selected'])
        self.assertEqual(m.state()[0],items)
        self.assertFalse(any(i.get('scr_selected') for i in m.state(len(lines))[0]))

    def test_trim_displays_original_before_trim_and_changed_geometry_after(self):
        p=project([command('LINE',x1='0',y1='0',x2='100',y2='0'),command('LINE',x1='40',y1='-20',x2='40',y2='20'),command('TRIM',x1='40',y1='10',x2='80',y2='0')])
        m=ScriptPreviewModel(p,[0]);before,_=m.state(m.steps[1]['start_line']);after,_=m.state(m.steps[2]['start_line'])
        self.assertEqual(before[0]['coords'],(0.,0.,100.,0.));self.assertEqual(after[0]['coords'],(0.,0.,40.,0.))
        self.assertTrue(after[0]['scr_selected']);self.assertFalse(after[1].get('scr_selected'))

    def test_repeat_and_multiple_rows_distinguish_execution_instances(self):
        p=project([dict(type='REPEAT',count='3',commands=[command('CIRCLE',x='0',y='0',r='5')])])
        m=ScriptPreviewModel(p,[0,1]);self.assertEqual(len(m.steps),6)
        state,_=m.state(m.steps[4]['start_line'])
        self.assertEqual(len(state),5);self.assertEqual(sum(bool(i.get('scr_selected')) for i in state),1)
        self.assertTrue(state[-1]['scr_selected'])

if __name__=='__main__':unittest.main()
