"""Project-list toolbar and right-click file operations with real Tk widgets."""
import copy,json,os,sys,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from sample_project import EXAMPLE

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI unavailable')
class ProjectListMenu(unittest.TestCase):
 def setUp(self):
  gui.Gui.setUp(self);self.app.show_project_list();self.root.update();self.side=self.app.project_sidebar
 tearDown=gui.Gui.tearDown
 def file(self,name):
  p=self.app.project_library.ensure_directory()/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(EXAMPLE),encoding='utf-8');self.side.refresh(force=True);self.root.update();return p
 def menu(self,path):
  tree=self.side.tree;tree.see(str(path));self.root.update();x,y,w,h=tree.bbox(str(path))
  with patch.object(self.side.context_menu,'tk_popup'):
   tree.event_generate('<Button-3>',x=x+20,y=y+h//2);self.root.update()
  return self.side.context_menu
 def test_toolbar_has_only_new_folder_delete(self):
  self.assertEqual([w.cget('text') for w in self.side.toolbar.winfo_children()],['＋ 新規','フォルダ作成','削除'])
  with patch('tkinter.simpledialog.askstring',return_value='案件'):
   gui.button(self.side,'フォルダ作成').invoke()
  self.assertTrue((self.app.project_library.directory/'案件').is_dir())
  self.assertNotIn('「保存」',self.side.details.get())
 def test_right_click_selects_without_opening_then_moves_file(self):
  active=self.file('編集中.json');source=self.file('移動する.json');dest=source.parent/'移動先';dest.mkdir();self.app.open_project(active);self.side.refresh(force=True);before=copy.deepcopy(self.app.data)
  menu=self.menu(source)
  self.assertEqual(self.side.tree.selection(),(str(source),));self.assertEqual(self.app.path,str(active));self.assertEqual(self.app.data,before)
  self.assertEqual([menu.entrycget(i,'label') for i in (0,1,3)],['移動…','名前を変更…','削除'])
  with patch('tkinter.filedialog.askdirectory',return_value=str(dest)):menu.invoke(0)
  self.assertFalse(source.exists());self.assertTrue((dest/source.name).exists());self.assertEqual(self.app.path,str(active))
 def test_move_folder_updates_open_project_path(self):
  source=self.file('案件/作図.json');folder=source.parent;dest=folder.parent/'完了';dest.mkdir();self.app.open_project(source);self.side.refresh(force=True)
  menu=self.menu(folder)
  with patch('tkinter.filedialog.askdirectory',return_value=str(dest)):menu.invoke(0)
  expected=dest/folder.name/source.name
  self.assertTrue(expected.exists());self.assertFalse(folder.exists());self.assertEqual(self.app.path,str(expected))
 def test_context_delete_cancel_then_confirm_affects_only_selected_file(self):
  active=self.file('編集中.json');source=self.file('削除対象.json');self.app.open_project(active);self.side.refresh(force=True)
  menu=self.menu(source)
  with patch('tkinter.messagebox.askyesno',return_value=False):menu.invoke(3)
  self.assertTrue(source.exists())
  with patch('tkinter.messagebox.askyesno',return_value=True):menu.invoke(3)
  self.assertFalse(source.exists());self.assertTrue(active.exists());self.assertEqual(self.app.path,str(active))
 def test_move_cancel_and_name_collision_keep_files(self):
  source=self.file('作図.json');dest=source.parent/'移動先';dest.mkdir();other=dest/source.name;other.write_text('existing');original=source.read_bytes()
  self.menu(source)
  with patch('tkinter.filedialog.askdirectory',return_value=''):self.side.move_entry()
  self.assertEqual(source.read_bytes(),original)
  with patch('tkinter.filedialog.askdirectory',return_value=str(dest)),patch('tkinter.messagebox.showerror') as error:self.side.move_entry();error.assert_called_once()
  self.assertEqual(source.read_bytes(),original);self.assertEqual(other.read_text(),'existing')
