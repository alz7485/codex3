import sys,unittest,copy,json,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from polyline_edit import plan,geometry,reversed_path
from test_native_operations import project,command
from engine import compile_project,MacroError
from test_cad_state import read_form
from range_selection import entities,geometry_bounds
SID='p_'+'a'*32

def selector():return dict(type='SELECT',point_id=SID,selection_name='対象',selections=[dict(mode='window',x1='-1',y1='-1',x4='31',y4='31')])
def edit(action):return dict(type='PEDIT',selection_ref=SID,polyline_action=action,join_tolerance='0.001')
def outline():return [dict(type='LINE',x1='0',y1='0',x2='10',y2='0'),dict(type='ARC',x='10',y='10',r='10',start_angle='270',end_angle='90'),dict(type='LINE',x1='10',y1='20',x2='0',y2='20')]
class PolylineEdit(unittest.TestCase):
 def test_join_line_arc_and_close_preserves_true_bulge(self):
  p=project(outline()+[selector(),edit('結合して閉じる')]);before=copy.deepcopy(p)
  script,items=compile_project(json.loads(json.dumps(p)),[0])
  self.assertEqual(p,before)
  shapes=list(entities(items));shapes=[x for x in shapes if x['type']!='SELECT' and not x.get('operation_deleted')]
  self.assertEqual(len(shapes),1);poly=shapes[0]
  self.assertEqual(poly['display_type'],'POLYLINE');self.assertTrue(poly['closed'])
  self.assertEqual(len(poly['bulges']),4);self.assertAlmostEqual(poly['bulges'][1],1)
  self.assertAlmostEqual(geometry_bounds(poly)[2],20)
  self.assertIn('"_.PEDIT" "_Multiple"',script);self.assertIn('"_Join"',script);self.assertIn('"_Close"',script)
  self.assertIn('"PEDITACCEPT" saved',script);self.assertIn('"_Back"',script)
  for line in script.splitlines():
   if line.startswith('('):read_form(line)
 def test_arc_conversion_remains_open_and_circle_shape_can_close(self):
  cmds=[outline()[1],selector(),edit('ポリライン化')]
  _,items=compile_project(project(cmds),[0]);poly=items[0]
  self.assertFalse(poly['closed']);self.assertAlmostEqual(poly['bulges'][0],1)
  _,closed=compile_project(project([outline()[1],selector(),edit('閉じる')]),[0])
  self.assertTrue(closed[0]['closed']);self.assertEqual(len(closed[0]['bulges']),2)
 def test_reverse_traversal_flips_arc_bulge(self):
  arc=geometry(dict(type='ARC',coords=(0,0,10),start_angle=0,sweep=90))
  reverse=reversed_path(arc);self.assertAlmostEqual(reverse[1][0],-arc[1][0]);self.assertEqual(reverse[0],list(reversed(arc[0])))
 def test_disconnected_branch_and_mixed_types_rejected_without_mutation(self):
  cases=[[dict(type='LINE',coords=(0,0,1,0)),dict(type='LINE',coords=(2,0,3,0))],[dict(type='LINE',coords=(0,0,1,0)),dict(type='LINE',coords=(1,0,2,0)),dict(type='LINE',coords=(1,0,1,1))],[dict(type='CIRCLE',coords=(0,0,3))]]
  for sources in cases:
   original=copy.deepcopy(sources)
   with self.assertRaises(ValueError):plan(sources,'結合',.001)
   self.assertEqual(sources,original)
 def test_closed_square_from_unordered_reversed_lines(self):
  src=[dict(type='LINE',coords=c) for c in [(10,10,10,0),(0,0,0,10),(10,0,0,0),(0,10,10,10)]]
  v,b,closed=plan(src,'結合して閉じる',.001)[0]
  self.assertTrue(closed);self.assertEqual(len(v),4);self.assertTrue(all(x==0 for x in b))
 def test_copy_after_edit_uses_whole_updated_selection(self):
  copycmd=command('COPY',selection_ref=SID,x2='0',y2='0',x3='40',y3='0')
  _,items=compile_project(project(outline()+[selector(),edit('結合'),copycmd]),[0])
  self.assertEqual(len(items[-1]['children']),1)
  self.assertIn('bulges',items[-1]['children'][0])
 def test_invalid_action_tolerance_and_two_point_close(self):
  source=[dict(type='LINE',coords=(0,0,10,0))]
  for action,tol in [('invalid',.01),('結合',-1),('結合',float('nan')),('閉じる',.01)]:
   with self.assertRaises(ValueError):plan(source,action,tol)
 def test_explode_after_arc_join_preserves_arc(self):
  _,items=compile_project(project(outline()+[selector(),edit('結合'),command('EXPLODE',selection_ref=SID)]),[0])
  children=items[-1]['children']
  self.assertEqual([c.get('display_type',c['type']) for c in children],['LINE','ARC','LINE'])
  self.assertAlmostEqual(children[1]['sweep'],180)
 def test_polyline_reedit_keeps_bulges_and_reversed_join(self):
  arc=dict(type='ARC',coords=(10,10,10),start_angle=270,sweep=180)
  line=dict(type='LINE',coords=(0,0,10,0))
  vs,bs,closed=plan([arc,line],'結合',.001)[0]
  self.assertTrue(any(x<0 for x in bs));self.assertFalse(closed)
  poly=dict(type='POLYLINE',coords=tuple(z for p in vs for z in p),bulges=bs,closed=False)
  closedpath=plan([poly],'閉じる',.001)[0]
  self.assertEqual(closedpath[1],bs);self.assertTrue(closedpath[2])
 def test_arc_midpoint_reference_is_exact_after_copy(self):
  from command_points import geometry_points
  copycmd=command('COPY',selection_ref=SID,x2='0',y2='0',x3='40',y3='0')
  _,items=compile_project(project([dict(type='ARC',x='10',y='10',r='10',start_angle='0',end_angle='45'),selector(),edit('ポリライン化'),copycmd]),[0])
  midpoint=geometry_points(items[-1]['children'][0])['中点']
  self.assertAlmostEqual(midpoint[0],50+10*math.cos(math.pi/8),places=10)
  self.assertAlmostEqual(midpoint[1],10+10*math.sin(math.pi/8),places=10)
 def test_preview_bounds_and_runtime_setting_restore_include_arc(self):
  from preview import DrawingCanvas
  from cad_state import snapshot_variables
  script,items=compile_project(project(outline()+[selector(),edit('結合')]),[0])
  poly=items[0]
  class Canvas:
   items=[poly]
  bounds=DrawingCanvas.bounds(Canvas())
  self.assertAlmostEqual(max(p[0] for p in bounds),20)
  self.assertIn('PEDITACCEPT',snapshot_variables(script.splitlines()))
