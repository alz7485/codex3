import copy,os,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class SelectFlowGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def prior(self):return [dict(type='LINE',x1='0',y1='0',x2='10',y2='0')]
 def run_stage(self,fn):
  try:fn(gui.top(self.root,'コマンドの設定'))
  except Exception as e:
   self.errors.append(e)
   for w in list(gui.descendants(self.root)):
    if hasattr(w,'command_preview') and w.winfo_exists():w.destroy()
 def test_missing_select_opens_selection_then_requested_copy(self):
  prior=self.prior()
  def select(w):
   self.assertIsNotNone(w.select_editor);w.refresh_command_preview();self.root.update()
   w.select_editor.simple_rectangle((-1,-1),(11,1));self.root.update()
   self.root.after(100,lambda:self.run_stage(copy_stage));gui.button(w,'選択を確定').invoke()
  def copy_stage(w):
   w.preview_input.show_details()
   self.assertIn('x2',w.command_entries);w.command_entries['x2'].delete(0,'end');w.command_entries['x2'].insert(0,'20')
   gui.button(w,'コマンドを反映').invoke()
  self.root.after(160,lambda:self.run_stage(select))
  result=edit_command(self.root,{'type':'COPY'},self.app.data['blocks'],self.app.data,point_sources=prior,creating=True)
  self.assertEqual([c['type'] for c in result],['SELECT','COPY']);self.assertEqual(result[1]['selection_ref'],result[0]['point_id'])
  p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=prior+result)];compile_project(p,[0])
 def test_cancel_requested_command_rolls_back_auto_selection(self):
  prior=self.prior();before=copy.deepcopy(prior);blocks=copy.deepcopy(self.app.data['blocks'])
  def select(w):
   w.refresh_command_preview();self.root.update();w.select_editor.simple_rectangle((-1,-1),(11,1));self.root.update()
   self.root.after(100,lambda:self.run_stage(lambda w:gui.button(w,'キャンセル').invoke()));gui.button(w,'選択を確定').invoke()
  self.root.after(160,lambda:self.run_stage(select))
  result=edit_command(self.root,{'type':'COPY'},self.app.data['blocks'],self.app.data,point_sources=prior,creating=True)
  self.assertIsNone(result);self.assertEqual(prior,before);self.assertEqual(blocks,self.app.data['blocks'])
 def test_cancel_select_does_not_open_operator(self):
  self.root.after(160,lambda:self.run_stage(lambda w:gui.button(w,'キャンセル').invoke()))
  self.assertIsNone(edit_command(self.root,{'type':'PEDIT'},self.app.data['blocks'],self.app.data,point_sources=self.prior(),creating=True))
 def test_overlapping_lines_can_be_selected_and_removed_by_window(self):
  prior=self.prior()*2;prior=copy.deepcopy(prior);prior[1]=dict(prior[1])
  def select(w):
   w.refresh_command_preview();self.root.update();ed=w.select_editor;c=w.command_preview.canvas
   ed.simple_rectangle((-1,-1),(11,1));w.refresh_command_preview();self.root.update();self.assertEqual(c.selection_count,2)
   ed.simple_rectangle((-1,-1),(11,1),True);w.refresh_command_preview();self.root.update();self.assertEqual(c.selection_count,0)
   ed.simple_rectangle((-1,-1),(11,1));w.refresh_command_preview();self.root.update();self.assertEqual(c.selection_count,2)
   gui.button(w,'選択を確定').invoke()
  self.root.after(160,lambda:self.run_stage(select))
  self.assertIsNotNone(edit_command(self.root,{'type':'SELECT'},self.app.data['blocks'],self.app.data,point_sources=prior))
 def test_refresh_during_drag_does_not_cancel_rectangle(self):
  def select(w):
   w.refresh_command_preview();self.root.update();c=w.command_preview.canvas
   a=c.screen_point((-1,-1));b=c.screen_point((11,1))
   c.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]));c.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]))
   self.assertTrue(c._object_box);w.refresh_command_preview();self.root.update();self.assertTrue(c._object_box)
   c.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]));self.root.update();w.refresh_command_preview();self.root.update()
   self.assertEqual(c.selection_count,1);gui.button(w,'選択を確定').invoke()
  self.root.after(160,lambda:self.run_stage(select))
  self.assertIsNotNone(edit_command(self.root,{'type':'SELECT'},self.app.data['blocks'],self.app.data,point_sources=self.prior()))
