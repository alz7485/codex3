"""Exercise referenced exclusion and envelope conversion in the real editor."""
import os,sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class SafeExclusionGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_exclusion_reference_and_envelope_survive_editor_accept(self):
        prior=[dict(type='CIRCLE',x='0',y='0',r='10'),dict(type='LINE',x1='-20',y1='0',x2='20',y2='0')]
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.refresh_command_preview();self.root.update()
                editor=w.select_editor
                editor.simple_rectangle((-25,-15),(25,15))
                self.root.update();w.refresh_command_preview();self.root.update()
                source=next(item for item in w.command_preview.canvas.items if item['type']=='CIRCLE')
                editor.simple_point((10,0),source)
                self.root.update();w.refresh_command_preview();self.root.update()
                self.assertEqual(w.command_preview.canvas.selection_count,1)
                self.assertFalse(w.command_entries)
                gui.button(w,'選択を確定').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(180,inspect)
        result=edit_command(self.root,dict(type='SELECT'),self.app.data['blocks'],self.app.data,point_sources=prior)
        self.assertIsNotNone(result)
        minus=result['selections'][1]
        self.assertTrue(minus['unique_pick']);self.assertIn('点(',minus['x1'])
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=prior+[result])]
        _,items=compile_project(p,[0]);self.assertEqual(items[-1]['selected_count'],1)
