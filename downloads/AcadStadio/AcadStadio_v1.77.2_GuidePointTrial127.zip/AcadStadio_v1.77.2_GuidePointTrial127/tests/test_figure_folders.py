import copy,json,unittest
from pathlib import Path
import ezdxf
from cad_drawing_import import extract_drawing,imported_project,read_cad_drawing
from figure_folders import folderize,sort_folder,_visual_signature
from engine import compile_project
from block_folders import folder
from space_folders import folder_space,root_for
from command_points import reference
from appearance_commands import extract_appearance
from project_model import validate_sequential_project
SAMPLES=Path(__file__).resolve().parents[1]/'examples'/'DWG読込と表割当テスト'

class FigureFolders(unittest.TestCase):
    def sample(self):return imported_project(read_cad_drawing(SAMPLES/'plate_base.dxf'))
    def compare(self,a,b):
        self.assertEqual(_visual_signature(compile_project(a,[0])[1]),_visual_signature(compile_project(b,[0])[1]))
    def test_mixed_selection_moves_in_order_and_omits_empty_category(self):
        p=self.sample();before=copy.deepcopy(p)
        chosen={(p['blocks'][0]['id'],p['blocks'][0]['commands'][0]['point_id']),(p['blocks'][2]['id'],p['blocks'][2]['commands'][0]['point_id'])}
        q,f,created=folderize(p,chosen,'部品1');self.assertEqual(p,before);self.compare(p,q)
        self.assertEqual(folder(q,f)['parent_id'],root_for(q)['id']);self.assertEqual(len(created),2)
        moved=[b for b in q['blocks'] if b['id'] in created];self.assertEqual([len([c for c in b['commands'] if c.get('import_source')]) for b in moved],[1,1])
        self.assertEqual([c['point_id'] for b in moved for c in b['commands'] if c.get('import_source')], [pid for owner,pid in [(p['blocks'][0]['id'],p['blocks'][0]['commands'][0]['point_id']),(p['blocks'][2]['id'],p['blocks'][2]['commands'][0]['point_id'])]])
        self.assertEqual(validate_sequential_project(json.loads(json.dumps(q))),[])
    def test_editor_attributes_and_complete_selection_preserve_every_figure(self):
        p=self.sample()
        for b in p['blocks']:b['commands']=extract_appearance(b['commands'])
        selected={(b['id'],c['point_id']) for b in p['blocks'] for c in b['commands'] if c.get('import_source')}
        q,f,created=folderize(p,selected,'全体');self.compare(p,q)
        self.assertEqual(sum(c.get('import_source') is not None for b in q['blocks'] for c in b['commands']),19)
        self.assertEqual(len(created),2)
    def test_table_formulas_survive_all_three_rows_and_sort(self):
        p=json.loads((SAMPLES/'04_assigned_complete.json').read_text());selected={(p['blocks'][0]['id'],p['blocks'][0]['commands'][0]['point_id'])}
        q,f,created=folderize(p,selected,'表参照');q=sort_folder(q,f)
        self.assertEqual(_visual_signature(compile_project(p,[0,1,2])[1]),_visual_signature(compile_project(q,[0,1,2])[1]))
        moved=next(b for b in q['blocks'] if b['id'] in created)
        self.assertTrue(any('@' in str(c) for c in moved['commands']))
    def test_layout_destination_and_native_dimension_are_kept(self):
        doc=ezdxf.new(setup=True);paper=doc.layouts.new('SheetA');paper.add_line((0,0),(30,0))
        dim=paper.add_linear_dim(base=(0,10),p1=(0,0),p2=(30,0));dim.render()
        paper.add_text('寸法',dxfattribs=dict(height=3,insert=(5,15)))
        p=imported_project(extract_drawing(doc,include_layouts=True))
        chosen={(b['id'],c['point_id']) for b in p['blocks'] if b.get('drawing_space')=='SheetA' for c in b['commands'] if c.get('import_source')}
        q,f,created=folderize(p,chosen,'図面枠','SheetA');self.compare(p,q);self.assertEqual(folder_space(q,f),'SheetA');self.assertEqual(len(created),3)
        self.assertEqual(len([c for b in q['blocks'] if b['id'] in created for c in b['commands'] if c['type']=='DIMLINEAR']),1)
    def test_point_links_across_selected_and_remaining_are_repaired(self):
        p=self.sample();b=p['blocks'][0];first=b['commands'][0];second=b['commands'][1]
        second['x1']=reference(first['point_id'],'終点','X');second['y1']=reference(first['point_id'],'終点','Y')
        selected={(b['id'],first['point_id'])};q,f,_=folderize(p,selected,'点参照');self.compare(p,q)
        self.assertEqual(validate_sequential_project(q),[])
    def test_attribute_sort_is_stable_and_scoped_to_folder(self):
        doc=ezdxf.new();m=doc.modelspace()
        for x,color in enumerate((1,2,1,2)):m.add_line((x,0),(x,10),dxfattribs=dict(color=color))
        p=imported_project(extract_drawing(doc));b=p['blocks'][0]
        q,f,created=folderize(p,{(b['id'],c['point_id']) for c in b['commands']},'色別');before=copy.deepcopy(q)
        sorted_=sort_folder(q,f);self.assertEqual(q,before);self.compare(q,sorted_)
        figures=[i for i in compile_project(sorted_,[0])[1] if i.get('block_index')==next(j for j,b in enumerate(sorted_['blocks']) if b['id']==created[0])]
        self.assertEqual([i['color'] for i in figures],[1,1,2,2]);self.assertEqual([i['coords'][0] for i in figures],[0,2,1,3])
    def test_invalid_empty_stale_and_wrong_space_are_atomic(self):
        p=self.sample();before=copy.deepcopy(p);b=p['blocks'][0]
        for selected,name,space in [(set(),'A','Model'),({('missing','missing')},'A','Model'),({(b['id'],b['commands'][0]['point_id'])},'','Model'),({(b['id'],b['commands'][0]['point_id'])},'A','Unknown')]:
            with self.assertRaises(ValueError):folderize(p,selected,name,space)
            self.assertEqual(p,before)
    def test_all_attributes_retained_before_folder_or_explicit_sort(self):
        from figure_folders import sort_blocks
        p=self.sample();b=p['blocks'][0]
        b['commands']=extract_appearance(b['commands'],deduplicate=False)
        self.assertEqual(sum(c['type']=='APPEARANCE' for c in b['commands']),16)
        q=sort_blocks(p,[b['id']]);self.compare(p,q)
        self.assertEqual(sum(c['type']=='APPEARANCE' for c in q['blocks'][0]['commands']),4)
        chosen={(b['id'],c['point_id']) for c in b['commands'] if c.get('import_source')}
        q,f,new=folderize(p,chosen,'保存属性')
        moved=next(b for b in q['blocks'] if b['id']==new[0]);self.assertEqual(sum(c['type']=='APPEARANCE' for c in moved['commands']),16)
        sorted_=sort_folder(q,f);moved=next(b for b in sorted_['blocks'] if b['id']==new[0]);self.assertEqual(sum(c['type']=='APPEARANCE' for c in moved['commands']),4)
    def test_referenced_master_is_kept_and_space_root_cannot_be_sorted(self):
        from setting_references import add_reference,validate
        from figure_folders import sort_blocks
        p=self.sample();b=p['blocks'][0];b['commands']=extract_appearance(b['commands'],deduplicate=False)
        b['commands']=add_reference(b['commands'],0)
        source=b['commands'][0]['setting_id'];q=sort_blocks(p,[b['id']]);self.compare(p,q)
        commands=q['blocks'][0]['commands'];self.assertEqual(validate(commands),[])
        self.assertTrue(any(c.get('setting_id')==source for c in commands));self.assertTrue(any(c.get('setting_ref')==source for c in commands))
        with self.assertRaises(ValueError):sort_folder(p,root_for(p)['id'])
