import unittest,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from test_native_operations import project,command
from engine import compile_project
from selection_sets import select_queries,resolve
from test_cad_state import read_form

class SelectionSubtract(unittest.TestCase):
 def test_enclosed_line_can_be_removed_from_circle_window_and_copy(self):
  circle=dict(type='CIRCLE',x='0',y='0',r='10')
  line=dict(type='LINE',x1='-2',y1='0',x2='2',y2='0')
  sid='p_'+'a'*32
  plus=dict(mode='window',x1='-11',y1='-11',x4='11',y4='11')
  minus=dict(mode='point',x1='0',y1='0',entity_type='LINE',operation='subtract')
  selector=dict(type='SELECT',point_id=sid,selection_name='円だけ',selections=[plus,minus])
  p=project([circle,line,selector,command('COPY',selection_ref=sid,x2='0',y2='0',x3='30',y3='0')])
  script,items=compile_project(json.loads(json.dumps(p)),[0])
  self.assertEqual(items[2]['selected_count'],1)
  self.assertEqual(len(items[-1]['children']),1)
  self.assertEqual(items[-1]['children'][0]['display_type'],'CIRCLE')
  self.assertIn('(ssdel (ssname part index) selected)',script)
  for text in script.splitlines():
   if text.startswith('('):read_form(text)
 def test_exclusions_apply_after_all_additions(self):
  a=dict(type='LINE',coords=(0,0,10,0));b=dict(type='LINE',coords=(0,5,10,5))
  minus=dict(mode='point',point=(5,0),operation='subtract')
  plus=dict(mode='window',box=(-1,-1,11,6))
  result=select_queries([a,b],[minus,plus,plus],.01)
  self.assertEqual(len(result),1);self.assertIs(result[0],b)
 def test_invalid_operation_is_rejected(self):
  with self.assertRaises(ValueError):resolve(dict(selections=[dict(mode='point',x1='0',y1='0',operation='invalid')]),{},lambda v,c:float(v))
 def test_selected_extents_become_references_and_preserve_exclusions(self):
  from selection_reference_bounds import referenced_selection
  from engine import number
  sid='p_'+'a'*32;cid='p_'+'b'*32;lid='p_'+'c'*32
  circle=dict(type='CIRCLE',point_id=cid,x='0',y='0',r='10')
  line=dict(type='LINE',point_id=lid,x1='-2',y1='0',x2='2',y2='0')
  _,items=compile_project(project([circle,line]),[0])
  selector=dict(type='SELECT',point_id=sid,selection_name='円のみ',selections=[dict(mode='window',x1='-11',y1='-11',x4='11',y4='11'),dict(mode='point',x1='0',y1='0',entity_type='LINE',operation='subtract')])
  changed=referenced_selection(selector,items,{},number,lambda item:item['point_id'])
  self.assertIn(cid,changed['selections'][0]['x1'])
  self.assertNotIn(lid,changed['selections'][0]['x1'])
  self.assertEqual(changed['selections'][1],selector['selections'][1])
  for radius in ('10','15'):
   _,result=compile_project(project([dict(circle,r=radius),line,changed]),[0])
   self.assertEqual(result[-1]['selected_count'],1)
  self.assertNotEqual(selector['selections'][0],changed['selections'][0])
 def test_empty_exclusions_are_noop_but_ambiguous_pick_is_rejected(self):
  from selection_sets import native_collect
  a=dict(type='LINE',coords=(0,0,10,0))
  qs=[dict(mode='window',box=(-1,-1,11,1)),dict(mode='point',point=(50,50),operation='subtract'),dict(mode='window',box=(40,40,60,60),operation='subtract')]
  self.assertEqual(select_queries([a],qs,.01),[a])
  script=native_collect(qs,.01,'chosen')
  self.assertIn('(if (> (length found) 1)',script)
  self.assertIn('(if (not result) (setq result (ssadd)))',script)
  read_form(script)
  with self.assertRaises(ValueError):select_queries([a,dict(a)], [dict(mode='point',point=(5,0),operation='subtract')],.01)
