"""Pure point-pick builders. Coordinate/length expressions remain parametric."""
import copy,math
from command_points import geometry_points,reference
from vertex_points import MAX_VERTICES,points_text,vertex_id
KINDS=frozenset(('LINE','POLYLINE','CIRCLE','RECTANGLE','ARC','ELLIPSE','POINT','HATCH','SPLINE','LEADER','TEXT','MTEXT','DIMLINEAR','DIMALIGNED','DIMRADIUS','DIMDIAMETER','INSERT'))
_PATHS=frozenset(('LINE','POLYLINE','HATCH','SPLINE','LEADER'))
_COUNTS=dict(POINT=1,TEXT=1,INSERT=1,CIRCLE=2,RECTANGLE=2,MTEXT=2,ARC=3,ELLIPSE=3,DIMLINEAR=3,DIMALIGNED=3,DIMRADIUS=2,DIMDIAMETER=2)
def _kind(c):return str(c.get('type','')).upper()
def variable(c):return _kind(c) in _PATHS
def minimum(c):
 k=_kind(c)
 if k not in KINDS:raise ValueError('このコマンドはプレビュー入力に対応していません')
 return (3 if k=='HATCH' else 2) if k in _PATHS else _COUNTS[k]
def hint(c,picks):
 k,n=_kind(c),len(picks)
 if k in _PATHS:
  if not n:return '閉じた境界を選択、または境界の始点をクリック' if k=='HATCH' else '矢印先端をクリック' if k=='LEADER' else '始点をクリック'
  return '次の点をクリック' if n<minimum(c) else '次の点をクリック。Enterまたは「点を確定」で確定'
 if k in ('DIMRADIUS','DIMDIAMETER'):return '測定する円・円弧をクリック' if not n else '寸法文字の位置をクリック'
 if k in ('DIMLINEAR','DIMALIGNED'):return '測定の始点をクリック（線分クリックでも指定できます）' if not n else '寸法線の位置をクリック' if n>1 or _line_source(picks[0]) else '測定の終点をクリック'
 if k=='ARC':return {'center_angles':('中心','始点（半径）','終点の方向'),'three_points':('始点','通過点','終点'),'start_center_end':('始点','中心','終点の方向')}[c.get('arc_mode','center_angles')][min(n,2)]+'をクリック'
 steps={'CIRCLE':('中心をクリック','円周上の点をクリックしてサイズ指定'),'RECTANGLE':('最初の対角点をクリック','反対の対角点をクリック'),'ELLIPSE':('中心をクリック','長軸端点をクリック','短軸の幅をクリック'),'POINT':('配置位置をクリック',),'TEXT':('文字の挿入点をクリック',),'MTEXT':('文字枠の挿入点をクリック','文字枠の幅をクリック'),'INSERT':('ブロックの挿入点をクリック',)}
 values=steps[k];return values[min(n,len(values)-1)]
def _number(v):return format(float(v),'.12g')
def _pick(p):
 try:xy=tuple(float(v) for v in p['xy'])
 except (KeyError,TypeError,ValueError):raise ValueError('プレビュー上の点を指定してください') from None
 if len(xy)!=2 or not all(math.isfinite(v) for v in xy):raise ValueError('座標は有限数値で指定してください')
 return dict(xy=xy,x=str(p.get('x') or _number(xy[0])),y=str(p.get('y') or _number(xy[1])))
def _set(c,p,suffix=''):c['x'+suffix],c['y'+suffix]=p['x'],p['y']
def _difference(a,b,axis):return f"(({b[axis]}) - ({a[axis]}))"
def _distance(a,b):
 try:
  delta=[float(b[axis])-float(a[axis]) for axis in ('x','y')]
 except ValueError:
  return f"sqrt({_difference(a,b,'x')} ** 2 + {_difference(a,b,'y')} ** 2)"
 return _number(math.hypot(*delta))
def _separate(a,b,message='異なる位置の点を指定してください'):
 if math.dist(a['xy'],b['xy'])<=1e-12:raise ValueError(message)
def _source_type(p):
 s=p.get('source') or {};return s.get('display_type',s.get('type',''))
def _source_point(p,name):
 try:points=geometry_points(p.get('source') or {})
 except (KeyError,IndexError,TypeError,ValueError):points={}
 if name not in points:raise ValueError('参照できる図形をクリックしてください')
 key=p.get('key');return _pick(dict(xy=points[name],x=reference(key,name,'X') if key else None,y=reference(key,name,'Y') if key else None))
def _line_source(p):
 s=p.get('source') or {}
 if _source_type(p)!='LINE' or len(s.get('coords',()))!=4:return False
 try:_source_point(p,'始点');_source_point(p,'終点')
 except ValueError:return False
 return True
def boundary_picks(pick):
 s=pick.get('source') or {};kind=_source_type(pick);key=pick.get('key')
 if s.get('operation_deleted') or s.get('segments') or s.get('children'):return None
 if kind=='RECTANGLE':names=('左下','右下','右上','左上')
 elif kind in ('POLYLINE','HATCH') and (s.get('closed') or kind=='HATCH') and not any(s.get('bulges',[])):
  coords=s.get('coords',());names=tuple(f'頂点{i+1}' for i in range(len(coords)//2))
 else:return None
 points=geometry_points(s)
 if kind=='HATCH':return None  # HATCH currently exposes only its start reference.
 result=[]
 for name in names:
  if name not in points:return None
  q=_source_point(pick,name);q.update(source=s,key=key,snap_name=name);result.append(q)
 return result

def _path(c,picks):
 k=_kind(c);closing=len(picks)>2 and picks[0]['xy']==picks[-1]['xy']
 if k in ('HATCH','POLYLINE') and closing:picks=picks[:-1]
 if len(picks)<minimum(c):raise ValueError('境界は3点以上、線は2点以上を指定してください')
 limit=500 if k=='HATCH' else MAX_VERTICES
 if len(picks)>limit:raise ValueError(f'1コマンドは{limit}点までです')
 for a,b in zip(picks,picks[1:]):_separate(a,b,'隣り合う点は異なる位置にしてください')
 old=c.get('vertices',[]);vs=[]
 for i,p in enumerate(picks):vs.append(dict(id=(old[i].get('id') if i<len(old) and isinstance(old[i],dict) else None) or vertex_id(),x=p['x'],y=p['y']))
 for key in list(c):
  if key[:1] in ('x','y') and key[1:].isdigit():c.pop(key)
 c['vertices'],c['points']=vs,points_text(vs)
 if k=='LINE':_set(c,picks[0],'1');_set(c,picks[-1],'2')
 if k=='POLYLINE':c['closed']='1' if closing else c.get('closed','0') if len(picks)>=3 else '0'
 if k=='HATCH':
  from extended_commands import polygon_valid
  polygon_valid([p['xy'] for p in picks]);c.setdefault('pattern','ANSI31');c.setdefault('scale','1');c.setdefault('angle','0')
 if k=='LEADER':c.setdefault('text','注記');c.setdefault('height','settings.TEXT_HEIGHT')
def build(command,picks):
 d=copy.deepcopy(command);k,required=_kind(command),minimum(command)
 if k in _PATHS:_path(d,[_pick(p) for p in picks]);return d
 shortcut=k in ('DIMLINEAR','DIMALIGNED') and len(picks)==2 and _line_source(picks[0])
 if len(picks)!=required and not shortcut:raise ValueError(f'{required}点を指定してください')
 ps=[_pick(p) for p in picks]
 if k in ('POINT','TEXT','INSERT'):
  _set(d,ps[0])
  if k=='TEXT':d.setdefault('text','文字');d.setdefault('height','settings.TEXT_HEIGHT');d.setdefault('angle','0')
  elif k=='INSERT':d.setdefault('scale_x','1');d.setdefault('scale_y','1');d.setdefault('angle','0')
 elif k=='CIRCLE':
  _separate(*ps,'半径が0にならない点を指定してください');_set(d,ps[0]);d['r']=_distance(*ps)
  if d.get('circle_mode')=='diameter':
   try:d['diameter']=_number(2*float(d['r']))
   except ValueError:d['diameter']=f"2 * ({d['r']})"
 elif k=='RECTANGLE':
  if any(abs(ps[1]['xy'][i]-ps[0]['xy'][i])<=1e-12 for i in (0,1)):raise ValueError('幅と高さを0以外にしてください')
  _set(d,ps[0],'1');_set(d,ps[1],'2')
 elif k=='ARC':
  mode=d.get('arc_mode','center_angles')
  if mode=='center_angles':
   center,start,end=ps;_separate(center,start);_separate(center,end)
   sa=math.degrees(math.atan2(start['xy'][1]-center['xy'][1],start['xy'][0]-center['xy'][0]))%360;ea=math.degrees(math.atan2(end['xy'][1]-center['xy'][1],end['xy'][0]-center['xy'][0]))%360
   if math.isclose((ea-sa)%360,0,abs_tol=1e-9):raise ValueError('開始方向と異なる終了方向を指定してください')
   _set(d,center);d.update(r=_distance(center,start),start_angle=_number(sa),end_angle=_number(ea))
  elif mode in ('three_points','start_center_end'):
   from arc_modes import arc_geometry
   if mode=='start_center_end':
    start,center,end=ps;_separate(center,start);_separate(center,end);r,dist=_distance(center,start),_distance(center,end);ratio=math.dist(center['xy'],start['xy'])/math.dist(center['xy'],end['xy'])
    end=dict(xy=tuple(c+(e-c)*ratio for c,e in zip(center['xy'],end['xy'])),**{a:f"({center[a]}) + {_difference(center,end,a)} * ({r}) / ({dist})" for a in ('x','y')});ps=[start,center,end]
   arc_geometry(mode,[p['xy'] for p in ps])
   for i,p in enumerate(ps,1):_set(d,p,str(i))
  else:raise ValueError('円弧の入力方式を選択してください')
 elif k=='ELLIPSE':
  center,major,minor=ps;_separate(center,major);dx,dy=(major['xy'][i]-center['xy'][i] for i in (0,1));r=math.hypot(dx,dy);mx,my=(minor['xy'][i]-center['xy'][i] for i in (0,1));short=abs(dx*my-dy*mx)/r
  if short<=1e-12 or short>r+1e-9:raise ValueError('短軸半径は0より大きく長軸半径以下にしてください')
  _set(d,center);d.update(rx=_distance(center,major),ry=f"abs({_difference(center,major,'x')} * {_difference(center,minor,'y')} - {_difference(center,major,'y')} * {_difference(center,minor,'x')}) / ({_distance(center,major)})",angle=_number(math.degrees(math.atan2(dy,dx))%360))
 elif k=='MTEXT':
  a,b=ps;_separate(a,b);angle=str(d.get('angle','0'))
  try:r=math.radians(float(angle))
  except ValueError:r=None
  if r is not None and abs((b['xy'][0]-a['xy'][0])*math.cos(r)+(b['xy'][1]-a['xy'][1])*math.sin(r))<=1e-12:raise ValueError('文字枠の幅を0以外にしてください')
  _set(d,a);d['width']=f"abs({_difference(a,b,'x')} * cos(radians({angle})) + {_difference(a,b,'y')} * sin(radians({angle})))";d.setdefault('height','settings.TEXT_HEIGHT');d.setdefault('text','文字')
 elif k in ('DIMLINEAR','DIMALIGNED'):
  if shortcut:ps=[_source_point(picks[0],'始点'),_source_point(picks[0],'終点'),ps[1]]
  _separate(ps[0],ps[1])
  for i,p in enumerate(ps,1):_set(d,p,str(i))
 elif k in ('DIMRADIUS','DIMDIAMETER'):
  if _source_type(picks[0]) not in ('CIRCLE','ARC'):raise ValueError('測定する円・円弧をクリックしてください')
  center=_source_point(picks[0],'中心');edge=_source_point(picks[0],'右' if _source_type(picks[0])=='CIRCLE' else '始点');_separate(center,edge);_separate(center,ps[1],'寸法位置を中心以外にしてください');_set(d,center);_set(d,ps[1],'3');d['r']=_distance(center,edge)
 return d
