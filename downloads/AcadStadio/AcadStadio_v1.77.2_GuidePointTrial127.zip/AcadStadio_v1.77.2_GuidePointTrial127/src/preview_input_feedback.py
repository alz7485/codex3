"""Side-effect-free feedback for non-geometric commands."""
import math
def execution_label(command):return '生成全体で1回' if command.get('execution','per_row')=='once' else '対象の各行で実行'
def rendered_value(raw,kind,context,evaluate):
 if kind not in ('number','text'):raise ValueError('値の種類を選択してください')
 if kind=='number':
  value=evaluate(raw,context)
  if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or abs(value)>1e12:raise ValueError('有限の数値（±1e12以内）を指定してください')
  return format(value,'.12g')
 value=evaluate(raw[1:],context) if isinstance(raw,str) and raw.startswith('=') else raw
 if type(value) not in (str,int,float,bool):raise ValueError('数値または文字列を指定してください')
 text=format(value,'.12g') if type(value) in (int,float) else str(value)
 if not text:raise ValueError('システム変数の値を入力してください')
 if len(text)>2048 or any(ord(c)<32 or ord(c)==127 for c in text):raise ValueError('改行・制御文字を含まない2048文字以内の値にしてください')
 return text
def _shown(value,limit=90):
 text=format(value,'.12g') if type(value) in (int,float) else str(value)
 return text if len(text)<=limit else text[:limit-1]+'…'
def status(command,context,evaluate):
 k=str(command.get('type','')).upper()
 try:
  if k=='IF':
   passed=bool(evaluate(command.get('condition',''),context));branch='IF' if passed else 'ELSE';commands=command.get('commands' if passed else 'else',[])
   return f"条件{'成立' if passed else '不成立'} → {branch}側の{len(commands)}コマンドを実行"
  if k=='REPEAT':
   count=evaluate(command.get('count',''),context)
   if isinstance(count,bool) or not isinstance(count,(int,float)) or not math.isfinite(count) or count!=int(count) or not 0<=count<=1000:raise ValueError('反復回数は0〜1000の整数にしてください')
   return '繰り返し0回：内部のコマンドは実行しません' if count==0 else f"繰り返し{int(count)}回 / 1回あたり{len(command.get('commands',[]))}コマンド"
  if k=='SET':return f"変数 {command.get('name','')} = {_shown(evaluate(command.get('value',''),context))}"
  if k=='SYSVAR':return f"{command.get('name','').upper()} = {_shown(rendered_value(command.get('value',''),command.get('value_kind','number'),context,evaluate))} / {execution_label(command)}"
  if k=='SYSVARS':
   from layout_commands import validate_batch
   items=command.get('items',[]);validate_batch(items)
   values=[f"{i['name'].upper()} = {_shown(rendered_value(i.get('value',''),i.get('value_kind','number'),context,evaluate),35)}" for i in items]
   return f'{len(items)}項目 / {execution_label(command)}：'+'、'.join(values[:3])+(' …' if len(values)>3 else '')
  if k=='APPEARANCE':
   labels={'layer':'レイヤー','color':'色','linetype':'線種','linetype_scale':'線種尺度','text_style':'文字スタイル','dim_style':'寸法スタイル','lineweight':'線の太さ'}
   changes=[f'{label}：{_shown(command[field],24)}' for field,label in labels.items() if str(command.get(field,'')).strip()]
   return '以降の図形に適用：'+'、'.join(changes)+'。この設定だけでは図形を作成しません。' if changes else '空欄は直前の設定を引き継ぎます。先頭ではCADの現在値を使います。'
  if k=='REGEN':return f"{command.get('regen_scope','現在のビュー')}を再作図 / {execution_label(command)}（CADで実行）"
  if k=='CUSTOM':return '登録コマンドはSCRに出力します。図形の結果はCADで確認してください。'
 except (ValueError,TypeError,KeyError,ArithmeticError) as exc:return '入力を確認：'+_shown(exc,160)
 return ''
