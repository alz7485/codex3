"""Preview-only SELECT interaction; references are generated behind the scenes."""
import copy
import tkinter as tk
from tkinter import ttk,messagebox
from selection_sets import resolve,select_queries

class SelectionEditor:
    def __init__(self,win,get_data,apply_data,get_canvas,refresh,identity=None):
        self.win=win;self.get_data=get_data;self.apply_data=apply_data;self.get_canvas=get_canvas;self.refresh=refresh
        self.capturing=False;self.updating=False;self.identity=identity
        self.simple=False;self.simple_count=tk.StringVar(master=win,value='0 図形を選択')
        self.context=None;self.number=None

    def build_simple(self,host):
        self.simple=True
        for child in host.winfo_children():child.destroy()
        bar=ttk.Frame(host);bar.pack(fill='x')
        ttk.Label(bar,text=getattr(self,'purpose','') or '図形を選択',style='Section.TLabel').pack(side='left')
        ttk.Label(bar,textvariable=self.simple_count).pack(side='left',padx=18)
        ttk.Button(bar,text='元に戻す',command=self.win.undo_draft).pack(side='right',padx=6)
        ttk.Button(bar,text='すべて解除',command=self.clear).pack(side='right')
        ttk.Label(host,text='クリックで選択・解除。ドラッグで囲んで選択。Shift＋ドラッグでまとめて解除。',style='Muted.TLabel').pack(anchor='w',pady=(6,0))

    def simple_point(self,position,source):
        self.simple_sources([source],position,None)

    def simple_rectangle(self,a,b,remove=False):
        from range_selection import select_range
        mode='window' if b[0]>=a[0] else 'crossing'
        box=(min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1]))
        try:
            canvas=self.get_canvas();sources=select_range(canvas.items,box,mode)
            if not sources:return
            if self.simple_sources(sources,a,remove,report=False):return
            # Coincident figures cannot be addressed by an unambiguous point.
            # Preserve the user's exact window/crossing query as the fallback.
            from cad_drawing_import import number as literal
            query=dict(mode=mode,operation='subtract' if remove else 'add',
                       x1=literal(box[0]),y1=literal(box[1]),x4=literal(box[2]),y4=literal(box[3]))
            data=self.get_data();queries=copy.deepcopy(data.get('selections',[]))
            if not remove:
                # SELECT evaluates subtraction last. Re-adding the same window
                # must retire its earlier subtraction rather than stay empty.
                resolved=resolve(data,self.context,self.number) if queries else []
                queries=[q for q,value in zip(queries,resolved) if not (
                    q.get('operation')=='subtract' and value['mode']==mode and
                    value.get('box')==box)]
            data['selections']=queries+[query]
            if len(data['selections'])>1000:raise ValueError('選択条件は1000件までです。')
            self.change(data)
        except ValueError as exc:messagebox.showinfo('図形の選択',str(exc),parent=self.win)

    def simple_sources(self,sources,position,remove,report=True):
        if not sources:return
        from selection_pick_reference import exclusion_reference
        try:
            if self.context is None:raise ValueError('プレビューの計算完了をお待ちください。')
            canvas=self.get_canvas();data=self.get_data()
            tolerance=float(self.number(data.get('pick_tolerance','0.01'),self.context))
            current=select_queries(canvas.items,resolve(data,self.context,self.number),tolerance) if data.get('selections') else []
            queries=copy.deepcopy(data.get('selections',[]))
            staged=[]
            for source in sources:
                selected=any(item is source for item in current)
                subtract=selected if remove is None else remove
                if remove is not None and selected==(not remove):continue
                # Verify every figure before registering IDs or changing the draft.
                exclusion_reference(source,canvas.items,position,tolerance,lambda item:'p_'+'0'*32)
                staged.append((source,subtract))
            for source,subtract in staged:
                query=exclusion_reference(source,canvas.items,position,tolerance,self.identity or (lambda item:item.get('point_id')))
                query['operation']='subtract' if subtract else 'add'
                # A figure selected again must not stay excluded by its earlier query.
                key=(self.identity(source) if self.identity else source.get('point_id'))
                if key:
                    queries=[q for q in queries if q.get('simple_source')!=key and not (q.get('mode')=='point' and repr(key) in str(q.get('x1','')))]
                    query['simple_source']=key
                queries.append(query)
            if len(queries)>1000:
                raise ValueError('一度に選べる図形は1000件までです。')
            data['selections']=queries
            self.change(data)
            return True
        except ValueError as exc:
            if report:messagebox.showinfo('図形の選択',str(exc),parent=self.win)
            return False

    def change(self,data):
        self.updating=True
        try:self.apply_data(data)
        finally:self.updating=False

    def clear(self):
        data=self.get_data();data['selections']=[];self.change(data)

    def stop(self):
        self.capturing=False
        canvas=self.get_canvas()
        if canvas is not None:canvas.cancel_range()

    def start(self,force=False):
        canvas=self.get_canvas()
        if canvas is None:return
        if self.capturing and not force:self.stop();self.refresh();return
        self.capturing=True
        canvas.begin_object_selection(self.simple_point,self.simple_rectangle)

    def overlays(self,context,number):
        self.context=context;self.number=number
        canvas=self.get_canvas()
        if canvas is None:return
        try:queries=resolve(self.get_data(),context,number)
        except (ValueError,KeyError):queries=[]
        canvas.selection_rectangles=[(q['box'],q['mode']) for q in queries if q['mode']!='point']
        canvas.selection_points=[]
        canvas.reference_bounds=[p for q in queries for p in ([q['point']] if q['mode']=='point' else [q['box'][:2],q['box'][2:]])]
        try:members=select_queries(canvas.items,queries,float(number(self.get_data().get('pick_tolerance','0.01'),context))) if queries else []
        except (ValueError,KeyError):members=[]
        canvas.selection_count=len(members)
        self.simple_count.set(f'{len(members)} 図形を選択')
        canvas.selected_entity_ids={id(s) for s in members if s.get('entity_parent') is None}
        canvas.selected_segments=[s['coords'] for s in members if s.get('entity_parent') is not None]
        canvas.selection_active=True
        canvas.fit(preserve=True,preserve_camera=True)
        if self.simple:self.start(force=True)

