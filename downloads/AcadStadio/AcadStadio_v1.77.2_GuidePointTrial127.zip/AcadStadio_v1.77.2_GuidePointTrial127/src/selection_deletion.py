"""Plan SELECT deletion without silently changing dependent operations."""
import copy
from selection_sets import OPERATORS

def plan(commands, indices):
    removed=set(indices);lost={};fallback={}
    def selectors(items):
        for c in items:
            if c.get('type')=='SELECT':yield c.get('point_id')
            yield from selectors(c.get('commands',[]));yield from selectors(c.get('else',[]))
    targets=set(selectors([commands[i] for i in removed]))
    for i in sorted(removed):
        c=commands[i]
        if c.get('type')=='SELECT' and i>0 and i-1 not in removed and commands[i-1].get('type')=='SELECT':
            fallback[c.get('point_id')]=commands[i-1].get('point_id')
    def visit(items,previous=None,path=()):
        for i,c in enumerate(items):
            here=path+(i,)
            if c.get('type')=='SELECT':previous=c.get('point_id')
            if c.get('type') in OPERATORS:
                ref=c.get('selection_ref');key=previous if ref=='@previous' else ref
                if key in targets and key is not None:lost[here]=(key,ref)
            visit(c.get('commands',[]),previous,here+('commands',))
            visit(c.get('else',[]),previous,here+('else',))
    visit(commands)
    lost={p:v for p,v in lost.items() if p[0] not in removed}
    return lost,fallback

def apply(commands,indices,keep=False):
    lost,fallback=plan(commands,indices)
    if keep and any(key not in fallback for key,_ in lost.values()):raise ValueError('選択対象を引き継げないコマンドがあります。')
    def build(items,path=()):
        result=[]
        for i,c in enumerate(items):
            here=path+(i,)
            if not path and i in indices:continue
            if here in lost and not keep:continue
            c=copy.deepcopy(c)
            if here in lost:c['selection_ref']=fallback[lost[here][0]]
            for field in ('commands','else'):
                if field in c:c[field]=build(c[field],here+(field,))
            result.append(c)
        return result
    return build(commands)
