"""Input-mode changes preserve geometry and existing references."""
import ast,copy,math
from arc_modes import MODES,arc_geometry
ARC_FIELDS=frozenset(('x','y','r','start_angle','end_angle','x1','y1','x2','y2','x3','y3'))
FUNCS=frozenset(('abs','min','max','round','sqrt','sin','cos','tan','radians'))
def _literal(v):
 n=float(v)
 if not math.isfinite(n):raise ValueError('有限数値を指定してください')
 return format(0 if abs(n)<1e-12 else n,'.12g')
def _scaled(v,factor):
 text=str(v).strip()
 if not text:raise ValueError('サイズを入力してから方式を切り替えてください')
 try:return _literal(float(text)*factor)
 except ValueError:return f'({text}) * 2' if factor==2 else f'({text}) / 2'
def _arc_number(v,ctx,evaluate):
 if isinstance(v,bool):raise ValueError('円弧の座標・サイズは数値で指定してください')
 try:n=float(v)
 except (ValueError,TypeError):
  try:node=ast.parse(str(v).strip(),mode='eval')
  except (SyntaxError,ValueError):raise ValueError('表・変数・点を参照する円弧はこの方式のまま編集してください') from None
  if evaluate is None or any(isinstance(a,ast.Attribute) or isinstance(a,ast.Name) and a.id not in FUNCS for a in ast.walk(node)):raise ValueError('式を使う円弧はこの方式のまま編集してください')
  n=evaluate(v,ctx or {})
  if isinstance(n,bool) or not isinstance(n,(int,float)):raise ValueError('円弧の値は数値で指定してください')
 if not math.isfinite(n):raise ValueError('有限数値を指定してください')
 return n
def preserve_input_mode(command,field,new_mode,saved=None,*,context=None,evaluate=None):
 d=copy.deepcopy(command);k=command.get('type')
 if field=='circle_mode' and k=='CIRCLE':
  if new_mode not in ('radius','diameter'):raise ValueError('半径または直径を選択してください')
  if command.get(field,'radius')!=new_mode:
   src,dest,factor=('r','diameter',2) if new_mode=='diameter' else ('diameter','r',.5)
   if src not in command:raise ValueError('サイズを入力してから方式を切り替えてください')
   d[dest]=_scaled(command[src],factor);d.pop(src,None)
 elif field=='arc_mode' and k=='ARC' and command.get(field,'center_angles')!=new_mode:
  if new_mode not in MODES:raise ValueError('円弧の入力方式を選択してください')
  old=command.get(field,'center_angles')
  # Center-angle representation can be converted symbolically, retaining table references.
  if old=='center_angles' and new_mode in ('three_points','start_center_end'):
   cx,cy,r,sa,ea=(str(command.get(key,default)) for key,default in [('x','0'),('y','0'),('r','25'),('start_angle','0'),('end_angle','90')])
   for key in ARC_FIELDS:d.pop(key,None)
   angles=[sa,None if new_mode=='start_center_end' else f'({sa})+((({ea})-({sa}))%360)/2',ea]
   for i,a in enumerate(angles,1):
    d['x'+str(i)]=cx if a is None else f'({cx})+({r})*cos(radians({a}))'
    d['y'+str(i)]=cy if a is None else f'({cy})+({r})*sin(radians({a}))'
  else:
   n=lambda key:_arc_number(command[key],context,evaluate)
   try:center,r,start,sweep=arc_geometry(old,[(n('x'+str(i)),n('y'+str(i))) for i in (1,2,3)])
   except KeyError as exc:raise ValueError('円弧の値を指定してから方式を切り替えてください') from exc
   if sweep<0 and new_mode!='three_points':raise ValueError('時計回りの円弧は3点方式のまま編集してください')
   for key in ARC_FIELDS:d.pop(key,None)
   if new_mode=='center_angles':d.update(x=_literal(center[0]),y=_literal(center[1]),r=_literal(r),start_angle=_literal(start),end_angle=_literal(start+sweep))
   else:
    def p(t):
     a=math.radians(start+sweep*t);return center[0]+r*math.cos(a),center[1]+r*math.sin(a)
    for i,xy in enumerate([p(0),center if new_mode=='start_center_end' else p(.5),p(1)],1):d['x'+str(i)],d['y'+str(i)]=map(_literal,xy)
 d[field]=copy.deepcopy(new_mode);return d
