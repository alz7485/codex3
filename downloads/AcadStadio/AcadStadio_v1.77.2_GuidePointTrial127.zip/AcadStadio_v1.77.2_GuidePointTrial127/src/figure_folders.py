"""Transactional organization of imported figures without freezing table formulas."""
import copy
import json
from collections import Counter
from block_model import new_block
from block_folders import create_folder, descendant_ids
from block_operations import _remap, suggested_name
from command_types import DIMENSION_TYPES
from appearance_commands import FIELDS, extract_appearance
from setting_references import registry, resolve
from space_folders import ensure_space_folders, root_for, folder_space
from project_model import validate_sequential_project
from project_data import get_rows
from engine import compile_project

KINDS = frozenset(('LINE','POLYLINE','CIRCLE','ARC','ELLIPSE','RECTANGLE','POINT','SPLINE','HATCH','TEXT','MTEXT')) | DIMENSION_TYPES
ATTRS = (*FIELDS, 'lineweight')
GROUPS = ('作図','寸法','テキスト')


def category(command):
    return '寸法' if command['type'] in DIMENSION_TYPES else 'テキスト' if command['type'] in ('TEXT','MTEXT') else '作図'


def eligible(command):
    return command.get('type') in KINDS and bool(command.get('import_source')) and bool(command.get('point_id'))


def _attributes(command, state):
    result = {k:v for k,v in state.items() if k in ATTRS and str(v).strip()}
    if command['type'] not in ('TEXT','MTEXT'): result.pop('text_style',None)
    if command['type'] not in DIMENSION_TYPES: result.pop('dim_style',None)
    return result


def expanded_blocks(project):
    """Retain raw attribute expressions and figure identities, never sampled values."""
    state = {}
    output = []
    for block in project['blocks']:
        local = dict(state) if block.get('guide') else state
        sources = registry(block['commands'])
        commands = []
        safe = not block.get('variables') and not block.get('condition','').strip()
        for original in block['commands']:
            command = copy.deepcopy(original)
            actual = resolve(command,sources)
            typ = actual['type']
            if typ == 'APPEARANCE':
                if actual.get('condition','').strip(): safe = False
                for key in ATTRS:
                    if str(actual.get(key,'')).strip(): local[key] = actual[key]
            elif typ in KINDS:
                for key in ATTRS:
                    if str(command.get(key,'')).strip(): local[key] = command[key]
                command.update(_attributes(command,local))
                if command.get('condition','').strip(): safe = False
            elif typ != 'VIEWPORT' or actual.get('viewport_action','矩形を作成') != '矩形を作成':
                safe = False
                local.clear()
            commands.append(command)
        output.append((commands,safe))
    return output


def _visual_signature(items):
    # Ignore execution addresses and grouping metadata, retain all visible geometry.
    drop = {'row','block','block_index','preset','preset_index','command_index','command_path','command_addresses','definition_block_index','point_id','point_block_id','loop_index','guide','_logical_parent','_selection_parts'}
    def clean(item):
        item = dict(item)
        item['layer'] = item.pop('effective_layer', item.get('layer',''))
        if item.get('type') not in DIMENSION_TYPES: item.pop('dim_style',None)
        if item.get('type') not in ('TEXT','MTEXT'): item.pop('text_style',None)
        return {k:([clean(v) for v in value] if k in ('children','block_geometry') else value)
                for k,value in item.items() if k not in drop and not k.startswith('_')}
    return Counter(json.dumps(clean(i),ensure_ascii=False,sort_keys=True,default=str) for i in items if not i.get('guide'))


def _verify(before, after):
    errors = validate_sequential_project(after)
    if errors: raise ValueError('\n'.join(errors[:6]))
    # Compare every table row independently; formulas remain formulas in the data.
    for row in range(len(get_rows(before))):
        old = compile_project(before,[row])[1]
        new = compile_project(after,[row])[1]
        if _visual_signature(old) != _visual_signature(new):
            raise ValueError(f'{row+1}行目の作図属性や図形が変わるため整理を取り消しました。条件・設定コマンドの影響を確認してください。')


def folderize(project, selection, name, space='Model'):
    """Selection is a set of (block ID, point ID), not rendered row instances."""
    if not selection: raise ValueError('フォルダ化する読込図形を選択してください。')
    trial = copy.deepcopy(project); ensure_space_folders(trial)
    expanded = expanded_blocks(trial)
    buckets = {group:[] for group in GROUPS}
    owners = {}; moved = {}; sources = set(); found = set()
    try: root = root_for(trial,space)
    except StopIteration: raise ValueError('選択したモデル／レイアウトがありません。') from None
    folder = create_folder(trial,name,root['id'])
    for bi,block in enumerate(trial['blocks']):
        choices = [(ci,c) for ci,c in enumerate(block['commands']) if (block['id'],c.get('point_id')) in selection]
        if not choices: continue
        if block.get('guide') or folder_space(trial,block.get('folder_id','')) != space:
            raise ValueError('同じモデル／レイアウト内の読込図形を選択してください。')
        commands,safe = expanded[bi]
        if not safe: raise ValueError('条件・変数・編集操作を含むブロックは範囲で分割できません。読込図形と作図属性のブロックを選択してください。')
        sources.add(block['id']); moved[block['id']] = {}
        for ci,c in choices:
            if not eligible(c): raise ValueError('読込元を持つ独立した図形を選択してください。')
            group=category(c); moved[block['id']][ci]=group; found.add((block['id'],c['point_id']))
        block['commands'] = commands
    if found != set(selection): raise ValueError('選択した図形が変更されています。選択し直してください。')
    new_blocks={group:new_block() for group in {g for choices in moved.values() for g in choices.values()}}
    for block in trial['blocks']:
        for ci,group in moved.get(block['id'],{}).items(): owners[id(block['commands'][ci])] = new_blocks[group]['id']
    _remap(trial,owners)
    insertion = max(i for i,b in enumerate(trial['blocks']) if b['id'] in sources)+1
    for block in trial['blocks']:
        choices = moved.get(block['id'])
        if choices is None: continue
        kept=[]
        for ci,command in enumerate(block['commands']):
            if ci in choices:
                buckets[choices[ci]].append(command)
            elif command['type'] != 'APPEARANCE' or command.get('setting_id'):
                kept.append(command)
        block['commands'] = extract_appearance(kept,deduplicate=False)
    created=[]
    for group in GROUPS:
        if not buckets[group]: continue
        block=new_blocks[group]
        block.update(name=suggested_name(trial,group+'ブロック'),commands=extract_appearance(buckets[group],deduplicate=False),folder_id=folder['id'],drawing_space=space)
        trial['blocks'].insert(insertion,block);insertion+=1;created.append(block['id'])
    trial['blocks'] = [b for b in trial['blocks'] if b['commands'] or b['id'] not in sources]
    from guide_blocks import repair_forward_links
    repair_forward_links(trial)
    _verify(project,trial)
    return trial,folder['id'],created


def sort_folder(project, identity):
    """Sort only an explicitly selected organizational folder, not the space root."""
    from block_folders import folder
    if folder(project,identity).get('space'):
        raise ValueError('作成したフォルダ、または整理するブロックを選択してください。')
    members=descendant_ids(project,identity)
    identities=[b['id'] for b in project['blocks'] if b.get('folder_id') in members]
    return sort_blocks(project,identities)


def sort_blocks(project, identities):
    """Stable attribute buckets; preserve canonical settings used by references."""
    wanted=set(identities)
    if not wanted: raise ValueError('整理するブロックを選択してください。')
    trial=copy.deepcopy(project)
    if not wanted <= {b['id'] for b in trial['blocks']}: raise ValueError('整理するブロックが変更されています。')
    expanded=expanded_blocks(trial)
    count=0
    for bi,block in enumerate(trial['blocks']):
        if block['id'] not in wanted: continue
        commands,safe=expanded[bi]
        if not safe: raise ValueError('条件・変数・編集操作を含むブロックは属性順に整理できません。')
        figures=[c for c in commands if c.get('type') in KINDS]
        if not figures: continue
        if any(not eligible(c) for c in figures): raise ValueError('属性順の整理は読込図形のブロックで使用してください。')
        groups={}
        for c in figures:
            key=json.dumps(_attributes(c,c),sort_keys=True,ensure_ascii=False)
            groups.setdefault(key,[]).append(c)
        sorted_figures=[c for group in groups.values() for c in group]
        settings=[c for c in block['commands'] if c.get('type') not in KINDS
                  and (c.get('type')!='APPEARANCE' or c.get('setting_id'))]
        block['commands']=extract_appearance(settings+sorted_figures,deduplicate=True)
        count+=1
    if not count: raise ValueError('整理できる読込図形がありません。')
    from guide_blocks import repair_forward_links
    repair_forward_links(trial)
    _verify(project,trial)
    return trial
