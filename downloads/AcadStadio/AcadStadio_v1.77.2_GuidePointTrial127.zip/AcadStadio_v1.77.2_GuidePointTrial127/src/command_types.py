"""Shared command categories; UI grouping does not determine engine behavior."""

COMMAND_GROUPS = (
    ("線・形状を追加 ▾", ("LINE", "POLYLINE", "CIRCLE", "ARC", "ELLIPSE", "RECTANGLE", "POINT", "SPLINE", "HATCH")),
    ("編集・複写を追加 ▾", ("SELECT", "PEDIT", "OFFSET", "TRIM", "EXTEND", "CHAMFER", "FILLET", "COPY", "MIRROR", "ROTATE", "ROTATECOPY", "ARRAYRECT", "INSERT", "CADBLOCK", "EXPLODE", "SCALE")),
    ("文字・寸法を追加 ▾", ("TEXT", "MTEXT", "LEADER", "DIMLINEAR", "DIMALIGNED", "DIMRADIUS", "DIMDIAMETER")),
    ("空間・レイアウトを追加 ▾", ("SPACE", "VIEWPORT")),
    ("設定を追加 ▾", ("APPEARANCE", "LAYEREDIT", "SYSVARS", "REGEN")),
    ("制御を追加 ▾", ("IF", "REPEAT", "SYSVAR", "CUSTOM")),
)
CONTROL_TYPES = frozenset(("SETTINGREF", "REGEN", "LAYEREDIT", "SPACE", "LAYOUT", "VIEWPORT", "SYSVARS", "SELECT", "PEDIT", "APPEARANCE", "IF", "REPEAT", "SYSVAR", "CUSTOM"))
DIMENSION_TYPES = frozenset(("LEADER", "DIMLINEAR", "DIMALIGNED", "DIMRADIUS", "DIMDIAMETER"))
DRAWING_TYPES = frozenset(kind for _, kinds in COMMAND_GROUPS for kind in kinds) - CONTROL_TYPES
GUIDE_TYPES = DRAWING_TYPES - frozenset(("OFFSET", "TRIM", "EXTEND", "CHAMFER", "FILLET", "COPY", "MIRROR", "ROTATE", "ROTATECOPY", "ARRAYRECT", "EXPLODE", "CADBLOCK", "SCALE"))
