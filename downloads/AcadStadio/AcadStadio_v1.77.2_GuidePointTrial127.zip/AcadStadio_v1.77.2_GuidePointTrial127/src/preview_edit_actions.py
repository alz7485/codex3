"""Pure preview conversions. SELECT supplies targets, or TRIM/EXTEND boundaries."""
import copy,math
KINDS=frozenset(('COPY','MIRROR','OFFSET','TRIM','EXTEND','ROTATE','ROTATECOPY','ARRAYRECT','EXPLODE','CADBLOCK','SCALE','PEDIT','CHAMFER','FILLET'))
_COUNTS=dict(COPY=2,MIRROR=2,OFFSET=1,TRIM=1,EXTEND=1,ROTATE=2,ROTATECOPY=2,ARRAYRECT=3,EXPLODE=0,CADBLOCK=1,SCALE=3,PEDIT=0,CHAMFER=2,FILLET=2)
_STEPS={
'COPY':('コピーの基点をクリック','コピーの移動先をクリック'),
'MIRROR':('対称軸の始点をクリック','対称軸の終点をクリック'),
'OFFSET':('オフセットする側をクリック。線分・円では距離も指定できます。',),
'TRIM':('切断境界を確認し、削除する区間をクリック',),
'EXTEND':('延長境界を確認し、延長する端寄りをクリック',),
'ROTATE':('回転の基点をクリック','基点からの方向で角度を指定（右向き0°）'),
'ROTATECOPY':('回転複写の基点をクリック','基点からの方向で角度間隔を指定（右向き0°）'),
'ARRAYRECT':('配列の基準点をクリック','次の列の位置でX間隔を指定','次の行の位置でY間隔を指定'),
'CADBLOCK':('ブロックの挿入基点をクリック',),
'SCALE':('尺度変更の基点をクリック','変更前の長さを決める点をクリック','変更後の長さを決める点をクリック'),
'CHAMFER':('1本目の線の残したい側をクリック','2本目の線の残したい側をクリック。距離1・2は数値で調整できます。'),
'FILLET':('1本目の線の残したい側をクリック','2本目の線の残したい側をクリック。半径は数値で調整できます。')}
def _kind(command):
 k=str(command.get('type','')).upper()
 if k not in KINDS:raise ValueError('この編集はプレビュー入力に対応していません')
 return k
def variable(command):return False
def minimum(command):return _COUNTS[_kind(command)]
def hint(command,picks):
 k=_kind(command)
 if k in ('PEDIT','EXPLODE'):return '操作とプレビュー結果を確認してください。'
 return _STEPS[k][len(picks)] if len(picks)<len(_STEPS[k]) else '結果を確認してコマンドを反映してください。'
def _number(value):return format(float(value),'.12g')
def _point(pick):
 try:p=tuple(float(v) for v in pick['xy'])
 except (KeyError,TypeError,ValueError,OverflowError):raise ValueError('有効な点を指定してください') from None
 if len(p)!=2 or any(not math.isfinite(v) or abs(v)>1e12 for v in p):raise ValueError('座標は有限の±1e12以内で指定してください')
 return p
def _expression(pick,axis):
 v=pick.get(axis)
 return str(v).strip() if v is not None and str(v).strip() else _number(_point(pick)[axis=='y'])
def _set_point(command,suffix,pick):
 command['x'+suffix]=_expression(pick,'x');command['y'+suffix]=_expression(pick,'y')
def _constant(expression):
 try:v=float(expression)
 except (TypeError,ValueError):return None
 return v if math.isfinite(v) else None
def _difference(first,second,axis):
 a,b=_expression(first,axis),_expression(second,axis);av,bv=_constant(a),_constant(b)
 return _number(bv-av) if av is not None and bv is not None else f'({b}) - ({a})'
def _length(first,second):
 dx,dy=_difference(first,second,'x'),_difference(first,second,'y')
 return f'sqrt(({dx})**2 + ({dy})**2)'
def _straight_line(source):
 if not isinstance(source,dict) or source.get('segments') or source.get('children') or source.get('display_type',source.get('type'))!='LINE':return None
 try:c=tuple(float(v) for v in source['coords'])
 except (KeyError,TypeError,ValueError,OverflowError):return None
 return c if len(c)==4 and all(math.isfinite(v) for v in c) and math.dist(c[:2],c[2:])>1e-12 else None
def _offset_distance(pick):
 source=pick.get('source');line=_straight_line(source);x,y=_point(pick)
 if line:
  a,b,c,d=line;return abs((c-a)*(y-b)-(d-b)*(x-a))/math.hypot(c-a,d-b)
 if isinstance(source,dict) and source.get('display_type',source.get('type'))=='CIRCLE':
  try:cx,cy,radius=(float(v) for v in source['coords'])
  except (KeyError,TypeError,ValueError,OverflowError):return None
  if all(math.isfinite(v) for v in (cx,cy,radius)) and radius>0:return abs(math.hypot(x-cx,y-cy)-radius)
 return None
def _validate_edge_picks(picks):
 lines=[]
 for pick in picks:
  line=_straight_line(pick.get('source'))
  if line is None:raise ValueError('プレビューに表示された2本の線分を選択してください')
  lines.append(line)
 if lines[0]==lines[1] or lines[0]==(*lines[1][2:],*lines[1][:2]):raise ValueError('異なる2本の線を選択してください')
 a,b,c,d=lines[0];e,f,g,h=lines[1];ux,uy,vx,vy=c-a,d-b,g-e,h-f;det=ux*vy-uy*vx
 if abs(det)<=1e-12*math.hypot(ux,uy)*math.hypot(vx,vy):raise ValueError('平行でない2本の線を選択してください')
 t=((e-a)*vy-(f-b)*vx)/det;origin=a+t*ux,b+t*uy
 for pick,line in zip(picks,lines):
  px,py=_point(pick);ux,uy=line[2]-line[0],line[3]-line[1]
  if abs((px-origin[0])*ux+(py-origin[1])*uy)/math.hypot(ux,uy)<=1e-9:raise ValueError('交点以外の線上で残したい側を選択してください')
def build(command,picks):
 k=_kind(command);count=_COUNTS[k]
 if len(picks)<count:raise ValueError(hint(command,picks))
 picks=picks[:count];points=[_point(p) for p in picks];d=copy.deepcopy(command)
 if k in ('EXPLODE','PEDIT'):return d
 if k in ('COPY','MIRROR'):
  if math.dist(*points)<=1e-12:raise ValueError('2点は異なる位置にしてください')
  _set_point(d,'2',picks[0]);_set_point(d,'3',picks[1])
 elif k in ('OFFSET','TRIM','EXTEND'):
  _set_point(d,'2',picks[0])
  if k=='OFFSET':
   distance=_offset_distance(picks[0])
   if distance is not None:
    if distance<=1e-9:raise ValueError('方向点を対象図形から離してください')
    d['distance']=_number(distance)
 elif k in ('ROTATE','ROTATECOPY'):
  base,handle=points
  if math.dist(base,handle)<=1e-12:raise ValueError('角度を指定する点を基点から離してください')
  _set_point(d,'2',picks[0]);d['angle']=_number(math.degrees(math.atan2(handle[1]-base[1],handle[0]-base[0])))
 elif k=='SCALE':
  base,before,after=points;old,new=math.dist(base,before),math.dist(base,after)
  if old<=1e-12 or new<=1e-12:raise ValueError('変更前・変更後の点を基点から離してください')
  _set_point(d,'2',picks[0]);d['factor']=_number(new/old) if all(_constant(_expression(p,a)) is not None for p in picks for a in ('x','y')) else f'({_length(picks[0],picks[2])}) / ({_length(picks[0],picks[1])})'
 elif k=='ARRAYRECT':
  if abs(points[1][0]-points[0][0])<=1e-12 or abs(points[2][1]-points[0][1])<=1e-12:raise ValueError('列/行の間隔を0以外で指定してください')
  d['column_spacing']=_difference(picks[0],picks[1],'x');d['row_spacing']=_difference(picks[0],picks[2],'y')
 elif k=='CADBLOCK':_set_point(d,'2',picks[0])
 elif k in ('CHAMFER','FILLET'):
  _validate_edge_picks(picks);_set_point(d,'1',picks[0]);_set_point(d,'2',picks[1])
 return d
