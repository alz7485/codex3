"""Compact grouped system variables with evaluated values and early errors."""
import tkinter as tk
from tkinter import ttk
from preview_input_feedback import rendered_value
COMMON=('OSMODE','OSNAPCOORD','SNAPMODE','ORTHOMODE','DYNMODE','CMDECHO','LTSCALE','PSLTSCALE','MSLTSCALE','LWDISPLAY','ATTREQ','MIRRTEXT','DIMASSOC','PICKADD','PICKFIRST')
TYPE_LABELS={'number':'数値・式','text':'文字列'}
HINTS={'OSMODE':'オブジェクトスナップの合計値（0＝オフ）','SNAPMODE':'スナップ：0＝オフ / 1＝オン','ORTHOMODE':'直交：0＝オフ / 1＝オン','LTSCALE':'図面全体の線種尺度（正の数値）','MIRRTEXT':'ミラー時の文字反転：0＝維持 / 1＝反転','DIMASSOC':'寸法の関連付け：0〜2'}
def evaluate_item(item,context,evaluator=None):
 if evaluator is None:
  from engine import evaluate
  evaluator=evaluate
 return rendered_value(item.get('value',''),item.get('value_kind','number'),context,evaluator)
def validate_items(items,context=None,evaluator=None):
 from engine import parse_expression
 from layout_commands import validate_batch
 validate_batch(items);values=[]
 for i,item in enumerate(items):
  raw=item.get('value','');kind=item.get('value_kind','number')
  try:
   if kind=='number':parse_expression(str(raw))
   elif isinstance(raw,str) and raw.startswith('='):parse_expression(raw[1:])
   else:rendered_value(raw,'text',{},lambda *_:None)
   if context is not None:values.append(evaluate_item(item,context,evaluator))
  except (ValueError,TypeError,KeyError,ArithmeticError) as exc:raise ValueError(f'{i+1}項目（{item.get("name","")}）：{exc}') from exc
 return values
class SystemVariablesEditor(ttk.Frame):
 def __init__(self,parent,items,changed,context_provider=None,evaluator=None):
  super().__init__(parent,padding=8);self.items,self.changed=items,changed;self.context_provider,self.evaluator=context_provider,evaluator;self.rows=[];self.row_widgets=[];self.feedback_labels=[];self.grid_columnconfigure(2,weight=1);self.redraw()
 def redraw(self):
  for child in self.winfo_children():child.destroy()
  self.rows=[];self.row_widgets=[];self.feedback_labels=[]
  for col,title in enumerate(('システム変数','値の種類','設定値・式','')):ttk.Label(self,text=title).grid(row=0,column=col,sticky='w',pady=(0,5))
  for i,item in enumerate(self.items):
   variables={k:tk.StringVar(value=str(item.get(k,v))) for k,v in [('name','OSMODE'),('value_kind','number'),('value','0')]}
   display=tk.StringVar(value=TYPE_LABELS.get(variables['value_kind'].get(),variables['value_kind'].get()))
   name=ttk.Combobox(self,textvariable=variables['name'],values=COMMON,width=15);kind=ttk.Combobox(self,textvariable=display,values=tuple(TYPE_LABELS.values()),state='readonly',width=8);value=ttk.Entry(self,textvariable=variables['value'],width=22);row=1+i*2
   for col,w in enumerate((name,kind,value)):w.grid(row=row,column=col,sticky='ew',padx=(0,5),pady=3)
   feedback=ttk.Label(self,text='',style='Muted.TLabel',wraplength=450);feedback.grid(row=row+1,column=0,columnspan=4,sticky='w',pady=(0,5))
   def update(*_,item=item,variables=variables,display=display):
    item.update({k:v.get() for k,v in variables.items()});display.set(TYPE_LABELS.get(variables['value_kind'].get(),variables['value_kind'].get()));self.refresh_feedback();self.changed()
   kind.bind('<<ComboboxSelected>>',lambda e,v=variables,d=display:v['value_kind'].set(next(k for k,label in TYPE_LABELS.items() if label==d.get())))
   for v in variables.values():v.trace_add('write',update)
   ttk.Button(self,text='削除',command=lambda i=i:self.remove(i),width=5).grid(row=row,column=3)
   self.rows.append(variables);self.row_widgets.append(dict(name=name,value_kind=kind,value=value));self.feedback_labels.append(feedback)
  ttk.Button(self,text='＋ 項目を追加',command=self.add).grid(row=len(self.items)*2+1,column=0,columnspan=4,sticky='w',pady=(8,0));self.refresh_feedback()
 def refresh_feedback(self):
  context,error=None,None
  if self.context_provider is not None:
   try:context=self.context_provider()
   except (ValueError,TypeError,KeyError,ArithmeticError) as exc:error=str(exc)
  names={}
  for item in self.items:
   name=str(item.get('name','')).upper();names[name]=names.get(name,0)+1
  for item,label in zip(self.items,self.feedback_labels):
   name=str(item.get('name','')).upper();hint=HINTS.get(name,'数値は式・@列名、文字列はそのままの値または =式');bad=False
   try:
    validate_items([item])
    if names.get(name,0)>1:raise ValueError('変数名が重複しています')
    text=hint+' / 試算できません：'+error if error else '確認値：'+evaluate_item(item,context,self.evaluator)+' / '+hint if context is not None else hint
   except (ValueError,TypeError,KeyError,ArithmeticError) as exc:text='入力を確認：'+str(exc);bad=True
   label.configure(text=text,foreground='#a33a2b' if bad else '#596777')
 def validate(self,context=None):return validate_items(self.items,context,self.evaluator)
 def add(self):
  if len(self.items)>=100:return
  self.items.append(dict(name='',value_kind='number',value='0'));self.redraw();self.changed()
 def remove(self,index):self.items.pop(index);self.redraw();self.changed()
