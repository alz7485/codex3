"""Localized display choices with stable serialized values."""
import tkinter as tk
from tkinter import ttk
class LocalizedChoice(ttk.Combobox):
 def __init__(self,parent,variable,labels,**kwargs):
  self.model=variable;self.labels=dict(labels);self.display=tk.StringVar(parent,value=self.labels.get(variable.get(),variable.get()));self.busy=False
  super().__init__(parent,textvariable=self.display,values=tuple(self.labels.values()),state='readonly',**kwargs)
  self.display.trace_add('write',self._display_changed);self.trace_id=self.model.trace_add('write',self._model_changed)
  self.bind('<Destroy>',self._destroyed,add='+')
 def _display_changed(self,*_):
  if self.busy:return
  value=self.display.get();self.busy=True
  try:self.model.set(next((k for k,v in self.labels.items() if v==value),value))
  finally:self.busy=False
 def _model_changed(self,*_):
  if self.busy:return
  self.busy=True
  try:self.display.set(self.labels.get(self.model.get(),self.model.get()))
  finally:self.busy=False
 def _destroyed(self,event):
  if event.widget is self:
   try:self.model.trace_remove('write',self.trace_id)
   except tk.TclError:pass
 def get(self):return self.model.get()
 def set(self,value):self.model.set(next((k for k,v in self.labels.items() if v==value),value))
