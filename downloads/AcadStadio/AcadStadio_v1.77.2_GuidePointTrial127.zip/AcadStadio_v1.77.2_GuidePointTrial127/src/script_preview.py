"""SCR line selection backed by the same compiler as exported drawings."""
import copy
import tkinter as tk
from tkinter import ttk
from engine import compile_project
from preview import DrawingCanvas


class ScriptPreviewModel:
    def __init__(self, project, rows):
        self.project = copy.deepcopy(project)
        self.rows = list(rows)
        self.steps = []
        self.script, self.final = compile_project(self.project, self.rows, script_trace=self.steps)
        self.cache = {}

    def state(self, line=None):
        if line is None:
            return self.final, '最終状態'
        completed = [s for s in self.steps if s['end_line'] >= s['start_line'] and s['start_line'] <= line]
        step = completed[-1] if completed else None
        ordinal = step['ordinal'] if step else -1
        selected = step is not None and line <= step['end_line']
        key = (ordinal, selected)
        if key not in self.cache:
            _, items = compile_project(self.project, self.rows, validate=False, script_until=ordinal)
            items = [item for item in items if not item.get('guide')]
            if not selected:
                def clear(item):
                    item.pop('scr_selected', None)
                    for child in item.get('children', [])+item.get('block_geometry', []): clear(child)
                for item in items: clear(item)
            # Bound memory for long scripts.
            if len(self.cache) >= 8: self.cache.pop(next(iter(self.cache)))
            self.cache[key] = items
        caption = f'SCR {line}行'
        if step:
            caption += f" / {step['type']}（{step['start_line']}〜{step['end_line']}行）の完了時"
            if step['type'] == 'CUSTOM': caption += '（対応する作図のみ表示）'
        else: caption += ' / 作図前'
        return self.cache[key], caption


class ScriptCanvas(DrawingCanvas):
    def highlight(self, *args, **kwargs):
        super().highlight()
        changed = False
        for node, item, color in self.geometry:
            if not (item.get('scr_selected') or item.get('_logical_parent', {}).get('scr_selected')): continue
            typ = self.type(node)
            shade = '#ffdb59'
            if typ == 'image':
                self._text_colors[node] = shade; changed = True
            elif typ == 'polygon':
                self.itemconfigure(node, outline=shade, width=3, **({'fill':shade} if self.itemcget(node, 'fill') else {}))
            else:
                options = {'outline' if typ in ('oval','rectangle') else 'fill':shade}
                if typ != 'text': options['width'] = 3
                self.itemconfigure(node, **options)
        if changed: self.redraw_text()


class ScriptPreviewPane:
    def __init__(self, app, host, text):
        self.app, self.host, self.text = app, host, text
        self.frame = ttk.Frame(host)
        self.visible = False
        self.model = None
        self.job = None
        toolbar = ttk.Frame(self.frame, padding=4); toolbar.pack(fill='x')
        ttk.Button(toolbar, text='選択解除・最終状態', command=self.clear).pack(side='left')
        ttk.Button(toolbar, text='全体表示', command=lambda:self.canvas.fit()).pack(side='right')
        self.caption = tk.StringVar(value='最終状態')
        ttk.Label(self.frame, textvariable=self.caption, wraplength=440, padding=4).pack(fill='x')
        self.canvas = ScriptCanvas(self.frame, space_tabs=True)
        self.canvas.pack(fill='both', expand=True)
        text.bind('<ButtonRelease-1>', self.clicked, add='+')
        for sequence in ('<<Selection>>', '<KeyRelease>'):
            text.bind(sequence, self.queue, add='+')
        text.bind('<Escape>', self.escape, add='+')

    def toggle(self):
        self.visible = not self.visible
        if self.visible:
            self.host.add(self.frame, weight=1)
            self.host.update_idletasks()
            self.host.sashpos(0, self.host.winfo_width() // 2)
            self.update()
        else: self.host.forget(self.frame)

    def invalidate(self):
        self.model = None
        self.queue()

    def clicked(self, event):
        if not self.visible: return
        if not self.text.tag_ranges('sel'):
            at = self.text.index(f'@{event.x},{event.y}')
            self.text.tag_add('sel', at+' linestart', at+' lineend+1c')
        self.queue()

    def escape(self, event):
        if self.visible and self.text.tag_ranges('sel'):
            self.clear(); return 'break'

    def clear(self):
        self.text.tag_remove('sel', '1.0', 'end'); self.queue()

    def queue(self, *_):
        if self.job: self.frame.after_cancel(self.job)
        self.job = self.frame.after(100, self.update)

    def update(self):
        self.job = None
        if not self.visible: return
        try:
            if self.model is None:
                self.model = ScriptPreviewModel(self.app.data, self.app.target_rows())
                if self.model.script != self.app._script_text:
                    self.model = None
                    self.caption.set('再生成してからプレビューしてください'); return
                self.canvas.set_color_resources(self.model.project)
            ranges = self.text.tag_ranges('sel')
            line = int(self.text.index(str(ranges[-1])+'-1c').split('.')[0]) if ranges else None
            items, caption = self.model.state(line)
            items = [item for item in items if not item.get('guide')]
            self.canvas.set_items(items)
            selected = next((i for i in items if i.get("scr_selected")), None)
            if selected is not None and self.canvas.space_tabs:
                self.canvas.space_tabs.select_space(selected.get("cad_space", "Model"))
            self.caption.set(caption)
        except (ValueError, KeyError) as exc:
            self.caption.set('プレビューできません: '+str(exc))
