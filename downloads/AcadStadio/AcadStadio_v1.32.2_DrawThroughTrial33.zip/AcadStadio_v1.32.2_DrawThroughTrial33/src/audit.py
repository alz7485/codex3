"""Structural and expression preflight, including inactive branches."""

from project_data import input_tables, parse_row_number
import ast
from engine import compile_project, parse_expression, MacroError, ALLOWED_FUNCS, SCOPES
from engine import RowResolver, convert, evaluate
from engine import polyline_expressions
from table_formulas import computed_columns, translate_columns, table_columns
from project_model import validate_project
from flow import walk, execution_address
from block_model import unified, legacy_view, modern_address


class Issue(str):
    def __new__(cls, message, **location):
        obj = super().__new__(cls, message)
        obj.location = location
        return obj


def audit_details(project):
    return [
        dict(
            message=str(issue),
            **getattr(issue, "location", {}) or structural_location(project, issue),
        )
        for issue in audit_project(project)
    ]


def structural_location(project, message):
    """Attach addresses to structural errors while keeping legacy text stable."""
    if not isinstance(project, dict):
        return {}
    if unified(project):
        converted = str(message)
        for block in sorted(project["blocks"], key=lambda b: -len(b.get("name", ""))):
            prefix = "ブロック " + block.get("name", "")
            if converted.startswith(prefix):
                converted = "プリセット " + converted[len("ブロック ") :]
                break
        location = structural_location(legacy_view(project), converted)
        if "preset_index" in location:
            location["block_index"] = location.pop("preset_index")
        if location.get("address"):
            location["address"] = modern_address(project, location["address"])
            location.setdefault("block_index", location["address"][1])
        return location
    for key in ("globals", "settings"):
        if message.startswith(key + ":") or message.startswith(key + "."):
            return {"resource": key}
    from cad_setup import SECTIONS

    if any(
        message.startswith(title + ":") or message.startswith(title + " / ")
        for title, _ in SECTIONS.values()
    ):
        return {"resource": "cad_setup"}
    candidates = []

    def commands(items, prefix, address, owner, depth=0):
        if not isinstance(items, list) or depth > 12:
            return
        for i, cmd in enumerate(items):
            path = f"{prefix} / {i + 1}"
            at = (*address, i)
            candidates.append((path + ":", dict(owner, address=at)))
            if isinstance(cmd, dict):
                for key, label in (("commands", "実行"), ("else", "ELSE")):
                    commands(
                        cmd.get(key, []),
                        path + " / " + label,
                        (*at, key),
                        owner,
                        depth + 1,
                    )

    for i, preset in enumerate(project.get("presets", [])):
        if isinstance(preset, dict):
            prefix = "プリセット " + str(preset.get("name", i + 1))
            candidates.append((prefix + ":", {"preset_index": i}))
            commands(
                preset.get("commands", []),
                prefix,
                ("presets", i, "commands"),
                {"preset_index": i},
            )
    if isinstance(project.get("blocks"), dict):
        for name, items in project["blocks"].items():
            commands(items, "ブロック " + name, ("blocks", name), {})
    for prefix, location in sorted(candidates, key=lambda entry: -len(entry[0])):
        if message.startswith(prefix):
            return location
    return {}


def audit_project(project):
    if not unified(project):
        return _audit_legacy(project)
    errors = validate_project(project)
    if errors:
        return errors
    view = legacy_view(project)
    result = []
    for issue in _audit_legacy(view):
        location = getattr(issue, "location", {}).copy() or structural_location(
            view, issue
        )
        if "preset_index" in location:
            location["block_index"] = location.pop("preset_index")
        if location.get("address"):
            location["address"] = modern_address(project, location["address"])
            location.setdefault("block_index", location["address"][1])
        message = str(issue).replace("プリセット ", "ブロック ")
        for block in project["blocks"]:
            message = message.replace(
                "ブロック " + block["id"], "ブロック " + block["name"]
            )
        result.append(Issue(message, **location))
    return result


def _audit_legacy(project):
    issues = [] if "_block_definitions" in project else validate_project(project)
    if issues:
        return issues
    expressions = []
    for table in input_tables(project):
        for column, expression in computed_columns(table).items():
            location = dict(table_id=table["id"], row=0, column=column)
            try:
                expression = translate_columns(expression, table_columns(table))
                expressions.append((f"{table['name']} / 1行目 / {column}", expression, location))
            except ValueError as exc:
                issues.append(Issue(f"{table['name']} / 1行目 / {column}: {exc}", **location))
    for key, value in project.get("globals", {}).items():
        expressions.append(("変数." + key, value, {"resource": "globals"}))
    for pi, preset in enumerate(project["presets"]):
        path = "プリセット " + preset["name"]
        if preset.get("condition"):
            expressions.append((path, preset["condition"], {"preset_index": pi}))
        expressions.extend(
            (path + " / local." + k, v, {"preset_index": pi})
            for k, v in preset.get("variables", {}).items()
        )
    groups = (
        []
        if "_block_definitions" in project
        else [
            (name, commands, ("blocks", name), {})
            for name, commands in project["blocks"].items()
        ]
    ) + [
        (
            p["name"],
            p.get("commands", []),
            ("presets", pi, "commands"),
            {"preset_index": pi},
        )
        for pi, p in enumerate(project["presets"])
    ]
    for name, definition in project.get("custom_commands", {}).items():
        for param in definition.get("parameters", []):
            default = param.get("default", "0" if param["kind"] == "number" else "")
            if param["kind"] == "number":
                expressions.append(
                    (
                        definition["name"] + " / 引数 " + param["name"],
                        default,
                        {"catalog": True},
                    )
                )
            elif isinstance(default, str) and default.startswith("="):
                expressions.append(
                    (
                        definition["name"] + " / 引数 " + param["name"],
                        default[1:],
                        {"catalog": True},
                    )
                )
    numeric = {
        "x",
        "y",
        "x1",
        "x2",
        "x3",
        "y1",
        "y2",
        "y3",
        "r",
        "height",
        "angle",
        "value",
        "count",
        "condition",
        "rx", "ry", "start_angle", "end_angle", "closed", "linetype_scale",
    }
    for name, commands, address, owner in groups:
        for i, (at, cmd) in enumerate(walk(commands, address)):
            location = dict(owner, address=at)
            if cmd.get("type", "").upper() == "POLYLINE":
                try:
                    for point in polyline_expressions(cmd.get("points", "")):
                        expressions.extend((f"{name} / {i + 1} / points", expression, location) for expression in point)
                except MacroError as exc:
                    issues.append(Issue(f"{name} / {i + 1} / points: {exc}", **location))
            if str(cmd.get("color", "")).strip():
                color = str(cmd["color"]).strip()
                expressions.append((f"{name} / {i + 1} / color", {"bylayer": "256", "byblock": "0"}.get(color.casefold(), color), location))
            if cmd.get("type", "").upper() == "CUSTOM":
                definition = project.get("custom_commands", {}).get(cmd.get("name"), {})
                kinds = {p["name"]: p["kind"] for p in definition.get("parameters", [])}
                for key, value in cmd.get("arguments", {}).items():
                    if kinds.get(key) == "number":
                        expressions.append((f"{name} / 引数 {key}", value, location))
                    elif isinstance(value, str) and value.startswith("="):
                        expressions.append(
                            (f"{name} / 引数 {key}", value[1:], location)
                        )
            for key, value in cmd.items():
                if (
                    key == "value"
                    and cmd.get("type", "").upper() == "SYSVAR"
                    and cmd.get("value_kind", "number") == "text"
                ):
                    if isinstance(value, str) and value.startswith("="):
                        expressions.append(
                            (f"{name} / {i + 1} / {key}", value[1:], location)
                        )
                    continue
                if key in numeric and str(value).strip():
                    expressions.append((f"{name} / {i + 1} / {key}", value, location))
                if (
                    key in ("text", "layer")
                    and isinstance(value, str)
                    and value.startswith("=")
                ):
                    expressions.append(
                        (f"{name} / {i + 1} / {key}", value[1:], location)
                    )
    allowed = (
        ast.Expression,
        ast.Constant,
        ast.Name,
        ast.Load,
        ast.Attribute,
        ast.BinOp,
        ast.UnaryOp,
        ast.BoolOp,
        ast.Compare,
        ast.Call,
        ast.Add,
        ast.Sub,
        ast.Mult,
        ast.Div,
        ast.Mod,
        ast.Pow,
        ast.USub,
        ast.UAdd,
        ast.Not,
        ast.And,
        ast.Or,
        ast.Eq,
        ast.NotEq,
        ast.Lt,
        ast.LtE,
        ast.Gt,
        ast.GtE,
    )
    for path, expr, location in expressions:
        try:
            if isinstance(expr, (int, float, bool)):
                continue
            root = parse_expression(str(expr))
            table_calls = {
                id(node.func) for node in ast.walk(root)
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                and node.func.id == "__table_cell__" and len(node.args) in (2, 3)
                and not node.keywords
                and all(isinstance(arg, ast.Constant) and isinstance(arg.value, str) for arg in node.args[:2])
            }
            for node in ast.walk(root):
                if not isinstance(node, allowed):
                    raise MacroError("許可されていない構文です")
                if isinstance(node, ast.Name) and node.id.startswith("__") and id(node) not in table_calls:
                    raise MacroError("内部名は参照できません")
                if isinstance(node, ast.Call) and (
                    not isinstance(node.func, ast.Name)
                    or (node.func.id not in ALLOWED_FUNCS and id(node.func) not in table_calls)
                    or node.keywords
                ):
                    raise MacroError("未対応の関数です")
                if isinstance(node, ast.Attribute) and (
                    not isinstance(node.value, ast.Name)
                    or node.value.id
                    not in SCOPES
                    or node.attr.startswith("__")
                ):
                    raise MacroError("未対応の参照です")
        except MacroError as exc:
            issues.append(Issue(f"{path}: {exc}", **location))
    if issues:
        return list(dict.fromkeys(issues))[:100]
    resolver = RowResolver(project, convert, evaluate, MacroError)
    for table in input_tables(project):
        target = project.get("drawing", {}).get("targets", {}).get(table["id"], {})
        if target.get("mode") == "range":
            try:
                parse_row_number(target.get("range", ""), len(table["rows"]))
            except ValueError as exc:
                issues.append(
                    Issue(
                        table["name"] + " / 作図設定: " + str(exc),
                        table_id=table["id"],
                        drawing=True,
                    )
                )
        for i in range(len(table["rows"])):
            try:
                for column in resolver.formulas[table["name"].casefold()]:
                    resolver.cell(table["name"], i, column)
                compile_project(project, [i], table_id=table["id"], validate=False)
            except (MacroError, KeyError, TypeError) as exc:
                location = getattr(exc, "location", {}).copy()
                if location.get("preset_index") is not None and location.get(
                    "command_path"
                ):
                    location["address"] = execution_address(
                        project, location["preset_index"], location["command_path"]
                    )
                issues.append(
                    Issue(
                        f"{table['name']} / {i + 1}行目: {exc}",
                        **dict(location, table_id=table["id"], row=i),
                    )
                )
            if len(issues) >= 100:
                return list(dict.fromkeys(issues))[:100]
    return list(dict.fromkeys(issues))
