"""Clickable point markers on a compiler-backed preview; never writes project data."""
import copy
import tkinter as tk
from tkinter import ttk
from command_points import geometry_points
from engine import compile_project, MacroError
from expression_sample import sample_value
from project_data import get_rows
from preview import DrawingCanvas


class PointCanvas(DrawingCanvas):
    def __init__(self, parent, on_pick, on_source=None):
        self.snap_points = {}; self.selected_point = None; self.shifted_point = None
        self.on_pick = on_pick
        self.on_source = on_source
        self.source_index = None
        self.source_labels = {}
        super().__init__(parent, width=340, height=260)
        self.bind('<ButtonPress-1>', self.press, add='+')
        self.bind('<ButtonRelease-1>', self.pick, add='+')

    def display_color(self, item, fallback):
        if "command_index" in item and item["command_index"] != self.source_index:
            return "#34465c"
        return super().display_color(item, fallback)

    def screen_point(self, point):
        w,h=self.winfo_width(),self.winfo_height()
        bx=self._base_offset[0]+point[0]*self._base_scale
        by=self._base_offset[1]-point[1]*self._base_scale
        return (w/2+(bx-w/2)*self.view_ratio+self.pan[0], h/2+(by-h/2)*self.view_ratio+self.pan[1])

    def draw_markers(self):
        self.delete('snap_overlay')
        if not hasattr(self,'_base_offset'):return
        for name,position in self.snap_points.items():
            x,y=self.screen_point(position);selected=name==self.selected_point
            color='#fbbf24' if selected else '#f8fafc'
            self.create_oval(x-6,y-6,x+6,y+6,fill=color,outline='#101d30',width=2,tags='snap_overlay')
            self.create_text(x+9,y-13,text=name,fill=color,anchor='w',tags='snap_overlay')
        if self.shifted_point is not None:
            x,y=self.screen_point(self.shifted_point)
            self.create_line(x-9,y,x+9,y,fill='#fb7185',width=2,tags='snap_overlay')
            self.create_line(x,y-9,x,y+9,fill='#fb7185',width=2,tags='snap_overlay')
            self.create_text(x+10,y+14,text='ずらし後',anchor='w',fill='#fb7185',tags='snap_overlay')

    def bounds(self, items=None):
        if items is None:
            items = self.items + ([dict(type="POINT", coords=self.shifted_point)] if self.shifted_point is not None else [])
        return super().bounds(items)

    def fit(self, **kwargs):
        super().fit(**kwargs);self.draw_markers()
    def zoom(self,event,factor=None):
        super().zoom(event,factor);self.draw_markers()
    def drag(self,event):
        super().drag(event);self.draw_markers()
    def press(self,event):self._snap_press=(event.x,event.y)
    def pick(self,event):
        press=getattr(self,'_snap_press',(event.x,event.y))
        if (press[0]-event.x)**2+(press[1]-event.y)**2>16:return
        hits=[]
        for name,point in self.snap_points.items():
            x,y=self.screen_point(point)
            if (x-event.x)**2+(y-event.y)**2<=144:hits.append(name)
        if len(hits)==1:self.on_pick(hits[0])
        elif hits:
            menu=tk.Menu(self,tearoff=False)
            for name in hits:menu.add_command(label=name,command=lambda n=name:self.on_pick(n))
            menu.tk_popup(event.x_root,event.y_root)
        else:
            under=set(self.find_overlapping(event.x-5,event.y-5,event.x+5,event.y+5))
            indices=sorted({item['command_index'] for node,item,_ in self.geometry if node in under and item.get('command_index') in self.source_labels})
            if len(indices)==1 and self.on_source:
                self.on_source(indices[0])
            elif indices:
                menu=tk.Menu(self,tearoff=False)
                for index in indices:
                    menu.add_command(label=self.source_labels[index],command=lambda i=index:self.on_source(i))
                menu.tk_popup(event.x_root,event.y_root)
            elif any(node in under for node, item, color in self.geometry) and hasattr(self, "on_unavailable"):
                self.on_unavailable()


class PointReferencePreview(ttk.Frame):
    def __init__(self,parent,project,commands,on_pick,initial_row=0,local_values=None, *, preview_commands=None, on_source=None):
        super().__init__(parent)
        self.project=project;self.commands=commands;self.local_values=local_values
        self.preview_commands=preview_commands;self.warning=""
        self.on_pick=on_pick;self.source_index=0;self.point_name='';self.axis='X';self.shifts={}
        self.status=tk.StringVar();self.row=tk.StringVar(value=str(initial_row+1))
        bar=ttk.Frame(self);bar.pack(fill='x',pady=(0,6))
        ttk.Label(bar,text='確認行').pack(side='left')
        rows=get_rows(project)
        choice=ttk.Combobox(bar,textvariable=self.row,values=[str(i+1) for i in range(len(rows))],state='readonly',width=5)
        choice.pack(side='left',padx=6);choice.bind('<<ComboboxSelected>>',lambda e:self.load(self.source_index))
        ttk.Button(bar,text='全体を表示',command=lambda:self.canvas.fit()).pack(side='right')
        self.canvas=PointCanvas(self,on_pick,on_source);self.canvas.pack(fill='both',expand=True)
        self.canvas.on_unavailable=lambda:self.status.set("この図形は参照元に選べません。編集中コマンドや未対応の図形は表示のみです。")
        ttk.Label(self,text='図形または一覧で参照元を選択 → 白い点をクリック。非選択の図形は暗く表示。',style='Muted.TLabel',wraplength=360).pack(fill='x',pady=6)
        ttk.Label(self,textvariable=self.status,wraplength=360).pack(fill='x')
        self.points={}

    def load(self,index):
        self.source_index=index;self.points={};self.canvas.snap_points={};self.canvas.shifted_point=None
        self.canvas.source_index=index
        self.canvas.source_labels={i:f"{i+1}: {command.get('type','')}" for i,command in enumerate(self.commands) if command.get('type') in ('LINE','ARC','CIRCLE','ELLIPSE','RECTANGLE','TEXT','POINT')}
        self.warning=""
        try:
            probe=copy.deepcopy(self.project)
            commands=copy.deepcopy(self.preview_commands() if self.preview_commands else self.commands)
            def compile_scene(sequence):
                if isinstance(probe.get('blocks'),list):
                    probe['blocks']=[dict(id='point_preview',name='点の確認',commands=sequence)]
                else:
                    probe['blocks']={};probe['presets']=[dict(name='点の確認',commands=sequence)]
                return compile_project(probe,[int(self.row.get())-1],validate=False)[1]
            try:
                items=compile_scene(commands)
            except MacroError as exc:
                path=str(exc.location.get('command_path',''))
                try:stop=int(path.split('/')[0])-1
                except ValueError:raise exc
                if stop <= 0:raise exc
                items=compile_scene(commands[:stop])
                self.warning=f"コマンド{stop+1}以降は未表示（入力を確認）"
            source=next((item for item in reversed(items) if item.get('command_index')==index),None)
            # Keep the complete scene even when the chosen source is absent in this row.
            self.canvas.set_items(items,preserve_camera=bool(self.canvas.items) and getattr(self,'_loaded_row',None)==self.row.get())
            self._loaded_row=self.row.get()
            if source is None:
                self.status.set('この行では参照元が作図されません。条件や確認行を確認してください。')
                return
            self.points=geometry_points(source)
            self.canvas.snap_points=self.points
            self.update_selection(self.point_name,self.axis,self.shifts)
        except (MacroError,ValueError,KeyError,TypeError) as exc:
            self.canvas.set_items([],message='この行のプレビューを表示できません')
            self.status.set(str(exc))

    def update_selection(self,name,axis,shifts):
        self.point_name=name;self.axis=axis;self.shifts=shifts
        self.canvas.selected_point=name;self.canvas.shifted_point=None
        if name in self.points:
            try:
                x,y=self.points[name];dx=dy=0
                for key,expression in shifts.items():
                    value=sample_value(self.project,expression or '0',int(self.row.get())-1,self.local_values)
                    if type(value) not in (int,float):raise ValueError('ずらし量は数値で指定してください')
                    if key=='X' or (key=='value' and axis=='X'):dx=value
                    else:dy=value
                self.canvas.shifted_point=(x+dx,y+dy)
                output=f'{x+dx:.12g}, {y+dy:.12g}' if axis is None else f'{(x+dx) if axis=="X" else (y+dy):.12g}'
                self.status.set(f'{name}：X={x:.12g} / Y={y:.12g}\n取得値：{output}'+('（'+axis+'のみ）' if axis else '')+('\n'+self.warning if self.warning else ''))
            except (MacroError,ValueError,KeyError,TypeError) as exc:self.status.set(str(exc))
        self.canvas._camera_items = self.canvas.items + ([dict(type="POINT", coords=self.canvas.shifted_point)] if self.canvas.shifted_point is not None else [])
        self.canvas.draw_markers()
