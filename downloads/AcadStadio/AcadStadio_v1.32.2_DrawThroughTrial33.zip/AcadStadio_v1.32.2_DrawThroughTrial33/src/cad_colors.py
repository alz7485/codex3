"""ACI model-space swatches; CAD backgrounds and plot styles may alter appearance."""

import colorsys
import tkinter as tk
from tkinter import ttk
from theme import fit_window

BASIC = {
    1: ("赤", "#ff0000"),
    2: ("黄", "#ffff00"),
    3: ("緑", "#00ff00"),
    4: ("シアン", "#00ffff"),
    5: ("青", "#0000ff"),
    6: ("マゼンタ", "#ff00ff"),
    7: ("白／黒", "#ffffff"),
    8: ("濃いグレー", "#808080"),
    9: ("薄いグレー", "#c0c0c0"),
}


def color_label(value):
    index = int(float(value))
    return (
        f"{BASIC[index][0]}（ACI {index}）"
        if index in BASIC
        else f"色見本 {index}（ACI {index}）"
    )


def color_code(value):
    for i in range(1, 256):
        if value == color_label(i):
            return str(i)
    return str(value).strip()


def entity_color_code(value):
    text = str(value).strip()
    if text.casefold() in ("bylayer", "bylayer（レイヤーに従う）"):
        return "256"
    if text.casefold() in ("byblock", "byblock（ブロックに従う）"):
        return "0"
    return color_code(text)


def entity_color_label(value):
    text = str(value).strip()
    try:
        index = float(entity_color_code(text))
        if index == 256:
            return "ByLayer（レイヤーに従う）"
        if index == 0:
            return "ByBlock（ブロックに従う）"
        if index.is_integer() and 1 <= index <= 255:
            return color_label(index)
    except ValueError:
        pass
    return text


def swatch(index):
    if index in BASIC:
        return BASIC[index][1]
    if index >= 250:
        level = (51, 80, 105, 130, 190, 255)[index - 250]
        return "#" + f"{level:02x}" * 3
    hue = (index - 10) // 10 / 24
    tone = (index - 10) % 10
    # The standard dark model-space ACI palette uses these integer levels.
    # Truncate channels (e.g. ACI 20 = FF3F00), rather than rounding them up.
    level = (255, 165, 127, 76, 38)[tone // 2]
    r, g, b = colorsys.hsv_to_rgb(hue, 1 if tone % 2 == 0 else 0.5, 1)
    return "#" + "".join(f"{int(c * level + 1e-9):02x}" for c in (r, g, b))


CELL_WIDTH = 46
CELL_HEIGHT = 24


def palette_cell(index):
    return (index - 1, 0) if index < 10 else (index % 10, index // 10)


class ColorPicker:
    def __init__(self, parent, variable, *, title="レイヤーの色を選択"):
        self.parent = parent
        self.variable = variable
        self.win = tk.Toplevel(parent)
        self.win.title(title)
        fit_window(self.win, 540, 820, 520, 560)
        self.win.transient(parent)
        self.win.grab_set()
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.bind("<Escape>", lambda e: self.close())
        self.title = tk.StringVar()
        ttk.Label(
            self.win, textvariable=self.title, style="Section.TLabel", padding=12
        ).pack(anchor="w")
        ttk.Label(
            self.win,
            text="色をクリック、または矢印キーで移動してEnterで選択。",
            padding=(12, 0),
            wraplength=490,
        ).pack(anchor="w")
        grid = ttk.Frame(self.win)
        grid.pack(fill="both", expand=True, padx=12, pady=8)
        grid.rowconfigure(0, weight=1)
        grid.columnconfigure(0, weight=1)
        self.canvas = tk.Canvas(
            grid,
            width=476,
            height=640,
            highlightthickness=0,
            bg="#f3f5f9",
            takefocus=True,
        )
        self.canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(grid, command=self.canvas.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.canvas.configure(
            yscrollcommand=scrollbar.set, scrollregion=(0, 0, 476, 640)
        )
        self.canvas.bind(
            "<MouseWheel>",
            lambda e: self.canvas.yview_scroll(-int(e.delta / 120), "units"),
        )
        self.canvas.bind("<Button-4>", lambda e: self.canvas.yview_scroll(-1, "units"))
        self.canvas.bind("<Button-5>", lambda e: self.canvas.yview_scroll(1, "units"))
        self.canvas.bind("<Configure>", lambda e: self.ensure_visible())
        ttk.Label(
            self.win,
            text="色見本は目安です。CADの背景・印刷設定により異なります。",
            wraplength=490,
            padding=(12, 0),
            style="Muted.TLabel",
        ).pack(anchor="w")
        try:
            self.index = max(1, min(255, int(float(color_code(variable.get())))))
        except ValueError:
            self.index = 7
        for i in range(1, 256):
            col, row = palette_cell(i)
            x = 8 + col * CELL_WIDTH
            y = 8 + row * CELL_HEIGHT
            color = swatch(i)
            self.canvas.create_rectangle(
                x, y, x + 42, y + 22, fill=color, outline="#707888"
            )
            brightness = sum(int(color[j : j + 2], 16) for j in (1, 3, 5))
            self.canvas.create_text(
                x + 21,
                y + 11,
                text=str(i),
                fill="black" if brightness > 350 else "white",
                font=("Arial", 8),
            )
        self.cursor = self.canvas.create_rectangle(
            0, 0, 0, 0, outline="#2463eb", width=3
        )
        self.canvas.bind("<Button-1>", self.click)
        for key, delta in (("Left", -1), ("Right", 1), ("Up", -10), ("Down", 10)):
            self.canvas.bind("<" + key + ">", lambda e, d=delta: self.move(d))
        self.canvas.bind("<Return>", lambda e: self.choose())
        self.move(0)
        self.canvas.focus_set()

    def move(self, delta):
        if delta in (-10, 10):
            col, row = palette_cell(self.index)
            row = max(0, min(25, row + (1 if delta > 0 else -1)))
            col = min(col, 8 if row == 0 else 5 if row == 25 else 9)
            self.index = col + 1 if row == 0 else row * 10 + col
        else:
            self.index = max(1, min(255, self.index + delta))
        col, row = palette_cell(self.index)
        x = 8 + col * CELL_WIDTH
        y = 8 + row * CELL_HEIGHT
        self.canvas.coords(self.cursor, x - 1, y - 1, x + 43, y + 23)
        self.title.set(color_label(self.index))
        self.ensure_visible()
        return "break"

    def ensure_visible(self):
        if self.canvas.winfo_height() <= 1:
            return
        _, row = palette_cell(self.index)
        y = 8 + row * CELL_HEIGHT
        top = self.canvas.canvasy(0)
        height = self.canvas.winfo_height()
        if y - 2 < top:
            self.canvas.yview_moveto(max(0, y - 4) / 640)
        elif y + 24 > top + height:
            self.canvas.yview_moveto((y + 28 - height) / 640)

    def click(self, event):
        px = self.canvas.canvasx(event.x) - 8
        py = self.canvas.canvasy(event.y) - 8
        col = int(px // CELL_WIDTH)
        row = int(py // CELL_HEIGHT)
        if px < 0 or py < 0 or not 0 <= col < 10 or not 0 <= row < 26:
            return
        if px % CELL_WIDTH > 42 or py % CELL_HEIGHT > 22:
            return
        if row == 0:
            if col > 8:
                return
            index = col + 1
        else:
            index = row * 10 + col
        if index <= 255:
            self.index = index
            self.choose()

    def choose(self):
        self.variable.set(color_label(self.index))
        self.close()

    def close(self):
        self.win.destroy()
        if self.parent.winfo_exists():
            self.parent.grab_set()
