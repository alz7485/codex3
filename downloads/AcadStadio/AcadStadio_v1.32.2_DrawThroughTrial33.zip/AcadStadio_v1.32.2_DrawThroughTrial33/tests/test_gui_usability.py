"""Real-widget workflows for the adopted usability changes."""

import copy
import json
import os
from pathlib import Path
import sys
import tkinter as tk
from tkinter import ttk
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from main import App
from flow import resolve
from inspection import InspectionWindow
from macro_editor import edit_command
from input_assist import show_table_reference_picker
from sample_project import EXAMPLE


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class UsabilityGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_icons_keep_action_names_and_keyboard_tooltips(self):
        edit = gui.button(self.app.drawing_page, "編集")
        self.assertTrue(edit.cget("image"))
        self.assertEqual(str(edit.cget("compound")), "none")
        self.assertIn("編集", edit.tooltip_text)
        edit.focus_force()
        self.root.update()
        edit.event_generate("<FocusIn>")
        self.assertIsNotNone(self.app.icons.job)
        self.app.icons.show(edit, edit.tooltip_text)
        self.assertIsNotNone(self.app.icons.tooltip)
        edit.event_generate("<Escape>")
        self.root.update()
        self.assertIsNone(self.app.icons.tooltip)

    def test_preview_begins_at_top_and_scr_opens_without_changing_preview_size(self):
        panel=self.app.preview_panel
        self.assertEqual(panel.winfo_y(),0)
        before=(panel.winfo_x(),panel.winfo_y(),panel.winfo_width())
        for _ in range(3):
            self.app.show_script();self.root.update();self.app.script_window.withdraw();self.root.update()
            self.assertEqual((panel.winfo_x(),panel.winfo_y(),panel.winfo_width()),before)


    def test_small_window_keeps_block_list_preview_and_grouped_settings_visible(self):
        for geometry in ("1040x680", "1320x840"):
            self.root.geometry(geometry); self.root.update()
            self.assertTrue(self.app.settings_group.winfo_ismapped())
            self.assertTrue(self.app.table_group.winfo_ismapped())
            self.assertGreater(self.app.block_list.winfo_height(), 100)
            self.assertGreater(self.app.canvas.winfo_height(), 150)
        win = self.app.edit_target_settings(); self.root.update()
        self.app.scope.set("range"); self.app.row_range.set("3")
        self.assertEqual(self.app.target_rows(), [2])
        self.assertFalse(any(isinstance(w, ttk.Button) and "サイズ" in str(w.cget("text")) for w in gui.descendants(win)))
        win.destroy()

    def test_switch_confirmation_includes_pending_cell(self):
        self.app.show_input_table()
        self.root.update()
        editor = self.app.table_editor
        editor.begin(cell=(0, editor.keys().index("OD")))
        editor.entry.delete(0, "end")
        editor.entry.insert(0, "141")
        with patch("tkinter.messagebox.askyesnocancel", return_value=None) as question:
            self.assertFalse(self.app.confirm_discard("切替"))
        question.assert_called_once()
        self.assertEqual(self.app.rows[0]["OD"], "141")

    def restart(self):
        self.root.destroy()
        self.root = tk.Tk()
        self.root.report_callback_exception = lambda typ, value, tb: self.errors.append(
            value
        )
        self.app = App(
            self.root, library_state_path=Path(self.library_dir.name) / "library.json"
        )
        self.root.update()

    def test_save_commits_pending_cell_without_redundant_confirmation(self):
        path = Path(self.library_dir.name) / "document.json"
        self.app.path = str(path)
        self.app.show_input_table()
        self.root.update()
        column = self.app.table_editor.keys().index("OD")
        self.app.table_editor.begin(cell=(0, column))
        entry = self.app.table_editor.entry
        entry.delete(0, "end")
        entry.insert(0, "125")
        with patch("tkinter.messagebox.askyesno") as question:
            self.assertTrue(self.app.save())
        question.assert_not_called()
        saved = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(saved["input_tables"][0]["rows"][0]["OD"], "125")

    def test_cell_tab_escape_and_project_undo(self):
        self.app.show_input_table()
        self.root.update()
        editor = self.app.table_editor
        column = editor.keys().index("X")
        before = self.app.rows[0]["X"]
        editor.begin(cell=(0, column))
        editor.entry.delete(0, "end")
        editor.entry.insert(0, "42")
        editor.advance(1)
        self.assertEqual(editor.cell, (0, column + 1))
        editor.entry.delete(0, "end")
        editor.entry.insert(0, "cancelled")
        editor.finish(False)
        self.assertEqual(self.app.rows[0]["X"], "42")
        self.app.undo_project()
        self.assertEqual(self.app.rows[0]["X"], before)
        self.assertNotIn("cancelled", self.app.rows[0].values())

    def test_tsv_paste_appends_rows_as_single_undo(self):
        editor = self.app.table_editor
        before = copy.deepcopy(self.app.rows)
        editor.cell = (len(before) - 1, 0)
        self.app.table.focus(str(len(before) - 1))
        keys = editor.keys()
        editor.paste(text="A\tB\r\nC\tD\r\n")
        self.assertEqual(len(self.app.rows), len(before) + 1)
        self.assertEqual(self.app.rows[-1][keys[0]], "C")
        self.assertEqual(self.app.rows[-1][keys[1]], "D")
        self.app.undo_project()
        self.assertEqual(self.app.rows, before)

    def test_paste_overflow_changes_nothing(self):
        editor = self.app.table_editor
        editor.cell = (0, len(editor.keys()) - 1)
        before = copy.deepcopy(self.app.data)
        editor.paste(text="one\ttwo")
        self.assertEqual(self.app.data, before)
        self.assertIn("列数", self.messages[-1][1])

    def test_multicell_clipboard_paste_while_editing(self):
        self.app.show_input_table()
        self.root.update()
        self.app.table_editor.begin(cell=(0, 0))
        self.root.clipboard_clear()
        self.root.clipboard_append("one\ttwo\nthree\tfour")
        self.app.table_editor.paste_in_editor()
        keys = self.app.table_editor.keys()
        self.assertEqual(self.app.rows[0][keys[1]], "two")
        self.assertEqual(self.app.rows[1][keys[1]], "four")

    def test_preview_highlight_preserves_script_and_zoom(self):
        self.app.set_checked_rows([0, 1, 2])
        self.app.table.selection_set("1")
        self.app.preview(quiet=True)
        script = self.app._script_text
        self.app.canvas.zoom(SimpleNamespace(x=160, y=100, delta=120), 1.7)
        view = self.app.canvas.get_view()
        self.app.block_list.selection_set("0")
        self.root.update()
        self.app.highlight_preview()
        self.app.preview(quiet=True)
        self.assertEqual(self.app.canvas.get_view(), view)
        self.assertEqual(self.app._script_text, script)
        self.assertEqual(len(self.app.canvas.items), 135)
        colors = [
            self.app.canvas.itemcget(
                node,
                "outline"
                if self.app.canvas.type(node) in ("oval", "rectangle")
                else "fill",
            )
            for node, _, _ in self.app.canvas.geometry
        ]
        self.assertIn("#3e5068", colors)
        self.assertTrue(any(color != "#3e5068" for color in colors))

    def test_highlight_toggle_shows_all_geometry_without_changing_targets(self):
        self.app.set_checked_rows([0, 1, 2])
        self.app.table.selection_set("1")
        self.app.block_list.selection_set("0")
        self.app.preview(quiet=True)
        before = copy.deepcopy(self.app.data)
        script = self.app._script_text
        toggle = next(
            w
            for w in gui.descendants(self.app.root)
            if isinstance(w, ttk.Checkbutton) and w.cget("text") == "選択を強調"
        )
        toggle.invoke()
        for node, _, color in self.app.canvas.geometry:
            option = (
                "outline"
                if self.app.canvas.type(node) in ("oval", "rectangle")
                else "fill"
            )
            self.assertEqual(self.app.canvas.itemcget(node, option), color)
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app._script_text, script)

    def test_selected_block_highlight_is_independent_of_other_blocks(self):
        from block_model import new_block
        first = new_block("円", commands=[{"type":"CIRCLE","x":"0","y":"0","r":"10"}])
        second = new_block("線", commands=[{"type":"LINE","x1":"0","y1":"0","x2":"20","y2":"20"}])
        self.app.data["blocks"] = [first, second]
        self.app.refresh(); self.app.block_list.selection_set("0"); self.app.preview(quiet=True)
        self.app.highlight_preview(("blocks",0,"commands",0))
        for node,item,color in self.app.canvas.geometry:
            option = "outline" if self.app.canvas.type(node)=="oval" else "fill"
            self.assertEqual(self.app.canvas.itemcget(node,option),color if item["type"]=="CIRCLE" else "#3e5068")


    def test_nested_command_edit_from_structure_tree_is_undoable(self):
        project = copy.deepcopy(EXAMPLE)
        command = {"type": "CIRCLE", "x": "0", "y": "0", "r": "10"}
        project["blocks"] = [
            {
                "id": "fold",
                "draw": True,
                "name": "fold",
                "commands": [
                    {"type": "IF", "condition": "True", "commands": [command]}
                ],
            }
        ]
        self.app.replace_document(project)
        self.app.block_list.selection_set("0")
        self.root.update()
        address = ("blocks", 0, "commands", 0, "commands", 0)
        self.app.open_navigator()
        self.assertTrue(self.app.navigator.select_address(address))
        changed = dict(command, r="20")
        with patch("project_navigator.edit_command", return_value=changed):
            self.app.navigator.edit()
        self.assertEqual(resolve(self.app.data, address)["r"], "20")
        self.app.undo_project()
        self.assertEqual(resolve(self.app.data, address)["r"], "10")

    def test_inspection_click_moves_to_nested_command_without_changing_targets(self):
        self.app.data["blocks"][0]["commands"] = [
            {
                "type": "IF",
                "condition": "False",
                "commands": [{"type": "CIRCLE", "x": "0", "y": "0", "r": "1+"}],
            }
        ]
        self.app.refresh()
        selected = self.app.selected_rows()
        win = InspectionWindow(self.app)
        self.assertTrue(win.records[0].get("address"))
        win.tree.selection_set("0")
        self.root.update()
        self.assertEqual(
            self.app.navigator.selected(),
            [("command", ("block", 0, (0, "commands")), 0)]
        )
        self.assertEqual(self.app.selected_rows(), selected)
        self.assertTrue(self.app.navigator.winfo_ismapped())

    def test_stale_inspection_requires_refresh(self):
        self.app.data["blocks"][0]["commands"][0]["x"] = "1+"
        self.app.refresh()
        win = InspectionWindow(self.app)
        self.app.rows[0]["X"] = "5"
        win.tree.selection_set("0")
        self.root.update()
        self.assertIn("再検査", win.detail.get())

    def test_summary_reports_table_rows_enabled_presets_and_setup(self):
        self.app.set_checked_rows([0, 2])
        self.app.data["cad_setup"]["enabled"] = True
        self.app.refresh()
        summary = self.app.drawing_summary.get()
        self.assertIn("2行（1,3）", summary)
        self.assertIn("CAD初期設定: ON", summary)
        self.assertIn("作図ブロック", summary)
        self.app.scope.set("range")
        self.app.row_range.set("99")
        self.assertIn("行番号を確認", self.app.drawing_summary.get())

    def test_pending_cell_is_in_recovery_but_original_file_is_untouched(self):
        path = Path(self.library_dir.name) / "original.json"
        path.write_text(json.dumps(self.app.data), encoding="utf-8")
        original = path.read_bytes()
        self.app.path = str(path)
        self.app.show_input_table()
        self.root.update()
        editor = self.app.table_editor
        editor.begin(cell=(0, editor.keys().index("OD")))
        editor.entry.delete(0, "end")
        editor.entry.insert(0, "137")
        self.app.autosave_workspace(False)
        self.assertEqual(path.read_bytes(), original)
        recovered = self.app.workspace_state.recoveries()[0]["data"]
        self.assertEqual(recovered["input_tables"][0]["rows"][0]["OD"], "137")

    def test_crash_restore_opens_unsaved_copy(self):
        self.app.rows[0]["OD"] = "137"
        self.app.refresh()
        self.app.autosave_workspace(False)
        self.restart()
        self.assertTrue(self.app.recovery_banner.winfo_ismapped())
        self.app.restore_recovery()
        self.assertEqual(self.app.rows[0]["OD"], "137")
        self.assertIsNone(self.app.path)
        self.assertTrue(self.app.has_unsaved_changes())
        self.assertFalse(self.app.recovery_banner.winfo_ismapped())
        self.assertEqual(len(self.app.workspace_state.recoveries()), 1)

    def test_pending_previous_recovery_does_not_prevent_new_autosave(self):
        self.app.rows[0]["OD"] = "137"
        self.app.refresh()
        self.app.autosave_workspace(False)
        self.restart()
        self.app.rows[0]["OD"] = "149"
        self.app.refresh()
        self.app.autosave_workspace(False)
        self.assertEqual(len(self.app.workspace_state.recoveries()), 2)
        with patch("tkinter.messagebox.askyesno", return_value=True):
            self.app.discard_recovery()
        self.assertEqual(len(self.app.workspace_state.recoveries()), 1)
        self.assertEqual(
            self.app.workspace_state.recoveries()[0]["data"]["input_tables"][0]["rows"][
                0
            ]["OD"],
            "149",
        )

    def test_input_window_zoom_and_block_survive_restart(self):
        self.app.block_list.selection_set("1")
        self.app.canvas.zoom(SimpleNamespace(x=200, y=120, delta=120), 1.8)
        view = self.app.canvas.get_view()
        self.app.show_script()
        self.app.script_window.withdraw()
        self.app.show_input_table()
        self.root.update()
        self.app.persist_workspace()
        self.restart()
        self.assertEqual(self.app.input_window.state(), "normal")
        self.assertFalse(hasattr(self.app,"result_tabs"))
        self.assertEqual(self.app.selected_block(), 1)
        self.assertAlmostEqual(self.app.canvas.get_view()["zoom"], view["zoom"])
        self.assertEqual(self.app.canvas.get_view()["pan"], view["pan"])

    def test_cad_resource_references_refresh_and_exclude_self(self):
        editor = self.app.edit_cad_setup()
        editor.data["text_styles"] = [{"name": "NOTE"}]
        editor.data["linetypes"] = [{"name": "CENTER"}]
        editor.data["dim_styles"] = [{"name": "BASE"}, {"name": "SELF"}]
        editor.forms["dim_styles"][1]["name"].set("SELF")
        editor.refresh_resources()
        self.assertIn(
            "NOTE", editor.resource_widgets[("dim_styles", "text_style")]["values"]
        )
        self.assertIn(
            "CENTER", editor.resource_widgets[("layers", "linetype")]["values"]
        )
        self.assertIn("BASE", editor.resource_widgets[("dim_styles", "base")]["values"])
        self.assertNotIn(
            "SELF", editor.resource_widgets[("dim_styles", "base")]["values"]
        )
        editor.win.destroy()

    def test_formula_result_updates_for_field_and_sample_row(self):
        results = []

        def interact():
            win = gui.top(self.root, "コマンドの設定")
            entry = win.command_entries["x"]
            entry.focus_force()
            entry.event_generate("<FocusIn>")
            entry.delete(0, "end")
            entry.insert(0, "@OD / 2")
            self.root.update()
            results.append(win.sample_result.get())
            win.sample_row.set("2")
            results.append(win.sample_result.get())
            win.destroy()

        self.root.after(25, interact)
        edit_command(
            self.root,
            {"type": "CIRCLE", "x": "0", "y": "0", "r": "10"},
            self.app.data["blocks"],
            self.app.data,
        )
        self.assertIn("1行目 → 50", results[0])
        expected = float(self.app.rows[1]["OD"]) / 2
        self.assertIn(f"2行目 → {expected:g}", results[1])

    def test_table_picker_cell_click_inserts_fixed_row_without_editing_table(self):
        project = {
            "input_tables": [
                {"id": "a", "name": "座標表", "rows": [{"X": "10", "Y": "20"}, {"X": "30", "Y": "40"}]},
                {"id": "b", "name": "寸法表", "rows": [{"OD": "100"}]},
            ],
            "active_table": "a", "globals": {"参照行": "2"},
        }
        before = copy.deepcopy(project)
        result = []

        def interact():
            picker = gui.top(self.root, "表から参照を選ぶ")
            try:
                table = next(w for w in gui.descendants(picker) if isinstance(w, ttk.Treeview))
                self.root.update()
                x, y, width, height = table.bbox("1", "Y")
                table.event_generate("<ButtonRelease-1>", x=x + width // 2, y=y + height // 2)
                gui.button(picker, "この参照を挿入").invoke()
            finally:
                if picker.winfo_exists():
                    picker.destroy()

        self.root.after(25, interact)
        show_table_reference_picker(self.root, project, result.append)
        self.assertEqual(result, ["[座標表]@Y{2}"])
        self.assertEqual(project, before)

    def test_table_picker_header_then_variable_row(self):
        project = {
            "input_tables": [{"id": "a", "name": "座標表", "rows": [{"X": "1"}]}],
            "active_table": "a", "globals": {"参照行": "1"},
        }
        results = []

        def interact():
            picker = gui.top(self.root, "表から参照を選ぶ")
            try:
                table = next(w for w in gui.descendants(picker) if isinstance(w, ttk.Treeview))
                self.root.update()
                heading = table.heading("X", "command")
                self.root.tk.eval(heading)
                mode = next(
                    w for w in gui.descendants(picker)
                    if isinstance(w, ttk.Combobox) and "変数で行を指定" in w.cget("values")
                )
                mode.set("変数で行を指定")
                gui.button(picker, "この参照を挿入").invoke()
            finally:
                if picker.winfo_exists():
                    picker.destroy()

        self.root.after(25, interact)
        show_table_reference_picker(self.root, project, results.append)
        self.assertEqual(results, ["[座標表]@X{変数.参照行}"])

    def test_command_field_table_picker_replaces_default_formula(self):
        recorded = []

        def interact():
            win = gui.top(self.root, "コマンドの設定")
            try:
                entry = win.command_entries["x"]
                menu_button = entry.reference_button
                menu = self.root.nametowidget(menu_button.cget("menu"))
                with patch(
                    "macro_editor.show_table_reference_picker",
                    side_effect=lambda parent, project, on_select, on_replace: on_replace("[座標表]@X{2}"),
                ):
                    menu.invoke(0)
                recorded.append(entry.get())
            finally:
                if win.winfo_exists():
                    win.destroy()

        self.root.after(25, interact)
        edit_command(
            self.root, {"type": "CIRCLE", "x": "@X", "y": "0", "r": "10"},
            self.app.data["blocks"], self.app.data,
        )
        self.assertEqual(recorded, ["[座標表]@X{2}"])


if __name__ == "__main__":
    unittest.main()
