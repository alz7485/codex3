import copy
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command, MacroEditor
from point_preview_ui import PointReferencePreview

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class PointSceneGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_scene_includes_current_and_click_synchronizes_source_and_dimming(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),dict(type='LINE',x1='0',y1='50',x2='100',y2='50')]
        current=dict(type='CIRCLE',x='200',y='100',r='10')
        before=copy.deepcopy(self.app.data)
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.choose_command_point('x');self.root.update()
                dialog=gui.top(self.root,'コマンドの点を選択');v=dialog.point_preview;c=v.canvas
                self.assertEqual({i['command_index'] for i in c.items},{0,1,2})
                self.assertEqual(c.source_index,0)
                colors={item['command_index']:color for node,item,color in c.geometry}
                self.assertNotEqual(colors[0],'#34465c');self.assertEqual(colors[1],'#34465c');self.assertEqual(colors[2],'#34465c')
                scale,pan=c.scale_value,list(c.pan)
                x,y=c.screen_point((25,50))
                c.event_generate('<ButtonPress-1>',x=int(x),y=int(y));c.event_generate('<ButtonRelease-1>',x=int(x),y=int(y));self.root.update()
                self.assertEqual(dialog.source_picker.current(),1);self.assertEqual(c.source_index,1)
                self.assertEqual(c.scale_value,scale);self.assertEqual(c.pan,pan)
                self.assertEqual({i['command_index'] for i in c.items},{0,1,2})
                colors={item['command_index']:color for node,item,color in c.geometry}
                self.assertEqual(colors[0],'#34465c');self.assertNotEqual(colors[1],'#34465c')
                self.assertEqual(v.points['中点'],(50,50))
                dialog.source_picker.current(0);dialog.source_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                self.assertEqual(c.source_index,0)
                gui.button(dialog,'キャンセル').invoke();gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,inspect)
        self.assertIsNone(edit_command(self.root,current,self.app.data['blocks'],self.app.data,point_sources=sources))
        self.assertEqual(self.app.data,before);self.assertTrue(all('point_id' not in s for s in sources))

    def test_invalid_current_keeps_valid_prior_geometry_and_warning(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]
        current=dict(type='CIRCLE',x='0',y='0',r='unfinished')
        frame=PointReferencePreview(self.root,self.app.data,sources,lambda name:None,preview_commands=lambda:sources+[current])
        frame.pack(fill='both',expand=True);frame.load(0);self.root.update();frame.update_selection('中点','X',{'value':'0'})
        self.assertEqual(len(frame.canvas.items),1);self.assertEqual(frame.points['中点'],(50,0))
        self.assertIn('コマンド2以降は未表示',frame.status.get());frame.destroy()

    def test_overlapping_geometry_offers_menu_instead_of_guessing(self):
        from unittest.mock import patch
        import tkinter as tk
        commands=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]
        selected=[];frame=PointReferencePreview(self.root,self.app.data,commands,lambda name:None,on_source=selected.append)
        frame.pack(fill='both',expand=True);frame.load(0);self.root.update();c=frame.canvas
        x,y=c.screen_point((25,0));c._snap_press=(x,y)
        with patch.object(tk.Menu,'tk_popup') as popup:
            c.pick(SimpleNamespace(x=x,y=y,x_root=x,y_root=y))
        self.assertTrue(popup.called);self.assertEqual(selected,[]);frame.destroy()

    def test_editor_list_excludes_commands_after_current_position(self):
        editor=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0])
        editor.list.commands[:]=[dict(type='LINE',x1='0',y1='0',x2='10',y2='0'),dict(type='LINE',x1='0',y1='10',x2='10',y2='10'),dict(type='CIRCLE',x='20',y='20',r='5'),dict(type='LINE',x1='1000',y1='0',x2='2000',y2='0')]
        editor.list.refresh(2)
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.choose_command_point('x');self.root.update()
                dialog=gui.top(self.root,'コマンドの点を選択')
                self.assertEqual({i['command_index'] for i in dialog.point_preview.canvas.items},{0,1,2})
                gui.button(dialog,'キャンセル').invoke();gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,inspect);editor.list.edit();editor.win.destroy()
