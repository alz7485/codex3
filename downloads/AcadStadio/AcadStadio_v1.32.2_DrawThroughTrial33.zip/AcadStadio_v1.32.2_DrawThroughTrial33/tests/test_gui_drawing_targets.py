"""Output row checks integrated into the editable input table."""
import copy
import json
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui
from main import EMPTY
from project_data import add_input_table, target_settings
from engine import MacroError

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform == 'win32', 'GUI display unavailable')
class DrawingTargetsGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_real_check_click_updates_scr_without_changing_selected_preview_row(self):
        self.app.show_input_table(); self.root.update()
        self.app.table.selection_set('0'); self.root.update()
        selected = self.app.table.selection()
        box = self.app.table.bbox('2', '#0')
        self.app.table.event_generate('<ButtonPress-1>', x=box[0]+20, y=box[1]+10)
        self.app.table.event_generate('<ButtonRelease-1>', x=box[0]+20, y=box[1]+10)
        self.root.update()
        self.assertEqual(self.app.target_rows(), [0, 2])
        self.assertEqual(self.app.table.selection(), selected)
        self.assertEqual({p['row'] for p in self.app.compile()[1]}, {0, 2})
        self.assertEqual(self.app.preview_rows(), [0])

    def test_check_column_cannot_edit_data_or_shift_cell_mapping(self):
        self.app.show_input_table(); self.root.update()
        before = copy.deepcopy(self.app.rows)
        box = self.app.table.bbox('1', '#0')
        from types import SimpleNamespace
        import tkinter as tk
        self.app.table_editor.begin(SimpleNamespace(type=tk.EventType.ButtonPress, x=box[0]+10, y=box[1]+10))
        self.assertIsNone(self.app.table_editor.entry)
        self.app.table_editor.begin(cell=(1, 0))
        entry = self.app.table_editor.entry
        entry.delete(0, 'end'); entry.insert(0, '変更した部品名')
        self.app.table_editor.finish()
        self.assertEqual(self.app.rows[1]['TYPE'], '変更した部品名')
        self.assertEqual(self.app.rows[1]['X'], before[1]['X'])

    def test_checks_save_reload_and_undo(self):
        before = copy.deepcopy(self.app.data)
        self.app.set_input_checks([0, 2]); self.root.update()
        self.app.undo_project(); self.assertEqual(self.app.data, before)
        self.app.redo_project(); self.assertEqual(self.app.target_rows(), [0, 2])
        path = Path(self.library_dir.name)/'checks.json'
        with patch('tkinter.filedialog.asksaveasfilename', return_value=str(path)):
            self.assertTrue(self.app.save())
        self.app.replace_document(EMPTY)
        self.app.open_project(path)
        self.assertEqual(self.app.target_rows(), [0, 2])
        data=json.loads(path.read_text())
        self.assertEqual(target_settings(data)['selected'], [0, 2])

    def test_all_none_space_and_empty_export(self):
        self.app.show_input_table(); self.root.update()
        gui.button(self.app.input_window, 'すべてチェック').invoke()
        self.assertEqual(self.app.target_rows(), [0, 1, 2])
        gui.button(self.app.input_window, 'すべて外す').invoke()
        self.assertEqual(self.app.target_rows(), [])
        with self.assertRaises(MacroError):self.app.compile()
        self.app.preview(quiet=True); self.assertEqual(self.app._script_text, '')
        self.app.table.selection_set(['1', '2'])
        self.app.toggle_selected_drawing_rows(); self.assertEqual(self.app.target_rows(), [1, 2])
        self.app.toggle_selected_drawing_rows(); self.assertEqual(self.app.target_rows(), [])
        self.app.toggle_all_drawing_rows(); self.assertEqual(self.app.target_rows(), [0, 1, 2])

    def test_per_table_checks_and_longer_second_table(self):
        first=self.app.data['active_table']; self.app.set_input_checks([1])
        second=add_input_table(self.app.data, '長い別表', copy.deepcopy(self.app.rows)*2)
        self.app.refresh(); self.app.set_input_checks([4, 5])
        self.app.switch_table(first); self.assertEqual(self.app.target_rows(), [1])
        self.app.switch_table(second['id']); self.assertEqual(self.app.target_rows(), [4, 5])
        self.assertEqual(self.app.table.item('5', 'text'), '☑')

    def test_duplicate_and_delete_keep_checked_parts_checked(self):
        self.app.set_input_checks([1]); self.app.table.selection_set('0'); self.app.duplicate_rows()
        self.assertEqual(self.app.target_rows(), [2])
        self.app.table.selection_set('0'); self.app.del_row()
        self.assertEqual(self.app.target_rows(), [1])
        self.assertEqual(self.app.rows[1]['TYPE'], 'FL-120')

    def test_empty_table_and_reopen_reuses_editor(self):
        self.app.replace_document(EMPTY)
        win=self.app.show_input_table(); self.root.update()
        self.app.set_input_checks([]); self.app.toggle_all_drawing_rows()
        self.assertEqual(self.app.target_rows(), [])
        self.app.hide_input_table(); self.assertIs(self.app.edit_target_settings(), win)
        self.assertEqual(self.app._target_controls, [])

    def test_minimum_layout_and_toolbar_tone(self):
        win=self.app.show_input_table(); win.geometry('780x460'); self.root.update()
        for label in ['すべてチェック', 'すべて外す', '行を追加', '表を追加', '表を置換']:
            button=gui.button(win,label)
            self.assertTrue(button.winfo_ismapped())
            self.assertLess(button.winfo_rooty()+button.winfo_height(), self.app.table.winfo_rooty() if label not in ['表を追加','表を置換'] else self.app.table_list.winfo_rooty())
            self.assertLessEqual(button.winfo_rootx()+button.winfo_width(), win.winfo_rootx()+win.winfo_width())
            self.assertLessEqual(button.winfo_rooty()+button.winfo_height(), win.winfo_rooty()+win.winfo_height())
        self.assertEqual([b.cget('text') for b in self.app.settings_buttons], ['CAD設定','プリセット'])
