"""Native drawing commands, bounded vertices and real centerline entities."""
import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from sample_project import EXAMPLE
from engine import compile_project, MacroError, polyline_expressions
from cad_setup import initial_macro, validate_setup
from block_model import nested
from command_types import COMMAND_GROUPS
from test_cad_state import read_form, walk
from audit import audit_project

COMMANDS = [
    dict(type='ARC', x='@X', y='@Y', r='10', start_angle='350', end_angle='10'),
    dict(type='ELLIPSE', x='@X+40', y='@Y', rx='20', ry='10', angle='30'),
    dict(type='POLYLINE', points='@X,@Y; @X+10,@Y; @X+10,@Y+10', closed='1'),
    dict(type='POINT', x='@X', y='@Y+20'),
    dict(type='DIMALIGNED', x1='0', y1='0', x2='3', y2='4', x3='-2', y3='2'),
    dict(type='DIMRADIUS', x='0', y='0', r='10', x3='20', y3='20'),
    dict(type='DIMDIAMETER', x='30', y='0', r='10', x3='50', y3='20'),
]

class ExtendedDrawing(unittest.TestCase):
    def project(self, commands):
        p = copy.deepcopy(EXAMPLE)
        p['blocks'] = [dict(p['blocks'][0], commands=copy.deepcopy(commands))]
        return p

    def test_all_seven_new_commands_compile_after_json_roundtrip(self):
        p = json.loads(json.dumps(self.project(COMMANDS)))
        script, items = compile_project(p, [0])
        self.assertEqual(audit_project(p), [])
        self.assertEqual([i['type'] for i in items], [c['type'] for c in COMMANDS])
        for token in ('_.ARC\n_Center', '_.ELLIPSE\n_Center', '_.PLINE\n_non', '_.POINT\n_non', '_.DIMALIGNED\n_non'):
            self.assertIn(token, script)
        self.assertEqual(items[0]['sweep'], 20)
        self.assertEqual(items[1]['angle'], 30)
        self.assertTrue(items[2]['closed'])
        self.assertEqual(items[2]['coords'], (100,100,110,100,110,110))
        self.assertIn('_Close\n', script)
        self.assertIn('\"PLINETYPE\"', script)
        self.assertIn('\"PELLIPSE\"', script)
        self.assertEqual(len([k for _, kinds in COMMAND_GROUPS for k in kinds]), 16)

    def test_radius_and_diameter_cleanup_and_independent_native_dimensions(self):
        script, items = compile_project(self.project(COMMANDS[-2:]), [0])
        forms = [read_form(line) for line in script.splitlines() if line.startswith('((lambda (/ e result)')]
        self.assertEqual(len(forms), 2)
        for form, kind in zip(forms, ('DIMRADIUS','DIMDIAMETER')):
            nodes = list(walk(form))
            self.assertTrue(any(node and node[0]=='entdel' for node in nodes))
            self.assertTrue(any(node and node[0]=='vl-catch-all-apply' for node in nodes))
            self.assertTrue(any('_.'+kind in node for node in nodes))
        self.assertIn('_.SETVAR\nDIMASSOC\n1\n', script)
        self.assertIn('"DIMASSOC"', script)
        self.assertEqual([item['coords'][2] for item in items], [10,10])

    def test_polyline_nested_functions_and_other_table_references(self):
        text = 'min(@X, 110),@Y; @X+10,max(@Y, 90); [段付きフランジ寸法表]@X{2},@Y+20'
        _, items = compile_project(self.project([dict(type='POLYLINE', points=text)]), [0])
        self.assertEqual(items[0]['coords'], (100,100,110,100,420,120))
        self.assertFalse(items[0]['closed'])
        for bad in ('1,2', '1,2,3;4,5', '1,2;', '(1,2;3,4', '"a;b",2;3,4'):
            with self.subTest(bad=bad), self.assertRaises(MacroError):
                compile_project(self.project([dict(type='POLYLINE', points=bad)]), [0])
        with self.assertRaises(MacroError):polyline_expressions(';'.join('1,2' for _ in range(1001)))

    def test_invalid_shapes_are_rejected_before_export(self):
        bad = [dict(COMMANDS[0], r='0'), dict(COMMANDS[0], end_angle='710'),
               dict(COMMANDS[1], ry='21'), dict(COMMANDS[1], rx='-1'),
               dict(COMMANDS[2], points='0,0;0,0'), dict(COMMANDS[2], closed='2'),
               dict(COMMANDS[2], points='0,0;1,1'), dict(COMMANDS[3], x='1/0'),
               dict(COMMANDS[4], x2='0', y2='0'), dict(COMMANDS[5], r='-1'),
               dict(COMMANDS[6], x3='30', y3='0')]
        for command in bad:
            with self.subTest(command=command), self.assertRaises(MacroError):
                compile_project(self.project([command]), [0])

    def test_inactive_polyline_and_new_scalar_fields_are_audited(self):
        bad = [dict(COMMANDS[2], points="__import__('os'),0;1,1"),
               dict(COMMANDS[0], end_angle="evil(1)"),
               dict(COMMANDS[1], rx="evil(1)"),
               dict(COMMANDS[3], linetype_scale="evil(1)")]
        for command in bad:
            p = self.project([dict(type='IF', condition='False', commands=[command])])
            self.assertEqual(compile_project(p,[0])[1], [])
            self.assertTrue(audit_project(p))

    def test_centerlines_are_one_circle_three_lines_without_repeat(self):
        repeats = [c for block in EXAMPLE['blocks'] for c in nested(block['commands']) if c['type']=='REPEAT']
        self.assertEqual(len(repeats), 1)
        self.assertEqual(repeats[0]['count'], '@N')
        self.assertTrue(all(c['layer']=='HOLES' for c in repeats[0]['commands']))
        for row in range(3):
            script, items = compile_project(EXAMPLE,[row])
            center = [i for i in items if i['layer']=='CENTER']
            self.assertEqual(sorted(i['type'] for i in center), ['CIRCLE','LINE','LINE','LINE'])
            self.assertTrue(all(i['linetype']=='CENTER' and i['linetype_scale']==0.25 for i in center))
            circle = next(i for i in center if i['type']=='CIRCLE')
            self.assertEqual(circle['coords'][2], float(EXAMPLE['input_tables'][0]['rows'][row]['PCD'])/2)
            self.assertIn('_.SETVAR\nCELTYPE\nCENTER\n',script)
            self.assertNotIn('_.-LINETYPE',script)
        self.assertEqual([len(compile_project(EXAMPLE,[i])[1]) for i in range(3)], [43,45,47])

    def test_builtin_center_is_optional_and_has_no_external_file_dependency(self):
        setup = copy.deepcopy(EXAMPLE['cad_setup'])
        self.assertEqual(validate_setup(setup), [])
        lines = initial_macro(setup)
        form = read_form(next(line for line in lines if 'Center ____' in line))
        self.assertTrue(any(node and node[0]=='entmake' for node in walk(form)))
        self.assertTrue(any('CENTER' in node for node in walk(form)))
        self.assertNotIn('_.-LINETYPE','\n'.join(lines))
        setup['enabled'] = False; self.assertEqual(initial_macro(setup), [])
        setup['enabled'] = True; setup['linetypes'][0]['existing_only'] = True
        self.assertFalse(any('Center ____' in line for line in initial_macro(setup)))
        setup['linetypes'][0]['builtin'] = 'unknown'
        self.assertTrue(validate_setup(setup))
