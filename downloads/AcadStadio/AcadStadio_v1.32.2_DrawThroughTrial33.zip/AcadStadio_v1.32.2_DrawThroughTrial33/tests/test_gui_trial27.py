"""Color preferences, shared toolbar sizing and direct folder naming."""
import copy
import json
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import MacroEditor
from block_browser import FOLDER_PREFIX
from command_types import COMMAND_GROUPS

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class Trial27Gui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def editor(self):
        ed=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0])
        self.root.update()
        return ed

    def test_actual_colors_preserve_camera_data_scr_and_legend(self):
        canvas=self.app.canvas
        canvas.zoom(SimpleNamespace(x=150,y=160,delta=120),1.5)
        canvas.drag_point=(10,10);canvas.drag(SimpleNamespace(x=30,y=40))
        before=copy.deepcopy(self.app.data);script=self.app.compile()[0];view=canvas.get_view();scale=canvas.scale_value
        palette={item['layer']:color for _,item,color in canvas.geometry}
        self.app.actual_color_toggle.invoke();self.root.update()
        expected={'OUTLINE':'#ffffff','HOLES':'#00ffff','CENTER':'#ffff00','DIM':'#ff00ff'}
        self.assertEqual({item['layer']:color for _,item,color in canvas.geometry},expected)
        self.assertEqual({canvas.itemcget(n,'fill') for n in canvas.find_withtag('legend')},set(expected.values()))
        self.assertEqual(canvas.get_view(),view);self.assertAlmostEqual(canvas.scale_value,scale)
        self.assertEqual(self.app.data,before);self.assertEqual(self.app.compile()[0],script)
        self.app.actual_color_toggle.invoke();self.root.update()
        self.assertEqual({item['layer']:color for _,item,color in canvas.geometry},palette)
        self.assertTrue(self.app.persist_workspace())
        self.assertFalse(self.app.workspace_state.read('view',128*1024)['actual_colors'])

    def test_actual_color_mode_is_shared_with_editor_and_traces_are_removed(self):
        variable=self.app.canvas.actual_color_mode
        count=len(variable.trace_info())
        for _ in range(3):
            ed=self.editor()
            self.assertIs(ed.preview_canvas.actual_color_mode,variable)
            self.assertTrue(ed.actual_color_toggle.winfo_ismapped())
            ed.actual_color_toggle.invoke();self.root.update()
            self.assertEqual(variable.get(),bool(ed.actual_color_toggle.instate(['selected'])))
            ed.win.destroy();self.root.update()
            self.assertEqual(len(variable.trace_info()),count)
        self.app.actual_color_toggle.invoke();self.root.update()
        self.assertTrue(self.app.persist_workspace())
        self.assertEqual(self.app.workspace_state.read('view',128*1024)['actual_colors'],variable.get())

    def test_command_color_bylayer_byblock_inheritance_and_unknown_fallback(self):
        p=copy.deepcopy(self.app.data)
        line=dict(type='LINE',x1='0',y1='0',x2='10',y2='0')
        p['blocks']=[dict(p['blocks'][0],commands=[dict(line,layer='OUTLINE',color='1'),dict(line,layer='HOLES',color='256'),dict(line,layer='',color='256'),dict(line,layer='CENTER',color='0')])]
        self.app.replace_document(p);self.root.update();self.app.preview(quiet=True)
        self.app.actual_color_toggle.invoke();self.root.update()
        colors=[color for _,_,color in self.app.canvas.geometry]
        self.assertEqual(colors,['#ff0000','#00ffff','#00ffff','#ffffff'])
        self.assertEqual(self.app.canvas.display_color({'layer':'unknown'},'#123456'),'#123456')
        self.app.data['cad_setup']['layers'][1]['color']='3';self.app.refresh();self.root.update();self.app.preview(quiet=True)
        self.assertEqual([color for _,_,color in self.app.canvas.geometry][1:3],['#00ff00','#00ff00'])

    def test_command_icons_match_add_categories_and_button_sizes_match_main(self):
        ed=self.editor()
        self.assertEqual(ed.win.winfo_width(),max(850,min(1320,self.root.winfo_screenwidth()-60)))
        self.assertEqual(ed.win.winfo_height(),max(640,min(860,self.root.winfo_screenheight()-100)))
        controls=ed.list.toolbar.winfo_children()
        for row,command in enumerate(ed.list.commands):
            category=next(i for i,(_,kinds) in enumerate(COMMAND_GROUPS) if command['type'] in kinds)
            self.assertEqual(self.root.tk.splitlist(ed.list.tree.item(str(row),'image'))[0],self.root.tk.splitlist(controls[category].cget('image'))[0])
            self.assertTrue(ed.list.tree.item(str(row),'text').startswith(command['type']))
        main_controls={str(w.cget('text')):w for w in self.app.block_actions.winfo_children()}
        editor_controls={str(w.cget('text')):w for w in controls}
        for sash in (370,300):
            self.app.drawing_panes.sashpos(0,sash);self.root.update()
            ed.command_panes.sashpos(0,570 if sash==370 else 320);self.root.update()
            for label in ('編集','削除','↑','↓'):
                a,b=main_controls[label],editor_controls[label]
                self.assertEqual((a.winfo_width(),a.winfo_height()),(b.winfo_width(),b.winfo_height()))
            a,b=main_controls['表示 ▾'],controls[0]
            self.assertEqual((a.winfo_width(),a.winfo_height()),(b.winfo_width(),b.winfo_height()))
            self.assertTrue(all(w.winfo_x()+w.winfo_width()<=ed.list.toolbar.winfo_width() for w in controls))
        self.assertEqual(len(self.app.settings_buttons), 2)
        ed.win.destroy()

    def test_folder_add_is_immediate_numbered_at_root_and_undoable(self):
        before=copy.deepcopy(self.app.data);script=self.app.compile()[0]
        with patch('tkinter.simpledialog.askstring',side_effect=AssertionError('No name dialog')):
            gui.button(self.app.block_actions,'フォルダ追加').invoke();self.root.update()
            gui.button(self.app.block_actions,'フォルダ追加').invoke();self.root.update()
        folders=self.app.data['block_folders']
        self.assertEqual([f['name'] for f in folders],['新しいフォルダ(1)','新しいフォルダ(2)'])
        self.assertTrue(all(f['parent_id']=='' for f in folders))
        self.assertEqual(self.app.compile()[0],script)
        self.app.undo_project();self.root.update();self.assertEqual(len(self.app.data['block_folders']),1)
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,before)
        self.app.redo_project();self.root.update();self.assertEqual(len(self.app.data['block_folders']),1)

    def test_folder_double_click_inline_rename_cancel_validation_and_context_menu(self):
        browser=self.app.block_browser
        a=browser.new_folder('');b=browser.new_folder('');self.root.update()
        node=FOLDER_PREFIX+a['id'];browser.select_folder(a['id']);self.root.update()
        box=browser.tree.bbox(node,'name')
        event=SimpleNamespace(x=box[0]+8,y=box[1]+8)
        self.assertEqual(browser.double_visibility(event),'break');self.root.update()
        self.assertIsNotNone(browser.rename_entry)
        browser.rename_entry.delete(0,'end');browser.rename_entry.insert(0,'輪郭')
        self.assertTrue(browser.finish_folder_rename());self.root.update()
        self.assertEqual(next(f['name'] for f in self.app.data['block_folders'] if f['id']==a['id']),'輪郭')
        browser.rename_folder();browser.rename_entry.delete(0,'end');browser.rename_entry.insert(0,b['name'])
        self.assertFalse(browser.finish_folder_rename());self.assertIsNotNone(browser.rename_entry)
        browser.cancel_folder_rename();self.root.update()
        self.assertEqual(next(f['name'] for f in self.app.data['block_folders'] if f['id']==a['id']),'輪郭')
        browser.prepare_menu()
        labels=[browser.menu.entrycget(i,'label') for i in range(browser.menu.index('end')+1) if browser.menu.type(i)=='command']
        self.assertFalse(any('追加' in label for label in labels))
        self.app.undo_project();self.root.update()
        self.assertEqual(next(f['name'] for f in self.app.data['block_folders'] if f['id']==a['id']),a['name'])

    def test_block_grid_lines_follow_expansion_scroll_and_visible_columns(self):
        browser=self.app.block_browser
        folder=browser.new_folder('');browser.select_folder(folder['id'])
        browser.tree.selection_set('0');browser.move_selection(folder['id']);self.root.update()
        browser.expand_all();self.root.update()
        lines=[w for w in browser.tree._grid_lines if w.winfo_ismapped()]
        self.assertTrue(any(w.winfo_height()==1 and w.winfo_width()>100 for w in lines))
        self.assertTrue(any(w.winfo_width()==1 and w.winfo_height()>40 for w in lines))
        browser.collapse_all();self.root.update();browser.expand_all();self.root.update()
        self.assertTrue(any(w.winfo_ismapped() for w in browser.tree._grid_lines))
        self.assertTrue(browser.tree._grid_on_top)

    def test_real_double_click_enter_and_f2_escape_rename(self):
        browser=self.app.block_browser;record=browser.new_folder('');self.root.update()
        node=FOLDER_PREFIX+record['id'];box=browser.tree.bbox(node,'name')
        self.root.focus_force();self.root.update()
        for sequence,stamp in (('<ButtonPress-1>',10000),('<ButtonRelease-1>',10010),('<ButtonPress-1>',10100),('<ButtonRelease-1>',10110)):
            browser.tree.event_generate(sequence,x=box[0]+10,y=box[1]+10,time=stamp)
            self.root.update()
        self.assertIsNotNone(browser.rename_entry)
        entry=browser.rename_entry;entry.delete(0,'end');entry.insert(0,'名前変更済み');entry.focus_force();self.root.update()
        entry.event_generate('<Return>');self.root.update()
        self.assertIsNone(browser.rename_entry)
        self.assertEqual(self.app.data['block_folders'][0]['name'],'名前変更済み')

        browser.tree.focus_force();self.root.update();browser.tree.event_generate('<F2>');self.root.update()
        self.assertIsNotNone(browser.rename_entry)
        browser.rename_entry.delete(0,'end');browser.rename_entry.insert(0,'破棄する')
        browser.rename_entry.focus_force();self.root.update();browser.rename_entry.event_generate('<Escape>');self.root.update()
        self.assertEqual(self.app.data['block_folders'][0]['name'],'名前変更済み')

    def test_save_commits_pending_folder_name_and_blocks_invalid_name(self):
        browser=self.app.block_browser;browser.new_folder('');self.root.update()
        browser.rename_folder();browser.rename_entry.delete(0,'end');browser.rename_entry.insert(0,'保存用')
        path=Path(self.library_dir.name)/'folder-save.json'
        with patch('tkinter.filedialog.asksaveasfilename',return_value=str(path)):
            self.assertTrue(self.app.save())
        saved=json.loads(path.read_text(encoding='utf-8'))
        self.assertEqual(saved['block_folders'][0]['name'],'保存用')
        self.assertIsNone(browser.rename_entry)
        browser.new_folder('');browser.rename_folder();browser.rename_entry.delete(0,'end');browser.rename_entry.insert(0,'保存用')
        self.assertFalse(self.app.save())
        self.assertIsNotNone(browser.rename_entry)
        browser.cancel_folder_rename()
