"""Real GUI workflows for creating, selecting and sharing user commands."""

import copy
import json
import os
import sys
import tempfile
import tkinter as tk
from tkinter import ttk
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from main import App
from engine import compile_project
from block_model import new_block
from catalog_editor import CommandCatalogManager
from macro_editor import edit_command
from test_gui import button, descendants, top


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class CatalogGui(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.errors = []
        self.messages = []
        self.root.report_callback_exception = (
            lambda kind, value, tb: self.errors.append(value)
        )
        self.library_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.library_dir.cleanup)
        self.app = App(
            self.root, library_state_path=Path(self.library_dir.name) / "library.json"
        )
        self.root.update()
        self.app.preview(quiet=True)
        self.patches = [
            patch("tkinter.messagebox.askyesno", return_value=True),
            patch(
                "tkinter.messagebox.showerror",
                side_effect=lambda *a, **k: self.messages.append(a),
            ),
        ]
        for item in self.patches:
            item.start()

    def tearDown(self):
        if self.app._preview_job:
            try:
                self.root.after_cancel(self.app._preview_job)
            except tk.TclError:
                pass
        self.root.update_idletasks()
        self.root.destroy()
        for item in self.patches:
            item.stop()
        self.assertEqual(self.errors, [])

    def manager(self):
        manager = CommandCatalogManager(self.root, self.app.data, self.app.refresh)
        self.root.update()
        return manager

    def schedule_form(self, callback, title="コマンドの設定"):
        def run():
            win = top(self.root, title)
            try:
                callback(win)
            except Exception as exc:
                self.errors.append(exc)
                win.destroy()

        self.root.after(30, run)

    def choose_type(self, win, label):
        picker = next(w for w in descendants(win) if isinstance(w, ttk.Combobox))
        picker.set(label)
        picker.event_generate("<<ComboboxSelected>>")
        win.update()

    def field(self, win, label):
        return next(
            w
            for w in descendants(win)
            if isinstance(w, ttk.Entry)
            and any(
                isinstance(s, ttk.Label) and s.cget("text") == label
                for s in w.master.winfo_children()
            )
        )

    def test_examples_and_json_actions_are_visible(self):
        manager = self.manager()
        self.assertEqual(len(manager.tree.get_children()), 15)
        for label in [
            "新規登録",
            "編集",
            "複製",
            "JSON読込",
            "JSON書出",
            "プロジェクトに適用",
        ]:
            self.assertTrue(button(manager.win, label).winfo_ismapped())
        manager.cancel()

    def test_create_register_and_undo(self):
        manager = self.manager()

        def interact(win):
            name = self.field(win, "コマンド名")
            name.delete(0, "end")
            name.insert(0, "ユーザー追加")
            body = next(w for w in descendants(win) if isinstance(w, tk.Text))
            body.delete("1.0", "end")
            body.insert("1.0", "_.SETVAR\nLTSCALE\n{VALUE}")
            button(win, "この定義を確定").invoke()

        self.schedule_form(interact, "登録コマンドの編集")
        manager.add()
        self.assertEqual(len(manager.catalog), 16)
        self.assertEqual(len(self.app.data["custom_commands"]), 15)
        manager.save()
        self.assertEqual(len(self.app.data["custom_commands"]), 16)
        self.app.undo_project()
        self.assertEqual(len(self.app.data["custom_commands"]), 15)

    def test_additional_restore_variables_persist_and_emit(self):
        manager = self.manager()
        manager.tree.selection_set("set_osmode")

        def interact(win):
            field = self.field(win, "追加の復元変数")
            field.insert(0, "pickfirst, SELECTIONPREVIEW")
            button(win, "この定義を確定").invoke()

        self.schedule_form(interact, "登録コマンドの編集")
        manager.edit()
        manager.save()
        self.assertEqual(
            self.app.data["custom_commands"]["set_osmode"]["system_variables"],
            ["PICKFIRST", "SELECTIONPREVIEW"],
        )
        script, _ = compile_project(self.app.data, [0])
        self.assertIn('"PICKFIRST"', script)
        self.assertIn('"SELECTIONPREVIEW"', script)

    def test_used_definition_edit_updates_instances(self):
        self.app.data["blocks"][0]["commands"] = [
            {"type": "CUSTOM", "name": "set_osmode", "arguments": {"VALUE": "8"}}
        ]
        self.app.refresh()
        manager = self.manager()
        manager.tree.selection_set("set_osmode")

        def interact(win):
            body = next(w for w in descendants(win) if isinstance(w, tk.Text))
            body.delete("1.0", "end")
            body.insert("1.0", "_.SETVAR\nLTSCALE\n{VALUE}")
            button(win, "この定義を確定").invoke()

        self.schedule_form(interact, "登録コマンドの編集")
        manager.edit()
        manager.save()
        self.assertIn("_.SETVAR\nLTSCALE\n8\n", compile_project(self.app.data, [0])[0])

    def test_cancel_preserves_registry(self):
        original = copy.deepcopy(self.app.data)
        manager = self.manager()
        manager.catalog["set_osmode"]["name"] = "changed"
        manager.cancel()
        self.assertEqual(self.app.data, original)

    def test_nested_conditional_usage_prevents_deletion(self):
        helper = new_block(
            "条件付きブロック",
            commands=[
                {
                    "type": "IF",
                    "condition": "False",
                    "commands": [{"type": "CUSTOM", "name": "set_osmode"}],
                }
            ],
        )
        self.app.data["blocks"].append(helper)
        manager = self.manager()
        manager.tree.selection_set("set_osmode")
        manager.delete()
        self.assertIn("set_osmode", manager.catalog)
        self.assertIn(helper["name"], manager.usages("set_osmode"))
        self.assertTrue(self.messages)
        manager.cancel()

    def test_export_and_import_json(self):
        manager = self.manager()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "commands.json"
            with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
                manager.export_json()
            doc = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(doc["format"], "cadflow-command-library")
            self.assertEqual(len(doc["commands"]), 15)
            manager.catalog = {}
            with patch("tkinter.filedialog.askopenfilename", return_value=str(path)):
                manager.import_json()
        self.assertEqual(len(manager.catalog), 15)
        manager.cancel()

    def test_select_user_command_and_supply_formula(self):
        def interact(win):
            self.choose_type(win, "CUSTOM · ユーザー登録コマンド")
            combo = [w for w in descendants(win) if isinstance(w, ttk.Combobox)][1]
            combo.set("線種尺度を設定")
            combo.event_generate("<<ComboboxSelected>>")
            win.update()
            value = self.field(win, "線種尺度")
            value.delete(0, "end")
            value.insert(0, "@OD / 10")
            button(win, "コマンドを確定").invoke()

        self.schedule_form(interact)
        result = edit_command(
            self.root, {"type": "LINE"}, self.app.data["blocks"], self.app.data
        )
        self.assertEqual(result["name"], "set_ltscale")
        self.assertEqual(result["arguments"], {"VALUE": "@OD / 10"})
        p = copy.deepcopy(self.app.data)
        p["blocks"][0]["commands"] = [result]
        self.assertIn("LTSCALE\n10\n", compile_project(p, [0])[0])

    def test_sysvar_text_form(self):
        def interact(win):
            self.choose_type(win, "SYSVAR · システム変数変更")
            name = self.field(win, "名前")
            name.delete(0, "end")
            name.insert(0, "CECOLOR")
            kind = self.field(win, "値の種類")
            kind.set("text")
            value = self.field(win, "代入する式")
            value.delete(0, "end")
            value.insert(0, "BYLAYER")
            button(win, "コマンドを確定").invoke()

        self.schedule_form(interact)
        result = edit_command(
            self.root, {"type": "LINE"}, self.app.data["blocks"], self.app.data
        )
        self.assertEqual(result["value_kind"], "text")
        self.assertEqual(result["value"], "BYLAYER")

    def test_custom_only_preview_does_not_report_fake_geometry(self):
        self.app.set_checked_rows([0, 1, 2])
        self.app.data["blocks"] = [
            new_block("再描画", commands=[{"type": "CUSTOM", "name": "regenerate"}])
        ]
        self.app.refresh()
        self.app.preview(quiet=True)
        self.assertEqual(self.app.canvas.items, [])
        self.assertIn("対象外", self.app.canvas.empty_message)
        self.assertIn("登録3件", self.app.preview_status.get())
        self.assertEqual(self.app._script_text.count("_.REGEN"), 3)

    def test_style_creation_runs_once_for_multiple_rows(self):
        self.app.set_checked_rows([0, 1, 2])
        self.app.data["blocks"].insert(
            0,
            new_block(
                "寸法設定", commands=[{"type": "CUSTOM", "name": "dimstyle_create"}]
            ),
        )
        self.app.refresh()
        scr, items = self.app.compile()
        self.assertEqual(scr.count("_Save"), 1)
        self.assertEqual(len(items), 135)


if __name__ == "__main__":
    unittest.main(verbosity=2)
