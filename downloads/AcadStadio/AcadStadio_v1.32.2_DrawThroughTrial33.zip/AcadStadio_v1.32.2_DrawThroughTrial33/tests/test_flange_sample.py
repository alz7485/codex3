"""Plan circles and full section outlines must agree when dimensions change."""

import copy
import json
import math
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from sample_project import EXAMPLE
from engine import compile_project
from project_model import normalize_project
from table_io import read_csv, read_excel, sheet_names
from audit import audit_project
from block_model import nested

ROOT = Path(__file__).resolve().parents[1]


class FlangeSample(unittest.TestCase):
    def test_sample_opens_one_row_and_has_two_views_without_local_variables(self):
        self.assertEqual(
            EXAMPLE["drawing"]["targets"][EXAMPLE["active_table"]]["selected"], [0]
        )
        self.assertEqual(audit_project(EXAMPLE), [])
        self.assertEqual(
            [b["name"] for b in EXAMPLE["blocks"][:2]], ["平面図", "断面図 A-A"]
        )
        for block in EXAMPLE["blocks"]:
            self.assertNotIn("variables", block)
            for command in nested(block["commands"]):
                self.assertNotIn(command["type"], ("BLOCK", "SET"))
                self.assertNotIn("local.", json.dumps(command))

    def test_dimensions_and_all_hole_outlines_remain_complete(self):
        # The shoulder and plate must remain one continuous part when resized.
        cases = [copy.deepcopy(row) for row in EXAMPLE["input_tables"][0]["rows"]]
        cases.append(
            dict(
                cases[0],
                OD="160.5",
                ID="50.25",
                PCD="110",
                R="6.5",
                T="25.5",
                HUB_D="80.5",
                H="12.25",
            )
        )
        for row in cases:
            with self.subTest(row=row):
                project = copy.deepcopy(EXAMPLE)
                project["input_tables"][0]["rows"] = [row]
                script, items = compile_project(project, [0])
                x, y, od, bore, pcd, radius, thickness, hub, height = (
                    float(row[k])
                    for k in ("X", "Y", "OD", "ID", "PCD", "R", "T", "HUB_D", "H")
                )
                circles = [i for i in items if i["type"] == "CIRCLE"]
                self.assertEqual(len(circles), int(row["N"]) + 4)
                self.assertEqual(circles[0]["coords"], (x, y, od / 2))
                self.assertEqual(circles[1]["coords"], (x, y, bore / 2))
                self.assertIn((x, y, hub / 2), [i["coords"] for i in circles])
                holes = [i for i in circles if i["layer"] == "HOLES"]
                self.assertEqual(len(holes), int(row["N"]))
                for hole in holes:
                    hx, hy, hr = hole["coords"]
                    self.assertAlmostEqual(
                        math.hypot(hx - x, hy - y), pcd / 2, places=8
                    )
                    self.assertEqual(hr, radius)
                for sign in (-1, 1):
                    self.assertTrue(
                        any(
                            abs(i["coords"][0] - x) < 1e-8
                            and abs(i["coords"][1] - (y + sign * pcd / 2)) < 1e-8
                            for i in holes
                        )
                    )
                nose = x - od / 2 - float(project["settings"]["VIEW_GAP"])
                shoulder, rear = nose - height, nose - height - thickness
                section = [i for i in items if i["block_index"] == 1]
                outer = [i["coords"] for i in section if i["layer"] == "OUTLINE"]
                profile = [
                    (rear, y - od / 2),
                    (shoulder, y - od / 2),
                    (shoulder, y - hub / 2),
                    (nose, y - hub / 2),
                    (nose, y + hub / 2),
                    (shoulder, y + hub / 2),
                    (shoulder, y + od / 2),
                    (rear, y + od / 2),
                ]
                self.assertEqual(
                    outer,
                    [(*p1, *p2) for p1, p2 in zip(profile, profile[1:] + profile[:1])],
                )
                # The rear face and hub nose must continue across every opening.
                self.assertIn((rear, y + od / 2, rear, y - od / 2), outer)
                self.assertIn((nose, y - hub / 2, nose, y + hub / 2), outer)
                edges = [i["coords"] for i in section if i["layer"] == "HOLES"]
                self.assertEqual(len(edges), 6)
                for sign in (-1, 1):
                    level = y + sign * bore / 2
                    self.assertIn((rear, level, nose, level), edges)
                    for side in (-1, 1):
                        level = y + sign * pcd / 2 + side * radius
                        self.assertIn((rear, level, shoulder, level), edges)
                self.assertTrue(all(i["type"] == "LINE" for i in section))
                self.assertFalse(any(i["layer"] == "HATCH" for i in items))
                self.assertNotIn("HATCH_PITCH", project["settings"])
                self.assertFalse(
                    any(
                        layer["name"] == "HATCH"
                        for layer in project["cad_setup"]["layers"]
                    )
                )
                self.assertEqual(len(project["blocks"]), 3)
                dims = [i["coords"] for i in items if i["type"] == "DIMLINEAR"]
                self.assertEqual(len(dims), 5)
                for points, value in zip(dims[:3], (od, hub, bore)):
                    self.assertAlmostEqual(points[3] - points[1], value)
                for points, value in zip(dims[3:], (thickness, thickness + height)):
                    self.assertAlmostEqual(points[2] - points[0], value)
                self.assertLess(nose, x - od / 2)
                self.assertNotIn("_.-LINETYPE", script)
                self.assertIn("(c:CADFLOWRESTORE)", script)
                labels = [i["text"] for i in items if i["type"] == "TEXT"]
                self.assertTrue(
                    any("中心穴" in label and "通し" in label for label in labels)
                )
                self.assertFalse(
                    any("Rc" in label or "ねじ" in label for label in labels)
                )

    def test_shipped_json_csv_excel_and_script_match_default_sample(self):
        project = normalize_project(
            json.loads(
                (ROOT / "examples/flange_project.json").read_text(encoding="utf-8")
            )
        )
        self.assertEqual(project, EXAMPLE)
        rows = EXAMPLE["input_tables"][0]["rows"]
        self.assertEqual(read_csv(ROOT / "examples/flange_input.csv"), rows)
        excel = ROOT / "examples/flange_input.xlsx"
        self.assertEqual(read_excel(excel, sheet_names(excel)[0]), rows)
        expected, _ = compile_project(EXAMPLE, [0])
        self.assertEqual(
            (ROOT / "examples/flange_output.scr")
            .read_bytes()
            .decode("cp932")
            .replace("\r\n", "\n"),
            expected + "\n",
        )

    def test_organized_sample_changes_only_folder_organization(self):
        project = normalize_project(
            json.loads(
                (ROOT / "examples/folder_organization.json").read_text(encoding="utf-8")
            )
        )
        self.assertEqual(
            compile_project(project, [0, 1, 2]), compile_project(EXAMPLE, [0, 1, 2])
        )


if __name__ == "__main__":
    unittest.main()
