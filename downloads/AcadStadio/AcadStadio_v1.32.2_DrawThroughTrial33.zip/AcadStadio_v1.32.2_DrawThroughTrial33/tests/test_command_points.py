import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from sample_project import EXAMPLE
from engine import compile_project, MacroError, evaluate
from command_points import reference, new_id, clone_commands
from audit import audit_details

class CommandPoints(unittest.TestCase):
    def project(self,commands):
        p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=commands)];return p
    def line_dim(self):
        identity=new_id()
        line=dict(type='LINE',point_id=identity,x1='@X',y1='@Y',x2='@X+@OD',y2='@Y+10')
        dim=dict(type='DIMALIGNED',x1=reference(identity,'始点','X'),y1=reference(identity,'始点','Y'),x2=reference(identity,'終点','X'),y2=reference(identity,'終点','Y'),x3=reference(identity,'中点','X'),y3=reference(identity,'中点','Y')+'+20')
        return line,dim
    def test_dimension_follows_line_and_each_row_and_json(self):
        line,dim=self.line_dim();p=self.project([line,dim]);_,items=compile_project(json.loads(json.dumps(p)),[0,1])
        for index in (0,2):
            self.assertEqual(items[index+1]['coords'][:4],items[index]['coords'])
        line['x2']='@X+200';_,items=compile_project(p,[0]);self.assertEqual(items[1]['coords'][2],300)
        self.assertFalse(audit_details(p))
    def test_missing_forward_skipped_and_other_block_fail(self):
        line,dim=self.line_dim()
        for commands in [[dim],[dim,line],[dict(line,condition='False'),dim]]:
            with self.assertRaisesRegex(MacroError,'参照先の点がありません'):compile_project(self.project(commands),[0])
        p=self.project([line]);p['blocks'].append(dict(p['blocks'][0],id='second',name='second',commands=[dim]))
        with self.assertRaisesRegex(MacroError,'参照先の点がありません'):compile_project(p,[0])
    def test_arc_midpoint_and_center(self):
        identity=new_id();arc=dict(type='ARC',point_id=identity,x='0',y='0',r='10',start_angle='350',end_angle='10')
        p=dict(type='POINT',x=reference(identity,'中点','X'),y=reference(identity,'中点','Y'))
        _,items=compile_project(self.project([arc,p]),[0]);self.assertAlmostEqual(items[1]['coords'][0],10);self.assertAlmostEqual(items[1]['coords'][1],0)
    def test_reorder_duplicate_and_remap_with_table_formula(self):
        line,dim=self.line_dim();dim['x3']+=' + @OD'
        clone=clone_commands([line,dim]);self.assertNotEqual(clone[0]['point_id'],line['point_id'])
        p=self.project([line,dim]+clone);_,items=compile_project(p,[0]);self.assertEqual(items[1]['coords'],items[3]['coords'])
        standalone=clone_commands([line])[0];self.assertNotEqual(standalone['point_id'],line['point_id'])
        with self.assertRaises(MacroError):compile_project(self.project([line,line,dim]),[0])
    def test_no_stale_points_from_previous_row(self):
        line,dim=self.line_dim();line['condition']='@OD == 100'
        with self.assertRaisesRegex(MacroError,'2行目'):compile_project(self.project([line,dim]),[0,1])
    def test_reference_validation(self):
        for source in ['点(1,2,3)', '点("a", "始点", "Z")', '点("a", "始点", "X", "extra")']:
            with self.assertRaises(MacroError):evaluate(source,{})

    def test_custom_selection_coordinate_and_offsets(self):
        line, _=self.line_dim();identity=line['point_id']
        expr=f'点位置({identity!r}, "中点", -10, 5)'
        p=self.project([line,dict(type='CUSTOM',name='pick',arguments={'TARGET':'='+expr})])
        p['custom_commands']['pick']=dict(name='座標で選択',parameters=[dict(name='TARGET',label='選択点',kind='text',default='0,0')],lines=['_.SELECT','_non','{TARGET}',''])
        script,_=compile_project(p,[0]);self.assertIn('140,110',script)
        copy=clone_commands(p['blocks'][0]['commands'])
        self.assertIn(copy[0]['point_id'],copy[1]['arguments']['TARGET'])
        self.assertNotIn(identity,copy[1]['arguments']['TARGET'])

    def test_skipped_source_in_later_iteration_is_not_stale(self):
        line,dim=self.line_dim();line['condition']='loop.index == 0'
        p=self.project([dict(type='REPEAT',count='2',commands=[line,dim])])
        with self.assertRaisesRegex(MacroError,'参照先の点がありません'):compile_project(p,[0])
