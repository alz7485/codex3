import copy
import os
import sys
import unittest
from pathlib import Path
from tkinter import ttk
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command, MacroEditor
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CommandPointGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_picker_fills_separate_coordinates_and_cancel_keeps_source_unchanged(self):
        line=dict(type='LINE',x1='0',y1='0',x2='100',y2='0')
        dim=dict(type='DIMLINEAR',x1='0',y1='0',x2='10',y2='0',x3='50',y3='20')
        def choose():
            win=gui.top(self.root,'コマンドの設定')
            try:
                for key,point in [('x1','始点'),('y1','始点'),('x2','終点'),('y2','終点'),('x3','中点'),('y3','中点')]:
                    win.choose_command_point(key);self.root.update()
                    dialog=gui.top(self.root,'コマンドの点を選択')
                    combos=[w for w in gui.descendants(dialog) if isinstance(w,ttk.Combobox)]
                    combos[1].set(point);gui.button(dialog,'この点を使用').invoke()
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,choose)
        result=edit_command(self.root,dim,self.app.data['blocks'],self.app.data,point_sources=[line])
        self.assertTrue(line.get('point_id'))
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[line,result])]
        _,items=compile_project(p,[0]);self.assertEqual(items[1]['coords'][:4],(0,0,100,0))
        self.assertEqual(items[1]['coords'][4:],(50,0))
        before=copy.deepcopy(line)
        def cancel():
            win=gui.top(self.root,'コマンドの設定');win.choose_command_point('x1');self.root.update()
            gui.button(gui.top(self.root,'コマンドの点を選択'),'この点を使用').invoke()
            gui.button(win,'キャンセル').invoke()
        self.root.after(50,cancel)
        self.assertIsNone(edit_command(self.root,dim,self.app.data['blocks'],self.app.data,point_sources=[line]))
        self.assertEqual(line,before)

    def test_command_edit_undo_includes_new_source_identity(self):
        editor=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0])
        commands=editor.list.commands
        # Use two LINE commands so the second can refer to the first.
        commands[:]=[dict(type='LINE',x1='0',y1='0',x2='10',y2='0'),dict(type='LINE',x1='0',y1='1',x2='20',y2='1')]
        editor.list.refresh(1);before=copy.deepcopy(commands)
        def choose():
            win=gui.top(self.root,'コマンドの設定');win.choose_command_point('x1');self.root.update()
            gui.button(gui.top(self.root,'コマンドの点を選択'),'この点を使用').invoke()
            gui.button(win,'コマンドを反映').invoke()
        self.root.after(50,choose);editor.list.edit()
        self.assertIn('point_id',commands[0]);editor.list.undo();self.assertEqual(commands,before)
        editor.win.destroy()

    def test_x_offset_does_not_overwrite_y(self):
        line=dict(type='LINE',x1='0',y1='0',x2='100',y2='0')
        point=dict(type='POINT',x='1',y='25')
        def choose():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.choose_command_point('x');self.root.update()
                dialog=gui.top(self.root,'コマンドの点を選択')
                combos=[w for w in gui.descendants(dialog) if isinstance(w,ttk.Combobox)]
                combos[1].set('中点');combos[2].set('X')
                entry=next(w for w in gui.descendants(dialog) if isinstance(w,ttk.Entry) and not isinstance(w,ttk.Combobox))
                entry.delete(0,'end');entry.insert(0,'-10')
                gui.button(dialog,'この点を使用').invoke();gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,choose)
        result=edit_command(self.root,point,self.app.data['blocks'],self.app.data,point_sources=[line])
        self.assertEqual(result['y'],'25')
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[line,result])]
        self.assertEqual(compile_project(p,[0])[1][1]['coords'],(40,25))
