"""Semantic input metadata is optional and does not change SCR values."""
import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from command_catalog import validate_catalog, load_default_catalog
from engine import custom_lines


class ParameterControls(unittest.TestCase):
    def test_library_roundtrip_keeps_controls_and_emits_raw_values(self):
        catalog=json.loads(json.dumps(load_default_catalog()))
        self.assertEqual(validate_catalog(catalog),[])
        self.assertEqual(catalog['layer_color']['parameters'][0]['control'],'layer')
        self.assertEqual(catalog['layer_color']['parameters'][1]['control'],'color')
        self.assertEqual(custom_lines(catalog['layer_color'],{'LAYER':'OUTLINE','COLOR':'1'},{}),['_.-LAYER','_Color','1','OUTLINE',''])

    def test_invalid_input_control_and_numeric_layer_are_rejected(self):
        item=copy.deepcopy(load_default_catalog()['set_ltscale'])
        item['parameters'][0]['control']='unknown';self.assertTrue(validate_catalog({'example':item}))
        item['parameters'][0]['control']='layer';self.assertTrue(validate_catalog({'example':item}))
        item['parameters'][0]['control']='color';self.assertEqual(validate_catalog({'example':item}),[])
