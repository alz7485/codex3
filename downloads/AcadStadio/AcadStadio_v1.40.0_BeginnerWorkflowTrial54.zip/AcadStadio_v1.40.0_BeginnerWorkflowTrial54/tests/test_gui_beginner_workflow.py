"""First-use paths and semantic arguments through real Tk interactions."""
import copy
import os
import sys
import unittest
from pathlib import Path
from tkinter import ttk
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from main import EMPTY
from macro_editor import edit_command, MacroEditor
from project_model import normalize_sequential_project
from user_guidance import configure_columns
from cad_colors import color_label


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class BeginnerGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_empty_guidance_disappears_after_data_and_returns_on_undo(self):
        self.app.data=normalize_sequential_project(copy.deepcopy(EMPTY));self.app.refresh();self.root.update()
        self.assertTrue(self.app.start_guidance.panel.winfo_ismapped())
        self.assertTrue(self.app.start_guidance.empty_blocks.winfo_ismapped())
        self.assertIn('disabled',self.app.export_button.state())
        self.app.rows.append({'品名':'A','外径':'100'});self.app.refresh();self.root.update()
        self.assertFalse(self.app.start_guidance.panel.winfo_ismapped())
        self.assertTrue(self.app.start_guidance.empty_blocks.winfo_ismapped())
        self.app.undo_project();self.root.update()
        self.assertTrue(self.app.start_guidance.panel.winfo_ismapped())

    def test_configure_first_columns_creates_editable_row_and_one_undo_step(self):
        self.app.data=normalize_sequential_project(copy.deepcopy(EMPTY));self.app.refresh();before=copy.deepcopy(self.app.data)
        self.app.show_input_table();self.root.update()
        def fill():
            win=gui.top(self.root,'列を設定')
            next(w for w in gui.descendants(win) if isinstance(w,ttk.Entry)).insert(0,'品名,外径,厚さ')
            gui.button(win,'列を追加').invoke()
        self.root.after(50,fill);configure_columns(self.app);self.root.update()
        self.assertEqual(self.app.rows,[{'品名':'','外径':'','厚さ':''}])
        self.assertEqual(self.app.target_rows(),[0])
        self.app.undo_project();self.assertEqual(self.app.data,before)

    def test_export_target_titles_are_independent_of_confirmation_row_and_fit(self):
        self.app.set_input_checks([0,2]);self.app.preview_row_controls.value.set('2');self.app.preview_row_controls.apply()
        self.app.preview(quiet=True);before=copy.deepcopy(self.app.data);script=self.app.compile()[0]
        self.app.export();self.root.update();win=gui.top(self.root,'SCRを書き出す')
        self.assertEqual([win.output_targets.item(n,'values') for n in win.output_targets.get_children()],[('1','FL-100'),('3','FL-140')])
        texts=[str(w.cget('text')) for w in gui.descendants(win) if isinstance(w,ttk.Label)]
        self.assertTrue(any('FL-120' in t and '出力対象外' in t for t in texts))
        win.geometry('580x600');self.root.update()
        action=gui.button(win,'保存先を選んで書き出す')
        self.assertLessEqual(action.winfo_rooty()+action.winfo_height(),win.winfo_rooty()+win.winfo_height())
        gui.button(win,'戻る').invoke()
        self.assertEqual(self.app.data,before);self.assertEqual(self.app.compile()[0],script)

    def test_layer_color_control_preserves_raw_aci_and_allows_reference_formula(self):
        before=copy.deepcopy(self.app.data)
        def fill():
            win=gui.top(self.root,'コマンドの設定')
            color=win.command_entries['arg:COLOR'];layer=win.command_entries['arg:LAYER']
            self.assertIsInstance(layer,ttk.Combobox);self.assertIn('OUTLINE',layer.cget('values'))
            color.set(color_label(1));color.event_generate('<<ComboboxSelected>>')
            layer.set('OUTLINE');gui.button(win,'コマンドを反映').invoke()
        self.root.after(100,fill)
        result=edit_command(self.root,dict(type='CUSTOM',name='layer_color'),self.app.data['blocks'],self.app.data)
        self.assertEqual(result['arguments'],{'LAYER':'OUTLINE','COLOR':'1'})
        self.assertEqual(self.app.data,before)

    def test_custom_numeric_formula_has_live_result_and_remains_formula(self):
        def fill():
            win=gui.top(self.root,'コマンドの設定');win.refresh_command_preview();self.root.update()
            self.assertIn('10',win.field_results['arg:VALUE'].cget('text'))
            gui.button(win,'コマンドを反映').invoke()
        self.root.after(150,fill)
        result=edit_command(self.root,dict(type='CUSTOM',name='set_ltscale',arguments={'VALUE':'@OD / 10'}),self.app.data['blocks'],self.app.data)
        self.assertEqual(result['arguments']['VALUE'],'@OD / 10')

    def test_block_empty_add_opens_classified_palette_and_cancel_keeps_project(self):
        before=copy.deepcopy(self.app.data);block=copy.deepcopy(self.app.data['blocks'][0]);block['commands']=[]
        ed=MacroEditor(self.root,block,self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update()
        self.assertTrue(ed.list.empty_help.winfo_ismapped())
        def inspect():
            win=gui.top(self.root,'追加するコマンド')
            line=gui.button(win,'LINE');circle=gui.button(win,'CIRCLE')
            self.assertNotEqual(line.cget('image'),circle.cget('image'))
            gui.button(win,'キャンセル').invoke()
        self.root.after(60,inspect);gui.button(ed.list.toolbar,'＋ コマンド追加').invoke();ed.cancel()
        self.assertEqual(self.app.data,before)

    def test_failed_export_does_not_open_output_dialog(self):
        self.app.set_input_checks([])
        with patch('tkinter.messagebox.showerror') as error:self.app.export()
        error.assert_called_once()
        self.assertFalse(any(w.title()=='SCRを書き出す' for w in self.root.winfo_children() if hasattr(w,'title')))

    def test_registration_exposes_input_control_and_saves_it_in_definition(self):
        from catalog_editor import edit_definition
        from parameter_inputs import CONTROLS
        definition=dict(name='試験レイヤー',parameters=[dict(name='NAME',label='レイヤー',kind='text',default='PARTS')],lines=['_.-LAYER','_Make','{NAME}',''])
        def fill():
            win=gui.top(self.root,'登録コマンドの編集')
            try:
                tabs=next(w for w in gui.descendants(win) if isinstance(w,ttk.Notebook));tabs.select(1);self.root.update()
                tree=next(w for w in gui.descendants(win) if isinstance(w,ttk.Treeview) and 'kind' in w.cget('columns'))
                tree.selection_set('0');tree.event_generate('<<TreeviewSelect>>');self.root.update()
                widgets=[w for w in gui.descendants(win) if isinstance(w,ttk.Combobox)]
                kind=next(w for w in widgets if 'number' in w.cget('values'))
                kind.set('number')
                control=next(w for w in widgets if CONTROLS['layer'] in w.cget('values'))
                control.set(CONTROLS['layer']);control.event_generate('<<ComboboxSelected>>')
                self.assertEqual(kind.get(),'text')
                gui.button(win,'追加 / 更新').invoke();gui.button(win,'この定義を確定').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,fill);result=edit_definition(self.root,definition)
        self.assertEqual(result['parameters'][0]['control'],'layer')
        self.assertEqual(definition['parameters'][0].get('control'),None)

    def test_layer_color_excludes_entity_inheritance_and_rejects_zero(self):
        def fill():
            win=gui.top(self.root,'コマンドの設定')
            try:
                color=win.command_entries['arg:COLOR']
                self.assertFalse(any('ByLayer' in s for s in color.cget('values')))
                color.set('0')
                with patch('tkinter.messagebox.showerror') as error:gui.button(win,'コマンドを反映').invoke()
                error.assert_called_once()
                gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(100,fill)
        self.assertIsNone(edit_command(self.root,dict(type='CUSTOM',name='layer_color'),self.app.data['blocks'],self.app.data))
