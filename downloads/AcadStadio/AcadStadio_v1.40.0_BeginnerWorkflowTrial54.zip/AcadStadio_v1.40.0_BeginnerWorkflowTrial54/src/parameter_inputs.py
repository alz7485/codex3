"""Semantic argument controls; stored values retain their SCR representation."""
import tkinter as tk
from tkinter import ttk
from cad_colors import ColorPicker, entity_color_label, entity_color_code, swatch
from cad_setup import names

CONTROLS = {'default':'自動（数値／文字列）', 'layer':'レイヤー一覧', 'color':'色見本（ACI）', 'entity_color':'色（ByLayer対応）'}


def argument_entry(parent, parameter, value, project, owner):
    control=parameter.get('control','default')
    if control=='layer':
        entry=ttk.Combobox(parent,textvariable=value,values=names(project,'layers'))
        entry.pack(side='left',fill='x',expand=True)
        return entry
    if control not in ('color','entity_color'):
        entry=ttk.Entry(parent,textvariable=value);entry.pack(side='left',fill='x',expand=True)
        return entry
    display=tk.StringVar(value=entity_color_label(value.get()));busy=[False]
    choices=[entity_color_label(i) for i in ((256,0,*range(1,10)) if control=='entity_color' else range(1,10))]
    entry=ttk.Combobox(parent,textvariable=display,values=choices)
    entry.pack(side='left',fill='x',expand=True)
    chip=tk.Label(parent,width=2,relief='solid',borderwidth=1);chip.pack(side='left',padx=5)
    def update_chip():
        try:
            i=int(entity_color_code(value.get()));chip.configure(bg=swatch(7 if i in (0,256) else i))
        except (ValueError,IndexError,KeyError):chip.configure(bg='#edf2f9')
    def from_display(*_):
        if busy[0]:return
        busy[0]=True
        try:
            code=entity_color_code(display.get())
            if parameter['kind']=='text':code={'256':'BYLAYER','0':'BYBLOCK'}.get(code,code)
            value.set(code);update_chip()
        finally:busy[0]=False
    def from_value(*_):
        if busy[0]:return
        busy[0]=True
        try:display.set(entity_color_label(value.get()));update_chip()
        finally:busy[0]=False
    display.trace_add('write',from_display)
    trace=value.trace_add('write',from_value)
    def cleanup(event):
        if event.widget is entry:value.trace_remove('write',trace)
    entry.bind('<Destroy>',cleanup,add='+')
    ttk.Button(parent,text='色見本…',style='WorkbenchRef.TButton',command=lambda:ColorPicker(owner,display,title='引数の色を選択')).pack(side='left')
    update_chip();entry.argument_display=display
    return entry
