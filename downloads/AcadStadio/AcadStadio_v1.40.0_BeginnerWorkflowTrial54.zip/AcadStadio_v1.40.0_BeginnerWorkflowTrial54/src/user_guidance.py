"""Contextual first-use guidance and a preview of SCR output targets."""
import tkinter as tk
from tkinter import ttk, messagebox

from project_data import current_table, target_settings, row_title
from table_formulas import table_columns
from theme import fit_window


class StartGuidance:
    def __init__(self, app):
        self.app = app
        self.panel = tk.Frame(app.canvas, bg='#101d30', highlightbackground='#7186b4', highlightthickness=1, padx=18, pady=16)
        tk.Label(self.panel, text='まずは入力表から始めましょう', bg='#101d30', fg='#d0e1f7', font=(app.face, 13, 'bold'), wraplength=420).pack(pady=(0, 12))
        tk.Label(self.panel, text='① 入力表を作る　→　② ブロックに作図を追加　→　③ SCRを書き出す', bg='#101d30', fg='#9cb7d8', wraplength=420).pack(pady=(0, 10))
        tk.Label(self.panel, text='入力表を用意し、ブロックに線や円を追加して作図します。', bg='#101d30', fg='#9cb7d8', wraplength=420).pack(pady=(0, 10))
        actions = tk.Frame(self.panel, bg='#101d30'); actions.pack()
        ttk.Button(actions, text='入力表を作る', command=self.start_table, style='Compact.Primary.TButton').pack(side='left', padx=4)
        ttk.Button(actions, text='サンプルを開く', command=app.load_sample, style='Compact.TButton').pack(side='left', padx=4)
        self.empty_blocks = ttk.Frame(app.block_browser.tree, style='Surface.TFrame', padding=8)
        ttk.Label(self.empty_blocks, text='平面図・断面図など、\n作図のまとまりを追加します。', style='SurfaceMuted.TLabel', justify='center').pack(pady=(0, 8))
        ttk.Button(self.empty_blocks, text='＋ ブロックを追加', command=app.add_block, style='Compact.TButton').pack()
        app.canvas.bind('<Configure>', lambda e: self.resize(), add='+')

    def start_table(self):
        self.app.show_input_table()
        if not self.app.rows:
            configure_columns(self.app)

    def resize(self):
        width = max(180, min(560, self.app.canvas.winfo_width()-32))
        for w in self.panel.winfo_children():
            if isinstance(w, tk.Label):w.configure(wraplength=max(120, width-40))
        if self.panel.winfo_manager():self.panel.place_configure(width=width)

    def sync(self):
        blocks = self.app.data.get('blocks', [])
        if not blocks:
            self.empty_blocks.place(relx=.5, rely=.42, anchor='center', relwidth=.94)
        else:self.empty_blocks.place_forget()
        if not blocks and not any(t['rows'] for t in self.app.data['input_tables']):
            self.panel.place(relx=.5, rely=.48, anchor='center');self.resize()
        else:self.panel.place_forget()
        can_export = bool(self.app.rows and any(b.get('commands') and not b.get('guide') for b in blocks))
        self.app.export_button.configure(state='normal' if can_export else 'disabled')


def configure_columns(app):
    app.table_editor.finish()
    win = tk.Toplevel(app.input_window);win.title('列を設定');win.transient(app.input_window);win.grab_set()
    fit_window(win, 600, 360, 480, 320)
    body = ttk.Frame(win, padding=14);body.pack(fill='both', expand=True)
    columns = table_columns(current_table(app.data))
    ttk.Label(body, text='現在の列', style='Section.TLabel').pack(anchor='w')
    ttk.Label(body, text='・'.join(columns) if columns else '列はまだありません', wraplength=520).pack(fill='x', pady=8)
    ttk.Label(body, text='追加する列名（カンマ区切り）').pack(anchor='w', pady=(8, 4))
    names = tk.StringVar();entry = ttk.Entry(body, textvariable=names);entry.pack(fill='x')
    ttk.Label(body, text='例：品名,外径,穴径,厚さ,X,Y\n左端の列を行のタイトルとして表示します。', style='Muted.TLabel').pack(anchor='w', pady=8)
    def apply():
        from table_io import headers
        try:
            added = headers([s.strip() for s in names.get().replace('、', ',').split(',')])
            if any(c in columns for c in added):raise ValueError('同じ名前の列が既にあります。')
            if len(columns)+len(added)>200:raise ValueError('列は200個までです。')
        except ValueError as exc:
            messagebox.showerror('列の確認', str(exc), parent=win);return
        app.table_editor.finish()
        if not app.rows:
            app.rows.append(dict.fromkeys(added, ''))
            target_settings(app.data).update(mode='selected', selected=[0])
        else:
            for row in app.rows:
                for c in added:row[c]=''
        app._rendered_table_id=None;app.refresh();app.queue_preview();win.destroy()
    footer=ttk.Frame(win,padding=14);footer.pack(side='bottom',fill='x')
    ttk.Button(footer,text='キャンセル',command=win.destroy).pack(side='left')
    ttk.Button(footer,text='列を追加',command=apply,style='Compact.Primary.TButton').pack(side='right')
    win.bind('<Escape>',lambda e:win.destroy());entry.focus_set()
    app.root.wait_window(win)


def output_targets_card(win, app, indices):
    from table_grid import GridTreeview
    card=ttk.Frame(win,padding=12,style='SurfaceCard.TFrame');card.pack(fill='x',padx=14,pady=(12,8))
    ttk.Label(card,text='出力する行',style='SurfaceTitle.TLabel').pack(anchor='w')
    ttk.Label(card,text=f"{current_table(app.data)['name']} / {len(indices)}行",style='Surface.TLabel').pack(anchor='w',pady=(4,8))
    frame=ttk.Frame(card,style='Surface.TFrame');frame.pack(fill='x')
    tree=GridTreeview(frame,columns=('row','title'),show='headings',height=min(4,len(indices)),selectmode='none')
    tree.heading('row',text='行');tree.column('row',width=60,stretch=False)
    tree.heading('title',text='タイトル');tree.column('title',width=360)
    ys=ttk.Scrollbar(frame,command=tree.yview);tree.configure(yscrollcommand=ys.set)
    tree.pack(side='left',fill='both',expand=True)
    if len(indices)>4:ys.pack(side='right',fill='y')
    for i in indices:tree.insert('', 'end', values=(i+1,row_title(app.data,i)))
    current=app.preview_rows()
    descriptions=[f'{i+1}行目 {row_title(app.data,i)}' for i in current[:3]]
    info='プレビュー確認中：'+('・'.join(descriptions) if descriptions else 'なし')
    if len(current)>3:info+=' ほか'
    if current and any(i not in indices for i in current):
        info+='（今回の出力対象外）' if all(i not in indices for i in current) else '（出力対象外の行を含む）'
    ttk.Label(card,text=info,style='SurfaceMuted.TLabel',wraplength=550).pack(anchor='w',pady=(8,0))
    win.output_targets=tree
    return card
