"""Shared visual surfaces for auxiliary windows; no changes to their actions."""
from tkinter import ttk

BORDER = '#d0dff0'
BUTTON_BORDER = '#b8cbe1'


def apply_secondary_styles(style, face):
    style.configure('Surface.TFrame', background='white')
    style.configure('SurfaceCard.TFrame', background='white', borderwidth=1,
                    relief='solid', bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER)
    for name, foreground, font in (
        ('Surface.TLabel', '#192c42', (face, 10)),
        ('SurfaceMuted.TLabel', '#67788d', (face, 9)),
        ('SurfaceTitle.TLabel', '#192c42', (face, 11, 'bold')),
    ):
        style.configure(name, background='white', foreground=foreground, font=font)
    style.configure('Surface.TLabelframe', background='white', borderwidth=1,
                    relief='solid', bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER)
    style.configure('Surface.TLabelframe.Label', background='white', font=(face, 11, 'bold'))
    style.configure('Surface.TCheckbutton', background='white')
    style.configure('InlineHint.TLabel', background='#eaf3ff', foreground='#245882', padding=(8,6), font=(face,9))
    for name in ('MainIcon.TButton', 'MainIcon.TMenubutton', 'Eye.TMenubutton',
                 'Command.TMenubutton', 'DenseMainIcon.TButton',
                 'DenseMainIcon.TMenubutton', 'DenseCommand.TMenubutton'):
        dense = 'Dense' in name
        style.configure(name, background='white', borderwidth=1, relief='solid',
                        bordercolor=BUTTON_BORDER, lightcolor=BUTTON_BORDER,
                        darkcolor=BUTTON_BORDER, focusthickness=0,
                        padding=(0 if dense else 2, 2))
        style.map(name, background=[('active', '#eef5ff')],
                  bordercolor=[('disabled', '#d4dce7'), ('active', '#2463eb')])
    for name in ('Primary.TButton', 'Compact.Primary.TButton'):
        style.configure(name, borderwidth=1, relief='solid', bordercolor='#1d52cf',
                        lightcolor='#1d52cf', darkcolor='#1d52cf', focusthickness=0)
    style.configure('TNotebook', borderwidth=1, bordercolor=BORDER,
                    lightcolor=BORDER, darkcolor=BORDER)
    style.configure('TNotebook.Tab', bordercolor=BORDER, padding=(12, 6))
    style.map('TNotebook.Tab', background=[('selected', 'white'), ('!selected', '#edf2f9')],
              foreground=[('selected', '#2463eb')])
    style.configure('Treeview', borderwidth=1, relief='solid', bordercolor=BORDER,
                    lightcolor=BORDER, darkcolor=BORDER)


def surface(container, *, border=False):
    """Paint a chosen form as a white surface, preserving specialized widgets."""
    if isinstance(container, ttk.LabelFrame):
        container.configure(style='Surface.TLabelframe')
    elif isinstance(container, ttk.Frame):
        container.configure(style='SurfaceCard.TFrame' if border else 'Surface.TFrame')
    for child in container.winfo_children():
        if isinstance(child, (ttk.Frame, ttk.LabelFrame)):
            if str(child.cget('style')) in ('', 'TFrame', 'TLabelframe'):
                surface(child)
        elif isinstance(child, ttk.Label):
            old = str(child.cget('style'))
            if old in ('', 'TLabel', 'Muted.TLabel', 'Section.TLabel'):
                child.configure(style='SurfaceMuted.TLabel' if 'Muted' in old else
                                'SurfaceTitle.TLabel' if 'Section' in old else 'Surface.TLabel')
        elif isinstance(child, ttk.Checkbutton) and str(child.cget('style')) in ('', 'TCheckbutton'):
            child.configure(style='Surface.TCheckbutton')
