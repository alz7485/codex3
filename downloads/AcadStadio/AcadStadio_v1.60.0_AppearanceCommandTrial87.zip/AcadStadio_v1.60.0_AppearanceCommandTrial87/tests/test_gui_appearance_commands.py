import os,sys,unittest
import test_gui as gui
from macro_editor import edit_command
from tkinter import ttk

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class AppearanceGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_setting_command_shows_attributes_and_saves(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            self.assertEqual(set(w.advanced_rows),{'layer','color','linetype','linetype_scale','text_style','dim_style','condition'})
            gui.button(w,'コマンドを反映').invoke()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='APPEARANCE',layer='OUTLINE',color='1'),self.app.data['blocks'],self.app.data)
        self.assertEqual(result['type'],'APPEARANCE');self.assertEqual(result['color'],'1')
        self.assertEqual(self.errors,[])
    def test_line_editor_has_no_appearance_inputs(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            self.assertEqual(set(w.advanced_rows),{'condition'})
            gui.button(w,'コマンドを反映').invoke()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),self.app.data['blocks'],self.app.data)
        self.assertNotIn('layer',result);self.assertEqual(self.errors,[])
