# 現行版: Trial26 / 1.28.1-beta26

MacroEditorのコマンド見出しとpreview_headerを削除。preview_throughはconditions_actions内でcondition_buttonの右に配置。条件ボタンは▸条件を追加/▸条件あり/▾条件の短い表記。conditions_actionsとpreview_through_buttonを実体として公開。通常・最小画面・左幅320pxで1行に収まる。右Canvasは上端y=0（ウィンドウ内12px）。旧条件ボタンの長い文言や上部のチェック配置を戻さない。

# 現行版: Trial25 / 1.28.0-beta25

command_types.pyが分類とDRAWING_TYPES/DIMENSION_TYPESを共有。標準16種類。CommandList.toolbarの先頭3つは分類Menubutton、残り7つは編集/複製/削除/上下/Undo/Redo。全10操作が1行で左320pxにも収まる。新コマンドの定義はmodel/editor/engine/previewに反映。
フランジ中心線はCIRCLE 1個・LINE 3本、CENTER、CELTSCALE0.25。REPEATはHOLESの等配のみ。cad_setupのlinetypes[].builtin="CENTER"は初期設定で不足時だけentmake。外部LINは読まない。CadSetupEditorはbuiltinを保存/編集で保持する。
engineはlinetypeも共有appearanceへ保存し、SYSVAR/CUSTOMの変更も追跡。previewはCENTERをTkのdashパターンで表示、ズーム/復元で尺度を再計算。POLYLINEは2〜1000頂点、全体50000頂点。半径/直径寸法は一時測定円から独立したネイティブ寸法を作成し、一時円はエラー時も削除。DIMASSOC/PLINETYPE/PELLIPSEはSCR復元対象。
標準フランジは43/45/47・合計135図形。古い102/104/106・312の期待値を現行に使わない。外形/穴/寸法は維持。詳細はdocs/DRAWING_COMMANDS.md、docs/VALIDATION.md。

# 現行版: Trial24 / 1.27.3-beta24

メインのsettings_group/table_group/block_panelはGroup.TLabelframe。境界色#94a3b8、borderwidth=1、solid。内側横余白4px。左幅370px/右プレビュー位置は維持。以前のFlat.TLabelframeを使う仕様よりこちらを優先。

# 現行版: Trial23 / 1.27.2-beta23

DrawingTableTargetsを作図設定に追加。readonlyのFormulaGridTreeviewを表タブごとに遅延構築。チェックはステージし、明示適用時だけset_checked_rows(table_id=...)で使用表と対象を原子的に更新して1回Undo。コマンドcolor/linetype_scaleは数値または式。engineでCECOLOR/CELTSCALEへ出力し、appearance共有辞書で継承情報を保持。CECOLOR/CELTSCALEはcad_state既存の復元対象。ACI色のみpreviewへ反映、線種間隔はCAD確認。

MacroEditorの全幅metaを削除。command_panesを先に作成し、左command_page内の上部にmeta（名前）、下部にconditions_panel（条件の開閉）をpack。取消/確定のbarはcommand_panesより前にbottomでpack。右プレビューの開始位置は通常画面232→80px。条件説明を左幅で折り返す。GUIと手動の最小画面/条件開閉を検証。

# 現行版: Trial22 / 1.27.1-beta22

MacroEditorはcommand_panes（左CommandList・右preview_frame）へ変更。左右の境界はドラッグ可能。CommandList.toolbarは8操作をgridのrow=0へ集約し、IF/ELSE・REPEAT内部でも共通。＋のMenubuttonはCommand.TMenubutton、他はMainIcon.TButton。操作テキストはアクセシビリティ用に保持し、IconThemeで画像を付ける。詳細: docs/HANDOFF_Trial22.md。

# 過去版: Trial21 / 1.27.0-beta21

採用された整理案を実装。主画面はFlat.TLabelframe、左ペイン370px、目の表示メニュー、キャンバス内操作、横凡例、確認/SCR対象の下端表示、下部の図形数。DrawingCanvas(workspace=True)は主画面だけ。他のプレビューは従来の配置。詳細: docs/HANDOFF_Trial21.md。

# 現行版: Trial20 / 1.26.1-beta20

ブロック一覧の下段3ボタンを上のblock_actionsへ統合。操作は10個が1行。横幅372px未満ではDenseMainIcon.TButtonと小さい間隔で全アイコンを保持。詳細: docs/HANDOFF_Trial20.md。公開先alz7485/codex3はユーザーが明示承認済み。Trial19は318f29c936fd7155977e64b4befe3f884c2335c5で公開・ダウンロード確認済み。

# 現行版: Trial19 / 1.26.0-beta19

メインを設定/表へ集約。settings_groupとtable_group。サイズはSettingsPresetEditorへ統合。PreviewRowControlsはプレビュー行だけを変更し、DrawingTargetControlsは別窓でSCR対象を指定。旧サイズ別窓と簡易/展開作図欄を削除。詳細: docs/HANDOFF_Trial19.md。

# 現行版: Trial18 / 1.25.0-beta18

選択フローのタブとflow_viewを削除。メインはblock_panelのブロック一覧。block_actions内は追加/フォルダ追加/編集/↑/↓/削除/表示の1行。検査のコマンド移動は既存ProjectNavigator.select_addressへ。詳細: docs/HANDOFF_Trial18.md。

# 現行版: Trial17 / 1.24.2-beta17

CAD名の半角・全角スペースを許可。cad_setup.cad_nameを共有し、engineのレイヤー独自検証を廃止。script_cad_nameでスペース付きのSCR引数を引用。DWG取得/設定/モデル/フローの検証を一致させ、元の名前を保持。詳細: docs/HANDOFF_Trial17.md。

# 現行版: Trial16 / 1.24.1-beta16

入力表の別窓を左一覧＋右編集へ変更。table_picker/table_menuは廃止。table_listの選択はtable IDで管理し、メインのdrawing_table_pickerと同期。未確定セルはswitch_tableの冒頭で確定。管理ボタンはtable_list_frame内。計算列・2段表示・プレビュー連動・作図対象独立・倍率保持を維持。詳細: docs/HANDOFF_Trial16.md。

# 現在の追加仕様: AcadStadio 1.24.0-beta15

入力表の1行目は列の式・変数の定義行でもある。見出し名を同じ表内の変数として使い、計算列の2行目以降を表示専用にする。他の列は通常入力。セルは結果の下へ小さく薄い式を表示し、1行目の編集時だけ式そのものを表示する。日本語の見出しに対応。
計算の解決はtable_formulas.RowResolverを使い、プレビュー・SCR・試算・表表示で共有する。formula_gridは可視セルの2段表示。保存データを計算値で書き換えない。以降の過去記録よりREADME/CALCULATED_COLUMNS/HANDOFF_Trial15を優先する。

---

# 現在の仕様: AcadStadio 1.23.0-beta14

現行アプリは順次実行するブロックだけを扱う。メイン・編集・構成ツリーに作図対象／呼び出し専用の区分やBLOCKコマンドを戻さない。UI用の検証・正規化はproject_modelのvalidate_sequential_project / normalize_sequential_projectを使用する。新しいブロックのJSONにdraw属性はない。
既存コンパイラの低レベル旧形式処理はテスト用に残っているが、現行アプリの操作仕様ではない。旧プロジェクトの移行機能は追加しない。以下の過去記録より現行README・HANDOFF_Trial14を優先する。

---

# AcadStadio v1.20.4-beta5（DWG設定読込試用版5）— 継続開発の入口

1.20.4-beta5では「CAD初期設定」にDWGからの定義選択取込を実装。`src/dwg_resources.py` はWindowsの起動中AutoCAD COM経由でDWGを読み取り専用で開き、レイヤー・文字スタイル・寸法スタイル・線種のうち現在のCAD初期設定形式で扱える値を取得する。`src/dwg_import_editor.py` はチェックボックス・検索・一括選択・同名衝突の保持/上書きUI。`src/cad_setup_editor.py` に起動ボタン。取り込みは元の `cad_setup` のドラフトへ反映し、最終保存は既存の「設定を確定」操作。`tests/test_dwg_resources.py` はCOMモックで値変換と選択取込を検証する。`tests/test_gui_cad_setup.py` に実ウィジェットの追加テストあり（表示環境で要実行）。

AutoCADが未起動、pywin32未導入、別CAD実装、COM拒否の場合は利用不可。線種定義の元LINファイルは自動復元せず手動指定。寸法スタイルは現モデルが持つ4値だけを取得し、それ以外は取り込まない。AutoCAD実機でのCOM取込成功とWindows UIを検証済みと主張しないこと。

1.20.3-beta4はコマンド式の各入力欄から表を直接選ぶ補助画面を追加。`src/input_assist.py` の `show_table_reference_picker`、`selected_table_reference` と `src/macro_editor.py` の「表・変数」メニューを参照。列見出しは `[表名]@列`、セルは `[表名]@列{固定行}`、任意に変数行も指定。表・行のクリックは参照式を組み立てるだけで元の入力表を改変しない。100行ページ表示とジャンプを実装。既存の式入力・条件ビルダー・内部計算を変更していない。`tests/test_input_assist.py` と `tests/test_gui_usability.py` に回帰検証を追加。GUI側は表示環境での実機確認が必要。

1.20.2-beta3はユーザー向けの「グローバル変数」を「変数」に改称。`変数.参照行` など日本語の変数名を使えます。コード・JSONの `globals` キー、旧式 `global.ROW`、スコープおよび順次評価はそのまま維持。`project_model.valid_variable_name` はプロジェクト変数専用のUnicode識別子検証です。ほかの列名や共通設定名の規則は変更しません。
GUIメニュー・参照候補と説明を「変数」に統一し、旧ローカル変数候補を表示しないようにしました。テストは `tests/test_japanese_variables.py`。`docs/VARIABLES.md` を参照。

1.20.1-beta2は `src/table_references.py` を追加。`[表名]@X`、`@X{2}`、`[表名]@X{global.ROW}` を式評価器で扱います。行指定なしは作図対象の現在行、明示指定は1始まり整数です。元の `@X` は互換維持。
`engine.py` が選択対象表・行と全入力表を評価コンテキストへ渡し、`expression_sample.py` の試算も同じ解釈です。表名の変更時は `main.py` が式内の明示参照を追従更新します。
詳細は `docs/TABLE_ROW_REFERENCES.md` と `tests/test_table_references.py`。データモデル版11は維持します。

1.20.0-beta1では `src/input_assist.py` を追加し、`src/macro_editor.py` の入力UIのみ段階表示に変更しました。
詳細設定が折りたたまれても既存値を保持し、コマンドの種類変更前の値もドラフトへ保持します。
コマンド追加メニューは種類を選んだ状態で既存 `edit_command` を開きます。
条件ビルダーは簡単な比較式の補助であり、AST評価や保存スキーマは変更しません。
GUIの実行確認はこの試用版では未実施なので、Windows側で確認してください。
`docs/UI_TRIAL_1.md` を参照。

この配布の最新実装は `src/`。CADScriptMaker v1.5を土台に完成させたPythonソース版です。
複数入力表と作図設定は `src/project_data.py`、モデル版は11です。
現在の機能・制限は `README.md`、`ARCHITECTURE_AND_KNOWN_LIMITATIONS.md` とソースを優先してください。
古いREADME・変更履歴は `docs/history/` に保管しています。

- `python tests/smoke_test.py`
- `python -m unittest discover -s tests -v`
- `python src/main.py`

GUIを含む実施結果は `docs/VALIDATION.md` を参照。Windows / AutoCAD実機の動作を検証済みと主張しないでください。
Windows用EXEは未ビルドです。任意の将来ビルド用にPyInstaller onedirのspecを付属します。

維持する仕様: プロジェクト → ブロック → コマンド、Excel / CSV、明示的な変数スコープ、
ASTによる式評価、循環ブロック禁止、保存前検査、履歴、未保存確認、原子的保存、世代バックアップ。
IFとREPEATはGUI・コンパイラ・構成ツリー・検査・プレビューで対応しています。

次の実作業はWindows 11 / Python 3.11のGUI確認と、対象バージョンのAutoCADでのSCR実行確認です。
利用するAutoCADの文字スタイルは固定高さ0を前提とします。図面テンプレートによる見た目の違いは残ります。

ユーザー登録コマンドは `src/command_catalog.py` / `src/catalog_editor.py`。初期15件は `assets/default_commands.json`。
標準は11タイプです。登録内容と呼出をプロジェクトJSONへ保存し、別プロジェクトにはライブラリJSONを取り込みます。
寸法スタイルは新規名用／既存名更新を分離。任意SCRの図形・外観はプレビューへ反映しないことをUI・資料で維持してください。

設定プリセットは `src/settings_presets.py` / `src/settings_preset_editor.py`。作図ブロックとは別の、サイズ等の値の保存です。
標準3件は保護、カスタムは最大100件。管理画面の操作は確定まで一時保持し、設定適用は登録キーのみを反映します。

システム設定の復元は `src/cad_state.py`。生成SCRにAutoLISPの退避と復元を付加します。
標準生成の設定・UCS・寸法スタイル選択、SYSVAR、登録の直接指定と追加system_variablesが対象。
中断時はCADFLOWRESTOREで手動復元。AutoCAD実機の検証は未実施です。

別窓のプロジェクト一覧は `src/project_library.py` / `src/project_sidebar.py`。個別プロジェクトはJSON、フォルダー・履歴はユーザー別library.jsonです。

メインUIはworkspace_tabsの作図（ブロック・プレビュー）/入力表。初回は作図、以後は作業状態を復元。表の選択・対象行・履歴は共有し、切替で変更しないこと。

一覧はApp.show_project_listで必要時に生成し、閉じるとwithdraw。非モーダルで重複生成せず、メイン画面は作図と入力表へ全幅を使います。

CAD初期設定はcad_setup.py/cad_setup_editor.py。モデル版10からの定義を維持し、任意の冒頭CADFLOWINIT、同名定義は維持。フローのレイヤー/線種/文字・寸法スタイルに候補を表示します。詳細はdocs/CAD_INITIALIZATION.md。

1.17のUI・退避・検査の移動は docs/USABILITY.md を参照。フローアドレス、入力表セル編集、数式試算、原子的作業退避、線画アイコンを追加しました。メインUIのプレビュー上部に独立見出しを戻さないこと。最新の検証件数・結果はdocs/VALIDATION.mdを参照してください。


1.18の統合構造は`src/block_model.py`と`docs/BLOCKS.md`を参照してください。
保存モデル版11は順序付き`blocks`配列だけを持ち、作図用の`presets`キーを保存しません。
各ブロックはid/name/draw/condition/variables/commandsを保持します。BLOCK.nameは表示名ではなく参照先IDです。
表示名の変更で参照を書き換えないこと。draw=Falseは呼び出し専用であり、明示的な呼び出しまで無効化しないこと。
既存の条件・変数・繰り返し・SETの互換性を維持します。旧形式の内部投影は互換境界だけで使い、JSONへ戻さないこと。
旧作図プリセットと共通ブロックの別管理画面・別階層を再導入しないこと。文字高さ等の設定プリセットは維持します。


1.19のフォルダ分類は `src/block_folders.py` と `src/block_browser.py`、操作は `docs/BLOCK_FOLDERS.md` を参照してください。
モデル版11の追加メタデータであり、`blocks` の実行順は維持します。フォルダ移動は分類のみ、削除は中のブロックを未分類へ戻す操作です。
一覧の見た目の並びと実行順を混同せず、常に「順」列とコンパイラの配列順を検証してください。
