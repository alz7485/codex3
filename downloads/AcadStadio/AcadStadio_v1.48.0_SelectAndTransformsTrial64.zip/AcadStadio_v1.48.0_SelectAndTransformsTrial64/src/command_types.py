"""Shared drawing types and the three compact command-add categories."""

COMMAND_GROUPS = (
    ("線・形状を追加 ▾", ("LINE", "POLYLINE", "CIRCLE", "ARC", "ELLIPSE", "RECTANGLE", "POINT", "HATCH", "SPLINE", "INSERT", "OFFSET", "TRIM", "EXTEND", "COPY", "MIRROR", "ROTATE", "ROTATECOPY", "ARRAYRECT", "EXPLODE", "CADBLOCK", "SCALE")),
    ("文字・寸法を追加 ▾", ("TEXT", "MTEXT", "LEADER", "DIMLINEAR", "DIMALIGNED", "DIMRADIUS", "DIMDIAMETER")),
    ("制御を追加 ▾", ("SELECT", "IF", "REPEAT", "SYSVAR", "CUSTOM")),
)
DIMENSION_TYPES = frozenset(("LEADER", "DIMLINEAR", "DIMALIGNED", "DIMRADIUS", "DIMDIAMETER"))
DRAWING_TYPES = frozenset(kind for _, kinds in COMMAND_GROUPS[:2] for kind in kinds)

GUIDE_TYPES = DRAWING_TYPES - frozenset(("OFFSET", "TRIM", "EXTEND", "COPY", "MIRROR", "ROTATE", "ROTATECOPY", "ARRAYRECT", "EXPLODE", "CADBLOCK", "SCALE"))
