"""Subset of AutoCAD inline text formatting, independent of DXF dependencies."""
import re

def normalize(text):
    return re.sub(r'[¥￥](?=[HhSsPp])',lambda m:'\\',text)

def has_format(text):
    return bool(re.search(r'\\(?:H[0-9.+-]+[xX]?;|S[^;]*;|[ACcFfQWT][^;]*;|P)',normalize(text)))

def encoded(text):
    # Valid CAD codes opt into native MTEXT syntax. Plain braces and paths
    # retain their previous literal behavior.
    if has_format(text):
        return normalize(text).replace('\n',r'\P').replace('\t','    ')
    return text.replace('\\','\\\\').replace('{',r'\{').replace('}',r'\}').replace('\n',r'\P').replace('\t','    ')

def tokens(text,height):
    """Yield (upper, lower-or-None, relative height) and newline tokens."""
    text=normalize(text);scale=1.;stack=[];i=0
    while i<len(text):
        c=text[i]
        if c=='{':stack.append(scale);i+=1;continue
        if c=='}':scale=stack.pop() if stack else 1.;i+=1;continue
        if c=='\\' and i+1<len(text):
            code=text[i+1];i+=2
            if code in '\\{}':yield (code,None,scale);continue
            if code=='P':yield ('\n',None,scale);continue
            if code=='~':yield (' ',None,scale);continue
            end=text.find(';',i)
            if code=='H' and end>=0:
                raw=text[i:end]
                try:
                    value=float(raw.rstrip('xX'));scale=scale*value if raw.lower().endswith('x') else value/height
                    scale=max(.01,min(100.,scale))
                except ValueError:pass
                i=end+1;continue
            if code=='S' and end>=0:
                raw=text[i:end];parts=re.split(r'[\^/#]',raw,maxsplit=1)
                yield (parts[0],parts[1] if len(parts)>1 else '',scale);i=end+1;continue
            if code in 'ACcFfQWT' and end>=0:i=end+1;continue
            if code in 'LlOoKk':continue
            yield ('\\'+code,None,scale);continue
        yield (c,None,scale);i+=1
