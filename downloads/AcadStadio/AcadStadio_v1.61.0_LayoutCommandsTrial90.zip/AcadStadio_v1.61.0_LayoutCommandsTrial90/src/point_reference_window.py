"""Small point-reference window sharing its owner's interactive preview."""
import tkinter as tk
from tkinter import ttk


class PointReferenceWindow(tk.Toplevel):
    """Keep the owner's grab: taking a grab here would disable its preview."""
    def __init__(self, owner, anchor, target):
        super().__init__(owner)
        self.withdraw()
        self.transient(owner)
        self.title('点参照 — ' + target)
        self.owner = owner
        self.anchor = anchor
        self._arrange_job = None
        self._positioned = False
        self.minsize(320, 140)
        self.footer = ttk.Frame(self, padding=(3, 2, 3, 3))
        self.footer.pack(side='bottom', fill='x')
        host = ttk.Frame(self, padding=(3, 3, 3, 0))
        host.pack(fill='both', expand=True)
        host.rowconfigure(0, weight=1)
        host.columnconfigure(0, weight=1)
        self.viewport = tk.Canvas(host, bg='#f3f5f9', highlightthickness=0)
        self.viewport.grid(row=0, column=0, sticky='nsew')
        scrollbar = ttk.Scrollbar(host, command=self.viewport.yview)
        self.content = ttk.Frame(self.viewport, style='PointCard.TFrame', padding=3)
        node = self.viewport.create_window(0, 0, window=self.content, anchor='nw')
        def scrolled(first, last):
            scrollbar.set(first, last)
            if float(first) > 0 or float(last) < 1:
                scrollbar.grid(row=0, column=1, sticky='ns')
            else:
                scrollbar.grid_remove()
        self.viewport.configure(yscrollcommand=scrolled)
        def size_changed(event=None):
            self.viewport.itemconfigure(node, width=self.viewport.winfo_width())
            self.viewport.configure(scrollregion=self.viewport.bbox('all'))
            self.queue_arrange()
        self.content.bind('<Configure>', size_changed)
        self.viewport.bind('<Configure>', size_changed)
        def scroll(event):
            if self.content.winfo_height() <= self.viewport.winfo_height():return
            step = -1 if event.num == 4 or event.delta > 0 else 1
            self.viewport.yview_scroll(step, 'units')
        for seq in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
            self.bind(seq, scroll, add='+')
        self.bind('<Destroy>', self._destroyed, add='+')

    def queue_arrange(self):
        if self._arrange_job is None:
            self._arrange_job = self.after_idle(self._arrange)

    def _arrange(self):
        self._arrange_job = None
        if not self.winfo_exists() or not self.owner.winfo_exists():return
        # Place near the lower part of the shared preview without resizing it.
        width = max(320, min(360, self.anchor.winfo_width()-24))
        limit = max(140, min(self.anchor.winfo_height()-36,self.owner.winfo_height()-76,self.winfo_screenheight()-90))
        height = min(limit, max(140, self.content.winfo_reqheight()+self.footer.winfo_reqheight()+8))
        if self._positioned:
            # Retain a user-moved position and width when optional controls appear.
            width = max(320, self.winfo_width())
            x=max(0,min(self.winfo_x(),self.winfo_screenwidth()-width-12))
            y=max(0,min(self.winfo_y(),self.winfo_screenheight()-height-45))
            if (self.anchor.winfo_rootx()<=x<self.anchor.winfo_rootx()+self.anchor.winfo_width()
                    and y>=self.anchor.winfo_rooty() and height<self.anchor.winfo_height()):
                y=min(y,self.anchor.winfo_rooty()+self.anchor.winfo_height()-height-48)
            self.geometry(f'{width}x{height}+{x}+{y}')
        else:
            x = max(0, min(self.anchor.winfo_rootx()+max(12,(self.anchor.winfo_width()-width)//2), self.winfo_screenwidth()-width-12))
            y = max(0, min(self.anchor.winfo_rooty()+max(8,int((self.anchor.winfo_height()-height)*0.78)), self.winfo_screenheight()-height-45))
            self.geometry(f'{width}x{height}+{x}+{y}')
            self._positioned = True
            self.deiconify()
            self.lift()

    def _destroyed(self, event):
        if event.widget is self and self._arrange_job is not None:
            self.after_cancel(self._arrange_job)
            self._arrange_job = None


class PointReferenceCoordinates(ttk.Frame):
    """Coordinates of the selected source point; displacement belongs to the form."""
    def __init__(self,parent):
        super().__init__(parent)
        self.rows={};self.values={}
        for name in ('X','Y'):
            row=ttk.Frame(self)
            ttk.Label(row,text=name+' =').pack(side='left')
            value=ttk.Label(row,style='PointResultValue.TLabel')
            value.pack(side='left',padx=(4,10))
            self.rows[name]=row;self.values[name]=value
        self.note=ttk.Label(self,style='Muted.TLabel',wraplength=310)
    def update_values(self,origin,result,axis,status=''):
        for i,name in enumerate(('X','Y')):
            row=self.rows[name];row.pack_forget()
            if axis in ('XY',name):row.pack(side='left')
            self.values[name].configure(text=f'{result[i]:.12g}' if result else '—')
        self.note.pack_forget()
        if not origin or not result:
            self.note.configure(text=status);self.note.pack(side='bottom',fill='x')
