"""Arc construction geometry, independent of CAD and UI."""
import math
MODES={'center_angles':'中心・半径・開始角・終了角','three_points':'始点・通過点・終点（3点）','start_center_end':'始点・中心・終点'}

def arc_geometry(mode,points):
    a,b,c=points
    if mode=='three_points':
        ax,ay=a;bx,by=b;cx,cy=c
        d=2*((bx-ax)*(cy-ay)-(by-ay)*(cx-ax))
        scale=max(math.dist(a,b),math.dist(a,c),math.dist(b,c))
        if scale==0 or abs(d)<1e-10*scale*scale:raise ValueError('3点は異なる位置で、一直線上にない点を指定してください')
        u=(bx-ax)**2+(by-ay)**2;v=(cx-ax)**2+(cy-ay)**2
        center=(ax+(u*(cy-ay)-v*(by-ay))/d,ay+((bx-ax)*v-(cx-ax)*u)/d)
    elif mode=='start_center_end':
        center=b
        if not math.isclose(math.dist(a,b),math.dist(c,b),rel_tol=1e-7,abs_tol=1e-8):raise ValueError('始点と終点は中心から同じ距離にしてください')
    else:raise ValueError('未対応の円弧入力方式です')
    r=math.dist(a,center)
    angle=lambda p:math.degrees(math.atan2(p[1]-center[1],p[0]-center[0]))%360
    start=angle(a);sweep=(angle(c)-start)%360
    if r<=0 or math.isclose(sweep,0,abs_tol=1e-9):raise ValueError('半径と円弧の長さは0にできません')
    if mode=='three_points' and (angle(b)-start)%360>sweep:sweep-=360
    return center,r,start,sweep


def arc_script(center, radius, start, sweep, points=None):
    """Send typed points in one complete ARC call, avoiding SCR point parsing."""
    if points is None:
        points = [
            (center[0] + radius * math.cos(math.radians(start + sweep * t)),
             center[1] + radius * math.sin(math.radians(start + sweep * t)))
            for t in (0, 0.5, 1)
        ]
    def literal(value):
        # A decimal point keeps scientific numeric literals unambiguous in Lisp.
        text = repr(float(value))
        return text
    args = ['"_.ARC"']
    for x, y in points:
        args.extend(['"_non"', f'(list {literal(x)} {literal(y)} 0.0)'])
    return '(command-s ' + ' '.join(args) + ')'
