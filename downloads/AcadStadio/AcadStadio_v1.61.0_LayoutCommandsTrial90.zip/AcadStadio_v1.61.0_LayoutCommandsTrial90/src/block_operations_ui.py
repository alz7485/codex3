"""Small transactional dialogs for splitting or joining drawing blocks."""
import tkinter as tk
from tkinter import ttk, messagebox
from table_grid import GridTreeview
from theme import fit_window
from macro_editor import command_summary, TYPE_LABELS
from block_operations import split_block, join_blocks, suggested_name


def _window(parent, title):
    previous_grab = parent.grab_current()
    win = tk.Toplevel(parent); win.title(title); win.transient(parent); win.grab_set()
    def restore_grab(event):
        if event.widget is not win or previous_grab is None:
            return
        def restore():
            try:
                if previous_grab.winfo_exists() and parent.grab_current() is None:
                    previous_grab.grab_set()
            except tk.TclError:
                pass
        parent._root().after_idle(restore)
    win.bind('<Destroy>', restore_grab, add='+')
    fit_window(win, 820, 640, 680, 520)
    win.bind('<Escape>', lambda event: win.destroy())
    return win


def _table(parent, **options):
    host=ttk.Frame(parent);host.pack(fill='both',expand=True,padx=12,pady=10)
    table=GridTreeview(host,**options)
    scroll=ttk.Scrollbar(host,command=table.yview)
    table.pack(side='left',fill='both',expand=True)
    def changed(first,last):
        scroll.set(first,last)
        if float(first)>0 or float(last)<1:scroll.pack(side='right',fill='y')
        else:scroll.pack_forget()
    table.configure(yscrollcommand=changed)
    return table


def split_dialog(parent, project, index, on_apply):
    block = project['blocks'][index]
    if block.get('guide') or len(block['commands']) < 2:
        messagebox.showinfo('ブロックを分割', 'コマンドが2件以上ある作図ブロックを選択してください。', parent=parent)
        return
    win = _window(parent, 'ブロックを分割')
    ttk.Label(win, text='後半の先頭にするコマンドを選択します。', padding=12).pack(anchor='w')
    ttk.Label(win, text='分割元：' + block['name'], padding=(12, 0)).pack(anchor='w')
    bar = ttk.Frame(win, padding=12); bar.pack(side='bottom', fill='x')
    ttk.Button(bar, text='キャンセル', command=win.destroy).pack(side='left')
    name = tk.StringVar(value=suggested_name(project, block['name'] + '（後半）'))
    fields = ttk.Frame(win, padding=12); fields.pack(side='bottom', fill='x')
    ttk.Label(fields, text='新しいブロック名').pack(anchor='w', pady=(0, 4))
    ttk.Entry(fields, textvariable=name).pack(fill='x')
    status = tk.StringVar(); ttk.Label(fields, textvariable=status).pack(anchor='w', pady=(8, 0))
    table = _table(win, columns=('type', 'command'), show='tree headings', selectmode='browse')
    table.heading('#0', text='順'); table.column('#0', width=55, stretch=False)
    table.heading('type', text='種類'); table.column('type', width=115, stretch=False)
    table.heading('command', text='コマンド（選択した行から後半へ）'); table.column('command', width=540)
    for i, command in enumerate(block['commands']):
        table.insert('', 'end', iid=str(i), text=str(i + 1), values=(TYPE_LABELS.get(command['type'], command['type']).split(' · ')[-1], command_summary(command)))
    def changed(event=None):
        start = int(table.selection()[0]) if table.selection() else 0
        status.set(f'前半：{start}件 ／ 後半：{len(block["commands"]) - start}件　条件・所属フォルダは引き継ぎます。')
        apply_button.configure(state='normal' if start > 0 else 'disabled')
    def apply():
        try:
            trial = split_block(project, index, int(table.selection()[0]), name.get())
        except ValueError as exc:
            messagebox.showerror('分割の確認', str(exc), parent=win); return
        win.destroy(); on_apply(trial, [index, index + 1])
    apply_button = ttk.Button(bar, text='分割する', command=apply, style='Primary.TButton'); apply_button.pack(side='right')
    table.bind('<<TreeviewSelect>>', changed)
    table.selection_set(str(max(1, len(block['commands']) // 2))); changed()
    win.command_table, win.new_name, win.apply_button = table, name, apply_button
    return win


def join_dialog(parent, project, selected, on_apply):
    win = _window(parent, 'ブロックを結合')
    ttk.Label(win, text='連続するブロックを選択します（Ctrl／Shiftで複数選択）。', padding=12).pack(anchor='w')
    bar = ttk.Frame(win, padding=12); bar.pack(side='bottom', fill='x')
    ttk.Button(bar, text='キャンセル', command=win.destroy).pack(side='left')
    fields = ttk.Frame(win, padding=12); fields.pack(side='bottom', fill='x')
    ttk.Label(fields, text='結合後のブロック名').pack(anchor='w', pady=(0, 4))
    name = tk.StringVar(value=suggested_name(project, '結合したブロック'))
    ttk.Entry(fields, textvariable=name).pack(fill='x')
    ttk.Label(fields, text='コマンドは一覧の順に結合します。所属フォルダは先頭ブロックを使用します。').pack(anchor='w', pady=(8, 0))
    status = tk.StringVar(); ttk.Label(fields, textvariable=status).pack(anchor='w', pady=(6, 0))
    table = _table(win, columns=('name', 'count', 'condition'), show='headings', selectmode='extended')
    for key, title, width in [('name', 'ブロック名', 300), ('count', 'コマンド数', 90), ('condition', '実行条件', 260)]:
        table.heading(key, text=title); table.column(key, width=width)
    for i, block in enumerate(project['blocks']):
        if not block.get('guide'):
            table.insert('', 'end', iid=str(i), values=(block['name'], len(block['commands']), block.get('condition', '') or '条件なし'))
    def changed(event=None):
        ids = sorted(int(i) for i in table.selection())
        valid = len(ids) >= 2 and ids == list(range(ids[0], ids[-1] + 1))
        valid = valid and len({project['blocks'][i].get('condition', '').strip() for i in ids}) == 1
        status.set(f'{len(ids)}ブロック ／ {sum(len(project["blocks"][i]["commands"]) for i in ids)}コマンド' if valid else '同じ実行条件で、連続するブロックを2件以上選択してください。')
        apply_button.configure(state='normal' if valid else 'disabled')
    def apply():
        ids = sorted(int(i) for i in table.selection())
        try:
            trial = join_blocks(project, ids, name.get())
        except ValueError as exc:
            messagebox.showerror('結合の確認', str(exc), parent=win); return
        win.destroy(); on_apply(trial, [ids[0]])
    apply_button = ttk.Button(bar, text='結合する', command=apply, style='Primary.TButton'); apply_button.pack(side='right')
    table.bind('<<TreeviewSelect>>', changed)
    table.selection_set([str(i) for i in selected if table.exists(str(i))]); changed()
    win.block_table, win.new_name, win.apply_button = table, name, apply_button
    return win
