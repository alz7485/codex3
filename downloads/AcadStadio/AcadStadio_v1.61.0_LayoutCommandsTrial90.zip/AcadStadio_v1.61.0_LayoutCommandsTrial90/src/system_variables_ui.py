"""Compact editable rows for a grouped system-variable command."""
import tkinter as tk
from tkinter import ttk

COMMON=('OSMODE','OSNAPCOORD','SNAPMODE','ORTHOMODE','DYNMODE','CMDECHO','LTSCALE','PSLTSCALE','MSLTSCALE','LWDISPLAY','ATTREQ','MIRRTEXT','DIMASSOC','PICKADD','PICKFIRST')
class SystemVariablesEditor(ttk.Frame):
 def __init__(self,parent,items,changed):
  super().__init__(parent,padding=8);self.items=items;self.changed=changed;self.rows=[]
  self.grid_columnconfigure(2,weight=1)
  self.redraw()
 def redraw(self):
  for child in self.winfo_children():child.destroy()
  self.rows=[]
  for col,title in enumerate(('システム変数','値の種類','設定値・式','')):ttk.Label(self,text=title).grid(row=0,column=col,sticky='w',pady=(0,5))
  for i,item in enumerate(self.items):
   variables={k:tk.StringVar(value=str(item.get(k,v))) for k,v in [('name','OSMODE'),('value_kind','number'),('value','0')]}
   name=ttk.Combobox(self,textvariable=variables['name'],values=COMMON,width=16)
   kind=ttk.Combobox(self,textvariable=variables['value_kind'],values=('number','text'),state='readonly',width=8)
   value=ttk.Entry(self,textvariable=variables['value'],width=22)
   for j,widget in enumerate((name,kind,value)):widget.grid(row=i+1,column=j,sticky='ew',padx=(0,5),pady=3)
   def update(*_,item=item,variables=variables):
    item.update({k:v.get() for k,v in variables.items()});self.changed()
   for variable in variables.values():variable.trace_add('write',update)
   ttk.Button(self,text='削除',command=lambda i=i:self.remove(i),width=5).grid(row=i+1,column=3)
   self.rows.append(variables)
  ttk.Button(self,text='＋ 項目を追加',command=self.add).grid(row=len(self.items)+1,column=0,columnspan=4,sticky='w',pady=(8,0))
 def add(self):
  if len(self.items)>=100:return
  self.items.append(dict(name='',value_kind='number',value='0'));self.redraw();self.changed()
 def remove(self,index):
  self.items.pop(index);self.redraw();self.changed()
