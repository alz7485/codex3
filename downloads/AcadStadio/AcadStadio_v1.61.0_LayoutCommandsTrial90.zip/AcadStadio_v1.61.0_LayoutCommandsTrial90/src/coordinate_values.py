"""Separate a coordinate's reference value and displacement without new JSON fields."""
from command_points import read_point_reference, reference
from derived_points import read_relation_reference
from vertex_points import split_top_level


def compose_coordinate(base, movement):
    base=str(base).strip() or '0'
    movement=str(movement).strip() or '0'
    return base if movement in ('0','0.0','+0','-0') else f'({base}) + ({movement})'


def _closing(text, start=0):
    depth=0;quote=None;escaped=False
    for i in range(start,len(text)):
        char=text[i]
        if quote:
            if escaped:escaped=False
            elif char=='\\':escaped=True
            elif char==quote:quote=None
        elif char in ('"',"'"):quote=char
        elif char=='(':depth+=1
        elif char==')':
            depth-=1
            if depth==0:return i
    return None


def split_coordinate(expression):
    text=str(expression).strip()
    # Only unwrap our explicit two-field representation. Arbitrary arithmetic
    # entered as the reference remains untouched.
    if text.startswith('('):
        end=_closing(text)
        if end is not None and text[end+1:].startswith(' + ('):
            start=end+4
            if _closing(text,start)==len(text)-1:
                return text[1:end],text[start+1:-1]
    old=read_point_reference(text)
    if old and old['axis'] is not None:
        angle=old.get('angle','0')
        return reference(old['identity'],old['point'],old['axis'],angle if angle!='0' else None),old['offsets'][0]
    relation=read_relation_reference(text)
    if relation and relation['axis'] in ('X','Y'):
        name='交点' if text.startswith('交点(') else '接点'
        end=_closing(text,len(name))
        args=split_top_level(text[len(name)+1:end],',')
        size=7 if name=='交点' else 5
        return name+'('+', '.join(args[:size])+')',relation['offsets'][0 if relation['axis']=='X' else 1]
    return text,'0'


class CoordinateValue:
    def __init__(self, master, value):
        import tkinter as tk
        self.value=value
        base,movement=split_coordinate(value.get())
        self.base=tk.StringVar(master=master,value=base)
        self.movement=tk.StringVar(master=master,value=movement)
        self.syncing=False
        self.traces=[]
        for variable,callback in ((self.base,self._parts_changed),(self.movement,self._parts_changed),(value,self._value_changed)):
            self.traces.append((variable,variable.trace_add('write',callback)))
        self._parts_changed()

    def _parts_changed(self,*_):
        if self.syncing:return
        self.syncing=True
        try:self.value.set(compose_coordinate(self.base.get(),self.movement.get()))
        finally:self.syncing=False

    def _value_changed(self,*_):
        if self.syncing:return
        self.syncing=True
        try:
            base,movement=split_coordinate(self.value.get())
            self.base.set(base);self.movement.set(movement)
        finally:self.syncing=False

    def close(self):
        import tkinter as tk
        for variable,trace in self.traces:
            try:variable.trace_remove('write',trace)
            except tk.TclError:pass
        self.traces.clear()
