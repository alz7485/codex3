"""Layout/viewport operations and grouped system-variable editing."""
import re
from cad_setup import cad_name
from extended_commands import quoted

FIELDS={
 'SPACE':[('space_mode','モデル空間'),('layout_name','Layout1'),('viewport_id','2')],
 'LAYOUT':[('layout_action','作成して選択'),('layout_name','Layout1'),('source_layout','Layout1')],
 'VIEWPORT':[('viewport_action','矩形を作成'),('x1','0'),('y1','0'),('x2','200'),('y2','150'),('viewport_id','2'),('view_x','0'),('view_y','0'),('view_scale','1')],
 'SYSVARS':[('execution','per_row')],
}
for _fields in FIELDS.values():
 if not any(k=='execution' for k,v in _fields):_fields.append(('execution','per_row'))

CHOICES={'space_mode':('モデル空間','レイアウト空間','ビューポート内'),
 'layout_action':('作成して選択','選択','複製','名前を変更'),
 'viewport_action':('矩形を作成','アクティブにする','ロック','ロック解除','表示中心・尺度')}
LABELS={'space_mode':'移動先','layout_name':'レイアウト名','source_layout':'元のレイアウト名',
 'layout_action':'操作','viewport_action':'操作','viewport_id':'ビューポート番号',
 'view_x':'表示中心X','view_y':'表示中心Y','view_scale':'尺度（紙／モデル）'}
TITLES={'SPACE':'SPACE · 作図空間を切り替え','LAYOUT':'LAYOUT · レイアウトを操作','VIEWPORT':'VIEWPORT · ビューポートを操作','SYSVARS':'SYSVARS · システム変数をまとめて設定'}

def visible_fields(kind,command):
 fields=list(FIELDS[kind]);keys=None
 if kind=='SPACE':
  mode=command.get('space_mode','モデル空間');keys={'space_mode'}|({'layout_name'} if mode!='モデル空間' else set())|({'viewport_id'} if mode=='ビューポート内' else set())
 elif kind=='LAYOUT':keys={'layout_action','layout_name'}|({'source_layout'} if command.get('layout_action','作成して選択') in ('複製','名前を変更') else set())
 elif kind=='VIEWPORT':
  action=command.get('viewport_action','矩形を作成');keys={'viewport_action'}|({'x1','y1','x2','y2'} if action=='矩形を作成' else {'viewport_id'})|({'view_x','view_y','view_scale'} if action=='表示中心・尺度' else set())
 if keys is not None:keys.add('execution')
 return [(k,v) for k,v in fields if keys is None or k in keys]

def validate_batch(items):
 if not isinstance(items,list) or not 1<=len(items)<=100:raise ValueError('システム変数を1〜100件指定してください')
 names=set()
 for item in items:
  if not isinstance(item,dict) or not isinstance(item.get('name'),str) or not re.fullmatch('[A-Za-z][A-Za-z0-9_]*',item['name']):raise ValueError('システム変数名を英数字で指定してください')
  name=item['name'].upper()
  if name in names:raise ValueError('システム変数名が重複しています: '+name)
  names.add(name)
  if item.get('value_kind','number') not in ('number','text'):raise ValueError('値の種類が不正です')
  if not isinstance(item.get('value'),(str,int,float)) or (item.get('value_kind','number')=='number' and not str(item['value']).strip()):raise ValueError('システム変数の値を入力してください')

def render(command,values,number):
 kind=command['type']
 def n(key,default='0'):return float(number(command.get(key,default),values))
 def vp():
  value=n('viewport_id','2')
  if not value.is_integer() or value<2:raise ValueError('ビューポート番号は2以上の整数です')
  return int(value)
 def name(key):
  from advanced_commands import text_value
  raw=text_value(command.get(key,''),values)
  if not isinstance(raw,str) or not cad_name(raw) or raw.casefold()=='model':raise ValueError('レイアウト名を入力してください（Modelは指定できません）')
  return quoted(raw)
 paper='(if (= (getvar "TILEMODE") 1) (error "AcadStadio: Select a layout first")) (if (/= (getvar "CVPORT") 1) (command-s "_.PSPACE")) '
 activate=lambda:paper+'(command-s "_.MSPACE") '+f'(setvar "CVPORT" {vp()}) '
 if kind=='SPACE':
  mode=command.get('space_mode','モデル空間')
  if mode not in CHOICES['space_mode']:raise ValueError('移動先を選択してください')
  if mode=='モデル空間':body='(setvar "TILEMODE" 1)'
  else:
   body=f'(if (not (member {name("layout_name")} (layoutlist))) (error "AcadStadio: Layout does not exist")) (setvar "TILEMODE" 0) (setvar "CTAB" {name("layout_name")}) '
   body+=paper if mode=='レイアウト空間' else activate()
 elif kind=='LAYOUT':
  action=command.get('layout_action','作成して選択');target=name('layout_name')
  if action not in CHOICES['layout_action']:raise ValueError('レイアウトの操作を選択してください')
  if action=='選択':return render(dict(type='SPACE',space_mode='レイアウト空間',layout_name=command['layout_name']),values,number)
  body='' if action=='作成して選択' else f'(if (member {target} (layoutlist)) (error "AcadStadio: Layout name already exists")) '
  if action=='作成して選択':body+=f'(if (not (member {target} (layoutlist))) (command-s "_.-LAYOUT" "_New" {target})) '
  else:
   source=name('source_layout');body+=f'(if (not (member {source} (layoutlist))) (error "AcadStadio: Source layout does not exist")) '
   body+=f'(command-s "_.-LAYOUT" "{ "_Copy" if action=="複製" else "_Rename"}" {source} {target}) '
  body+=f'(setvar "TILEMODE" 0) (setvar "CTAB" {target}) '+paper
 elif kind=='VIEWPORT':
  action=command.get('viewport_action','矩形を作成')
  if action not in CHOICES['viewport_action']:raise ValueError('ビューポートの操作を選択してください')
  if action=='矩形を作成':
   a=(n('x1'),n('y1'));b=(n('x2','200'),n('y2','150'))
   if a[0]==b[0] or a[1]==b[1]:raise ValueError('ビューポートの幅と高さを0以外にしてください')
   body=paper+f'(command-s "_.MVIEW" "_non" (list {a[0]} {a[1]}) "_non" (list {b[0]} {b[1]}))'
  elif action=='アクティブにする':body=activate()
  elif action in ('ロック','ロック解除'):
   # Resolve by viewport number in the current layout, never by overlapping pick points.
   body=paper+'(setq ss (ssget "_X" (list (cons 0 "VIEWPORT") (cons 410 (getvar "CTAB")) '+f'(cons 69 {vp()})))) '+ '(if (not ss) (error "AcadStadio: Viewport not found")) '
   body+=f'(command-s "_.MVIEW" "_Lock" "{ "_On" if action=="ロック" else "_Off"}" ss "")'
  else:
   scale=n('view_scale','1')
   if scale<=0:raise ValueError('尺度は正数にしてください')
   # Explicit viewport selection, centered pan, then paper/model custom scale.
   body=activate()+f'(command-s "_.ZOOM" "_Center" (list {n("view_x")} {n("view_y")}) "") (command-s "_.ZOOM" "{scale:.12g}XP")'
 else:raise ValueError('未対応のレイアウトコマンドです')
 return ['((lambda (/ ss) '+body+' (princ)))']
