"""Expose existing per-command appearance as explicit ordered settings commands."""
import copy
from command_types import DRAWING_TYPES, DIMENSION_TYPES
FIELDS = ('layer', 'color', 'linetype', 'linetype_scale', 'text_style', 'dim_style')

def extract_appearance(commands):
    result=[]
    for original in commands:
        command=copy.deepcopy(original)
        for branch in ('commands','else'):
            if isinstance(command.get(branch),list):
                command[branch]=extract_appearance(command[branch])
        if command.get('type') in DRAWING_TYPES:
            attrs={key:command.pop(key) for key in FIELDS if key in command}
            attrs={k:v for k,v in attrs.items() if str(v).strip()}
            if command['type'] not in ('TEXT','MTEXT'):attrs.pop('text_style',None)
            if command['type'] not in DIMENSION_TYPES:attrs.pop('dim_style',None)
            if attrs:
                result.append(dict(type='APPEARANCE', **attrs, condition=command.get('condition','')))
        result.append(command)
    return result
