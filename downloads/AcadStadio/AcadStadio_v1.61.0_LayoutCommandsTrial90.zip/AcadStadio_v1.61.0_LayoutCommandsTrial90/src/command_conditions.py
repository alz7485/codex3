"""Represent optional per-command guards explicitly as IF commands."""
import copy

def explicit_conditions(commands):
    result=[]
    for original in commands:
        command=copy.deepcopy(original)
        for branch in ('commands','else'):
            if isinstance(command.get(branch),list):command[branch]=explicit_conditions(command[branch])
        if command.get('type','').upper() not in ('IF','BLOCK'):
            condition=command.get('condition','').strip()
            if condition:
                command.pop('condition',None)
                result.append(dict(type='IF',condition=condition,commands=[command],**{'else':[]}))
                continue
        result.append(command)
    return result
