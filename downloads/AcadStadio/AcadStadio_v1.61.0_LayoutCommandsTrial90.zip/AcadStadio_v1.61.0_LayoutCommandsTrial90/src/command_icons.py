"""One bundled, cached glyph per command, shared by palette and command list."""
import tkinter as tk
from theme import ROOT


def command_icon(icons,kind):
    if kind in ('SYSVARS','SPACE','LAYOUT','VIEWPORT'):return icons.get('gear' if kind=='SYSVARS' else 'blocks')
    if kind == 'APPEARANCE':return icons.get('gear')
    key='command_'+kind.lower()
    if key not in icons.images:
        path=ROOT/'assets'/'commands'/(kind.lower()+'.png')
        if not path.is_file():return icons.get('commands')
        icons.images[key]=tk.PhotoImage(master=icons.root,file=str(path))
    return icons.images[key]
