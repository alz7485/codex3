import copy
import os
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import MacroEditor
from tkinter import ttk

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CrossBlockPointGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_prior_block_point_selection_is_staged_undoable_and_saved_with_source_ids(self):
        p=copy.deepcopy(self.app.data)
        p['blocks']=[dict(id='prior',name='前の作図',commands=[dict(type='LINE',x1='@X',y1='@Y',x2='@X+@OD',y2='@Y'),dict(type='LINE',x1='@X',y1='@Y+40',x2='@X+80',y2='@Y+40')]),dict(id='current',name='編集対象',commands=[dict(type='POINT',x='0',y='0')])]
        self.app.replace_document(p);self.root.update();original=copy.deepcopy(self.app.data)
        editor=MacroEditor(self.root,self.app.data['blocks'][1],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);editor.list.refresh(0)
        def edit_point(key,source_index,point_name,offset):
            def inspect():
                win=gui.top(self.root,'コマンドの設定')
                try:
                    win.choose_command_point(key);self.root.update()
                    dialog=gui.top(self.root,'コマンドの点を選択');v=dialog.point_preview
                    self.assertIn('前の作図',dialog.source_picker.get())
                    self.assertEqual({i['block_index'] for i in v.canvas.items},{0,1})
                    dialog.source_picker.current(source_index);dialog.source_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                    combos=[w for w in gui.descendants(dialog) if isinstance(w,ttk.Combobox)]
                    dialog.point_picker.set(point_name)
                    gui.button(dialog,'この点を使用').invoke();win.coordinate_values[key].movement.set(offset);gui.button(win,'コマンドを反映').invoke()
                except Exception as exc:self.errors.append(exc);win.destroy()
            editor.list.tree.selection_set("0")
            self.root.after(50,inspect);editor.list.edit()
        edit_point('x',1,'中点','-10')
        self.assertIn('point_id',editor.working_blocks[0]['commands'][1])
        self.assertEqual(self.app.data,original)
        self.assertIn('prior/',editor.list.commands[0]['x'])
        editor.list.undo();self.assertNotIn('point_id',editor.working_blocks[0]['commands'][1])
        editor.list.redo();self.assertIn('point_id',editor.working_blocks[0]['commands'][1])
        # Another edit after collection restore must resolve live preceding blocks.
        edit_point('y',0,'始点','0')
        self.assertIn('point_id',editor.working_blocks[0]['commands'][0])
        editor.show_preview([0]);self.assertEqual(editor.preview_canvas.items[0]['coords'],(130,100))
        editor.save();self.root.update()
        self.assertEqual(self.app.compile()[1][-1]['coords'],(130,100))
        self.app.undo_project();self.assertEqual(self.app.data,original)

    def test_cancel_does_not_modify_prior_source_commands(self):
        p=copy.deepcopy(self.app.data)
        p['blocks']=[dict(id='prior',name='前',commands=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]),dict(id='current',name='後',commands=[dict(type='POINT',x='0',y='0')])]
        self.app.replace_document(p);self.root.update();original=copy.deepcopy(self.app.data)
        editor=MacroEditor(self.root,self.app.data['blocks'][1],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);editor.list.refresh(0)
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            win.choose_command_point('x');self.root.update()
            gui.button(gui.top(self.root,'コマンドの点を選択'),'この点を使用').invoke()
            gui.button(win,'キャンセル').invoke()
        self.root.after(50,inspect);editor.list.edit()
        self.assertEqual(editor.working_blocks,original['blocks']);editor.win.destroy()
        self.assertEqual(self.app.data,original)
