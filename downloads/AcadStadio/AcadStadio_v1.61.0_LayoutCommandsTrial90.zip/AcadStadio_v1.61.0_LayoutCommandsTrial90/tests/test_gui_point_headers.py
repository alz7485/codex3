import os,sys,unittest
import test_gui as gui
from macro_editor import edit_command

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class PointHeaders(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_line_header_click_preserves_values_and_delete_removes_vertex(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                card=w.coordinate_cards['1'];self.assertEqual(card.point_caption.get(),'▼ 始点')
                card.point_heading.event_generate('<Button-1>');self.root.update()
                self.assertEqual(card.point_caption.get(),'▶ 始点')
                self.assertFalse(w.command_entries['x1'].winfo_ismapped())
                card.point_header.event_generate('<Button-1>');self.root.update()
                self.assertEqual(card.point_caption.get(),'▼ 始点')
                self.assertEqual(w.command_entries['x1'].get(),'10')
                self.assertTrue(w.command_entries['x1'].winfo_ismapped())
                self.assertEqual(str(card.point_header.cget('style')),'PointHeader.TFrame')
                w.add_vertex();self.root.update()
                card=w.coordinate_cards['1'];self.assertEqual(card.point_caption.get(),'▶ 始点')
                delete=gui.button(card.point_header,'点を削除');delete.invoke();self.root.update()
                self.assertEqual(len(w.coordinate_cards),2)
            except Exception as exc:self.errors.append(exc)
            finally:w.destroy()
        self.root.after(100,inspect)
        edit_command(self.root,dict(type='LINE',x1='10',y1='20',x2='100',y2='60'),self.app.data['blocks'],self.app.data)
        self.assertEqual(self.errors,[])
    def test_circle_center_header_has_no_collapse(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                card=w.coordinate_cards[''];self.assertEqual(card.point_caption.get(),'中心')
                card.point_heading.event_generate('<Button-1>');self.root.update()
                self.assertTrue(w.command_entries['x'].winfo_ismapped())
                self.assertFalse(hasattr(card.point_header,'set_expanded'))
            except Exception as exc:self.errors.append(exc)
            finally:w.destroy()
        self.root.after(100,inspect)
        edit_command(self.root,dict(type='CIRCLE',x='0',y='0',r='50'),self.app.data['blocks'],self.app.data)
        self.assertEqual(self.errors,[])
