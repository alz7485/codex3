"""Main-window split/join dialogs apply atomically and participate in project undo."""
import copy
import os
import sys
import unittest
import test_gui as gui
from block_model import new_block
from command_points import new_id
from engine import compile_project


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class BlockOperationsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def install(self):
        p=copy.deepcopy(self.app.data);point=new_id()
        p['blocks']=[new_block('元のブロック',commands=[dict(type='LINE',point_id=point,x1='0',y1='0',x2='100',y2='0'),
                  dict(type='POINT',x=f"点('{point}', '中点', 'X')",y='10'),dict(type='CIRCLE',x='150',y='0',r='20')])]
        self.app.replace_document(p);self.root.update();self.app.block_browser.reveal(0)
        return copy.deepcopy(self.app.data)

    def geometry(self):
        return [(i['type'],i['coords']) for i in compile_project(self.app.data,[0])[1]]

    def test_split_join_preserve_drawing_and_undo_redo(self):
        original=self.install();geometry=self.geometry()
        win=self.app.split_selected_block();self.root.update()
        win.command_table.selection_set('1');win.command_table.event_generate('<<TreeviewSelect>>');self.root.update()
        win.new_name.set('後半');win.apply_button.invoke();self.root.update()
        self.assertFalse(win.winfo_exists());self.assertEqual(len(self.app.data['blocks']),2)
        self.assertEqual(self.geometry(),geometry)
        split=copy.deepcopy(self.app.data)
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,original)
        self.app.redo_project();self.root.update();self.assertEqual(self.app.data,split)
        self.app.block_list.selection_set('0','1')
        win=self.app.join_selected_blocks();self.root.update()
        self.assertEqual(str(win.apply_button.cget('state')),'normal')
        win.new_name.set('結合後');win.apply_button.invoke();self.root.update()
        self.assertEqual(len(self.app.data['blocks']),1);self.assertEqual(self.geometry(),geometry)
        self.assertEqual(self.app.data['blocks'][0]['name'],'結合後')
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,split)
        self.assertEqual(self.messages,[])

    def test_invalid_selection_cancel_and_menu_access(self):
        original=self.install()
        labels=[self.app.block_auxiliary_menu.entrycget(i,'label') for i in range(self.app.block_auxiliary_menu.index('end')+1) if self.app.block_auxiliary_menu.type(i) not in ('separator','tearoff')]
        self.assertIn('ブロックを分割…',labels);self.assertIn('ブロックを結合…',labels)
        win=self.app.split_selected_block();win.command_table.selection_set('0');win.command_table.event_generate('<<TreeviewSelect>>');self.root.update()
        self.assertEqual(str(win.apply_button.cget('state')),'disabled')
        gui.button(win,'キャンセル').invoke();self.assertEqual(self.app.data,original)
        self.app.data['blocks'] += [new_block('2'),new_block('3')];self.app.refresh();self.root.update()
        win=self.app.join_selected_blocks();win.block_table.selection_set('0','2');win.block_table.event_generate('<<TreeviewSelect>>');self.root.update()
        self.assertEqual(str(win.apply_button.cget('state')),'disabled')
        before=copy.deepcopy(self.app.data);gui.button(win,'キャンセル').invoke();self.assertEqual(self.app.data,before)

    def editor(self):
        from macro_editor import MacroEditor
        return MacroEditor(self.root, self.app.data['blocks'][0], self.app.data['blocks'],
                           self.app.refresh, self.app.data, [0])

    def test_editor_split_commits_pending_changes_closes_and_can_undo(self):
        original=self.install();editor=self.editor();self.root.update()
        editor.name.set('編集中の名前')
        editor.list.commands.append(dict(type='POINT',x='200',y='20'))
        editor.list.refresh();editor.split_button.invoke();self.root.update()
        win=gui.top(self.root,'ブロックを分割')
        win.command_table.selection_set('2');win.command_table.event_generate('<<TreeviewSelect>>')
        win.new_name.set('分割した後半');win.apply_button.invoke();self.root.update()
        self.assertFalse(editor.win.winfo_exists())
        self.assertEqual([b['name'] for b in self.app.data['blocks']], ['編集中の名前','分割した後半'])
        self.assertEqual([len(b['commands']) for b in self.app.data['blocks']], [2,2])
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,original)
        self.assertEqual(self.errors,[])

    def test_editor_join_cancel_retains_edits_and_restores_grab_then_commit(self):
        self.install();self.app.data['blocks'].append(new_block('次のブロック',commands=[dict(type='POINT',x='250',y='0')]))
        self.app.refresh();self.root.update();original=copy.deepcopy(self.app.data)
        editor=self.editor();editor.name.set('変更した名前');self.root.update()
        editor.join_button.invoke();self.root.update()
        win=gui.top(self.root,'ブロックを結合');gui.button(win,'キャンセル').invoke();self.root.update()
        self.assertEqual(self.app.data,original)
        self.assertEqual(editor.name.get(),'変更した名前')
        self.assertEqual(self.root.grab_current(),editor.win)
        editor.join_button.invoke();self.root.update();win=gui.top(self.root,'ブロックを結合')
        win.block_table.selection_set('0','1');win.block_table.event_generate('<<TreeviewSelect>>');self.root.update()
        win.new_name.set('結合後');win.apply_button.invoke();self.root.update()
        self.assertFalse(editor.win.winfo_exists())
        self.assertEqual(len(self.app.data['blocks']),1)
        self.assertEqual(len(self.app.data['blocks'][0]['commands']),4)
        self.assertEqual(self.errors,[])
