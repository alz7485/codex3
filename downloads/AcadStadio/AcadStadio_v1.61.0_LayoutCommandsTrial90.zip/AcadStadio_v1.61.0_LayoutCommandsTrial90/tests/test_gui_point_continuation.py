import os,sys,unittest
import test_gui as gui
from macro_editor import edit_command

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class PointContinuation(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_chain_and_source_retention(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='20'),dict(type='LINE',x1='10',y1='30',x2='200',y2='40')]
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.choose_command_point('x1');self.root.update();p=w.point_panel
                p.source_picker.current(1);p.source_picker.event_generate('<<ComboboxSelected>>')
                p.point_picker.set('終点');p.point_picker.event_generate('<<ComboboxSelected>>')
                for key,axis in [('y1','Y'),('x2','X'),('y2','Y')]:
                    gui.button(w.point_panel,'この点を使用').invoke();self.root.update()
                    self.assertEqual(w.point_panel.target_key,key);self.assertEqual(w.point_panel.axis_picker.get(),axis)
                    self.assertEqual(w.point_panel.source_picker.current(),1);self.assertEqual(w.point_panel.point_picker.get(),'終点')
                gui.button(w.point_panel,'この点を使用').invoke();self.root.update()
                self.assertFalse(w.point_panel.winfo_exists());gui.button(w,'コマンドを反映').invoke()
            except Exception as e:self.errors.append(e);w.destroy()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='LINE'),self.app.data['blocks'],self.app.data,point_sources=sources)
        self.assertIsNotNone(result)
    def test_xy_advances_and_cancel_preserves_committed_point(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                for key in ('x1','y1','x2','y2'):self.assertEqual(w.command_entries[key].get(),'0')
                w.choose_command_point('x1',both=True);self.root.update()
                gui.button(w.point_panel,'この点を使用').invoke();self.root.update()
                self.assertEqual(w.point_panel.target_key,'x2');self.assertEqual(w.point_panel.axis_picker.get(),'X')
                gui.button(w.point_panel,'キャンセル').invoke();self.root.update()
                self.assertIn('点(',w.command_entries['x1'].get());self.assertEqual(w.command_entries['x2'].get(),'0')
                gui.button(w,'コマンドを反映').invoke()
            except Exception as e:self.errors.append(e);w.destroy()
        self.root.after(100,inspect)
        self.assertIsNotNone(edit_command(self.root,dict(type='LINE'),self.app.data['blocks'],self.app.data,point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]))
