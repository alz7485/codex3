import json
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class DataTree(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_folders_move_open_document_and_external_rename_follow(self):
        base=self.app.project_library.ensure_directory()
        folder=base/'案件';folder.mkdir()
        source=base/'作図.json';source.write_text(json.dumps(self.app.data))
        self.app.open_project(source);self.app.show_project_list();self.root.update()
        side=self.app.project_sidebar
        side.relocate(source,folder/source.name)
        moved=folder/source.name
        self.assertTrue(moved.exists());self.assertFalse(source.exists())
        self.assertEqual(Path(self.app.path),moved)
        self.assertIsInstance(self.app.path,str)
        self.assertEqual(side.tree.parent(str(moved)),str(folder))
        renamed=base/'名前変更';folder.rename(renamed)
        side.after_cancel(side._poll_job);side.poll_files();self.root.update()
        self.assertEqual(Path(self.app.path),renamed/source.name)
        json.dumps({"source":self.app.path})
        self.assertTrue(side.tree.exists(str(renamed)))
        with self.assertRaises(ValueError):side.relocate(renamed,renamed/'child')

    def test_create_and_recursive_delete_reflect_files(self):
        self.app.show_project_list();self.root.update();side=self.app.project_sidebar
        with patch('tkinter.simpledialog.askstring',return_value='新しい案件'):side.create_folder()
        folder=self.app.project_library.directory/'新しい案件'
        self.assertTrue(folder.is_dir())
        (folder/'one.JSON').write_text('{}');side.refresh(force=True)
        self.assertTrue(side.tree.exists(str(folder/'one.JSON')))
        side.tree.selection_set(str(folder))
        with patch('tkinter.messagebox.askyesno',return_value=True):side.delete_entry()
        self.assertFalse(folder.exists());self.assertFalse(side.tree.exists(str(folder)))

    def test_portable_data_default_import_and_outside_save_guard(self):
        from project_library import ProjectLibrary
        base=self.app.project_library.state_path.parent
        with patch('project_library.data_directory',return_value=base/'prefs'),patch.object(sys,'frozen',True,create=True),patch.object(sys,'executable',str(base/'portable'/'AcadStadio.exe')):
            self.app.project_library=ProjectLibrary()
        expected=base/'portable'/'Data'
        self.assertEqual(self.app.project_library.directory,expected)
        external=base/'external.json';external.write_text(json.dumps(self.app.data))
        self.assertTrue(self.app.open_project(external))
        self.assertEqual(Path(self.app.path).parent,expected)
        self.assertTrue(external.exists())
        outside=base/'outside.json'
        with patch('tkinter.filedialog.asksaveasfilename',return_value=str(outside)),patch('tkinter.messagebox.showerror') as error:
            self.assertFalse(self.app.save(choose_path=True))
            error.assert_called_once()
        self.assertFalse(outside.exists())

    def test_offset_table_and_variable_buttons_fill_expressions(self):
        import tkinter as tk
        from tkinter import ttk
        from macro_editor import edit_command
        source=dict(type='LINE',point_id='p_'+'7'*32,x1='@X',y1='@Y',x2='@X+10',y2='@Y')
        def interact():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.movement_entries['x1'].focus_force();self.root.update()
                def choose_table():
                    picker=gui.top(self.root,'表から参照を選ぶ')
                    tree=next(w for w in gui.descendants(picker) if isinstance(w,ttk.Treeview))
                    self.root.update();tree.tk.call(tree.heading('OD','command'))
                    self.root.update();gui.button(picker,'この参照を挿入').invoke()
                self.root.after(70,choose_table);win.movement_entries['x1'].reference_buttons[0].invoke()
                self.assertIn('@OD',win.coordinate_values['x1'].movement.get())
                win.movement_entries['x1'].focus_force();self.root.update()
                def choose_variable():
                    picker=gui.top(self.root,'変数を選択')
                    listing=next(w for w in gui.descendants(picker) if isinstance(w,tk.Listbox))
                    index=list(listing.get(0,'end')).index('変数.SCALE');listing.selection_set(index)
                    gui.button(picker,'この変数を使用').invoke()
                self.root.after(70,choose_variable);win.movement_entries['x1'].reference_buttons[1].invoke()
                self.assertEqual(win.coordinate_values['x1'].movement.get(),'変数.SCALE')
                gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(100,interact)
        self.assertIsNone(edit_command(self.root,dict(type='LINE'),self.app.data['blocks'],self.app.data,previous_blocks=[dict(id='prior',name='前のブロック',commands=[source])]))
