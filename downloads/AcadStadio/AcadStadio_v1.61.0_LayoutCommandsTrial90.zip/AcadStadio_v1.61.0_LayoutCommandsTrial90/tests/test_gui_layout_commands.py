import os,sys,unittest
import test_gui as gui
from macro_editor import edit_command

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class LayoutGui(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def edit(self,data,inspect):
  def run():
   w=gui.top(self.root,'コマンドの設定')
   try:inspect(w)
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(100,run)
  result=edit_command(self.root,data,self.app.data['blocks'],self.app.data)
  self.assertEqual(self.errors,[]);return result
 def test_space_mode_switch_changes_visible_fields_and_saves(self):
  def inspect(w):
   self.assertNotIn('layout_name',w.command_entries)
   picker=w.command_entries['space_mode'];picker.set('ビューポート内');picker.event_generate('<<ComboboxSelected>>');self.root.update()
   self.assertIn('layout_name',w.command_entries);self.assertIn('viewport_id',w.command_entries)
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit(dict(type='SPACE'),inspect);self.assertEqual(result['space_mode'],'ビューポート内')
 def test_batch_add_edit_remove_and_save(self):
  def inspect(w):
   editor=w.system_variables_editor;editor.add();self.root.update()
   editor.rows[1]['name'].set('USERR1');editor.rows[1]['value'].set('2*3')
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit(dict(type='SYSVARS'),inspect)
  self.assertEqual(len(result['items']),2);self.assertEqual(result['items'][1]['value'],'2*3')
 def test_viewport_operation_switch_hides_coordinate_boxes(self):
  def inspect(w):
   self.assertIn('x1',w.command_entries)
   picker=w.command_entries['viewport_action'];picker.set('ロック');picker.event_generate('<<ComboboxSelected>>');self.root.update()
   self.assertNotIn('x1',w.command_entries);self.assertIn('viewport_id',w.command_entries)
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit(dict(type='VIEWPORT'),inspect);self.assertEqual(result['viewport_action'],'ロック')
