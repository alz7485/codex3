"""Reference and displacement are edited in separate fields in the point card."""
import copy
import os
import sys
import unittest
import test_gui as gui
from macro_editor import edit_command
from project_data import current_table
from engine import compile_project
from coordinate_values import compose_coordinate
from unittest.mock import patch
from tkinter import ttk


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CoordinateValueGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def output(self,result,row=0,sources=()):
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[*sources,result])]
        return compile_project(p,[row])[1][-1]['coords']

    def test_direct_values_add_and_empty_reference_is_zero(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                for base,move,total in [('', '100',100),('', '',0),('100','100',200)]:
                    for entry,value in [(w.command_entries['x'],base),(w.movement_entries['x'],move)]:
                        entry.delete(0,'end');entry.insert(0,value)
                    w.refresh_command_preview();self.root.update()
                    self.assertEqual(w.command_preview.canvas.items[-1]['coords'],(total,0))
                    self.assertEqual(w.command_entries['x'].get(),base)
                    self.assertEqual(w.command_entries['x'].winfo_height(),w.movement_entries['x'].winfo_height())
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x='0',y='0'),self.app.data['blocks'],self.app.data)
        self.assertEqual(self.output(result),(200,0))
        self.assertFalse(any(k.startswith('move:') for k in result))
        def reopen():
            w=gui.top(self.root,'コマンドの設定')
            try:
                self.assertEqual(w.command_entries['x'].get(),'100');self.assertEqual(w.movement_entries['x'].get(),'100')
                gui.button(w,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(80,reopen)
        edit_command(self.root,result,self.app.data['blocks'],self.app.data)

    def test_new_reference_retains_independent_axis_displacements(self):
        source=dict(type='LINE',x1='0',y1='0',x2='100',y2='40')
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.choose_command_point('x');self.root.update();panel=w.point_panel
                self.assertFalse(hasattr(panel,'point_offsets'))
                self.assertFalse(any(isinstance(e,ttk.Entry) and not isinstance(e,ttk.Combobox) and e.winfo_ismapped() for e in gui.descendants(panel)))
                panel.point_picker.set('終点');panel.point_picker.event_generate('<<ComboboxSelected>>')
                gui.button(panel,'この点を使用').invoke();self.root.update()
                self.assertEqual(w.movement_entries['x'].get(),'10');self.assertEqual(w.movement_entries['y'].get(),'5')
                self.assertIn('終点',w.command_entries['x'].get());self.assertEqual(w.command_entries['y'].get(),'60')
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x=compose_coordinate('25','10'),y=compose_coordinate('60','5')),self.app.data['blocks'],self.app.data,point_sources=[source])
        self.assertEqual(self.output(result,sources=[source]),(110,65))

    def test_table_and_variable_values_remain_dynamic_for_each_row(self):
        self.app.data['globals']={'SHIFT':'@OD / 10'}
        current_table(self.app.data)['rows']=[{'名称':'A','OD':'100'},{'名称':'B','OD':'120'}]
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.coordinate_values['x'].base.set('@OD');w.coordinate_values['x'].movement.set('変数.SHIFT')
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x='0',y='0'),self.app.data['blocks'],self.app.data)
        self.assertEqual(self.output(result,0),(110,0));self.assertEqual(self.output(result,1),(132,0))

    def test_movement_toolbar_inserts_into_movement_and_point_button_is_disabled(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.movement_entries['x'].focus_force();self.root.update()
                self.assertTrue(w.command_entries['x'].reference_buttons[1].instate(('disabled',)))
                with patch('macro_editor.show_table_reference_picker',side_effect=lambda parent,project,*a,**kw:a[0]('@OD')):
                    w.movement_entries['x'].reference_buttons[0].invoke()
                self.assertEqual(w.movement_entries['x'].get(),'@OD');self.assertEqual(w.command_entries['x'].get(),'25')
                w.command_entries['x'].focus_force();self.root.update()
                self.assertFalse(w.command_entries['x'].reference_buttons[1].instate(('disabled',)))
                w.movement_entries['x'].focus_force();self.root.update()
                with patch('coordinate_formula_ui.show_coordinate_formulas',return_value=('100','200')):w.make_coordinate_formula('')
                self.assertEqual(w.command_entries['x'].get(),'25');self.assertEqual(w.movement_entries['y'].get(),'200')
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x='25',y='0'),self.app.data['blocks'],self.app.data)
        self.assertEqual(self.output(result),(125,200))

    def test_undo_redo_and_old_reference_offset_reopen(self):
        source=dict(type='LINE',point_id='p_'+'e'*32,x1='0',y1='0',x2='100',y2='0')
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                self.assertEqual(w.movement_entries['x'].get(),'-10')
                self.assertNotIn('-10',w.command_entries['x'].get())
                w.coordinate_values['x'].movement.set('20');w.undo_draft();self.root.update()
                self.assertEqual(w.movement_entries['x'].get(),'-10')
                w.redo_draft();self.root.update();self.assertEqual(w.movement_entries['x'].get(),'20')
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='POINT',x="点('"+source['point_id']+"', '終点', 'X') + (-10)",y='0'),self.app.data['blocks'],self.app.data,point_sources=[source])
        self.assertEqual(self.output(result,sources=[source]),(120,0))

    def test_previous_vertex_uses_final_position_including_displacement(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.coordinate_values['x1'].movement.set('100')
                w.coordinate_values['x2'].base.set('前点.X');w.coordinate_values['x2'].movement.set('100')
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='LINE',x1='0',y1='0',x2='10',y2='0'),self.app.data['blocks'],self.app.data)
        self.assertEqual(self.output(result),(100,0,200,0))

    def test_custom_xy_argument_changes_point_without_losing_existing_expression(self):
        source=dict(type='LINE',point_id='p_'+'d'*32,x1='0',y1='0',x2='100',y2='40')
        self.app.data['custom_commands']['xy_point']={'name':'座標文字列','description':'座標から点を作成','parameters':[{'name':'POSITION','kind':'text','label':'位置','default':'0,0'}],'lines':['_.POINT','{POSITION}'],'system_variables':[],'execution':'per_row'}
        original="=点位置('"+source['point_id']+"', '始点', 2, 3)"
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.choose_command_point('arg:POSITION');self.root.update();panel=w.point_panel
                self.assertFalse(hasattr(panel,'point_offsets'))
                panel.point_picker.set('終点');panel.point_picker.event_generate('<<ComboboxSelected>>')
                gui.button(panel,'この点を使用').invoke();gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(80,inspect)
        result=edit_command(self.root,dict(type='CUSTOM',name='xy_point',arguments={'POSITION':original}),self.app.data['blocks'],self.app.data,point_sources=[source])
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[source,result])]
        self.assertIn('102,43',compile_project(p,[0])[0])
