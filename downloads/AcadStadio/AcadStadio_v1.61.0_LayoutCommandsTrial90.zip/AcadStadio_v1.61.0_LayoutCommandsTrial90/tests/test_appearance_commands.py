import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from appearance_commands import extract_appearance
from sample_project import EXAMPLE
from engine import compile_project,MacroError
from project_model import validate_project

class AppearanceCommands(unittest.TestCase):
    def project(self,commands):
        p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=commands)];return p
    def test_settings_emit_no_geometry_and_following_drawings_inherit(self):
        p=self.project([dict(type='APPEARANCE',layer='OUTLINE',color='1',linetype='Continuous',linetype_scale='2',text_style='Standard',dim_style='Standard'),dict(type='CIRCLE',x='0',y='0',r='10')])
        self.assertEqual(validate_project(p),[])
        script,items=compile_project(p,[0])
        self.assertEqual(len(items),1)
        self.assertEqual(items[0]['color'],1)
        self.assertEqual(items[0]['linetype_scale'],2)
        self.assertEqual(items[0]['effective_layer'],'OUTLINE')
        for name in ('CECOLOR','CELTYPE','CELTSCALE','TEXTSTYLE'):self.assertIn(name,script)
        self.assertIn('_.-DIMSTYLE',script)
    def test_extract_preserves_geometry_and_explicit_zero_color(self):
        original=[dict(type='LINE',layer='OUTLINE',color='0',x1='0',y1='0',x2='100',y2='0')]
        changed=extract_appearance(original)
        self.assertEqual(changed[0]['color'],'0');self.assertNotIn('layer',changed[1])
        a=compile_project(self.project(original),[0])[1];b=compile_project(self.project(changed),[0])[1]
        for key in ('coords','color','effective_layer'):self.assertEqual(a[0][key],b[0][key])
        self.assertEqual(extract_appearance(changed),changed)
    def test_invalid_scale_fails_and_blank_settings_leave_current(self):
        compile_project(self.project([dict(type='APPEARANCE')]),[0])
        with self.assertRaises(MacroError):compile_project(self.project([dict(type='APPEARANCE',linetype_scale='0')]),[0])
