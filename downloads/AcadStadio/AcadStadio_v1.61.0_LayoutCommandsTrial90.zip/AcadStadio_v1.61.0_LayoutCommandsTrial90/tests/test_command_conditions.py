import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from command_conditions import explicit_conditions
from engine import compile_project
from sample_project import EXAMPLE
from command_points import new_id

class Conditions(unittest.TestCase):
    def test_conversion_preserves_true_false_results_and_identity(self):
        for condition in ('1 == 1','1 == 0'):
            command=dict(type='CIRCLE',condition=condition,x='0',y='0',r='10',point_id=new_id())
            changed=explicit_conditions([command]);self.assertEqual(changed[0]['type'],'IF')
            self.assertNotIn('condition',changed[0]['commands'][0])
            self.assertEqual(changed[0]['commands'][0]['point_id'],command['point_id'])
            p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=[command])]
            a=compile_project(p,[0])[1];p['blocks'][0]['commands']=changed;b=compile_project(p,[0])[1]
            self.assertEqual([i['coords'] for i in a],[i['coords'] for i in b])
            self.assertEqual(explicit_conditions(changed),changed)
    def test_recurses_and_preserves_block_level_condition(self):
        source=[dict(type='REPEAT',count='2',commands=[dict(type='POINT',x='0',y='0',condition='1')])]
        result=explicit_conditions(source)
        self.assertEqual(result[0]['commands'][0]['type'],'IF')
        self.assertEqual(source[0]['commands'][0]['type'],'POINT')
