import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from coordinate_values import compose_coordinate,split_coordinate
from engine import evaluate


class CoordinateValues(unittest.TestCase):
    def test_empty_reference_is_zero_and_empty_movement_is_zero(self):
        for base,movement,expected in [('', '100',100),('', '',0),('25','',25),('25','-10',15)]:
            self.assertEqual(evaluate(compose_coordinate(base,movement),{}),expected)

    def test_roundtrip_expressions_and_quoted_plus_signs(self):
        for base,move in [('@外径 / 2','変数.余裕'),("点('コマンド1', '終点', 'X')",'@幅 / 2'),("点('a+b', '始点', 'Y', 30)",'(1 + 2) * 4')]:
            self.assertEqual(split_coordinate(compose_coordinate(base,move)),(base,move))
        self.assertEqual(split_coordinate('@X + 100'),('@X + 100','0'))
        self.assertEqual(split_coordinate('前点.X + 100'),('前点.X + 100','0'))

    def test_old_point_reference_displacement_moves_to_separate_field(self):
        base,move=split_coordinate("点('コマンド1', '中点', 'X') + (-10)")
        self.assertEqual(base,"点('コマンド1', '中点', 'X')");self.assertEqual(move,'-10')

    def test_old_relation_displacement_and_nested_table_expression(self):
        base="交点('LL', 点位置('a', '始点'), 点位置('a', '終点'), 点位置('b', '始点'), 点位置('b', '終点'), '候補A', 'Y')"
        self.assertEqual(split_coordinate(base+' + (@幅 / 2)'),(base,'@幅 / 2'))
        self.assertEqual(split_coordinate(base[:-1]+', 10, 20)'),(base,'20'))

    def test_two_way_variable_sync_and_trace_cleanup(self):
        import tkinter as tk
        from coordinate_values import CoordinateValue
        master=tk.Tcl();actual=tk.StringVar(master=master,value='')
        coord=CoordinateValue(master,actual)
        self.assertEqual(actual.get(),'0');self.assertEqual(coord.base.get(),'')
        coord.base.set('100');coord.movement.set('100')
        self.assertEqual(evaluate(actual.get(),{}),200)
        actual.set(compose_coordinate('50','20'))
        self.assertEqual((coord.base.get(),coord.movement.get()),('50','20'))
        coord.close();coord.base.set('80')
        self.assertEqual(evaluate(actual.get(),{}),70)
