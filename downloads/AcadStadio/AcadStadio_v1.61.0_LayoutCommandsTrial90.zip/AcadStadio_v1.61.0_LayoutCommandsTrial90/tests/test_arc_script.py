"""ARC calls carry all three numeric points without interactive keyword states."""
import math
import sys
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from arc_modes import arc_geometry, arc_script
from test_cad_state import read_form

class ArcScript(unittest.TestCase):
    def points(self, line):
        call = read_form(line)
        self.assertEqual(call[:2], ['command-s', '_.ARC'])
        self.assertEqual(len(call), 8)
        result=[]
        for i in (2,4,6):
            self.assertEqual(call[i], '_non')
            self.assertEqual(call[i+1][0], 'list')
            result.append(tuple(float(x) for x in call[i+1][1:3]))
        return result

    def test_semicircle_quadrants_and_large_sweep(self):
        for start,sweep in [(0,180),(90,180),(350,20),(10,300),(0,-180)]:
            with self.subTest(start=start,sweep=sweep):
                points=self.points(arc_script((10,20),5,start,sweep))
                center,radius,actual_start,actual_sweep=arc_geometry('three_points',points)
                self.assertAlmostEqual(center[0],10)
                self.assertAlmostEqual(center[1],20)
                self.assertAlmostEqual(radius,5)
                self.assertAlmostEqual(actual_sweep,sweep)
                for x,y in points:self.assertAlmostEqual(math.hypot(x-10,y-20),5)

    def test_three_points_keep_original_pass_point_and_clockwise_direction(self):
        points=[(10,0),(0,-10),(-10,0)]
        args=arc_geometry('three_points',points)
        self.assertEqual(self.points(arc_script(*args, points=points)),points)

    def test_all_calls_are_single_line_and_ascii(self):
        for radius in (0.000001,1,1000000000):
            line=arc_script((0,0),radius,0,180)
            self.assertNotIn('\n',line)
            line.encode('ascii')
            self.points(line)
