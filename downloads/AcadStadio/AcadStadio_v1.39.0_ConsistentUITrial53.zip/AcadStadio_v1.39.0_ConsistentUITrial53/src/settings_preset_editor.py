from ui_icons import standard_toolbar
from table_grid import GridTreeview
"""Staged management of drawing-setting presets; selection never applies implicitly."""

import copy
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from settings_presets import (
    BUILTINS,
    SIZE_KEYS,
    entries,
    create_preset,
    apply_preset,
    validate_values,
)
from project_model import valid_name
from theme import fit_window


CURRENT = "current-settings"
SIZE_LABELS = dict(zip(SIZE_KEYS, ("文字の高さ", "寸法の文字高さ", "矢印サイズ", "寸法尺度")))


class SettingsPresetEditor:
    def __init__(self, app):
        self.app = app
        self.data = copy.deepcopy(app.data)
        self._loaded_key = None
        self._size_original = {}
        self.win = tk.Toplevel(app.root)
        self.win.title("設定プリセット")
        fit_window(self.win, 900, 700, 760, 600)
        self.win.transient(app.root)
        self.win.grab_set()
        self.win.bind("<Escape>", lambda e: self.win.destroy())
        ttk.Label(self.win, text="設定プリセット・サイズ設定", style="Section.TLabel",
                  padding=(14, 12, 14, 6)).pack(anchor="w")
        ttk.Label(self.win, text="「現在の設定」でサイズを変更できます。プリセットは選択しただけでは適用されません。",
                  style="Muted.TLabel", wraplength=720, padding=(14, 0)).pack(fill="x")
        footer = ttk.Frame(self.win, padding=14)
        footer.pack(side="bottom", fill="x")
        ttk.Button(footer, text="キャンセル", command=self.win.destroy).pack(side="left")
        ttk.Button(footer, text="保存して閉じる", command=lambda: self.commit(False)).pack(side="right", padx=(8, 0))
        ttk.Button(footer, text="選択を適用して保存", style="Primary.TButton",
                   command=lambda: self.commit(True)).pack(side="right")
        body = ttk.Frame(self.win, padding=(14, 10, 14, 0))
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body, width=220)
        left.pack(side="left", fill="y", padx=(0, 14))
        left.pack_propagate(False)
        ttk.Label(left, text="プリセット一覧", style="Section.TLabel").pack(anchor="w", pady=(0, 5))
        list_frame = ttk.Frame(left)
        list_frame.pack(fill="both", expand=True)
        self.list = GridTreeview(list_frame, columns=("kind", "name"), show="headings",
                                 height=4, selectmode="browse")
        self.list.heading("kind", text="種類"); self.list.heading("name", text="名前")
        self.list.column("kind", width=56, minwidth=48, stretch=False)
        self.list.column("name", width=145, minwidth=80)
        self.list.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(list_frame, command=self.list.yview)
        scroll.pack(side="right", fill="y"); self.list.configure(yscrollcommand=scroll.set)
        self.list.bind("<<TreeviewSelect>>", self.show_values)
        tools = ttk.Frame(left, padding=(0, 4))
        tools.pack(fill="x", pady=(0, 6), before=list_frame)
        for label, action in [("現在値から新規作成", self.new), ("複製", self.duplicate),
                              ("名前変更", self.rename), ("値を編集", self.edit), ("削除", self.delete)]:
            ttk.Button(tools, text=label, command=action).pack(side="left")
        standard_toolbar(tools)
        right = ttk.Frame(body); right.pack(side="left", fill="both", expand=True)
        self.selection_name = tk.StringVar()
        ttk.Label(right, textvariable=self.selection_name, style="Section.TLabel", width=1).pack(fill="x", pady=(0, 8))
        sizes = ttk.LabelFrame(right, text="サイズ設定", padding=10)
        sizes.pack(fill="x")
        sizes.columnconfigure(1, weight=1)
        self.size_vars = {}; self.size_entries = {}; self.current_labels = {}
        for i, key in enumerate(SIZE_KEYS):
            ttk.Label(sizes, text=SIZE_LABELS[key]).grid(row=i, column=0, sticky="w", padx=(0, 8), pady=4)
            var = tk.StringVar(); self.size_vars[key] = var
            entry = ttk.Entry(sizes, textvariable=var, width=9)
            entry.grid(row=i, column=1, sticky="ew", pady=4); self.size_entries[key] = entry
            label = ttk.Label(sizes, style="Muted.TLabel", width=12)
            label.grid(row=i, column=2, sticky="w", padx=(8, 0)); self.current_labels[key] = label
        self.size_notice = tk.StringVar()
        ttk.Label(right, textvariable=self.size_notice, style="Muted.TLabel", wraplength=460).pack(fill="x", pady=(7, 8))
        ttk.Label(right, text="その他の共通設定（右列は現在値）").pack(anchor="w", pady=(0, 4))
        frame = ttk.Frame(right); frame.pack(fill="both", expand=True)
        self.values = GridTreeview(frame, columns=("key", "saved", "current"), show="headings", height=3)
        for col, label in (("key", "設定名"), ("saved", "登録値"), ("current", "現在値")):
            self.values.heading(col, text=label); self.values.column(col, width=115, minwidth=55)
        self.values.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(frame, command=self.values.yview)
        scroll.pack(side="right", fill="y"); self.values.configure(yscrollcommand=scroll.set)
        ttk.Label(right, text="変更は保存するまで反映しません。標準は「複製」でカスタムを作れます。",
                  style="Muted.TLabel", wraplength=460).pack(fill="x", pady=(8, 0))
        from secondary_style import surface
        surface(left, border=True)
        left.configure(padding=8)
        surface(right, border=True)
        right.configure(padding=8)
        self.reload(self.data.get("active_settings_preset") or CURRENT)

    def selected(self):
        selected = self.list.selection()
        return selected[0] if selected else None

    def reload(self, key):
        self.list.delete(*self.list.get_children())
        self.list.insert("", "end", iid=CURRENT, values=("現在", "現在の設定"))
        for ident, preset in entries(self.data).items():
            self.list.insert(
                "",
                "end",
                iid=ident,
                values=("標準" if ident in BUILTINS else "カスタム", preset["name"]),
            )
        if key in self.list.get_children():
            self.list.selection_set(key)
            self.list.see(key)
        self.show_values()

    def size_target(self, key):
        if key == CURRENT:
            return self.data["settings"]
        if key in self.data.get("settings_presets", {}):
            return self.data["settings_presets"][key]["values"]
        return None

    def flush_sizes(self):
        target = self.size_target(self._loaded_key)
        if target is None:
            return True
        trial = copy.deepcopy(target)
        changed = False
        for key, variable in self.size_vars.items():
            value = variable.get().strip()
            if value == self._size_original.get(key, ""):
                continue
            changed = True
            if value:
                trial[key] = value
            else:
                if self._loaded_key == CURRENT and key in target:
                    messagebox.showerror("サイズ設定の確認", SIZE_LABELS[key] + "は正の数値にしてください。", parent=self.win)
                    return False
                trial.pop(key, None)
        if not changed:
            return True
        errors = validate_values(trial, valid_name)
        if errors:
            messagebox.showerror("サイズ設定の確認", "\n".join(errors[:10]), parent=self.win)
            return False
        if self._loaded_key == CURRENT:
            from engine import number
            for key in SIZE_KEYS:
                if key in trial and self.size_vars[key].get().strip() != self._size_original.get(key, ""):
                    trial[key] = number(str(trial[key]), {})
        target.clear(); target.update(trial)
        self._size_original = {key: variable.get().strip() for key, variable in self.size_vars.items()}
        return True

    def show_values(self, event=None):
        key = self.selected()
        if event is not None and key == self._loaded_key:
            return
        if key != self._loaded_key and not self.flush_sizes():
            if self._loaded_key and self.list.exists(self._loaded_key):
                self.list.selection_set(self._loaded_key)
            return
        self._loaded_key = key
        preset = entries(self.data).get(key, {})
        values = self.data["settings"] if key == CURRENT else preset.get("values", {})
        self.selection_name.set("現在の設定" if key == CURRENT else preset.get("name", ""))
        for name, variable in self.size_vars.items():
            variable.set(str(values.get(name, "")))
            self.size_entries[name].configure(state="readonly" if key in BUILTINS else "normal")
            self.current_labels[name].configure(text="現在: " + str(self.data["settings"].get(name, "—")))
        self._size_original = {name: var.get() for name, var in self.size_vars.items()}
        self.size_notice.set("標準のサイズは変更できません。複製して編集します。" if key in BUILTINS
                             else "サイズの変更は、保存するまで反映しません。" if key == CURRENT
                             else "空欄のサイズは、適用時に現在値を維持します。")
        self.values.delete(*self.values.get_children())
        for name, value in values.items():
            if name not in SIZE_KEYS:
                self.values.insert("", "end", values=(name, str(value), str(self.data["settings"].get(name, "未設定"))))

    def ask_name(self, initial=""):
        name = simpledialog.askstring(
            "設定プリセット名",
            "プリセット名（80文字まで）",
            initialvalue=initial,
            parent=self.win,
        )
        self.win.grab_set()
        return name

    def add(self, values, initial=""):
        name = self.ask_name(initial)
        if name is None:
            return
        try:
            key = create_preset(self.data, name, values)
        except ValueError as exc:
            return messagebox.showerror("設定プリセット", str(exc), parent=self.win)
        self.reload(key)

    def new(self):
        if self.flush_sizes():
            self.add(self.data["settings"])

    def duplicate(self):
        if not self.flush_sizes():
            return
        preset = ({"name": "現在の設定", "values": self.data["settings"]} if self.selected() == CURRENT
                  else entries(self.data).get(self.selected()))
        if preset:
            self.add(preset["values"], preset["name"] + " のコピー")

    def custom_key(self):
        key = self.selected()
        if key == CURRENT:
            return None
        if key in BUILTINS:
            messagebox.showinfo(
                "標準プリセット",
                "標準は変更できません。「複製」でカスタムを作成してください。",
                parent=self.win,
            )
            return None
        return key

    def edit(self):
        if not self.flush_sizes():
            return
        key = self.selected()
        if key != CURRENT and not self.custom_key():
            return
        target = self.size_target(key)
        if target is None:
            return
        values = self.app.edit_key_values(
            "設定プリセットの値",
            target,
            parent=self.win,
            validator=lambda data: validate_values(data, valid_name),
        )
        self.win.grab_set()
        if values is None:
            return
        errors = validate_values(values, valid_name)
        if errors:
            return messagebox.showerror(
                "設定値の確認", "\n".join(errors[:12]), parent=self.win
            )
        if key == CURRENT:
            from engine import number
            for name in SIZE_KEYS:
                if name in values:
                    values[name] = number(str(values[name]), {})
        target.clear(); target.update(values)
        self.show_values()

    def rename(self):
        if not self.flush_sizes():
            return
        key = self.custom_key()
        if not key:
            return
        preset = self.data["settings_presets"][key]
        name = self.ask_name(preset["name"])
        if name is None:
            return
        name = name.strip()
        if (
            not name
            or len(name) > 80
            or any(p["name"] == name for k, p in entries(self.data).items() if k != key)
        ):
            return messagebox.showerror(
                "名前の確認",
                "1〜80文字の重複しない名前を指定してください。",
                parent=self.win,
            )
        preset["name"] = name
        self.reload(key)

    def delete(self):
        key = self.custom_key()
        if key and messagebox.askyesno(
            "設定プリセット削除",
            "選択したカスタムを削除しますか？ 現在の設定値は維持します。",
            parent=self.win,
        ):
            del self.data["settings_presets"][key]
            if self.data.get("active_settings_preset") == key:
                self.data["active_settings_preset"] = ""
            self.reload(CURRENT)

    def commit(self, apply):
        if not self.flush_sizes():
            return
        if apply:
            key = self.selected()
            if not key:
                return
            if key != CURRENT:
                apply_preset(self.data, key)
        for key in ("settings", "settings_presets", "active_settings_preset"):
            self.app.data[key] = copy.deepcopy(self.data[key])
        self.win.destroy()
        self.app.refresh()
        self.app.status.set(
            "設定プリセットを適用しました" if apply else "設定プリセットを保存しました"
        )
