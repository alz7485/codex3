from table_grid import GridTreeview
"""Clickable inspection results; navigation never changes drawing scope."""

import tkinter as tk
import copy
from tkinter import ttk
from audit import audit_details
from theme import fit_window


class InspectionWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.title("プロジェクトの検査")
        fit_window(self, 960, 600, 700, 450)
        self.transient(app.root)
        self.heading = tk.StringVar()
        ttk.Label(
            self, textvariable=self.heading, style="Section.TLabel", padding=14
        ).pack(anchor="w")
        frame = ttk.Frame(self, padding=(14, 0))
        frame.pack(fill="both", expand=True)
        self.tree = GridTreeview(
            frame, columns=("message",), show="headings", selectmode="browse"
        )
        self.tree.heading("message", text="問題（クリックすると該当箇所へ移動）")
        self.tree.column("message", width=1100, stretch=False)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(frame, command=self.tree.yview)
        xs = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        ys.grid(row=0, column=1, sticky="ns")
        xs.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.detail = tk.StringVar()
        ttk.Label(self, textvariable=self.detail, wraplength=880, padding=14).pack(
            fill="x"
        )
        ttk.Label(
            self,
            text="未実行の分岐も構文を検査します。行の値による計算エラーは実行される分岐で検出します。",
            style="Muted.TLabel",
            padding=(14, 0),
        ).pack(anchor="w")
        bar = ttk.Frame(self, padding=14)
        bar.pack(fill="x", before=frame)
        ttk.Button(bar, text="再検査", command=self.refresh).pack(side="left")
        footer = ttk.Frame(self, padding=14)
        footer.pack(side="bottom", fill="x")
        ttk.Button(footer, text="閉じる", command=self.destroy).pack(side="right")
        self.tree.bind("<<TreeviewSelect>>", self.jump)
        self.bind("<Escape>", lambda e: self.destroy())
        from secondary_style import surface
        surface(frame, border=True)
        self.refresh()

    def refresh(self):
        self.snapshot = copy.deepcopy(self.app.data)
        self.records = audit_details(self.app.data)
        self.tree.delete(*self.tree.get_children())
        for i, record in enumerate(self.records):
            self.tree.insert("", "end", iid=str(i), values=(record["message"],))
        self.heading.set(
            f"検出した問題: {len(self.records)}件"
            if self.records
            else "全入力表・式・ブロック参照の検査を通過しました"
        )
        self.detail.set(
            "問題を選ぶと行・プリセット・コマンドを表示します。修正後は再検査してください。"
            if self.records
            else "問題は検出されませんでした。"
        )

    def jump(self, event=None):
        selection = self.tree.selection()
        if selection:
            if self.snapshot != self.app.data:
                self.detail.set(
                    "検査後に内容が変更されています。再検査して最新の問題を表示してください。"
                )
                return
            record = self.records[int(selection[0])]
            self.detail.set(record["message"])
            self.app.navigate_issue(record)
            self.snapshot["active_table"] = self.app.data.get("active_table")
