from guide_blocks import confirm_reference_order
from table_grid import GridTreeview
from formula_grid import FormulaGridTreeview
"""AcadStadio — a local, row-driven AutoCAD script workbench."""

import copy
import json
import re
import uuid
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from pathlib import Path
from project_safety import atomic_save, atomic_write_script, details
from project_model import (normalize_sequential_project as normalize_project, valid_name,
                           valid_variable_name, validate_sequential_project as validate_project)
from project_data import (
    current_table,
    get_rows,
    target_settings,
    add_input_table,
    unique_table_name,
    parse_row_number,
    row_title,
    default_target,
)
from engine import compile_project, MacroError, RowResolver, convert, evaluate
from macro_editor import MacroEditor
from catalog_editor import CommandCatalogManager
from settings_preset_editor import SettingsPresetEditor
from settings_presets import active_label
from project_library import ProjectLibrary, canonical
from project_sidebar import ProjectSidebar
from cad_setup import default_setup
from cad_setup_editor import CadSetupEditor
from project_navigator import ProjectNavigator
from preview import DrawingCanvas
from theme import apply_theme, fit_window, APP_NAME, APP_VERSION, ROOT
from sample_project import EXAMPLE
from table_io import read_csv, read_excel, sheet_names
from table_edit import TableEditor
from workspace_state import WorkspaceState
from ui_icons import IconTheme, layout_icon_toolbar
from block_model import new_block
from block_browser import BlockBrowser
from table_references import rename_project_table_references
from preview_row_ui import PreviewRowControls
from table_formulas import computed_columns, check_cell_input, display_formula

EMPTY = {
    "version": 11,
    "cad_setup": default_setup(),
    "settings": {"TEXT_HEIGHT": "3.5"},
    "globals": {},
    "rows": [],
    "blocks": [],
}


class MainCard(ttk.Frame):
    """Compact white panel with its heading inside the border."""
    def __init__(self, parent, text, **kwargs):
        kwargs.pop('padding', None)
        kwargs.pop('style', None)
        super().__init__(parent, padding=(6, 32, 6, 6), style='MainCard.TFrame', **kwargs)
        ttk.Label(self, text=text, style='MainCardTitle.TLabel').place(x=3, y=-27)


class App:
    def __init__(self, root, *, library_state_path=None):
        self.root = root
        self.face = apply_theme(root)
        self.icons = IconTheme(root)
        root.title(APP_NAME)
        fit_window(root, 1320, 840, 1040, 680)
        self.project_library = ProjectLibrary(library_state_path)
        self.workspace_state = WorkspaceState(self.project_library.state_path.parent)
        self._session_job = None
        self._startup_job = None
        self._draft_id = uuid.uuid4().hex
        self._recoveries = self.workspace_state.recoveries()
        self._recovery = self._recoveries[0] if self._recoveries else None
        self.project_window = None
        self.project_sidebar = None
        self.data = normalize_project(EXAMPLE)
        self.path = None
        self.document_name = "サンプルプロジェクト"
        self.navigator = None
        self._history = []
        self._future = []
        self._history_limit = 100
        self._restoring = False
        self._observed = copy.deepcopy(self.data)
        self._saved = copy.deepcopy(self.data)
        self._preview_job = None
        self.command_diagnostics = []
        self._syncing_options = False
        self._rendered_table_id = None
        self._table_selections = {}
        self._preview_row_selection = None
        self._target_controls = []
        self.status = tk.StringVar(
            value="サンプルを表示しています。行やブロックを編集して試せます。"
        )
        if self.project_library.warning:
            self.status.set(self.project_library.warning)
        self.document_status = tk.StringVar()
        self.selection_status = tk.StringVar()
        self.drawing_selection_summary = tk.StringVar()
        self.preview_status = tk.StringVar()
        self.highlight_enabled = tk.BooleanVar(value=True)
        self.drawing_summary = tk.StringVar()
        self.scope = tk.StringVar(value="selected")
        self.encoding = tk.StringVar(value="cp932")
        self.table_choice = tk.StringVar()
        self.table_heading = tk.StringVar(value="入力表")
        self.row_range = tk.StringVar()
        self.settings_summary = tk.StringVar()
        self.settings_preset_summary = tk.StringVar()
        root.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.build_menu()
        for key, action in [
            ("<Control-n>", self.new),
            ("<Control-o>", self.load),
            ("<Control-s>", self.save),
            ("<Control-z>", self.undo_project),
            ("<Control-y>", self.redo_project),
            ("<Control-e>", self.export),
            ("<F5>", self.preview),
            ("<F1>", self.show_help),
        ]:
            root.bind(key, lambda e, fn=action: self.shortcut(e, fn))
        header = ttk.Frame(root, padding=(18, 6))
        header.pack(fill="x")
        actions = ttk.Frame(header)
        actions.pack(side="right")
        for label, fn in [
            ("開く", self.load),
            ("保存", self.save),
            ("プロジェクトを検査", self.audit),
        ]:
            ttk.Button(actions, text=label, command=fn, style="Compact.TButton").pack(side="left", padx=4)
        ttk.Button(actions, text="SCRを表示", command=self.show_script, style="Compact.TButton").pack(side="left", padx=4)
        ttk.Button(
            actions, text="SCRを書き出す", style="Compact.Primary.TButton", command=self.export
        ).pack(side="left", padx=(10, 0))
        self.recovery_banner = ttk.Frame(root, padding=(20, 6))
        if self._recovery:
            self.recovery_banner.pack(fill="x")
        ttk.Label(
            self.recovery_banner,
            text="前回の未保存データがあります。",
            style="Section.TLabel",
        ).pack(side="left")
        self.recovery_choice = ttk.Combobox(
            self.recovery_banner,
            state="readonly",
            width=24,
            values=[
                f"{i + 1}. {d.get('name', 'プロジェクト')}"
                for i, d in enumerate(self._recoveries)
            ],
        )
        self.recovery_choice.pack(side="left", padx=8)
        if self._recoveries:
            self.recovery_choice.current(0)
        self.recovery_choice.bind(
            "<<ComboboxSelected>>",
            lambda e: setattr(
                self, "_recovery", self._recoveries[self.recovery_choice.current()]
            ),
        )
        ttk.Button(
            self.recovery_banner, text="内容を復元", command=self.restore_recovery
        ).pack(side="left", padx=8)
        ttk.Button(
            self.recovery_banner, text="破棄", command=self.discard_recovery
        ).pack(side="left")
        project_button = ttk.Button(header, text="プロジェクト一覧…", command=self.show_project_list)
        project_button.icon_only = True
        project_button.pack(side="left", padx=(0, 10))
        ttk.Label(
            header, textvariable=self.document_status, style="Section.TLabel", width=1
        ).pack(side="left", fill="x", expand=True, padx=(0, 12))
        for label, action in (("元に戻す", self.undo_project), ("やり直し", self.redo_project)):
            ttk.Button(header, text=label, command=action, style="Compact.TButton").pack(side="left", padx=2)
        workspace = ttk.Frame(root)
        body = workspace
        workspace.pack(fill="both", expand=True, padx=(18, 0), pady=0)
        self.drawing_page = ttk.Frame(workspace, padding=0)
        self.drawing_page.pack(fill="both", expand=True)
        self.input_window = tk.Toplevel(root)
        self.input_window.withdraw()
        self.input_window.title("入力表 — " + APP_NAME)
        fit_window(self.input_window, 1120, 680, 780, 460)
        self.input_window.protocol("WM_DELETE_WINDOW", self.hide_input_table)
        self.input_window.bind("<Escape>", lambda e: self.hide_input_table())
        for key, action in [
            ("<Control-s>", self.save),
            ("<Control-z>", self.undo_project),
            ("<Control-y>", self.redo_project),
            ("<F5>", self.preview),
        ]:
            self.input_window.bind(key, lambda e, fn=action: self.shortcut(e, fn))
        self.input_page = ttk.Frame(self.input_window, padding=12)
        self.input_page.pack(fill="both", expand=True)
        panes = ttk.Panedwindow(self.drawing_page, orient="horizontal")
        self.drawing_panes = panes
        panes.pack(fill="both", expand=True)
        blocks_frame = ttk.Frame(panes, width=370, padding=(0, 0, 12, 0))
        blocks_frame.pack_propagate(False)
        right = ttk.Frame(panes)
        panes.add(blocks_frame, weight=0)
        panes.add(right, weight=1)

        def initialize_sash(event):
            if event.width > 700 and not getattr(panes, "_sash_initialized", False):
                panes._sash_initialized = True
                panes.sashpos(0, 370)

        panes.bind("<Configure>", initialize_sash)
        sourcebar = self.sourcebar = ttk.Frame(blocks_frame)
        sourcebar.pack(fill="x", pady=(0, 8))
        self.settings_group = MainCard(sourcebar, text="設定")
        self.settings_group.pack(fill="x", pady=(0, 6))
        self.settings_buttons = []
        for label, action in [
            ("CAD設定", self.edit_cad_setup),
            ("プリセット", self.manage_settings_presets),
        ]:
            button = ttk.Button(self.settings_group, text=label, command=action, style="Compact.TButton")
            button.pack(side="left", expand=True, fill="x", padx=2)
            self.settings_buttons.append(button)

        def adapt_settings_buttons(event):
            compact = event.width < 330
            for button in self.settings_buttons:
                button.configure(compound="none" if compact else "left", width=2 if compact else -1)

        self.settings_group.bind("<Configure>", adapt_settings_buttons)
        self.table_group = MainCard(sourcebar, text="入力表")
        self.table_group.pack(fill="x")
        pickerbar = ttk.Frame(self.table_group)
        pickerbar.pack(fill="x")
        ttk.Button(pickerbar, text="表一覧…", command=self.show_input_table,
                   style="Compact.TButton").pack(side="left", padx=(0, 6))
        self.drawing_table_picker = ttk.Combobox(
            pickerbar, textvariable=self.table_choice, state="readonly", width=16
        )
        self.drawing_table_picker.pack(side="left", fill="x", expand=True)
        self.drawing_table_picker.bind(
            "<<ComboboxSelected>>", lambda e: self.switch_table_by_name()
        )
        self.preview_row_controls = PreviewRowControls(self.table_group, self)
        self.preview_row_controls.pack(fill="x", pady=(5, 0))
        rowhead = ttk.Frame(self.input_page)
        rowhead.pack(fill="x", pady=(0, 8))
        ttk.Label(
            rowhead, textvariable=self.table_heading, style="Section.TLabel"
        ).pack(side="left")
        ttk.Button(rowhead, text="閉じる", command=self.hide_input_table).pack(
            side="right"
        )
        table_body = ttk.Frame(self.input_page)
        table_body.pack(fill="both", expand=True)
        self.table_list_frame = ttk.Frame(table_body, width=200, padding=(0, 0, 12, 0))
        self.table_list_frame.pack(side="left", fill="y")
        self.table_list_frame.pack_propagate(False)
        list_frame = ttk.Frame(self.table_list_frame)
        list_frame.pack(fill="both", expand=True)
        list_frame.rowconfigure(0, weight=1)
        list_frame.columnconfigure(0, weight=1)
        self.table_list = GridTreeview(
            list_frame, columns=("name",), show="headings", selectmode="browse", height=4
        )
        self.table_list.heading("name", text="入力表一覧")
        self.table_list.column("name", width=160, minwidth=100, anchor="w")
        self.table_list.grid(row=0, column=0, sticky="nsew")
        list_scroll = ttk.Scrollbar(list_frame, command=self.table_list.yview)
        list_scroll.grid(row=0, column=1, sticky="ns")
        self.table_list.configure(yscrollcommand=list_scroll.set)
        self.table_list.bind("<<TreeviewSelect>>", self.on_table_list_selection)
        self.table_list.bind("<F2>", lambda e: self.rename_table())
        self.table_actions = ttk.Frame(self.table_list_frame)
        self.table_actions.pack(fill="x", pady=(0, 6), before=list_frame)
        for labels in [
            [("表を追加", self.new_table), ("名前を変更", self.rename_table),
             ("複製", self.duplicate_table), ("削除", self.delete_table)],
            [("表を読込", self.import_table), ("表を置換", self.replace_table_file)],
        ]:
            tools = ttk.Frame(self.table_actions, padding=(0, 4))
            tools.pack(fill="x")
            for label, fn in labels:
                ttk.Button(tools, text=label, command=fn).pack(side="left")
            tools.bind("<Configure>", lambda e, bar=tools: layout_icon_toolbar(bar, e.width))
        rows_frame = ttk.Frame(table_body)
        rows_frame.pack(side="left", fill="both", expand=True)
        tablebar = ttk.Frame(rows_frame)
        tablebar.pack(fill="x", pady=(0, 6))
        ttk.Label(
            tablebar, textvariable=self.table_choice, style="Section.TLabel", width=1
        ).pack(side="left", fill="x", expand=True)
        ttk.Label(
            tablebar, text="式は1行目／ƒ列は自動計算", style="Muted.TLabel"
        ).pack(side="right", padx=(8, 0))
        targets_bar = ttk.Frame(rows_frame)
        targets_bar.pack(fill="x", pady=(0, 6))
        for label, fn in [("すべてチェック", lambda: self.set_input_checks(range(len(self.rows)))),
                          ("すべて外す", lambda: self.set_input_checks([]))]:
            ttk.Button(targets_bar, text=label, command=fn, style="Compact.TButton").pack(side="left", padx=(0, 4))
        ttk.Label(targets_bar, textvariable=self.drawing_selection_summary, style="Muted.TLabel").pack(side="right")
        frame = ttk.Frame(rows_frame)
        self.row_table_container = frame
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.table = FormulaGridTreeview(
            frame, show="tree headings", selectmode="extended", height=4
        )
        self.table.heading("#0", text="作図", command=self.toggle_all_drawing_rows)
        self.table.column("#0", width=48, minwidth=48, stretch=False, anchor="center")
        self.table.bind("<Button-1>", self.on_drawing_check)
        self.table.bind("<space>", self.toggle_selected_drawing_rows)
        self.table.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(frame, command=self.table.yview)
        ys.grid(row=0, column=1, sticky="ns")
        xs = ttk.Scrollbar(frame, orient="horizontal", command=self.table.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.table.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        self.table_editor = TableEditor(self)
        self.table.bind("<Return>", lambda e: self.edit_row())
        self.table.bind("<<TreeviewSelect>>", self.on_row_selection)
        self.table.bind(
            "<Control-a>",
            lambda e: (self.table.selection_set(self.table.get_children()), "break")[
                -1
            ],
        )
        rowtools = ttk.Frame(rows_frame, padding=(0, 4))
        self.input_row_tools = rowtools
        rowtools.pack(fill="x", pady=(0, 6), before=targets_bar)
        for label, fn in [
            ("行を追加", self.add_row),
            ("編集", self.edit_row),
            ("複製", self.duplicate_rows),
            ("削除", self.del_row),
        ]:
            ttk.Button(rowtools, text=label, command=fn).pack(side="left", padx=(0, 4))
        rowtools.bind("<Configure>", lambda e: layout_icon_toolbar(rowtools, e.width))
        formulas_button = ttk.Menubutton(rowtools, text="式・変数 ▾")
        formulas_button.pack(side="left", padx=6)
        self.table_editor.formula_menu = tk.Menu(
            formulas_button, tearoff=False, postcommand=self.table_editor.prepare_formula_menu
        )
        formulas_button.configure(menu=self.table_editor.formula_menu)
        ttk.Label(
            rows_frame, textvariable=self.selection_status, style="Muted.TLabel"
        ).pack(side="bottom", anchor="w", pady=(0, 5), before=rowtools)
        self.block_panel = MainCard(blocks_frame, text="ブロック一覧")
        self.block_panel.pack(fill="both", expand=True)
        frame = self.block_panel
        self.block_table_container = frame
        frame.rowconfigure(1, weight=1)
        frame.columnconfigure(0, weight=1)
        ptools = self.block_actions = ttk.Frame(frame, padding=(0, 4))
        ptools.grid(row=0, column=0, sticky="ew")
        for label, fn in [
            ("ブロック追加", self.add_block),
            ("フォルダ追加", lambda: self.block_browser.new_folder("")),
            ("編集", self.edit_block),
            ("↑", lambda: self.move_block(-1)),
            ("↓", lambda: self.move_block(1)),
            ("削除", self.del_block),
        ]:
            if label == "↑":
                ttk.Separator(ptools, orient='vertical').pack(side='left', fill='y', padx=(2, 4), pady=3)
            button = ttk.Button(ptools, text=label, command=fn, width=2, style="Compact.TButton")
            button.icon_only = True
            button.icon_button_width = 2
            button.icon_button_style = "MainIcon.TButton"
            button.pack(side="left", fill="y", padx=(0, 2))
        ttk.Separator(ptools, orient='vertical').pack(side='left', fill='y', padx=(2, 4), pady=3)
        self.block_browser = BlockBrowser(
            frame, lambda: self.data, self.refresh, icons=self.icons,
            on_preview_changed=self.update_preview_display, actions_parent=ptools,
        )
        self.block_browser.grid(row=1, column=0, sticky="nsew")
        self.block_list = self.block_browser.tree
        self.block_list.bind("<Double-1>", self.activate_block, add="+")
        self.block_list.bind("<Return>", self.activate_block, add="+")
        self.block_list.bind("<<TreeviewSelect>>", self.on_block_selection)
        self.block_list.bind(
            "<Escape>",
            lambda e: self.block_list.selection_remove(self.block_list.selection()),
        )
        self.block_browser.visibility_button.pack_configure(fill="y", padx=(0, 2))
        self.block_auxiliary_menu = tk.Menu(ptools, tearoff=False)
        for label, fn in [
            ("登録コマンド", self.manage_custom_commands),
            ("変数", self.edit_globals),
            ("構成ツリー", self.open_navigator),
        ]:
            self.block_auxiliary_menu.add_command(label=label, command=fn)
        self.block_more_button = ttk.Menubutton(ptools, text='…', width=2,
            style='MainIcon.TMenubutton', menu=self.block_auxiliary_menu)
        self.block_more_button.pack(side='left', fill='y', padx=(0, 2))

        def adapt_block_actions(event):
            layout_icon_toolbar(ptools, event.width)
            for control in ptools.winfo_children():
                if isinstance(control, (ttk.Button, ttk.Menubutton)):
                    control.icon_button_style = "Main51." + str(control.cget("style"))
                    control.configure(style=control.icon_button_style)

        ptools.bind("<Configure>", adapt_block_actions)
        self.preview_panel = ttk.Frame(right)
        self.preview_panel.pack(fill="both", expand=True)
        canvaspage = self.preview_panel
        self.script_window = None
        self.script = None
        self._script_text = ""
        self.canvas = DrawingCanvas(canvaspage, workspace=True)
        self.canvas.pack(fill="both", expand=True)
        foot = ttk.Frame(self.canvas, padding=4, style="Preview.TFrame")
        foot.place(relx=1, rely=1, x=-12, y=-10, anchor="se")
        self.preview_controls = foot
        self.canvas.set_overlay_controls(foot)
        self.actual_color_toggle = self.canvas.make_color_toggle(foot)
        self.actual_color_toggle.pack(side="left", padx=3)
        highlight = ttk.Checkbutton(foot, text="選択を強調", variable=self.highlight_enabled,
                                    command=self.highlight_preview, style="Preview.Toggle.Toolbutton")
        highlight.icon_button_style = "Preview.Toggle.Toolbutton"
        highlight.icon_white = True
        highlight.pack(side="left", padx=3)
        for label, action in (("再生成  F5", self.preview), ("全体を表示", self.canvas.fit)):
            button = ttk.Button(foot, text=label, command=action, style="Preview.Primary.TButton")
            button.icon_button_style = "Preview.Primary.TButton"
            button.icon_white = True
            button.pack(side="left", padx=3)
        statusbar = ttk.Frame(root, padding=(18, 4))
        statusbar.pack(side="bottom", fill="x", before=body)
        self.preview_metrics = tk.StringVar(value="図面単位")
        ttk.Label(statusbar, textvariable=self.preview_metrics, style="Muted.TLabel").pack(side="right", padx=(12, 0))
        status_label = ttk.Label(statusbar, textvariable=self.status, width=1)
        status_label.pack(side="left", fill="x", expand=True)
        status_label.bind("<Configure>", lambda e: status_label.configure(wraplength=max(100, e.width)))
        self.scope.trace_add("write", self.update_drawing_options)
        self.row_range.trace_add("write", self.update_drawing_options)
        def white_panel(widget):
            for child in widget.winfo_children():
                if isinstance(child, ttk.Frame) and not isinstance(child, MainCard):
                    child.configure(style='MainInner.TFrame')
                elif isinstance(child, ttk.Label) and str(child.cget('style')) != 'MainCardTitle.TLabel':
                    child.configure(style='MainMuted.TLabel' if 'Muted' in str(child.cget('style')) else 'MainInner.TLabel')
                white_panel(child)
        for card in (self.settings_group, self.table_group, self.block_panel):
            white_panel(card)
        self.preview_row_controls.title_label.configure(style='PreviewRowTitle.TLabel')
        self.block_auxiliary_menu.add_separator()
        self.block_auxiliary_menu.add_command(label='作図対象をプレビューに表示', command=self.preview_row_controls.reset)
        from secondary_style import surface
        surface(self.input_page, border=True)
        self.refresh()
        self.queue_preview()
        root.bind("<Destroy>", self.cleanup_jobs, add="+")
        self._startup_job = root.after_idle(self.restore_workspace)
        self._session_job = root.after(15000, self.autosave_workspace)

    def build_menu(self):
        menu = tk.Menu(self.root)
        self.root.configure(menu=menu)

        def group(label, items):
            sub = tk.Menu(menu, tearoff=False)
            menu.add_cascade(label=label, menu=sub)
            for name, fn in items:
                if name is None:
                    sub.add_separator()
                else:
                    sub.add_command(label=name, command=fn)

        group(
            "ファイル",
            [
                ("プロジェクト一覧…", self.show_project_list),
                ("新規プロジェクト  Ctrl+N", self.new),
                ("サンプルを開く", self.load_sample),
                ("開く…  Ctrl+O", self.load),
                ("保存  Ctrl+S", self.save),
                ("名前を付けて保存…", self.save_as),
                (None, None),
                ("表を読み込む…", self.import_table),
                ("SCR出力…  Ctrl+E", self.export),
                (None, None),
                ("終了", self.on_exit),
            ],
        )
        group(
            "編集",
            [
                ("元に戻す  Ctrl+Z", self.undo_project),
                ("やり直し  Ctrl+Y", self.redo_project),
                ("保存済みとの変更を表示", self.show_changes),
            ],
        )
        group(
            "プロジェクト",
            [
                ("設定プリセット・サイズ", self.edit_settings),
                ("変数", self.edit_globals),
                ("ユーザーコマンド登録", self.manage_custom_commands),
                ("構成ツリー", self.open_navigator),
                ("参照式一覧", self.reference_help),
                ("全行を検査", self.audit),
            ],
        )
        group(
            "ヘルプ",
            [
                ("使い方  F1", self.show_help),
                (
                    "このアプリについて",
                    lambda: messagebox.showinfo(
                        APP_NAME,
                        f"{APP_NAME} {APP_VERSION}\n旧名称: CADFlow Studio / CADScriptMaker\n\n表の値からAutoCADのSCRを作成するローカルアプリです。\nAutoCADを自動操作する機能はありません。",
                        parent=self.root,
                    ),
                ),
            ],
        )

    def shortcut(self, event, action):
        # Text entries keep their own undo. Modal editors own their shortcuts.
        if self.root.grab_current() is not None:
            return
        if action in (self.undo_project, self.redo_project) and isinstance(
            event.widget, (tk.Text, tk.Entry, ttk.Entry, ttk.Combobox)
        ):
            return
        action()
        return "break"

    def _checkpoint(self):
        if self._restoring or self.data == self._observed:
            return False
        self._history.append(copy.deepcopy(self._observed))
        del self._history[: -self._history_limit]
        self._future.clear()
        self._observed = copy.deepcopy(self.data)
        return True

    def _restore(self, target):
        self._restoring = True
        try:
            self.close_navigator()
            self.data = copy.deepcopy(target)
            self._observed = copy.deepcopy(self.data)
            self.refresh()
        finally:
            self._restoring = False

    def undo_project(self):
        self._checkpoint()
        if self._history:
            self._future.append(copy.deepcopy(self.data))
            self._restore(self._history.pop())
            self.status.set("変更を元に戻しました")

    def redo_project(self):
        self._checkpoint()
        if self._future:
            self._history.append(copy.deepcopy(self.data))
            self._restore(self._future.pop())
            self.status.set("変更をやり直しました")

    def refresh(self):
        self.capture_selection()
        self._checkpoint()
        target = target_settings(self.data)
        target["selected"] = [i for i in target["selected"] if i < len(self.rows)]
        rows = [i for i in self._table_selections.get(self.data["active_table"], target["selected"]) if i < len(self.rows)]
        self._syncing_options = True
        self.table_heading.set(f"入力表（{len(self.data['input_tables'])}個）")
        self.drawing_table_picker["values"] = [t["name"] for t in self.data["input_tables"]]
        self.table_list.delete(*self.table_list.get_children())
        for i, table in enumerate(self.data["input_tables"]):
            self.table_list.insert(
                "", "end", iid=table["id"], values=(table["name"],),
                tags=("alternate",) if i % 2 else (),
            )
        self.table_list.tag_configure("alternate", background="#f5f8fc")
        self.table_list.selection_set(self.data["active_table"])
        self.table_list.focus(self.data["active_table"])
        self.table_list.see(self.data["active_table"])
        self.table_choice.set(current_table(self.data)["name"])
        self.scope.set(target["mode"])
        self.row_range.set(target["range"] if target["mode"] == "range" else target["range"] or "1")
        self.settings_summary.set(
            "文字高 "
            + str(self.data["settings"].get("TEXT_HEIGHT", "未設定"))
            + " / 寸法尺度 "
            + str(self.data["settings"].get("DIM_SCALE", "図面設定"))
        )
        self.settings_preset_summary.set("設定プリセット: " + active_label(self.data))
        self._syncing_options = False
        keys = list(dict.fromkeys(k for row in self.rows for k in row))
        table_data = current_table(self.data)
        formulas = computed_columns(table_data, keys)
        resolver = RowResolver(self.data, convert, evaluate, MacroError) if formulas else None
        self.table["columns"] = ["#row-number"] + keys
        self.table.heading("#row-number", text="行")
        self.table.column(
            "#row-number", width=42, minwidth=42, stretch=False, anchor="center"
        )
        for key in keys:
            self.table.heading(key, text=key + (" ƒ" if key in formulas else ""))
            self.table.column(
                key, width=140 if key in formulas else 68, minwidth=60, stretch=False, anchor="center"
            )
        self.table.delete(*self.table.get_children())
        self.table.set_formulas({key: display_formula(table_data["rows"][0][key], table_data) for key in formulas})
        try:
            checked_rows = set(self.target_rows()) if self.rows else set()
        except ValueError:
            checked_rows = set()
        for i, row in enumerate(self.rows):
            cells = []
            for key in keys:
                value = row.get(key, "")
                if key in formulas:
                    try:
                        value = resolver.cell(table_data["name"], i, key)
                        if type(value) in (int, float):
                            value = format(value, ".12g")
                    except MacroError:
                        value = "計算エラー"
                cells.append(value)
            self.table.insert(
                "",
                "end",
                iid=str(i),
                text="☑" if i in checked_rows else "☐",
                values=[i + 1] + cells,
                tags=("alternate",) if i % 2 else (),
            )
        self.table.tag_configure("alternate", background="#f5f8fc")
        self.table.selection_set([str(i) for i in rows if i < len(self.rows)])
        self.block_browser.refresh(self.data)
        self._rendered_table_id = self.data["active_table"]
        self.update_title()
        if self.navigator and self.navigator.winfo_exists():
            self.navigator.refresh()
        self.update_drawing_summary()
        manager = getattr(self, "target_table_controls", None)
        if manager is not None and manager.winfo_exists():
            manager.refresh()
        self.queue_preview()

    def update_title(self):
        dirty = " • 未保存の変更" if self.has_unsaved_changes() else ""
        name = Path(self.path).name if self.path else self.document_name
        self.document_status.set(name + dirty)
        self.root.title(f"{'* ' if dirty else ''}{name} — {APP_NAME}")
        self.input_window.title(f"入力表 — {name} — {APP_NAME}")
        if self.project_sidebar is not None:
            self.project_sidebar.refresh()

    def show_project_list(self):
        modal = self.root.grab_current()
        if modal is not None:
            modal.winfo_toplevel().lift()
            return None
        if self.project_window is None or not self.project_window.winfo_exists():
            win = tk.Toplevel(self.root)
            self.project_window = win
            win.title("プロジェクト一覧 — " + APP_NAME)
            fit_window(win, 640, 720, 480, 560)
            win.transient(self.root)
            win.protocol("WM_DELETE_WINDOW", win.withdraw)
            win.bind("<Escape>", lambda e: win.withdraw())
            footer = ttk.Frame(win, padding=(14, 0, 14, 14))
            footer.pack(side="bottom", fill="x")
            ttk.Button(footer, text="閉じる", command=win.withdraw).pack(side="right")
            self.project_sidebar = ProjectSidebar(win, self)
            self.project_sidebar.pack(fill="both", expand=True, padx=14, pady=14)
        self.project_sidebar.refresh(force=True)
        current = canonical(self.path) if self.path else "unsaved"
        if self.project_sidebar.tree.exists(current):
            self.project_sidebar.tree.selection_set(current)
            self.project_sidebar.tree.see(current)
        self.project_window.deiconify()
        self.project_window.lift()
        self.project_sidebar.search.focus_set()
        return self.project_window

    @property
    def rows(self):
        return get_rows(self.data)

    def capture_selection(self):
        if self._rendered_table_id == self.data["active_table"] and not self._restoring:
            selected = [i for i in self.selected_rows() if i < len(self.rows)]
            self._table_selections[self.data["active_table"]] = selected

    def on_row_selection(self, event=None):
        if self._syncing_options:
            return
        self.capture_selection()
        if self.input_window.winfo_ismapped():
            selected = self.selected_rows()
            self._preview_row_selection = (
                (self.data["active_table"], selected) if selected else None
            )
        self._checkpoint()
        self.update_title()
        self.highlight_preview()
        self.update_drawing_summary()
        self.queue_preview()

    def update_drawing_options(self, *_):
        if self._syncing_options:
            return
        self._preview_row_selection = None
        target = target_settings(self.data)
        target["mode"] = self.scope.get()
        target["range"] = self.row_range.get()
        manager = getattr(self, "target_table_controls", None)
        if manager is not None and manager.winfo_exists():
            manager.refresh()
        self.update_title()
        self.update_drawing_summary()
        self.queue_preview()

    def switch_table_by_name(self):
        table = next(
            (
                t
                for t in self.data["input_tables"]
                if t["name"] == self.table_choice.get()
            ),
            None,
        )
        if table:
            self.switch_table(table["id"])

    def switch_table(self, table_id):
        current_table(self.data, table_id)
        if table_id == self.data["active_table"]:
            return
        self.table_editor.finish()
        self.capture_selection()
        self.data["active_table"] = table_id
        self.table_editor.has_cell = False
        self.refresh()

    def on_table_list_selection(self, event=None):
        if self._syncing_options:
            return
        selected = self.table_list.selection()
        if selected and selected[0] != self.data["active_table"]:
            self.switch_table(selected[0])
            self.table_list.focus_set()

    def new_table(self):
        self.table_editor.finish()
        name = simpledialog.askstring(
            "入力表を追加",
            "新しい入力表の名前",
            initialvalue=unique_table_name(self.data, "入力表"),
            parent=self.root,
        )
        if name is None:
            return
        try:
            add_input_table(self.data, name, [])
        except ValueError as exc:
            return messagebox.showerror("入力表の確認", str(exc), parent=self.root)
        self.refresh()

    def rename_table(self):
        self.table_editor.finish()
        table = current_table(self.data)
        name = simpledialog.askstring(
            "入力表の名前", "新しい名前", initialvalue=table["name"], parent=self.root
        )
        if name is None:
            return
        name = name.strip()
        if not name or any(
            t["id"] != table["id"] and t["name"].casefold() == name.casefold()
            for t in self.data["input_tables"]
        ):
            return messagebox.showerror(
                "入力表の名前", "空欄や他の表と同じ名前は使えません", parent=self.root
            )
        rename_project_table_references(self.data, table["name"], name)
        table["name"] = name
        self.refresh()

    def duplicate_table(self):
        self.table_editor.finish()
        self.capture_selection()
        source = current_table(self.data)
        target = copy.deepcopy(target_settings(self.data))
        try:
            table = add_input_table(
                self.data,
                unique_table_name(self.data, source["name"] + " コピー"),
                source["rows"],
            )
        except ValueError as exc:
            return messagebox.showerror("入力表の確認", str(exc), parent=self.root)
        self.data["drawing"]["targets"][table["id"]] = target
        self.refresh()

    def delete_table(self):
        self.table_editor.finish()
        if len(self.data["input_tables"]) <= 1:
            return messagebox.showinfo(
                "入力表の削除",
                "入力表は1つ以上必要です。行を削除すると空の表にできます。",
                parent=self.root,
            )
        table = current_table(self.data)
        if not messagebox.askyesno(
            "入力表を削除",
            f"「{table['name']}」を削除しますか？ 元に戻す操作で復元できます。",
            parent=self.root,
        ):
            return
        self.data["input_tables"].remove(table)
        self.data["drawing"]["targets"].pop(table["id"])
        self.data["active_table"] = self.data["input_tables"][0]["id"]
        self.refresh()

    def replace_table_file(self):
        path = filedialog.askopenfilename(
            parent=self.root, filetypes=[("入力表", "*.xlsx *.csv")]
        )
        if path:
            self.read_table(path, replace=True)

    def manage_settings_presets(self):
        return SettingsPresetEditor(self)

    def show_input_table(self):
        self.input_window.deiconify()
        self.input_window.lift()
        self.table.focus_set()
        return self.input_window

    def hide_input_table(self):
        self.table_editor.finish()
        self.input_window.withdraw()
        self.root.lift()
        return "break"

    def edit_cad_setup(self):
        return CadSetupEditor(self)

    def show_drawing(self):
        self.root.deiconify()
        self.root.lift()

    def selected_rows(self):
        return sorted(int(i) for i in self.table.selection())

    def selected_block(self):
        selected = self.block_browser.selected_indices()
        return selected[0] if len(selected) == 1 else None

    def activate_block(self, event=None):
        if event is not None and self.block_browser.visibility_hit(event):
            return "break"
        if self.selected_block() is not None:
            self.edit_block()
            return "break"

    def has_unsaved_changes(self):
        return self.data != self._saved

    def project_dialog_parent(self):
        if (
            self.project_window is not None
            and self.project_window.winfo_exists()
            and self.project_window.state() == "normal"
        ):
            return self.project_window
        return self.root

    def confirm_discard(self, what):
        self.table_editor.finish()
        if not self.block_browser.commit_pending_rename():
            return False
        if not self.has_unsaved_changes():
            return True
        answer = messagebox.askyesnocancel(
            "未保存の変更",
            f"{what}する前に変更を保存しますか？\n\nはい: 保存する / いいえ: 変更を破棄 / キャンセル: 戻る",
            parent=self.project_dialog_parent(),
        )
        return False if answer is None else self.save() if answer else True

    def on_exit(self):
        self.table_editor.finish()
        modal = self.root.grab_current()
        if modal is not None and modal.winfo_toplevel() is not self.root:
            modal.winfo_toplevel().lift()
            modal.focus_set()
            self.status.set(
                "編集中の画面を確定またはキャンセルしてから終了してください。"
            )
            return
        if self.confirm_discard("終了"):
            self.persist_workspace()
            self.clear_current_recovery()
            if self._preview_job:
                self.root.after_cancel(self._preview_job)
            self.root.destroy()

    def replace_document(self, data, path=None, name="新規プロジェクト"):
        prepared = normalize_project(data)
        self.table_editor.finish(False)
        self.clear_current_recovery()
        self._rendered_table_id = None
        self.close_navigator()
        self._table_selections.clear()
        self.table_editor.has_cell = False
        self._preview_row_selection = None
        self._rendered_table_id = None
        picker = getattr(self, "row_selection_dialog", None)
        if picker is not None and picker.win.winfo_exists():
            picker.cancel()
        self.data = prepared
        self.block_browser.reset_view()
        self.input_window.withdraw()
        self.path = path
        self.document_name = name
        self._history.clear()
        self._future.clear()
        self._saved = copy.deepcopy(self.data)
        self._observed = copy.deepcopy(self.data)
        self.canvas.items = []
        self.canvas.reset_camera()
        self._preview_items = []
        self._preview_valid = False
        self.refresh()
        self.show_drawing()
        self.queue_preview()

    def new(self):
        if self.confirm_discard("新規作成"):
            self.replace_document(EMPTY)
            self.status.set("表を読み込むか、行を追加して始めてください")

    def load_sample(self):
        if self.confirm_discard("サンプルを開く"):
            self.replace_document(EXAMPLE, name="サンプルプロジェクト")
            self.status.set("条件分岐・等配穴のサンプルを開きました")

    def load(self):
        path = filedialog.askopenfilename(
            parent=self.project_dialog_parent(),
            initialdir=str(self.project_library.directory),
            filetypes=[("AcadStadio プロジェクト", "*.json")],
        )
        if not path:
            return False
        return self.open_project(path)

    def remember_project(self, path):
        try:
            self.project_library.remember(path)
            return ""
        except (OSError, ValueError) as exc:
            return "（一覧設定の保存に失敗しました: " + str(exc) + "）"

    def open_project(self, path):
        try:
            path = canonical(path)
            if Path(path).stat().st_size > 20 * 1024 * 1024:
                raise ValueError("プロジェクトは20MBまでです")
            data = normalize_project(
                json.loads(Path(path).read_text(encoding="utf-8-sig"))
            )
            if not self.confirm_discard("プロジェクトを開く"):
                return False
            # A save during the confirmation may have updated this same file.
            if Path(path).stat().st_size > 20 * 1024 * 1024:
                raise ValueError("プロジェクトは20MBまでです")
            source = json.loads(Path(path).read_text(encoding="utf-8-sig"))
            migrated = "presets" in source
            data = normalize_project(source)
            self.replace_document(data, path)
            notice = self.remember_project(path)
            if self.project_sidebar is not None:
                self.project_sidebar.refresh()
            self.status.set(
                (
                    "旧JSONをブロック構造へ移行して開きました（元ファイルは保存するまで維持）: "
                    if migrated
                    else "開きました: "
                )
                + str(path)
                + notice
            )
            return True
        except Exception as exc:
            messagebox.showerror(
                "プロジェクトを開けません",
                str(exc),
                parent=self.project_dialog_parent(),
            )
            return False

    def changes(self):
        names = {
            "input_tables": "入力表",
            "active_table": "作図対象表",
            "drawing": "対象行の作図設定",
            "settings": "共通設定",
            "cad_setup": "CAD初期設定",
            "settings_presets": "設定プリセット",
            "active_settings_preset": "適用中の設定プリセット",
            "globals": "変数",
            "blocks": "ブロック",
            "custom_commands": "登録コマンド",
        }
        return [
            name + "を変更"
            for key, name in names.items()
            if self._saved.get(key) != self.data.get(key)
        ]

    def save_as(self):
        return self.save(choose_path=True)

    def save(self, choose_path=False):
        from audit import audit_project

        self.table_editor.finish()
        if not self.block_browser.commit_pending_rename():
            return False
        self.capture_selection()
        self._checkpoint()
        problems = audit_project(self.data)
        if problems and not messagebox.askyesno(
            "未解決の問題があります",
            "\n".join(problems[:8])
            + "\n\n編集途中として保存しますか？\nSCRを書き出す前に問題を解消してください。",
            parent=self.project_dialog_parent(),
        ):
            return False
        if not self.path or choose_path:
            try:
                self.project_library.ensure_directory()
            except OSError as exc:
                messagebox.showerror(
                    "保存フォルダーを用意できません",
                    str(exc),
                    parent=self.project_dialog_parent(),
                )
                return False
        path = (None if choose_path else self.path) or filedialog.asksaveasfilename(
            parent=self.project_dialog_parent(),
            defaultextension=".json",
            initialdir=str(self.project_library.directory),
            initialfile=Path(self.path).name if self.path else "project.json",
            filetypes=[("AcadStadio プロジェクト", "*.json")],
        )
        if not path:
            return False
        try:
            if canonical(path) == str(self.project_library.state_path):
                raise ValueError(
                    "一覧管理用のlibrary.jsonには保存できません。別のファイル名を指定してください。"
                )
            if Path(canonical(path)).is_relative_to(
                self.workspace_state.directory.resolve()
            ):
                raise ValueError(
                    "作業状態・復元用フォルダーには保存できません。別の場所を指定してください。"
                )
            atomic_save(path, self.data)
            self.path = canonical(path)
            self._saved = copy.deepcopy(self.data)
            self.clear_current_recovery()
            notice = self.remember_project(path)
            self.refresh()
            self.status.set("保存しました: " + str(path) + notice)
            return True
        except Exception as exc:
            messagebox.showerror(
                "保存できません", str(exc), parent=self.project_dialog_parent()
            )
            return False

    def show_changes(self):
        self.show_text(
            "保存済みとの変更",
            "\n".join(details(self._saved, self.data)) or "変更はありません。",
        )

    def show_text(self, title, text):
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry("860x570")
        win.transient(self.root)
        frame = ttk.Frame(win, padding=14)
        frame.pack(fill="both", expand=True)
        body = tk.Text(frame, wrap="word", relief="flat", padx=12, pady=12)
        scroll = ttk.Scrollbar(frame, command=body.yview)
        body.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        body.pack(fill="both", expand=True)
        body.insert("1.0", text)
        body.configure(state="disabled")
        ttk.Button(win, text="閉じる", command=win.destroy).pack(pady=(0, 12))
        win.bind("<Escape>", lambda e: win.destroy())
        return win

    def import_table(self):
        path = filedialog.askopenfilename(
            parent=self.root,
            filetypes=[
                ("入力表", "*.xlsx *.csv"),
                ("Excel", "*.xlsx"),
                ("CSV", "*.csv"),
            ],
        )
        if path:
            self.read_table(path)

    def read_table(self, path, replace=False):
        try:
            if Path(path).suffix.lower() == ".csv":
                rows = read_csv(path)
            else:
                names = sheet_names(path)
                sheet = names[0] if len(names) == 1 else self.choose_sheet(names)
                if sheet is None:
                    return False
                header = simpledialog.askinteger(
                    "見出しの位置",
                    "列名がある行番号",
                    initialvalue=1,
                    minvalue=1,
                    parent=self.root,
                )
                if header is None:
                    return False
                rows = read_excel(path, sheet, header)
            if replace:
                if not messagebox.askyesno(
                    "入力表の置き換え",
                    f"「{current_table(self.data)['name']}」を{len(rows)}行の表に置き換えますか？",
                    parent=self.root,
                ):
                    return False
                current_table(self.data)["rows"] = rows
                self.data["drawing"]["targets"][self.data["active_table"]] = (
                    default_target(rows)
                )
            else:
                name = unique_table_name(
                    self.data,
                    Path(path).stem
                    + ((" / " + sheet) if Path(path).suffix.lower() != ".csv" else ""),
                )
                add_input_table(self.data, name, rows)
            self.refresh()
            self.queue_preview()
            self.show_input_table()
            self.status.set(f"{Path(path).name} から {len(rows)}行を読み込みました")
            return True
        except ImportError:
            messagebox.showerror(
                "Excel読込の準備",
                "Excelの読込には openpyxl が必要です。\nREADMEの「起動」を参照してください。",
                parent=self.root,
            )
        except Exception as exc:
            messagebox.showerror("表を読み込めません", str(exc), parent=self.root)
        return False

    def import_csv(self):
        self.import_table()

    def import_excel(self):
        self.import_table()

    def choose_sheet(self, names):
        win = tk.Toplevel(self.root)
        win.title("シートを選択")
        win.transient(self.root)
        win.grab_set()
        result = []
        ttk.Label(win, text="読み込むシート", padding=14).pack()
        value = tk.StringVar(value=names[0])
        ttk.Combobox(
            win, values=names, textvariable=value, state="readonly", width=35
        ).pack(padx=14)
        ttk.Button(
            win,
            text="次へ",
            command=lambda: (result.append(value.get()), win.destroy()),
        ).pack(pady=14)
        from secondary_style import surface
        surface(win)
        self.root.wait_window(win)
        return result[0] if result else None

    def edit_key_values(
        self, title, value, kind="settings", parent=None, validator=None
    ):
        parent = parent or self.root
        win = tk.Toplevel(parent)
        win.title(title)
        win.geometry("750x540")
        win.transient(parent)
        win.grab_set()
        win.bind("<Escape>", lambda e: win.destroy())
        hint = (
            "名前は日本語も使えます。値は式として上から順に計算します。参照例: 変数.参照行"
            if kind == "globals"
            else "設定値は数値または文字列です。settings.名前 で参照できます。"
        )
        ttk.Label(win, text=hint, padding=12, wraplength=710).pack(anchor="w")
        frame = ttk.Frame(win, padding=(12, 0))
        frame.pack(fill="both", expand=True)
        tree = GridTreeview(
            frame, columns=("key", "value"), show="headings", selectmode="browse"
        )
        tree.heading("key", text="名前")
        tree.heading("value", text="式 / 値")
        tree.column("key", width=210)
        tree.column("value", width=420)
        tree.pack(fill="both", expand=True)
        for key, val in value.items():
            tree.insert("", "end", values=(key, str(val)))
        fields = ttk.Frame(win, padding=12)
        fields.pack(fill="x")
        name = tk.StringVar()
        val = tk.StringVar()
        ttk.Label(fields, text="名前").grid(row=0, column=0)
        ttk.Entry(fields, textvariable=name, width=22).grid(row=0, column=1, padx=6)
        ttk.Label(fields, text="値").grid(row=0, column=2)
        ttk.Entry(fields, textvariable=val, width=35).grid(row=0, column=3, padx=6)
        result = []

        def select(_=None):
            if tree.selection():
                a, b = tree.item(tree.selection()[0], "values")
                name.set(a)
                val.set(b)

        tree.bind("<<TreeviewSelect>>", select)

        def upsert():
            key = name.get().strip()
            selected = tree.selection()
            if not (valid_variable_name(key) if kind == "globals" else valid_name(key)):
                messagebox.showerror(
                    "名前",
                    "日本語または英数字の名前を指定してください。記号・空白・予約名は使えません"
                    if kind == "globals" else
                    "英数字と_で指定してください。予約名は使えません",
                    parent=win,
                )
                return False
            if any(
                tree.item(i, "values")[0] == key
                for i in tree.get_children()
                if not selected or i != selected[0]
            ):
                messagebox.showerror("名前の重複", "同じ名前があります", parent=win)
                return False
            if selected:
                tree.item(selected[0], values=(key, val.get()))
            else:
                tree.selection_set(tree.insert("", "end", values=(key, val.get())))
            return True

        bar = ttk.Frame(win, padding=(12, 0))
        bar.pack(fill="x")
        ttk.Button(bar, text="入力した値を追加 / 更新", command=upsert).pack(
            side="left"
        )
        ttk.Button(
            bar,
            text="新しい項目",
            command=lambda: (
                tree.selection_remove(tree.selection()),
                name.set(""),
                val.set(""),
            ),
        ).pack(side="left", padx=4)
        ttk.Button(
            bar,
            text="選択を削除",
            command=lambda: [tree.delete(i) for i in tree.selection()],
        ).pack(side="left")

        def done():
            selected = tree.selection()
            pending = (name.get().strip(), val.get())
            original = tuple(tree.item(selected[0], "values")) if selected else ("", "")
            if pending != original and (pending[0] or pending[1]) and not upsert():
                return
            data = {
                tree.item(i, "values")[0]: tree.item(i, "values")[1]
                for i in tree.get_children()
            }
            errors = validator(data) if validator else []
            if errors:
                messagebox.showerror("設定値の確認", "\n".join(errors[:12]), parent=win)
                return
            result.append(data)
            win.destroy()

        ttk.Button(
            win, text="表の内容を確定", style="Primary.TButton", command=done
        ).pack(pady=14)
        from secondary_style import surface
        surface(win)
        self.root.wait_window(win)
        return result[0] if result else None

    def edit_settings(self):
        return self.manage_settings_presets()

    def edit_globals(self):
        data = self.edit_key_values("変数", self.data["globals"], "globals")
        if data is not None:
            self.data["globals"] = data
            self.refresh()

    def edit_row_values(self, title, row, row_index=None):
        parent = self.input_window if self.input_window.winfo_ismapped() else self.root
        win = tk.Toplevel(parent)
        win.title(title)
        win.geometry("530x610")
        win.transient(parent)
        win.grab_set()
        result = []
        ttk.Label(
            win,
            text="各列の値を入力してください。数値と文字列を入力できます。",
            padding=14,
            wraplength=490,
        ).pack(anchor="w")
        canvas = tk.Canvas(win, highlightthickness=0)
        scroll = ttk.Scrollbar(win, command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(fill="both", expand=True, padx=14)
        form = ttk.Frame(canvas)
        window = canvas.create_window(0, 0, window=form, anchor="nw")
        canvas.bind(
            "<Configure>", lambda e: canvas.itemconfigure(window, width=e.width)
        )
        form.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        variables = {}
        table_data = current_table(self.data)
        formulas = computed_columns(table_data)
        locked = set(formulas) if row_index is not None and row_index > 0 else set()
        resolver = RowResolver(self.data, convert, evaluate, MacroError) if locked else None
        for key, value in row.items():
            field = ttk.Frame(form)
            field.pack(fill="x", pady=5)
            ttk.Label(field, text=key, width=15).pack(side="left")
            display = display_formula(value, table_data)
            if key in locked:
                try:
                    display = resolver.cell(table_data["name"], row_index, key) if row_index < len(self.rows) else "自動計算"
                except MacroError:
                    display = "計算エラー"
            if type(display) in (int, float):
                display = format(display, ".12g")
            variable = tk.StringVar(value=str(display))
            ttk.Entry(field, textvariable=variable, state="readonly" if key in locked else "normal").pack(
                side="left", fill="x", expand=True
            )
            variables[key] = variable

        def done():
            data = {k: row.get(k, "") if k in locked else v.get() for k, v in variables.items()}
            try:
                if row_index is not None:
                    for key, value in data.items():
                        if key not in locked:
                            check_cell_input(table_data, row_index, key, value)
            except ValueError as exc:
                messagebox.showerror("行の編集", str(exc), parent=win)
                return
            result.append(data)
            win.destroy()

        buttons = ttk.Frame(win, padding=14)
        buttons.pack(side="bottom", fill="x", before=canvas)
        ttk.Button(buttons, text="キャンセル", command=win.destroy).pack(side="left")
        ttk.Button(
            buttons, text="行を確定", style="Primary.TButton", command=done
        ).pack(side="right")
        from secondary_style import surface
        surface(win)
        self.root.wait_window(win)
        return result[0] if result else None

    def add_row(self):
        if len(self.rows) >= 10000:
            return messagebox.showerror(
                "行数の上限", "1つの入力表は10000行までです", parent=self.root
            )
        keys = list(dict.fromkeys(k for row in self.rows for k in row))
        if not keys:
            names = simpledialog.askstring(
                "入力表の列",
                "列名をカンマ区切りで入力（例: TYPE,X,Y,OD,R）",
                initialvalue="TYPE,X,Y,OD,R",
                parent=self.root,
            )
            if names is None:
                return
            from table_io import headers

            try:
                keys = headers(names.split(","))
            except ValueError as exc:
                return messagebox.showerror("列名の確認", str(exc), parent=self.root)
        data = self.edit_row_values("行を追加", dict.fromkeys(keys, "0"), row_index=len(self.rows))
        if data is not None:
            self.rows.append(data)
            self._table_selections[self.data["active_table"]] = [len(self.rows) - 1]
            self._rendered_table_id = None
            self.refresh()

    def edit_row(self):
        rows = self.selected_rows()
        if len(rows) != 1:
            return messagebox.showinfo(
                "行を選択", "編集する行を1つ選択してください", parent=self.root
            )
        data = self.edit_row_values(f"{rows[0] + 1}行目を編集", self.rows[rows[0]], row_index=rows[0])
        if data is not None:
            self.rows[rows[0]] = data
            self.refresh()

    def duplicate_rows(self):
        ids = self.selected_rows()
        if len(self.rows) + len(ids) > 10000:
            return messagebox.showerror(
                "行数の上限", "1つの入力表は10000行までです", parent=self.root
            )
        formulas = computed_columns(current_table(self.data))
        for i in reversed(ids):
            duplicate = copy.deepcopy(self.rows[i])
            for key in formulas:
                duplicate[key] = ""
            self.rows.insert(i + 1, duplicate)
        target = target_settings(self.data)
        target["selected"] = [i + sum(d < i for d in ids) for i in target["selected"]]
        self._table_selections[self.data["active_table"]] = [
            i + 1 + offset for offset, i in enumerate(ids)
        ]
        self._rendered_table_id = None
        self.refresh()

    def del_row(self):
        ids = self.selected_rows()
        if not ids:
            return
        if not messagebox.askyesno(
            "行の削除",
            f"{len(ids)}行を削除しますか？ 元に戻す操作で復元できます。",
            parent=self.root,
        ):
            return
        formulas = computed_columns(current_table(self.data))
        templates = {key: self.rows[0][key] for key in formulas}
        columns = list(dict.fromkeys(key for row in self.rows for key in row))
        for i in reversed(ids):
            self.rows.pop(i)
        if self.rows and 0 in ids:
            self.rows[0] = {key: self.rows[0].get(key, "") for key in columns}
            self.rows[0].update(templates)
        target = target_settings(self.data)
        target["selected"] = [i - sum(d < i for d in ids) for i in target["selected"] if i not in ids]
        self._table_selections[self.data["active_table"]] = []
        self._rendered_table_id = None
        self.refresh()

    def add_block(self):
        trial = copy.deepcopy(self.data)
        block = new_block()
        folder_id = self.block_browser.selected_folder()
        if folder_id:
            block["folder_id"] = folder_id
        trial["blocks"].append(block)

        def commit():
            self.data["blocks"] = copy.deepcopy(trial["blocks"])
            self.refresh()
            self.block_browser.reveal(
                next(
                    i
                    for i, b in enumerate(self.data["blocks"])
                    if b["id"] == block["id"]
                )
            )

        MacroEditor(
            self.root, block, trial["blocks"], commit, trial, self.block_preview_rows()
        )

    def edit_block(self):
        index = self.selected_block()
        if index is None:
            if any(n.startswith("folder:") for n in self.block_list.selection()):
                return self.block_browser.rename_folder()
            return messagebox.showinfo(
                "ブロックを選択", "編集するブロックを選択してください", parent=self.root
            )
        self.edit_block_index(index)

    def edit_block_index(self, index):
        if 0 <= index < len(self.data["blocks"]):
            MacroEditor(
                self.root,
                self.data["blocks"][index],
                self.data["blocks"],
                self.refresh,
                self.data,
                self.block_preview_rows(),
            )

    def block_preview_rows(self):
        try:
            return self.preview_rows()
        except ValueError:
            return []

    def manage_custom_commands(self):
        CommandCatalogManager(self.root, self.data, self.refresh)

    def del_block(self):
        index = self.selected_block()
        if index is None:
            if any(n.startswith("folder:") for n in self.block_list.selection()):
                return self.block_browser.delete_folder()
            return
        block = self.data["blocks"][index]
        if messagebox.askyesno(
            "ブロックの削除", f"「{block['name']}」を削除しますか？", parent=self.root
        ):
            self.data["blocks"].pop(index)
            self.refresh()

    def move_block(self, delta):
        i = self.selected_block()
        if i is not None and 0 <= i + delta < len(self.data["blocks"]):
            if self.data["blocks"][i].get("guide") or self.data["blocks"][i+delta].get("guide"):
                return
            identity=self.data["blocks"][i]["id"]
            trial=copy.deepcopy(self.data)
            trial["blocks"][i],trial["blocks"][i+delta]=trial["blocks"][i+delta],trial["blocks"][i]
            if not confirm_reference_order(self.root,trial):return
            self.data.clear();self.data.update(trial)
            self.refresh()
            self.block_browser.reveal(next(i for i,b in enumerate(self.data["blocks"]) if b["id"]==identity))

    def open_navigator(self):
        if self.navigator and self.navigator.winfo_exists():
            self.navigator.lift()
            return
        self.navigator = ProjectNavigator(
            self.root,
            self.data,
            self.edit_block_index,
            self.add_block,
            self.refresh,
            undo=self.undo_project,
            redo=self.redo_project,
        )

    def close_navigator(self):
        if self.navigator and self.navigator.winfo_exists():
            self.navigator.destroy()
        self.navigator = None

    def reference_help(self):
        candidates = ["入力表: @列名、[表名]@列名、@列名{行番号}"]
        candidates += [
            "@" + key for key in dict.fromkeys(k for row in self.rows for k in row)
        ]
        candidates += ["\n共通設定: settings." + k for k in self.data["settings"]]
        candidates += ["変数." + k for k in self.data["globals"]]
        candidates += ["\n繰り返しの内側: loop.index / loop.number / loop.count"]
        self.show_text("参照式の一覧", "\n".join(candidates))

    def target_rows(self, all_rows=None):
        if all_rows is True:
            return list(range(len(self.rows)))
        if all_rows is False or self.scope.get() == "selected":
            return list(target_settings(self.data)["selected"])
        if self.scope.get() == "all":
            return list(range(len(self.rows)))
        try:
            return [parse_row_number(self.row_range.get(), len(self.rows))]
        except ValueError as exc:
            raise MacroError(str(exc)) from exc

    def compile(self, all_rows=None):
        if not self.rows:
            raise MacroError("Excel / CSVを読み込むか、入力表に行を追加してください。")
        errors = validate_project(self.data)
        if errors:
            raise MacroError("\n".join(errors[:12]))
        indices = self.target_rows(all_rows)
        if not indices:
            raise MacroError(
                "入力表の「作図」列で出力する行にチェックしてください。"
            )
        self.command_diagnostics = []
        result = compile_project(
            self.data, indices, diagnostics=self.command_diagnostics
        )
        return result

    def preview_rows(self):
        selection = self._preview_row_selection
        if selection is not None and selection[0] == self.data["active_table"]:
            return [i for i in selection[1] if 0 <= i < len(self.rows)]
        return self.target_rows()

    def queue_preview(self):
        if self._preview_job:
            self.root.after_cancel(self._preview_job)
        self._preview_job = self.root.after(180, lambda: self.preview(quiet=True))

    def set_script(self, text):
        self._script_text = text
        if self.script is not None and self.script.winfo_exists():
            self.script.configure(state="normal")
            self.script.delete("1.0", "end")
            self.script.insert("1.0", text)
            self.script.configure(state="disabled")

    def preview(self, quiet=False):
        self._checkpoint()
        if self._preview_job:
            self.root.after_cancel(self._preview_job)
            self._preview_job = None
        self.selection_status.set(
            f"{len(self.rows)}行中 {len(self.selected_rows())}行を選択 · プレビュー連動 / SCR対象は「作図」列のチェックで指定"
        )
        self.drawing_selection_summary.set(
            f"全{len(self.rows)}行 / チェック{len(target_settings(self.data)['selected'])}行"
        )
        self.update_drawing_summary()
        try:
            script, items = self.compile()
            self.set_script(script)
            display_rows = self.preview_rows()
            diagnostics = self.command_diagnostics
            try:
                if display_rows != self.target_rows():
                    diagnostics = []
                    _, display_items = compile_project(self.data, display_rows, diagnostics=diagnostics)
                else:
                    display_items = items
            except Exception as exc:
                self._preview_items = []
                self._preview_valid = False
                self.canvas.set_items([], message="選択行の値を確認してください。", preserve_camera=True)
                self.preview_status.set("選択行のプレビューを生成できません")
                self.canvas.set_workspace_info("確認行の値を確認してください。SCR対象は入力表のチェックを維持しています。")
                self.preview_metrics.set("プレビュー生成エラー")
                self.status.set("プレビュー: " + str(exc))
                return script, items
            custom_count = sum(e["type"] == "CUSTOM" for e in diagnostics)
            identity = (self.data["active_table"], tuple(display_rows))
            recenter = identity != getattr(self, "_preview_display_identity", identity)
            self._preview_display_identity = identity
            self._preview_display_rows = display_rows
            self._preview_items = display_items
            self._preview_custom_count = custom_count
            self._preview_target_count = len(self.target_rows())
            self._preview_valid = True
            self.update_preview_display(recenter=recenter)
            self.status.set("更新済み")
            return script, items
        except Exception as exc:
            self.command_diagnostics = []
            self._preview_items = []
            self._preview_valid = False
            self.canvas.set_items([], preserve_camera=True)
            self.set_script("")
            self.preview_status.set("未生成")
            self.canvas.set_workspace_info("未生成 · 入力表の作図チェックと入力値を確認してください")
            self.preview_metrics.set("未生成")
            self.status.set(str(exc))
            if not quiet and self.rows:
                messagebox.showerror("生成内容の確認", str(exc), parent=self.root)
            return None

    def update_preview_display(self, *, recenter=False):
        """Filter cached geometry only; the compiled SCR and project stay intact."""
        if not hasattr(self, "canvas") or not getattr(self, "_preview_valid", False):
            return
        items = getattr(self, "_preview_items", [])
        visible = self.block_browser.preview_items(items)
        custom_count = getattr(self, "_preview_custom_count", 0)
        message = None
        if items and not visible:
            message = "プレビューの表示がすべてOFFです。\n一覧の「表示」で戻せます。SCR出力には影響しません。"
        elif custom_count:
            message = "登録コマンドの図形はプレビュー対象外です。右上の「SCRを表示」で確認してください。"
        self.canvas.set_color_resources(self.data)
        self.canvas.set_items(
            visible, message=message,
            layer_order=list(dict.fromkeys(i.get("layer", "0") for i in items)),
            preserve_camera=True, recenter=recenter,
            camera_items=items,
        )
        self.highlight_preview()
        summary = f"{current_table(self.data)['name']} · {len(items)}図形 / SCR対象{self._preview_target_count}行"
        if self._preview_row_selection is not None:
            numbers = ",".join(str(i + 1) for i in self._preview_display_rows[:5])
            if len(self._preview_display_rows) > 5:
                numbers += "…"
            summary += f" / 確認行{numbers}"
        if len(visible) != len(items):
            summary += f"（表示{len(visible)}）"
        if custom_count:
            summary += f" / 登録{custom_count}件はSCRのみ"
        self.preview_status.set(summary)
        rows = self._preview_display_rows
        numbers = ",".join(str(i + 1) for i in rows[:4]) + ("…" if len(rows) > 4 else "")
        title = row_title(self.data, rows[0]) if len(rows) == 1 else f"{len(rows)}行"
        title = " ".join(title.splitlines())
        title = title if len(title) <= 20 else title[:19] + "…"
        compact = f"確認行: {numbers or 'なし'}  |  SCR対象: {self._preview_target_count}行"
        self.canvas.set_workspace_info(
            f"確認: {title} / {numbers or 'なし'}行目  |  SCR対象: {self._preview_target_count}行", compact)
        count = str(len(items)) if len(visible) == len(items) else f"表示{len(visible)} / {len(items)}"
        self.preview_metrics.set(count + "図形" + (f"（ガイド{sum(bool(i.get('guide')) for i in items)}）" if any(i.get("guide") for i in items) else "") + " · 図面単位")

    def show_script(self):
        self.preview(quiet=True)
        if self.script_window is not None and self.script_window.winfo_exists():
            self.script_window.deiconify()
            self.script_window.lift()
            return self.script_window
        win = self.script_window = tk.Toplevel(self.root)
        win.title("生成SCR")
        win.bind("<F5>", lambda e: (self.preview(), "break")[-1])
        fit_window(win, 900, 700, 650, 450)
        win.transient(self.root)
        win.protocol("WM_DELETE_WINDOW", win.withdraw)
        win.bind("<Escape>", lambda e: win.withdraw())
        area = ttk.Frame(win, padding=10, style="SurfaceCard.TFrame")
        area.pack(fill="both", expand=True)
        area.rowconfigure(0, weight=1); area.columnconfigure(0, weight=1)
        self.script = tk.Text(area, wrap="none", font=("Consolas",11),
                              bg="#101d30", fg="#d0e1f7", relief="flat", padx=12, pady=12)
        self.script.grid(row=0,column=0,sticky="nsew")
        vertical=ttk.Scrollbar(area,command=self.script.yview)
        vertical.grid(row=0,column=1,sticky="ns")
        horizontal=ttk.Scrollbar(area,orient="horizontal",command=self.script.xview)
        horizontal.grid(row=1,column=0,sticky="ew")
        self.script.configure(yscrollcommand=vertical.set,xscrollcommand=horizontal.set)
        bar=ttk.Frame(win,padding=(10, 4));bar.pack(fill="x", before=area)
        ttk.Button(bar,text="SCRをコピー",command=self.copy_script).pack(side="left")
        ttk.Button(bar,text="再生成  F5",command=self.preview).pack(side="left",padx=6)
        footer=ttk.Frame(win,padding=10);footer.pack(side="bottom",fill="x")
        ttk.Button(footer,text="SCRを書き出す",command=self.export,style="Primary.TButton").pack(side="right")
        self.set_script(self._script_text)
        return win

    def copy_script(self):
        result = self.preview()
        if result:
            self.root.clipboard_clear()
            self.root.clipboard_append(result[0])
            self.status.set("生成SCRをコピーしました")

    def audit(self):
        from inspection import InspectionWindow

        self.table_editor.finish()
        win = InspectionWindow(self)
        return [record["message"] for record in win.records]

    def update_drawing_summary(self):
        self.drawing_selection_summary.set(
            f"全{len(self.rows)}行 / チェック{len(target_settings(self.data)['selected'])}行"
        )
        try:
            target = self.target_rows()
            count = len(target)
            numbers = ",".join(str(i + 1) for i in target[:8])
            if count > 8:
                numbers += "…"
            rows = f"{count}行" + (f"（{numbers}）" if numbers else "")
        except ValueError:
            rows = "行番号を確認してください"
        mode = {"selected": "選択行", "range": "行番号", "all": "全行"}.get(
            self.scope.get(), ""
        )
        if self.scope.get() == "range":
            try:
                title = row_title(self.data, parse_row_number(self.row_range.get(), len(self.rows)))
                rows += " / " + title
            except ValueError:
                pass
        for controls in self._target_controls:
            controls.sync()
        self.preview_row_controls.sync()
        enabled = len(self.data["blocks"])
        setup = "ON" if self.data.get("cad_setup", {}).get("enabled") else "OFF"
        self.drawing_summary.set(
            f"作図条件  |  表: {current_table(self.data)['name']}  |  対象: {mode} / {rows}  |  作図ブロック: {enabled}件  |  CAD初期設定: {setup}"
        )

    def edit_target_settings(self):
        return self.show_input_table()

    def set_input_checks(self, indices):
        """Change output checks independently of highlighted preview rows."""
        self.table_editor.finish()
        selected = sorted({i for i in indices if type(i) is int and 0 <= i < len(self.rows)})
        target_settings(self.data).update(mode="selected", selected=selected)
        self._syncing_options = True
        self.scope.set("selected")
        self._syncing_options = False
        checked = set(selected)
        for iid in self.table.get_children():
            self.table.item(iid, text="☑" if int(iid) in checked else "☐")
        self._checkpoint()
        self.update_title()
        self.update_drawing_summary()
        self.queue_preview()

    def on_drawing_check(self, event):
        if self.table.identify_column(event.x) != "#0":
            return
        row = self.table.identify_row(event.y)
        if row:
            checked = set(self.target_rows())
            index = int(row)
            checked.symmetric_difference_update({index})
            self.set_input_checks(checked)
            return "break"

    def toggle_selected_drawing_rows(self, event=None):
        rows = set(self.selected_rows())
        if rows:
            checked = set(self.target_rows())
            self.set_input_checks(checked - rows if rows <= checked else checked | rows)
        return "break"

    def toggle_all_drawing_rows(self):
        self.set_input_checks([] if len(target_settings(self.data)["selected"]) == len(self.rows) else range(len(self.rows)))

    def set_checked_rows(self, indices, *, table_id=None):
        if table_id is not None:
            table = current_table(self.data, table_id)
            selected = sorted({i for i in indices if type(i) is int and 0 <= i < len(table["rows"])})
            self.capture_selection()
            self.data["active_table"] = table_id
            target_settings(self.data).update(mode="selected", selected=selected)
            self._preview_row_selection = None
            self._table_selections[table_id] = selected
            self.table_editor.has_cell = False
            self.refresh()
            return
        target_settings(self.data)["selected"] = sorted(set(indices))
        self.scope.set("selected")
        self._table_selections[self.data["active_table"]] = list(indices)
        self.table.selection_set([str(i) for i in indices])
        self._checkpoint()
        self.update_drawing_summary()
        self.update_title()
        self.queue_preview()

    def on_block_selection(self, event=None):
        self.highlight_preview()

    def highlight_preview(self, address=None):
        if self.highlight_enabled.get():
            try:
                targets = self.preview_rows()
            except ValueError:
                targets = []
            rows = [i for i in self.selected_rows() if i in targets] or targets
            self.canvas.highlight(rows, self.selected_block(), address)
        else:
            self.canvas.highlight()

    def navigate_issue(self, record):
        try:
            table_id = record.get("table_id")
            if table_id:
                self.switch_table(table_id)
            row = record.get("row")
            # Focus marks the erroneous row without changing the selected drawing targets.
            if row is not None:
                if not self.table.exists(str(row)):
                    raise ValueError("行が変更されています")
                self.table.focus(str(row))
                self.table.see(str(row))
                self.table.tag_configure("issue", background="#fff0bd")
                for node in self.table.get_children():
                    self.table.item(
                        node,
                        tags=tuple(
                            t for t in self.table.item(node, "tags") if t != "issue"
                        ),
                    )
                self.table.item(
                    str(row), tags=(*self.table.item(str(row), "tags"), "issue")
                )
                self.show_input_table()
            index = record.get("block_index")
            if record.get("address") and record["address"][0] == "blocks":
                index = record["address"][1]
            if index is not None:
                self.block_browser.reveal(index)
                self.show_drawing()
            address = record.get("address")
            if address and index is not None:
                self.show_drawing()
                self.open_navigator()
                if not self.navigator.select_address(address):
                    raise ValueError("コマンドが変更されています")
            elif record.get("drawing"):
                self.show_drawing()
                self.edit_target_settings()
                self.target_window_controls.spin.focus_set()
            elif record.get("resource") == "globals":
                self.edit_globals()
            elif record.get("resource") == "settings":
                self.edit_settings()
            elif record.get("resource") == "cad_setup":
                self.edit_cad_setup()
            elif record.get("catalog"):
                self.manage_custom_commands()
            self.status.set(record["message"])
        except (KeyError, IndexError, ValueError, tk.TclError):
            self.status.set("検査後に構成が変更されています。再検査してください。")

    def cleanup_jobs(self, event):
        if event.widget is self.root:
            for name in ("_preview_job", "_session_job", "_startup_job"):
                job = getattr(self, name, None)
                if job:
                    self.root.after_cancel(job)
                    setattr(self, name, None)

    def persist_workspace(self):
        try:
            self.workspace_state.write(
                "view",
                {
                    "geometry": self.root.geometry(),
                    "path": self.path,
                    "input_window_open": self.input_window.state() == "normal",
                    "input_window_geometry": self.input_window.geometry(),
                    "block": self.selected_block(),
                    "block_browser": self.block_browser.get_view(),
                    "sash": self.drawing_panes.sashpos(0),
                    "preview": self.canvas.get_view(),
                    "highlight": self.highlight_enabled.get(),
                    "actual_colors": self.canvas.actual_color_mode.get(),
                    "command_preview_through": bool(getattr(self.root, "_command_preview_through", False)),
                },
            )
            return True
        except (OSError, ValueError, tk.TclError) as exc:
            self.status.set("作業状態を保存できません: " + str(exc))
            return False

    def autosave_workspace(self, reschedule=True):
        try:
            self.persist_workspace()
            snapshot = copy.deepcopy(self.data)
            editor = self.table_editor
            if editor.entry is not None:
                row, col = editor.cell
                get_rows(snapshot)[row][editor.keys()[col]] = editor.entry.get()
            if snapshot != self._saved:
                self.workspace_state.save_recovery(
                    self._draft_id,
                    {"data": snapshot, "name": self.document_name, "source": self.path},
                )
            else:
                self.workspace_state.remove_recovery(self._draft_id)
        except (OSError, ValueError, IndexError, tk.TclError) as exc:
            self.status.set("作業の復元データを保存できません: " + str(exc))
        finally:
            if reschedule:
                self._session_job = self.root.after(15000, self.autosave_workspace)

    def restore_workspace(self):
        self._startup_job = None
        state = self.workspace_state.read("view", 128 * 1024)
        if not state:
            return
        try:
            path = state.get("path")
            if (
                isinstance(path, str)
                and Path(path).is_file()
                and Path(path).stat().st_size <= 20 * 1024 * 1024
            ):
                data = normalize_project(
                    json.loads(Path(path).read_text(encoding="utf-8-sig"))
                )
                self.replace_document(data, path)
            geometry = re.fullmatch(
                r"(\d+)x(\d+)([+-]\d+)([+-]\d+)", str(state.get("geometry", ""))
            )
            if geometry:
                w, h, x, y = map(int, geometry.groups())
                sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
                w, h = min(sw, max(1040, w)), min(sh, max(680, h))
                x, y = max(0, min(x, sw - w)), max(0, min(y, sh - h))
                self.root.geometry(f"{w}x{h}+{x}+{y}")
            input_geometry = re.fullmatch(
                r"(\d+)x(\d+)([+-]\d+)([+-]\d+)", str(state.get("input_window_geometry", ""))
            )
            if input_geometry:
                w, h, x, y = map(int, input_geometry.groups())
                sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
                w, h = min(sw, max(780, w)), min(sh, max(460, h))
                x, y = max(0, min(x, sw - w)), max(0, min(y, sh - h))
                self.input_window.geometry(f"{w}x{h}+{x}+{y}")
            if state.get("input_window_open") is True:
                self.show_input_table()
            self.root.update_idletasks()
            self.block_browser.restore_view(state.get("block_browser", {}))
            preset = state.get("block", state.get("preset"))
            if (
                not state.get("block_browser")
                and type(preset) is int
                and 0 <= preset < len(self.data["blocks"])
            ):
                self.block_browser.reveal(preset)
            if type(state.get("command_preview_through")) is bool:
                self.root._command_preview_through = state["command_preview_through"]
            if type(state.get("actual_colors")) is bool:
                self.canvas.actual_color_mode.set(state["actual_colors"])
            if type(state.get("highlight")) is bool:
                self.highlight_enabled.set(state["highlight"])
            sash = state.get("sash", 370)
            if type(sash) is int:
                self.drawing_panes.sashpos(
                    0, max(300, min(sash, self.drawing_panes.winfo_width() - 350))
                )
            self.preview(quiet=True)
            self.canvas.restore_view(state.get("preview", {}))
        except (OSError, ValueError, TypeError, KeyError, tk.TclError):
            self.status.set(
                "前回の表示状態を復元できないため、既定の表示で続行します。"
            )

    def discard_recovery(self):
        if not messagebox.askyesno(
            "復元データの破棄", "前回の未保存データを破棄しますか？", parent=self.root
        ):
            return
        try:
            self.workspace_state.remove_recovery(self._recovery["id"])
            self.refresh_recovery_banner()
        except OSError as exc:
            messagebox.showerror("復元データの破棄", str(exc), parent=self.root)

    def restore_recovery(self):
        if not self._recovery:
            return
        try:
            identity = self._recovery["id"]
            data = normalize_project(self._recovery["data"])
            if not self.confirm_discard("復元"):
                return
            self.replace_document(
                data, name=str(self._recovery.get("name", "プロジェクト")) + "（復元）"
            )
            self._saved = normalize_project(EMPTY)
            self.update_title()
            # Save the restored copy before removing its previous recovery entry.
            self.workspace_state.save_recovery(
                self._draft_id,
                {"data": self.data, "name": self.document_name, "source": None},
            )
            self.workspace_state.remove_recovery(identity)
            self.refresh_recovery_banner()
            self.status.set(
                "未保存データを別のプロジェクトとして復元しました。名前を付けて保存してください。"
            )
        except (OSError, ValueError, KeyError, TypeError) as exc:
            messagebox.showerror("復元できません", str(exc), parent=self.root)

    def clear_current_recovery(self):
        try:
            self.workspace_state.remove_recovery(self._draft_id)
        except OSError as exc:
            self.status.set("復元データの更新に失敗しました: " + str(exc))

    def refresh_recovery_banner(self):
        self._recoveries = [
            d for d in self.workspace_state.recoveries() if d["id"] != self._draft_id
        ]
        self._recovery = self._recoveries[0] if self._recoveries else None
        self.recovery_choice.configure(
            values=[
                f"{i + 1}. {d.get('name', 'プロジェクト')}"
                for i, d in enumerate(self._recoveries)
            ]
        )
        if self._recoveries:
            self.recovery_choice.current(0)
        else:
            self.recovery_banner.pack_forget()

    def export(self, all_rows=None):
        try:
            script, items = self.compile(all_rows)
        except Exception as exc:
            return messagebox.showerror(
                "SCRを生成できません", str(exc), parent=self.root
            )
        win = tk.Toplevel(self.root)
        win.title("SCRを書き出す")
        fit_window(win, 560, 420, 540, 400)
        win.transient(self.root)
        win.grab_set()
        n = len(self.target_rows(all_rows))
        custom_count = sum(e["type"] == "CUSTOM" for e in self.command_diagnostics)
        ttk.Label(
            win,
            text=f"{current_table(self.data)['name']} · {n}行 / 標準{sum(not i.get('guide') for i in items)}図形"
            + (f" / 登録{custom_count}件" if custom_count else ""),
            style="Section.TLabel",
            padding=16,
        ).pack(anchor="w")
        ttk.Label(
            win, text="AutoCADの環境に合う文字コードを選んでください。", padding=(16, 0)
        ).pack(anchor="w")
        ttk.Label(
            win,
            text="CAD初期設定マクロ: "
            + (
                "ON（不足する定義を作成）"
                if self.data.get("cad_setup", {}).get("enabled", False)
                else "OFF（既存の定義を使用）"
            ),
            padding=(16, 4),
            style="Muted.TLabel",
        ).pack(anchor="w")
        for label, value in [
            ("Shift-JIS（CP932）・日本語Windows向け", "cp932"),
            ("UTF-8・対応するAutoCAD環境向け", "utf-8"),
        ]:
            ttk.Radiobutton(win, text=label, variable=self.encoding, value=value).pack(
                anchor="w", padx=18, pady=8
            )
        ttk.Label(
            win,
            text="作図後、スナップ等の設定を実行前の値へ戻します。\nAutoLISP対応のAutoCADが必要です（LTは2024以降）。\n中断した場合は、コマンド待機状態で CADFLOWRESTORE を実行。\nTEXTは高さ0の文字スタイルで実行してください。",
            style="Muted.TLabel",
            padding=(16, 8),
            wraplength=520,
        ).pack(anchor="w")

        def write():
            try:
                script.encode(self.encoding.get())
            except UnicodeEncodeError:
                return messagebox.showerror(
                    "文字コードの確認",
                    "Shift-JISに変換できない文字があります。UTF-8を選択するか、文字・レイヤー名を変更してください。",
                    parent=win,
                )
            path = filedialog.asksaveasfilename(
                parent=win,
                defaultextension=".scr",
                initialfile="drawing.scr",
                filetypes=[("AutoCAD Script", "*.scr")],
            )
            if not path:
                return
            try:
                atomic_write_script(path, script, self.encoding.get())
                win.destroy()
                self.status.set(f"SCR出力完了 · {n}行 / {sum(not i.get('guide') for i in items)}図形 · {path}")
            except Exception as exc:
                messagebox.showerror("SCRを書き込めません", str(exc), parent=win)

        ttk.Button(
            win, text="保存先を選んで書き出す", style="Primary.TButton", command=write
        ).pack(pady=10)

    def show_help(self):
        self.show_text(
            "AcadStadio の使い方",
            (ROOT / "docs" / "QUICK_START.txt").read_text(encoding="utf-8"),
        )


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
