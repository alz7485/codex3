from table_grid import GridTreeview
from file_drop import enable_file_drop
from pathlib import Path
"""Checkbox-based selection of resource definitions discovered in a DWG."""

import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from dwg_resources import (
    DWGImportError, SECTIONS, TITLES, merge_selected_definitions, read_dwg_resources,
)
from theme import fit_window


PAGE_SIZE = 80


def description(section, values):
    if section == "layers":
        return (f"色 {values['color']}  /  線種 {values['linetype']}  /  "
                f"線幅 {values['lineweight']}  /  印刷 {'する' if values['plot'] else 'しない'}")
    if section == "text_styles":
        return (f"フォント {values['font']}  /  幅 {values['width']}  /  "
                f"傾斜 {values['oblique']}°")
    if section == "dim_styles" and "scale" in values:
        return (f"尺度 {values['scale']}  /  文字高 {values['text_height']}  /  "
                f"矢印 {values['arrow_size']}  /  文字スタイル {values['text_style']}")
    return "CAD内の同名の線種を使用" if section == "linetypes" else "寸法値の取得不可"


class DWGImportDialog:
    def __init__(self, parent_editor):
        self.editor = parent_editor
        self.win = tk.Toplevel(parent_editor.win)
        self.win.title("DWGからレイヤー・スタイルを取得")
        fit_window(self.win, 1020, 730, 800, 580)
        self.win.transient(parent_editor.win)
        self.win.grab_set()
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.bind("<Escape>", lambda event: self.close())
        self.path = tk.StringVar()
        self.status = tk.StringVar(value="DWGファイルを選んで「読み取る」を押してください。")
        self.replace = tk.BooleanVar(value=False)
        self.resources = {section: [] for section in SECTIONS}
        self.checked = {section: set() for section in SECTIONS}
        self.pages = {section: 0 for section in SECTIONS}
        self.filters = {section: tk.StringVar() for section in SECTIONS}
        self.views = {}
        self.result_queue = queue.Queue()
        self.worker = None
        self.job = None

        frame = ttk.Frame(self.win, padding=14)
        frame.pack(fill="both", expand=True)
        first = ttk.Frame(frame)
        first.pack(fill="x")
        ttk.Label(first, text="DWGファイル").pack(side="left", padx=(0, 8))
        ttk.Entry(first, textvariable=self.path, state="readonly").pack(
            side="left", fill="x", expand=True
        )
        self.browse = ttk.Button(first, text="参照…", command=self.browse_file)
        self.browse.pack(side="left", padx=5)
        self.read_button = ttk.Button(first, text="読み取る", command=self.read_file)
        self.read_button.pack(side="left")
        ttk.Label(
            frame,
            text="DWGをこの画面へドラッグ、または「参照…」で選択。AutoCADを起動してから読み取ります。",
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(5, 9))
        status_line = ttk.Frame(frame)
        status_line.pack(fill="x", pady=(0, 8))
        ttk.Label(status_line, textvariable=self.status, style="Muted.TLabel", wraplength=700).pack(
            side="left", fill="x", expand=True
        )
        self.busy = ttk.Progressbar(status_line, mode="indeterminate", length=130)
        self.busy.pack(side="right")

        self.tabs = ttk.Notebook(frame)
        self.tabs.pack(fill="both", expand=True)
        for section in SECTIONS:
            page = ttk.Frame(self.tabs, padding=8)
            self.tabs.add(page, text=TITLES[section])
            actions = ttk.Frame(page)
            actions.pack(fill="x", pady=(0, 7))
            ttk.Button(
                actions, text="すべて選択", command=lambda s=section: self.select_visible(s, True),
            ).pack(side="left", padx=4)
            ttk.Button(
                actions, text="選択を解除", command=lambda s=section: self.select_visible(s, False),
            ).pack(side="left")
            count = tk.StringVar()
            ttk.Label(actions, textvariable=count, style="Muted.TLabel").pack(side="right")
            canvas_frame = ttk.Frame(page)
            canvas_frame.pack(fill="both", expand=True)
            canvas_frame.rowconfigure(0,weight=1); canvas_frame.columnconfigure(0,weight=1)
            tree=GridTreeview(canvas_frame,columns=("check","name","detail"),show="headings",selectmode="browse",height=8)
            for key,label,width in [("check","選択",48),("name","名前",220),("detail","取得した設定",650)]:
                tree.heading(key,text=label);tree.column(key,width=width,stretch=key=="detail")
            tree.grid(row=0,column=0,sticky="nsew")
            scroll=ttk.Scrollbar(canvas_frame,command=tree.yview);scroll.grid(row=0,column=1,sticky="ns")
            horizontal=ttk.Scrollbar(canvas_frame,orient="horizontal",command=tree.xview);horizontal.grid(row=1,column=0,sticky="ew")
            tree.configure(yscrollcommand=scroll.set,xscrollcommand=horizontal.set)
            tree.bind('<Button-1>',lambda e,s=section:self.toggle_candidate(s,e))
            tree.bind('<space>',lambda e,s=section:self.toggle_candidate(s))
            pager = ttk.Frame(page)
            pager.pack(fill="x", pady=(7, 0))
            previous = ttk.Button(pager, text="◀ 前の80件",
                                  command=lambda s=section: self.change_page(s, -1))
            previous.pack(side="left")
            page_info = tk.StringVar()
            ttk.Label(pager, textvariable=page_info).pack(side="left", padx=12)
            forward = ttk.Button(pager, text="次の80件 ▶",
                                 command=lambda s=section: self.change_page(s, 1))
            forward.pack(side="left")
            self.views[section] = dict(tree=tree,count=count,page_info=page_info,back=previous,forward=forward)

        bottom=ttk.Frame(frame)
        bottom.pack(side="bottom",fill="x",before=self.tabs)
        ttk.Label(bottom,text="線種は追加ファイルを読み込まず、CAD内にある同名の線種を使用します。",style="Muted.TLabel",wraplength=740).pack(anchor="w",pady=(6,0))
        overwrite = ttk.Frame(bottom)
        overwrite.pack(fill="x", pady=(6, 2))
        ttk.Label(overwrite, text="同名の登録がある場合：").pack(side="left")
        ttk.Radiobutton(overwrite, text="既存を残す", value=False,
                        variable=self.replace).pack(side="left", padx=7)
        ttk.Radiobutton(overwrite, text="選択した定義で上書き", value=True,
                        variable=self.replace).pack(side="left")
        footer = ttk.Frame(bottom)
        footer.pack(fill="x", pady=(10, 0))
        ttk.Button(footer, text="キャンセル", command=self.close).pack(side="left")
        self.apply_button = ttk.Button(
            footer, text="チェックした項目を登録", command=self.apply, style="Primary.TButton"
        )
        self.apply_button.pack(side="right")
        self.tabs.bind("<<NotebookTabChanged>>", self.tab_changed)
        from secondary_style import surface
        surface(frame, border=True)
        self.render_section(SECTIONS[0])
        self.drop_enabled = enable_file_drop(self.win, self.accept_drop)

    def current_section(self):
        return SECTIONS[self.tabs.index(self.tabs.select())]

    def browse_file(self):
        file = filedialog.askopenfilename(
            parent=self.win, title="設定を読み取るDWG", filetypes=[("AutoCAD図面", "*.dwg")]
        )
        if file:
            self.path.set(file)

    def accept_drop(self, paths):
        if self.read_button.instate(["disabled"]) or (self.worker is not None and self.worker.is_alive()):
            self.status.set("読み取りが終わってからDWGをドロップしてください。")
            return False
        if len(paths)!=1 or Path(paths[0]).suffix.lower()!='.dwg' or not Path(paths[0]).is_file():
            self.status.set("DWGファイルを1つドロップしてください。")
            return False
        self.path.set(str(Path(paths[0])))
        self.read_file()
        return True

    def toggle_candidate(self, section, event=None):
        tree=self.views[section]['tree']
        identity=tree.identify_row(event.y) if event is not None else tree.focus()
        if not identity or (event is not None and tree.identify_column(event.x)!='#1'): return
        candidate=self.rows_for(section)[int(identity)]
        if not candidate.get('supported',True): return 'break'
        name=candidate['name']
        tree.focus(identity)
        tree.selection_set(identity)
        if name in self.checked[section]:self.checked[section].remove(name)
        else:self.checked[section].add(name)
        tree.set(identity,'check','☑' if name in self.checked[section] else '☐')
        self.update_count(section)
        return 'break'

    def read_file(self):
        if self.read_button.instate(["disabled"]) or (self.worker is not None and self.worker.is_alive()):
            return
        path = self.path.get()
        if not path:
            messagebox.showinfo("DWGを選択", "DWGファイルを指定してください", parent=self.win)
            return
        self.read_button.configure(state="disabled")
        self.browse.configure(state="disabled")
        self.apply_button.configure(state="disabled")
        self.busy.start(15)
        self.status.set("AutoCADでDWGを読み取っています。完了までお待ちください…")

        def work():
            try:
                self.result_queue.put((True, read_dwg_resources(path)))
            except Exception as exc:
                self.result_queue.put((False, str(exc)))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()
        self.job = self.win.after(100, self.poll)

    def poll(self):
        self.job = None
        if not self.win.winfo_exists():
            return
        try:
            ok, payload = self.result_queue.get_nowait()
        except queue.Empty:
            self.job = self.win.after(100, self.poll)
            return
        self.busy.stop()
        self.read_button.configure(state="normal")
        self.browse.configure(state="normal")
        self.apply_button.configure(state="normal")
        if not ok:
            self.status.set("読み取りに失敗しました")
            messagebox.showerror("DWGを読み取れません", str(payload), parent=self.win)
            return
        self.resources, issues = payload
        self.checked = {section: set() for section in SECTIONS}
        self.pages = {section: 0 for section in SECTIONS}
        for section in SECTIONS:
            self.render_section(section)
        sizes = " / ".join(f"{TITLES[s]} {len(self.resources[s])}件" for s in SECTIONS)
        self.status.set("取得完了: " + sizes + (f" / 注意 {len(issues)}件" if issues else ""))
        if issues:
            messagebox.showwarning("一部の項目を取得できません", "\n".join(issues[:12]), parent=self.win)

    def rows_for(self, section):
        keyword = self.filters[section].get().casefold().strip()
        items = self.resources[section]
        return [row for row in items if not keyword or keyword in row["name"].casefold()
                or keyword in str(row.get("note", "")).casefold()]

    def render_section(self, section):
        view = self.views[section]
        tree=view["tree"]
        tree.delete(*tree.get_children())
        candidates=self.rows_for(section)
        start=self.pages[section]*PAGE_SIZE
        if start>=len(candidates) and start:self.pages[section]=0;start=0
        for index,candidate in enumerate(candidates[start:start+PAGE_SIZE],start):
            name=candidate['name']
            detail=description(section,candidate['values'])
            if candidate.get('note'): detail+=' / '+candidate['note']
            tree.insert('', 'end', iid=str(index), values=('☑' if name in self.checked[section] else '☐',name,detail))
        view["page_info"].set(
            f"{start + 1}〜{min(start + PAGE_SIZE, len(candidates))} / {len(candidates)}件"
            if candidates else "対象なし"
        )
        view["back"].configure(state="normal" if start > 0 else "disabled")
        view["forward"].configure(
            state="normal" if start + PAGE_SIZE < len(candidates) else "disabled"
        )
        tree.yview_moveto(0)
        self.update_count(section)

    def update_count(self, section):
        self.views[section]["count"].set(
            f"取得 {len(self.resources[section])} / チェック {len(self.checked[section])}"
        )

    def change_page(self, section, direction):
        self.pages[section] += direction
        self.render_section(section)

    def reset_filter(self, section):
        self.pages[section] = 0
        self.render_section(section)

    def select_visible(self, section, checked):
        shown = self.rows_for(section)[self.pages[section] * PAGE_SIZE:
                                       (self.pages[section] + 1) * PAGE_SIZE]
        for candidate in shown:
            if candidate.get("supported", True):
                if checked:
                    self.checked[section].add(candidate["name"])
                else:
                    self.checked[section].discard(candidate["name"])
        self.render_section(section)

    def tab_changed(self, event=None):
        self.render_section(self.current_section())

    def apply(self):
        if not any(self.checked.values()):
            messagebox.showinfo("登録する項目", "登録する項目にチェックを付けてください", parent=self.win)
            return
        if not self.editor.finalize_pending():
            return
        try:
            updated = merge_selected_definitions(
                self.editor.data, self.resources, self.checked,
                overwrite=self.replace.get(),
            )
        except DWGImportError as exc:
            messagebox.showerror("登録内容の確認", str(exc), parent=self.win)
            return
        self.editor.data = updated
        for section in SECTIONS:
            self.editor.reload(section)
        count = sum(len(values) for values in self.checked.values())
        self.editor.app.status.set(
            f"DWGから{count}項目をCAD初期設定画面に取り込みました。設定を確定すると反映します。"
        )
        self.close()

    def close(self):
        if self.job is not None:
            try:
                self.win.after_cancel(self.job)
            except tk.TclError:
                pass
            self.job = None
        self.win.destroy()
        try:
            if self.editor.win.winfo_exists():
                self.editor.win.grab_set()
        except tk.TclError:
            pass
