# 1.80.1-beta133の検証

- コア全583件成功。関連GUI7ファイル・63件成功。スモーク成功。GUI全件は今回は再実行していません。
- GUI対象：test_gui_enter_confirm133（新規9件）、test_gui_preview_input、test_gui_inline_point_reference、test_gui_preview_real_click、test_gui_command_workbench、test_gui_command_points、test_gui_direct_point_candidates。
- 線分・ポリラインで3点をクリックし、最初のEnterでは点指定だけを終了し、次のEnterでコマンドを追加して窓を閉じることを実際のTkキーイベントで確認。テンキーEnterも検証。
- ブロック編集から線分を追加し、最初のEnterでは一覧に追加しないこと、次のEnterでブロックの作業内容へ追加し、ブロック確定後にUndoできることも確認。
- 点数不足時は既定値で追加しないこと、1回目のEnter後の取消でデータを変更しないこと、キーを離さない連続KeyPressだけでは追加しないことを確認。
- 点参照を保存し、元図形の端点・円中心の変更へ追従することをコンパイラで照合。
- 数値欄のEnterではコマンドを追加しないこと、MTEXTの文字欄では改行すること、WindowsのNumLock状態0x8を再現してプレビューのEnter確定を拒否しないことを検証。
- 従来の別コマンドの点選択での通常Enter・テンキーEnter、座標の連続選択、点選択の取消、Undoを維持。プレビューのクリック・スナップ・ビューポートも関連回帰を通過。
- GUIは51件の確認後、案内文調整後に新規9件と追加の関連12件を再実行し成功。重複を除いた件数が7ファイル・63件です。
- Linux / Python 3.13 / Tkで検証。Windows実操作・AutoCAD実機・EXEビルドは未確認です。

再実行例：

```text
python scripts/run_checks.py --mode core
python -m unittest discover -s tests -p test_gui_enter_confirm133.py
python -m unittest discover -s tests -p test_gui_inline_point_reference.py
python -m unittest discover -s tests -p test_gui_preview_input.py
python tests/smoke_test.py
```

GUIにはTkと表示環境が必要です。使用するPythonの版に合う依存をインストールしてください。
