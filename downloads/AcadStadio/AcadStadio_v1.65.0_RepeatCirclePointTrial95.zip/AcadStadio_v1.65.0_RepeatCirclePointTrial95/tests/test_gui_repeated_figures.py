import copy,os,sys,unittest
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class RepeatedFigures(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def edit(self,command,inspect):
  def run():
   w=gui.top(self.root,'コマンドの設定')
   try:inspect(w)
   except Exception as exc:self.errors.append(exc);w.destroy()
  self.root.after(100,run)
  result=edit_command(self.root,command,self.app.data['blocks'],self.app.data)
  self.assertEqual(self.errors,[]);return result
 def put(self,w,key,value):
  entry=w.command_entries[key];entry.delete(0,'end');entry.insert(0,value)
 def geometry(self,commands):
  p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=commands if isinstance(commands,list) else [commands])];return compile_project(p,[0])[1]
 def test_circle_plus_keeps_radius_and_adds_independent_circle(self):
  def inspect(w):
   w.figure_add_button.invoke();self.root.update()
   self.assertEqual(w.command_entries['r'].get(),'25')
   self.assertTrue(w.command_entries['x'].selection_present())
   self.put(w,'x','200');self.put(w,'r','40');w.refresh_command_preview();self.root.update()
   self.assertEqual(len(w.command_preview.canvas.items),2)
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit(dict(type='CIRCLE',x='100',y='0',r='25'),inspect)
  self.assertEqual([i['coords'] for i in self.geometry(result)],[(100,0,25),(200,0,40)])
 def test_points_plus_create_three_positions(self):
  def inspect(w):
   w.figure_add_button.invoke();self.put(w,'x','10');w.figure_add_button.invoke();self.put(w,'x','20')
   gui.button(w,'コマンドを反映').invoke()
  result=self.edit(dict(type='POINT',x='0',y='0'),inspect)
  self.assertEqual([i['coords'] for i in self.geometry(result)],[(0,0),(10,0),(20,0)])
 def test_next_circle_can_reference_previously_added_circle(self):
  def inspect(w):
   w.figure_add_button.invoke();self.root.update();w.choose_command_point('x',both=True);self.root.update()
   panel=w.point_panel;panel.point_picker.set('右');panel.point_picker.event_generate('<<ComboboxSelected>>')
   gui.use_reference_and_finish(panel);gui.button(w,'コマンドを反映').invoke()
  result=self.edit(dict(type='CIRCLE',x='100',y='0',r='25'),inspect)
  self.assertTrue(result[0].get('point_id'));self.assertIn('点(',result[1]['x'])
  self.assertEqual([i['coords'] for i in self.geometry(result)],[(100,0,25),(125,0,25)])
 def test_cancel_discards_only_next_draft_after_plus(self):
  def inspect(w):
   w.figure_add_button.invoke();self.put(w,'x','999');self.root.update()
   self.assertEqual(gui.button(w,'キャンセル').cget('text'),'キャンセル（入力中のみ）')
   gui.button(w,'キャンセル').invoke()
  result=self.edit(dict(type='POINT',x='10',y='20'),inspect)
  self.assertEqual([i['coords'] for i in self.geometry(result)],[(10,20)])
 def test_diameter_mode_keeps_size_for_next_circle(self):
  def inspect(w):
   w.figure_add_button.invoke();self.root.update()
   self.assertEqual(w.circle_mode_picker.get(),'直径')
   self.assertEqual(w.command_entries['diameter'].get(),'50')
   self.put(w,'x','150');self.put(w,'diameter','80');gui.button(w,'コマンドを反映').invoke()
  result=self.edit(dict(type='CIRCLE',circle_mode='diameter',x='100',y='0',diameter='50',r='25'),inspect)
  self.assertEqual([i['coords'] for i in self.geometry(result)],[(100,0,25),(150,0,40)])
