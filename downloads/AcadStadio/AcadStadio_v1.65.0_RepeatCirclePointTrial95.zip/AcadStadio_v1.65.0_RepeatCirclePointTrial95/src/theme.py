"""Application identity and a compact, keyboard-friendly ttk theme."""

import sys
import tkinter as tk
from tkinter import ttk, font
from pathlib import Path

APP_NAME = "AcadStadio"
APP_VERSION = "1.65.0-beta95"
ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
BG = "#f3f5f9"
INK = "#192c42"
MUTED = "#67788d"
BLUE = "#2463eb"


def apply_theme(root):
    style = ttk.Style(root)
    style.theme_use("clam")
    families = set(font.families(root))
    face = next(
        (
            x
            for x in ("Yu Gothic UI", "Meiryo", "Noto Sans CJK JP", "DejaVu Sans")
            if x in families
        ),
        "TkDefaultFont",
    )
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        font.nametofont(name).configure(family=face, size=10)
    root.configure(bg=BG)
    root.option_add("*Toplevel.background", BG)
    style.configure(".", background=BG, foreground=INK, font=(face, 10))
    style.configure("TFrame", background=BG)
    style.configure('PointCard.TFrame',borderwidth=1,relief='solid',bordercolor='#d0dbea')
    style.configure('FocusPointCard.TFrame',borderwidth=1,relief='solid',bordercolor='#2463eb')
    style.configure("Card.TFrame", background="white")
    style.configure("TLabel", background=BG)
    style.configure("Card.TLabel", background="white")
    style.configure("Muted.TLabel", foreground=MUTED)
    style.configure("Title.TLabel", font=(face, 22, "bold"))
    style.configure("Section.TLabel", font=(face, 11, "bold"))
    style.configure(
        "TButton", padding=(10, 7), background="white", borderwidth=1, relief="flat"
    )
    style.map(
        "TButton",
        background=[("active", "#e6edfb")],
        foreground=[("disabled", "#9ca8b6")],
    )
    style.configure("Compact.TButton", padding=(7, 3))
    style.configure("Compact.TMenubutton", padding=(7, 3))
    style.configure("MainIcon.TButton", padding=(3, 3), borderwidth=0, background=BG)
    style.configure("DenseMainIcon.TButton", padding=(0, 3), borderwidth=0, focusthickness=1)
    style.configure("MainIcon.TMenubutton", padding=(3, 3), width=2, background=BG, borderwidth=0)
    style.configure("DenseMainIcon.TMenubutton", padding=(0, 3), width=2, background=BG, borderwidth=0, focusthickness=1)
    style.configure("Command.Treeview", indent=0)
    style.configure("Toggle.Toolbutton", padding=(7, 3), background="white")
    style.map(
        "Toggle.Toolbutton", background=[("selected", "#dce8ff"), ("active", "#e6edfb")]
    )
    style.configure("Compact.Treeview", rowheight=28)
    style.configure("Compact.Treeview.Heading", padding=(4, 3))
    style.configure(
        "Primary.TButton", background=BLUE, foreground="white", borderwidth=0
    )
    style.map(
        "Primary.TButton",
        background=[("active", "#194fc6"), ("disabled", "#a9bce7")],
        foreground=[("disabled", "white")],
    )
    style.configure(
        "Treeview",
        background="white",
        fieldbackground="white",
        rowheight=30,
        borderwidth=0,
    )
    style.configure(
        "Treeview.Heading",
        background="#e9eef6",
        font=(face, 10, "bold"),
        padding=(6, 7),
        relief="flat",
    )
    style.map(
        "Treeview",
        background=[("selected", "#dce8ff")],
        foreground=[("selected", "#163f86")],
    )
    style.configure("TNotebook", borderwidth=0)
    style.configure("TNotebook.Tab", padding=(16, 8), font=(face, 10))
    style.map(
        "TNotebook.Tab",
        padding=[("selected", (16, 8)), ("!selected", (16, 8))],
        font=[("selected", (face, 10)), ("!selected", (face, 10))],
        background=[("selected", "white")],
        foreground=[("selected", BLUE)],
    )
    style.configure("Compact.TNotebook.Tab", padding=(10, 4))
    style.map(
        "Compact.TNotebook.Tab", padding=[("selected", (10, 4)), ("!selected", (10, 4))]
    )
    for input_style in ("TEntry", "TCombobox", "TSpinbox"):
        style.configure(input_style, padding=6, fieldbackground="white")
    style.configure("Group.TLabelframe", borderwidth=1, relief="solid", bordercolor="#94a3b8", lightcolor="#94a3b8", darkcolor="#94a3b8")
    style.configure("Group.TLabelframe.Label", font=(face, 10, "bold"), padding=(4, 0))
    style.configure("Eye.TMenubutton", padding=(3, 3), width=2, background=BG, borderwidth=0)
    style.configure("DenseCommand.TMenubutton", padding=(0, 3), width=2, background=BG, borderwidth=0, focusthickness=1)
    style.configure("Command.TMenubutton", padding=(3, 3), width=3, background=BG, borderwidth=0)
    style.configure("Compact.Primary.TButton", padding=(7, 3))
    style.configure("Preview.TFrame", background="#101d30")
    style.configure("Preview.Primary.TButton", background="#16283f", padding=(7, 3), borderwidth=1)
    style.map("Preview.Primary.TButton", background=[("active", "#294766")])
    style.configure("Preview.Toggle.Toolbutton", background="#16283f", padding=(7, 3))
    style.map("Preview.Toggle.Toolbutton", background=[("selected", "#294766"), ("active", "#25405f")])
    style.configure("TLabelframe", bordercolor="#dce3ee")
    style.configure("TLabelframe.Label", font=(face, 10, "bold"))
    try:
        root._app_icon = tk.PhotoImage(file=str(ROOT / "assets" / "acadstadio.png"))
        root.iconphoto(True, root._app_icon)
        if sys.platform == "win32":
            root.iconbitmap(str(ROOT / "assets" / "acadstadio.ico"))
    except tk.TclError:
        pass
    from workbench_style import apply_workbench_styles
    apply_workbench_styles(style,face)
    style.configure('MainCard.TFrame', background='white', borderwidth=1, relief='solid',
                    bordercolor='#d0dff0', lightcolor='#d0dff0', darkcolor='#d0dff0')
    style.configure('MainCardTitle.TLabel', background='white', font=(face,11,'bold'))
    style.configure('MainInner.TFrame', background='white')
    style.configure('MainInner.TLabel', background='white')
    style.configure('MainMuted.TLabel', background='white', foreground=MUTED, font=(face,9))
    style.configure('PreviewRowTitle.TLabel', background='#e4efff', foreground='#163f86', padding=(6,3))
    for name in ('MainIcon.TButton','DenseMainIcon.TButton','MainIcon.TMenubutton',
                 'DenseMainIcon.TMenubutton','Eye.TMenubutton'):
        style.configure('Main51.'+name, background='white', borderwidth=1, relief='solid',
                        bordercolor='#b8cbe1', lightcolor='#b8cbe1', darkcolor='#b8cbe1')
    from secondary_style import apply_secondary_styles
    apply_secondary_styles(style, face)
    return face


def modal(win, parent):
    win.transient(parent.winfo_toplevel())
    win.grab_set()
    win.bind("<Escape>", lambda e: win.event_generate("<<Cancel>>"))
    win.bind("<<Cancel>>", lambda e: win.destroy())


def fit_window(win, width, height, min_width, min_height):
    """Keep primary actions inside a typical 1366×768 Windows work area."""
    w = max(min_width, min(width, win.winfo_screenwidth() - 60))
    h = max(min_height, min(height, win.winfo_screenheight() - 100))
    x = max(0, (win.winfo_screenwidth() - w) // 2)
    y = max(0, (win.winfo_screenheight() - h - 60) // 2)
    win.geometry(f"{w}x{h}+{x}+{y}")
    win.minsize(min_width, min_height)
