# 1.76.0-beta122の検証

- 関連GUI5ファイル・29件成功。preview_input 16件、preview_real_click 2件、direct_point_candidates・command_points・select_flowの合計11件。
- 関連コア31件成功（command_points、point_candidates、preview_actions）。スモーク成功。
- 線分端点と円中心から数pxずらしたクリックでスナップし、X/Yが点参照式で保存されることを確認しました。参照元の線分始点と円中心の変更後、新規線分の両端が追従することをコンパイラで照合しています。
- ホバー時のコマンド名・点名・点参照表示と、長方形の同一点の別名統合を確認。別図形の重複候補の選択とキャンセル、自動SELECTを含む既存回帰も成功。
- 前版のX11 OSマウスイベントによる追加・2点指定・保存も通過。
- コア全件・GUI全件の今回の再実行はしていません。Linux/Tkで確認。Windows実操作・AutoCAD実機・EXEビルドは未確認です。
