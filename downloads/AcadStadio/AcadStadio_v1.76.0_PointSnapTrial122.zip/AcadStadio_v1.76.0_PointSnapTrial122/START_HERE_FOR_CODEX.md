# 現在版：1.76.0-beta122

プレビュー入力の版です。preview_shape_actions.py / preview_edit_actions.pyは純粋なコマンド生成、preview_input_ui.pyは画面指定と小入力、preview_input_handles.pyは参照を保つ差分更新、preview_input_modes.pyは安全な方式切替です。macro_editor.pyが既存のgather/redraw/historyに接続し、PointCanvasがイベントを渡します。コンパイラを描画の正本とする構成は維持します。

新規作成は画面指定を開始。既存編集は小入力＋ハンドルと「画面で指定」。詳細入力は明示的に開く方式なので、従来のフォーム表示を検証するテストは「数値・式の詳細」を開いてから検証します。SELECTの自動作成・取消の巻き戻し、モーダルのタイムアウト検証を維持してください。

評価表示はpreview_input_feedback.py。SYSVARSの構文検証はsystem_variables_ui.validate_items。表示用の日本語はlocalized_choice.pyで保存用のnumber/text/per_row/onceから分離しています。

詳しい操作・制約・検証範囲はREADME.md、docs/PREVIEW_INPUT.md、docs/VALIDATION.mdを参照。Windows/AutoCAD実機・EXE検証済みとは主張しないこと。従来のSELECT、DWG読込、レイアウト、ポリライン編集を含みます。
