# AcadStadio 1.19.2 — 2026-10-25

- アプリ名をAcadStadioへ変更。起動ファイル・アイコン・EXE名・案内資料を統一。
- 旧版の保存先と登録コマンドJSON、CAD設定復元コマンドの互換性を保持。

# CADFlow Studio 1.19.1 — 2026-10-24（JST）

- ブロックの追加・編集・作図対象切替・上下移動・削除を「ブロック一覧」タブ内へ集約。
- 「ブロック追加」はアイコンと文字で常時表示し、登録コマンド・設定/変数・構成ツリーは同じ枠内下部へ配置。
- 一覧を操作するボタンが、操作対象と同じ枠内に見える配置へ変更。
- 重複する「作図ブロック」見出しを削除し、一覧の表示領域を確保。
- フォルダ分類、作図順、JSON形式、プレビューとSCRの生成処理は維持。

検証記録は [docs/VALIDATION.md](docs/VALIDATION.md) を参照。

---

# CADFlow Studio 1.19.0 — 2026-10-24（JST）

- ブロック一覧へフォルダ・子フォルダを追加。名前変更・分類移動・複数ブロックのまとめ移動に対応。
- 折りたたみ・全展開と、ブロック名・実行条件・フォルダ名による検索を追加。
- 「順」列へ実行順番号を表示。フォルダの移動や絞り込みで作図順・対象を変えず、既存のblocks配列順で実行。
- フォルダ削除では分類だけを除去し、子フォルダ内のブロックも未分類へ戻して保持。
- フォルダ分類をプロジェクトJSON・Undo / Redoへ保存。旧JSONは未分類の一覧として継続利用。
- 構成ツリーでも同じフォルダ分類と実行順番号を表示。
- 保存モデル版11、ブロック呼び出し・設定プリセット・CAD設定復元・onedir手順を維持。

操作: [docs/BLOCK_FOLDERS.md](docs/BLOCK_FOLDERS.md)。検証記録は [docs/VALIDATION.md](docs/VALIDATION.md) を参照。

---

# CADFlow Studio 1.18.0 — 2026-10-23（JST）

- 作図の構造を「プロジェクト → ブロック → コマンド」へ統一。作図用プリセットと共通ブロックの別管理を、1つのブロック一覧へ統合。
- 「● 作図対象」は対象行ごとに一覧順で実行し、「◇ 呼び出し専用」はBLOCKコマンドから呼び出す方式へ整理。
- 条件・ローカル変数・コマンドをブロックに集約。呼び出し先は安定したIDで保持し、表示名の変更でも参照を維持。
- 保存モデル版11。旧JSONの作図条件・順序・変数・共有処理を移行し、1回だけの単純な呼び出しの中間層を取り込み。
- 編集画面・フロー・構成ツリー・検査・プレビューを統一ブロック構造へ対応。
- 文字高さなどの設定プリセット、複数表・セル編集・作業復元・アイコン・右ペイン上端のプレビュー・onedir手順を維持。

移行と操作: [docs/BLOCKS.md](docs/BLOCKS.md)。旧版のJSONは読込だけでは変更せず、保存時は新形式を使用します。旧アプリで使う必要がある場合は元のJSONを残してください。
検証の実施件数と環境は [docs/VALIDATION.md](docs/VALIDATION.md) を参照。

---

# CADFlow Studio 1.17.0 — 2026-10-22（JST）

- プレビュー／生成SCRタブを右ペイン上端へ移動し、見出し・上部情報行を削減。再生成・全体表示を下部へ移動。
- 統一した線画アイコン、キーボードでも表示するツールチップ、1段のプリセットツールバーを追加。
- 作図条件の集約、通常保存の確認削減、選択フローの展開・コマンド編集、プレビュー強調を追加。
- セル直接編集、Tab移動、Excel範囲貼り付け、単位・引き継ぎ説明、行を選べる数式試算を追加。
- 検査結果からネスト・共有ブロックを含む該当箇所へ移動。編集後の古い検査結果からの移動を防止。
- CAD設定の線種・文字スタイル・元寸法スタイルに参照候補を追加。
- ウィンドウ・タブ・倍率の復元、15秒ごとの未保存データ退避、異常終了からの復元コピーに対応。
- 小さい画面では作図設定を別窓から操作し、一覧とプレビューの領域を確保。
- モデル版10・既存JSON・システム設定復元・ACI配列・onedir手順を継続。

追加: flow.py, flow_view.py, table_edit.py, inspection.py, expression_sample.py, workspace_state.py, ui_icons.py、アイコンPNG、生成スクリプト、操作ガイド、関連検証。削除なし。

---

# CADFlow Studio 1.16.0 — 2026-10-22（JST）

- 色見本を先頭行1〜9、以後10〜19・20〜29…の10色単位に変更。末尾は250〜255。
- 同じ色相の明暗を横、色相の変化を縦に比較できる配置へ変更。
- 上下キーで同じ列の色へ移動し、空きマスを避けるよう調整。
- 小さい画面では縦スクロールし、キーボード選択色が見える位置へ追従。
- ACI保存値、線の太さ、印刷切替、onedir手順は維持。

変更: `src/cad_colors.py`, `src/theme.py`, `scripts/package_release.py`、関連テスト・ガイド・画面例。削除なし。

---

# CADFlow Studio 1.15.0 — 2026-10-22（JST）

- カラーを色名＋色見本で表示。ACI 1〜255のパレット、矢印キー/Enterでの選択、小さな選択色表示を追加。保存するACI番号は維持。
- レイヤーの線の太さを「既定（LWDEFAULT）」とmm単位の選択表示に変更。JSON内部のAutoCAD値は維持。
- 「印刷する」チェックを追加。JSONのplot真偽値と初期設定マクロのDXFコード290に反映。
- 以前の定義に印刷指定がない場合は印刷ONとして扱い、OFFの保存・編集・再読込に対応。
- 印刷OFFのGUIDEレイヤーと補助線をサンプルへ追加。
- 既存の同名定義の保護、初期設定マクロの組込ON/OFF、onedir手順を維持。

追加: `src/cad_colors.py`。
変更: `src/cad_setup.py`, `src/cad_setup_editor.py`, `src/theme.py`, `scripts/package_release.py`、関連テスト・ガイド・サンプル。削除なし。

---

# CADFlow Studio 1.14.0 — 2026-10-22（JST）

- CAD初期設定にレイヤー・文字スタイル・寸法スタイル・線種読込の4タブを追加。
- 冒頭マクロの組込ON/OFF、マクロ確認、プロジェクトJSON保存、確定・キャンセル・Undoに対応。
- 登録した名前をフローで選択可能。レイヤー・線種、TEXTの文字スタイル、DIMLINEARの寸法スタイルを指定。
- ONは未作成定義のみを依存順に作成し、作図前にCADFLOWINITを1回実行。既存定義は維持。
- OFFは初期設定マクロを省略し、名前候補を維持して既存CAD内の設定を指定可能。
- モデル版10。旧プロジェクトのレイヤー自動作成は初期設定を確定するまで維持し、確定後は既存レイヤーへの切替を使用。
- ガイド、サンプルJSON、生成SCR、初期マクロ単体、画面例を同梱。onedir手順も継続。

追加: `src/cad_setup.py`, `src/cad_setup_editor.py`, `tests/test_cad_setup.py`, `tests/test_gui_cad_setup.py`。
変更: `src/main.py`, `src/engine.py`, `src/project_model.py`, `src/macro_editor.py`, `src/theme.py`,
`scripts/package_release.py`、関連テストとドキュメント。削除なし。

---

# CADFlow Studio 1.13.0 — 2026-10-22（JST）

- 左側に常設していたプロジェクト一覧を、「プロジェクト一覧…」ボタンから開く別ウィンドウへ移動。
- 作図プリセット・プレビューと入力表へメイン画面の全幅を割り当て。
- 一覧は非モーダルで1つだけ表示。閉じる・×・Escは一覧のみを非表示にし、編集内容を維持。
- 保存・切替・名前検索・JSON管理・フォルダーと履歴の復元を継続。
- 保存や読込の確認画面が一覧ウィンドウの手前へ表示されるよう、ダイアログの親を調整。
- 最小サイズと長いフォルダー名の折返しを別窓向けに調整。

変更: `src/main.py`, `src/project_sidebar.py`, `src/theme.py`, `scripts/package_release.py`,
`tests/test_gui_projects.py`, `tests/test_gui_workspace.py`、関連ドキュメントと画面例。
追加: `docs/project-list.png`。削除なし。onedirビルド手順も継続同梱。

---

# CADFlow Studio 1.12.0 — 2026-10-22（JST）

- メイン領域を「作図」「入力表」タブに分離。起動時は作図プリセットとプレビューを並べる作図タブを表示。
- 作図設定をプリセット一覧の下に配置し、プレビューの表示領域を拡大。
- 入力表タブでは表を広く編集でき、作図タブから使用する入力表を選択可能。両タブの表選択は連動。
- 入力表編集・作図へ戻るボタンを追加。タブ切替時に対象行・設定・SCR・Undo履歴を維持。
- 表の読込後は入力表、JSON読込・新規作成後は作図を表示。
- 左側のプロジェクト一覧と結果内の作図プレビュー／生成SCRタブを維持。
- ステータスバーを画面下部に固定し、左側一覧の下部操作が隠れないようレイアウトを調整。
- 長い保存フォルダー表示を省略し、一覧下部の領域を確保。

変更: `src/main.py`, `src/project_sidebar.py`, `src/theme.py`, `scripts/package_release.py`、関連ドキュメント。
追加: `tests/test_gui_workspace.py`, `docs/input-tables.png`。削除なし。

---

# CADFlow Studio 1.11.0 — 2026-10-21

- メイン画面左端にプロジェクト一覧を追加。保存フォルダー内のJSONと外部プロジェクト履歴を表示。
- 新規・保存・JSONを開く・別名で保存・名前検索・フォルダー変更・一覧更新を配置。
- クリックまたはEnterで開き、編集中のプロジェクトと未保存状態を表示。
- フォルダーと最大100件の外部履歴をユーザー別library.jsonへ保存。EXE配置場所への書込は不要。
- 切替時の保存・破棄・キャンセル、壊れたJSON・欠落ファイルの非破壊な読込失敗に対応。
- 同じJSONを保存して読み直す際、保存後の内容を再取得するよう修正。
- 一覧設定ファイルへのプロジェクト保存を防止。一覧設定の保存失敗でもプロジェクトJSONの保存を維持。
- onedirビルド手順、システム設定復元、複数入力表、設定プリセット等を継続同梱。

変更: `src/main.py`, `src/theme.py`, `scripts/package_release.py`,
`tests/test_gui.py`, `tests/test_gui_catalog.py`、関連ドキュメント。
追加: `src/project_library.py`, `src/project_sidebar.py`,
`tests/test_project_library.py`, `tests/test_gui_projects.py`。削除なし。

---

# CADFlow Studio 1.10.0 — 2026-10-21

- 生成SCRで実行前のシステム設定を退避し、通常完了時に元の値へ戻す処理を追加。
- SNAPMODE / OSMODE / DYNMODE、現在レイヤー、色・線種・尺度、文字・寸法設定、RECTANG副作用などを対象に対応。
- 元のUCS（名前付き・名前なし）と寸法スタイル選択・寸法変数を復元。
- SYSVAR、登録SCRのSETVAR・直接変数指定・リテラルsetvarを展開後に検出。
- 登録画面に「追加の復元変数」を追加。独自コマンド内部の変更対象をJSONで保存・共有。
- 中断時用のCADFLOWRESTOREを追加。復元失敗時は退避を保持し再試行可能。
- 自動のZOOM Extentsを廃止。生成SCRにAutoLISP / command-s対応環境が必要と明示。
- onedirビルドガイド・spec、設定プリセット等の既存機能を維持。

変更: `src/engine.py`, `src/command_catalog.py`, `src/catalog_editor.py`, `src/main.py`,
`src/theme.py`, `scripts/package_release.py`、関連テスト・ドキュメント・生成例。
追加: `src/cad_state.py`, `tests/test_cad_state.py`, `docs/SYSTEM_SETTINGS_RESTORE.md`。削除なし。

---

# CADFlow Studio 1.9.0 — 2026-10-21

- 入力表・作図コマンドとは独立した「設定プリセット」を追加。サイズと任意の共通設定に対応。
- 標準3件（デフォルト・小さめ・大きめ）、カスタム最大100件。現在値から新規作成、複製、値編集、名前変更、削除。
- 登録値と現在値を並べて表示。選択のみでは変更せず、適用時に登録項目を反映し未登録項目は維持。
- 管理画面は変更を一時保持し、キャンセルですべて破棄。標準定義の編集・削除を保護。
- モデル版9へ移行。定義と適用中IDをプロジェクトJSONに保存し、Undo / Redo・変更一覧に対応。
- 旧プロジェクトは現在値を維持して移行。適用後の手動変更は「変更あり」と表示。
- onedirのEXE化ガイドとspecを引き続き同梱。

変更: `src/main.py`, `src/project_model.py`, `src/theme.py`, `scripts/package_release.py`,
`tests/test_core.py`, `tests/test_tables.py`、関連ドキュメント。
追加: `src/settings_presets.py`, `src/settings_preset_editor.py`,
`tests/test_settings_presets.py`, `tests/test_gui_settings.py`。削除なし。

---

# CADFlow Studio 1.8.0 — 2026-10-20

- 配布資料追記: `EXE_BUILD_ONEDIR.md` にWindows向けonedir EXE化コマンド、出力先、フォルダ配布手順を同梱。
- 標準タイプを9から11へ拡張（SYSVAR、CUSTOM）。一覧にないシステム変数を名前で指定可能。
- 登録コマンドの新規作成・編集・複製・削除・引数設定・SCR手順・実行回数のGUIを追加。
- レイヤー作成／切替、作図色／レイヤー色、線種変更／読込、LTSCALE／CELTSCALE、寸法スタイル作成／切替／更新など15件のJSON登録例を同梱。
- 定義・呼出・引数をプロジェクトJSONへ保存。独立したライブラリJSONの書出／読込、ID衝突の保護、重複読込の抑制。
- 各行実行／生成全体1回に対応。寸法スタイル作成／更新は1回が既定。条件成立時と反復内でも一貫して処理。
- 現在のレイヤーを使う空欄指定を標準図形へ追加。以前の明示されたレイヤー指定は維持。
- 登録コマンドの出力を診断情報として分離し、任意のSCRの図形はプレビュー対象外と表示。
- 登録ガイド、全15件ライブラリJSON、PSLTSCALEの新規登録例、作図属性のサンプルプロジェクトを追加。

この更新で変更したPythonファイル:
`src/main.py`, `src/theme.py`, `src/project_model.py`, `src/engine.py`, `src/audit.py`,
`src/macro_editor.py`, `src/preview.py`, `tests/test_core.py`, `tests/test_tables.py`,
`tests/smoke_test.py`, `scripts/package_release.py`。

追加: `src/command_catalog.py`, `src/catalog_editor.py`, `tests/test_custom_commands.py`, `tests/test_gui_catalog.py`。
削除したPythonファイルなし。118件の検証結果は `docs/VALIDATION.md` を参照。

---

# CADFlow Studio 1.7.0 — 2026-10-20

- タブの選択時だけ余白が縮む問題を修正。選択・未選択のpaddingとフォントを固定し、切替による寸法変化を防止。
- 最大100個の名前付き入力表をプロジェクトに保存。読込は新規表追加が標準。切替・空表追加・複製・改名・削除・明示的な置換に対応。
- 入力表とは別の「作図設定」を右側に表示。対象行を選択行・行番号（1-3,5）・全行から指定し、表ごとに保存。
- 「サイズ・共通設定」から文字高・寸法文字高さ・矢印サイズ・寸法尺度を編集。寸法設定はDIMTXT / DIMASZ / DIMSCALEとしてSCRへ反映。
- 旧v1.5 / v1.6 JSONをモデル版7へ移行。非アクティブ表も保存前検査し、作図対象の表・行はプレビューとSCRで共通化。
- 入力表とプリセットの操作ボタンを、表の表示領域より先に配置して常時操作できるよう調整。

この更新で変更したPythonファイル:
`src/main.py`, `src/theme.py`, `src/project_model.py`, `src/engine.py`, `src/audit.py`,
`src/macro_editor.py`, `src/project_navigator.py`, `src/sample_project.py`,
`tests/test_core.py`, `tests/test_gui.py`, `tests/smoke_test.py`, `scripts/package_release.py`。

追加: `src/project_data.py`, `tests/test_tables.py`。削除したPythonファイルなし。
検証結果は `docs/VALIDATION.md` を参照。

---

# CADFlow Studio 1.6.0 — 2026-10-20

CADScriptMaker v1.5 Trialから開発を継続したPythonソース配布版です。

## 追加・改善

- アプリ名をCADFlow Studioに変更。PNG / ICO / SVGアイコンとWindowsのアプリIDを設定。
- メイン画面を入力表・作図ルール・作図結果に整理。画面幅を超えるツールバーをメニューと文脈ごとの操作へ移動。
- 行をJSONではなくフォームで編集。追加・複製・削除、選択の維持、変更表示、ショートカットを整備。
- IF / ELSE、コマンド単位の条件、REPEAT、反復インデックスをGUI・モデル・コンパイラ・構成ツリー・監査で実装。
- 日本語フィールド名、検索できる参照式挿入、入れ子の専用編集画面、ローカル変数タブを追加。
- 作図とSCRは同じコンパイラで生成。再生成に失敗したら以前の結果を消去。回転文字と寸法位置を簡易プレビューへ反映。
- プリセット・ブロック編集を作業コピー化。キャンセルで共有データが変わる問題を解消。
- 入れ子のブロック名変更・使用箇所の検出、グループ化のUndo、切り取り後に元が変更された場合の保護を改善。
- 式の短絡評価、文字列内参照の保持、計算量制限、名前検証、隠れた分岐・未使用ブロックの構造監査を追加。
- CSVの重複・空列名・セル数不一致、Excel数式のキャッシュ欠損を明示的に検出。
- SCRの文字コード選択と原子的書込を追加。文字コード変換に失敗しても既存のSCRを保護。
- JSONの原子的保存・5世代バックアップ・詳細差分・未保存確認・プロジェクト履歴を維持。
- `.pyw` 起動ファイル、使い方、スクリーンショット、サンプルJSON / CSV / XLSX / SCR、任意の将来EXE用onedir specを追加。

## 変更した既存Pythonファイル

- `src/main.py`
- `src/engine.py`
- `src/macro_editor.py`
- `src/project_navigator.py`
- `src/project_safety.py`
- `src/audit.py`
- `tests/smoke_test.py`

## 追加したPythonファイル

- `src/project_model.py`
- `src/table_io.py`
- `src/preview.py`
- `src/theme.py`
- `src/sample_project.py`
- `tests/test_core.py`
- `tests/test_gui.py`
- `scripts/create_assets.py`
- `scripts/package_release.py`
- `CADFlow Studio.pyw`（Windows用のPython起動ファイル）

削除した `.py` ファイルはありません。
旧README・変更履歴・プロジェクト履歴は `docs/history/` に移動して保持しました。

## 検証

スモーク検証、基本処理39件、実際のTk GUI操作25件に合格しました。
Windows 11 / Python 3.11、AutoCAD実機、PyInstallerでのEXEビルドは未検証です。
詳細と制約は `docs/VALIDATION.md` と `ARCHITECTURE_AND_KNOWN_LIMITATIONS.md` を参照してください。
