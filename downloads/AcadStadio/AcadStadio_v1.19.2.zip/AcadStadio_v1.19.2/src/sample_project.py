"""A small working example that demonstrates reusable blocks and bounded repeats."""

EXAMPLE = {
    "version": 6,
    "settings": {
        "TEXT_HEIGHT": "5",
        "LAYER_OUTLINE": "OUTLINE",
        "LAYER_HOLES": "HOLES",
    },
    "globals": {"SCALE": "1"},
    "rows": [
        {
            "TYPE": "A",
            "X": "100",
            "Y": "100",
            "OD": "100",
            "PCD": "65",
            "R": "5",
            "N": "4",
        },
        {
            "TYPE": "B",
            "X": "250",
            "Y": "100",
            "OD": "120",
            "PCD": "80",
            "R": "6",
            "N": "6",
        },
        {
            "TYPE": "A",
            "X": "420",
            "Y": "100",
            "OD": "140",
            "PCD": "100",
            "R": "7",
            "N": "8",
        },
    ],
    "blocks": {
        "外形円": [
            {
                "type": "CIRCLE",
                "layer": "settings.LAYER_OUTLINE",
                "x": "@X",
                "y": "@Y",
                "r": "@OD / 2",
            }
        ]
    },
    "presets": [
        {
            "name": "01 外形を描く",
            "enabled": True,
            "condition": "",
            "variables": {},
            "commands": [{"type": "BLOCK", "name": "外形円"}],
        },
        {
            "name": "02 等配穴を描く",
            "enabled": True,
            "condition": "",
            "variables": {"PITCH_R": "@PCD / 2"},
            "commands": [
                {
                    "type": "REPEAT",
                    "count": "@N",
                    "commands": [
                        {
                            "type": "CIRCLE",
                            "layer": "settings.LAYER_HOLES",
                            "x": "@X + local.PITCH_R * cos(radians(360 * loop.index / @N))",
                            "y": "@Y + local.PITCH_R * sin(radians(360 * loop.index / @N))",
                            "r": "@R",
                        }
                    ],
                }
            ],
        },
        {
            "name": "03 種別で中心形状を切替",
            "enabled": True,
            "condition": "",
            "variables": {},
            "commands": [
                {
                    "type": "IF",
                    "condition": '@TYPE == "A"',
                    "commands": [
                        {
                            "type": "CIRCLE",
                            "layer": "CENTER",
                            "x": "@X",
                            "y": "@Y",
                            "r": "10",
                        }
                    ],
                    "else": [
                        {
                            "type": "RECTANGLE",
                            "layer": "CENTER",
                            "x1": "@X-10",
                            "y1": "@Y-10",
                            "x2": "@X+10",
                            "y2": "@Y+10",
                        }
                    ],
                }
            ],
        },
        {
            "name": "04 ラベルを添える",
            "enabled": True,
            "condition": "",
            "variables": {},
            "commands": [
                {
                    "type": "TEXT",
                    "layer": "LABEL",
                    "x": "@X-12",
                    "y": "@Y-@OD/2-14",
                    "height": "settings.TEXT_HEIGHT",
                    "angle": "0",
                    "text": "@TYPE",
                }
            ],
        },
    ],
}

from project_model import normalize_project
from project_data import upgrade_tables
from command_catalog import load_default_catalog
from cad_setup import default_setup

# Kept as a compatibility fixture for version 1–10 projects, never used by the UI.
LEGACY_EXAMPLE = upgrade_tables(EXAMPLE)
LEGACY_EXAMPLE.update(
    version=10,
    custom_commands=load_default_catalog(),
    settings_presets={},
    active_settings_preset="",
    cad_setup=default_setup(legacy=True),
)
LEGACY_EXAMPLE["input_tables"][0]["name"] = "フランジ寸法表"

EXAMPLE = normalize_project(EXAMPLE)

EXAMPLE["input_tables"][0]["name"] = "フランジ寸法表"
