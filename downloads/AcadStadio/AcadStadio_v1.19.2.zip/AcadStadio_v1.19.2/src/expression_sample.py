"""Safe, side-effect-free expression samples using the compiler's interpreter."""

from engine import convert, evaluate
from project_data import get_rows


def sample_value(project, expression, row_index=0, local_variables=None):
    rows = get_rows(project)
    row = {k: convert(v) for k, v in (rows[row_index] if rows else {}).items()}
    values = dict(
        row,
        __row__=row,
        __settings__={k: convert(v) for k, v in project.get("settings", {}).items()},
        __global__={},
        __local__={},
    )
    for scope, definitions in (
        ("__global__", project.get("globals", {})),
        ("__local__", local_variables or {}),
    ):
        for key, expr in definitions.items():
            values[scope][key] = evaluate(expr, values)
            values[key] = values[scope][key]
    return evaluate(expression, values)
