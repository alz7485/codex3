"""Bounded AST expression interpreter and deterministic AutoCAD SCR compiler."""

from project_data import get_rows
import ast
import math
import operator
import re
from functools import lru_cache
from project_model import validate_project, MAX_DEPTH, valid_name
from block_model import unified, legacy_view


class MacroError(ValueError):
    def __init__(self, message, **location):
        super().__init__(message)
        self.location = location


MAX_REPEAT = 1000
MAX_STEPS = 50000
MAX_FIGURES = 20000
ALLOWED_FUNCS = {
    "abs": abs,
    "min": min,
    "max": max,
    "round": round,
    "sqrt": math.sqrt,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "radians": math.radians,
}
OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
COMPARE = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
}
SCOPES = ("row", "global_", "local", "settings", "loop")


def bounded(value):
    if isinstance(value, str):
        if len(value) > 4096:
            raise MacroError("文字列は4096文字までです")
    elif isinstance(value, (int, float)):
        if isinstance(value, int) and value.bit_length() > 160:
            raise MacroError("計算値が大きすぎます")
        if not math.isfinite(value) or abs(value) > 1e15:
            raise MacroError("計算値は有限の±1e15以内にしてください")
    else:
        raise MacroError("数値・文字列・真偽値のみ使用できます")
    return value


@lru_cache(maxsize=1024)
def parse_expression(expr):
    if len(expr) > 2048:
        raise MacroError("式は2048文字までです")
    # Do not rewrite inside quoted strings.
    # The reference syntax is translated token-by-token with a small quote-aware scan.
    parts = re.split(r"""('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")""", expr)
    for i in range(0, len(parts), 2):
        parts[i] = re.sub(r"@([A-Za-z_][A-Za-z_0-9]*)", r"row.\1", parts[i])
        parts[i] = re.sub(r"\bglobal\.", "global_.", parts[i])
    try:
        root = ast.parse("".join(parts), mode="eval").body
    except (SyntaxError, RecursionError) as exc:
        raise MacroError("式の構文が不正: " + expr) from exc
    if sum(1 for _ in ast.walk(root)) > 256:
        raise MacroError("式が複雑すぎます")
    return root


def evaluate(expr, values):
    if isinstance(expr, (int, float, bool)):
        return bounded(expr)
    if expr is None or not str(expr).strip():
        raise MacroError("式が空です")
    source = str(expr).strip()
    root = parse_expression(source)

    def walk(node, depth=0):
        if depth > 30:
            raise MacroError("式が深すぎます")
        step = lambda n: walk(n, depth + 1)
        if isinstance(node, ast.Constant) and isinstance(
            node.value, (str, int, float, bool)
        ):
            return bounded(node.value)
        if (
            isinstance(node, ast.Attribute)
            and isinstance(node.value, ast.Name)
            and node.value.id in SCOPES
        ):
            key = "global" if node.value.id == "global_" else node.value.id
            scope = values.get("__" + key + "__", {})
            if node.attr.startswith("__") or node.attr not in scope:
                raise MacroError(f"未定義の参照: {key}.{node.attr}")
            return bounded(scope[node.attr])
        if isinstance(node, ast.Name):
            if node.id.startswith("__") or node.id in SCOPES or node.id not in values:
                raise MacroError("未定義の列/変数: " + node.id)
            return bounded(values[node.id])
        if isinstance(node, ast.BinOp) and type(node.op) in OPS:
            a, b = step(node.left), step(node.right)
            if isinstance(node.op, ast.Pow) and (
                not isinstance(b, (int, float)) or abs(b) > 100
            ):
                raise MacroError("累乗の指数は±100以内です")
            if isinstance(node.op, ast.Mult) and (
                isinstance(a, str) or isinstance(b, str)
            ):
                string, count = (a, b) if isinstance(a, str) else (b, a)
                if not isinstance(count, int) or len(string) * max(0, count) > 4096:
                    raise MacroError("文字列の計算結果が大きすぎます")
            return bounded(OPS[type(node.op)](a, b))
        if isinstance(node, ast.UnaryOp) and isinstance(
            node.op, (ast.USub, ast.UAdd, ast.Not)
        ):
            value = step(node.operand)
            return bounded(
                -value
                if isinstance(node.op, ast.USub)
                else +value
                if isinstance(node.op, ast.UAdd)
                else not value
            )
        if isinstance(node, ast.BoolOp) and isinstance(node.op, (ast.And, ast.Or)):
            for child in node.values:
                result = step(child)
                if isinstance(node.op, ast.And) and not result:
                    return result
                if isinstance(node.op, ast.Or) and result:
                    return result
            return result
        if isinstance(node, ast.Compare):
            left = step(node.left)
            for op, comp in zip(node.ops, node.comparators):
                if type(op) not in COMPARE:
                    raise MacroError("未対応の比較です")
                right = step(comp)
                if not COMPARE[type(op)](left, right):
                    return False
                left = right
            return True
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in ALLOWED_FUNCS
            and not node.keywords
        ):
            if not 1 <= len(node.args) <= 16:
                raise MacroError("関数の引数は1〜16個です")
            return bounded(ALLOWED_FUNCS[node.func.id](*[step(a) for a in node.args]))
        raise MacroError("許可されていない式: " + source)

    try:
        return walk(root)
    except MacroError:
        raise
    except (ArithmeticError, TypeError, ValueError) as exc:
        raise MacroError(f"式の評価エラー: {source}: {exc}") from exc


def number(expr, values):
    value = evaluate(expr, values)
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or abs(value) > 1e12
    ):
        raise MacroError(f"有限の数値（±1e12以内）が必要: {expr}")
    return format(value, ".12g")


def convert(value):
    if isinstance(value, (int, float, bool)):
        return bounded(value)
    if value is None:
        return ""
    source = str(value).strip()
    if re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", source):
        return bounded(float(source))
    return bounded(source)


def command_value(raw, kind, values):
    if kind == "number":
        return number(raw, values)
    value = (
        evaluate(raw[1:], values)
        if isinstance(raw, str) and raw.startswith("=")
        else raw
    )
    if type(value) not in (str, int, float, bool):
        raise MacroError("引数には数値または文字列を指定してください")
    text = format(value, ".12g") if type(value) in (int, float) else str(value)
    if len(text) > 2048 or any(ord(c) < 32 or ord(c) == 127 for c in text):
        raise MacroError("引数は改行・制御文字を含まない2048文字以内の値にしてください")
    return text


def custom_lines(definition, arguments, values):
    resolved = {
        p["name"]: command_value(
            arguments.get(
                p["name"], p.get("default", "0" if p["kind"] == "number" else "")
            ),
            p["kind"],
            values,
        )
        for p in definition.get("parameters", [])
    }
    rendered = []
    for line in definition["lines"]:
        try:
            text = line.format_map(resolved)
        except (KeyError, ValueError, IndexError) as exc:
            raise MacroError("登録コマンドの引数・波括弧を確認してください") from exc
        if len(text) > 2048 or any(ord(c) < 32 or ord(c) == 127 for c in text):
            raise MacroError(
                "展開したSCRの1行は2048文字以内で、改行・制御文字を含められません"
            )
        rendered.append(text)
    return rendered


def compile_project(project, row_indices, **kwargs):
    original = project
    event_start = len(kwargs.get("diagnostics") or [])
    modern = unified(project)
    if modern:
        if kwargs.get("validate", True):
            errors = validate_project(project)
            if errors:
                raise MacroError("\n".join(errors[:8]))
        project = legacy_view(project)
        kwargs["validate"] = False
    try:
        script, items = _compile_project(project, row_indices, **kwargs)
    except MacroError as exc:
        if modern:
            from flow import execution_address

            location = exc.location
            pi = location.pop("preset_index", None)
            location["block_index"] = pi
            if pi is not None and location.get("command_path"):
                location["address"] = execution_address(
                    original, pi, location["command_path"]
                )
        raise
    if modern:
        from flow import execution_trace

        for item in items + list(kwargs.get("diagnostics") or [])[event_start:]:
            pi = item.pop("preset_index", None)
            item["block_index"] = pi
            item["block"] = item.pop("preset", "")
            if pi is not None and item.get("command_path"):
                trace = execution_trace(original, pi, item["command_path"])
                item["command_addresses"] = trace
                at = trace[-1]
                item["definition_block_index"] = at[1]
    return script, items


def _compile_project(
    project, row_indices, *, table_id=None, validate=True, diagnostics=None
):
    if validate:
        errors = validate_project(project)
        if errors:
            raise MacroError("\n".join(errors[:8]))
    indices = list(row_indices)
    try:
        rows = get_rows(project, table_id)
    except ValueError as exc:
        raise MacroError(str(exc)) from exc
    if any(type(i) is not int or not 0 <= i < len(rows) for i in indices):
        raise MacroError("行番号が範囲外です")
    lines = ["_.UCS", "_World", "_.OSMODE", "0", "_.SNAPMODE", "0", "_.DYNMODE", "0"]
    from cad_setup import initial_macro

    try:
        lines.extend(initial_macro(project.get("cad_setup", {})))
    except ValueError as exc:
        raise MacroError(str(exc)) from exc
    previews = []
    budget = [0, 0, 0]
    diagnostics = diagnostics if diagnostics is not None else []
    once_seen = set()
    settings = {k: convert(v) for k, v in project.get("settings", {}).items()}
    for key, variable in [
        ("DIM_SCALE", "_.DIMSCALE"),
        ("DIM_TEXT_HEIGHT", "_.DIMTXT"),
        ("ARROW_SIZE", "_.DIMASZ"),
    ]:
        if key in settings:
            value = number(settings[key], {})
            if float(value) <= 0:
                raise MacroError(key + " は正の数値にしてください")
            lines += [variable, value]
    for ri in indices:
        row = {k: convert(v) for k, v in rows[ri].items()}
        globals_ = {}
        values = dict(row, __row__=row, __settings__=settings, __global__=globals_)
        values["__existing_layers_only__"] = "cad_setup" in project and not project[
            "cad_setup"
        ].get("legacy_make_layers", False)
        values["__block_definitions__"] = project.get("_block_definitions", {})
        pi = None
        try:
            for key, expr in project.get("globals", {}).items():
                globals_[key] = evaluate(expr, values)
                values[key] = globals_[key]
            for pi, preset in enumerate(project.get("presets", [])):
                if not preset.get("enabled", True):
                    continue
                cond = preset.get("condition", "").strip()
                if cond and not evaluate(cond, values):
                    continue
                local = dict(values, __local__={})
                for key, expr in preset.get("variables", {}).items():
                    local["__local__"][key] = evaluate(expr, local)
                    local[key] = local["__local__"][key]
                for ci, command in enumerate(preset.get("commands", [])):
                    start = len(previews)
                    event_start = len(diagnostics)
                    try:
                        emit(
                            command,
                            local,
                            project["blocks"],
                            lines,
                            previews,
                            ri,
                            [],
                            budget=budget,
                            path=str(ci + 1),
                            catalog=project.get("custom_commands", {}),
                            events=diagnostics,
                            once_seen=once_seen,
                            source=pi,
                        )
                    except MacroError as exc:
                        raise MacroError(
                            f"{preset.get('name', '?')} / コマンド {ci + 1}: {exc}",
                            **dict(exc.location, preset_index=pi, command_index=ci),
                        ) from exc
                    for event in diagnostics[event_start:]:
                        event.update(
                            preset=preset.get("name", ""),
                            preset_index=pi,
                            command_index=ci,
                        )
                    for item in previews[start:]:
                        item.update(
                            preset=preset.get("name", ""),
                            preset_index=pi,
                            command_index=ci,
                        )
        except MacroError as exc:
            raise MacroError(
                f"{ri + 1}行目 / {exc}",
                **dict(
                    exc.location,
                    row=ri,
                    table_id=table_id or project.get("active_table"),
                    preset_index=pi,
                ),
            ) from exc
    from cad_state import protect_script

    extra = [
        variable
        for definition in project.get("custom_commands", {}).values()
        for variable in definition.get("system_variables", [])
    ]
    return "\n".join(protect_script(lines, extra)), previews


def emit(*args, **kwargs):
    try:
        return _emit(*args, **kwargs)
    except MacroError as exc:
        exc.location.setdefault("command_path", kwargs.get("path", "1"))
        raise


def _emit(
    cmd,
    values,
    blocks,
    lines,
    previews,
    ri,
    stack,
    *,
    budget=None,
    depth=0,
    path="1",
    catalog=None,
    events=None,
    once_seen=None,
    source=0,
):
    budget = budget if budget is not None else [0]
    budget[0] += 1
    if budget[0] > MAX_STEPS:
        raise MacroError(
            "展開上限50000コマンドを超えました。対象行・反復回数を減らしてください"
        )
    if depth > MAX_DEPTH:
        raise MacroError("実行時の入れ子は12階層までです")
    typ = cmd.get("type", "").upper()
    condition = cmd.get("condition", "").strip()
    if typ != "IF" and condition and not evaluate(condition, values):
        return

    def children(commands, label, block_stack=None, child_values=None):
        for i, sub in enumerate(commands):
            emit(
                sub,
                values if child_values is None else child_values,
                blocks,
                lines,
                previews,
                ri,
                stack if block_stack is None else block_stack,
                budget=budget,
                depth=depth + 1,
                path=f"{path}/{label}/{i + 1}",
                catalog=catalog,
                events=events,
                once_seen=once_seen,
                source=source,
            )

    if typ == "IF":
        passed = bool(evaluate(condition, values))
        children(
            cmd.get("commands" if passed else "else", []), "IF" if passed else "ELSE"
        )
        return
    if typ == "REPEAT":
        count = evaluate(cmd["count"], values)
        if (
            isinstance(count, bool)
            or not isinstance(count, (int, float))
            or count != int(count)
            or not 0 <= count <= MAX_REPEAT
        ):
            raise MacroError("反復回数は0〜1000の整数にしてください")
        previous = values.get("__loop__")
        try:
            for index in range(int(count)):
                values["__loop__"] = {
                    "index": index,
                    "number": index + 1,
                    "count": int(count),
                }
                children(cmd.get("commands", []), f"REPEAT[{index}]")
        finally:
            if previous is None:
                values.pop("__loop__", None)
            else:
                values["__loop__"] = previous
        return
    if typ == "BLOCK":
        name = cmd.get("name", "")
        if name in stack:
            raise MacroError("ブロックの循環参照: " + " → ".join(stack + [name]))
        if name not in blocks:
            raise MacroError("ブロックがありません: " + name)
        definition = values.get("__block_definitions__", {}).get(name, {})
        condition = definition.get("condition", "").strip()
        if condition and not evaluate(condition, values):
            return
        context = values
        if definition.get("variables"):
            context = dict(values, __local__=dict(values.get("__local__", {})))
            for key, expression in definition["variables"].items():
                context["__local__"][key] = evaluate(expression, context)
                context[key] = context["__local__"][key]
        children(
            blocks[name],
            "BLOCK:" + name if definition else name,
            stack + [name],
            context,
        )
        return
    if typ == "SET":
        name = cmd.get("name", "")
        if not valid_name(name):
            raise MacroError("変数名が不正です")
        value = evaluate(cmd["value"], values)
        values[name] = value
        values.setdefault("__local__", {})[name] = value
        return
    if typ in ("SYSVAR", "CUSTOM"):
        definition = (catalog or {}).get(cmd.get("name"), {}) if typ == "CUSTOM" else {}
        execution = cmd.get("execution", definition.get("execution", "per_row"))
        once_key = (source, re.sub(r"REPEAT\[\d+\]", "REPEAT", path))
        if execution == "once" and once_seen is not None and once_key in once_seen:
            return
        if typ == "SYSVAR":
            name = cmd.get("name", "")
            if not isinstance(name, str) or not re.fullmatch(
                r"[A-Za-z][A-Za-z0-9_]*", name
            ):
                raise MacroError("システム変数名が不正です")
            value = command_value(cmd["value"], cmd.get("value_kind", "number"), values)
            if not value:
                raise MacroError("システム変数の値は空欄にできません")
            rendered = ["_.SETVAR", name.upper(), value]
        else:
            name = cmd.get("name", "")
            if not catalog or name not in catalog:
                raise MacroError("登録コマンドがありません: " + str(name))
            rendered = custom_lines(catalog[name], cmd.get("arguments", {}), values)
            name = catalog[name]["name"]
        if len(budget) < 3:
            budget.extend([0] * (3 - len(budget)))
        budget[1] += len(rendered)
        budget[2] += sum(len(line) for line in rendered)
        if budget[1] > 10000 or budget[2] > 2000000:
            raise MacroError(
                "システム変数・登録コマンドの出力上限（10000行 / 200万文字）を超えました"
            )
        lines.extend(rendered)
        if execution == "once" and once_seen is not None:
            once_seen.add(once_key)
        if events is not None:
            events.append(
                {
                    "type": typ,
                    "name": name,
                    "row": ri,
                    "command_path": path,
                    "lines": list(rendered),
                }
            )
        return
    if typ not in ("LINE", "CIRCLE", "RECTANGLE", "TEXT", "DIMLINEAR"):
        raise MacroError("未対応コマンド: " + typ)
    if len(previews) >= MAX_FIGURES:
        raise MacroError("図形数の上限20000を超えました")
    layer = cmd.get("layer", "0")
    if isinstance(layer, str) and (
        layer.startswith("=") or layer.startswith("settings.")
    ):
        resolved = evaluate(layer[1:] if layer.startswith("=") else layer, values)
        layer = (
            format(resolved, ".12g")
            if isinstance(resolved, (int, float)) and not isinstance(resolved, bool)
            else str(resolved)
        )
    if (
        not isinstance(layer, str)
        or len(layer) > 255
        or re.search(r'[\s";<>/\\:*?|=\x00-\x1f]', layer)
    ):
        raise MacroError('レイヤー名に空白・制御文字・記号 <>/\\:*?|="; は使えません')
    if layer:
        if values.get("__existing_layers_only__", False):
            lines += ["_.SETVAR", "CLAYER", layer]
        else:
            lines += ["_.-LAYER", "_Make", layer, ""]
    from cad_setup import cad_name

    for field, variable in (
        ("linetype", "CELTYPE"),
        ("text_style", "TEXTSTYLE"),
        ("dim_style", "DIMSTYLE"),
    ):
        if (
            field == "text_style"
            and typ != "TEXT"
            or field == "dim_style"
            and typ != "DIMLINEAR"
        ):
            continue
        style = cmd.get(field, "")
        if style:
            if not cad_name(style):
                raise MacroError("スタイル・線種名が不正です: " + str(style))
            if field == "dim_style":
                lines += ["_.-DIMSTYLE", "_Restore", style]
            else:
                lines += ["_.SETVAR", variable, style]

    def point(x, y):
        return number(cmd[x], values) + "," + number(cmd[y], values)

    def coords(*points):
        return tuple(float(z) for p in points for z in p.split(","))

    item = {
        "row": ri,
        "type": typ,
        "layer": layer or "現在のレイヤー",
        "command_path": path,
        "loop_index": values.get("__loop__", {}).get("index"),
    }
    if typ == "TEXT":
        x, y, h, angle = [
            number(cmd.get(key, default), values)
            for key, default in [
                ("x", 0),
                ("y", 0),
                ("height", "settings.TEXT_HEIGHT"),
                ("angle", 0),
            ]
        ]
        if float(h) <= 0:
            raise MacroError("文字高さは正数にしてください")
        raw = str(cmd.get("text", ""))
        content = (
            str(evaluate(raw[1:], values))
            if raw.startswith("=")
            else str(evaluate(raw, values))
            if re.fullmatch(r"@[A-Za-z_][A-Za-z_0-9]*", raw)
            else raw
        )
        if (
            not content
            or content[0].isspace()
            or any(ord(c) < 32 or ord(c) == 127 for c in content)
        ):
            raise MacroError("文字は空欄・先頭空白・改行・制御文字を使用できません")
        lines += ["_.-TEXT", "_non", x + "," + y, h, angle, content]
        item.update(
            coords=(float(x), float(y), float(h)), text=content, angle=float(angle)
        )
    elif typ == "DIMLINEAR":
        p1, p2, p3 = point("x1", "y1"), point("x2", "y2"), point("x3", "y3")
        if p1 == p2:
            raise MacroError("寸法の始点と終点は異なる位置にしてください")
        lines += ["_.DIMLINEAR", "_non", p1, "_non", p2, "_non", p3]
        item.update(coords=coords(p1, p2, p3))
    elif typ in ("LINE", "RECTANGLE"):
        p1, p2 = point("x1", "y1"), point("x2", "y2")
        if typ == "LINE" and p1 == p2:
            raise MacroError("線分の始点と終点は異なる位置にしてください")
        if typ == "RECTANGLE":
            v = coords(p1, p2)
            if v[0] == v[2] or v[1] == v[3]:
                raise MacroError("長方形の幅と高さは0以外にしてください")
        if typ == "LINE":
            lines += ["_.LINE", "_non", p1, "_non", p2, ""]
        else:
            lines += [
                "_.RECTANG",
                "_Chamfer",
                "0",
                "0",
                "_Fillet",
                "0",
                "_Width",
                "0",
                "_non",
                p1,
                "_non",
                p2,
            ]
        item.update(coords=coords(p1, p2))
    else:
        point_ = point("x", "y")
        radius = number(cmd["r"], values)
        if float(radius) <= 0:
            raise MacroError("円の半径は正数にしてください")
        lines += ["_.CIRCLE", "_non", point_, radius]
        item.update(coords=coords(point_) + (float(radius),))
    previews.append(item)
