"""Staged management of drawing-setting presets; selection never applies implicitly."""

import copy
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from settings_presets import (
    BUILTINS,
    entries,
    create_preset,
    apply_preset,
    validate_values,
)
from project_model import valid_name
from theme import fit_window


class SettingsPresetEditor:
    def __init__(self, app):
        self.app = app
        self.data = copy.deepcopy(app.data)
        self.win = tk.Toplevel(app.root)
        self.win.title("設定プリセット")
        fit_window(self.win, 820, 720, 700, 640)
        self.win.transient(app.root)
        self.win.grab_set()
        self.win.bind("<Escape>", lambda e: self.win.destroy())
        ttk.Label(
            self.win,
            text="設定値をまとめて保存・切替",
            style="Section.TLabel",
            padding=14,
        ).pack(anchor="w")
        description = ttk.Label(
            self.win,
            text="文字・寸法サイズと任意の共通設定が対象です。対象行・入力表・作図コマンドは変更しません。\n選択だけでは適用されません。適用時は登録された項目を反映し、未登録の項目は維持します。",
            wraplength=760,
            padding=(14, 0),
        )
        description.pack(anchor="w")
        list_frame = ttk.Frame(self.win)
        list_frame.pack(fill="x", padx=14, pady=10)
        self.list = ttk.Treeview(
            list_frame,
            columns=("kind", "name"),
            show="headings",
            height=4,
            selectmode="browse",
        )
        self.list.heading("kind", text="種類")
        self.list.heading("name", text="プリセット名")
        self.list.column("kind", width=100, stretch=False)
        self.list.pack(side="left", fill="x", expand=True)
        self.list.bind("<<TreeviewSelect>>", self.show_values)
        scroll = ttk.Scrollbar(list_frame, command=self.list.yview)
        scroll.pack(side="right", fill="y")
        self.list.configure(yscrollcommand=scroll.set)
        tools = ttk.Frame(self.win, padding=(14, 0))
        tools.pack(fill="x")
        for label, action in (
            ("現在値から新規作成", self.new),
            ("複製", self.duplicate),
            ("値を編集", self.edit),
            ("名前変更", self.rename),
            ("削除", self.delete),
        ):
            ttk.Button(tools, text=label, command=action).pack(side="left", padx=(0, 4))
        ttk.Label(
            self.win,
            text="選択したプリセットの値（右列は現在値）",
            padding=(14, 10, 14, 4),
        ).pack(anchor="w")
        frame = ttk.Frame(self.win, padding=(14, 0))
        frame.pack(fill="both", expand=True)
        self.values = ttk.Treeview(
            frame, columns=("key", "saved", "current"), show="headings", height=5
        )
        for col, label in (
            ("key", "設定名"),
            ("saved", "登録値"),
            ("current", "現在値"),
        ):
            self.values.heading(col, text=label)
            self.values.column(col, width=210, minwidth=70)
        self.values.pack(side="left", fill="both", expand=True)
        ttk.Scrollbar(frame, command=self.values.yview).pack(side="right", fill="y")
        self.values.configure(yscrollcommand=frame.winfo_children()[-1].set)
        notice = ttk.Label(
            self.win,
            text="標準は編集・削除できません。「複製」するとカスタムとして編集できます。\n作成・編集した内容は、下の確定ボタンで保存します。キャンセルですべて破棄します。",
            wraplength=760,
            padding=14,
            style="Muted.TLabel",
        )
        notice.pack(side="bottom", fill="x", before=frame)

        def resize(event):
            if event.widget == self.win:
                description.configure(wraplength=max(200, event.width - 28))
                notice.configure(wraplength=max(200, event.width - 28))

        self.win.bind("<Configure>", resize)
        footer = ttk.Frame(self.win, padding=(14, 0, 14, 14))
        footer.pack(side="bottom", fill="x", before=notice)
        ttk.Button(footer, text="キャンセル", command=self.win.destroy).pack(
            side="left"
        )
        ttk.Button(
            footer, text="保存して閉じる", command=lambda: self.commit(False)
        ).pack(side="right", padx=(8, 0))
        ttk.Button(
            footer,
            text="選択を適用して保存",
            style="Primary.TButton",
            command=lambda: self.commit(True),
        ).pack(side="right")
        self.reload(self.data.get("active_settings_preset") or "default")

    def selected(self):
        selected = self.list.selection()
        return selected[0] if selected else None

    def reload(self, key):
        self.list.delete(*self.list.get_children())
        for ident, preset in entries(self.data).items():
            self.list.insert(
                "",
                "end",
                iid=ident,
                values=("標準" if ident in BUILTINS else "カスタム", preset["name"]),
            )
        if key in self.list.get_children():
            self.list.selection_set(key)
            self.list.see(key)
        self.show_values()

    def show_values(self, *_):
        self.values.delete(*self.values.get_children())
        preset = entries(self.data).get(self.selected(), {})
        for key, value in preset.get("values", {}).items():
            self.values.insert(
                "",
                "end",
                values=(key, str(value), str(self.data["settings"].get(key, "未設定"))),
            )

    def ask_name(self, initial=""):
        name = simpledialog.askstring(
            "設定プリセット名",
            "プリセット名（80文字まで）",
            initialvalue=initial,
            parent=self.win,
        )
        self.win.grab_set()
        return name

    def add(self, values, initial=""):
        name = self.ask_name(initial)
        if name is None:
            return
        try:
            key = create_preset(self.data, name, values)
        except ValueError as exc:
            return messagebox.showerror("設定プリセット", str(exc), parent=self.win)
        self.reload(key)

    def new(self):
        self.add(self.data["settings"])

    def duplicate(self):
        preset = entries(self.data).get(self.selected())
        if preset:
            self.add(preset["values"], preset["name"] + " のコピー")

    def custom_key(self):
        key = self.selected()
        if key in BUILTINS:
            messagebox.showinfo(
                "標準プリセット",
                "標準は変更できません。「複製」でカスタムを作成してください。",
                parent=self.win,
            )
            return None
        return key

    def edit(self):
        key = self.custom_key()
        if not key:
            return
        values = self.app.edit_key_values(
            "設定プリセットの値",
            self.data["settings_presets"][key]["values"],
            parent=self.win,
            validator=lambda data: validate_values(data, valid_name),
        )
        self.win.grab_set()
        if values is None:
            return
        errors = validate_values(values, valid_name)
        if errors:
            return messagebox.showerror(
                "設定値の確認", "\n".join(errors[:12]), parent=self.win
            )
        self.data["settings_presets"][key]["values"] = values
        self.show_values()

    def rename(self):
        key = self.custom_key()
        if not key:
            return
        preset = self.data["settings_presets"][key]
        name = self.ask_name(preset["name"])
        if name is None:
            return
        name = name.strip()
        if (
            not name
            or len(name) > 80
            or any(p["name"] == name for k, p in entries(self.data).items() if k != key)
        ):
            return messagebox.showerror(
                "名前の確認",
                "1〜80文字の重複しない名前を指定してください。",
                parent=self.win,
            )
        preset["name"] = name
        self.reload(key)

    def delete(self):
        key = self.custom_key()
        if key and messagebox.askyesno(
            "設定プリセット削除",
            "選択したカスタムを削除しますか？ 現在の設定値は維持します。",
            parent=self.win,
        ):
            del self.data["settings_presets"][key]
            if self.data.get("active_settings_preset") == key:
                self.data["active_settings_preset"] = ""
            self.reload("default")

    def commit(self, apply):
        if apply:
            key = self.selected()
            if not key:
                return
            apply_preset(self.data, key)
        for key in ("settings", "settings_presets", "active_settings_preset"):
            self.app.data[key] = copy.deepcopy(self.data[key])
        self.win.destroy()
        self.app.refresh()
        self.app.status.set(
            "設定プリセットを適用しました" if apply else "設定プリセットを保存しました"
        )
