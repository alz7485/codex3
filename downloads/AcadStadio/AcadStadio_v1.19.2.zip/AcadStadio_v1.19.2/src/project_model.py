"""Versioned project validation shared by loading, auditing and compilation."""

import re
from project_data import upgrade_tables
from command_catalog import validate_catalog, load_default_catalog
from settings_presets import validate_presets
from cad_setup import validate_setup, default_setup, cad_name
from block_model import unified, upgrade as upgrade_blocks, legacy_view
from block_folders import validate_folders

VERSION = 11
MAX_DEPTH = 12
MAX_COMMANDS = 10000
COMMAND_TYPES = {
    "LINE",
    "CIRCLE",
    "RECTANGLE",
    "TEXT",
    "DIMLINEAR",
    "SET",
    "BLOCK",
    "IF",
    "REPEAT",
    "SYSVAR",
    "CUSTOM",
}
FIELDS = {
    "LINE": ("x1", "y1", "x2", "y2"),
    "CIRCLE": ("x", "y", "r"),
    "RECTANGLE": ("x1", "y1", "x2", "y2"),
    "TEXT": ("x", "y", "text"),
    "DIMLINEAR": ("x1", "y1", "x2", "y2", "x3", "y3"),
    "SET": ("name", "value"),
    "BLOCK": ("name",),
    "IF": ("condition",),
    "REPEAT": ("count",),
    "SYSVAR": ("name", "value"),
    "CUSTOM": ("name",),
}
RESERVED = {
    "row",
    "settings",
    "global",
    "global_",
    "local",
    "loop",
    "True",
    "False",
    "None",
    "and",
    "or",
    "not",
    "abs",
    "min",
    "max",
    "round",
    "sqrt",
    "sin",
    "cos",
    "tan",
    "radians",
}


def valid_name(name):
    return (
        isinstance(name, str)
        and bool(re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", name))
        and not name.startswith("__")
        and name not in RESERVED
    )


def walk_commands(commands):
    """Yield nested commands, including both branches; callers validate first."""
    for cmd in commands:
        yield cmd
        if cmd.get("type", "").upper() in ("IF", "REPEAT"):
            yield from walk_commands(cmd.get("commands", []))
        if cmd.get("type", "").upper() == "IF":
            yield from walk_commands(cmd.get("else", []))


def validate_project(project):
    if isinstance(project, dict):
        folder_errors = validate_folders(project)
        if folder_errors:
            return folder_errors
    if isinstance(project, dict) and project.get("version") == 11:
        if type(project["version"]) is not int:
            return ["プロジェクト版は整数で指定してください"]
        if not unified(project) or "presets" in project:
            return ["版11はblocks配列のみを使用します。presetsは旧版専用です"]
        ids, names = set(), set()
        errors = []
        for i, block in enumerate(project["blocks"]):
            if not isinstance(block, dict):
                errors.append(f"ブロック {i + 1}: 形式が不正です")
                continue
            identity, name = block.get("id"), block.get("name")
            if (
                not isinstance(identity, str)
                or not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]{0,99}", identity)
                or identity in ids
            ):
                errors.append(f"ブロック {i + 1}: IDが不正または重複しています")
            else:
                ids.add(identity)
            if (
                not isinstance(name, str)
                or not name.strip()
                or name.casefold() in names
            ):
                errors.append(f"ブロック {i + 1}: 名前が空欄または重複しています")
            else:
                names.add(name.casefold())
            if type(block.get("draw", True)) is not bool:
                errors.append(f"ブロック {i + 1}: 作図対象は真偽値で指定してください")
        if errors:
            return errors[:100]
        return [
            s.replace("プリセット ", "ブロック ")
            for s in _validate_legacy(legacy_view(project), unified_blocks=True)
        ]
    if unified(project):
        return ["blocks配列はモデル版11で指定してください"]
    return _validate_legacy(project)


def _validate_legacy(project, unified_blocks=False):
    errors = []
    if not isinstance(project, dict):
        return ["プロジェクトはJSONオブジェクトで指定してください"]
    version = project.get("version", 5)
    if type(version) is not int or not 1 <= version <= 10:
        errors.append("未対応のプロジェクト版です（対応: 1〜11）")
    for key, kind in [
        ("blocks", dict),
        ("presets", list),
        ("settings", dict),
        ("globals", dict),
    ]:
        if not isinstance(project.get(key, kind()), kind):
            errors.append(f"{key} の形式が不正です")
    if errors:
        return errors
    if not all(k in project for k in ("blocks", "presets")):
        return ["blocks / presets が必要です"]
    if "input_tables" in project:
        if "rows" in project:
            return ["rows と input_tables は同時に保存できません"]
        tables = project["input_tables"]
        if not isinstance(tables, list) or not 1 <= len(tables) <= 100:
            return ["入力表は1〜100個で指定してください"]
        ids = set()
        names = set()
        for table in tables:
            if not isinstance(table, dict):
                return ["入力表の形式が不正です"]
            table_id = table.get("id")
            name = table.get("name")
            if not isinstance(table_id, str) or not table_id or table_id in ids:
                return ["入力表IDが不正または重複しています"]
            if (
                not isinstance(name, str)
                or not name.strip()
                or name.casefold() in names
            ):
                return ["入力表の名前が空欄または重複しています"]
            ids.add(table_id)
            names.add(name.casefold())
        if (
            not isinstance(project.get("active_table"), str)
            or project.get("active_table") not in ids
        ):
            return ["作図対象の入力表がありません"]
    else:
        if "rows" not in project:
            return ["rows または input_tables が必要です"]
        tables = [{"id": "table_1", "name": "入力表1", "rows": project["rows"]}]
        ids = {"table_1"}
    for table in tables:
        rows = table.get("rows")
        if not isinstance(rows, list):
            return [table["name"] + ": 行の形式が不正です"]
        if len(rows) > 10000:
            return [table["name"] + ": 入力表は10000行までです"]
    drawing = project.get("drawing", {})
    if not isinstance(drawing, dict) or not isinstance(
        drawing.get("targets", {}), dict
    ):
        return ["作図設定の形式が不正です"]
    for key, target in drawing.get("targets", {}).items():
        if key not in ids or not isinstance(target, dict):
            return ["作図設定の入力表参照が不正です"]
        if target.get("mode") not in ("selected", "range", "all"):
            return ["対象行の指定方法が不正です"]
        if not isinstance(target.get("range", ""), str):
            return ["行番号指定は文字列で保存してください"]
        selected = target.get("selected", [])
        count = len(next(t["rows"] for t in tables if t["id"] == key))
        if (
            not isinstance(selected, list)
            or any(type(i) is not int or not 0 <= i < count for i in selected)
            or len(selected) != len(set(selected))
        ):
            return ["選択行の設定が不正です"]
    for key in ("settings", "globals"):
        for name, value in project.get(key, {}).items():
            if not valid_name(name):
                errors.append(f"{key}: 名前が不正です: {name}")
            if not isinstance(value, (str, int, float, bool)):
                errors.append(f"{key}.{name}: 値は文字列または数値で指定してください")
    for table in tables:
        for i, row in enumerate(table["rows"]):
            loc = f"{table['name']} / {i + 1}行目"
            if not isinstance(row, dict):
                errors.append(loc + ": 行はオブジェクトで指定してください")
                continue
            for name, value in row.items():
                if not valid_name(name):
                    errors.append(loc + f": 列名が不正です: {name}")
                if value is not None and not isinstance(value, (str, int, float, bool)):
                    errors.append(loc + f" / {name}: セルの形式が不正です")
    errors.extend(validate_presets(project, valid_name))
    if "cad_setup" in project:
        errors.extend(validate_setup(project["cad_setup"]))
    catalog = project.get("custom_commands", {})
    catalog_errors = validate_catalog(catalog)
    if catalog_errors:
        return list(dict.fromkeys(errors + catalog_errors))[:100]
    total = 0

    def check(commands, path, depth=0):
        nonlocal total
        if depth > MAX_DEPTH:
            errors.append(path + ": 入れ子は12階層までです")
            return
        if not isinstance(commands, list):
            errors.append(path + ": コマンドは配列で指定してください")
            return
        for i, cmd in enumerate(commands):
            total += 1
            if total > MAX_COMMANDS:
                if total == MAX_COMMANDS + 1:
                    errors.append("コマンド定義は10000件までです")
                return
            loc = f"{path} / {i + 1}"
            if not isinstance(cmd, dict):
                errors.append(loc + ": コマンド形式が不正です")
                continue
            typ = cmd.get("type")
            if not isinstance(typ, str) or typ.upper() not in COMMAND_TYPES:
                errors.append(loc + f": 未対応コマンド: {typ}")
                continue
            typ = typ.upper()
            for style_key in ("linetype", "text_style", "dim_style"):
                if not isinstance(cmd.get(style_key, ""), str):
                    errors.append(loc + ": スタイル名は文字列で指定してください")
                elif cmd.get(style_key) and not cad_name(cmd[style_key]):
                    errors.append(loc + ": スタイル・線種名が不正です")
            for field in FIELDS[typ]:
                if field not in cmd or not isinstance(
                    cmd[field], (str, int, float, bool)
                ):
                    errors.append(loc + f": {field} が必要です")
            if not isinstance(cmd.get("condition", ""), str):
                errors.append(loc + ": 条件は式で指定してください")
            if typ == "IF" and not str(cmd.get("condition", "")).strip():
                errors.append(loc + ": IF条件が空です")
            if typ == "SET" and not valid_name(cmd.get("name")):
                errors.append(loc + ": 変数名が不正です")
            if typ == "BLOCK" and (
                not isinstance(cmd.get("name"), str)
                or cmd.get("name") not in project["blocks"]
            ):
                errors.append(loc + f": 参照先ブロックがありません: {cmd.get('name')}")
            if typ in ("SYSVAR", "CUSTOM") and cmd.get("execution", "per_row") not in (
                "once",
                "per_row",
            ):
                errors.append(loc + ": 実行回数が不正です")
            if typ == "SYSVAR":
                if not isinstance(cmd.get("name"), str) or not re.fullmatch(
                    r"[A-Za-z][A-Za-z0-9_]*", cmd["name"]
                ):
                    errors.append(loc + ": システム変数名が不正です")
                if cmd.get("value_kind", "number") not in ("number", "text"):
                    errors.append(loc + ": 値の種類が不正です")
            if typ == "CUSTOM":
                name = cmd.get("name")
                arguments = cmd.get("arguments", {})
                if not isinstance(name, str) or name not in catalog:
                    errors.append(loc + ": 登録コマンドがありません: " + str(name))
                elif isinstance(catalog[name], dict) and isinstance(
                    catalog[name].get("parameters", []), list
                ):
                    allowed = {
                        p.get("name")
                        for p in catalog[name].get("parameters", [])
                        if isinstance(p, dict) and isinstance(p.get("name"), str)
                    }
                    if not isinstance(arguments, dict) or any(
                        k not in allowed or type(v) not in (str, int, float)
                        for k, v in arguments.items()
                    ):
                        errors.append(loc + ": 登録コマンドの引数が不正です")
            if typ in ("IF", "REPEAT"):
                check(cmd.get("commands", []), loc + " / 実行", depth + 1)
            if typ == "IF":
                check(cmd.get("else", []), loc + " / ELSE", depth + 1)

    for name, commands in project["blocks"].items():
        if not isinstance(name, str) or not name.strip():
            errors.append("ブロック名が空です")
        if not unified_blocks:
            check(commands, f"ブロック {name}")
    for i, preset in enumerate(project["presets"]):
        if not isinstance(preset, dict):
            errors.append(f"プリセット {i + 1}: 形式が不正です")
            continue
        path = f"プリセット {preset.get('name', i + 1)}"
        if not isinstance(preset.get("name"), str) or not preset["name"].strip():
            errors.append(path + ": 名前が空です")
        if type(preset.get("enabled", True)) is not bool:
            errors.append(path + ": enabled は真偽値です")
        if not isinstance(preset.get("condition", ""), str):
            errors.append(path + ": 条件は文字列です")
        variables = preset.get("variables", {})
        if not isinstance(variables, dict):
            errors.append(path + ": ローカル変数の形式が不正です")
        else:
            for name, value in variables.items():
                if not valid_name(name):
                    errors.append(path + f": 変数名が不正です: {name}")
                if not isinstance(value, (str, int, float, bool)):
                    errors.append(path + f": 式が不正です: {name}")
        check(preset.get("commands", []), path)
    if errors:
        return list(dict.fromkeys(errors))[:100]
    # Inspect inactive branches and unused blocks too. No unbounded recursive DFS.
    graph = {
        name: [c["name"] for c in walk_commands(cmds) if c["type"].upper() == "BLOCK"]
        for name, cmds in project["blocks"].items()
    }
    heights = {}
    call_limit = MAX_DEPTH + (1 if unified_blocks else 0)

    def visit(name, stack):
        if name in stack:
            errors.append("ブロックの循環参照: " + " → ".join(stack + [name]))
            return 0
        if len(stack) >= call_limit:
            errors.append("ブロック呼出は12階層までです: " + name)
            return 0
        if name not in heights:
            heights[name] = 1 + max(
                (visit(target, stack + [name]) for target in graph[name]), default=0
            )
        if len(stack) + heights[name] > call_limit:
            errors.append("ブロック呼出は12階層までです: " + name)
        return heights[name]

    for name in graph:
        visit(name, [])
    return list(dict.fromkeys(errors))[:100]


def normalize_project(project):
    """Upgrade a valid legacy document without mutating the supplied object."""
    errors = validate_project(project)
    if errors:
        raise ValueError("\n".join(errors[:12]))
    result = upgrade_blocks(upgrade_tables(project))
    result.pop("_block_definitions", None)
    result["version"] = VERSION
    result.setdefault("custom_commands", load_default_catalog())
    result.setdefault("settings", {})
    result.setdefault("globals", {})
    result.setdefault("settings_presets", {})
    result.setdefault("active_settings_preset", "")
    result.setdefault("cad_setup", default_setup(legacy=project.get("version", 5) < 10))
    result.setdefault("block_folders", [])
    return result
