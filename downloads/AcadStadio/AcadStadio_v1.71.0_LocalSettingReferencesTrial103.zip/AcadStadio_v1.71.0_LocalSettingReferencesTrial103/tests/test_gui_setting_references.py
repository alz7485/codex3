import copy,unittest
from unittest.mock import patch
import test_gui as gui
from macro_editor import MacroEditor
from setting_references import add_reference
from test_native_operations import project,command

class SettingReferenceGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def editor(self):
        commands=add_reference([dict(type='APPEARANCE',color='1')],0)
        commands += [dict(commands[1]),command('CIRCLE',x='0',y='0',r='10')]
        self.app.replace_document(project(commands));self.root.update()
        e=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update();return e
    def test_reference_creation_edit_and_undo_are_staged(self):
        e=self.editor();l=e.list;before=copy.deepcopy(self.app.data);l.refresh(0);l.reference_menu.invoke(0);self.root.update()
        self.assertEqual(l.commands[1]['type'],'SETTINGREF');self.assertEqual(self.app.data,before)
        l.undo();self.assertEqual(len(l.commands),4);l.redo();self.assertEqual(len(l.commands),5)
        l.refresh(1)
        def inspect():
            w=gui.top(self.root,'コマンドの設定');w.command_entries['color'].set('2');gui.button(w,'コマンドを反映').invoke()
        self.root.after(120,inspect);l.edit();self.root.update()
        self.assertEqual(l.commands[0]['color'],'2');self.assertEqual(l.commands[1]['setting_ref'],l.commands[0]['setting_id'])
        self.assertIn('コマンド1',str(l.tree.item('1','values')))
        gui.button(e.win,'ブロックを反映').invoke();self.root.update();self.assertEqual(self.app.compile()[1][-1]['color'],2)
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,before)
    def test_delete_modes_cancel_and_undo_restore_references(self):
        for label,expected in [('キャンセル',None),('参照をすべて正本化','all'),('最初の参照を正本化・残りを付け替え','first')]:
            e=self.editor();l=e.list;l.refresh(0);before=copy.deepcopy(l.commands)
            def choose(label=label):
                win=gui.top(self.root,'正本の削除');gui.button(win,label).invoke()
            self.root.after(100,choose);l.delete();self.root.update()
            if expected is None:self.assertEqual(l.commands,before);self.assertEqual(len(l.undo_stack),0)
            else:
                self.assertEqual(l.commands[0]['type'],'APPEARANCE')
                self.assertEqual(l.commands[1]['type'],'APPEARANCE' if expected=='all' else 'SETTINGREF')
                l.undo();self.assertEqual(l.commands,before);l.redo()
            self.assertIs(self.root.grab_current(),e.win);e.win.destroy();self.root.update()
    def test_copy_and_materialize(self):
        e=self.editor();l=e.list;l.tree.selection_set('0','1');l.duplicate();self.root.update()
        self.assertEqual(l.commands[3]['setting_ref'],l.commands[1]['setting_id']);self.assertNotEqual(l.commands[0]['setting_id'],l.commands[1]['setting_id'])
        l.refresh(3);l.materialize_setting_reference();self.assertEqual(l.commands[3]['type'],'APPEARANCE')
        l.undo();self.assertEqual(l.commands[3]['type'],'SETTINGREF');e.win.destroy()
    def test_removing_nested_master_during_container_edit_prompts_for_outer_refs(self):
        e=self.editor();l=e.list;master=l.commands[0]
        l.commands[:]=[dict(type='IF',condition='1',commands=[master],**{'else':[]}),l.commands[1],l.commands[2],l.commands[3]]
        l.refresh(0);before=copy.deepcopy(l.commands)
        replacement=dict(type='IF',condition='1',commands=[],**{'else':[]})
        with patch('macro_editor.edit_command',return_value=replacement),patch('setting_references.choose_deletion_mode',return_value='first') as choose:
            l.edit()
        self.assertEqual(choose.call_count,1);self.assertEqual(l.commands[1]['type'],'APPEARANCE');self.assertEqual(l.commands[2]['setting_ref'],l.commands[1]['setting_id'])
        l.undo();self.assertEqual(l.commands,before);e.win.destroy()
