"""Block-local references to non-drawing setting commands."""
import copy
import re
import uuid

REFERABLE = frozenset(('APPEARANCE', 'SYSVAR', 'SYSVARS', 'LAYEREDIT'))
REFERENCE = 'SETTINGREF'


def new_id():
    return 's_' + uuid.uuid4().hex


def walk(commands):
    for command in commands:
        if not isinstance(command, dict): continue
        yield command
        for branch in ('commands', 'else'):
            if isinstance(command.get(branch), list): yield from walk(command[branch])


def registry(commands):
    return {c['setting_id']: c for c in walk(commands)
            if c.get('type') in REFERABLE and isinstance(c.get('setting_id'), str)}


def validate(commands):
    errors, seen = [], set()
    sources = registry(commands)
    for command in walk(commands):
        identity = command.get('setting_id')
        if identity is not None:
            if command.get('type') not in REFERABLE or not isinstance(identity, str) or not re.fullmatch(r's_[a-f0-9]{32}', identity) or identity in seen:
                errors.append('設定の正本IDが不正または重複しています')
            if isinstance(identity, str): seen.add(identity)
        if command.get('type') == REFERENCE:
            target = command.get('setting_ref')
            if not isinstance(target, str) or target not in sources:
                errors.append('設定参照の正本が同じブロック内にありません')
    return errors


def resolve(command, sources):
    if command.get('type') != REFERENCE: return command
    target = sources.get(command.get('setting_ref'))
    if target is None or target.get('type') not in REFERABLE:
        raise ValueError('設定参照の正本が同じブロック内にありません')
    result = copy.deepcopy(target)
    result.pop('setting_id', None)
    return result


def add_reference(commands, index):
    result = copy.deepcopy(commands)
    source = result[index]
    if source.get('type') == REFERENCE:
        target = source.get('setting_ref')
        if target not in registry(result): raise ValueError('正本がありません')
    elif source.get('type') in REFERABLE:
        target = source.setdefault('setting_id', new_id())
    else:
        raise ValueError('参照化できるのは作図属性・システム変数・レイヤー編集です')
    result.insert(index+1, dict(type=REFERENCE, setting_ref=target))
    return result


def localize(commands, sources, *, all_independent=False):
    """Promote orphaned references in traversal order, without changing sources."""
    result = copy.deepcopy(commands)
    local = registry(result)
    promoted = {}
    def convert(items):
        for index, command in enumerate(items):
            if command.get('type') == REFERENCE:
                old = command.get('setting_ref')
                if old in local: continue
                if not all_independent and old in promoted:
                    command['setting_ref'] = promoted[old]
                else:
                    master = resolve(command, sources)
                    master['setting_id'] = new_id()
                    items[index] = master
                    if not all_independent: promoted[old] = master['setting_id']
            else:
                for branch in ('commands', 'else'):
                    if isinstance(command.get(branch), list): convert(command[branch])
    convert(result)
    return result


def delete_commands(commands, indices, mode):
    sources = registry(commands)
    kept = [c for i,c in enumerate(commands) if i not in set(indices)]
    return localize(kept, sources, all_independent=mode=='all')


def remap_copies(commands):
    """Mutate a copied command group, preserving links inside that copy."""
    mapping = {}
    for command in walk(commands):
        if command.get('setting_id'):
            old = command['setting_id']; mapping[old] = new_id(); command['setting_id'] = mapping[old]
    for command in walk(commands):
        if command.get('type') == REFERENCE:
            command['setting_ref'] = mapping.get(command.get('setting_ref'), command.get('setting_ref'))


def locate(commands, identity):
    for index, command in enumerate(commands):
        if command.get('setting_id') == identity: return commands, index
        for branch in ('commands', 'else'):
            found = locate(command.get(branch, []), identity)
            if found: return found
    return None


def choose_deletion_mode(parent, count):
    import tkinter as tk
    from tkinter import ttk
    from theme import fit_window
    win = tk.Toplevel(parent)
    win.title('正本の削除')
    win.transient(parent.winfo_toplevel())
    previous = parent.grab_current()
    result = [None]
    def close(mode=None):
        result[0] = mode; win.destroy()
    ttk.Label(win, text=f'削除する正本を使う参照が{count}件あります。\n参照の残し方を選んでください。', padding=14).pack(fill='x')
    buttons = ttk.Frame(win, padding=10); buttons.pack(fill='x')
    ttk.Button(buttons, text='参照をすべて正本化', command=lambda:close('all')).pack(fill='x', pady=3)
    ttk.Button(buttons, text='最初の参照を正本化・残りを付け替え', command=lambda:close('first')).pack(fill='x', pady=3)
    ttk.Button(buttons, text='キャンセル', command=close).pack(pady=5)
    win.protocol('WM_DELETE_WINDOW', close)
    win.bind('<Escape>', lambda e:close())
    fit_window(win, 440, 240, 360, 210)
    win.grab_set(); win.wait_window()
    if previous is not None and previous.winfo_exists(): previous.grab_set()
    return result[0]
