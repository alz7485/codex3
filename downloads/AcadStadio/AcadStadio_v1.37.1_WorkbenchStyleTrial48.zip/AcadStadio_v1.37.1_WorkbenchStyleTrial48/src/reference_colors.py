"""Colour reference-bearing input fields without changing their values."""
import io
import tokenize
from theme import INK

TABLE_COLOR = '#1759a6'
POINT_COLOR = '#7942a4'
VARIABLE_COLOR = '#16705a'


def reference_color(text, variable_names=()):
    try:
        tokens=list(tokenize.generate_tokens(io.StringIO(text.lstrip('=')).readline))
    except (tokenize.TokenError, IndentationError):
        return INK
    names={t.string for t in tokens if t.type==tokenize.NAME}
    if names.intersection(('点','点位置')):return POINT_COLOR
    if any(t.string=='@' and t.type!=tokenize.STRING for t in tokens):return TABLE_COLOR
    if names.intersection({'変数','variable','global','local','settings','loop',*variable_names}):return VARIABLE_COLOR
    return INK


def add_reference_color(entry, variable, variable_names=(), literal=False):
    def refresh(*_):
        text=variable.get()
        color=reference_color(text,variable_names) if not literal or text.startswith(('=','@')) else INK
        entry.configure(foreground=color)
    trace=variable.trace_add('write',refresh)
    def cleanup(event):
        if event.widget is entry:variable.trace_remove('write',trace)
    entry.bind('<Destroy>',cleanup,add='+')
    refresh()
