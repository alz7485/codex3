"""Editable vertex expressions shared by continuous LINE and POLYLINE commands."""
import uuid
MAX_VERTICES=1000


def vertex_id():return 'v_'+uuid.uuid4().hex


def split_top_level(text, delimiter):
    parts=[];start=0;stack=[];quote=None;escaped=False
    for i,char in enumerate(text):
        if quote:
            if escaped:escaped=False
            elif char=='\\':escaped=True
            elif char==quote:quote=None
        elif char in "\"'":quote=char
        elif char in '([{':stack.append(char)
        elif char in ')]}':
            if not stack or stack.pop()!={')':'(',']':'[','}':'{'}[char]:raise ValueError('頂点の括弧が対応していません')
        elif char==delimiter and not stack:parts.append(text[start:i].strip());start=i+1
    if stack or quote:raise ValueError('頂点の括弧または引用符が閉じていません')
    return parts+[text[start:].strip()]


def read_vertices(command):
    if 'vertices' in command:
        values=command['vertices']
        if not isinstance(values,list) or not 2<=len(values)<=MAX_VERTICES:raise ValueError('頂点は2〜1000点で指定してください')
        result=[];ids=set()
        for point in values:
            if not isinstance(point,dict) or any(type(point.get(k)) not in (str,int,float) for k in ('x','y')):raise ValueError('各点のX/Yを数値または式で指定してください')
            if any(len(str(point[k]))>2048 for k in ('x','y')):raise ValueError('各座標の式は2048文字以内にしてください')
            identity=point.get('id') or vertex_id()
            if not isinstance(identity,str) or len(identity)>80 or identity in ids:raise ValueError('頂点IDが不正または重複しています')
            ids.add(identity);result.append(dict(id=identity,x=str(point['x']),y=str(point['y'])))
        return result
    if command.get('type')=='LINE':
        pairs=[(command.get('x1','@X'),command.get('y1','@Y')),(command.get('x2','@X + 100'),command.get('y2','@Y'))]
    else:
        text=command.get('points','@X,@Y; @X + 100,@Y')
        if not isinstance(text,str) or len(text)>16384:raise ValueError('頂点の形式が不正、または16384文字を超えています')
        pairs=[split_top_level(part,',') for part in split_top_level(text,';')]
        if not 2<=len(pairs)<=MAX_VERTICES or any(len(pair)!=2 for pair in pairs):raise ValueError('頂点は X,Y; X,Y; … の形式で2〜1000点を指定してください')
    return [dict(id=vertex_id(),x=str(x),y=str(y)) for x,y in pairs]


def points_text(vertices):return '; '.join(f"{p['x']},{p['y']}" for p in vertices)


def path_midpoint(coords, closed=False):
    import math
    points=list(zip(coords[::2],coords[1::2]))
    if closed:points.append(points[0])
    lengths=[math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(points,points[1:])]
    remaining=sum(lengths)/2
    for a,b,length in zip(points,points[1:],lengths):
        if remaining<=length and length:
            t=remaining/length;return (a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t)
        remaining-=length
    return points[0]
