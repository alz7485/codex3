"""Bounded AST expression interpreter and deterministic AutoCAD SCR compiler."""

from project_data import get_rows, current_table
import ast
import math
import operator
import re
from functools import lru_cache
from project_model import validate_project, MAX_DEPTH, valid_name
from block_model import unified, legacy_view
from table_references import expand_table_references, is_single_table_reference
from table_formulas import DeferredCell, RowResolver
from command_types import DRAWING_TYPES, DIMENSION_TYPES


class MacroError(ValueError):
    def __init__(self, message, **location):
        super().__init__(message)
        self.location = location


MAX_REPEAT = 1000
MAX_STEPS = 50000
MAX_FIGURES = 20000
ALLOWED_FUNCS = {
    "点": None,
    "点位置": None,
    "abs": abs,
    "min": min,
    "max": max,
    "round": round,
    "sqrt": math.sqrt,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "radians": math.radians,
}
OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
COMPARE = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
}
SCOPES = ("row", "global_", "variable", "変数", "local", "settings", "loop")


def bounded(value):
    if isinstance(value, DeferredCell):
        return bounded(value.resolve())
    if isinstance(value, str):
        if len(value) > 4096:
            raise MacroError("文字列は4096文字までです")
    elif isinstance(value, (int, float)):
        if isinstance(value, int) and value.bit_length() > 160:
            raise MacroError("計算値が大きすぎます")
        if not math.isfinite(value) or abs(value) > 1e15:
            raise MacroError("計算値は有限の±1e15以内にしてください")
    else:
        raise MacroError("数値・文字列・真偽値のみ使用できます")
    return value


@lru_cache(maxsize=1024)
def parse_expression(expr):
    if len(expr) > 2048:
        raise MacroError("式は2048文字までです")
    # Do not rewrite inside quoted strings.
    # The reference syntax is translated token-by-token with a small quote-aware scan.
    expr = expand_table_references(expr)
    parts = re.split(r"""('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")""", expr)
    for i in range(0, len(parts), 2):
        parts[i] = re.sub(r"@([^\W\d]\w*)", r"row.\1", parts[i])
        parts[i] = re.sub(r"\bglobal\.", "global_.", parts[i])
    try:
        root = ast.parse("".join(parts), mode="eval").body
    except (SyntaxError, RecursionError) as exc:
        raise MacroError("式の構文が不正: " + expr) from exc
    if sum(1 for _ in ast.walk(root)) > 256:
        raise MacroError("式が複雑すぎます")
    return root


def evaluate(expr, values):
    if isinstance(expr, (int, float, bool)):
        return bounded(expr)
    if expr is None or not str(expr).strip():
        raise MacroError("式が空です")
    source = str(expr).strip()
    root = parse_expression(source)

    def walk(node, depth=0):
        if depth > 30:
            raise MacroError("式が深すぎます")
        step = lambda n: walk(n, depth + 1)
        if isinstance(node, ast.Constant) and isinstance(
            node.value, (str, int, float, bool)
        ):
            return bounded(node.value)
        if (
            isinstance(node, ast.Attribute)
            and isinstance(node.value, ast.Name)
            and node.value.id in SCOPES
        ):
            key = {
                "global_": "global", "variable": "global", "変数": "global",
            }.get(node.value.id, node.value.id)
            field = node.attr
            scope = values.get("__" + key + "__", {})
            if field.startswith("__") or field not in scope:
                raise MacroError(f"未定義の参照: {node.value.id}.{node.attr}")
            return bounded(scope[field])
        if isinstance(node, ast.Name):
            if values.get("__in_table_formula__") and node.id in values.get("__row__", {}):
                return bounded(values["__row__"][node.id])
            if node.id.startswith("__") or node.id in SCOPES or node.id not in values:
                scope = values.get("__global__", {})
                if not node.id.startswith("__") and node.id not in SCOPES and node.id in scope:
                    return bounded(scope[node.id])
                raise MacroError("未定義の列/変数: " + node.id)
            return bounded(values[node.id])
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "__table_cell__"
            and len(node.args) in (2, 3)
            and not node.keywords
            and all(isinstance(a, ast.Constant) and isinstance(a.value, str)
                    for a in node.args[:2])
        ):
            table_name, column = (a.value for a in node.args[:2])
            tables = values.get("__tables__", {})
            if not tables:
                raise MacroError("入力表を参照できる作図・試算の中で使用してください")
            table = tables.get((table_name or values.get("__active_table_name__", "")).casefold())
            if table is None:
                raise MacroError(f"入力表が見つかりません: {table_name}")
            index = values.get("__current_row_index__", 0) + 1
            if len(node.args) == 3:
                selected = step(node.args[2])
                if (isinstance(selected, bool) or not isinstance(selected, (int, float))
                        or not float(selected).is_integer()):
                    raise MacroError(f"行番号は1以上の整数にしてください: {selected}")
                index = int(selected)
            if not 1 <= index <= len(table):
                raise MacroError(f"{table_name or values.get('__active_table_name__', '入力表')} の行番号 {index} は範囲外（1〜{len(table)}）です")
            resolver = values.get("__cell_resolver__")
            if resolver is None and column not in table[index - 1]:
                raise MacroError(f"{table_name or values.get('__active_table_name__', '入力表')} の{index}行目に列 {column} がありません")
            if resolver is not None:
                return bounded(resolver(table_name or values["__active_table_name__"], index - 1, column))
            return convert(table[index - 1][column])
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in ("点", "点位置"):
            expected = 3 if node.func.id == "点" else 2
            count_ok = len(node.args) == 3 if expected == 3 else len(node.args) in (2, 4)
            literal_args = node.args[:3] if expected == 3 else node.args[:2]
            if node.keywords or not count_ok or not all(isinstance(arg, ast.Constant) and isinstance(arg.value, str) for arg in literal_args):
                raise MacroError('点参照は 点("コマンドID", "始点/中点/終点", "X/Y") で指定してください')
            identity, point_name = [arg.value for arg in node.args[:2]]
            axis = node.args[2].value if expected == 3 else None
            points = values.get("__all_command_points__" if "/" in identity else "__command_points__", {}).get(identity)
            if points is None:
                raise MacroError("参照先の点がありません。先に作図するブロック/コマンドを指定してください（削除・順序・条件も確認）。")
            if point_name not in points or axis not in (None, "X", "Y"):
                raise MacroError("参照先にない点、またはX/Y以外の座標が指定されています")
            if axis is None:
                x, y = points[point_name]
                if len(node.args) == 4:
                    dx, dy = [step(arg) for arg in node.args[2:]]
                    if type(dx) not in (int, float) or type(dy) not in (int, float):
                        raise MacroError("点のずらし量は数値で指定してください")
                    x, y = bounded(x+dx), bounded(y+dy)
                return f"{x:.12g},{y:.12g}"
            return bounded(points[point_name][0 if axis == "X" else 1])
        if isinstance(node, ast.BinOp) and type(node.op) in OPS:
            a, b = step(node.left), step(node.right)
            if isinstance(node.op, ast.Pow) and (
                not isinstance(b, (int, float)) or abs(b) > 100
            ):
                raise MacroError("累乗の指数は±100以内です")
            if isinstance(node.op, ast.Mult) and (
                isinstance(a, str) or isinstance(b, str)
            ):
                string, count = (a, b) if isinstance(a, str) else (b, a)
                if not isinstance(count, int) or len(string) * max(0, count) > 4096:
                    raise MacroError("文字列の計算結果が大きすぎます")
            return bounded(OPS[type(node.op)](a, b))
        if isinstance(node, ast.UnaryOp) and isinstance(
            node.op, (ast.USub, ast.UAdd, ast.Not)
        ):
            value = step(node.operand)
            return bounded(
                -value
                if isinstance(node.op, ast.USub)
                else +value
                if isinstance(node.op, ast.UAdd)
                else not value
            )
        if isinstance(node, ast.BoolOp) and isinstance(node.op, (ast.And, ast.Or)):
            for child in node.values:
                result = step(child)
                if isinstance(node.op, ast.And) and not result:
                    return result
                if isinstance(node.op, ast.Or) and result:
                    return result
            return result
        if isinstance(node, ast.Compare):
            left = step(node.left)
            for op, comp in zip(node.ops, node.comparators):
                if type(op) not in COMPARE:
                    raise MacroError("未対応の比較です")
                right = step(comp)
                if not COMPARE[type(op)](left, right):
                    return False
                left = right
            return True
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in ALLOWED_FUNCS
            and not node.keywords
        ):
            if not 1 <= len(node.args) <= 16:
                raise MacroError("関数の引数は1〜16個です")
            return bounded(ALLOWED_FUNCS[node.func.id](*[step(a) for a in node.args]))
        raise MacroError("許可されていない式: " + source)

    try:
        return walk(root)
    except MacroError:
        raise
    except (ArithmeticError, TypeError, ValueError) as exc:
        raise MacroError(f"式の評価エラー: {source}: {exc}") from exc


def number(expr, values):
    value = evaluate(expr, values)
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or abs(value) > 1e12
    ):
        raise MacroError(f"有限の数値（±1e12以内）が必要: {expr}")
    return format(value, ".12g")


def polyline_expressions(text):
    """Bounded X,Y pairs separated by semicolons outside references/functions."""
    if not isinstance(text, str) or not 1 <= len(text) <= 16384:
        raise MacroError("ポリラインの頂点は文字列（16384文字以内）で指定してください")
    parts, start, stack, quote, escaped = [], 0, [], None, False
    for i, char in enumerate(text):
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
        elif char in "\"'":
            quote = char
        elif char in "([{":
            stack.append(char)
        elif char in ")]}":
            if not stack or stack.pop() != {")": "(", "]": "[", "}": "{"}[char]:
                raise MacroError("頂点の括弧が対応していません")
        elif char == ";" and not stack:
            parts.append(text[start:i]); start = i + 1
    parts.append(text[start:])
    if quote or stack or not 2 <= len(parts) <= 1000:
        raise MacroError("頂点は X,Y; X,Y; … の形式で2〜1000点を指定してください")
    result = []
    for part in parts:
        node = parse_expression(part.strip())
        if not isinstance(node, ast.Tuple) or len(node.elts) != 2:
            raise MacroError("各頂点は X,Y の2座標で指定してください")
        result.append(tuple(ast.unparse(value) for value in node.elts))
    return result


def convert(value):
    if isinstance(value, (int, float, bool)):
        return bounded(value)
    if value is None:
        return ""
    source = str(value).strip()
    if re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", source):
        return bounded(float(source))
    return bounded(source)


def row_values(project, row_index=0, table_id=None, resolver=None):
    resolver = resolver or RowResolver(project, convert, evaluate, MacroError)
    table = current_table(project, table_id)
    return resolver.context(table["name"], row_index, eager=True)


def command_value(raw, kind, values):
    if kind == "number":
        return number(raw, values)
    value = (
        evaluate(raw[1:], values)
        if isinstance(raw, str) and raw.startswith("=")
        else raw
    )
    if type(value) not in (str, int, float, bool):
        raise MacroError("引数には数値または文字列を指定してください")
    text = format(value, ".12g") if type(value) in (int, float) else str(value)
    if len(text) > 2048 or any(ord(c) < 32 or ord(c) == 127 for c in text):
        raise MacroError("引数は改行・制御文字を含まない2048文字以内の値にしてください")
    return text


def custom_lines(definition, arguments, values):
    resolved = {
        p["name"]: command_value(
            arguments.get(
                p["name"], p.get("default", "0" if p["kind"] == "number" else "")
            ),
            p["kind"],
            values,
        )
        for p in definition.get("parameters", [])
    }
    rendered = []
    for line in definition["lines"]:
        try:
            text = line.format_map(resolved)
        except (KeyError, ValueError, IndexError) as exc:
            raise MacroError("登録コマンドの引数・波括弧を確認してください") from exc
        if len(text) > 2048 or any(ord(c) < 32 or ord(c) == 127 for c in text):
            raise MacroError(
                "展開したSCRの1行は2048文字以内で、改行・制御文字を含められません"
            )
        rendered.append(text)
    return rendered


def compile_project(project, row_indices, **kwargs):
    original = project
    event_start = len(kwargs.get("diagnostics") or [])
    modern = unified(project)
    if modern:
        if kwargs.get("validate", True):
            errors = validate_project(project)
            if errors:
                raise MacroError("\n".join(errors[:8]))
        project = legacy_view(project)
        kwargs["validate"] = False
    try:
        script, items = _compile_project(project, row_indices, **kwargs)
    except MacroError as exc:
        if modern:
            from flow import execution_address

            location = exc.location
            pi = location.pop("preset_index", None)
            location["block_index"] = pi
            if pi is not None and location.get("command_path"):
                location["address"] = execution_address(
                    original, pi, location["command_path"]
                )
        raise
    if modern:
        from flow import execution_trace

        for item in items + list(kwargs.get("diagnostics") or [])[event_start:]:
            pi = item.pop("preset_index", None)
            item["block_index"] = pi
            item["block"] = item.pop("preset", "")
            if pi is not None and item.get("command_path"):
                trace = execution_trace(original, pi, item["command_path"])
                item["command_addresses"] = trace
                at = trace[-1]
                item["definition_block_index"] = at[1]
    return script, items


def _compile_project(
    project, row_indices, *, table_id=None, validate=True, diagnostics=None
):
    if validate:
        errors = validate_project(project)
        if errors:
            raise MacroError("\n".join(errors[:8]))
    indices = list(row_indices)
    try:
        rows = get_rows(project, table_id)
    except ValueError as exc:
        raise MacroError(str(exc)) from exc
    if any(type(i) is not int or not 0 <= i < len(rows) for i in indices):
        raise MacroError("行番号が範囲外です")
    lines = ["_.UCS", "_World", "_.OSMODE", "0", "_.SNAPMODE", "0", "_.DYNMODE", "0"]
    from cad_setup import initial_macro

    try:
        lines.extend(initial_macro(project.get("cad_setup", {})))
    except ValueError as exc:
        raise MacroError(str(exc)) from exc
    previews = []
    budget = [0, 0, 0]
    diagnostics = diagnostics if diagnostics is not None else []
    once_seen = set()
    settings = {k: convert(v) for k, v in project.get("settings", {}).items()}
    resolver = RowResolver(project, convert, evaluate, MacroError)
    for key, variable in [
        ("DIM_SCALE", "_.DIMSCALE"),
        ("DIM_TEXT_HEIGHT", "_.DIMTXT"),
        ("ARROW_SIZE", "_.DIMASZ"),
    ]:
        if key in settings:
            value = number(settings[key], {})
            if float(value) <= 0:
                raise MacroError(key + " は正の数値にしてください")
            lines += [variable, value]
    appearance = {}
    for ri in indices:
        values = resolver.context(current_table(project, table_id)["name"], ri)
        values["__appearance__"] = appearance
        values["__all_command_points__"] = {}
        values["__existing_layers_only__"] = "cad_setup" in project and not project[
            "cad_setup"
        ].get("legacy_make_layers", False)
        values["__block_definitions__"] = project.get("_block_definitions", {})
        pi = None
        try:
            for key, expr in project.get("globals", {}).items():
                values[key] = values["__global__"][key]
            for pi, preset in enumerate(project.get("presets", [])):
                if not preset.get("enabled", True):
                    continue
                cond = preset.get("condition", "").strip()
                if cond and not evaluate(cond, values):
                    continue
                local = dict(values, __local__={}, __command_points__={}, __point_block_id__=preset.get("id", f"legacy_{pi}"))
                guide = bool(preset.get("guide"))
                if guide:
                    local["__appearance__"] = {}
                output_lines = [] if guide else lines
                for key, expr in preset.get("variables", {}).items():
                    local["__local__"][key] = evaluate(expr, local)
                    local[key] = local["__local__"][key]
                for ci, command in enumerate(preset.get("commands", [])):
                    start = len(previews)
                    event_start = len(diagnostics)
                    try:
                        emit(
                            command,
                            local,
                            project["blocks"],
                            output_lines,
                            previews,
                            ri,
                            [],
                            budget=budget,
                            path=str(ci + 1),
                            catalog=project.get("custom_commands", {}),
                            events=diagnostics,
                            once_seen=once_seen,
                            source=pi,
                        )
                    except MacroError as exc:
                        raise MacroError(
                            f"{preset.get('name', '?')} / コマンド {ci + 1}: {exc}",
                            **dict(exc.location, preset_index=pi, command_index=ci),
                        ) from exc
                    for event in diagnostics[event_start:]:
                        event.update(
                            preset=preset.get("name", ""),
                            preset_index=pi,
                            command_index=ci,
                        )
                    for item in previews[start:]:
                        if guide:
                            item["guide"] = True
                        item.update(
                            preset=preset.get("name", ""),
                            preset_index=pi,
                            command_index=ci,
                        )
        except MacroError as exc:
            raise MacroError(
                f"{ri + 1}行目 / {exc}",
                **dict(
                    exc.location,
                    row=ri,
                    table_id=table_id or project.get("active_table"),
                    preset_index=pi,
                ),
            ) from exc
    from cad_state import protect_script

    extra = [
        variable
        for definition in project.get("custom_commands", {}).values()
        for variable in definition.get("system_variables", [])
    ]
    return "\n".join(protect_script(lines, extra)), previews


def emit(*args, **kwargs):
    try:
        return _emit(*args, **kwargs)
    except MacroError as exc:
        exc.location.setdefault("command_path", kwargs.get("path", "1"))
        raise


def _emit(
    cmd,
    values,
    blocks,
    lines,
    previews,
    ri,
    stack,
    *,
    budget=None,
    depth=0,
    path="1",
    catalog=None,
    events=None,
    once_seen=None,
    source=0,
):
    budget = budget if budget is not None else [0]
    budget[0] += 1
    if budget[0] > MAX_STEPS:
        raise MacroError(
            "展開上限50000コマンドを超えました。対象行・反復回数を減らしてください"
        )
    if depth > MAX_DEPTH:
        raise MacroError("実行時の入れ子は12階層までです")
    typ = cmd.get("type", "").upper()
    def forget_points(command):
        if command.get("point_id"):
            values.setdefault("__command_points__", {}).pop(command["point_id"], None)
            values.setdefault("__all_command_points__", {}).pop(str(values.get("__point_block_id__", ""))+"/"+command["point_id"], None)
        for child in command.get("commands", []) + command.get("else", []):
            forget_points(child)
    forget_points(cmd)
    condition = cmd.get("condition", "").strip()
    if typ != "IF" and condition and not evaluate(condition, values):
        return

    def children(commands, label, block_stack=None, child_values=None):
        for i, sub in enumerate(commands):
            emit(
                sub,
                values if child_values is None else child_values,
                blocks,
                lines,
                previews,
                ri,
                stack if block_stack is None else block_stack,
                budget=budget,
                depth=depth + 1,
                path=f"{path}/{label}/{i + 1}",
                catalog=catalog,
                events=events,
                once_seen=once_seen,
                source=source,
            )

    if typ == "IF":
        passed = bool(evaluate(condition, values))
        children(
            cmd.get("commands" if passed else "else", []), "IF" if passed else "ELSE"
        )
        return
    if typ == "REPEAT":
        count = evaluate(cmd["count"], values)
        if (
            isinstance(count, bool)
            or not isinstance(count, (int, float))
            or count != int(count)
            or not 0 <= count <= MAX_REPEAT
        ):
            raise MacroError("反復回数は0〜1000の整数にしてください")
        previous = values.get("__loop__")
        try:
            for index in range(int(count)):
                values["__loop__"] = {
                    "index": index,
                    "number": index + 1,
                    "count": int(count),
                }
                children(cmd.get("commands", []), f"REPEAT[{index}]")
        finally:
            if previous is None:
                values.pop("__loop__", None)
            else:
                values["__loop__"] = previous
        return
    if typ == "BLOCK":
        name = cmd.get("name", "")
        if name in stack:
            raise MacroError("ブロックの循環参照: " + " → ".join(stack + [name]))
        if name not in blocks:
            raise MacroError("ブロックがありません: " + name)
        definition = values.get("__block_definitions__", {}).get(name, {})
        condition = definition.get("condition", "").strip()
        if condition and not evaluate(condition, values):
            return
        context = values
        if definition.get("variables"):
            context = dict(values, __local__=dict(values.get("__local__", {})))
            for key, expression in definition["variables"].items():
                context["__local__"][key] = evaluate(expression, context)
                context[key] = context["__local__"][key]
        children(
            blocks[name],
            "BLOCK:" + name if definition else name,
            stack + [name],
            context,
        )
        return
    if typ == "SET":
        name = cmd.get("name", "")
        if not valid_name(name):
            raise MacroError("変数名が不正です")
        value = evaluate(cmd["value"], values)
        values[name] = value
        values.setdefault("__local__", {})[name] = value
        return
    if typ in ("SYSVAR", "CUSTOM"):
        definition = (catalog or {}).get(cmd.get("name"), {}) if typ == "CUSTOM" else {}
        execution = cmd.get("execution", definition.get("execution", "per_row"))
        once_key = (source, re.sub(r"REPEAT\[\d+\]", "REPEAT", path))
        if execution == "once" and once_seen is not None and once_key in once_seen:
            return
        if typ == "SYSVAR":
            name = cmd.get("name", "")
            if not isinstance(name, str) or not re.fullmatch(
                r"[A-Za-z][A-Za-z0-9_]*", name
            ):
                raise MacroError("システム変数名が不正です")
            value = command_value(cmd["value"], cmd.get("value_kind", "number"), values)
            if not value:
                raise MacroError("システム変数の値は空欄にできません")
            rendered = ["_.SETVAR", name.upper(), value]
        else:
            name = cmd.get("name", "")
            if not catalog or name not in catalog:
                raise MacroError("登録コマンドがありません: " + str(name))
            rendered = custom_lines(catalog[name], cmd.get("arguments", {}), values)
            name = catalog[name]["name"]
        if len(budget) < 3:
            budget.extend([0] * (3 - len(budget)))
        budget[1] += len(rendered)
        budget[2] += sum(len(line) for line in rendered)
        if budget[1] > 10000 or budget[2] > 2000000:
            raise MacroError(
                "システム変数・登録コマンドの出力上限（10000行 / 200万文字）を超えました"
            )
        lines.extend(rendered)
        appearance = values.setdefault("__appearance__", {})
        if typ == "SYSVAR" and name.upper() == "CLAYER":
            appearance["effective_layer"] = str(value).strip().strip('"')
        elif typ == "SYSVAR" and name.upper() == "CELTYPE":
            appearance["linetype"] = str(value).strip().strip('"')
        elif typ == "SYSVAR" and name.upper() in ("CECOLOR", "CELTSCALE"):
            field = "color" if name.upper() == "CECOLOR" else "linetype_scale"
            appearance.pop(field, None)
            text = str(value).strip().strip('"')
            try:
                parsed = float({"bylayer": "256", "byblock": "0"}.get(text.casefold(), text))
                if field == "color" and parsed.is_integer() and 0 <= parsed <= 256:
                    appearance[field] = int(parsed)
                elif field == "linetype_scale" and 0 < parsed <= 1e12:
                    appearance[field] = parsed
            except ValueError:
                pass
        elif typ == "CUSTOM":
            changed = {v.upper() for v in catalog[cmd["name"]].get("system_variables", [])}
            for variable, field in (("CECOLOR", "color"), ("CELTSCALE", "linetype_scale"), ("CELTYPE", "linetype"), ("CLAYER", "effective_layer")):
                if variable in changed:
                    appearance.pop(field, None)
        if execution == "once" and once_seen is not None:
            once_seen.add(once_key)
        if events is not None:
            events.append(
                {
                    "type": typ,
                    "name": name,
                    "row": ri,
                    "command_path": path,
                    "lines": list(rendered),
                }
            )
        return
    if typ not in DRAWING_TYPES:
        raise MacroError("未対応コマンド: " + typ)
    if len(previews) >= MAX_FIGURES:
        raise MacroError("図形数の上限20000を超えました")
    layer = cmd.get("layer", "0")
    if isinstance(layer, str) and (
        layer.startswith("=") or layer.startswith("settings.")
    ):
        resolved = evaluate(layer[1:] if layer.startswith("=") else layer, values)
        layer = (
            format(resolved, ".12g")
            if isinstance(resolved, (int, float)) and not isinstance(resolved, bool)
            else str(resolved)
        )
    from cad_setup import cad_name, script_cad_name

    if not isinstance(layer, str) or (layer and not cad_name(layer)):
        raise MacroError('レイヤー名に制御文字・記号 <>/\\:*?|="; は使えません')
    if layer:
        if values.get("__existing_layers_only__", False):
            lines += ["_.SETVAR", "CLAYER", script_cad_name(layer)]
        else:
            lines += ["_.-LAYER", "_Make", script_cad_name(layer), ""]

    appearance = values.setdefault("__appearance__", {})
    if layer:
        appearance["effective_layer"] = layer
    for field, variable in (
        ("linetype", "CELTYPE"),
        ("text_style", "TEXTSTYLE"),
        ("dim_style", "DIMSTYLE"),
    ):
        if (
            field == "text_style"
            and typ != "TEXT"
            or field == "dim_style"
            and typ not in DIMENSION_TYPES
        ):
            continue
        style = cmd.get(field, "")
        if style:
            if not cad_name(style):
                raise MacroError("スタイル・線種名が不正です: " + str(style))
            if field == "dim_style":
                lines += ["_.-DIMSTYLE", "_Restore", script_cad_name(style)]
            else:
                lines += ["_.SETVAR", variable, script_cad_name(style)]
                if field == "linetype":
                    appearance["linetype"] = style

    appearance = values.setdefault("__appearance__", {})
    raw_color = cmd.get("color", "")
    if str(raw_color).strip():
        color_text = str(raw_color).strip()
        color = float(number({"bylayer": "256", "byblock": "0"}.get(color_text.casefold(), color_text), values))
        if not color.is_integer() or not 0 <= color <= 256:
            raise MacroError("色はACI 1〜255、ByLayer（256）、ByBlock（0）で指定してください")
        lines += ["_.SETVAR", "CECOLOR", str(int(color))]
        appearance["color"] = int(color)
    raw_scale = cmd.get("linetype_scale", "")
    if str(raw_scale).strip():
        scale = number(raw_scale, values)
        if float(scale) <= 0:
            raise MacroError("線種尺度は正の数値にしてください")
        lines += ["_.SETVAR", "CELTSCALE", scale]
        appearance["linetype_scale"] = float(scale)

    def point(x, y):
        return number(cmd[x], values) + "," + number(cmd[y], values)

    def coords(*points):
        return tuple(float(z) for p in points for z in p.split(","))

    item = {
        "row": ri,
        "type": typ,
        "layer": layer or "現在のレイヤー",
        "command_path": path,
        "loop_index": values.get("__loop__", {}).get("index"),
    }
    item.update(appearance)
    if typ == "TEXT":
        x, y, h, angle = [
            number(cmd.get(key, default), values)
            for key, default in [
                ("x", 0),
                ("y", 0),
                ("height", "settings.TEXT_HEIGHT"),
                ("angle", 0),
            ]
        ]
        if float(h) <= 0:
            raise MacroError("文字高さは正数にしてください")
        raw = str(cmd.get("text", ""))
        content = (
            str(evaluate(raw[1:], values))
            if raw.startswith("=")
            else str(evaluate(raw, values))
            if is_single_table_reference(raw)
            else raw
        )
        if (
            not content
            or content[0].isspace()
            or any(ord(c) < 32 or ord(c) == 127 for c in content)
        ):
            raise MacroError("文字は空欄・先頭空白・改行・制御文字を使用できません")
        lines += ["_.-TEXT", "_non", x + "," + y, h, angle, content]
        item.update(
            coords=(float(x), float(y), float(h)), text=content, angle=float(angle)
        )
    elif typ in ("DIMLINEAR", "DIMALIGNED"):
        p1, p2, p3 = point("x1", "y1"), point("x2", "y2"), point("x3", "y3")
        if p1 == p2:
            raise MacroError("寸法の始点と終点は異なる位置にしてください")
        lines += ["_." + typ, "_non", p1, "_non", p2, "_non", p3]
        item.update(coords=coords(p1, p2, p3))
    elif typ in ("DIMRADIUS", "DIMDIAMETER"):
        center, label = point("x", "y"), point("x3", "y3")
        radius = number(cmd["r"], values)
        if float(radius) <= 0 or center == label:
            raise MacroError("寸法の半径は正数、寸法位置は中心と異なる位置にしてください")
        cx, cy, tx, ty = coords(center, label)
        # DIMASSOC=1 creates an independent native dimension. Its temporary
        # measurement circle is removed even when the command reports an error.
        lines += ["_.SETVAR", "DIMASSOC", "1",
            "((lambda (/ e result) "
            f"(if (not (entmake (list '(0 . \"CIRCLE\") (cons 10 (list {cx:.12g} {cy:.12g} 0.0)) (cons 40 {radius})))) (error \"AcadStadio: Cannot create measurement circle\")) "
            "(setq e (entlast)) "
            f"(setq result (vl-catch-all-apply 'command-s (list \"_.{typ}\" e \"_non\" (list {tx:.12g} {ty:.12g} 0.0)))) "
            "(entdel e) (if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result)))))"]
        item.update(coords=(cx, cy, float(radius), tx, ty))
    elif typ == "POINT":
        p = point("x", "y")
        lines += ["_.POINT", "_non", p]
        item.update(coords=coords(p))
    elif typ == "POLYLINE" or (typ == "LINE" and "vertices" in cmd):
        if "vertices" in cmd:
            from vertex_points import read_vertices
            try:expressions=[(p["x"],p["y"]) for p in read_vertices(cmd)]
            except ValueError as exc:raise MacroError(str(exc)) from exc
        else:
            expressions = polyline_expressions(cmd["points"])
        vertices = [tuple(float(number(expression, values)) for expression in pair) for pair in expressions]
        if any(a == b for a, b in zip(vertices, vertices[1:])):
            raise MacroError("隣り合う頂点は異なる位置にしてください")
        closed = float(number(cmd.get("closed", "0"), values)) if typ == "POLYLINE" else 0
        if closed not in (0, 1) or (closed and len(vertices) < 3):
            raise MacroError("閉じるは0または1。閉じたポリラインは3頂点以上が必要です")
        if len(budget) < 4:
            budget.extend([0] * (4 - len(budget)))
        budget[3] += len(vertices)
        if budget[3] > 50000:
            raise MacroError("連続線の合計頂点は50000点までです")
        if typ == "LINE":
            lines += ["_.LINE", "_non", f"{vertices[0][0]:.12g},{vertices[0][1]:.12g}"]
        else:
            lines += ["_.SETVAR", "PLINETYPE", "2", "_.PLINE", "_non", f"{vertices[0][0]:.12g},{vertices[0][1]:.12g}", "_Width", "0", "0"]
        for x, y in vertices[1:]:
            lines += ["_non", f"{x:.12g},{y:.12g}"]
        lines.append("_Close" if closed else "")
        item.update(coords=tuple(value for pair in vertices for value in pair))
        if typ == "POLYLINE":item["closed"]=bool(closed)
    elif typ == "ARC" and cmd.get("arc_mode","center_angles") != "center_angles":
        from arc_modes import arc_geometry
        points=[coords(point("x"+str(i),"y"+str(i))) for i in (1,2,3)]
        try:center,radius,start,sweep=arc_geometry(cmd["arc_mode"],points)
        except ValueError as exc:raise MacroError(str(exc)) from exc
        if cmd["arc_mode"]=="three_points":
            lines += ["_.ARC","_non",point("x1","y1"),"_non",point("x2","y2"),"_non",point("x3","y3")]
        else:
            lines += ["_.ARC","_non",point("x1","y1"),"_Center","_non",point("x2","y2"),"_non",point("x3","y3")]
        item.update(coords=(*center,radius),start_angle=start,sweep=sweep)
    elif typ in ("ARC", "ELLIPSE"):
        cx, cy = coords(point("x", "y"))
        if typ == "ARC":
            radius = float(number(cmd["r"], values))
            start, end = [float(number(cmd[key], values)) for key in ("start_angle", "end_angle")]
            sweep = (end - start) % 360
            if radius <= 0 or math.isclose(sweep, 0, abs_tol=1e-9):
                raise MacroError("円弧の半径は正数、開始角度と終了角度は異なる方向にしてください")
            a, b = [math.radians(angle % 360) for angle in (start, end)]
            first = f"{cx + radius * math.cos(a):.12g},{cy + radius * math.sin(a):.12g}"
            last = f"{cx + radius * math.cos(b):.12g},{cy + radius * math.sin(b):.12g}"
            lines += ["_.ARC", "_Center", "_non", f"{cx:.12g},{cy:.12g}", "_non", first, "_non", last]
            item.update(coords=(cx, cy, radius), start_angle=start % 360, sweep=sweep)
        else:
            rx, ry, angle = [float(number(cmd.get(key, "0"), values)) for key in ("rx", "ry", "angle")]
            if not 0 < ry <= rx:
                raise MacroError("楕円は長軸半径≧短軸半径>0で指定してください")
            a = math.radians(angle % 360)
            endpoint = f"{cx + rx * math.cos(a):.12g},{cy + rx * math.sin(a):.12g}"
            lines += ["_.SETVAR", "PELLIPSE", "0", "_.ELLIPSE", "_Center", "_non", f"{cx:.12g},{cy:.12g}", "_non", endpoint, f"{ry:.12g}"]
            item.update(coords=(cx, cy, rx, ry), angle=angle % 360)
    elif typ in ("LINE", "RECTANGLE"):
        p1, p2 = point("x1", "y1"), point("x2", "y2")
        if typ == "LINE" and p1 == p2:
            raise MacroError("線分の始点と終点は異なる位置にしてください")
        if typ == "RECTANGLE":
            v = coords(p1, p2)
            if v[0] == v[2] or v[1] == v[3]:
                raise MacroError("長方形の幅と高さは0以外にしてください")
        if typ == "LINE":
            lines += ["_.LINE", "_non", p1, "_non", p2, ""]
        else:
            lines += [
                "_.RECTANG",
                "_Chamfer",
                "0",
                "0",
                "_Fillet",
                "0",
                "_Width",
                "0",
                "_non",
                p1,
                "_non",
                p2,
            ]
        item.update(coords=coords(p1, p2))
    else:
        point_ = point("x", "y")
        radius = format(float(number(cmd["diameter"], values))/2,".12g") if cmd.get("circle_mode")=="diameter" else number(cmd["r"], values)
        if float(radius) <= 0:
            raise MacroError("円の半径は正数にしてください")
        lines += ["_.CIRCLE", "_non", point_, radius]
        item.update(coords=coords(point_) + (float(radius),))
    if cmd.get("point_id"):
        from command_points import geometry_points
        points = geometry_points(item)
        values.setdefault("__command_points__", {})[cmd["point_id"]] = points
        values.setdefault("__all_command_points__", {})[str(values.get("__point_block_id__", ""))+"/"+cmd["point_id"]] = points
    previews.append(item)
