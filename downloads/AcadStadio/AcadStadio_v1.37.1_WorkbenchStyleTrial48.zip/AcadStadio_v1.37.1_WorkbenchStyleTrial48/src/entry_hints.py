"""Display empty-field guidance without inserting it into the input value."""

from tkinter import ttk, font
from theme import MUTED


def add_entry_hint(entry, variable, text):
    hint = ttk.Label(entry, text=text, foreground=MUTED, background="white",
                     cursor="xterm", takefocus=False)
    entry.hint_label = hint

    def refresh(*_):
        if variable.get() or entry.instate(("disabled",)):
            hint.place_forget()
        else:
            reserve = 28 if isinstance(entry, ttk.Combobox) else 14
            available=max(0,entry.winfo_width()-reserve)
            shown=text
            if text=='現在の設定を引き継ぐ':
                face=font.nametofont('TkDefaultFont')
                if face.measure(shown)>available:shown='現在を引き継ぐ'
                if face.measure(shown)>available:shown='引き継ぐ'
            hint.configure(text=shown)
            width = min(font.nametofont('TkDefaultFont').measure(shown)+2, available)
            hint.place(x=7, rely=0.5, anchor="w", width=width)

    def focus(event):
        entry.focus_set()
        entry.icursor(0)
        return "break"

    trace = variable.trace_add("write", refresh)

    def cleanup(event):
        if event.widget is entry:
            variable.trace_remove("write", trace)

    hint.bind("<Button-1>", focus)
    entry.bind("<Configure>", refresh, add="+")
    entry.bind("<Map>", refresh, add="+")
    entry.bind("<Destroy>", cleanup, add="+")
    refresh()
    return hint
