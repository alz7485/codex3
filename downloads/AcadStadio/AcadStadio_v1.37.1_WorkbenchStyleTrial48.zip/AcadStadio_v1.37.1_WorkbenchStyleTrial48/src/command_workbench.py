"""Small supporting views for the command workbench."""
import tkinter as tk
from tkinter import ttk
from command_points import geometry_points
from engine import row_values, evaluate
from theme import fit_window


def evaluated_fields(project, blocks, items, row, locals_=None):
    values=dict(row_values(project,row),__local__={},__command_points__={},__all_command_points__={})
    for name,expression in (locals_ or {}).items():
        values['__local__'][name]=evaluate(expression,values)
    for item in items:
        bi=item.get('block_index',item.get('preset_index',0));ci=item.get('command_index',-1)
        if not 0<=bi<len(blocks) or not 0<=ci<len(blocks[bi]['commands']):continue
        command=blocks[bi]['commands'][ci]
        if bi==len(blocks)-1 and ci==len(blocks[bi]['commands'])-1:continue
        identity=command.get('point_id')
        if identity:
            points=geometry_points(item)
            values['__all_command_points__'][blocks[bi]['id']+'/'+identity]=points
            if bi==len(blocks)-1:values['__command_points__'][identity]=points
    return values


def show_reference_list(parent,groups,on_select):
    win=tk.Toplevel(parent);win.title('列・変数の一覧');win.transient(parent);win.grab_set()
    fit_window(win,500,520,360,300)
    query=tk.StringVar();ttk.Entry(win,textvariable=query).pack(fill='x',padx=12,pady=12)
    listing=tk.Listbox(win,exportselection=False);listing.pack(fill='both',expand=True,padx=12)
    values=[r for _,refs in groups for r in refs]
    def refresh(*_):
        listing.delete(0,'end')
        for value in values:
            if query.get().casefold() in value.casefold():listing.insert('end',value)
    def apply(*_):
        if listing.curselection():on_select(listing.get(listing.curselection()[0]));win.destroy()
    query.trace_add('write',refresh);refresh();listing.bind('<Double-1>',apply)
    bar=ttk.Frame(win,padding=12);bar.pack(fill='x')
    ttk.Button(bar,text='キャンセル',command=win.destroy).pack(side='left')
    ttk.Button(bar,text='参照を挿入',command=apply).pack(side='right')
    parent.wait_window(win);parent.grab_set()


def choose_kind(parent,groups,labels,on_select,icons):
    win=tk.Toplevel(parent);win.title('コマンドを選択');win.transient(parent);win.grab_set()
    fit_window(win,650,420,520,320)
    query=tk.StringVar();entry=ttk.Entry(win,textvariable=query);entry.pack(fill='x',padx=12,pady=12)
    categories=ttk.Frame(win);categories.pack(fill='x',padx=12)
    area=ttk.Frame(win,padding=12);area.pack(fill='both',expand=True)
    active=[0]
    def draw(*_):
        for child in area.winfo_children():child.destroy()
        kinds=[kind for _,group in groups for kind in group] if query.get() else groups[active[0]][1]
        filtered=[k for k in kinds if query.get().casefold() in labels[k].casefold()]
        for i,kind in enumerate(filtered):
            icon=next(('blocks','script','tree')[j] for j,(_,group) in enumerate(groups) if kind in group)
            button=ttk.Button(area,text=labels[kind],image=icons.get(icon),compound='left',command=lambda k=kind:(win.destroy(),on_select(k)))
            button.grid(row=i//3,column=i%3,sticky='ew',padx=4,pady=5)
        for i in range(3):area.columnconfigure(i,weight=1)
    for i,(title,_) in enumerate(groups):
        name=title.replace('を追加 ▾','')
        ttk.Button(categories,text=name,command=lambda j=i:(active.__setitem__(0,j),query.set(''),draw())).pack(side='left',padx=(0,5))
    query.trace_add('write',draw);draw();entry.focus_set()
    ttk.Button(win,text='キャンセル',command=win.destroy).pack(anchor='w',padx=12,pady=10)
    parent.wait_window(win);parent.grab_set()
