"""CAD setup staging, optional macros and flow style selectors through real Tk."""

import copy
import os
from pathlib import Path
import sys
from tkinter import ttk
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from test_cad_setup import project
from engine import compile_project
from macro_editor import edit_command
from cad_colors import ColorPicker, color_label
from dwg_import_editor import DWGImportDialog
from dwg_resources import extract_resources
from test_dwg_resources import FakeDocument, obj


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class CadSetupGui(unittest.TestCase):
    def setUp(self):
        gui.Gui.setUp(self)
        from cad_setup import default_setup
        self.app.data["cad_setup"] = default_setup()
        self.app.refresh()
    tearDown = gui.Gui.tearDown

    def test_palette_vertical_navigation_scrolls_and_skips_empty_cells(self):
        editor = self.app.edit_cad_setup()
        variable = editor.forms["layers"][1]["color"]
        picker = ColorPicker(editor.win, variable)
        picker.win.geometry("520x560")
        self.root.update()
        picker.canvas.event_generate("<Button-1>", x=443, y=18)
        self.assertTrue(picker.win.winfo_exists())
        picker.index = 19
        picker.move(-10)
        self.assertEqual(picker.index, 9)
        picker.index = 249
        picker.move(10)
        self.assertEqual(picker.index, 255)
        self.root.update()
        self.assertGreater(picker.canvas.yview()[0], 0)
        y = 8 + 25 * 24
        self.assertLessEqual(
            y + 22, picker.canvas.canvasy(0) + picker.canvas.winfo_height()
        )
        picker.close()
        editor.win.destroy()

    def test_color_palette_selects_name_swatch_and_saves_aci(self):
        editor = self.app.edit_cad_setup()
        variables = editor.forms["layers"][1]
        self.assertIn("白／黒", variables["color"].get())
        variables["name"].set("COLOR_TEST")
        picker = ColorPicker(editor.win, variables["color"])
        self.root.update()
        picker.canvas.event_generate("<Button-1>", x=74, y=66)
        self.root.update()
        self.assertEqual(variables["color"].get(), color_label(21))
        self.assertIs(self.root.grab_current(), editor.win)
        gui.button(editor.win, "設定を確定").invoke()
        self.assertEqual(self.app.data["cad_setup"]["layers"][0]["color"], "21")

    def test_lineweight_labels_and_nonplot_checkbox_roundtrip(self):
        editor = self.app.edit_cad_setup()
        variables = editor.forms["layers"][1]
        self.assertEqual(variables["lineweight"].get(), "既定（LWDEFAULT）")
        variables["name"].set("GUIDE")
        variables["lineweight"].set("0.25 mm")
        variables["plot"].set(False)
        self.assertTrue(editor.upsert("layers"))
        gui.button(editor.win, "設定を確定").invoke()
        layer = self.app.data["cad_setup"]["layers"][0]
        self.assertEqual(layer["lineweight"], "25")
        self.assertIs(layer["plot"], False)
        editor = self.app.edit_cad_setup()
        tree, variables = editor.forms["layers"]
        tree.selection_set("0")
        editor.select("layers")
        self.assertEqual(variables["lineweight"].get(), "0.25 mm")
        self.assertIs(variables["plot"].get(), False)
        self.assertIn("しない", tree.item("0", "values"))
        editor.win.destroy()

    def test_cancel_does_not_modify_project(self):
        before = copy.deepcopy(self.app.data)
        editor = self.app.edit_cad_setup()
        editor.forms["layers"][1]["name"].set("NEW_LAYER")
        editor.upsert("layers")
        editor.enabled.set(True)
        gui.button(editor.win, "キャンセル").invoke()
        self.assertEqual(self.app.data, before)

    def test_dwg_import_checkbox_stages_only_selected_layer(self):
        before = copy.deepcopy(self.app.data)
        editor = self.app.edit_cad_setup()
        dialog = DWGImportDialog(editor)
        dialog.resources, _ = extract_resources(FakeDocument())
        dialog.render_section("layers")
        self.root.update()
        tree=dialog.views["layers"]["tree"]
        tree.focus(tree.get_children()[0])
        dialog.toggle_candidate("layers")
        self.assertEqual(dialog.checked["layers"], {"PARTS"})
        dialog.apply()
        self.assertFalse(dialog.win.winfo_exists())
        self.assertEqual([r["name"] for r in editor.data["layers"]], ["PARTS"])
        self.assertEqual(editor.data["text_styles"], [])
        self.assertEqual(self.app.data, before)
        editor.win.destroy()

    def test_spaced_dwg_text_styles_are_registered_and_selectable_in_commands(self):
        names = ["MS明朝\u3000縦", "SX_FONT 縦"]
        document = FakeDocument()
        document.TextStyles = [obj(Name=name, FontFile="arial.ttf", Width=1,
                                  ObliqueAngle=0, Height=0) for name in names]
        editor = self.app.edit_cad_setup()
        dialog = DWGImportDialog(editor)
        dialog.resources, issues = extract_resources(document)
        self.assertEqual(issues, [])
        dialog.tabs.select(1)
        dialog.render_section("text_styles"); self.root.update()
        tree = dialog.views["text_styles"]["tree"]
        self.assertEqual([tree.item(i, "values")[1] for i in tree.get_children()], names)
        dialog.select_visible("text_styles", True)
        dialog.apply()
        gui.button(editor.win, "設定を確定").invoke(); self.root.update()
        self.assertEqual([r["name"] for r in self.app.data["cad_setup"]["text_styles"]], names)
        for name in names:
            def choose(name=name):
                win = gui.top(self.root, "コマンドの設定")
                try:
                    combo = next(w for w in gui.descendants(win)
                                 if isinstance(w, ttk.Combobox) and name in w.cget("values"))
                    combo.set(name)
                    gui.button(win, "変更を保存").invoke()
                except Exception as exc:
                    self.errors.append(exc); win.destroy()
            self.root.after(80, choose)
            result = edit_command(self.root, {"type": "TEXT", "x": 0, "y": 0, "text": "A"},
                                  self.app.data["blocks"], self.app.data)
            self.assertEqual(result["text_style"], name)
            self.app.data["blocks"][0]["commands"].append(result)
        script = compile_project(self.app.data, [0])[0]
        for name in names:
            self.assertIn(f'_.SETVAR\nTEXTSTYLE\n"{name}"\n', script)
        self.assertEqual(self.messages, [])

    def test_create_commit_and_undo(self):
        before = copy.deepcopy(self.app.data)
        editor = self.app.edit_cad_setup()
        editor.forms["layers"][1]["name"].set("PARTS")
        editor.forms["layers"][1]["color"].set("2")
        self.assertTrue(editor.upsert("layers"))
        editor.enabled.set(True)
        gui.button(editor.win, "設定を確定").invoke()
        self.assertEqual(self.app.data["cad_setup"]["layers"][0]["name"], "PARTS")
        self.assertFalse(self.app.data["cad_setup"]["legacy_make_layers"])
        self.assertIn("(c:CADFLOWINIT)", compile_project(self.app.data, [0])[0])
        self.app.undo_project()
        self.assertEqual(self.app.data, before)

    def test_toggle_off_keeps_names_and_form_selector_uses_them(self):
        self.app.replace_document(project())
        self.assertEqual(self.app.data["version"], 11)
        self.assertIsInstance(self.app.data["blocks"], list)
        self.assertNotIn("presets", self.app.data)
        editor = self.app.edit_cad_setup()
        editor.enabled.set(False)
        gui.button(editor.win, "設定を確定").invoke()
        self.assertEqual(
            self.app.data["cad_setup"]["text_styles"][0]["name"], "CF_TEXT"
        )
        self.assertNotIn("CADFLOWINIT", compile_project(self.app.data, [0])[0])

        def choose():
            win = gui.top(self.root, "コマンドの設定")
            try:
                combo = next(
                    w
                    for w in gui.descendants(win)
                    if isinstance(w, ttk.Combobox) and "CF_TEXT" in w.cget("values")
                )
                combo.set("CF_TEXT")
                gui.button(win, "変更を保存").invoke()
            except Exception as exc:
                self.errors.append(exc)
                win.destroy()

        self.root.after(80, choose)
        result = edit_command(
            self.root,
            {"type": "TEXT", "layer": "PARTS", "x": 0, "y": 0, "text": "A"},
            self.app.data["blocks"],
            self.app.data,
        )
        self.assertEqual(result["text_style"], "CF_TEXT")

    def test_invalid_input_remains_open_and_pending_edits_are_committed(self):
        editor = self.app.edit_cad_setup()
        vars = editor.forms["layers"][1]
        vars["name"].set("PARTS")
        vars["color"].set("999")
        gui.button(editor.win, "設定を確定").invoke()
        self.assertTrue(editor.win.winfo_exists())
        self.assertTrue(self.messages)
        vars["color"].set("3")
        gui.button(editor.win, "設定を確定").invoke()
        self.assertEqual(self.app.data["cad_setup"]["layers"][0]["color"], "3")

    def test_all_tabs_keep_confirm_and_editor_buttons_visible_at_minimum(self):
        editor = self.app.edit_cad_setup()
        editor.win.geometry("820x650")
        notebook = next(
            w for w in gui.descendants(editor.win) if isinstance(w, ttk.Notebook)
        )
        for tab in notebook.tabs():
            notebook.select(tab)
            self.root.update()
            for w in gui.descendants(editor.win):
                if isinstance(w, ttk.Button) and w.winfo_ismapped():
                    self.assertLessEqual(
                        w.winfo_rooty() + w.winfo_height(),
                        editor.win.winfo_rooty() + editor.win.winfo_height(),
                    )
        editor.win.destroy()


if __name__ == "__main__":
    unittest.main()
