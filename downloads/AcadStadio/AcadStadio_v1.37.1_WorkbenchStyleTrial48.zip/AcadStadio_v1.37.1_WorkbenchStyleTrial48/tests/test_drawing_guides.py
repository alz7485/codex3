import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from sample_project import EXAMPLE
from engine import compile_project, MacroError
from guide_blocks import copy_to_guide, forward_links, repair_forward_links, pin_guide
from command_points import new_id, reference
from project_model import validate_sequential_project

class Guides(unittest.TestCase):
    def project(self):
        p=copy.deepcopy(EXAMPLE);pid=new_id()
        line=dict(type='LINE',point_id=pid,x1='@X',y1='@Y',x2='@X+@OD',y2='@Y',color='1')
        point=dict(type='POINT',x=reference('source/'+pid,'中点','X'),y=reference('source/'+pid,'中点','Y'))
        p['blocks']=[dict(id='source',name='元',commands=[line]),dict(id='target',name='使用',commands=[point])]
        return p
    def test_copy_is_preview_only_and_original_scr_is_identical(self):
        p=self.project();before=compile_project(p,[0])[0]
        added=copy_to_guide(p,'source',[p['blocks'][0]['commands'][0]])
        self.assertTrue(p['blocks'][0]['guide']);self.assertEqual(len(added),1)
        self.assertFalse(validate_sequential_project(p))
        script,items=compile_project(p,[0]);self.assertEqual(script,before)
        self.assertEqual(sum(bool(i.get('guide')) for i in items),1)
        p['blocks']=p['blocks'][:1]
        script,items=compile_project(p,[0]);self.assertNotIn('_.LINE\n',script);self.assertEqual(len(items),1)
    def test_reorder_keeps_links_then_repair_copies_and_retargets(self):
        p=self.project();before=copy.deepcopy(p['blocks'][1]['commands'][0]);p['blocks'].reverse()
        self.assertEqual(len(forward_links(p)),1);self.assertEqual(p['blocks'][0]['commands'][0],before)
        with self.assertRaises(MacroError):compile_project(p,[0])
        self.assertEqual(repair_forward_links(p),1);self.assertFalse(forward_links(p))
        self.assertIn(p['blocks'][0]['id']+'/',p['blocks'][1]['commands'][0]['x'])
        script,items=compile_project(p,[0]);self.assertEqual(items[1]['coords'],(150,100))
        self.assertEqual(script.count('_.LINE\n'),1)
    def test_dependency_closure_is_copied_before_consumer_and_excludes_scr_effects(self):
        p=self.project();p['blocks'][1]['commands'][0]['point_id']=new_id()
        added=copy_to_guide(p,'target',[p['blocks'][1]['commands'][0]])
        self.assertEqual([c['type'] for c in added],['LINE','POINT'])
        self.assertIn(p['blocks'][0]['id']+'/',added[1]['x'])
        self.assertEqual(compile_project(p,[0])[1][1]['coords'],(150,100))
    def test_guides_do_not_change_normal_color_state(self):
        p=self.project();p['blocks'][0]['commands'][0].pop('color');before=compile_project(p,[0])[0]
        copy_to_guide(p,'source',[dict(p['blocks'][0]['commands'][0],color='4',linetype_scale='3')])
        self.assertEqual(compile_project(p,[0])[0],before)
    def test_guide_order_schema_and_unsupported_commands(self):
        p=self.project();copy_to_guide(p,'source',[p['blocks'][0]['commands'][0]])
        p['blocks'].append(p['blocks'].pop(0));self.assertTrue(validate_sequential_project(p));pin_guide(p);self.assertFalse(validate_sequential_project(p))
        with self.assertRaises(ValueError):copy_to_guide(p,'source',[dict(type='SYSVAR',name='SNAPMODE',value='0')])
    def test_dependency_cycle_is_reported(self):
        p=self.project();pid=p['blocks'][0]['commands'][0]['point_id'];p['blocks'][0]['commands'][0]['x1']=reference(pid,'始点','X')
        with self.assertRaisesRegex(ValueError,'循環'):copy_to_guide(p,'source',[p['blocks'][0]['commands'][0]])

    def test_literal_text_that_looks_like_point_formula_is_not_a_dependency(self):
        p=self.project();text=dict(type='TEXT',x='0',y='0',text="点('missing', '始点', 'X')",height='3')
        added=copy_to_guide(p,'source',[text])
        self.assertEqual(len(added),1);self.assertEqual(added[0]['text'],text['text'])
        self.assertFalse(forward_links(p))
