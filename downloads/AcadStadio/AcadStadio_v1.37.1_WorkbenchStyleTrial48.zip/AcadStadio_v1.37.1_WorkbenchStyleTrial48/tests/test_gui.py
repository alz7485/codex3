"""Real Tk interaction regressions. Headless hosts skip unless DISPLAY is set."""

import copy
import os
import sys
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from tkinter import ttk
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from main import App, EMPTY
from macro_editor import MacroEditor, CommandList, edit_command
from block_model import new_block
from sample_project import EXAMPLE


def descendants(widget):
    for child in widget.winfo_children():
        yield child
        yield from descendants(child)


def button(widget, text):
    if hasattr(widget,'action_bar') and text in ('キャンセル','この点を使用'):
        return button(widget.action_bar,text)
    if text=='変更を保存':
        match=next((w for w in descendants(widget) if isinstance(w,ttk.Button) and str(w.cget('text')) in ('変更を保存','追加して閉じる')),None)
        if match is not None:return match
    return next(
        w
        for w in descendants(widget)
        if isinstance(w, (ttk.Button, ttk.Menubutton)) and str(w.cget("text")).startswith(text)
    )


def top(root, title):
    if title=='コマンドの点を選択':
        return next(w.point_panel for w in descendants(root) if isinstance(w,tk.Toplevel) and hasattr(w,'point_panel') and w.point_panel.winfo_exists())
    return next(
        w
        for w in descendants(root)
        if isinstance(w, tk.Toplevel) and title in w.title()
    )


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class Gui(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.errors = []
        self.root.report_callback_exception = lambda typ, value, tb: self.errors.append(
            value
        )
        self.library_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.library_dir.cleanup)
        self.app = App(
            self.root, library_state_path=Path(self.library_dir.name) / "library.json"
        )
        self.root.update()
        self.app.preview(quiet=True)
        self.messages = []
        self.patches = [
            patch("tkinter.messagebox.askyesno", return_value=True),
            patch(
                "tkinter.messagebox.showerror",
                side_effect=lambda *a, **k: self.messages.append(a),
            ),
            patch("tkinter.messagebox.showinfo", return_value=None),
        ]
        for item in self.patches:
            item.start()

    def tearDown(self):
        if self.app._preview_job:
            try:
                self.root.after_cancel(self.app._preview_job)
            except tk.TclError:
                pass
        self.root.update_idletasks()
        self.root.destroy()
        for item in self.patches:
            item.stop()
        self.assertEqual(self.errors, [])

    def test_initial_preview_and_readonly_script(self):
        self.assertEqual(len(self.app.canvas.items), 43)
        self.app.show_script()
        self.assertEqual(self.app.script.cget("state"), "disabled")
        self.assertIn("AcadStadio", self.root.title())

    def test_undo_redo_restores_whole_project(self):
        before = copy.deepcopy(self.app.data)
        self.app.rows[0]["OD"] = "150"
        self.app.refresh()
        self.assertTrue(self.app.has_unsaved_changes())
        self.app.undo_project()
        self.assertEqual(self.app.data, before)
        self.app.redo_project()
        self.assertEqual(self.app.rows[0]["OD"], "150")
        self.app.undo_project()
        self.app.data["globals"]["NEW"] = "1"
        self.app.refresh()
        self.app.redo_project()
        self.assertEqual(self.app.rows[0]["OD"], "100")

    def test_selection_preserved_on_edit(self):
        self.app.table.selection_set("1")
        self.app.block_list.selection_set("2")
        self.app.rows[1]["X"] = "260"
        self.app.refresh()
        self.assertEqual(self.app.selected_rows(), [1])
        self.assertEqual(self.app.selected_block(), 2)

    def test_failed_preview_clears_old_result(self):
        self.app.rows[0]["OD"] = "bad"
        self.app.preview(quiet=True)
        self.assertEqual(self.app.canvas.items, [])
        self.assertEqual(self.app._script_text, "")
        self.assertIn("1行目", self.app.status.get())

    def test_new_cancel_preserves_project(self):
        self.app.data["globals"]["NEW"] = "1"
        before = copy.deepcopy(self.app.data)
        with patch("tkinter.messagebox.askyesnocancel", return_value=None):
            self.app.new()
        self.assertEqual(self.app.data, before)

    def test_save_load_and_backup(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "p.json"
            with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
                self.assertTrue(self.app.save())
            self.app.rows[0]["X"] = "180"
            self.app.refresh()
            self.assertTrue(self.app.save())
            self.assertEqual(len(list((Path(folder) / "p_backups").glob("*.json"))), 1)
            self.app.replace_document(EMPTY)
            with patch("tkinter.filedialog.askopenfilename", return_value=str(path)):
                self.assertTrue(self.app.load())
            self.assertEqual(self.app.rows[0]["X"], "180")
            self.assertFalse(self.app.has_unsaved_changes())

    def test_bad_load_keeps_document(self):
        before = copy.deepcopy(self.app.data)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "p.json"
            path.write_text('{"rows":[1],"blocks":{},"presets":[]}', encoding="utf-8")
            with patch("tkinter.filedialog.askopenfilename", return_value=str(path)):
                self.assertFalse(self.app.load())
        self.assertEqual(self.app.data, before)

    def test_import_replace_and_undo(self):
        before = copy.deepcopy(self.app.data)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "p.csv"
            path.write_text("X,Y\n20,30\n", encoding="utf-8")
            self.assertTrue(self.app.read_table(path))
        self.assertEqual(self.app.rows, [{"X": "20", "Y": "30"}])
        self.app.undo_project()
        self.assertEqual(self.app.data, before)

    def test_block_editor_cancel_discards_new_block_and_command_changes(self):
        before = copy.deepcopy(self.app.data)
        editor = MacroEditor(
            self.root,
            self.app.data["blocks"][0],
            self.app.data["blocks"],
            self.app.refresh,
            self.app.data,
            [0],
        )
        self.root.update()
        editor.list.commands.append({"type": "SET", "name": "A", "value": "1"})
        editor.working_blocks.append(new_block("temporary"))
        editor.name.set("different")
        editor.cancel()
        self.assertEqual(self.app.data, before)

    def test_block_editor_commit_updates_preview_and_undo(self):
        editor = MacroEditor(
            self.root,
            self.app.data["blocks"][0],
            self.app.data["blocks"],
            self.app.refresh,
            self.app.data,
            [0],
        )
        self.root.update()
        editor.name.set("Renamed")
        editor.cond.set("False")
        editor.show_preview([])
        self.assertEqual(editor.preview_canvas.items, [])
        editor.save()
        self.assertEqual(self.app.data["blocks"][0]["name"], "Renamed")
        self.app.undo_project()
        self.assertEqual(self.app.data, EXAMPLE)

    def test_new_block_cancel_leaves_no_empty_block(self):
        before = copy.deepcopy(self.app.data)
        self.app.add_block()
        self.root.update()
        win = top(self.root, "ブロック編集")
        button(win, "キャンセル").invoke()
        self.assertEqual(self.app.data, before)

    def add_referenced_block(self):
        helper = new_block("外形円", commands=self.app.data["blocks"][0]["commands"])
        self.app.data["blocks"].append(helper)
        self.app.refresh()
        return helper


    def test_block_rename_keeps_identity_and_undo_restores_name(self):
        helper = self.add_referenced_block()
        before = copy.deepcopy(self.app.data)
        identity = helper["id"]
        editor = MacroEditor(
            self.root,
            helper,
            self.app.data["blocks"],
            self.app.refresh,
            self.app.data,
            [0],
        )
        self.root.update()
        editor.name.set("輪郭")
        # Editing a label is staged until the block editor is committed.
        self.assertEqual(self.app.data["blocks"][-1]["name"], "外形円")
        editor.save()
        self.assertEqual(self.app.data["blocks"][-1]["name"], "輪郭")
        self.assertEqual(self.app.data["blocks"][-1]["id"], identity)
        self.app.undo_project()
        self.assertEqual(self.app.data, before)

    def test_block_cancel_preserves_all_project_data(self):
        helper = self.add_referenced_block()
        before = copy.deepcopy(self.app.data)
        editor = MacroEditor(
            self.root,
            helper,
            self.app.data["blocks"],
            self.app.refresh,
            self.app.data,
            [0],
        )
        self.root.update()
        editor.name.set("other")
        editor.cond.set("False")
        editor.list.commands.append({"type": "SET", "name": "EXTRA", "value": "2"})
        editor.cancel()
        self.assertEqual(self.app.data, before)

    def test_block_deletion_is_undoable(self):
        self.add_referenced_block()
        before = copy.deepcopy(self.app.data)
        self.app.block_list.selection_set(str(len(self.app.data["blocks"]) - 1))
        self.app.del_block()
        self.assertEqual(len(self.app.data["blocks"]), len(before["blocks"]) - 1)
        self.app.undo_project()
        self.assertEqual(self.app.data, before)


    def test_direct_command_duplicate_undo_does_not_create_blocks(self):
        win = tk.Toplevel(self.root)
        blocks = []
        commands = [{"type": "CIRCLE", "x": "0", "y": "0", "r": "1"}]
        editor = CommandList(win, commands, blocks)
        editor.tree.selection_set("0"); editor.duplicate()
        self.assertEqual(len(commands), 2)
        self.assertEqual(blocks, [])
        self.assertFalse(hasattr(editor, "group"))
        editor.undo(); self.assertEqual(len(commands), 1)
        editor.redo(); self.assertEqual(len(commands), 2)
        win.destroy()


    def test_nested_command_form_preserves_typed_condition(self):
        checks = []

        def interact():
            win = top(self.root, "コマンドの設定")
            picker = next(w for w in descendants(win) if isinstance(w, ttk.Combobox))
            picker.set("IF / ELSE · 条件分岐")
            picker.event_generate("<<ComboboxSelected>>")
            win.update()
            entry = next(
                w
                for w in descendants(win)
                if isinstance(w, ttk.Entry)
                and any(
                    isinstance(s, ttk.Label) and s.cget("text") == "実行条件（式）"
                    for s in w.master.winfo_children()
                )
            )
            entry.delete(0, "end")
            entry.insert(0, "@X > 0")

            def finish_branch():
                sub = top(win, "IF:")
                button(sub, "この階層を確定").invoke()

            win.after(20, finish_branch)
            button(win, "実行するコマンドを編集").invoke()
            checks.append(True)
            button(win, "変更を保存").invoke()

        self.root.after(30, interact)
        result = edit_command(
            self.root, {"type": "LINE"}, self.app.data["blocks"], self.app.data
        )
        self.assertEqual(checks, [True])
        self.assertEqual(result["condition"], "@X > 0")
        self.assertEqual(result["commands"], [])

    def test_navigator_nested_commands_editable(self):
        self.app.open_navigator()
        nav = self.app.navigator
        owner = ("block", 0, (2, "commands"))
        self.assertEqual(len(nav.commands(owner)), 1)
        nav.choose(owner, 0)
        nav.duplicate()
        self.assertEqual(len(self.app.data["blocks"][0]["commands"][2]["commands"]), 2)
        self.assertEqual(nav.command_selection(), (owner, [1]))
        self.app.undo_project()
        self.assertEqual(len(self.app.data["blocks"][0]["commands"][2]["commands"]), 1)

    def test_navigator_cut_stale_source_is_rejected(self):
        self.app.open_navigator()
        nav = self.app.navigator
        nav.choose(("block", 0), 0)
        nav.cut_commands()
        self.app.data["blocks"][0]["commands"].append(
            {"type": "SET", "name": "A", "value": "0"}
        )
        nav.choose(("block", 1), 0)
        before = copy.deepcopy(self.app.data)
        nav.paste_commands()
        self.assertEqual(self.app.data, before)
        self.assertTrue(self.messages)

    def test_navigator_cut_into_descendant_is_rejected(self):
        self.app.open_navigator()
        nav = self.app.navigator
        nav.choose(("block", 0), 2)
        nav.cut_commands()
        owner = ("block", 0, (2, "commands"))
        nav.choose(owner, 0)
        before = copy.deepcopy(self.app.data)
        nav.paste_commands()
        self.assertEqual(self.app.data, before)

    def test_settings_pending_field_is_committed(self):
        def interact():
            win = top(self.root, "共通設定テスト")
            tree = next(w for w in descendants(win) if isinstance(w, ttk.Treeview))
            tree.selection_set(tree.get_children()[0])
            tree.event_generate("<<TreeviewSelect>>")
            win.update()
            entries = [w for w in descendants(win) if isinstance(w, ttk.Entry)]
            entries[-1].delete(0, "end")
            entries[-1].insert(0, "8")
            button(win, "表の内容を確定").invoke()

        self.root.after(30, interact)
        self.assertEqual(
            self.app.edit_key_values("共通設定テスト", {"TEXT_HEIGHT": "3.5"}),
            {"TEXT_HEIGHT": "8"},
        )

    def test_row_form_has_no_json_requirement(self):
        def interact():
            win = top(self.root, "数値の編集テスト")
            entry = next(w for w in descendants(win) if isinstance(w, ttk.Entry))
            entry.delete(0, "end")
            entry.insert(0, "42")
            button(win, "行を確定").invoke()

        self.root.after(30, interact)
        self.assertEqual(
            self.app.edit_row_values("数値の編集テスト", {"X": "1"}), {"X": "42"}
        )

    def test_export_writes_selected_rows_and_encoding(self):
        self.app.table.selection_set("0")
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "out.scr"
            with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
                self.app.export()
                self.root.update()
                win = top(self.root, "SCRを書き出す")
                button(win, "保存先を選んで").invoke()
            data = path.read_bytes()
            self.assertIn(b"_.CIRCLE\r\n", data)
            self.assertNotIn(b"\r\r\n", data)
            self.assertEqual(data.count(b"_.CIRCLE"), 8)

    def test_block_footer_accessible_at_small_size(self):
        editor = MacroEditor(
            self.root,
            self.app.data["blocks"][0],
            self.app.data["blocks"],
            self.app.refresh,
            self.app.data,
            [0],
        )
        editor.win.geometry("850x640")
        self.assertFalse(any(isinstance(w, ttk.Button) and w.cget("text") == "ブロック化" for w in descendants(editor.win)))
        self.root.update()
        for label in ["ブロックを確定", "キャンセル", "線・形状を追加", "編集"]:
            w = button(editor.win, label)
            self.assertTrue(w.winfo_ismapped())
            self.assertLessEqual(
                w.winfo_rooty() + w.winfo_height(),
                editor.win.winfo_rooty() + editor.win.winfo_height(),
            )
        editor.cancel()

    def test_main_close_keeps_modal_draft_open(self):
        editor = MacroEditor(
            self.root,
            self.app.data["blocks"][0],
            self.app.data["blocks"],
            self.app.refresh,
            self.app.data,
            [0],
        )
        editor.name.set("draft")
        self.app.on_exit()
        self.assertTrue(self.root.winfo_exists())
        self.assertTrue(editor.win.winfo_exists())
        editor.cancel()

    def test_preview_has_no_result_tabs_and_scr_window_can_close_without_moving_it(self):
        panel=self.app.preview_panel
        self.root.update()
        before=(panel.winfo_x(),panel.winfo_y(),panel.winfo_width(),panel.winfo_height())
        self.assertFalse(hasattr(self.app,"result_tabs"))
        win=self.app.show_script();self.root.update()
        self.assertEqual(self.app.script.get("1.0","end-1c"),self.app._script_text)
        self.assertEqual(before,(panel.winfo_x(),panel.winfo_y(),panel.winfo_width(),panel.winfo_height()))
        win.withdraw();self.root.update()
        self.assertIs(self.app.show_script(),win)


    def test_table_import_appends_instead_of_replacing(self):
        old = self.app.data["active_table"]
        rows = copy.deepcopy(self.app.rows)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "second.csv"
            path.write_text("X,Y\n9,8\n", encoding="utf-8")
            self.app.read_table(path)
        self.assertEqual(len(self.app.data["input_tables"]), 2)
        self.assertEqual(self.app.rows, [{"X": "9", "Y": "8"}])
        self.app.switch_table(old)
        self.root.update()
        self.assertEqual(self.app.rows, rows)

    def test_table_drawing_targets_are_restored_on_switch(self):
        old = self.app.data["active_table"]
        self.app.scope.set("range")
        self.app.row_range.set("3")
        self.root.update()
        self.app.duplicate_table()
        new = self.app.data["active_table"]
        self.app.set_checked_rows([0, 1, 2])
        self.root.update()
        self.app.switch_table(old)
        self.root.update()
        self.assertEqual(self.app.scope.get(), "range")
        self.assertEqual(self.app.target_rows(), [2])
        self.app.switch_table(new)
        self.root.update()
        self.assertEqual(self.app.target_rows(), [0, 1, 2])

    def test_duplicate_table_is_independent_and_delete_can_undo(self):
        old = self.app.data["active_table"]
        self.app.duplicate_table()
        new = self.app.data["active_table"]
        self.app.rows[0]["X"] = "999"
        self.app.refresh()
        self.app.switch_table(old)
        self.root.update()
        self.assertEqual(self.app.rows[0]["X"], "100")
        self.app.switch_table(new)
        self.root.update()
        self.app.delete_table()
        self.root.update()
        self.assertEqual(len(self.app.data["input_tables"]), 1)
        self.app.undo_project()
        self.root.update()
        self.assertEqual(len(self.app.data["input_tables"]), 2)
        self.assertEqual(self.app.rows[0]["X"], "999")

    def test_range_preview_and_export_use_same_rows(self):
        self.app.scope.set("range")
        self.app.row_range.set("2")
        self.root.update()
        _, items = self.app.compile()
        self.assertTrue(items)
        self.assertTrue(all(i["row"] == 1 for i in items))
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "out.scr"
            with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
                self.app.export()
                self.root.update()
                button(top(self.root, "SCRを書き出す"), "保存先を選んで").invoke()
            self.assertEqual(path.read_bytes().count(b"_.CIRCLE"), 10)

    def test_sizes_in_preset_settings_apply_common_values(self):
        editor = self.app.manage_settings_presets()
        self.root.update()
        for key, value in zip(("TEXT_HEIGHT", "DIM_TEXT_HEIGHT", "ARROW_SIZE", "DIM_SCALE"), ["7", "4", "3", "2"]):
            editor.size_vars[key].set(value)
        button(editor.win, "保存して閉じる").invoke()
        self.root.update()
        scr, items = self.app.compile()
        self.assertIn("_.DIMTXT\n4\n", scr)
        self.assertIn("_.DIMASZ\n3\n", scr)
        self.assertIn("_.DIMSCALE\n2\n", scr)
        self.assertTrue(all(i["coords"][2] == 7 for i in items if i["type"] == "TEXT"))

    def test_save_reload_preserves_multiple_tables_and_targets(self):
        self.app.duplicate_table()
        self.root.update()
        active = self.app.data["active_table"]
        self.app.set_checked_rows([1, 2])
        self.root.update()
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "p.json"
            with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
                self.assertTrue(self.app.save())
            self.app.replace_document(EMPTY)
            with patch("tkinter.filedialog.askopenfilename", return_value=str(path)):
                self.assertTrue(self.app.load())
        self.root.update()
        self.assertEqual(len(self.app.data["input_tables"]), 2)
        self.assertEqual(self.app.data["active_table"], active)
        self.assertEqual(self.app.target_rows(), [1, 2])

    def test_main_buttons_are_accessible_at_minimum_size(self):
        self.root.geometry("1040x680")
        self.root.update()
        x0, y0 = self.root.winfo_rootx(), self.root.winfo_rooty()
        right = x0 + self.root.winfo_width()
        bottom = y0 + self.root.winfo_height()
        for w in descendants(self.root):
            if isinstance(w, ttk.Button) and w.winfo_ismapped():
                with self.subTest(label=w.cget("text")):
                    self.assertLessEqual(w.winfo_rootx() + w.winfo_width(), right)
                    self.assertLessEqual(w.winfo_rooty() + w.winfo_height(), bottom)


if __name__ == "__main__":
    unittest.main(verbosity=2)
