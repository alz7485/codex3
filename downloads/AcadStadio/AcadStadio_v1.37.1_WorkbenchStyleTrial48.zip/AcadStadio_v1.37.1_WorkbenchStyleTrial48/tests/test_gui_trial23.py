"""Drawing source tables are staged independently from preview selection."""
import os
import sys
import unittest
from pathlib import Path
from tkinter import ttk
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui
from macro_editor import edit_command
from cad_colors import entity_color_label

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform == 'win32', 'GUI display unavailable')
class Trial23Gui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_color_and_scale_editor_save_and_cancel(self):
        command = dict(type='LINE', x1='0', y1='0', x2='10', y2='0', color='1', linetype_scale='2')
        def choose():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                combos = [w for w in gui.descendants(win) if isinstance(w, ttk.Combobox)]
                color = next(w for w in combos if entity_color_label(256) in w.cget('values'))
                color.set(entity_color_label(256))
                entries = [w for w in gui.descendants(win) if isinstance(w, ttk.Entry) and not isinstance(w, ttk.Combobox)]
                scale = next(w for w in entries if w.get() == '2')
                scale.delete(0, 'end'); scale.insert(0, '@OD / 50')
                gui.button(win, '変更を保存').invoke()
            except Exception as exc:
                self.errors.append(exc); win.destroy()
        self.root.after(80, choose)
        result = edit_command(self.root, command, self.app.data['blocks'], self.app.data)
        self.assertEqual(result['color'], '256')
        self.assertEqual(result['linetype_scale'], '@OD / 50')
        self.assertEqual(command['color'], '1')
        self.root.after(80, lambda: gui.button(gui.top(self.root, 'コマンドの設定'), 'キャンセル').invoke())
        self.assertIsNone(edit_command(self.root, command, self.app.data['blocks'], self.app.data))

