"""Category menus invoke real forms and new native shapes remain selectable."""
import copy
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from tkinter import ttk
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import MacroEditor, TYPE_LABELS
from command_types import COMMAND_GROUPS
from engine import compile_project
from test_extended_drawing import COMMANDS

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CommandGroupsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_three_category_menus_and_all_actions_fit_in_one_row(self):
        ed=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0])
        self.root.update()
        controls=ed.list.toolbar.winfo_children()
        self.assertEqual(len(controls),11)
        for control,(label,kinds) in zip(controls,COMMAND_GROUPS):
            self.assertIsInstance(control,ttk.Menubutton)
            self.assertEqual(control.cget('text'),label)
            self.assertTrue(control.cget('image'))
            self.assertTrue(control.tooltip_text)
            menu=self.root.nametowidget(control.cget('menu'))
            self.assertEqual([menu.entrycget(i,'label') for i in range(menu.index('end')+1)],[TYPE_LABELS[k] for k in kinds])
        for geometry in ('1160x780','850x640'):
            ed.win.geometry(geometry);self.root.update()
            ed.command_panes.sashpos(0,320);self.root.update()
            self.assertEqual(len({w.winfo_y() for w in controls}),1)
            self.assertTrue(all(w.winfo_ismapped() and w.winfo_x()+w.winfo_width()<=ed.list.toolbar.winfo_width() for w in controls))
        ed.win.destroy()

    def test_menu_adds_each_new_command_and_undo_redo_remains_transactional(self):
        ed=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0]);self.root.update()
        before=copy.deepcopy(self.app.data)
        for command in COMMANDS:
            kind=command['type'];at=next((i,kinds.index(kind)) for i,(_,kinds) in enumerate(COMMAND_GROUPS) if kind in kinds)
            control=ed.list.toolbar.winfo_children()[at[0]];menu=self.root.nametowidget(control.cget('menu'))
            self.root.after(50,lambda:gui.button(gui.top(self.root,'コマンドの設定'),'変更を保存').invoke())
            menu.invoke(at[1]);self.root.update()
            self.assertEqual(ed.list.commands[-1]['type'],kind)
            ed.list.undo();ed.list.redo();self.root.update()
            self.assertEqual(ed.list.commands[-1]['type'],kind)
            ed.list.tree.selection_remove(ed.list.tree.selection())
        self.assertEqual(self.app.data,before)
        ed.win.destroy()

    def test_extended_geometry_preview_fit_zoom_and_highlight(self):
        project=copy.deepcopy(self.app.data)
        project['blocks']=[dict(project['blocks'][0],commands=copy.deepcopy(COMMANDS))]
        script,items=compile_project(project,[0])
        self.app.canvas.set_items(items);self.root.update();self.app.canvas.fit()
        self.assertEqual(len(self.app.canvas.items),7)
        self.assertTrue(any(self.app.canvas.type(n)=='arc' for n,_,_ in self.app.canvas.geometry))
        self.assertTrue(any(self.app.canvas.itemcget(n,'text')=='R10' for n,_,_ in self.app.canvas.geometry if self.app.canvas.type(n)=='text'))
        self.app.canvas.zoom(SimpleNamespace(x=150,y=150,delta=120),1.5)
        self.app.canvas.highlight([0],0)
        self.assertEqual(compile_project(project,[0])[0],script)

    def test_centerline_dash_survives_zoom_and_cad_editor_save(self):
        self.app.canvas.fit();self.root.update()
        center=[(n,i) for n,i,_ in self.app.canvas.geometry if i['layer']=='CENTER']
        self.assertEqual(len(center),4)
        self.assertEqual(sorted(self.app.canvas.type(n) for n,_ in center),['line','line','line','oval'])
        node,item=center[0];pattern=self.app.canvas.linetype_dash(item)
        self.assertEqual(len(pattern),4);self.assertGreater(pattern[0],pattern[2])
        # Some Tk builds truncate the final digit of dash-list readback.
        self.assertEqual(int(self.app.canvas.itemcget(node,'dash').split()[0]),pattern[0])
        self.app.canvas.zoom(SimpleNamespace(x=150,y=150,delta=120),1.5)
        changed=tuple(map(int,self.app.canvas.itemcget(node,'dash').split()))
        self.assertGreater(changed[0],pattern[0])
        editor=self.app.edit_cad_setup();self.root.update()
        self.assertFalse(editor.data['linetypes'][0]['existing_only'])
        self.assertEqual(editor.data['linetypes'][0]['builtin'],'CENTER')
        gui.button(editor.win,'設定を確定').invoke();self.root.update()
        self.assertIn('Center ____',self.app.compile()[0])
