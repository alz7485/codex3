import os
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from macro_editor import edit_command

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class CoordinateLayoutGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_each_coordinate_pair_is_aligned_and_references_fit_at_minimum_width(self):
        for kind, pairs in [('LINE',['1','2']),('CIRCLE',['']),('DIMLINEAR',['1','2','3']),('DIMALIGNED',['1','2','3']),('DIMRADIUS',['','3'])]:
            def inspect(pairs=pairs):
                win=gui.top(self.root,'コマンドの設定')
                try:
                    win.geometry('1320x860');self.root.update()
                    for expanded in (False, True):
                        if expanded:win.geometry('980x620');self.root.update()
                        for suffix in pairs:
                            x=win.command_entries['x'+suffix];y=win.command_entries['y'+suffix]
                            self.assertEqual(x.winfo_rooty(),y.winfo_rooty())
                            self.assertLess(x.winfo_rootx(),y.winfo_rootx())
                            for e in (x,y):
                                self.assertGreaterEqual(e.winfo_width(),30)
                                b=e.reference_button
                                self.assertTrue(b.winfo_ismapped());self.assertEqual(str(b.cget('compound')),'left')
                                self.assertLessEqual(b.winfo_rootx()+b.winfo_width(),win.winfo_rootx()+win.winfo_width())
                                self.assertTrue(b.tooltip_text)
                except Exception as exc:self.errors.append(exc)
                finally:win.destroy()
            self.root.after(40,inspect)
            edit_command(self.root,dict(type=kind),self.app.data['blocks'],self.app.data)

    def test_x_and_y_edits_and_reference_replace_are_independent_and_save_values(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                for key,value in [('x1','@X - 10'),('y1','@Y'),('x2','@X + 20'),('y2','@Y + 5')]:
                    e=win.command_entries[key];e.delete(0,'end');e.insert(0,value)
                self.assertEqual(win.command_entries['y1'].get(),'@Y')
                gui.button(win,'変更を保存').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(40,inspect)
        result=edit_command(self.root,dict(type='LINE'),self.app.data['blocks'],self.app.data)
        self.assertEqual(result['x1'],'@X - 10');self.assertEqual(result['y2'],'@Y + 5')
