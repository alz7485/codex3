import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from sample_project import EXAMPLE
from engine import compile_project, MacroError
from command_points import new_id, reference
from vertex_points import read_vertices, path_midpoint
from project_model import validate_sequential_project
from audit import audit_details
from guide_blocks import copy_to_guide

class ContinuousVertices(unittest.TestCase):
    def command(self,kind='LINE'):
        return dict(type=kind,x1='0',y1='0',x2='100',y2='50',points='0,0;100,0;100,50',vertices=[dict(id='a',x='@X',y='@Y'),dict(id='b',x='@X+100',y='@Y'),dict(id='c',x='@X+100',y='@Y+50')])
    def project(self,commands):
        p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=commands)];return p
    def test_line_three_vertices_scr_and_each_row(self):
        cmd=self.command();script,items=compile_project(json.loads(json.dumps(self.project([cmd]))),[0,1])
        self.assertIn('_.LINE\n_non\n100,100\n_non\n200,100\n_non\n200,150\n',script)
        self.assertEqual(items[0]['coords'],(100,100,200,100,200,150));self.assertEqual(items[1]['coords'],(420,100,520,100,520,150))
    def test_polyline_remains_one_closed_entity(self):
        script,items=compile_project(self.project([dict(self.command('POLYLINE'),closed='1')]),[0])
        self.assertIn('_.PLINE',script);self.assertIn('_Close',script);self.assertTrue(items[0]['closed'])
    def test_start_end_and_length_midpoint_references(self):
        cmd=self.command();cmd['point_id']=new_id()
        point=dict(type='POINT',x=reference(cmd['point_id'],'中点','X'),y=reference(cmd['point_id'],'終点','Y'))
        self.assertEqual(compile_project(self.project([cmd,point]),[0])[1][-1]['coords'],(175,150))
        self.assertEqual(path_midpoint((0,0,100,0,100,50)),(75,0))
    def test_structure_bad_expressions_and_adjacent_duplicates_rejected(self):
        for vertices in [[],[dict(x='0',y='0')],True,[dict(x=True,y='0'),dict(x='1',y='1')]]:
            self.assertTrue(validate_sequential_project(self.project([dict(self.command(),vertices=vertices)])))
        bad=self.command();bad['vertices'][1]['x']='__import__("os")'
        self.assertTrue(audit_details(self.project([dict(bad,condition='False')])))
        bad=self.command();bad['vertices'][1].update(x='@X',y='@Y')
        with self.assertRaises(MacroError):compile_project(self.project([bad]),[0])
    def test_raw_formulas_and_two_point_output_preserved(self):
        rows=read_vertices(dict(type='POLYLINE',points='max(@X, @Y),0; 点("id", "始点", "X"), 10'))
        self.assertEqual(rows[0]['x'],'max(@X, @Y)');self.assertIn('点(',rows[1]['x'])
        old=dict(type='LINE',x1='0',y1='0',x2='10',y2='0')
        new=dict(old,vertices=[dict(x='0',y='0'),dict(x='10',y='0')])
        self.assertEqual(compile_project(self.project([old]),[0]),compile_project(self.project([new]),[0]))
    def test_continuous_line_guide_and_loop_rejection(self):
        p=self.project([self.command()]);script=compile_project(p,[0])[0]
        copy_to_guide(p,p['blocks'][0]['id'],[p['blocks'][0]['commands'][0]])
        self.assertEqual(compile_project(p,[0])[0],script)
        bad=self.command();bad['vertices'][0]['x']='loop.index'
        with self.assertRaisesRegex(ValueError,'繰返し'):copy_to_guide(self.project([bad]),self.project([bad])['blocks'][0]['id'],[bad])
