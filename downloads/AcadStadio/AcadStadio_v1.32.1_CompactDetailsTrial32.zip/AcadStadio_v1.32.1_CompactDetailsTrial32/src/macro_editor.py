from point_preview_ui import PointReferencePreview
from command_points import POINTS, new_id, reference, clone_commands, rewrite_references
from table_grid import GridTreeview
"""Transactional preset/block editors and nested IF/REPEAT command forms."""

from project_data import get_rows
import copy
import tkinter as tk
from tkinter import ttk, messagebox
from engine import compile_project, parse_expression, MacroError, polyline_expressions
from command_types import DRAWING_TYPES, DIMENSION_TYPES, COMMAND_GROUPS
from project_model import validate_project, validate_sequential_project, walk_commands, valid_name
from preview import DrawingCanvas
from theme import fit_window
from cad_setup import STYLE_FIELDS, names as resource_names
from expression_sample import sample_value
from block_model import index_of, replace_collection
from input_assist import reference_groups, show_condition_builder, show_table_reference_picker
from cad_colors import ColorPicker, entity_color_code, entity_color_label, swatch
from ui_icons import icons_for, ICONS, layout_icon_toolbar

FIELDS = {
    "LINE": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y"),
    ],
    "CIRCLE": [("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "@OD / 2")],
    "RECTANGLE": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y + 50"),
    ],
    "TEXT": [
        ("layer", ""),
        ("x", "@X"),
        ("y", "@Y"),
        ("height", "settings.TEXT_HEIGHT"),
        ("angle", "0"),
        ("text", "@TYPE"),
    ],
    "DIMLINEAR": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y"),
        ("x3", "@X + 50"),
        ("y3", "@Y + 30"),
    ],
    "SET": [("name", "VALUE"), ("value", "0")],
    "IF": [("condition", '@TYPE == "A"')],
    "REPEAT": [("count", "3")],
    "SYSVAR": [
        ("name", "OSMODE"),
        ("value_kind", "number"),
        ("value", "0"),
        ("execution", "per_row"),
    ],
    "CUSTOM": [],
}
FIELDS.update(
    POLYLINE=[("layer", ""), ("points", "@X,@Y; @X+100,@Y; @X+100,@Y+50"), ("closed", "0")],
    ARC=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("start_angle", "0"), ("end_angle", "90")],
    ELLIPSE=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("rx", "40"), ("ry", "20"), ("angle", "0")],
    POINT=[("layer", ""), ("x", "@X"), ("y", "@Y")],
    DIMALIGNED=list(FIELDS["DIMLINEAR"]),
    DIMRADIUS=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("x3", "@X+40"), ("y3", "@Y+30")],
    DIMDIAMETER=[("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "25"), ("x3", "@X+40"), ("y3", "@Y+30")],
)
TYPE_LABELS = {
    "LINE": "LINE · 線分",
    "POLYLINE": "POLYLINE · ポリライン",
    "ARC": "ARC · 円弧",
    "ELLIPSE": "ELLIPSE · 楕円",
    "POINT": "POINT · 点",
    "DIMALIGNED": "DIMALIGNED · 平行寸法",
    "DIMRADIUS": "DIMRADIUS · 半径寸法",
    "DIMDIAMETER": "DIMDIAMETER · 直径寸法",
    "CIRCLE": "CIRCLE · 円",
    "RECTANGLE": "RECTANGLE · 長方形",
    "TEXT": "TEXT · 文字",
    "DIMLINEAR": "DIMLINEAR · 長さ寸法",
    "SET": "SET · 旧形式の変数代入",
    "IF": "IF / ELSE · 条件分岐",
    "REPEAT": "REPEAT · 繰り返し",
    "SYSVAR": "SYSVAR · システム変数変更",
    "CUSTOM": "CUSTOM · ユーザー登録コマンド",
}
LABELS = {
    "text_style": "文字スタイル",
    "dim_style": "寸法スタイル",
    "linetype": "線種",
    "color": "色（ACI）",
    "linetype_scale": "線種尺度（個別）",
    "points": "頂点（X,Y; X,Y; …）",
    "closed": "閉じる（0:開く / 1:閉じる）",
    "rx": "長軸半径",
    "ry": "短軸半径",
    "start_angle": "開始角度（°）",
    "end_angle": "終了角度（°・反時計回り）",
    "layer": "レイヤー",
    "x": "中心 / 挿入 X",
    "y": "中心 / 挿入 Y",
    "x1": "始点 X",
    "y1": "始点 Y",
    "x2": "終点 X",
    "y2": "終点 Y",
    "x3": "寸法位置 X",
    "y3": "寸法位置 Y",
    "r": "半径",
    "height": "文字高さ（図面単位）",
    "angle": "回転角度（°）",
    "text": "文字列",
    "name": "名前",
    "value": "代入する式",
    "condition": "実行条件（式）",
    "count": "反復回数（式）",
    "value_kind": "値の種類",
    "execution": "実行回数",
}


def command_summary(cmd):
    typ = cmd.get("type", "?").upper()
    if typ == "IF":
        return f"{cmd.get('condition', '')}  → {len(cmd.get('commands', []))}件 / ELSE {len(cmd.get('else', []))}件"
    if typ == "REPEAT":
        return f"{cmd.get('count', '')} 回 × {len(cmd.get('commands', []))}件"
    return ", ".join(
        f"{LABELS.get(k, k)}: {v}"
        for k, v in cmd.items()
        if k not in ("type", "commands", "else", "point_id")
    )


def edit_command(
    parent, current, blocks, project=None, local_names=(), *, sample_locals=None,
    folder_id="", point_sources=(),
):
    if current.get("type", "LINE").upper() not in FIELDS:
        messagebox.showerror("コマンドの確認", "このコマンドは追加・編集できません", parent=parent)
        return None
    win = tk.Toplevel(parent)
    win.title("コマンドの設定")
    fit_window(win, 860, 640, 760, 580)
    win.transient(parent.winfo_toplevel())
    win.grab_set()
    working = copy.deepcopy(current)
    result = []
    pending_point_ids = {}
    point_labels = {cmd['point_id']: f"コマンド{i+1}" for i,cmd in enumerate(point_sources) if cmd.get('point_id')}
    entries = {}
    win.command_entries = entries
    variables = {}
    argument_vars = {}
    selected_custom = [current.get("name", "")]
    focused = [None]
    old_type = current.get("type", "LINE").upper()
    drafts = {old_type: copy.deepcopy(current)}
    choice = tk.StringVar(value=TYPE_LABELS.get(old_type, TYPE_LABELS["LINE"]))
    header = ttk.Frame(win, padding=(16, 14))
    header.pack(fill="x")
    ttk.Label(header, text="① コマンドを選択", style="Section.TLabel").pack(side="left")
    picker = ttk.Combobox(
        header,
        textvariable=choice,
        values=[TYPE_LABELS[kind] for _, kinds in COMMAND_GROUPS for kind in kinds],
        state="readonly",
        width=32,
    )
    picker.pack(side="right")
    body = ttk.Frame(win, padding=(16, 0))
    body.pack(fill="both", expand=True)
    body.columnconfigure(0, weight=3)
    body.columnconfigure(1, weight=2)
    body.rowconfigure(0, weight=1)
    left = ttk.Frame(body)
    left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
    viewport = tk.Canvas(left, highlightthickness=0, bg="#f3f5f9")
    scroll = ttk.Scrollbar(left, command=viewport.yview)
    scroll.pack(side="right", fill="y")
    viewport.pack(side="left", fill="both", expand=True)
    viewport.configure(yscrollcommand=scroll.set)
    form = ttk.Frame(viewport)
    form_window = viewport.create_window(0, 0, window=form, anchor="nw")
    viewport.bind(
        "<Configure>", lambda e: viewport.itemconfigure(form_window, width=e.width)
    )
    form.bind(
        "<Configure>", lambda e: viewport.configure(scrollregion=viewport.bbox("all"))
    )

    refs = ttk.LabelFrame(body, text="参照一覧・式の試算", padding=10)
    refs.grid(row=0, column=1, sticky="nsew")
    refs.columnconfigure(0, weight=1)
    refs.rowconfigure(2, weight=1)
    ttk.Label(
        refs,
        text="入力欄を選び、候補をダブルクリック",
        style="Muted.TLabel",
        wraplength=250,
    ).grid(row=0, column=0, sticky="w")
    query = tk.StringVar()
    ttk.Entry(refs, textvariable=query).grid(row=1, column=0, sticky="ew", pady=7)
    listing = tk.Listbox(
        refs,
        exportselection=False,
        relief="flat",
        bg="white",
        activestyle="none",
        height=10,
    )
    listing.grid(row=2, column=0, sticky="nsew")
    project = project or {}
    sample_frame = ttk.LabelFrame(refs, text="選択した入力欄の試算", padding=8)
    sample_frame.grid(row=5, column=0, sticky="ew", pady=(6, 0))
    sample_row = tk.StringVar(value="1")
    sample_picker = ttk.Combobox(
        sample_frame,
        textvariable=sample_row,
        values=[str(i + 1) for i in range(len(get_rows(project)))],
        state="readonly",
        width=8,
    )
    ttk.Label(sample_frame, text="試算する行:").pack(side="left")
    sample_picker.pack(side="left", padx=5)
    sample_result = tk.StringVar(value="数値・条件の入力欄を選択してください")
    ttk.Label(refs, textvariable=sample_result, wraplength=250).grid(
        row=6, column=0, sticky="ew", pady=6
    )
    # Expose state for keyboard/accessibility tooling and real-widget regression tests.
    win.sample_result, win.sample_row = sample_result, sample_row

    def update_sample(*_):
        key = next((k for k, widget in entries.items() if widget is focused[0]), None)
        var = variables.get(key)
        if key and key.startswith("arg:"):
            var = argument_vars.get(key[4:])
            kind = next(
                (
                    p["kind"]
                    for p in project.get("custom_commands", {})
                    .get(selected_custom[0], {})
                    .get("parameters", [])
                    if p["name"] == key[4:]
                ),
                "text",
            )
            if kind != "number":
                sample_result.set("文字引数です。数値欄を選ぶと試算できます。")
                return
        if key in STYLE_FIELDS:
            sample_result.set(
                "空欄は直前の設定を引き継ぎます。先頭ではCADの現在の設定を使います。"
            )
            return
        if key in ("name", "text", "execution", "value_kind") or var is None:
            sample_result.set("数値・条件の入力欄を選択してください")
            return
        text = var.get().strip()
        if "点(" in text or "点位置(" in text:
            sample_result.set("点参照の値はブロックのプレビューで確認できます")
            return
        if key == "color":
            text = entity_color_code(text)
        if key in ("color", "linetype_scale") and not text:
            sample_result.set("空欄は直前の設定を引き継ぎます。先頭ではCADの現在値を使います。")
            return
        if not text and key == "condition":
            sample_result.set("条件なし: 常に実行")
            return
        if (
            key == "value"
            and active[0] == "SYSVAR"
            and variables.get("value_kind").get() == "text"
        ):
            sample_result.set("文字列の値です")
            return
        try:
            if key == "points":
                points = polyline_expressions(text)
                shown = [tuple(sample_value(project, expression, max(0, int(sample_row.get())-1), sample_locals) for expression in point) for point in points[:3]]
                sample_result.set(f"{len(points)}頂点: {shown}" + (" …" if len(points) > 3 else ""))
                return
            value = sample_value(
                project, text, max(0, int(sample_row.get()) - 1), sample_locals
            )
            rendered = f"{value:.12g}" if type(value) in (int, float) else str(value)
            sample_result.set(
                f"{sample_row.get()}行目 → {rendered}\n繰り返しの値は実行時に確定します。"
            )
        except (MacroError, ValueError, IndexError) as exc:
            sample_result.set("試算できません: " + str(exc))

    def focus_sample(event):
        focused[0] = event.widget
        update_sample()

    sample_row.trace_add("write", update_sample)
    ref_groups = reference_groups(project, local_names)
    candidates = [ref for _, group in ref_groups for ref in group]

    def filter_refs(*_):
        listing.delete(0, "end")
        for ref in dict.fromkeys(candidates):
            if query.get().lower() in ref.lower():
                listing.insert("end", ref)

    query.trace_add("write", filter_refs)
    filter_refs()

    def place_ref(entry, key, value, replace=False):
        if entry is None or not entry.winfo_exists():
            return
        if replace:
            entry.delete(0, "end")
        param_kind = next(
            (
                p["kind"]
                for p in project.get("custom_commands", {})
                .get(selected_custom[0], {})
                .get("parameters", [])
                if "arg:" + p["name"] == key
            ),
            None,
        )
        is_sysvar_text = (
            key == "value"
            and active[0] == "SYSVAR"
            and variables.get("value_kind") is not None
            and variables["value_kind"].get() == "text"
        )
        if (
            key in ("text", "layer") or param_kind == "text" or is_sysvar_text
        ) and not entry.get():
            if key == "text" and value.startswith("@"):
                pass
            else:
                entry.insert(0, "=")
        if entry.selection_present():
            entry.delete(tk.SEL_FIRST, tk.SEL_LAST)
        entry.insert(tk.INSERT, value)
        entry.focus_set()

    def choose_command_point(key):
        is_argument = key.startswith("arg:")
        param = next((p for p in project.get("custom_commands", {}).get(selected_custom[0], {}).get("parameters", []) if "arg:"+p["name"] == key), {})
        suffix = key[1:]
        xkey, ykey = "x"+suffix, "y"+suffix
        if not is_argument and (xkey not in variables or ykey not in variables):
            return
        candidates=[(i,c) for i,c in enumerate(point_sources) if c.get("type") in POINTS]
        if not candidates:
            messagebox.showinfo("コマンドの点", "同じリストで、このコマンドより前に線・円などを追加してください。", parent=win)
            return
        dialog=tk.Toplevel(win);dialog.title("コマンドの点を選択");dialog.transient(win);dialog.grab_set()
        fit_window(dialog, 1020, 560, 860, 500)
        buttons=ttk.Frame(dialog,padding=14);buttons.pack(side="bottom",fill="x")
        body=ttk.Frame(dialog,padding=(16,16,16,0));body.pack(fill="both",expand=True)
        body.columnconfigure(0,weight=1,uniform="point");body.columnconfigure(1,weight=1,uniform="point");body.rowconfigure(0,weight=1)
        area=ttk.Frame(body);area.grid(row=0,column=0,sticky="nsew",padx=(0,16))
        visual=None
        ttk.Label(area,text="入力先: "+LABELS.get(key, param.get("label", key)),style="Section.TLabel").pack(anchor="w",pady=(0,8))
        ttk.Label(area,text="参照元のコマンド").pack(anchor="w")
        source=ttk.Combobox(area,state="readonly",values=[f"{i+1}: {TYPE_LABELS[c['type']]}  {command_summary(c)}" for i,c in candidates])
        source.pack(fill="x",pady=(6,12));source.current(0)
        ttk.Label(area,text="使用する点").pack(anchor="w")
        point=ttk.Combobox(area,state="readonly");point.pack(fill="x",pady=6)
        def sync(*_):
            point.configure(values=POINTS[candidates[source.current()][1]['type']]);point.current(0)
            if visual is not None:
                visual.load(candidates[source.current()][0]);update_visual()
        source.bind("<<ComboboxSelected>>",sync);sync()
        combined = is_argument and param.get("kind") == "text"
        axis = None
        offsets = {}
        if not combined:
            ttk.Label(area,text="取得する座標").pack(anchor="w",pady=(6,0))
            axis=ttk.Combobox(area,state="readonly",values=("X","Y"));axis.pack(fill="x",pady=4)
            axis.set(key[0].upper() if not is_argument else "X")
            ttk.Label(area,text="ずらし量（例：-10、@OD / 2）").pack(anchor="w")
            offsets["value"]=tk.StringVar(value="0")
            ttk.Entry(area,textvariable=offsets["value"]).pack(fill="x",pady=4)
        else:
            for axis_name in ("X", "Y"):
                row=ttk.Frame(area);row.pack(fill="x",pady=3)
                ttk.Label(row,text=axis_name+"方向のずらし量",width=20).pack(side="left")
                offsets[axis_name]=tk.StringVar(value="0")
                ttk.Entry(row,textvariable=offsets[axis_name]).pack(side="left",fill="x",expand=True)
        ttk.Label(area,text="参照元の座標変更に追従します。重なる図形の選択はCAD側でも確認してください。",wraplength=370,style="Muted.TLabel").pack(anchor="w",pady=8)
        def update_visual(*_):
            if visual is not None:
                visual.update_selection(point.get(),axis.get() if axis else None,{k:v.get() for k,v in offsets.items()})
        def pick_visual(name):
            point.set(name);update_visual()
        visual=PointReferencePreview(body,project,point_sources,pick_visual,
                                     max(0,int(sample_row.get() or '1')-1),sample_locals)
        visual.grid(row=0,column=1,sticky="nsew")
        dialog.point_preview=visual
        visual.load(candidates[0][0]);update_visual()
        point.bind("<<ComboboxSelected>>",update_visual)
        if axis:axis.bind("<<ComboboxSelected>>",update_visual)
        for variable in offsets.values():variable.trace_add("write",update_visual)
        def close():
            dialog.destroy();win.grab_set()
        def apply():
            i,cmd=candidates[source.current()]
            identity=cmd.get("point_id") or pending_point_ids.setdefault(i,new_id())
            point_labels[identity] = f"コマンド{i+1}"
            shifts={key:var.get().strip() or "0" for key,var in offsets.items()}
            try:
                for expression in shifts.values():
                    parse_expression(expression)
            except MacroError as exc:
                messagebox.showerror("ずらし量の確認",str(exc),parent=dialog);return
            if combined:
                argument_vars[key[4:]].set(f"=点位置({identity!r}, {point.get()!r}, {shifts['X']}, {shifts['Y']})")
            else:
                expression=reference(identity,point.get(),axis.get())
                if shifts["value"] != "0":
                    expression += " + ("+shifts["value"]+")"
                if is_argument:
                    argument_vars[key[4:]].set(expression)
                else:
                    variables[key].set(expression)
            if is_argument:
                var=argument_vars[key[4:]]
            else:
                var=variables[key]
            var.set(rewrite_references(var.get(),point_labels))
            close()
        ttk.Button(buttons,text="キャンセル",command=close).pack(side="left")
        ttk.Button(buttons,text="この点を使用",style="Primary.TButton",command=apply).pack(side="right")
        dialog.protocol("WM_DELETE_WINDOW",close);dialog.bind("<Escape>",lambda e:close())

    win.choose_command_point = choose_command_point

    def add_reference_menu(row, entry, key):
        """Let every applicable field use a table picker or the old quick menu."""
        menu_button = ttk.Menubutton(row, text="表・変数 ▾", width=2, style="MainIcon.TMenubutton")
        menu_button.icon_button_style = "MainIcon.TMenubutton"
        entry.reference_button = menu_button
        menu = tk.Menu(menu_button, tearoff=0)
        menu.add_command(
            label="表の列・セルから選ぶ…",
            command=lambda e=entry, k=key: show_table_reference_picker(
                win, project,
                lambda ref: place_ref(e, k, ref),
                on_replace=lambda ref: place_ref(e, k, ref, replace=True),
            ),
        )
        if key in ("x", "y", "x1", "y1", "x2", "y2", "x3", "y3") or key.startswith("arg:"):
            menu.add_command(label="別コマンドの始点・中点・終点から選ぶ…", command=lambda k=key: choose_command_point(k))
        menu.add_separator()
        for group_title, group_refs in ref_groups:
            group_menu = tk.Menu(menu, tearoff=0)
            for ref in group_refs:
                group_menu.add_command(
                    label=ref,
                    command=lambda e=entry, k=key, r=ref: place_ref(e, k, r),
                )
            menu.add_cascade(label=group_title, menu=group_menu)
        menu_button.configure(menu=menu)
        menu_button.pack(side="left", padx=(3, 0))

    def insert_ref(*_):
        selected = listing.curselection()
        if not selected:
            return
        entry = focused[0]
        key = next((k for k, e in entries.items() if e is entry), "")
        place_ref(entry, key, listing.get(selected[0]))

    listing.bind("<Double-1>", insert_ref)
    ttk.Button(
        refs, text="選択した参照を挿入", command=insert_ref, style="Compact.TButton"
    ).grid(row=3, column=0, sticky="ew", pady=(6, 0))
    ttk.Label(
        refs,
        text="loop.index: 0始まり / number: 1始まり\nloop.count: 反復回数（繰り返し内のみ）",
        style="Muted.TLabel",
        wraplength=250,
    ).grid(row=4, column=0, sticky="w", pady=(6, 0))
    refs.grid_remove()
    body.columnconfigure(0, weight=1)
    body.columnconfigure(1, weight=0)
    left.grid_configure(padx=(0, 0))

    def toggle_refs():
        if refs.winfo_manager():
            refs.grid_remove()
            body.columnconfigure(1, weight=0)
            left.grid_configure(padx=(0, 0))
            ref_button.configure(text="列・変数の一覧と試算を表示 ▸")
        else:
            refs.grid()
            body.columnconfigure(1, weight=2)
            body.columnconfigure(0, weight=3)
            left.grid_configure(padx=(0, 16))
            ref_button.configure(text="参照一覧を閉じる ◂")

    assist_row = ttk.Frame(win, padding=(16, 0))
    assist_row.pack(fill="x", before=body)
    ttk.Label(
        assist_row, text="② 数値・式を入力、または右のアイコンから参照を選択", style="Muted.TLabel"
    ).pack(side="left")
    ref_button = ttk.Button(
        assist_row, text="列・変数の一覧と試算を表示 ▸", command=toggle_refs
    )
    ref_button.pack(side="right")
    active = [old_type]
    details_expanded = [None]

    def gather():
        data = {
            "type": active[0],
            **working,
            **{k: v.get() for k, v in variables.items()},
        }
        if "color" in data:
            data["color"] = entity_color_code(data["color"])
        if active[0] == "CUSTOM":
            data.update(
                name=selected_custom[0],
                arguments={k: v.get() for k, v in argument_vars.items()},
            )
        return rewrite_references(data, {label: identity for identity,label in point_labels.items()})

    def branch(key):
        working.update({k: v.get() for k, v in variables.items()})
        staged = copy.deepcopy(working.get(key, []))
        before_blocks = copy.deepcopy(blocks)
        sub = tk.Toplevel(win)
        sub.title(
            "IF: 実行する側"
            if key == "commands" and active[0] == "IF"
            else "ELSE: 条件に合わない側"
            if key == "else"
            else "繰り返すコマンド"
        )
        sub.geometry("880x540")
        sub.transient(win)
        sub.grab_set()
        ttk.Label(
            sub, text="ここに追加したコマンドを、上から順番に実行します。", padding=12
        ).pack(anchor="w")
        editor = CommandList(
            sub,
            staged,
            blocks,
            project=project,
            local_names=sample_locals or local_names,
            folder_id=folder_id,
        )

        def cancel():
            if (
                staged != working.get(key, []) or blocks != before_blocks
            ) and not messagebox.askyesno(
                "変更の破棄", "この階層の変更を破棄しますか？", parent=sub
            ):
                return
            replace_collection(blocks, before_blocks)
            sub.destroy()

        def commit():
            working[key] = copy.deepcopy(editor.commands)
            sub.destroy()

        bar = ttk.Frame(sub, padding=10)
        bar.pack(side="bottom", fill="x", before=editor.frame)
        ttk.Button(bar, text="キャンセル", command=cancel).pack(side="left")
        ttk.Button(
            bar, text="この階層を確定", style="Primary.TButton", command=commit
        ).pack(side="right")
        sub.protocol("WM_DELETE_WINDOW", cancel)
        sub.bind("<Escape>", lambda e: cancel())
        win.wait_window(sub)
        win.grab_set()
        redraw(False)

    def redraw(changed=True):
        if changed:
            drafts[active[0]] = gather()
            typ = next(k for k, v in TYPE_LABELS.items() if v == choice.get())
            active[0] = typ
            working.clear()
            working.update(copy.deepcopy(drafts.get(typ, {"type": typ})))
        for widget in form.winfo_children():
            widget.destroy()
        entries.clear()
        variables.clear()
        argument_vars.clear()
        focused[0] = None
        typ = active[0]
        if typ == "CUSTOM":
            catalog = project.get("custom_commands", {})
            if selected_custom[0] not in catalog:
                selected_custom[0] = next(iter(catalog), "")
            row = ttk.Frame(form)
            row.pack(fill="x", pady=4)
            ttk.Label(row, text="登録したコマンド", width=18).pack(side="left")
            names = {k: d["name"] for k, d in catalog.items()}
            custom_choice = tk.StringVar(value=names.get(selected_custom[0], ""))
            combo = ttk.Combobox(
                row,
                textvariable=custom_choice,
                values=list(names.values()),
                state="readonly",
            )
            combo.pack(side="left", fill="x", expand=True)

            def choose_custom(_=None):
                working["condition"] = variables.get(
                    "condition", tk.StringVar(value="")
                ).get()
                selected_custom[0] = next(
                    (k for k, v in names.items() if v == custom_choice.get()), ""
                )
                working["name"] = selected_custom[0]
                working["arguments"] = {}
                redraw(False)

            combo.bind("<<ComboboxSelected>>", choose_custom)
            if not catalog:
                ttk.Label(
                    form,
                    text="メイン画面の「登録コマンド」から新規登録できます。",
                    wraplength=400,
                ).pack(anchor="w", pady=12)
            definition = catalog.get(selected_custom[0], {})
            ttk.Label(
                form,
                text=definition.get("description", ""),
                style="Muted.TLabel",
                wraplength=400,
            ).pack(anchor="w", pady=8)
            ttk.Label(
                form,
                text="実行: "
                + (
                    "生成全体で1回"
                    if definition.get("execution") == "once"
                    else "対象の各行"
                )
                + " / 図形プレビュー対象外",
                style="Muted.TLabel",
                wraplength=400,
            ).pack(anchor="w", pady=(0, 7))
            for param in definition.get("parameters", []):
                row = ttk.Frame(form)
                row.pack(fill="x", pady=4)
                ttk.Label(row, text=param.get("label", param["name"]), width=18).pack(
                    side="left"
                )
                original = (
                    working.get("arguments", {})
                    if working.get("name") == selected_custom[0]
                    else {}
                )
                value = tk.StringVar(
                    value=rewrite_references(str(original.get(param["name"], param.get("default", ""))), point_labels)
                )
                entry = ttk.Entry(row, textvariable=value)
                entry.pack(side="left", fill="x", expand=True)
                argument_vars[param["name"]] = value
                entries["arg:" + param["name"]] = entry
                entry.bind("<FocusIn>", focus_sample)
                value.trace_add("write", update_sample)
                add_reference_menu(row, entry, "arg:" + param["name"])
        fields = list(FIELDS[typ])
        if typ in DRAWING_TYPES:
            fields.insert(1, ("linetype", ""))
            fields.extend([("color", ""), ("linetype_scale", "")])
        if typ == "TEXT":
            fields.insert(2, ("text_style", ""))
        if typ in DIMENSION_TYPES:
            fields.insert(2, ("dim_style", ""))
        if typ != "IF":
            fields.append(("condition", ""))
        advanced_keys = {"layer", "linetype", "color", "linetype_scale", "text_style", "dim_style", "condition"}
        if typ == "IF":
            advanced_keys.discard("condition")
        # Create every variable even when its row is hidden. Hidden optional
        # settings must survive switching types and never be silently reset.
        basic_section = ttk.Frame(form)
        basic_section.pack(fill="x")
        advanced_section = ttk.Frame(form)
        advanced_rows = {}
        win.advanced_rows = advanced_rows
        count = sum(
            bool(str(working.get(key, "")).strip())
            for key, _ in fields if key in advanced_keys
        )
        expanded = details_expanded[0] if details_expanded[0] is not None else count > 0
        details_button = None

        def detail_count():
            return sum(bool(var.get().strip()) for key, var in variables.items()
                       if key in advanced_keys)

        def update_detail_label(*_):
            if details_button is not None:
                details_button.configure(
                    text="▾ 詳細設定を閉じる" if advanced_section.winfo_manager()
                    else f"▸ 詳細設定（レイヤー・色・線種・尺度・条件 / {detail_count()}項目設定済み）"
                )

        def toggle_details():
            details_expanded[0] = not bool(advanced_section.winfo_manager())
            if details_expanded[0]:
                advanced_section.pack(fill="x", after=details_button, pady=(3, 0))
            else:
                advanced_section.pack_forget()
            update_detail_label()

        coordinate_rows = {}
        field_names = {key for key, _ in fields}
        for key, default in fields:
            optional = key in advanced_keys
            is_coordinate = key in ("x", "y", "x1", "y1", "x2", "y2", "x3", "y3") and "x"+key[1:] in field_names and "y"+key[1:] in field_names
            if is_coordinate:
                suffix = key[1:]
                if suffix not in coordinate_rows:
                    group = ttk.Frame(basic_section)
                    group.pack(fill="x", pady=4)
                    if suffix == "":
                        title = "挿入点" if typ == "TEXT" else "位置" if typ == "POINT" else "中心"
                    elif suffix == "3":
                        title = "寸法位置"
                    elif typ in ("DIMLINEAR", "DIMALIGNED"):
                        title = "測定点" + suffix
                    elif typ == "RECTANGLE":
                        title = "対角点" + suffix
                    else:
                        title = "始点" if suffix == "1" else "終点"
                    ttk.Label(group, text=title, width=14).pack(side="left")
                    axes = ttk.Frame(group)
                    axes.pack(side="left", fill="x", expand=True)
                    axes.columnconfigure((0, 1), weight=1, uniform="coordinate")
                    coordinate_rows[suffix] = axes
                axes = coordinate_rows[suffix]
                row = ttk.Frame(axes)
                row.grid(row=0, column=0 if key[0] == "x" else 1, sticky="ew", padx=(0, 8) if key[0] == "x" else (0, 0))
                ttk.Label(row, text=key[0].upper(), width=2).pack(side="left")
            elif optional and key != "condition":
                tile = ttk.Frame(advanced_section)
                advanced_rows[key] = tile
                ttk.Label(tile, text="線種尺度" if key == "linetype_scale" else LABELS.get(key, key), width=12).pack(side="left")
                row = tile
            else:
                row = ttk.Frame(advanced_section if optional else basic_section)
                if optional:
                    advanced_rows[key] = row
                else:
                    row.pack(fill="x", pady=4)
                ttk.Label(row, text=LABELS.get(key, key), width=14).pack(side="left")
            value = tk.StringVar(value=rewrite_references(str(working.get(key, default)), point_labels))
            if key == "color":
                value.set(entity_color_label(value.get()))
                entry = ttk.Combobox(
                    row, textvariable=value,
                    width=1, values=["", entity_color_label(256), entity_color_label(0), *[entity_color_label(i) for i in range(1, 10)]],
                )
            elif key in STYLE_FIELDS:
                entry = ttk.Combobox(
                    row,
                    textvariable=value,
                    values=["", *resource_names(project, STYLE_FIELDS[key])], width=1,
                )
            elif key in ("value_kind", "execution"):
                entry = ttk.Combobox(
                    row,
                    textvariable=value,
                    values=["number", "text"]
                    if key == "value_kind"
                    else ["per_row", "once"],
                    state="readonly",
                )
            else:
                entry = ttk.Entry(row, textvariable=value, width=1 if is_coordinate or optional else 20)
            entry.pack(side="left", fill="x", expand=True)
            if key == "color":
                chip = tk.Label(row, width=2, relief="solid", borderwidth=1)
                chip.pack(side="left", padx=5)

                def update_color_chip(*_, variable=value, label=chip):
                    try:
                        index = int(entity_color_code(variable.get()))
                        label.configure(bg=swatch(index) if 1 <= index <= 255 else "#f3f5f9")
                    except (ValueError, IndexError):
                        label.configure(bg="#f3f5f9")

                value.trace_add("write", update_color_chip)
                update_color_chip()
                palette = ttk.Button(row, text="色見本…", image=icons_for(win).get("colors"), compound="none", width=2,
                                     style="MainIcon.TButton", command=lambda v=value: ColorPicker(win, v, title="作図する図形の色を選択"))
                palette.pack(side="left")
                palette.tooltip_text = "色見本から選ぶ"
                palette.bind("<Enter>", lambda e, b=palette: icons_for(win).schedule(b, b.tooltip_text))
                palette.bind("<Leave>", lambda e: icons_for(win).hide())
            variables[key] = value
            entries[key] = entry
            entry.bind("<FocusIn>", focus_sample)
            if is_coordinate:
                entry.bind("<Enter>", lambda event, e=entry, k=key: icons_for(win).schedule(e, LABELS.get(k,k)+": "+e.get()))
                entry.bind("<Leave>", lambda event: icons_for(win).hide())
            value.trace_add("write", update_sample)
            if optional:
                value.trace_add("write", update_detail_label)
            if (isinstance(entry, ttk.Entry)
                    and not isinstance(entry, ttk.Combobox)
                    and key not in ("name", "value_kind", "execution")):
                add_reference_menu(row, entry, key)
            if key == "condition":
                ttk.Button(
                    row,
                    text="条件を作る…",
                    command=lambda v=value: show_condition_builder(win, v, project, local_names),
                ).pack(side="left", padx=(6, 0))
        def arrange_details(event=None):
            columns = 2 if advanced_section.winfo_width() >= 600 else 1
            for column in (0, 1):
                advanced_section.columnconfigure(column, weight=1 if column < columns else 0, uniform="details" if column < columns else "")
            order = [key for key in ("layer", "linetype", "color", "linetype_scale", "text_style", "dim_style") if key in advanced_rows]
            for i, key in enumerate(order):
                advanced_rows[key].grid(row=i//columns, column=i%columns, columnspan=1, sticky="new",
                                        padx=(0, 12) if columns == 2 and i%columns == 0 else (0, 0), pady=(5, 5))
            if "condition" in advanced_rows:
                advanced_rows["condition"].grid(row=(len(order)+columns-1)//columns, column=0, columnspan=columns, sticky="ew", pady=(6, 4))
        advanced_section.bind("<Configure>", arrange_details)
        arrange_details()
        if advanced_keys.intersection(key for key, _ in fields):
            details_button = ttk.Button(
                form,
                text=("▾ 詳細設定を閉じる" if expanded
                      else f"▸ 詳細設定（レイヤー・色・線種・尺度・条件 / {count}項目設定済み）"),
                command=toggle_details,
            )
            details_button.pack(fill="x", pady=(10, 0))
            if expanded:
                advanced_section.pack(fill="x", after=details_button, pady=(3, 0))
        if typ in ("IF", "REPEAT"):
            for key, label in [
                ("commands", "実行するコマンド" if typ == "IF" else "繰り返すコマンド")
            ] + ([("else", "ELSE のコマンド")] if typ == "IF" else []):
                ttk.Button(
                    form,
                    text=f"{label}を編集（{len(working.get(key, []))}件）",
                    command=lambda k=key: branch(k),
                ).pack(fill="x", pady=(12, 0))
        tips = ("条件が空欄なら常に実行。数値欄には値・列参照・計算式を入力できます。"
                "\n行指定: @X{2} は2行目固定、[表名]@X{@ROW} はROW列で行指定。"
                " 省略時は作図対象の行です。"
                "\nレイヤー・線種・スタイルの空欄は直前の設定を引き継ぎます。座標・長さは図面単位です。")
        if typ in DRAWING_TYPES:
            tips += "\n色・線種尺度も空欄は引継ぎ。線種尺度は正数・式で指定（CELTSCALE）。破線間隔はCADで確認してください。"
        if typ == "POLYLINE":
            tips += "\n頂点は X,Y; X,Y; … の順。各座標に式を使えます。閉じるは0（開く）または1。"
        if typ == "ARC":
            tips += "\n角度は+X方向が0°、反時計回り。0°→360°はCIRCLEを使ってください。"
        if typ == "POINT":
            tips += "\n点のCAD上の表示形式はPDMODE・PDSIZEの現在値に従います。"
        if typ in ("DIMRADIUS", "DIMDIAMETER"):
            tips += "\n中心・半径から独立した寸法を作成します。既存の円の選択は不要です。"
        if typ == "TEXT":
            tips += "\n文字列はそのまま入力。式で組み立てるときは = で始めます。"
        if typ == "SYSVAR":
            tips += "\nnumberは数値・式、textは文字列（=式も可）。onceは生成全体で1回。"
        if typ == "CUSTOM":
            tips += "\n数値引数は式、文字列引数はそのまま入力（=式も可）。登録内容はメイン画面で編集できます。"
        if typ == "REPEAT":
            tips += "\n回数は0〜1000の整数。内側で loop.index を参照できます。"
        ttk.Label(form, text=tips, style="Muted.TLabel", wraplength=620).pack(
            anchor="w", pady=(12, 5)
        )
        ttk.Label(
            form, textvariable=sample_result, style="Muted.TLabel", wraplength=620
        ).pack(anchor="w", pady=(0, 10))

    redraw(False)
    picker.bind("<<ComboboxSelected>>", lambda e: redraw())
    original_blocks = copy.deepcopy(blocks)

    def cancel():
        if (
            gather() != current or blocks != original_blocks
        ) and not messagebox.askyesno(
            "変更の破棄", "コマンドの変更を破棄しますか？", parent=win
        ):
            return
        replace_collection(blocks, original_blocks)
        win.destroy()

    def accept():
        d = gather()
        d["type"] = active[0]
        if d["type"] == "SET" and not valid_name(d.get("name")):
            return messagebox.showerror(
                "変数名",
                "英数字と_の名前を指定してください。予約名は使えません",
                parent=win,
            )
        try:
            for k, v in variables.items():
                text = v.get().strip()
                if k == "color":
                    text = entity_color_code(text)
                if k in (
                    "name",
                    "layer",
                    "text",
                    "value_kind",
                    "execution",
                    "linetype",
                    "text_style",
                    "dim_style",
                ):
                    continue
                if (
                    k == "value"
                    and d["type"] == "SYSVAR"
                    and d.get("value_kind") == "text"
                ):
                    if text.startswith("="):
                        parse_expression(text[1:])
                    continue
                if k in ("name", "layer", "text"):
                    continue
                if not text:
                    if k in ("color", "linetype_scale") or (k == "condition" and d["type"] != "IF"):
                        continue
                    raise MacroError(LABELS.get(k, k) + " を入力してください")
                if k == "points":
                    polyline_expressions(text)
                else:
                    parse_expression(text)
        except MacroError as exc:
            return messagebox.showerror("入力内容の確認", str(exc), parent=win)
        if d["type"] == "CUSTOM":
            catalog = project.get("custom_commands", {})
            if d.get("name") not in catalog:
                return messagebox.showerror(
                    "登録コマンド", "コマンドを登録・選択してください", parent=win
                )
            try:
                for param in catalog[d["name"]].get("parameters", []):
                    value = d["arguments"][param["name"]]
                    if param["kind"] == "number":
                        parse_expression(value)
                    elif value.startswith("="):
                        parse_expression(value[1:])
            except MacroError as exc:
                return messagebox.showerror("引数の確認", str(exc), parent=win)
        if d["type"] == "SYSVAR":
            import re

            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", d["name"]):
                return messagebox.showerror(
                    "システム変数名", "例: OSMODE / CMDECHO", parent=win
                )
        for index, identity in pending_point_ids.items():
            point_sources[index]["point_id"] = identity
        result.append(d)
        win.destroy()

    bar = ttk.Frame(win, padding=16)
    bar.pack(side="bottom", fill="x", before=body)
    ttk.Button(bar, text="キャンセル", command=cancel).pack(side="left")
    ttk.Button(
        bar, text="コマンドを確定", style="Primary.TButton", command=accept
    ).pack(side="right")
    win.protocol("WM_DELETE_WINDOW", cancel)
    win.bind("<Escape>", lambda e: cancel())
    parent.wait_window(win)
    try:
        parent.winfo_toplevel().grab_set() if parent.winfo_toplevel() is not parent._root() else None
    except tk.TclError:
        pass
    return result[0] if result else None


class CommandList:
    def __init__(
        self,
        parent,
        commands,
        blocks,
        on_select=None,
        on_change=None,
        project=None,
        local_names=(),
        folder_id="",
    ):
        self.commands = commands
        self.blocks = blocks
        self.on_select = on_select
        self.on_change = on_change
        self.project = project
        self.local_names = local_names
        self.folder_id = folder_id
        self.undo_stack = []
        self.redo_stack = []
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.frame.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)
        self.icons = icons_for(parent)
        self.command_images = {kind: self.icons.get(ICONS[label][0]) for label, kinds in COMMAND_GROUPS for kind in kinds}
        self.tree = GridTreeview(
            self.frame,
            columns=("detail",),
            show="tree headings",
            selectmode="extended",
            height=7,
            style="Command.Treeview",
        )
        for key, label, width in [
            ("#0", "コマンド", 220),
            ("detail", "設定 / 条件", 480),
        ]:
            self.tree.heading(key, text=label)
            self.tree.column(
                key, width=width, minwidth=190 if key == "#0" else 120,
                stretch=key != "#0",
            )
        self.tree.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(self.frame, command=self.tree.yview)
        ys.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=ys.set)
        xs = ttk.Scrollbar(self.frame, orient="horizontal", command=self.tree.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.tree.configure(xscrollcommand=xs.set)
        self.tree.bind("<Double-1>", lambda e: self.edit())
        self.tree.bind("<Return>", lambda e: self.edit())
        self.tree.bind(
            "<<TreeviewSelect>>",
            lambda e: self.on_select(self.indices()) if self.on_select else None,
        )
        self.tree.bind("<Alt-Up>", lambda e: self.move(-1))
        self.tree.bind("<Alt-Down>", lambda e: self.move(1))
        self.tree.bind("<Delete>", lambda e: self.delete())
        self.tree.bind("<Control-d>", lambda e: self.duplicate())
        self.tree.bind("<Control-z>", lambda e: (self.undo(), "break")[-1])
        self.tree.bind("<Control-y>", lambda e: (self.redo(), "break")[-1])
        self.toolbar = bar = ttk.Frame(parent, padding=(0, 4))
        bar.pack(fill="x", padx=10, before=self.frame)
        actions = [(label, None) for label, _ in COMMAND_GROUPS] + [
            ("編集", self.edit), ("複製", self.duplicate), ("削除", self.delete),
            ("↑", lambda: self.move(-1)), ("↓", lambda: self.move(1)),
            ("元に戻す", self.undo), ("やり直し", self.redo),
        ]
        for i, (label, action) in enumerate(actions):
            if i < len(COMMAND_GROUPS):
                button = ttk.Menubutton(bar, text=label, width=2)
                button.icon_button_style = "MainIcon.TMenubutton"
                menu = tk.Menu(button, tearoff=0)
                for kind in COMMAND_GROUPS[i][1]:
                    menu.add_command(label=TYPE_LABELS[kind], command=lambda k=kind: self.add(k))
                button.configure(menu=menu)
            else:
                button = ttk.Button(bar, text=label, command=action, width=2)
                button.icon_button_style = "MainIcon.TButton"
            button.icon_only = True
            button.icon_button_width = 2
            button.grid(row=0, column=i, padx=(0, 2), pady=0, sticky="ew")
        bar.bind("<Configure>", lambda event: layout_icon_toolbar(bar, event.width, grid=True))
        self.refresh()

    def snapshot(self):
        self.undo_stack.append(
            (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
        )
        self.undo_stack = self.undo_stack[-100:]
        self.redo_stack.clear()

    def restore(self, state):
        self.commands[:] = state[0]
        replace_collection(self.blocks, state[1])
        self.refresh()

    def undo(self):
        if self.undo_stack:
            self.redo_stack.append(
                (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
            )
            self.restore(self.undo_stack.pop())

    def redo(self):
        if self.redo_stack:
            self.undo_stack.append(
                (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
            )
            self.restore(self.redo_stack.pop())

    def indices(self):
        return sorted(int(i) for i in self.tree.selection())

    def refresh(self, selection=None):
        self.tree.delete(*self.tree.get_children())
        for i, cmd in enumerate(self.commands):
            display = rewrite_references(dict(cmd), {c["point_id"]:f"コマンド{j+1}" for j,c in enumerate(self.commands) if c.get("point_id")})
            self.tree.insert(
                "",
                "end",
                iid=str(i),
                text=TYPE_LABELS.get(cmd.get("type"), cmd.get("type", "?")),
                image=self.command_images.get(cmd.get("type"), self.icons.get("commands")),
                values=(
                    (self.project or {})
                    .get("custom_commands", {})
                    .get(cmd.get("name"), {})
                    .get("name", command_summary(cmd))
                    if cmd.get("type") == "CUSTOM"
                    else command_summary(display),
                ),
            )
        if selection is not None and 0 <= selection < len(self.commands):
            self.tree.selection_set(str(selection))
            self.tree.see(str(selection))
        if self.on_change:
            self.on_change()

    def names(self):
        return list(
            dict.fromkeys(
                list(self.local_names)
                + [
                    c["name"]
                    for c in walk_commands(self.commands)
                    if c.get("type", "").upper() == "SET"
                ]
            )
        )

    def add(self, kind="LINE"):
        before = copy.deepcopy(self.blocks)
        before_commands = copy.deepcopy(self.commands)
        selected = self.indices()
        insert_at = selected[-1] + 1 if selected else len(self.commands)
        d = edit_command(
            self.frame,
            {"type": kind},
            self.blocks,
            self.project,
            self.names(),
            sample_locals=self.local_names
            if isinstance(self.local_names, dict)
            else None,
            folder_id=self.folder_id,
            point_sources=self.commands[:insert_at],
        )
        if d is not None:
            changed = copy.deepcopy(self.blocks)
            replace_collection(self.blocks, before)
            changed_commands = copy.deepcopy(self.commands)
            self.commands[:] = before_commands
            self.snapshot()
            self.commands[:] = changed_commands
            replace_collection(self.blocks, changed)
            ids = self.indices()
            at = ids[-1] + 1 if ids else len(self.commands)
            self.commands.insert(at, d)
            self.refresh(at)

    def edit(self):
        ids = self.indices()
        if len(ids) != 1:
            return messagebox.showinfo(
                "コマンドの選択",
                "編集するコマンドを1件選択してください",
                parent=self.frame,
            )
        before = copy.deepcopy(self.blocks)
        i = ids[0]
        before_commands = copy.deepcopy(self.commands)
        d = edit_command(
            self.frame,
            self.commands[i],
            self.blocks,
            self.project,
            self.names(),
            sample_locals=self.local_names
            if isinstance(self.local_names, dict)
            else None,
            folder_id=self.folder_id,
            point_sources=self.commands[:i],
        )
        if d is not None:
            changed = copy.deepcopy(self.blocks)
            replace_collection(self.blocks, before)
            changed_commands = copy.deepcopy(self.commands)
            self.commands[:] = before_commands
            self.snapshot()
            self.commands[:] = changed_commands
            replace_collection(self.blocks, changed)
            self.commands[i] = d
            self.refresh(i)

    def duplicate(self):
        ids = self.indices()
        if not ids:
            return
        self.snapshot()
        for i in reversed(ids):
            self.commands.insert(i + 1, clone_commands([self.commands[i]])[0])
        self.refresh(ids[0] + 1)

    def delete(self):
        ids = self.indices()
        if not ids:
            return
        self.snapshot()
        for i in reversed(ids):
            self.commands.pop(i)
        self.refresh(min(ids[0], len(self.commands) - 1))

    def move(self, delta):
        ids = self.indices()
        if len(ids) == 1 and 0 <= ids[0] + delta < len(self.commands):
            i = ids[0]
            j = i + delta
            self.snapshot()
            self.commands[i], self.commands[j] = self.commands[j], self.commands[i]
            self.refresh(j)



class MacroEditor:
    def __init__(
        self, parent, preset, blocks, on_close, project=None, selected_rows=None
    ):
        self.unified = isinstance(blocks, list)
        self.win = tk.Toplevel(parent)
        self.win.title(
            ("ブロック編集 · " if self.unified else "プリセット編集 · ")
            + preset.get("name", "")
        )
        fit_window(self.win, 1320, 860, 850, 640)
        self.win.transient(parent)
        self.win.grab_set()
        self.preset = preset
        self.blocks = blocks
        self.working_blocks = copy.deepcopy(blocks)
        self.on_close = on_close
        self.project = project
        self._preview_job = None
        self.win.bind("<Destroy>", self.cancel_preview_job, add="+")
        self.selected_rows = list(selected_rows) if selected_rows is not None else (
            [0] if project and get_rows(project) else []
        )
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        self.win.bind("<Escape>", lambda e: self.cancel())
        self.command_panes = ttk.Panedwindow(self.win, orient="horizontal")
        self.command_panes.pack(fill="both", expand=True, padx=12, pady=(12, 8))
        self._split_initialized = False
        self.command_panes.bind("<Configure>", self.fit_command_panes)
        command_page = ttk.Frame(self.command_panes)
        self.command_panes.add(command_page, weight=1)
        meta = ttk.Frame(command_page, padding=(10, 0, 10, 8))
        meta.pack(fill="x")
        self.name = tk.StringVar(value=preset.get("name", ""))
        self.cond = tk.StringVar(value=preset.get("condition", ""))
        if not self.unified:
            self.enabled = tk.BooleanVar(value=preset.get("enabled", True))
        name_row = ttk.Frame(meta)
        name_row.pack(fill="x", pady=(2, 7))
        ttk.Label(name_row, text="名前", width=6).pack(side="left")
        ttk.Entry(name_row, textvariable=self.name).pack(side="left", fill="x", expand=True)
        if not self.unified:
            ttk.Checkbutton(meta, text="このプリセットを有効にする", variable=self.enabled).pack(anchor="w")
        self.conditions_panel = ttk.Frame(command_page, padding=(10, 8))
        self.conditions_panel.pack(side="bottom", fill="x")
        conditions = ttk.Frame(self.conditions_panel)
        condition_row = ttk.Frame(conditions)
        condition_row.pack(fill="x", pady=(3, 0))
        ttk.Label(condition_row, text="条件", width=6).pack(side="left")
        ttk.Entry(condition_row, textvariable=self.cond).pack(
            side="left", fill="x", expand=True
        )
        ttk.Button(
            condition_row,
            text="条件を作る…",
            command=lambda: show_condition_builder(
                self.win, self.cond, self.project or {}, preset.get("variables", {})
            ),
        ).pack(side="left", padx=(6, 0))
        condition_hint = ttk.Label(
            conditions,
            text='例: @TYPE == "A"。空欄なら作図対象の行に適用。',
            style="Muted.TLabel", wraplength=350,
        )
        condition_hint.pack(anchor="w", pady=(4, 0))
        conditions.bind("<Configure>", lambda e: condition_hint.configure(wraplength=max(160, e.width)))
        condition_open = [bool(self.cond.get().strip())]

        def toggle_conditions():
            condition_open[0] = not condition_open[0]
            if condition_open[0]:
                conditions.pack(fill="x", pady=(6, 0))
            else:
                conditions.pack_forget()
            condition_button.configure(
                text="▾ 条件" if condition_open[0] else
                ("▸ 条件あり" if self.cond.get().strip() else "▸ 条件を追加")
            )

        self.conditions_actions = ttk.Frame(self.conditions_panel)
        self.conditions_actions.pack(fill="x", pady=(8, 0))
        self.condition_button = condition_button = ttk.Button(self.conditions_actions, command=toggle_conditions, style="Compact.TButton")
        condition_button.pack(side="left", fill="x", expand=True)
        self.preview_through = tk.BooleanVar(
            value=getattr(self.win._root(), "_command_preview_through", False)
        )
        self.preview_through_button = ttk.Checkbutton(
            self.conditions_actions,
            text="選択したコマンドまで表示",
            variable=self.preview_through,
            command=self.change_preview_mode,
        )
        self.preview_through_button.pack(side="right", padx=(8, 0))
        if condition_open[0]:
            conditions.pack(fill="x", pady=(6, 0))
        condition_button.configure(
            text="▾ 条件" if condition_open[0] else "▸ 条件を追加"
        )
        self.cond.trace_add(
            "write",
            lambda *_: condition_button.configure(
                text="▾ 条件" if condition_open[0] else
                ("▸ 条件あり" if self.cond.get().strip() else
                 "▸ 条件を追加")
            ),
        )
        bar = ttk.Frame(self.win, padding=12)
        bar.pack(side="bottom", fill="x", before=self.command_panes)
        ttk.Button(bar, text="キャンセル", command=self.cancel).pack(side="left")
        ttk.Button(
            bar,
            text="ブロックを確定" if self.unified else "プリセットを確定",
            style="Primary.TButton",
            command=self.save,
        ).pack(side="right")
        self.preview_frame = preview_frame = ttk.Frame(self.command_panes)
        self.command_panes.add(preview_frame, weight=1)
        self.preview_label = ttk.Label(
            preview_frame, text="選択したコマンドのプレビュー",
            style="Muted.TLabel", padding=(8, 4), wraplength=400,
        )
        self.preview_label.pack(side="bottom", fill="x")
        self.preview_canvas = DrawingCanvas(preview_frame, width=320, height=320)
        self.preview_canvas.pack(fill="both", expand=True, padx=(8, 0))
        self.preview_tools = ttk.Frame(self.preview_canvas, padding=4, style="Preview.TFrame")
        self.preview_tools.place(relx=1, rely=1, x=-12, y=-10, anchor="se")
        self.preview_canvas.set_overlay_controls(self.preview_tools)
        self.actual_color_toggle = self.preview_canvas.make_color_toggle(self.preview_tools)
        self.actual_color_toggle.pack(side="left", padx=3)
        preview_frame.bind(
            "<Configure>",
            lambda event: self.preview_label.configure(wraplength=max(120, event.width - 16)),
        )
        self.list = CommandList(
            command_page,
            copy.deepcopy(preset.get("commands", [])),
            self.working_blocks,
            self.show_preview,
            self.queue_preview,
            project,
            dict(preset.get("variables", {})),
            folder_id=preset.get("folder_id", ""),
        )
        self.list.tree.tag_configure("previewed", background="#edf3ff")
        for var in (self.name, self.cond, *((self.enabled,) if not self.unified else ())):
            var.trace_add("write", lambda *_: self.queue_preview())
        self.queue_preview()

    def fit_command_panes(self, event):
        if event.width < 650:
            return
        position = self.command_panes.sashpos(0) if self._split_initialized else int(event.width * 0.52)
        self.command_panes.sashpos(0, max(320, min(position, event.width - 320)))
        self._split_initialized = True

    def change_preview_mode(self):
        self.win._root()._command_preview_through = self.preview_through.get()
        self.show_preview(self.list.indices())

    def queue_preview(self):
        if hasattr(self, "preview_canvas") and self._preview_job is None and self.win.winfo_exists():
            self._preview_job = self.win.after_idle(self.run_queued_preview)

    def run_queued_preview(self):
        self._preview_job = None
        if self.win.winfo_exists():
            self.show_preview(self.list.indices())

    def cancel_preview_job(self, event):
        if event.widget is self.win and self._preview_job is not None:
            self.win.after_cancel(self._preview_job)
            self._preview_job = None

    def current(self):
        result = dict(
            self.preset,
            name=self.name.get().strip(),
            condition=self.cond.get().strip(),
            commands=copy.deepcopy(self.list.commands),
        )

        if self.unified:
            result.pop("enabled", None)
            result.pop("draw", None)
        else:
            result["enabled"] = self.enabled.get()
        return result

    def trial(self):
        trial = copy.deepcopy(self.project)
        if self.unified:
            trial["blocks"] = copy.deepcopy(self.working_blocks)
            index = index_of(trial, self.preset["id"])
            trial["blocks"][index] = self.current()
        else:
            index = next(
                i for i, p in enumerate(self.project["presets"]) if p is self.preset
            )
            trial["presets"][index] = self.current()
            trial["blocks"] = copy.deepcopy(self.working_blocks)
        return trial, index

    def show_preview(self, indices):
        if not hasattr(self, "preview_canvas") or not self.win.winfo_exists():
            return
        self.preview_canvas.set_color_resources(self.project or {})
        self.preview_canvas.set_items([])
        through = self.preview_through.get()
        end = max(indices) if indices else None
        for node in self.list.tree.get_children():
            active = through and end is not None and int(node) <= end
            self.list.tree.item(node, tags=("previewed",) if active else ())
        if through and end is None:
            self.preview_canvas.set_items([], message="確認するコマンドを選択してください")
            self.preview_label.configure(text="先頭から選択したコマンドまでを表示")
            return
        if not self.project or not self.selected_rows:
            self.preview_label.configure(text="入力表の「作図」列にチェックしてください")
            return
        try:
            trial, pi = self.trial()
            preview_indices = list(range(end + 1)) if through else indices
            if through:
                # Later unfinished commands must not prevent checking this stage.
                collection = "blocks" if self.unified else "presets"
                trial[collection][pi]["commands"] = trial[collection][pi]["commands"][:end + 1]
            if self.unified:
                for i, block in enumerate(trial["blocks"]):
                    block["draw"] = i == pi
            events = []
            _, items = compile_project(
                trial, self.selected_rows[:1], diagnostics=events
            )
            events = [
                e
                for e in events
                if e.get("block_index" if self.unified else "preset_index") == pi
                and (not preview_indices or e.get("command_index") in preview_indices)
            ]
            items = [
                a
                for a in items
                if a["block_index" if self.unified else "preset_index"] == pi
                and (not preview_indices or a["command_index"] in preview_indices)
            ]
            custom_count = sum(e["type"] == "CUSTOM" for e in events)
            self.preview_canvas.set_items(
                items,
                message="登録コマンドの図形はプレビュー対象外です。生成SCRで確認してください。"
                if custom_count
                else None,
            )
            self.preview_label.configure(
                text=(f"ここまで {end + 1}/{len(self.list.commands)}コマンド · " if through else "編集中の値を反映 · ")
                + f"{self.selected_rows[0] + 1}行目 / 標準{len(items)}図形"
                + (f" / 登録{custom_count}件はSCRのみ" if custom_count else "")
            )
        except Exception as exc:
            self.preview_label.configure(text="プレビュー: " + str(exc)[:110])

    def cancel(self):
        if (
            self.current() != self.preset or self.working_blocks != self.blocks
        ) and not messagebox.askyesno(
            "変更の破棄",
            "ブロックの変更を破棄しますか？"
            if self.unified
            else "プリセットの変更を破棄しますか？",
            parent=self.win,
        ):
            return
        self.win.destroy()

    def save(self):
        current = self.current()
        if not current["name"]:
            return messagebox.showerror(
                "名前",
                "ブロック名を入力してください"
                if self.unified
                else "プリセット名を入力してください",
                parent=self.win,
            )
        if self.project:
            trial, _ = self.trial()
            errors = validate_sequential_project(trial) if self.unified else validate_project(trial)
            if errors:
                return messagebox.showerror(
                    "構成の確認", "\n".join(errors[:8]), parent=self.win
                )
        if self.unified:
            if self.project:
                replace_collection(self.blocks, trial["blocks"])
            else:
                index = next(
                    i
                    for i, block in enumerate(self.working_blocks)
                    if block["id"] == current["id"]
                )
                self.working_blocks[index] = current
                replace_collection(self.blocks, self.working_blocks)
        else:
            self.preset.clear()
            self.preset.update(current)
            replace_collection(self.blocks, self.working_blocks)
        self.win.destroy()
        self.on_close()

