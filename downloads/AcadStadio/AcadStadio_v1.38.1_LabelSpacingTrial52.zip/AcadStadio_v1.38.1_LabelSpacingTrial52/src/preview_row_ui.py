"""Choose a preview row without changing the rows exported to SCR."""
import tkinter as tk
from tkinter import ttk
import unicodedata

from project_data import parse_row_number, row_title


class PreviewRowControls(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.value = tk.StringVar(value="1")
        self._synced_value = "1"
        self.title = tk.StringVar()
        self.columnconfigure(3, weight=1)
        ttk.Label(self, text="確認行").grid(row=0, column=0, padx=(0, 6))
        self.spin = ttk.Spinbox(self, from_=1, to=1, width=4,
                                textvariable=self.value, command=self.apply)
        self.spin.grid(row=0, column=1, sticky="w")
        self.total = ttk.Label(self, style="Muted.TLabel")
        self.total.grid(row=0, column=2, padx=6)
        self.title_label = ttk.Label(self, textvariable=self.title, width=1)
        self.title_label.grid(row=0, column=3, sticky="ew")
        self.title_label.bind("<Enter>", lambda e: app.icons.schedule(
            self.title_label, getattr(self, "full_title", "プレビューで確認する行です")))
        self.title_label.bind("<Leave>", lambda e: app.icons.hide())
        self.spin.bind("<Return>", self.apply)
        self.spin.bind("<FocusOut>", self.apply)

    def apply(self, event=None):
        if self.app._syncing_options or not self.app.rows:
            return "break"
        if event is not None and event.type == tk.EventType.FocusOut and self.value.get() == self._synced_value:
            return "break"
        raw = unicodedata.normalize("NFKC", self.value.get())
        try:
            index = parse_row_number(raw, len(self.app.rows))
        except ValueError as exc:
            self.title.set("行番号を確認")
            self.full_title = str(exc)
            self.app.status.set(str(exc))
            return "break"
        self.app.table_editor.finish()
        self.app._preview_row_selection = (self.app.data["active_table"], [index])
        self.app._table_selections[self.app.data["active_table"]] = [index]
        self.app.table.selection_set(str(index))
        self.app.table.focus(str(index))
        self.app.table.see(str(index))
        self.value.set(str(index + 1))
        self.sync(force=True)
        self.app.queue_preview()
        return "break"

    def reset(self):
        self.app._preview_row_selection = None
        self.app._syncing_options = True
        try:
            self.app.table.selection_remove(self.app.table.selection())
            self.app._table_selections[self.app.data["active_table"]] = []
        finally:
            self.app._syncing_options = False
        self.sync(force=True)
        self.app.queue_preview()

    def sync(self, force=False):
        count = len(self.app.rows)
        self.spin.configure(to=max(1, count), state="normal" if count else "disabled")
        self.total.configure(text=f"/ {count}行")
        try:
            rows = self.app.preview_rows()
        except ValueError:
            rows = []
        if len(rows) == 1:
            full = row_title(self.app.data, rows[0])
            self.full_title = full
            display = " ".join(full.splitlines())
            self.title.set(display if len(display) <= 17 else display[:16] + "…")
        else:
            self.full_title = f"{len(rows)}行をプレビューに表示します。SCR対象は入力表の「作図」チェックで指定します。"
            self.title.set(f"{len(rows)}行を表示" if rows else "表示対象なし")
        if force or self.spin.focus_get() is not self.spin:
            self.value.set(str(rows[0] + 1) if len(rows) == 1 else "")
            self._synced_value = self.value.get()
