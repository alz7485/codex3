"""Secondary windows share compact controls without changing the main UI."""
import os
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from catalog_editor import CommandCatalogManager

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32', 'GUI display unavailable')
class SecondaryToneGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_list_actions_are_above_lists_and_same_size_as_main(self):
        main=gui.button(self.app.block_actions,'編集')
        preset=self.app.manage_settings_presets(); self.root.update()
        for label in ['現在値から新規作成','複製','名前変更','値を編集','削除']:
            b=gui.button(preset.win,label)
            self.assertLessEqual(abs(b.winfo_width()-main.winfo_width()), 4); self.assertLessEqual(abs(b.winfo_height()-main.winfo_height()), 4)
            self.assertLess(b.winfo_rooty()+b.winfo_height(),preset.list.winfo_rooty())
            self.assertTrue(b.tooltip_text)
        self.assertEqual(gui.button(preset.win,'選択を適用して保存').cget('style'),'Compact.Primary.TButton')
        preset.win.destroy()
        catalog=CommandCatalogManager(self.root,self.app.data,self.app.refresh);self.root.update()
        for label in ['新規登録','編集','複製','削除','JSON読込','JSON書出']:
            b=gui.button(catalog.win,label)
            self.assertLess(b.winfo_rooty()+b.winfo_height(),catalog.tree.winfo_rooty())
            self.assertLessEqual(abs(b.winfo_height()-main.winfo_height()), 4)
        catalog.win.destroy()

    def test_cad_actions_and_scr_controls_and_main_unchanged(self):
        styles=[b.cget('style') for b in self.app.settings_buttons]
        before=self.app.compile()[0]
        cad=self.app.edit_cad_setup();self.root.update()
        for tree,_ in cad.forms.values():
            page=tree.master.master
            page.master.select(page); self.root.update()
            add=gui.button(page,'入力値を追加')
            self.assertLess(add.winfo_rooty()+add.winfo_height(),tree.winfo_rooty())
        cad.win.destroy()
        scr=self.app.show_script();self.root.update()
        self.assertLess(gui.button(scr,'SCRをコピー').winfo_rooty(),self.app.script.winfo_rooty())
        self.assertGreater(gui.button(scr,'SCRを書き出す').winfo_rooty(),self.app.script.winfo_rooty())
        self.assertEqual(self.app.compile()[0],before)
        self.assertEqual([b.cget('style') for b in self.app.settings_buttons],styles)
