"""Adopted proposal: eye menu, flat sections, canvas HUD, and unchanged output."""
import copy
import os
from pathlib import Path
import sys
from tkinter import ttk
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui


@unittest.skipUnless(sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display unavailable")
class AdoptedDesignGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_eye_menu_has_icon_tooltip_and_changes_only_preview(self):
        button = self.app.block_browser.visibility_button
        self.assertTrue(button.cget("image"))
        self.assertEqual(str(button.cget("compound")), "none")
        self.assertEqual(button.cget("image"), (str(self.app.icons.get("eye")),))
        self.assertIn("表示", button.tooltip_text)
        before = copy.deepcopy(self.app.data); script = self.app.compile()[0]
        view = self.app.canvas.get_view(); scale = self.app.canvas.scale_value
        browser = self.app.block_browser
        browser.prepare_visibility_menu()
        browser.visibility_menu.invoke(1); self.root.update()
        self.assertFalse(self.app.canvas.items)
        self.assertIn("SCR対象", self.hud())
        browser.visibility_menu.invoke(0); self.root.update()
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app.compile()[0], script)
        self.assertEqual(self.app.canvas.get_view(), view)
        self.assertAlmostEqual(self.app.canvas.scale_value, scale)

    def hud(self):
        return " ".join(self.app.canvas.itemcget(n, "text") for n in self.app.canvas.find_withtag("workspace-info")
                        if self.app.canvas.type(n) == "text")

    def test_canvas_fills_panel_and_controls_are_inside_with_horizontal_legend(self):
        self.assertEqual(self.app.drawing_panes.sashpos(0), 370)
        self.assertEqual(str(self.app.settings_group.cget("style")), "MainCard.TFrame")
        self.assertEqual(str(self.app.block_panel.cget("style")), "MainCard.TFrame")
        self.assertGreater(self.app.canvas.winfo_width(), 900)
        self.assertIs(self.app.preview_controls.master, self.app.canvas)
        legend = self.app.canvas.find_withtag("legend")
        self.assertEqual(len(legend), 4)
        self.assertEqual(len({self.app.canvas.coords(n)[1] for n in legend}), 1)
        for size, sash in (("1320x840", 370), ("1040x680", 370), ("1040x680", 300)):
            self.root.geometry(size); self.root.update()
            self.app.drawing_panes.sashpos(0, sash); self.root.update()
            canvas = self.app.canvas; controls = self.app.preview_controls
            self.assertEqual(canvas.winfo_height(), self.app.preview_panel.winfo_height())
            self.assertLessEqual(controls.winfo_x()+controls.winfo_width(), canvas.winfo_width())
            self.assertLessEqual(controls.winfo_y()+controls.winfo_height(), canvas.winfo_height())
            for node in canvas.find_withtag("workspace-info"):
                self.assertLess(canvas.bbox(node)[2], controls.winfo_x())
            for node in self.app.block_list.get_children():
                box = self.app.block_list.bbox(node, "visible")
                self.assertTrue(box)
                self.assertLessEqual(box[0]+box[2], self.app.block_list.winfo_width())

    def test_confirmation_row_and_scr_target_are_distinct_and_failure_clears_old_hud(self):
        before = self.app.compile()[0]
        self.app.preview_row_controls.value.set("2"); self.app.preview_row_controls.apply()
        self.root.update(); self.app.preview(quiet=True)
        self.assertIn("FL-120", self.hud())
        self.assertIn("SCR対象: 1行", self.hud())
        self.assertEqual(self.app.target_rows(), [0])
        self.assertEqual(self.app.compile()[0], before)
        self.app.rows[1]["OD"] = "bad"; self.app.preview(quiet=True)
        self.assertIn("確認行の値", self.hud())
        self.assertNotIn("FL-120", self.hud())
        self.assertEqual(self.app.compile()[0], before)
        self.assertIn("エラー", self.app.preview_metrics.get())

    def test_search_placeholder_is_not_data_and_clear_is_only_visible_when_needed(self):
        browser = self.app.block_browser
        before = copy.deepcopy(self.app.data); script = self.app.compile()[0]
        self.assertEqual(browser.search.get(), "")
        self.assertFalse(browser.search_clear.winfo_ismapped())
        browser.search.set("断面"); self.root.update()
        self.assertTrue(browser.search_clear.winfo_ismapped())
        self.assertEqual(browser.selected_indices(), [])
        self.assertEqual(browser.tree.get_children(), ("1",))
        browser.search_clear.invoke(); self.root.update()
        self.assertEqual(browser.tree.get_children(), ("0", "1", "2"))
        self.assertFalse(browser.search_clear.winfo_ismapped())
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app.compile()[0], script)

    def test_sample_names_are_clean_but_user_names_are_preserved_and_header_undo_works(self):
        self.assertEqual(self.app.block_list.item("0", "values")[0], "平面図")
        self.app.data["blocks"][0]["name"] = "01 ユーザーの部品番号"
        self.app.refresh(); self.root.update()
        self.assertEqual(self.app.block_list.item("0", "values")[0], "01 ユーザーの部品番号")
        gui.button(self.root, "元に戻す").invoke(); self.root.update()
        self.assertEqual(self.app.data["blocks"][0]["name"], "平面図")
        gui.button(self.root, "やり直し").invoke(); self.root.update()
        self.assertEqual(self.app.data["blocks"][0]["name"], "01 ユーザーの部品番号")

    def test_foreign_preview_remains_unchanged_and_all_main_buttons_fit_at_minimum(self):
        from preview import DrawingCanvas
        other = DrawingCanvas(self.root, width=200, height=100)
        self.assertFalse(other.workspace)
        other.set_items(self.app.canvas.items[:1])
        self.assertFalse(other.find_withtag("workspace-info"))
        other.destroy()
        self.root.geometry("1040x680"); self.root.update()
        for widget in gui.descendants(self.root):
            if isinstance(widget, (ttk.Button, ttk.Checkbutton, ttk.Menubutton)) and widget.winfo_ismapped():
                if widget.winfo_toplevel() is not self.root:
                    continue
                self.assertLessEqual(widget.winfo_rootx()+widget.winfo_width(), self.root.winfo_rootx()+self.root.winfo_width())
                self.assertLessEqual(widget.winfo_rooty()+widget.winfo_height(), self.root.winfo_rooty()+self.root.winfo_height())
