# AcadStadio v1.19.4 — 継続開発の入口

この配布の最新実装は `src/`。CADScriptMaker v1.5を土台に完成させたPythonソース版です。
複数入力表と作図設定は `src/project_data.py`、モデル版は11です。
現在の機能・制限は `README.md`、`ARCHITECTURE_AND_KNOWN_LIMITATIONS.md` とソースを優先してください。
古いREADME・変更履歴は `docs/history/` に保管しています。

- `python tests/smoke_test.py`
- `python -m unittest discover -s tests -v`
- `python src/main.py`

GUIを含む実施結果は `docs/VALIDATION.md` を参照。Windows / AutoCAD実機の動作を検証済みと主張しないでください。
Windows用EXEは未ビルドです。任意の将来ビルド用にPyInstaller onedirのspecを付属します。

維持する仕様: プロジェクト → ブロック → コマンド、Excel / CSV、明示的な変数スコープ、
ASTによる式評価、循環ブロック禁止、保存前検査、履歴、未保存確認、原子的保存、世代バックアップ。
IFとREPEATはGUI・コンパイラ・構成ツリー・検査・プレビューで対応しています。

次の実作業はWindows 11 / Python 3.11のGUI確認と、対象バージョンのAutoCADでのSCR実行確認です。
利用するAutoCADの文字スタイルは固定高さ0を前提とします。図面テンプレートによる見た目の違いは残ります。

ユーザー登録コマンドは `src/command_catalog.py` / `src/catalog_editor.py`。初期15件は `assets/default_commands.json`。
標準は11タイプです。登録内容と呼出をプロジェクトJSONへ保存し、別プロジェクトにはライブラリJSONを取り込みます。
寸法スタイルは新規名用／既存名更新を分離。任意SCRの図形・外観はプレビューへ反映しないことをUI・資料で維持してください。

設定プリセットは `src/settings_presets.py` / `src/settings_preset_editor.py`。作図ブロックとは別の、サイズ等の値の保存です。
標準3件は保護、カスタムは最大100件。管理画面の操作は確定まで一時保持し、設定適用は登録キーのみを反映します。

システム設定の復元は `src/cad_state.py`。生成SCRにAutoLISPの退避と復元を付加します。
標準生成の設定・UCS・寸法スタイル選択、SYSVAR、登録の直接指定と追加system_variablesが対象。
中断時はCADFLOWRESTOREで手動復元。AutoCAD実機の検証は未実施です。

別窓のプロジェクト一覧は `src/project_library.py` / `src/project_sidebar.py`。個別プロジェクトはJSON、フォルダー・履歴はユーザー別library.jsonです。

メインUIはworkspace_tabsの作図（ブロック・プレビュー）/入力表。初回は作図、以後は作業状態を復元。表の選択・対象行・履歴は共有し、切替で変更しないこと。

一覧はApp.show_project_listで必要時に生成し、閉じるとwithdraw。非モーダルで重複生成せず、メイン画面は作図と入力表へ全幅を使います。

CAD初期設定はcad_setup.py/cad_setup_editor.py。モデル版10からの定義を維持し、任意の冒頭CADFLOWINIT、同名定義は維持。フローのレイヤー/線種/文字・寸法スタイルに候補を表示します。詳細はdocs/CAD_INITIALIZATION.md。

1.17のUI・退避・検査の移動は docs/USABILITY.md を参照。フローアドレス、入力表セル編集、数式試算、原子的作業退避、線画アイコンを追加しました。メインUIのプレビュー上部に独立見出しを戻さないこと。最新の検証件数・結果はdocs/VALIDATION.mdを参照してください。


1.18の統合構造は`src/block_model.py`と`docs/BLOCKS.md`を参照してください。
保存モデル版11は順序付き`blocks`配列だけを持ち、作図用の`presets`キーを保存しません。
各ブロックはid/name/draw/condition/variables/commandsを保持します。BLOCK.nameは表示名ではなく参照先IDです。
表示名の変更で参照を書き換えないこと。draw=Falseは呼び出し専用であり、明示的な呼び出しまで無効化しないこと。
既存の条件・変数・繰り返し・SETの互換性を維持します。旧形式の内部投影は互換境界だけで使い、JSONへ戻さないこと。
旧作図プリセットと共通ブロックの別管理画面・別階層を再導入しないこと。文字高さ等の設定プリセットは維持します。


1.19のフォルダ分類は `src/block_folders.py` と `src/block_browser.py`、操作は `docs/BLOCK_FOLDERS.md` を参照してください。
モデル版11の追加メタデータであり、`blocks` の実行順は維持します。フォルダ移動は分類のみ、削除は中のブロックを未分類へ戻す操作です。
一覧の見た目の並びと実行順を混同せず、常に「順」列とコンパイラの配列順を検証してください。
