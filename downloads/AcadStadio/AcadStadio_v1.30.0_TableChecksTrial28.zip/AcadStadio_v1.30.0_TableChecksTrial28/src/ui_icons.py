"""Bundled toolbar icons and tooltips for mouse and keyboard navigation."""

import tkinter as tk
from tkinter import ttk
from theme import ROOT


# Text stays on the widget for accessibility and automated UI navigation.
ICONS = {
    "線・形状を追加 ▾": ("blocks", True, "線・形状を追加: 線分 / ポリライン / 円 / 円弧 / 楕円 / 長方形 / 点"),
    "文字・寸法を追加 ▾": ("script", True, "文字・寸法を追加: 文字 / 長さ寸法 / 平行寸法 / 半径寸法 / 直径寸法"),
    "制御を追加 ▾": ("tree", True, "制御を追加: 条件分岐 / 繰り返し / システム変数 / 登録コマンド"),
    "＋ コマンドを追加 ▾": ("add", True, "作図コマンドを追加（線・円・文字・条件分岐など）"),
    "選択行…": ("table", False, "作図する行をチェックリストで選ぶ"),
    "SCRを表示": ("script", False, "生成SCRを別ウィンドウで表示"),
    "開く": ("folder", True, "プロジェクトを開く  Ctrl+O"),
    "保存": ("save", True, "保存  Ctrl+S"),
    "プロジェクトを検査": ("check", True, "全入力表と作図フローを検査"),
    "SCRを書き出す": ("export", False, "SCRを書き出す  Ctrl+E"),
    "プロジェクト一覧…": ("projects", False, "プロジェクト一覧を別ウィンドウで開く"),
    "CAD初期設定…": ("gear", False, "レイヤー・線種・文字/寸法スタイルの設定"),
    "入力表を編集…": ("table", False, "入力表を別ウィンドウで開く"),
    "表一覧…": ("table", False, "入力表の一覧と編集を別ウィンドウで開く"),
    "表示 ▾": ("eye", True, "プレビューの表示・非表示をまとめて変更"),
    "CAD設定": ("gear", False, "CADのレイヤー・線種・文字/寸法スタイルを設定"),
    "プリセット": ("save", False, "設定プリセットとサイズ設定"),
    "作図設定": ("check", False, "SCRへ出力する行を指定"),
    "表を追加": ("add", True, "入力表を追加"),
    "表を読込": ("folder", True, "Excel / CSVを新しい表として読み込む"),
    "表を置換": ("refresh", True, "現在の表をファイルで置き換える"),
    "式・変数 ▾": ("variables", True, "式・変数を入力"),
    "実色表示": ("colors", True, "実色表示 ON / OFF：登録レイヤーとコマンドのACI色（未定義の色は色分け表示）"),
    "CAD設定…": ("gear", False, "レイヤー・線種・文字/寸法スタイルの設定"),
    "作図対象を表示": ("refresh", True, "作図設定の対象行をプレビューに表示"),
    "ブロック追加": ("add", False, "選択フォルダにブロックを追加"),
    "フォルダ追加": ("folder_add", True, "最上位へフォルダを即時追加。名前は一覧上のダブルクリックで変更"),
    "登録コマンド": ("commands", True, "ユーザーコマンドを登録・編集"),
    "編集": ("edit", True, "選択項目を編集"),
    "名前を変更": ("edit", True, "選択した入力表の名前を変更  F2"),
    "↑": ("up", True, "上へ移動  Alt+↑"),
    "↓": ("down", True, "下へ移動  Alt+↓"),
    "削除": ("trash", True, "選択項目を削除"),
    "複製": ("duplicate", True, "選択項目を複製"),
    "設定・変数": ("variables", True, "設定・変数"),
    "変数": ("variables", True, "作図に使う変数を編集"),
    "構成ツリー": ("tree", True, "プロジェクト構成を別ウィンドウで開く"),
    "再生成  F5": ("refresh", True, "プレビューとSCRを再生成  F5"),
    "全体を表示": ("fit", True, "図形全体を表示（プレビューのダブルクリックでも可）"),
    "選択を強調": ("eye", True, "選択行・ブロックの強調 ON / OFF"),
    "SCRをコピー": ("copy", False, "生成SCRをクリップボードへコピー"),
    "行を追加": ("add", True, "入力表に行を追加"),
    "元に戻す": ("undo", True, "元に戻す  Ctrl+Z"),
    "やり直し": ("redo", True, "やり直す  Ctrl+Y"),
}


class IconTheme:
    def __init__(self, root):
        self.root = root
        root._acadstadio_icons = self
        self.images = {}
        self.tooltip = None
        self.job = None
        root.bind_all("<Map>", self.mapped, add="+")
        root.bind("<Destroy>", self.destroyed, add="+")

    def get(self, name, white=False):
        key = name + ("_white" if white else "")
        if key not in self.images:
            if name == "colors":
                icon = tk.PhotoImage(master=self.root, width=20, height=20)
                for color, x, y in (("#ff5252", 2, 2), ("#30dc80", 11, 2), ("#ffd54f", 2, 11), ("#5aa6ff", 11, 11)):
                    icon.put(color, to=(x, y, x+7, y+7))
                self.images[key] = icon
                return icon
            if name == "folder_add":
                icon = self.get("folder", white).copy()
                edge = icon.width()
                ink, paper = ("white", "#2463eb") if white else ("#2463eb", "white")
                icon.put(paper, to=(edge-10, edge-10, edge, edge))
                icon.put(ink, to=(edge-6, edge-9, edge-4, edge-1))
                icon.put(ink, to=(edge-9, edge-6, edge-1, edge-4))
                self.images[key] = icon
                return icon
            self.images[key] = tk.PhotoImage(
                master=self.root, file=str(ROOT / "assets" / "toolbar" / (key + ".png"))
            )
        return self.images[key]

    def mapped(self, event):
        widget = event.widget
        if not isinstance(widget, (ttk.Button, ttk.Checkbutton, ttk.Menubutton)) or getattr(
            widget, "_icon_ready", False
        ):
            return
        label = str(widget.cget("text"))
        spec = ICONS.get(label)
        if spec is None:
            for prefix, name in (
                ("＋ Excel", "folder"),
                ("設定プリセット", "save"),
                ("サイズ・共通設定", "gear"),
                ("作図設定…", "gear"),
                ("選択した参照", "add"),
            ):
                if label.startswith(prefix):
                    spec = name, False, label
                    break
        if spec is None:
            return
        name, icon_only, tip = spec
        icon_only = getattr(widget, "icon_only", icon_only)
        try:
            widget.configure(
                image=self.get(name, getattr(widget, "icon_white", "Primary" in widget.cget("style"))),
                compound="none" if icon_only else "left",
            )
        except tk.TclError:
            return
        if icon_only:
            if isinstance(widget, ttk.Checkbutton):
                widget.configure(style=getattr(widget, "icon_button_style", "Toggle.Toolbutton"))
            else:
                widget.configure(width=getattr(widget, "icon_button_width", 3),
                                 style=getattr(widget, "icon_button_style", "Compact.TButton"))
        widget._icon_ready = True
        widget.tooltip_text = tip
        widget.bind("<Enter>", lambda e: self.schedule(widget, tip), add="+")
        widget.bind("<FocusIn>", lambda e: self.schedule(widget, tip), add="+")
        for sequence in ("<Leave>", "<FocusOut>", "<ButtonPress>", "<Escape>"):
            widget.bind(sequence, lambda e: self.hide(), add="+")

    def schedule(self, widget, text):
        self.hide()
        self.job = self.root.after(450, lambda: self.show(widget, text))

    def show(self, widget, text):
        if self.job:
            self.root.after_cancel(self.job)
        self.job = None
        if not widget.winfo_exists() or not widget.winfo_ismapped():
            return
        win = self.tooltip = tk.Toplevel(self.root)
        win.overrideredirect(True)
        ttk.Label(
            win,
            text=text,
            padding=(9, 5),
            background="#233950",
            foreground="white",
            wraplength=350,
        ).pack()
        win.update_idletasks()
        x = min(
            widget.winfo_rootx(),
            self.root.winfo_screenwidth() - win.winfo_reqwidth() - 8,
        )
        y = widget.winfo_rooty() + widget.winfo_height() + 5
        if y + win.winfo_reqheight() > self.root.winfo_screenheight():
            y = widget.winfo_rooty() - win.winfo_reqheight() - 5
        win.geometry(f"+{max(0, x)}+{max(0, y)}")

    def hide(self):
        if self.job:
            self.root.after_cancel(self.job)
            self.job = None
        if self.tooltip is not None:
            try:
                self.tooltip.destroy()
            except tk.TclError:
                pass
            self.tooltip = None

    def destroyed(self, event):
        if event.widget is self.root:
            self.hide()


def icons_for(widget):
    root = widget._root()
    return getattr(root, "_acadstadio_icons", None) or IconTheme(root)


def layout_icon_toolbar(frame, width, *, grid=False):
    controls = [w for w in frame.winfo_children() if isinstance(w, (ttk.Button, ttk.Menubutton))]
    required = sum(45 if isinstance(w, ttk.Menubutton) else 28 for w in controls) + 2*len(controls)
    compact = width < max(330, required)
    for button in controls:
        suffix = "TMenubutton" if isinstance(button, ttk.Menubutton) else "TButton"
        style = ("DenseMainIcon." if compact else "MainIcon.") + suffix
        button.icon_button_style = style
        button.configure(style=style, width=2)
        if grid:
            button.grid_configure(padx=(0, 1 if compact else 2), pady=0)
        else:
            button.pack_configure(fill="y", padx=(0, 1 if compact else 2))
