"""Atomic project persistence, rotating backups, and JSON change details."""

import copy
import datetime
import json
import os
from pathlib import Path
import tempfile


def dump_project(data):
    return json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False)


def atomic_save(path, data, backup_count=5):
    """Save valid JSON atomically; keep prior on-disk versions as dated backups."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = dump_project(data)
    # Validate serialization before touching previous data.
    json.loads(payload)
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=target.parent,
            prefix="." + target.name + ".",
            suffix=".tmp",
            delete=False,
        ) as fp:
            temp_name = fp.name
            fp.write(payload)
            fp.flush()
            os.fsync(fp.fileno())
        if target.is_file():
            backup_dir = target.parent / (target.stem + "_backups")
            backup_dir.mkdir(exist_ok=True)
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            backup = backup_dir / (target.stem + "_" + stamp + target.suffix)
            # A failed backup must not replace the last known-good file.
            import shutil

            shutil.copy2(target, backup)
        os.replace(temp_name, target)
        temp_name = None
        if target.is_file() and backup_count > 0:
            folder = target.parent / (target.stem + "_backups")
            if folder.exists():
                backups = sorted(
                    folder.glob(target.stem + "_*" + target.suffix),
                    key=lambda p: p.name,
                    reverse=True,
                )
                for old in backups[backup_count:]:
                    try:
                        old.unlink()
                    except OSError:
                        pass  # The new file is committed; retention cleanup is best-effort.
        return target
    finally:
        if temp_name and os.path.exists(temp_name):
            os.unlink(temp_name)


def details(before, after, max_lines=400):
    """Structural differences using stable JSON key paths; no third-party deps."""
    changes = []

    def walk(a, b, path):
        if len(changes) >= max_lines:
            return
        if isinstance(a, dict) and isinstance(b, dict):
            for k in sorted(set(a) | set(b)):
                loc = f"{path}.{k}" if path else str(k)
                if k not in a:
                    changes.append(f"+ {loc} = {str(b[k])[:130]}")
                elif k not in b:
                    changes.append(f"- {loc} = {str(a[k])[:130]}")
                else:
                    walk(a[k], b[k], loc)
        elif isinstance(a, list) and isinstance(b, list):
            for i in range(max(len(a), len(b))):
                loc = f"{path}[{i + 1}]"
                if i >= len(a):
                    changes.append(f"+ {loc} = {str(b[i])[:130]}")
                elif i >= len(b):
                    changes.append(f"- {loc} = {str(a[i])[:130]}")
                else:
                    walk(a[i], b[i], loc)
                if len(changes) >= max_lines:
                    break
        elif a != b:
            changes.append(f"~ {path}: {str(a)[:85]} → {str(b)[:85]}")

    walk(copy.deepcopy(before), copy.deepcopy(after), "")
    if len(changes) >= max_lines:
        changes.append(f"...表示は{max_lines}件まで（変更多数）")
    return changes


def atomic_write_script(path, script, encoding="cp932"):
    """Encode before touching the target; a failed export preserves the old SCR."""
    payload = (
        script.replace("\r\n", "\n")
        .replace("\r", "\n")
        .replace("\n", "\r\n")
        .encode(encoding)
    )
    target = Path(path)
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(
            "wb",
            dir=target.parent,
            prefix="." + target.name + ".",
            suffix=".tmp",
            delete=False,
        ) as fp:
            temp_name = fp.name
            fp.write(payload)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(temp_name, target)
        temp_name = None
    finally:
        if temp_name and os.path.exists(temp_name):
            os.unlink(temp_name)
    return target
