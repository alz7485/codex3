"""Explorer WM_DROPFILES support; no extra Tk extension is required on Windows."""
import sys


def enable_file_drop(widget, on_files):
    if sys.platform != 'win32':
        return False
    import ctypes
    from ctypes import wintypes
    user = ctypes.WinDLL('user32', use_last_error=True)
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    get_parent = user.GetParent
    get_parent.argtypes = [wintypes.HWND]; get_parent.restype = wintypes.HWND
    widget.update_idletasks()
    handle = get_parent(widget.winfo_id()) or widget.winfo_id()
    proc_type = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT,
                                  ctypes.c_size_t, ctypes.c_ssize_t)
    set_proc = user.SetWindowLongPtrW if ctypes.sizeof(ctypes.c_void_p)==8 else user.SetWindowLongW
    set_proc.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
    set_proc.restype = ctypes.c_void_p
    user.CallWindowProcW.argtypes = [ctypes.c_void_p,wintypes.HWND,wintypes.UINT,ctypes.c_size_t,ctypes.c_ssize_t]
    user.CallWindowProcW.restype = ctypes.c_ssize_t
    shell.DragAcceptFiles.argtypes = [wintypes.HWND,wintypes.BOOL]
    shell.DragQueryFileW.argtypes = [wintypes.HANDLE,wintypes.UINT,wintypes.LPWSTR,wintypes.UINT]
    shell.DragQueryFileW.restype = wintypes.UINT
    shell.DragFinish.argtypes = [wintypes.HANDLE]
    old = [None]

    @proc_type
    def callback(hwnd, message, wparam, lparam):
        if message == 0x233:
            try:
                files=[]
                count=shell.DragQueryFileW(wparam,0xffffffff,None,0)
                for i in range(count):
                    length=shell.DragQueryFileW(wparam,i,None,0)
                    value=ctypes.create_unicode_buffer(length+1)
                    shell.DragQueryFileW(wparam,i,value,length+1)
                    files.append(value.value)
                widget.after_idle(lambda paths=files: on_files(paths) if widget.winfo_exists() else None)
            except Exception:
                # Never propagate Python exceptions through a native window procedure.
                pass
            finally:
                shell.DragFinish(wparam)
            return 0
        return user.CallWindowProcW(old[0],hwnd,message,wparam,lparam)

    old[0]=set_proc(handle,-4,ctypes.cast(callback,ctypes.c_void_p))
    if not old[0]:
        raise ctypes.WinError(ctypes.get_last_error())
    shell.DragAcceptFiles(handle,True)
    widget._file_drop_proc = callback

    def cleanup(event):
        if event.widget is widget:
            shell.DragAcceptFiles(handle,False)
            set_proc(handle,-4,old[0])
    widget.bind('<Destroy>',cleanup,add='+')
    return True
