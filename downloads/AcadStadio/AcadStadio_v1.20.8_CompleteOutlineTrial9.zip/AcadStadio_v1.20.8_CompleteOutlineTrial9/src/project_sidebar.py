from table_grid import GridTreeview
"""Project selection and JSON save controls for the project-list window."""

from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from project_library import canonical


class ProjectSidebar(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, width=220, padding=(0, 0, 8, 0))
        self.app = app
        self.query = tk.StringVar()
        self.folder_text = tk.StringVar()
        self.details = tk.StringVar()
        self.count = tk.StringVar()
        self._signature = None
        self._opening = False
        ttk.Label(self, text="プロジェクト", style="Section.TLabel").pack(
            anchor="w", pady=(0, 8)
        )
        tools = ttk.Frame(self)
        tools.pack(fill="x")
        for i, (text, action) in enumerate(
            (
                ("＋ 新規", app.new),
                ("保存", app.save),
                ("JSONを開く", app.load),
                ("別名で保存", app.save_as),
            )
        ):
            ttk.Button(tools, text=text, command=action).grid(
                row=i // 2, column=i % 2, sticky="ew", padx=(0, 4), pady=(0, 4)
            )
        tools.columnconfigure(0, weight=1)
        tools.columnconfigure(1, weight=1)
        ttk.Label(self, text="名前で絞り込み", style="Muted.TLabel").pack(
            anchor="w", pady=(6, 2)
        )
        self.search = ttk.Entry(self, textvariable=self.query)
        self.search.pack(fill="x")
        self.query.trace_add("write", lambda *_: self.refresh(force=True))
        frame = ttk.Frame(self)
        frame.pack(fill="both", expand=True, pady=(8, 0))
        self.tree = GridTreeview(frame, show="tree", selectmode="browse", height=8)
        self.tree.column("#0", width=185, minwidth=80)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(frame, command=self.tree.yview)
        ys.grid(row=0, column=1, sticky="ns")
        xs = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.tree.tag_configure("active", foreground="#2463eb")
        self.tree.tag_configure("external", foreground="#67788d")
        self.tree.bind("<ButtonRelease-1>", self.clicked)
        self.tree.bind("<Return>", lambda e: self.open_selected())
        self.tree.bind("<<TreeviewSelect>>", self.describe)
        footer = ttk.Frame(self)
        footer.pack(side="bottom", fill="x", before=frame)
        ttk.Label(footer, textvariable=self.count, style="Muted.TLabel").pack(
            anchor="w", pady=(4, 0)
        )
        self.detail_label = ttk.Label(
            footer, textvariable=self.details, wraplength=205, style="Muted.TLabel"
        )
        self.detail_label.pack(fill="x", pady=(4, 8))
        ttk.Label(footer, text="保存フォルダー", style="Section.TLabel").pack(
            anchor="w"
        )
        self.folder_label = ttk.Label(
            footer, textvariable=self.folder_text, wraplength=205, style="Muted.TLabel"
        )
        self.folder_label.pack(fill="x", pady=(4, 6))
        bottom = ttk.Frame(footer)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="フォルダー変更", command=self.choose_directory).pack(
            side="left"
        )
        ttk.Button(bottom, text="更新", command=lambda: self.refresh(force=True)).pack(
            side="right"
        )
        self._wrap_width = 205
        self.bind("<Configure>", self.resize_labels)
        self.refresh(force=True)

    def resize_labels(self, event):
        width = max(205, event.width - 12)
        if event.widget is self and width != self._wrap_width:
            self._wrap_width = width
            self.detail_label.configure(wraplength=width)
            self.folder_label.configure(wraplength=width)

    def refresh(self, force=False):
        library = self.app.project_library
        current = canonical(self.app.path) if self.app.path else None
        try:
            paths = library.files(current)
        except OSError as exc:
            self.app.status.set("プロジェクト一覧を読めません: " + str(exc))
            paths = list(
                dict.fromkeys([*library.recent, *([current] if current else [])])
            )
        query = self.query.get().strip().casefold()
        visible = [p for p in paths if query in Path(p).stem.casefold()]
        dirty = self.app.has_unsaved_changes()
        signature = (
            tuple(visible),
            current,
            dirty,
            self.app.document_name,
            str(library.directory),
        )
        if signature == self._signature and not force:
            return
        self._signature = signature
        old = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        if not current:
            self.tree.insert(
                "",
                "end",
                iid="unsaved",
                text=("● " if dirty else "") + self.app.document_name + "（未保存）",
                tags=("active",),
            )
        for path in visible:
            external = Path(path).parent != library.directory
            label = Path(path).stem + ("（外部）" if external else "")
            if path == current:
                label = ("● " if dirty else "▶ ") + label
            self.tree.insert(
                "",
                "end",
                iid=path,
                text=label,
                tags=("active",)
                if path == current
                else ("external",)
                if external
                else (),
            )
        preferred = current or "unsaved"
        if force and old and self.tree.exists(old[0]):
            preferred = old[0]
        if self.tree.exists(preferred):
            self.tree.selection_set(preferred)
            self.tree.see(preferred)
        folder = str(library.directory)
        self.folder_text.set(folder if len(folder) <= 100 else "…" + folder[-99:])
        self.count.set(
            f"{len(visible)}件のJSON"
            + ("（絞り込み中）" if query else "")
            + " · ● 未保存の変更"
        )
        self.describe()

    def describe(self, *_):
        selected = self.tree.selection()
        if not selected or selected[0] == "unsaved":
            self.details.set(
                "「保存」でJSONファイルを作成します。" if not self.app.path else ""
            )
        else:
            path = Path(selected[0])
            try:
                stamp = datetime.fromtimestamp(path.stat().st_mtime).strftime(
                    "%Y/%m/%d %H:%M"
                )
                text = "更新: " + stamp
                if path.parent != self.app.project_library.directory:
                    folder = str(path.parent)
                    text += "\n" + (folder if len(folder) <= 90 else "…" + folder[-89:])
                self.details.set(text)
            except OSError:
                self.details.set(
                    "ファイルが見つかりません。移動先のJSONを開いてください。"
                )

    def clicked(self, event):
        if self.tree.identify_row(event.y):
            self.open_selected()

    def open_selected(self):
        selected = self.tree.selection()
        if self._opening or not selected or selected[0] == "unsaved":
            return
        path = selected[0]
        if self.app.path and canonical(self.app.path) == path:
            return
        self._opening = True
        try:
            if not self.app.open_project(path):
                current = canonical(self.app.path) if self.app.path else "unsaved"
                if self.tree.exists(current):
                    self.tree.selection_set(current)
                self.describe()
        finally:
            self._opening = False

    def choose_directory(self):
        path = filedialog.askdirectory(
            parent=self.winfo_toplevel(),
            title="プロジェクトJSONの保存フォルダー",
            initialdir=str(self.app.project_library.directory),
        )
        if not path:
            return
        try:
            self.app.project_library.select_directory(path)
        except (OSError, ValueError) as exc:
            return messagebox.showerror(
                "保存フォルダーを変更できません", str(exc), parent=self.winfo_toplevel()
            )
        self.refresh(force=True)
        self.app.status.set("プロジェクトの保存フォルダーを変更しました。")
