"""Runtime AutoLISP snapshots around the generated SCR command stream.

Plain SCR cannot read initial system-variable values. All forms are single-line
and ASCII so that the same script can be written as CP932 or UTF-8.
"""

import re

# Also cover side effects of RECTANG/TEXT and of changing dimension styles.
BASE_VARIABLES = """CLAYER CECOLOR CELTYPE CELTSCALE CELWEIGHT CETRANSPARENCY
TEXTSTYLE TEXTSIZE TEXTJUST TEXTFILL ELEVATION THICKNESS
CHAMFERA CHAMFERB CHAMFERC CHAMFERD FILLETRAD PLINEWID
ORTHOMODE AUTOSNAP SNAPANG SNAPBASE SNAPUNIT OSNAPZ
LTSCALE PSLTSCALE MSLTSCALE LWDISPLAY CMDECHO FILEDIA CMDDIA
ATTREQ ATTDIA MIRRTEXT ANGBASE ANGDIR INSUNITS
DIMALT DIMALTD DIMALTF DIMALTRND DIMALTTD DIMALTTZ DIMALTU DIMALTZ
DIMAPOST DIMARCSYM DIMASZ DIMASSOC DIMATFIT DIMAUNIT DIMAZIN
DIMBLK DIMBLK1 DIMBLK2 DIMCEN DIMCLRD DIMCLRE DIMCLRT DIMDEC DIMDLE
DIMDLI DIMDSEP DIMEXE DIMEXO DIMFRAC DIMFXL DIMFXLON DIMGAP
DIMJOGANG DIMJUST DIMLDRBLK DIMLFAC DIMLIM DIMLTEX1 DIMLTEX2 DIMLTYPE
DIMLUNIT DIMLWD DIMLWE DIMPOST DIMRND DIMSAH DIMSCALE DIMSD1 DIMSD2
DIMSE1 DIMSE2 DIMSOXD DIMTAD DIMTDEC DIMTFAC DIMTFILL DIMTFILLCLR
DIMTIH DIMTIX DIMTM DIMTMOVE DIMTOFL DIMTOH DIMTOL DIMTOLJ DIMTP
DIMTSZ DIMTVP DIMTXSTY DIMTXT DIMTZIN DIMUPT DIMZIN DIMLAYER
DIMTXTDIRECTION DIMMZF DIMMZS DIMALTMZF DIMALTMZS
OSMODE SNAPMODE DYNMODE UCSFOLLOW""".split()
NAME = re.compile(r"[A-Za-z][A-Za-z0-9_]*\Z")


def snapshot_variables(lines, extra=()):
    names = set(BASE_VARIABLES)
    for i, line in enumerate(lines):
        token = line.strip().lstrip("_.").upper()
        if token == "SETVAR" and i + 1 < len(lines):
            variable = lines[i + 1].strip().upper()
            if NAME.fullmatch(variable):
                names.add(variable)
        elif NAME.fullmatch(token):
            # getvar returns nil for ordinary command names such as LINE.
            names.add(token)
        for variable in re.findall(r'\(setvar\s+"([A-Za-z][A-Za-z0-9_]*)"', line, re.I):
            names.add(variable.upper())
    names.update(name.upper() for name in extra if NAME.fullmatch(name))
    # UCS and DIMSTYLE need command-based restoration, not setvar.
    names.difference_update(
        (
            "UCS",
            "DIMSTYLE",
            "UCSORG",
            "UCSXDIR",
            "UCSYDIR",
            "UCSNAME",
            "DIMANNO",
            "AREA",
            "PERIMETER",
            "DATE",
            "CDATE",
            "LASTPOINT",
            "CMDACTIVE",
            "CMDNAMES",
        )
    )
    return sorted(names)


def protect_script(lines, extra=()):
    names = snapshot_variables(lines, extra)
    # The public recovery command remains available if SCRIPT is cancelled.
    restore = (
        "(defun c:CADFLOWRESTORE (/ s p r failed) "
        "(if (and (boundp '*cadflow-state*) *cadflow-state*) "
        "(progn (setq s *cadflow-state*) "
        '(vl-catch-all-apply \'setvar (list "UCSFOLLOW" 0)) '
        '(setq r (vl-catch-all-apply \'command-s (list "_.UCS" "_World"))) '
        "(if (vl-catch-all-error-p r) (setq failed T)) "
        '(if (/= (cdr (assoc \'ucsname s)) "") '
        '(setq r (vl-catch-all-apply \'command-s (list "_.UCS" "_Restore" (cdr (assoc \'ucsname s))))) '
        "(setq r (vl-catch-all-apply 'command-s "
        '(list "_.UCS" "_3point" "_non" (cdr (assoc \'origin s)) '
        "\"_non\" (mapcar '+ (cdr (assoc 'origin s)) (cdr (assoc 'xdir s))) "
        "\"_non\" (mapcar '+ (cdr (assoc 'origin s)) (cdr (assoc 'ydir s))))))) "
        "(if (vl-catch-all-error-p r) (setq failed T)) "
        '(if (/= (getvar "DIMSTYLE") (cdr (assoc \'dimstyle s))) (progn '
        "(setq r (vl-catch-all-apply 'command-s "
        '(list "_.-DIMSTYLE" "_Restore" (cdr (assoc \'dimstyle s))))) '
        "(if (vl-catch-all-error-p r) (setq failed T)))) "
        "(foreach p (cdr (assoc 'vars s)) "
        '(if (and (/= (car p) "UCSFOLLOW") (not (equal (getvar (car p)) (cdr p)))) '
        "(progn (setq r (vl-catch-all-apply 'setvar (list (car p) (cdr p)))) "
        "(if (vl-catch-all-error-p r) (setq failed T))))) "
        '(if (setq p (assoc "UCSFOLLOW" (cdr (assoc \'vars s)))) '
        "(progn (setq r (vl-catch-all-apply 'setvar (list (car p) (cdr p)))) "
        "(if (vl-catch-all-error-p r) (setq failed T)))) "
        '(if failed (princ "\\nAcadStadio: Some settings could not be restored; run CADFLOWRESTORE to retry.") '
        "(setq *cadflow-state* nil)))) (princ))"
    )
    snapshot = (
        "(if *cadflow-capture* (setq *cadflow-state* (list (cons 'vars nil) "
        '(cons \'ucsname (getvar "UCSNAME")) '
        '(cons \'origin (getvar "UCSORG")) '
        '(cons \'xdir (getvar "UCSXDIR")) '
        '(cons \'ydir (getvar "UCSYDIR")) '
        '(cons \'dimstyle (getvar "DIMSTYLE")))))'
    )
    captures = []
    for start in range(0, len(names), 20):
        quoted = " ".join('"' + name + '"' for name in names[start : start + 20])
        captures.append(
            "(if *cadflow-capture* (setq *cadflow-state* "
            "(subst (cons 'vars (append (cdr (assoc 'vars *cadflow-state*)) "
            "(vl-remove-if 'null (mapcar '(lambda (n / v) "
            "(setq v (getvar n)) (if v (cons n v))) '(" + quoted + "))))) "
            "(assoc 'vars *cadflow-state*) *cadflow-state*)))"
        )
    return [
        "; AcadStadio: AutoLISP required. Restore command: CADFLOWRESTORE.",
        restore,
        "(if (and (boundp '*cadflow-state*) *cadflow-state*) (c:CADFLOWRESTORE))",
        "(setq *cadflow-capture* (not (and (boundp '*cadflow-state*) *cadflow-state*)))",
        "(progn " + snapshot + " (princ))",
        *("(progn " + form + " (princ))" for form in captures),
        "(setq *cadflow-capture* nil)",
        '(setvar "UCSFOLLOW" 0)',
        *lines,
        "(c:CADFLOWRESTORE)",
        "",
    ]
