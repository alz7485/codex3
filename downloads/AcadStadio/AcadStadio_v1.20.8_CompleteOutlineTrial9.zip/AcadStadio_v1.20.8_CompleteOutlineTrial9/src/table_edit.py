"""Spreadsheet-style cell editing with one project undo per edit/paste."""

import csv
import io
import tkinter as tk
from tkinter import ttk, messagebox


class TableEditor:
    def __init__(self, app):
        self.app, self.tree = app, app.table
        self.cell = (0, 0)
        self.entry = None
        self.tree.bind("<Button-1>", self.locate, add="+")
        self.tree.bind("<Double-1>", self.begin)
        self.tree.bind("<F2>", self.begin)
        self.tree.bind("<Control-v>", self.paste)

    def keys(self):
        return list(self.tree["columns"])[1:]

    def locate(self, event):
        row = self.tree.identify_row(event.y)
        col = self.tree.identify_column(event.x)
        if row and col and int(col[1:]) >= 2:
            self.cell = (int(row), int(col[1:]) - 2)

    def begin(self, event=None, cell=None):
        if self.entry is not None:
            self.finish()
        if event is not None and event.type == tk.EventType.ButtonPress:
            if (
                not self.tree.identify_row(event.y)
                or self.tree.identify_column(event.x) == "#1"
            ):
                return "break"
            self.locate(event)
        elif cell is None:
            focus = self.tree.focus()
            if focus:
                self.cell = (int(focus), self.cell[1])
        row, col = cell or self.cell
        keys = self.keys()
        if not 0 <= row < len(self.app.rows) or not 0 <= col < len(keys):
            return "break"
        self.cell = row, col
        self.tree.see(str(row))
        # Reveal a horizontally scrolled cell before positioning its editor.
        columns = list(self.tree["columns"])
        left = sum(self.tree.column(k, "width") for k in columns[: col + 1])
        total = sum(self.tree.column(k, "width") for k in columns)
        visible = max(1, self.tree.winfo_width() - 6)
        start = self.tree.xview()[0] * total
        if (
            left < start
            or left + self.tree.column(keys[col], "width") > start + visible
        ):
            self.tree.xview_moveto(max(0, left - 42) / max(1, total))
        self.tree.update_idletasks()
        box = self.tree.bbox(str(row), keys[col])
        if not box:
            return "break"
        self.tree.selection_set(str(row))
        self.tree.focus(str(row))
        self.entry = ttk.Entry(self.tree)
        self.entry.insert(0, str(self.app.rows[row].get(keys[col], "")))
        self.entry.place(x=box[0], y=box[1], width=box[2], height=box[3])
        self.entry.select_range(0, "end")
        self.entry.focus_set()
        self.entry.bind("<Return>", lambda e: self.finish())
        self.entry.bind("<Escape>", lambda e: self.finish(False))
        self.entry.bind("<Tab>", lambda e: self.advance(1))
        self.entry.bind("<Shift-Tab>", lambda e: self.advance(-1))
        self.entry.bind("<ISO_Left_Tab>", lambda e: self.advance(-1))
        self.entry.bind("<FocusOut>", lambda e: self.finish())
        self.entry.bind("<Control-v>", self.paste_in_editor)
        return "break"

    def paste_in_editor(self, event=None):
        try:
            text = self.app.root.clipboard_get()
        except tk.TclError:
            return "break"
        if "\t" in text or "\n" in text or "\r" in text:
            self.finish(False)
            return self.paste(text=text)
        return None

    def finish(self, commit=True):
        entry, self.entry = self.entry, None
        if entry is None:
            return "break"
        value = entry.get()
        entry.destroy()
        row, col = self.cell
        keys = self.keys()
        if commit and row < len(self.app.rows) and col < len(keys):
            if len(value) > 10000:
                messagebox.showerror(
                    "セルの編集", "1セルは10000文字までです", parent=self.app.root
                )
                return "break"
            self.app.rows[row][keys[col]] = value
            self.app.refresh()
        self.tree.focus_set()
        return "break"

    def advance(self, delta):
        row, col = self.cell
        self.finish()
        width = len(self.keys())
        index = row * width + col + delta
        if 0 <= index < len(self.app.rows) * width:
            self.begin(cell=divmod(index, width))
        return "break"

    def paste(self, event=None, text=None):
        try:
            if text is None:
                text = self.app.root.clipboard_get()
            if len(text) > 20 * 1024 * 1024:
                raise ValueError("貼り付けデータは20MBまでです")
            cells = list(csv.reader(io.StringIO(text), delimiter="\t"))
            if not cells:
                return "break"
            row, col = self.cell
            if self.tree.focus():
                row = int(self.tree.focus())
            keys = self.keys()
            if not keys:
                raise ValueError("先に列のある入力表を読み込むか、行を追加してください")
            if any(len(line) + col > len(keys) for line in cells):
                raise ValueError(
                    "貼り付け先の列数を超えています。開始セルを選び直してください"
                )
            if row + len(cells) > 10000 or any(
                len(v) > 10000 for line in cells for v in line
            ):
                raise ValueError("入力上限（10000行・1セル10000文字）を超えています")
            # Validate the whole block before changing any value.
            for index in range(len(self.app.rows), row + len(cells)):
                self.app.rows.append({key: "" for key in keys})
            for offset, line in enumerate(cells):
                for c, value in enumerate(line, col):
                    self.app.rows[row + offset][keys[c]] = value
            self.app.refresh()
            self.tree.focus(str(row))
            self.app.status.set(
                f"{len(cells)}行を貼り付けました。Ctrl+Zで元に戻せます。"
            )
        except (ValueError, csv.Error, tk.TclError) as exc:
            messagebox.showerror("入力表への貼り付け", str(exc), parent=self.app.root)
        return "break"
