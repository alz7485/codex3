"""Read named drawing resources via an already-running Windows AutoCAD.

The DWG is opened read-only and closed without saving.  No project state is
changed until the user explicitly selects definitions and confirms the import.
AutoCAD ActiveX does not expose the originating LIN filename or the complete
dimension style data; neither limitation is silently filled with guesses.
"""

import copy
import math
import os
from pathlib import Path
import shutil
import tempfile

from cad_setup import cad_name, default_setup, validate_setup


SECTIONS = ("layers", "text_styles", "dim_styles", "linetypes")
TITLES = {
    "layers": "レイヤー",
    "text_styles": "文字スタイル",
    "dim_styles": "寸法スタイル",
    "linetypes": "線種",
}
LINEWEIGHTS = {-3, 0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53,
               60, 70, 80, 90, 100, 106, 120, 140, 158, 200, 211}
BUILTIN_LINETYPES = {"bylayer", "byblock", "continuous"}


class DWGImportError(ValueError):
    """A recoverable DWG inspection or candidate import problem."""


def _get(obj, attribute, default=None):
    try:
        return getattr(obj, attribute)
    except Exception:
        return default


def _number(value, default, *, positive=False, maximum=1e9):
    try:
        result = float(value)
        if not math.isfinite(result) or abs(result) > maximum or (positive and result <= 0):
            raise ValueError()
        return result
    except (TypeError, ValueError, OverflowError):
        return default


def _format(value):
    return f"{value:.12g}" if isinstance(value, (int, float)) else str(value)


def _candidate(name, values, note="", supported=True):
    return dict(name=name, values=values, note=note, supported=supported)


def extract_resources(document):
    """Read from an AutoCAD COM Document (also usable with fake COM objects)."""
    result = {section: [] for section in SECTIONS}
    issues = []

    def collect(section, collection, make):
        try:
            items = list(getattr(document, collection))
        except Exception as exc:
            issues.append(f"{TITLES[section]}を一覧取得できません: {exc}")
            return
        for item in items:
            name = str(_get(item, "Name", "") or "")
            if not cad_name(name):
                issues.append(f"{TITLES[section]}に使用できない名前があります: {name[:30]}")
                continue
            try:
                result[section].append(make(item, name))
            except Exception as exc:
                issues.append(f"{TITLES[section]}「{name}」の読込失敗: {exc}")

    def layer(item, name):
        notes = []
        color = int(_number(_get(item, "Color"), 7))
        if not 1 <= color <= 255:
            color = 7
            notes.append("色を正確に取得できずACI 7を仮設定")
        true_color = _get(item, "TrueColor")
        if true_color is not None and _get(true_color, "ColorMethod") == 194:
            notes.append("TrueColorは現在の設定形式にないため近似ACI色を使用")
        lineweight = int(_number(_get(item, "Lineweight"), -3))
        if lineweight not in LINEWEIGHTS:
            lineweight = -3
            notes.append("線幅を取得できず既定値を使用")
        values = dict(name=name, color=str(color),
                      linetype=str(_get(item, "Linetype", "Continuous") or "Continuous"),
                      lineweight=str(lineweight), plot=bool(_get(item, "Plottable", True)))
        return _candidate(name, values, " / ".join(notes))

    def text_style(item, name):
        notes = []
        font = str(_get(item, "FontFile", "") or "")
        if not font:
            notes.append("フォントファイル名を取得できません")
        width = _number(_get(item, "Width"), None, positive=True)
        angle = _number(_get(item, "ObliqueAngle"), None)
        if angle is not None:
            angle = math.degrees(angle)
        height = _number(_get(item, "Height"), 0)
        if height:
            notes.append("固定高さは再作成時に0になります")
        if width is None or angle is None or not -85 <= angle <= 85:
            notes.append("幅または傾斜角を正確に取得できません")
        values = dict(name=name, font=font, width=_format(width or 1),
                      oblique=_format(angle if angle is not None else 0))
        return _candidate(name, values, " / ".join(notes),
                          supported=bool(font) and width is not None and angle is not None
                          and -85 <= angle <= 85)

    def line_type(item, name):
        description = str(_get(item, "Description", "") or "").strip()
        values = dict(name=name, file="")
        note = "CAD側に存在する同名の線種を使用します。追加ファイルの読込は行いません。"
        if description:
            note += " / " + description[:70]
        return _candidate(name, values, note)

    collect("layers", "Layers", layer)
    collect("text_styles", "TextStyles", text_style)
    collect("linetypes", "Linetypes", line_type)
    result["linetypes"] = [r for r in result["linetypes"]
                           if r["name"].casefold() not in BUILTIN_LINETYPES]

    previous = _get(document, "ActiveDimStyle")
    try:
        styles = list(document.DimStyles)
    except Exception as exc:
        styles = []
        issues.append(f"寸法スタイルを一覧取得できません: {exc}")
    try:
        for item in styles:
            name = str(_get(item, "Name", "") or "")
            if not cad_name(name):
                continue
            try:
                # ActiveX stores DIMTXT/DIMASZ etc. as document system
                # variables, not as properties on the DimStyle object.
                # The read-only document is discarded after this inspection.
                document.ActiveDimStyle = item
                values = dict(
                    name=name, base="",
                    text_style=str(document.GetVariable("DIMTXSTY") or ""),
                    scale=_format(_number(document.GetVariable("DIMSCALE"), None, positive=True)),
                    text_height=_format(_number(document.GetVariable("DIMTXT"), None, positive=True)),
                    arrow_size=_format(_number(document.GetVariable("DIMASZ"), None, positive=True)),
                )
                if any(values[k] == "None" for k in ("scale", "text_height", "arrow_size")):
                    raise ValueError("寸法変数を取得できません")
                result["dim_styles"].append(_candidate(
                    name, values, "尺度・文字高さ・矢印・文字スタイルのみを取り込みます"
                ))
            except Exception as exc:
                result["dim_styles"].append(_candidate(
                    name, dict(name=name),
                    "寸法値の取得不可（チェック不可）: " + str(exc)[:90], False
                ))
    finally:
        if previous is not None:
            try:
                document.ActiveDimStyle = previous
            except Exception as exc:
                issues.append("元のアクティブ寸法スタイルの復帰に失敗: " + str(exc))
    return result, issues


def read_dwg_resources(path):
    """Read a DWG using the running AutoCAD ActiveX server, never saving it."""
    file = Path(path).expanduser().resolve()
    if not file.is_file() or file.suffix.lower() != ".dwg":
        raise DWGImportError("存在するDWGファイルを指定してください")
    if os.name != "nt":
        raise DWGImportError("DWG読込はAutoCADがインストールされたWindowsで利用できます")
    try:
        import pythoncom
        from win32com.client import GetActiveObject
    except ImportError as exc:
        raise DWGImportError("pywin32が必要です。pip install pywin32 を実行してください") from exc

    pythoncom.CoInitialize()
    temporary = None
    document = None
    previous = None
    result = None
    cleanup_issue = None
    try:
        try:
            acad = GetActiveObject("AutoCAD.Application")
        except Exception as exc:
            raise DWGImportError("AutoCADを起動してからDWG読込を実行してください") from exc
        previous = _get(acad, "ActiveDocument")
        opened = []
        try:
            opened = [os.path.normcase(os.path.abspath(str(d.FullName)))
                      for d in acad.Documents]
        except Exception as exc:
            raise DWGImportError(
                "AutoCADで開いている図面を確認できません。誤って編集中の図面を閉じないため読込を中止しました"
            ) from exc
        target = str(file)
        # Opening the same document would risk closing a drawing the user is
        # editing.  Use an isolated on-disk copy in that case.
        if os.path.normcase(target) in opened:
            temporary = tempfile.TemporaryDirectory(prefix="AcadStadio_DWG_")
            target = str(Path(temporary.name) / file.name)
            shutil.copy2(file, target)
        try:
            document = acad.Documents.Open(target, True)
        except Exception as exc:
            raise DWGImportError("DWGを読み取り専用で開けません。AutoCADの状態を確認してください: "
                                 + str(exc)) from exc
        result = extract_resources(document)
    finally:
        if document is not None:
            try:
                document.Close(False)
            except Exception as exc:
                cleanup_issue = "DWGを自動で閉じられませんでした。AutoCADで保存せず閉じてください: " + str(exc)
        if previous is not None:
            try:
                previous.Activate()
            except Exception:
                pass
        if temporary is not None:
            try:
                temporary.cleanup()
            except OSError as exc:
                cleanup_issue = (cleanup_issue or "一時DWGを削除できませんでした") + ": " + str(exc)
        pythoncom.CoUninitialize()
    if cleanup_issue:
        raise DWGImportError(cleanup_issue)
    return result


def merge_selected_definitions(setup, candidates, selected, *, linetype_file="", overwrite=False):
    """Merge checked definitions transactionally and validate before applying."""
    result = copy.deepcopy(setup if setup is not None else default_setup())
    for section in SECTIONS:
        result.setdefault(section, [])
        chosen = {str(name).casefold() for name in selected.get(section, ())}
        for candidate in candidates.get(section, ()):
            if candidate["name"].casefold() not in chosen:
                continue
            if not candidate.get("supported", True):
                raise DWGImportError(f"{TITLES[section]}「{candidate['name']}」は設定値を取得できません")
            row = copy.deepcopy(candidate["values"])
            if section == "linetypes":
                if linetype_file.strip():
                    row["file"] = linetype_file.strip()
                else:
                    row["file"] = ""
                    row["existing_only"] = True
            exists = next((i for i, old in enumerate(result[section])
                           if old["name"].casefold() == candidate["name"].casefold()), None)
            if exists is not None:
                if overwrite:
                    result[section][exists] = row
            else:
                result[section].append(row)
    errors = validate_setup(result)
    if errors:
        raise DWGImportError("登録内容を確認してください:\n" + "\n".join(errors[:10]))
    return result
