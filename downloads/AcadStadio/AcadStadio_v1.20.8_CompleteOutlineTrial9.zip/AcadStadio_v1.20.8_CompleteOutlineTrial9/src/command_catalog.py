"""JSON command templates. No template code is executed by Python."""

import copy
import hashlib
import json
import re
import string
import sys
import uuid
from pathlib import Path

ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
FORMAT = "cadflow-command-library"
MAX_COMMANDS = 200
MAX_LINES = 200
MAX_PARAMETERS = 30


def parameter_name(value):
    return (
        isinstance(value, str)
        and bool(re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", value))
        and not value.startswith("__")
    )


def validate_catalog(catalog):
    if not isinstance(catalog, dict) or len(catalog) > MAX_COMMANDS:
        return ["登録コマンドは辞書形式で200個までです"]
    errors = []
    names = set()
    for key, item in catalog.items():
        if not parameter_name(key):
            errors.append("登録コマンドIDが不正です")
            continue
        if not isinstance(item, dict):
            errors.append(key + ": コマンド定義が不正です")
            continue
        name = item.get("name")
        path = name if isinstance(name, str) else key
        if not isinstance(name, str) or not name.strip() or len(name) > 80:
            errors.append(key + ": 名前は1〜80文字です")
        elif name.casefold() in names:
            errors.append("登録コマンド名が重複しています: " + name)
        else:
            names.add(name.casefold())
        if (
            not isinstance(item.get("description", ""), str)
            or len(item.get("description", "")) > 1000
        ):
            errors.append(path + ": 説明は1000文字までです")
        if item.get("execution", "per_row") not in ("once", "per_row"):
            errors.append(path + ": 実行回数の指定が不正です")
        variables = item.get("system_variables", [])
        if (
            not isinstance(variables, list)
            or len(variables) > 30
            or any(
                not isinstance(v, str)
                or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", v)
                for v in variables
            )
        ):
            errors.append(
                path + ": 復元するシステム変数は有効な名前を30個まで指定してください"
            )
        params = item.get("parameters", [])
        if not isinstance(params, list) or len(params) > MAX_PARAMETERS:
            errors.append(path + ": 引数は30個までです")
            continue
        keys = set()
        for param in params:
            if not isinstance(param, dict):
                errors.append(path + ": 引数定義が不正です")
                continue
            pname = param.get("name")
            if not parameter_name(pname) or pname in keys:
                errors.append(path + ": 引数名が不正または重複しています")
                continue
            keys.add(pname)
            if param.get("kind") not in ("number", "text"):
                errors.append(path + ": 引数の種類はnumber / textです")
            if not isinstance(param.get("label", pname), str):
                errors.append(path + ": 引数の表示名は文字列です")
            default = param.get("default", "0" if param.get("kind") == "number" else "")
            if type(default) not in (str, int, float) or len(str(default)) > 2048:
                errors.append(path + ": 引数の既定値が不正です")
        lines = item.get("lines")
        if not isinstance(lines, list) or not 1 <= len(lines) <= MAX_LINES:
            errors.append(path + ": SCR手順は1〜200行です")
            continue
        if all(isinstance(line, str) and not line for line in lines):
            errors.append(path + ": SCR手順が空欄です")
        for i, line in enumerate(lines):
            if (
                not isinstance(line, str)
                or len(line) > 2048
                or any(ord(c) < 32 or ord(c) == 127 for c in line)
            ):
                errors.append(
                    f"{path} / {i + 1}行目: 改行・制御文字は行の中に入れられません"
                )
                continue
            try:
                for _, field, spec, conversion in string.Formatter().parse(line):
                    if field is not None and (field not in keys or spec or conversion):
                        errors.append(
                            f"{path} / {i + 1}行目: {{引数名}}のみ指定できます: {field}"
                        )
            except ValueError:
                errors.append(f"{path} / {i + 1}行目: 波括弧の対応が不正です")
    return list(dict.fromkeys(errors))[:100]


def load_default_catalog():
    raw = json.loads(
        (ROOT / "assets" / "default_commands.json").read_text(encoding="utf-8")
    )
    catalog = raw["commands"]
    errors = validate_catalog(catalog)
    if errors:
        raise ValueError("\n".join(errors))
    return copy.deepcopy(catalog)


def library_document(catalog):
    errors = validate_catalog(catalog)
    if errors:
        raise ValueError("\n".join(errors[:12]))
    return {"format": FORMAT, "version": 1, "commands": copy.deepcopy(catalog)}


def read_library(path):
    path = Path(path)
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("登録コマンドJSONは2MBまでです")
    doc = json.loads(path.read_text(encoding="utf-8-sig"))
    if (
        not isinstance(doc, dict)
        or doc.get("format") != FORMAT
        or doc.get("version") != 1
    ):
        raise ValueError("AcadStadioの登録コマンドJSONを選択してください")
    catalog = doc.get("commands")
    errors = validate_catalog(catalog)
    if errors:
        raise ValueError("\n".join(errors[:12]))
    return catalog


def merge_library(target, incoming):
    """Import without overwriting used IDs. Return a new independent registry."""
    errors = validate_catalog(incoming)
    if errors:
        raise ValueError("\n".join(errors[:12]))
    result = copy.deepcopy(target)
    for key, item in incoming.items():
        if key in result and result[key] == item:
            continue
        payload = copy.deepcopy(item)
        payload.pop("import_origin", None)
        fingerprint = hashlib.sha256(
            json.dumps(
                payload, ensure_ascii=False, sort_keys=True, allow_nan=False
            ).encode("utf-8")
        ).hexdigest()
        already_imported = False
        for existing in result.values():
            origin = existing.get("import_origin", {})
            candidate = copy.deepcopy(existing)
            candidate.pop("import_origin", None)
            candidate["name"] = item["name"]
            if (
                isinstance(origin, dict)
                and origin.get("id") == key
                and origin.get("fingerprint") == fingerprint
                and candidate == payload
            ):
                already_imported = True
                break
        if already_imported:
            continue
        definition = copy.deepcopy(item)
        names = {d["name"].casefold() for d in result.values()}
        base = definition["name"]
        i = 2
        while definition["name"].casefold() in names:
            suffix = f" ({i})"
            definition["name"] = base[: 80 - len(suffix)] + suffix
            i += 1
        if key in result:
            definition["import_origin"] = {"id": key, "fingerprint": fingerprint}
            key = "cmd_" + uuid.uuid4().hex
        result[key] = definition
    errors = validate_catalog(result)
    if errors:
        raise ValueError("\n".join(errors[:12]))
    return result
