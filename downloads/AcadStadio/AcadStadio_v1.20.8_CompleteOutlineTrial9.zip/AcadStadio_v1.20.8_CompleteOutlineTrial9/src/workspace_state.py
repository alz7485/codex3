"""Atomic local workspace and crash recovery storage, separate from projects."""

import json
import os
from pathlib import Path
import tempfile


class WorkspaceState:
    def __init__(self, directory):
        self.directory = Path(directory) / "Workspace"

    def path(self, name):
        return self.directory / (name + ".json")

    def read(self, name, limit=22 * 1024 * 1024):
        path = self.path(name)
        try:
            if path.stat().st_size > limit:
                return None
            value = json.loads(path.read_text(encoding="utf-8"))
            return (
                value if isinstance(value, dict) and value.get("version") == 1 else None
            )
        except (OSError, ValueError, RecursionError):
            return None

    def write(self, name, value):
        self.directory.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(
            dict(value, version=1), ensure_ascii=False, allow_nan=False
        )
        if len(payload.encode("utf-8")) > 128 * 1024 * 1024:
            raise ValueError(
                "復元データは合計128MBまでです。不要な復元データを破棄してください"
            )
        fd, temporary = tempfile.mkstemp(
            prefix=name + ".", suffix=".tmp", dir=self.directory
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                stream.write(payload + "\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path(name))
        finally:
            Path(temporary).unlink(missing_ok=True)

    def clear(self, name):
        self.path(name).unlink(missing_ok=True)

    def recoveries(self):
        value = self.read("recovery", 128 * 1024 * 1024) or {}
        if isinstance(value.get("data"), dict):
            return [dict(value, id="legacy")]
        if not isinstance(value.get("drafts", []), list):
            return []
        return [
            d
            for d in value.get("drafts", [])
            if isinstance(d, dict)
            and isinstance(d.get("data"), dict)
            and isinstance(d.get("id"), str)
        ]

    def save_recovery(self, identity, draft):
        drafts = [d for d in self.recoveries() if d["id"] != identity]
        drafts.append(dict(draft, id=identity))
        self.write("recovery", {"drafts": drafts})

    def remove_recovery(self, identity):
        drafts = [d for d in self.recoveries() if d["id"] != identity]
        if drafts:
            self.write("recovery", {"drafts": drafts})
        else:
            self.clear("recovery")
