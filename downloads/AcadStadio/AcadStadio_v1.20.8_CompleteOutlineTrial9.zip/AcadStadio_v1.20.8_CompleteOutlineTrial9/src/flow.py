"""Addresses shared by the flow view, compiler diagnostics and inspection links."""

import re
from block_model import unified, index_of


def resolve(project, address):
    value = project
    for key in address:
        value = value[key]
    return value


def walk(commands, address):
    for i, command in enumerate(commands):
        at = (*address, i)
        yield at, command
        for key in ("commands", "else"):
            if key in command:
                yield from walk(command[key], (*at, key))


def execution_address(project, preset_index, path):
    """Resolve expanded paths, including block calls and repeat iterations."""
    return execution_trace(project, preset_index, path)[-1]


def execution_trace(project, preset_index, path):
    modern = unified(project)
    address = ("blocks" if modern else "presets", preset_index, "commands")
    parts = path.split("/")
    address += (int(parts[0]) - 1,)
    addresses = [address]
    for label, index in zip(parts[1::2], parts[2::2]):
        if label.startswith("BLOCK:") and (modern or "_block_definitions" in project):
            address = (
                ("blocks", index_of(project, label[6:]), "commands", int(index) - 1)
                if modern
                else ("blocks", label[6:], int(index) - 1)
            )
        elif label in ("IF", "ELSE") or re.fullmatch(r"REPEAT\[\d+\]", label):
            address += ("else" if label == "ELSE" else "commands", int(index) - 1)
        else:
            address = (
                ("blocks", index_of(project, label), "commands", int(index) - 1)
                if modern
                else ("blocks", label, int(index) - 1)
            )
        addresses.append(address)
    resolve(project, address)
    return addresses
