from table_grid import GridTreeview
"""Transactional user command registration, JSON sharing, and template forms."""

import copy
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import uuid
from command_catalog import (
    validate_catalog,
    library_document,
    read_library,
    merge_library,
)
from project_safety import atomic_save
from project_model import validate_project, walk_commands
from theme import fit_window


def edit_definition(parent, current):
    current = copy.deepcopy(current)
    current.setdefault("execution", "per_row")
    current.setdefault("description", "")
    current.setdefault("parameters", [])
    current.setdefault("system_variables", [])
    win = tk.Toplevel(parent)
    win.title("登録コマンドの編集")
    fit_window(win, 960, 760, 820, 640)
    win.transient(parent)
    win.grab_set()
    result = []
    name = tk.StringVar(value=current.get("name", "新しいコマンド"))
    description = tk.StringVar(value=current.get("description", ""))
    system_variables = tk.StringVar(
        value=", ".join(current.get("system_variables", []))
    )
    execution = tk.StringVar(
        value="生成全体で1回"
        if current.get("execution") == "once"
        else "対象の各行で実行"
    )
    params = copy.deepcopy(current.get("parameters", []))
    header = ttk.Frame(win, padding=14)
    header.pack(fill="x")
    for label, var in [("コマンド名", name), ("説明・使用条件", description)]:
        row = ttk.Frame(header)
        row.pack(fill="x", pady=3)
        ttk.Label(row, text=label, width=17).pack(side="left")
        ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True)
    restore_row = ttk.Frame(header)
    restore_row.pack(fill="x", pady=3)
    ttk.Label(restore_row, text="追加の復元変数", width=17).pack(side="left")
    ttk.Entry(restore_row, textvariable=system_variables).pack(
        side="left", fill="x", expand=True
    )
    ttk.Label(
        header,
        text="通常のSETVARは自動検出します。独自コマンド内部で変更する変数は、名前をカンマ区切りで追加。",
        style="Muted.TLabel",
        wraplength=850,
    ).pack(anchor="w")
    row = ttk.Frame(header)
    row.pack(fill="x", pady=3)
    ttk.Label(row, text="実行回数", width=17).pack(side="left")
    ttk.Combobox(
        row,
        textvariable=execution,
        values=["対象の各行で実行", "生成全体で1回"],
        state="readonly",
        width=25,
    ).pack(side="left")
    ttk.Label(row, text="寸法スタイル作成などは1回を推奨", style="Muted.TLabel").pack(
        side="left", padx=12
    )
    footer = ttk.Frame(win, padding=14)
    footer.pack(side="bottom", fill="x")
    tabs = ttk.Notebook(win)
    tabs.pack(fill="both", expand=True, padx=14, pady=(0, 10))
    scriptpage = ttk.Frame(tabs, padding=10)
    parampage = ttk.Frame(tabs, padding=10)
    tabs.add(scriptpage, text="SCRの手順")
    tabs.add(parampage, text="引数の設定")
    ttk.Label(
        scriptpage,
        text="AutoCADに送る順に1行ずつ入力します。1行=Enter1回、空行もEnterです。\n引数は {VALUE} のように記述。文字として波括弧を使うときは {{ と }} にします。",
        style="Muted.TLabel",
        wraplength=850,
    ).pack(anchor="w", pady=(0, 10))
    body = tk.Text(scriptpage, wrap="none", undo=True, font=("Consolas", 12), height=12)
    scroll = ttk.Scrollbar(scriptpage, command=body.yview)
    body.configure(yscrollcommand=scroll.set)
    scroll.pack(side="right", fill="y")
    body.pack(fill="both", expand=True)
    body.insert(
        "1.0", "\n".join(current.get("lines", ["_.SETVAR", "CMDECHO", "{VALUE}"]))
    )
    ttk.Label(
        parampage,
        text="数値: 値・@列名・settings.名前などの式。文字列: そのままの値、または =式。",
        style="Muted.TLabel",
        wraplength=840,
    ).pack(anchor="w", pady=(0, 8))
    tree = GridTreeview(
        parampage,
        columns=("name", "label", "kind", "default"),
        show="headings",
        height=6,
        selectmode="browse",
    )
    for key, title, width in [
        ("name", "引数名", 120),
        ("label", "表示名", 220),
        ("kind", "種類", 90),
        ("default", "既定値 / 式", 220),
    ]:
        tree.heading(key, text=title)
        tree.column(key, width=width, minwidth=70)
    tree.pack(fill="both", expand=True)
    p_name = tk.StringVar()
    p_label = tk.StringVar()
    p_kind = tk.StringVar(value="number")
    p_default = tk.StringVar(value="0")
    fields = ttk.Frame(parampage)
    fields.pack(fill="x", pady=8)
    for i, (label, var, width) in enumerate(
        [
            ("引数名", p_name, 14),
            ("表示名", p_label, 20),
            ("種類", p_kind, 10),
            ("既定値", p_default, 20),
        ]
    ):
        ttk.Label(fields, text=label).grid(row=0, column=i, padx=4, sticky="w")
        entry = (
            ttk.Combobox(
                fields,
                textvariable=var,
                values=["number", "text"],
                state="readonly",
                width=width,
            )
            if var is p_kind
            else ttk.Entry(fields, textvariable=var, width=width)
        )
        entry.grid(row=1, column=i, padx=4, sticky="ew")
        fields.columnconfigure(i, weight=1)

    def populate():
        tree.delete(*tree.get_children())
        for i, param in enumerate(params):
            tree.insert(
                "",
                "end",
                iid=str(i),
                values=(
                    param["name"],
                    param.get("label", param["name"]),
                    param["kind"],
                    param.get("default", ""),
                ),
            )

    populate()

    def select(_=None):
        if tree.selection():
            param = params[int(tree.selection()[0])]
            p_name.set(param["name"])
            p_label.set(param.get("label", param["name"]))
            p_kind.set(param["kind"])
            p_default.set(str(param.get("default", "")))

    tree.bind("<<TreeviewSelect>>", select)

    def upsert():
        param = {
            "name": p_name.get().strip(),
            "label": p_label.get().strip() or p_name.get().strip(),
            "kind": p_kind.get(),
            "default": p_default.get(),
        }
        selected = tree.selection()
        i = int(selected[0]) if selected else None
        candidate = copy.deepcopy(params)
        if i is None:
            candidate.append(param)
        else:
            candidate[i] = param
        # Validate identifiers without requiring the currently edited template to match.
        probe = {"name": "検査", "parameters": candidate, "lines": ["_.REGEN"]}
        errors = validate_catalog({"probe": probe})
        if errors:
            messagebox.showerror("引数の確認", "\n".join(errors[:5]), parent=win)
            return False
        params[:] = candidate
        populate()
        tree.selection_set(str(len(params) - 1 if i is None else i))
        return True

    buttons = ttk.Frame(parampage)
    buttons.pack(fill="x")
    ttk.Button(buttons, text="追加 / 更新", command=upsert).pack(side="left")

    def clear():
        tree.selection_remove(tree.selection())
        p_name.set("")
        p_label.set("")
        p_kind.set("number")
        p_default.set("0")

    ttk.Button(buttons, text="新しい引数", command=clear).pack(side="left", padx=5)

    def remove():
        selected = tree.selection()
        if selected:
            params.pop(int(selected[0]))
            populate()
            clear()

    ttk.Button(buttons, text="削除", command=remove).pack(side="left")

    def current_definition():
        return {
            "name": name.get().strip(),
            "description": description.get(),
            "execution": "once" if execution.get() == "生成全体で1回" else "per_row",
            "parameters": copy.deepcopy(params),
            "lines": body.get("1.0", "end-1c").split("\n"),
            "system_variables": [
                v.upper() for v in system_variables.get().replace(",", " ").split()
            ],
        }

    def save():
        selected = tree.selection()
        pending = (
            p_name.get().strip(),
            p_label.get().strip() or p_name.get().strip(),
            p_kind.get(),
            p_default.get(),
        )
        old = params[int(selected[0])] if selected else None
        before = (
            (
                old["name"],
                old.get("label", old["name"]),
                old["kind"],
                str(old.get("default", "")),
            )
            if old
            else ("", "", "number", "0")
        )
        if p_name.get().strip() and pending != before and not upsert():
            return
        definition = current_definition()
        errors = validate_catalog({"entry": definition})
        if errors:
            return messagebox.showerror(
                "登録内容の確認", "\n".join(errors[:8]), parent=win
            )
        result.append(definition)
        win.destroy()

    def cancel():
        if current_definition() != current and not messagebox.askyesno(
            "変更の破棄", "編集中の登録コマンドを破棄しますか？", parent=win
        ):
            return
        win.destroy()

    ttk.Button(footer, text="キャンセル", command=cancel).pack(side="left")
    ttk.Button(
        footer, text="この定義を確定", style="Primary.TButton", command=save
    ).pack(side="right")
    win.protocol("WM_DELETE_WINDOW", cancel)
    win.bind("<Escape>", lambda e: cancel())
    parent.wait_window(win)
    parent.grab_set()
    return result[0] if result else None


class CommandCatalogManager:
    def __init__(self, parent, project, on_close):
        self.project = project
        self.on_close = on_close
        self.catalog = copy.deepcopy(project.get("custom_commands", {}))
        self.original = copy.deepcopy(self.catalog)
        self.win = tk.Toplevel(parent)
        self.win.title("ユーザー登録コマンド")
        fit_window(self.win, 980, 720, 820, 620)
        self.win.transient(parent)
        self.win.grab_set()
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        ttk.Label(
            self.win,
            text="コマンド名・引数・SCRの応答手順をJSONで登録します。登録例も編集・複製できます。",
            padding=14,
            wraplength=900,
        ).pack(anchor="w")
        footer = ttk.Frame(self.win, padding=14)
        footer.pack(side="bottom", fill="x")
        ttk.Button(footer, text="キャンセル", command=self.cancel).pack(side="left")
        ttk.Button(
            footer,
            text="プロジェクトに適用",
            style="Primary.TButton",
            command=self.save,
        ).pack(side="right")
        bar = ttk.Frame(self.win, padding=(14, 0))
        bar.pack(fill="x")
        for label, fn in [
            ("新規登録", self.add),
            ("編集", self.edit),
            ("複製", self.duplicate),
            ("削除", self.delete),
            ("JSON読込", self.import_json),
            ("JSON書出", self.export_json),
        ]:
            ttk.Button(bar, text=label, command=fn).pack(side="left", padx=(0, 4))
        area = ttk.Frame(self.win, padding=14)
        area.pack(fill="both", expand=True)
        self.tree = GridTreeview(
            area,
            columns=("name", "params", "execution"),
            show="headings",
            height=8,
            selectmode="browse",
        )
        for key, title, width in [
            ("name", "コマンド名", 360),
            ("params", "引数", 220),
            ("execution", "実行", 130),
        ]:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, minwidth=70)
        ys = ttk.Scrollbar(area, command=self.tree.yview)
        self.tree.configure(yscrollcommand=ys.set)
        ys.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.describe())
        self.tree.bind("<Double-1>", lambda e: self.edit())
        self.detail = tk.Text(
            self.win,
            height=7,
            wrap="word",
            state="disabled",
            font=("Consolas", 10),
            relief="flat",
            padx=12,
            pady=8,
        )
        self.detail.pack(side="bottom", fill="x", padx=14, pady=(0, 10), before=area)
        self.refresh()

    def selected(self):
        return self.tree.selection()[0] if self.tree.selection() else None

    def refresh(self, key=None):
        self.tree.delete(*self.tree.get_children())
        for item, definition in self.catalog.items():
            self.tree.insert(
                "",
                "end",
                iid=item,
                values=(
                    definition["name"],
                    ", ".join(p["name"] for p in definition.get("parameters", [])),
                    "全体1回" if definition.get("execution") == "once" else "各行",
                ),
            )
        if key in self.catalog:
            self.tree.selection_set(key)
            self.tree.see(key)
        self.describe()

    def describe(self):
        key = self.selected()
        text = "登録したコマンドは、コマンド追加画面の「ユーザー登録コマンド」で選択します。\n任意のSCRは図形プレビューには反映しません。生成SCRタブで手順を確認してください。"
        if key:
            definition = self.catalog[key]
            text = (
                definition.get("description", "")
                + "\n\nSCR手順:\n"
                + "\n".join(definition["lines"])
            )
        self.detail.configure(state="normal")
        self.detail.delete("1.0", "end")
        self.detail.insert("1.0", text)
        self.detail.configure(state="disabled")

    def add(self):
        definition = edit_definition(
            self.win,
            {
                "name": "新しいコマンド",
                "description": "",
                "parameters": [
                    {"name": "VALUE", "label": "値", "kind": "number", "default": "0"}
                ],
                "lines": ["_.SETVAR", "CMDECHO", "{VALUE}"],
                "execution": "per_row",
            },
        )
        if definition:
            key = "cmd_" + uuid.uuid4().hex
            self.catalog[key] = definition
            self.refresh(key)

    def edit(self):
        key = self.selected()
        if not key:
            return
        definition = edit_definition(self.win, self.catalog[key])
        if definition:
            self.catalog[key] = definition
            self.refresh(key)

    def duplicate(self):
        key = self.selected()
        if not key:
            return
        definition = copy.deepcopy(self.catalog[key])
        base = definition["name"][:65] + " コピー"
        names = {d["name"] for d in self.catalog.values()}
        name = base
        i = 2
        while name in names:
            name = f"{base} ({i})"
            i += 1
        definition["name"] = name
        key = "cmd_" + uuid.uuid4().hex
        self.catalog[key] = definition
        self.refresh(key)

    def usages(self, key):
        from block_model import groups

        result = []
        for name, commands in groups(self.project):
            for cmd in walk_commands(commands):
                if cmd.get("type", "").upper() == "CUSTOM" and cmd.get("name") == key:
                    result.append(name)
        return list(dict.fromkeys(result))

    def delete(self):
        key = self.selected()
        if not key:
            return
        uses = self.usages(key)
        if uses:
            return messagebox.showerror(
                "使用中のコマンド",
                "先に呼び出し元を変更してください。\n" + "\n".join(uses),
                parent=self.win,
            )
        self.catalog.pop(key)
        self.refresh()

    def import_json(self):
        path = filedialog.askopenfilename(
            parent=self.win, filetypes=[("登録コマンドJSON", "*.json")]
        )
        if not path:
            return
        try:
            self.catalog = merge_library(self.catalog, read_library(path))
            self.refresh()
        except (ValueError, OSError) as exc:
            messagebox.showerror("JSON読込", str(exc), parent=self.win)

    def export_json(self):
        path = filedialog.asksaveasfilename(
            parent=self.win,
            defaultextension=".json",
            initialfile="command_library.json",
            filetypes=[("登録コマンドJSON", "*.json")],
        )
        if not path:
            return
        try:
            atomic_save(path, library_document(self.catalog))
        except (ValueError, OSError) as exc:
            messagebox.showerror("JSON書出", str(exc), parent=self.win)

    def cancel(self):
        if self.catalog != self.original and not messagebox.askyesno(
            "変更の破棄", "登録コマンドの変更を破棄しますか？", parent=self.win
        ):
            return
        self.win.destroy()

    def save(self):
        trial = copy.deepcopy(self.project)
        trial["custom_commands"] = self.catalog
        errors = validate_project(trial)
        if errors:
            return messagebox.showerror(
                "登録内容の確認", "\n".join(errors[:10]), parent=self.win
            )
        self.project["custom_commands"] = copy.deepcopy(self.catalog)
        self.win.destroy()
        self.on_close()
