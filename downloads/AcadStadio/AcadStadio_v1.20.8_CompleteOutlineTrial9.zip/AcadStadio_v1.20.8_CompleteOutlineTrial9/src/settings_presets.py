"""Project-local snapshots of drawing settings, separate from command presets."""

import copy
import math
import uuid

SIZE_KEYS = ("TEXT_HEIGHT", "DIM_TEXT_HEIGHT", "ARROW_SIZE", "DIM_SCALE")
BUILTINS = {
    "default": {
        "name": "デフォルト",
        "values": dict(zip(SIZE_KEYS, (3.5, 3.5, 2.5, 1))),
    },
    "small": {"name": "小さめ", "values": dict(zip(SIZE_KEYS, (2.5, 2.5, 1.8, 1)))},
    "large": {"name": "大きめ", "values": dict(zip(SIZE_KEYS, (5, 5, 3.5, 1)))},
}
MAX_PRESETS = 100


def entries(project):
    return {
        **copy.deepcopy(BUILTINS),
        **copy.deepcopy(project.get("settings_presets", {})),
    }


def validate_values(values, valid_name):
    errors = []
    if not isinstance(values, dict) or not 1 <= len(values) <= 500:
        return ["設定値は1〜500項目で指定してください"]
    for key, value in values.items():
        if not valid_name(key):
            errors.append(f"設定名が不正です: {key}")
        if not isinstance(value, (str, int, float, bool)) or (
            isinstance(value, float) and not math.isfinite(value)
        ):
            errors.append(f"{key}: 値は有限の数値または文字列にしてください")
        elif key in SIZE_KEYS:
            from engine import number, MacroError

            try:
                if isinstance(value, bool) or float(number(str(value), {})) <= 0:
                    raise ValueError()
            except (MacroError, ValueError, OverflowError):
                errors.append(f"{key}: 正の数値にしてください")
    return errors


def validate_presets(project, valid_name):
    custom = project.get("settings_presets", {})
    if not isinstance(custom, dict) or len(custom) > MAX_PRESETS:
        return ["カスタム設定プリセットは100件までのオブジェクトで指定してください"]
    errors = []
    names = {p["name"] for p in BUILTINS.values()}
    for key, preset in custom.items():
        if not valid_name(key) or key in BUILTINS:
            errors.append("設定プリセットIDが不正または標準と重複しています")
        if not isinstance(preset, dict):
            errors.append("設定プリセットの形式が不正です")
            continue
        name = preset.get("name")
        if not isinstance(name, str) or not name.strip() or len(name) > 80:
            errors.append("設定プリセット名は1〜80文字にしてください")
        elif name.strip() in names:
            errors.append("設定プリセット名が重複しています: " + name)
        else:
            names.add(name.strip())
        errors.extend(validate_values(preset.get("values"), valid_name))
    active = project.get("active_settings_preset", "")
    if not isinstance(active, str) or (active and active not in entries(project)):
        errors.append("適用中の設定プリセットIDが不正です")
    return errors


def create_preset(project, name, values):
    from project_model import valid_name

    name = name.strip()
    if not name or len(name) > 80:
        raise ValueError("名前は1〜80文字にしてください")
    if name in {p["name"] for p in entries(project).values()}:
        raise ValueError("同じ名前の設定プリセットがあります")
    if len(project.get("settings_presets", {})) >= MAX_PRESETS:
        raise ValueError("カスタム設定プリセットは100件までです")
    errors = validate_values(values, valid_name)
    if errors:
        raise ValueError("\n".join(errors[:12]))
    key = "custom_" + uuid.uuid4().hex
    project.setdefault("settings_presets", {})[key] = {
        "name": name,
        "values": copy.deepcopy(values),
    }
    return key


def apply_preset(project, key):
    values = entries(project)[key]["values"]
    from engine import number

    for name in SIZE_KEYS:
        if name in values and isinstance(values[name], str):
            values[name] = number(values[name], {})
    project["settings"].update(copy.deepcopy(values))
    project["active_settings_preset"] = key


def active_label(project):
    key = project.get("active_settings_preset", "")
    preset = entries(project).get(key)
    if not preset:
        return "個別設定"
    from engine import number, MacroError

    def matches(name, saved):
        current = project["settings"].get(name)
        if name in SIZE_KEYS:
            try:
                return number(str(current), {}) == number(str(saved), {})
            except MacroError:
                return False
        return str(current) == str(saved)

    changed = any(not matches(k, v) for k, v in preset["values"].items())
    return preset["name"] + ("（変更あり）" if changed else "")
