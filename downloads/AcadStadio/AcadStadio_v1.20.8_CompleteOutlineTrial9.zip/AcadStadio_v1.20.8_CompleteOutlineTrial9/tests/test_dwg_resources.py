"""DWG resource extraction and selective import, without requiring AutoCAD."""

import copy
import math
from pathlib import Path
import sys
import unittest
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cad_setup import default_setup, validate_setup
from dwg_resources import (
    DWGImportError, extract_resources, merge_selected_definitions, read_dwg_resources,
)


def obj(**properties):
    return SimpleNamespace(**properties)


class FakeDocument:
    def __init__(self):
        self.Layers = [
            obj(Name="PARTS", Color=2, Linetype="DASHED", Lineweight=25,
                Plottable=True, TrueColor=None),
            obj(Name="GUIDE", Color=8, Linetype="Continuous", Lineweight=-3,
                Plottable=False, TrueColor=None),
        ]
        self.TextStyles = [obj(Name="CF_TEXT", FontFile="arial.ttf", Width=0.9,
                               ObliqueAngle=math.pi / 12, Height=0)]
        self.Linetypes = [obj(Name="DASHED", Description="dash"),
                          obj(Name="Continuous", Description="solid")]
        self.DimStyles = [obj(Name="Standard"), obj(Name="CF_DIM")]
        self._styles = {
            "Standard": dict(DIMSCALE=1, DIMTXT=2.5, DIMASZ=2.5, DIMTXSTY="Standard"),
            "CF_DIM": dict(DIMSCALE=2, DIMTXT=3.5, DIMASZ=2.5, DIMTXSTY="CF_TEXT"),
        }
        self._active = self.DimStyles[0]
        self.changes = []

    @property
    def ActiveDimStyle(self):
        return self._active

    @ActiveDimStyle.setter
    def ActiveDimStyle(self, value):
        self.changes.append(value.Name)
        self._active = value

    def GetVariable(self, name):
        return self._styles[self._active.Name][name]


class DWGResourceTests(unittest.TestCase):
    def setUp(self):
        self.document = FakeDocument()
        self.candidates, self.issues = extract_resources(self.document)

    def test_reads_layers_with_color_linetype_lineweight_and_plot(self):
        rows = self.candidates["layers"]
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["values"], dict(
            name="PARTS", color="2", linetype="DASHED", lineweight="25", plot=True,
        ))
        self.assertFalse(rows[1]["values"]["plot"])
        self.assertEqual(rows[1]["values"]["lineweight"], "-3")

    def test_text_style_degrees_and_fixed_height_caveat(self):
        row = self.candidates["text_styles"][0]
        self.assertEqual(row["values"], dict(
            name="CF_TEXT", font="arial.ttf", width="0.9", oblique="15",
        ))
        self.assertTrue(row["supported"])
        self.document.TextStyles[0].Height = 5
        items, _ = extract_resources(self.document)
        self.assertIn("固定高さ", items["text_styles"][0]["note"])

    def test_dim_style_values_from_active_document_and_restoration(self):
        rows = self.candidates["dim_styles"]
        self.assertEqual(rows[1]["values"], dict(
            name="CF_DIM", base="", scale="2", text_height="3.5",
            arrow_size="2.5", text_style="CF_TEXT",
        ))
        self.assertEqual(self.document.ActiveDimStyle.Name, "Standard")
        self.assertEqual(self.document.changes[-1], "Standard")

    def test_failed_dim_style_is_unselectable_but_kept_for_inspection(self):
        self.document._styles["CF_DIM"]["DIMTXT"] = 0
        resources, _ = extract_resources(self.document)
        self.assertFalse(resources["dim_styles"][1]["supported"])
        self.assertIn("取得不可", resources["dim_styles"][1]["note"])

    def test_dwg_linetype_has_no_invented_lin_file(self):
        rows = self.candidates["linetypes"]
        self.assertEqual([r["name"] for r in rows], ["DASHED"])
        self.assertEqual(rows[0]["values"]["file"], "")
        self.assertIn("同名の線種", rows[0]["note"])

    def test_merge_only_checked_rows_is_transactional(self):
        setup = default_setup()
        original = copy.deepcopy(setup)
        selected = {"layers": {"GUIDE"}, "text_styles": {"CF_TEXT"}}
        result = merge_selected_definitions(setup, self.candidates, selected)
        self.assertEqual(setup, original)
        self.assertEqual([r["name"] for r in result["layers"]], ["GUIDE"])
        self.assertEqual([r["name"] for r in result["text_styles"]], ["CF_TEXT"])
        self.assertEqual(result["dim_styles"], [])
        self.assertEqual(validate_setup(result), [])

    def test_existing_name_is_kept_by_default_and_can_be_replaced(self):
        setup = default_setup()
        setup["layers"] = [dict(name="parts", color="7", linetype="Continuous",
                                 lineweight="-3", plot=True)]
        selected = {"layers": ["PARTS"]}
        kept = merge_selected_definitions(setup, self.candidates, selected)
        overwritten = merge_selected_definitions(setup, self.candidates, selected,
                                                 overwrite=True)
        self.assertEqual(kept["layers"][0]["color"], "7")
        self.assertEqual(overwritten["layers"][0]["color"], "2")
        self.assertEqual(len(overwritten["layers"]), 1)

    def test_linetype_uses_existing_cad_definition_without_a_lin_file(self):
        chosen = {"linetypes": ["DASHED"]}
        result=merge_selected_definitions(default_setup(), self.candidates, chosen)
        self.assertTrue(result["linetypes"][0]["existing_only"])
        self.assertEqual(result["linetypes"][0]["file"], "")
        merged = merge_selected_definitions(
            default_setup(), self.candidates, chosen, linetype_file="mytypes.lin"
        )
        self.assertEqual(merged["linetypes"][0]["file"], "mytypes.lin")

    def test_bad_values_or_over_limit_reject_entire_import(self):
        candidate = copy.deepcopy(self.candidates)
        candidate["layers"][0]["values"]["color"] = "256"
        with self.assertRaises(DWGImportError):
            merge_selected_definitions(default_setup(), candidate, {"layers": ["PARTS"]})
        setup = default_setup()
        setup["layers"] = [dict(name=f"L{i}", color="7", linetype="Continuous",
                                lineweight="-3", plot=True) for i in range(100)]
        with self.assertRaises(DWGImportError):
            merge_selected_definitions(setup, self.candidates, {"layers": ["PARTS"]})

    def test_unavailable_dimstyle_cannot_be_silently_imported(self):
        bad = copy.deepcopy(self.candidates)
        bad["dim_styles"][0]["supported"] = False
        with self.assertRaises(DWGImportError):
            merge_selected_definitions(default_setup(), bad,
                                       {"dim_styles": ["Standard"]})

    def test_invalid_file_rejected_before_opening_autocad(self):
        with self.assertRaisesRegex(DWGImportError, "DWGファイル"):
            read_dwg_resources("missing_file.dwg")


if __name__ == "__main__":
    unittest.main()
