"""Behavioral coverage for the one-level drawing/reusable block model."""

import copy
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from audit import audit_details, audit_project
from block_model import references
from cad_setup import default_setup
from engine import compile_project, MacroError
from flow import execution_address, resolve
from project_model import normalize_project, validate_project


def circle(x="@X", radius="2"):
    return {"type": "CIRCLE", "x": x, "y": "0", "r": radius}


def call(name, **extra):
    return dict(type="BLOCK", name=name, **extra)


def legacy(*presets, blocks=None):
    return {
        "version": 10,
        "rows": [{"X": "10", "TYPE": "A"}, {"X": "30", "TYPE": "B"}],
        "settings": {"TEXT_HEIGHT": "3.5"},
        "globals": {"BASE": "@X + 1"},
        "cad_setup": default_setup(),
        "custom_commands": {},
        "blocks": blocks or {},
        "presets": list(presets),
    }


def preset(name, commands, **extra):
    result = dict(name=name, enabled=True, condition="", variables={}, commands=commands)
    result.update(extra)
    return result


def definition(identity, name, commands, draw=True, condition="", variables=None):
    return dict(id=identity, name=name, draw=draw, condition=condition, variables=variables or {}, commands=commands)


def modern(*blocks):
    data = legacy()
    data.pop("presets")
    data.update(version=11, blocks=list(blocks))
    return normalize_project(data)


def geometry(items):
    """Compare generated drawing facts independently of migrated source locations."""
    ignored = {"preset", "preset_index", "block", "block_index", "definition_block_index", "command_path", "command_index", "command_addresses"}
    return [{k: v for k, v in item.items() if k not in ignored} for item in items]


class LegacyBlockMigration(unittest.TestCase):
    def assert_same_drawing(self, old, rows=(0, 1)):
        before = copy.deepcopy(old)
        new = normalize_project(old)
        old_script, old_items = compile_project(old, rows)
        new_script, new_items = compile_project(new, rows)
        self.assertEqual(new_script, old_script)
        self.assertEqual(geometry(new_items), geometry(old_items))
        self.assertEqual(old, before)
        self.assertNotIn("presets", new)
        self.assertEqual(new["version"], 11)
        self.assertEqual(validate_project(new), [])
        return new

    def test_once_used_forwarding_wrapper_becomes_commands(self):
        old = legacy(preset("輪郭", [call("外形")]), blocks={"外形": [circle()]})
        new = self.assert_same_drawing(old)
        self.assertEqual(len(new["blocks"]), 1)
        self.assertEqual(new["blocks"][0]["name"], "輪郭")
        self.assertEqual(new["blocks"][0]["commands"], [circle()])
        self.assertTrue(new["blocks"][0]["draw"])

    def test_chain_of_single_use_forwarders_is_flattened(self):
        old = legacy(preset("輪郭", [call("outer")]), blocks={"outer": [call("inner")], "inner": [circle()]})
        new = self.assert_same_drawing(old)
        self.assertEqual(len(new["blocks"]), 1)
        self.assertEqual(new["blocks"][0]["commands"][0]["type"], "CIRCLE")

    def test_shared_and_unused_definitions_stay_call_only(self):
        old = legacy(
            preset("一つ目", [call("shared")]),
            preset("二つ目", [call("shared")]),
            blocks={"shared": [circle()], "unused": [circle("99")]},
        )
        new = self.assert_same_drawing(old)
        self.assertEqual([b["draw"] for b in new["blocks"]], [True, True, False, False])
        first, second, shared, unused = new["blocks"]
        self.assertEqual(first["commands"][0]["name"], shared["id"])
        self.assertEqual(second["commands"][0]["name"], shared["id"])
        self.assertEqual(unused["name"], "unused")
        self.assertEqual(references(new, shared["id"]), ["一つ目", "二つ目"])

    def test_conditional_call_is_not_flattened_and_preserves_row_condition(self):
        old = legacy(preset("conditional", [call("outer", condition='@TYPE == "A"')]), blocks={"outer": [circle()]})
        new = self.assert_same_drawing(old)
        self.assertEqual(len(new["blocks"]), 2)
        self.assertEqual(new["blocks"][0]["commands"][0]["type"], "BLOCK")
        self.assertEqual(len(compile_project(new, [0, 1])[1]), 1)

    def test_if_repeat_and_shared_set_keep_their_execution_order(self):
        commands = [
            {"type": "SET", "name": "OFFSET", "value": "1"},
            {"type": "REPEAT", "count": "2", "commands": [
                call("adjust"),
                {"type": "IF", "condition": 'row.TYPE == "A"', "commands": [circle("local.OFFSET")], "else": [circle("local.OFFSET + 100")]},
            ]},
        ]
        old = legacy(preset("loop", commands), blocks={"adjust": [{"type": "SET", "name": "OFFSET", "value": "local.OFFSET + 2"}]})
        new = self.assert_same_drawing(old)
        _, items = compile_project(new, [0, 1])
        self.assertEqual([i["coords"][0] for i in items], [3, 5, 103, 105])

    def test_migration_disambiguates_casefolded_display_names(self):
        old = legacy(
            preset("same", [call("Same"), circle()]),
            preset("SAME", [call("Same")]),
            blocks={"Same": [circle()]},
        )
        new = self.assert_same_drawing(old)
        names = [b["name"].casefold() for b in new["blocks"]]
        ids = [b["id"] for b in new["blocks"]]
        self.assertEqual(len(set(names)), len(names))
        self.assertEqual(len(set(ids)), len(ids))

    def test_root_conditions_variables_and_once_commands_survive_migration(self):
        old = legacy(
            preset("conditional", [{"type": "REPEAT", "count": "2", "commands": [call("helper")]}], condition='@TYPE == "A"', variables={"OFFSET": "global.BASE + 1"}),
            blocks={"helper": [{"type": "IF", "condition": "loop.number == 1", "commands": [{"type": "SYSVAR", "name": "LTSCALE", "value": "2", "execution": "once"}], "else": [circle("local.OFFSET")]}]},
        )
        new = self.assert_same_drawing(old)
        script, items = compile_project(new, [0, 1])
        self.assertEqual(script.count("_.SETVAR\nLTSCALE\n2"), 1)
        self.assertEqual([i["coords"][0] for i in items], [12])

    def test_maximum_legacy_call_depth_remains_usable_after_migration(self):
        shared = {f"h{i}": [call(f"h{i + 1}")] if i < 11 else [circle()] for i in range(12)}
        old = legacy(preset("first", [call("h0")]), preset("second", [call("h0")]), blocks=shared)
        self.assert_same_drawing(old, rows=(0,))

    def test_more_than_one_thousand_unused_legacy_definitions_remain_valid(self):
        old = legacy(blocks={f"unused_{i}": [] for i in range(1001)})
        new = self.assert_same_drawing(old, rows=(0,))
        self.assertEqual(len(new["blocks"]), 1001)
        self.assertFalse(any(block["draw"] for block in new["blocks"]))

    def test_disabled_legacy_drawing_container_is_call_only(self):
        p = preset("off", [circle()])
        p["enabled"] = False
        new = self.assert_same_drawing(legacy(p))
        self.assertFalse(new["blocks"][0]["draw"])
        self.assertEqual(compile_project(new, [0])[1], [])

    def test_normalization_is_idempotent_and_json_roundtrip_has_one_collection(self):
        new = normalize_project(legacy(preset("outline", [circle()])))
        again = normalize_project(json.loads(json.dumps(new, ensure_ascii=False)))
        self.assertEqual(new, again)
        self.assertEqual(list(again).count("blocks"), 1)
        self.assertNotIn("presets", again)
        self.assertNotIn("_block_definitions", again)


class UnifiedBlockExecution(unittest.TestCase):
    def test_display_rename_does_not_change_calls_or_output(self):
        data = modern(
            definition("main", "作図", [call("helper")]),
            definition("helper", "繰り返す形", [circle()], draw=False),
        )
        before = compile_project(data, [0])
        data["blocks"][1]["name"] = "名前を変更した形"
        self.assertEqual(compile_project(data, [0])[0], before[0])
        self.assertEqual(geometry(compile_project(data, [0])[1]), geometry(before[1]))
        self.assertEqual(data["blocks"][0]["commands"][0]["name"], "helper")

    def test_only_draw_blocks_run_directly_but_call_only_blocks_can_be_reused(self):
        data = modern(
            definition("main", "作図", [call("helper"), call("helper")]),
            definition("helper", "呼出のみ", [circle()], draw=False),
            definition("unused", "未使用", [circle("99")], draw=False),
        )
        _, items = compile_project(data, [0])
        self.assertEqual(len(items), 2)
        self.assertEqual([i["coords"][0] for i in items], [10, 10])
        self.assertEqual({i["block_index"] for i in items}, {0})
        self.assertEqual({i["definition_block_index"] for i in items}, {1})

    def test_root_block_order_is_stored_in_the_one_list(self):
        data = modern(definition("a", "A", [circle("1")]), definition("b", "B", [circle("2")]))
        data["blocks"].reverse()
        _, items = compile_project(data, [0])
        self.assertEqual([i["coords"][0] for i in items], [2, 1])

    def test_call_only_block_condition_applies_on_each_input_row(self):
        data = modern(
            definition("main", "作図", [call("helper")]),
            definition("helper", "Aだけ", [circle()], draw=False, condition='@TYPE == "A"'),
        )
        _, items = compile_project(data, [0, 1])
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["row"], 0)

    def test_declared_call_variables_are_scoped_and_can_reference_caller(self):
        data = modern(
            definition("main", "作図", [call("helper"), circle("local.OFFSET")], variables={"OFFSET": "5"}),
            definition("helper", "呼出", [circle("local.OFFSET")], draw=False, variables={"OFFSET": "local.OFFSET + 10"}),
        )
        _, items = compile_project(data, [0])
        self.assertEqual([i["coords"][0] for i in items], [15, 5])

    def test_nested_call_keeps_loop_context(self):
        data = modern(
            definition("main", "作図", [{"type": "REPEAT", "count": "3", "commands": [call("helper")]}]),
            definition("helper", "穴", [call("inner")], draw=False),
            definition("inner", "点", [circle("loop.index * 10")], draw=False),
        )
        _, items = compile_project(data, [0])
        self.assertEqual([i["coords"][0] for i in items], [0, 10, 20])
        self.assertEqual({i["definition_block_index"] for i in items}, {2})


class UnifiedBlockValidation(unittest.TestCase):
    def test_float_model_version_is_rejected(self):
        data = modern(definition("main", "作図", []))
        data["version"] = 11.0
        self.assertTrue(validate_project(data))
        with self.assertRaises(ValueError):
            normalize_project(data)

    def test_audit_counts_each_definition_once_at_the_command_limit(self):
        data = modern(definition("main", "作図", [{"type": "SET", "name": "VALUE", "value": "1"} for _ in range(5001)]))
        self.assertEqual(validate_project(data), [])
        self.assertEqual(audit_project(data), [])

    def test_duplicate_and_missing_block_ids_are_rejected(self):
        valid = modern(definition("a", "A", [circle()]), definition("b", "B", [circle()]))
        for alteration in ("duplicate", "missing", "invalid"):
            data = copy.deepcopy(valid)
            if alteration == "duplicate":
                data["blocks"][1]["id"] = "a"
            elif alteration == "missing":
                del data["blocks"][1]["id"]
            else:
                data["blocks"][1]["id"] = "bad/id"
            with self.subTest(alteration=alteration):
                self.assertTrue(validate_project(data))
                with self.assertRaises(MacroError):
                    compile_project(data, [0])

    def test_display_name_uniqueness_is_case_insensitive(self):
        data = modern(definition("a", "A", []), definition("b", "B", []))
        data["blocks"][1]["name"] = "a"
        self.assertTrue(validate_project(data))

    def test_missing_reference_is_rejected_even_in_an_inactive_branch(self):
        data = modern(definition("root", "root", []))
        data["blocks"][0]["commands"] = [{"type": "IF", "condition": "False", "commands": [call("missing")]}]
        self.assertTrue(any("参照先" in message for message in validate_project(data)))

    def test_cycles_are_rejected_between_call_only_blocks(self):
        data = modern(definition("a", "A", []), definition("b", "B", [], draw=False))
        data["blocks"][0]["draw"] = False
        data["blocks"][0]["commands"] = [call("b")]
        data["blocks"][1]["commands"] = [{"type": "REPEAT", "count": "0", "commands": [call("a")]}]
        self.assertTrue(any("循環" in message for message in validate_project(data)))
        self.assertTrue(audit_project(data))

    def test_mixed_old_and_new_collections_are_rejected(self):
        data = modern(definition("a", "A", []))
        data["presets"] = []
        self.assertTrue(validate_project(data))


class UnifiedBlockDiagnostics(unittest.TestCase):
    def test_trace_keeps_repeat_branch_call_site_and_called_definition(self):
        data = modern(
            definition("main", "作図", [{"type": "REPEAT", "count": "2", "commands": [{"type": "IF", "condition": 'row.TYPE == "A"', "commands": [call("helper")]}]}]),
            definition("helper", "呼出先", [circle("loop.index"), {"type": "SYSVAR", "name": "LTSCALE", "value": "2"}], draw=False),
        )
        events = []
        _, items = compile_project(data, [0], diagnostics=events)
        outer_frames = [
            ("blocks", 0, "commands", 0),
            ("blocks", 0, "commands", 0, "commands", 0),
            ("blocks", 0, "commands", 0, "commands", 0, "commands", 0),
        ]
        self.assertEqual([item["coords"][0] for item in items], [0, 1])
        for item in items:
            self.assertEqual(item["command_addresses"], outer_frames + [("blocks", 1, "commands", 0)])
            self.assertEqual([resolve(data, address)["type"] for address in item["command_addresses"]], ["REPEAT", "IF", "BLOCK", "CIRCLE"])
        self.assertEqual(len(events), 2)
        for event in events:
            self.assertEqual(event["command_addresses"], outer_frames + [("blocks", 1, "commands", 1)])

    def test_two_calls_of_one_definition_have_distinct_call_site_traces(self):
        data = modern(
            definition("main", "作図", [call("helper"), call("helper")]),
            definition("helper", "共通形", [circle()], draw=False),
        )
        _, items = compile_project(data, [0])
        self.assertEqual(items[0]["command_addresses"], [("blocks", 0, "commands", 0), ("blocks", 1, "commands", 0)])
        self.assertEqual(items[1]["command_addresses"], [("blocks", 0, "commands", 1), ("blocks", 1, "commands", 0)])

    def test_literal_if_and_else_ids_are_not_confused_with_branch_markers(self):
        data = modern(
            definition("main", "作図", [{"type": "IF", "condition": "True", "commands": [call("IF")]}]),
            definition("IF", "IFというIDの形", [call("ELSE")], draw=False),
            definition("ELSE", "ELSEというIDの形", [circle()], draw=False),
        )
        _, items = compile_project(data, [0])
        expected = ("blocks", 2, "commands", 0)
        self.assertEqual(len(items), 1)
        self.assertIn("/BLOCK:IF/", items[0]["command_path"])
        self.assertIn("/BLOCK:ELSE/", items[0]["command_path"])
        self.assertEqual(items[0]["command_addresses"][-1], expected)
        self.assertEqual(execution_address(data, 0, items[0]["command_path"]), expected)
        data["blocks"][2]["commands"][0]["r"] = "1 / 0"
        with self.assertRaises(MacroError) as caught:
            compile_project(data, [0])
        self.assertEqual(caught.exception.location["address"], expected)
        self.assertEqual(audit_details(data)[0]["address"], expected)

    def test_appending_diagnostics_does_not_rewrite_previous_compilation(self):
        data = modern(definition("main", "作図", [{"type": "SYSVAR", "name": "LTSCALE", "value": "2"}]))
        events = []
        compile_project(data, [0], diagnostics=events)
        before = copy.deepcopy(events)
        compile_project(data, [1], diagnostics=events)
        self.assertEqual(events[:len(before)], before)
        self.assertEqual([event["row"] for event in events], [0, 1])

    def broken_project(self, expression="1 / 0", condition="True"):
        return modern(
            definition("main", "作図", [{"type": "IF", "condition": condition, "commands": [call("helper")]}]),
            definition("helper", "計算先", [{"type": "REPEAT", "count": "2", "commands": [circle("0", expression)]}], draw=False),
        )

    def test_runtime_error_and_audit_resolve_the_definition_not_the_call_site(self):
        data = self.broken_project()
        expected = ("blocks", 1, "commands", 0, "commands", 0)
        with self.assertRaises(MacroError) as caught:
            compile_project(data, [1])
        location = caught.exception.location
        self.assertEqual(location["row"], 1)
        self.assertEqual(location["block_index"], 0)
        self.assertEqual(location["address"], expected)
        self.assertEqual(execution_address(data, 0, location["command_path"]), expected)
        self.assertEqual(resolve(data, expected)["type"], "CIRCLE")
        records = audit_details(data)
        self.assertEqual(records[0]["address"], expected)
        self.assertEqual(records[0]["block_index"], 0)

    def test_inactive_syntax_error_still_has_a_native_definition_address(self):
        data = self.broken_project("1+", "False")
        records = audit_details(data)
        self.assertTrue(records)
        self.assertEqual(records[0]["address"], ("blocks", 1, "commands", 0, "commands", 0))
        self.assertEqual(records[0]["block_index"], 1)

    def test_structural_error_has_a_native_definition_address(self):
        data = modern(definition("main", "作図", []))
        data["blocks"][0]["commands"] = [{"type": "IF", "condition": "False", "commands": [call("missing")]}]
        records = audit_details(data)
        self.assertEqual(records[0]["address"], ("blocks", 0, "commands", 0, "commands", 0))
        self.assertEqual(records[0]["block_index"], 0)


if __name__ == "__main__":
    unittest.main()
