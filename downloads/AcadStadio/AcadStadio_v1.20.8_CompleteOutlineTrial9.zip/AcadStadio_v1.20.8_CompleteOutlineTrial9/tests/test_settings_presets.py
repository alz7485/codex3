"""Persistence, validation and compilation behavior of drawing-setting snapshots."""

import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from project_model import normalize_project, validate_project
from sample_project import EXAMPLE, LEGACY_EXAMPLE
from settings_presets import entries, create_preset, apply_preset, active_label
from project_safety import atomic_save
from engine import compile_project


class SettingsPresets(unittest.TestCase):
    def setUp(self):
        self.p = copy.deepcopy(EXAMPLE)

    def test_legacy_upgrade_keeps_settings_without_auto_applying(self):
        old = copy.deepcopy(LEGACY_EXAMPLE)
        old["version"] = 8
        old.pop("settings_presets")
        old.pop("active_settings_preset")
        upgraded = normalize_project(old)
        self.assertEqual(upgraded["settings"], old["settings"])
        self.assertEqual(upgraded["active_settings_preset"], "")
        self.assertEqual(len(entries(upgraded)), 3)

    def test_json_roundtrip_and_generated_size(self):
        values = dict(self.p["settings"], TEXT_HEIGHT="8", DIM_SCALE="2")
        key = create_preset(self.p, "図面A用", values)
        apply_preset(self.p, key)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "settings.json"
            atomic_save(path, self.p)
            loaded = normalize_project(json.loads(path.read_text(encoding="utf-8")))
        self.assertEqual(loaded, self.p)
        self.assertEqual(active_label(loaded), "図面A用")
        output = compile_project(loaded, [0])
        self.assertEqual(output, compile_project(self.p, [0]))
        self.assertIn("_.DIMSCALE\n2", output[0])

    def test_builtin_preserves_custom_values_targets_and_commands(self):
        before = copy.deepcopy(self.p)
        apply_preset(self.p, "default")
        for key in ("drawing", "input_tables", "blocks", "blocks"):
            self.assertEqual(self.p[key], before[key])
        self.assertEqual(self.p["settings"]["LAYER_HOLES"], "HOLES")
        self.assertEqual(self.p["settings"]["TEXT_HEIGHT"], 3.5)

    def test_changed_label_and_reapply(self):
        key = create_preset(self.p, "設備用", self.p["settings"])
        apply_preset(self.p, key)
        self.p["settings"]["TEXT_HEIGHT"] = 9
        self.assertIn("変更あり", active_label(self.p))
        apply_preset(self.p, key)
        self.assertEqual(active_label(self.p), "設備用")

    def test_snapshots_do_not_alias_current_or_defaults(self):
        key = create_preset(self.p, "独立", self.p["settings"])
        self.p["settings"]["TEXT_HEIGHT"] = 99
        self.assertEqual(entries(self.p)[key]["values"]["TEXT_HEIGHT"], "5")
        catalog = entries(self.p)
        catalog["default"]["values"]["TEXT_HEIGHT"] = -1
        self.assertEqual(entries(self.p)["default"]["values"]["TEXT_HEIGHT"], 3.5)

    def test_rejects_duplicate_empty_and_invalid_values(self):
        for name, values in [
            ("デフォルト", {"X": 1}),
            (" ", {"X": 1}),
            ("x", {}),
            ("x", {"TEXT_HEIGHT": 0}),
            ("x", {"DIM_SCALE": "1/0"}),
            ("x", {"X": float("inf")}),
            ("x", {"row": 1}),
        ]:
            with self.subTest(name=name, values=values), self.assertRaises(ValueError):
                create_preset(self.p, name, values)
        self.assertEqual(self.p["settings_presets"], {})

    def test_malformed_library_does_not_load(self):
        for custom in (
            [],
            {"default": {"name": "bad", "values": {"X": 1}}},
            {"a": {"name": "a", "values": []}},
        ):
            p = dict(self.p, settings_presets=custom)
            self.assertTrue(validate_project(p))
            with self.assertRaises(ValueError):
                normalize_project(p)
        self.assertTrue(
            validate_project(dict(self.p, active_settings_preset="missing"))
        )

    def test_limit_and_arithmetic_size(self):
        for i in range(100):
            create_preset(self.p, f"設定{i}", {"TEXT_HEIGHT": "2*2"})
        self.assertFalse(validate_project(self.p))
        with self.assertRaises(ValueError):
            create_preset(self.p, "追加", {"X": 1})


if __name__ == "__main__":
    unittest.main()
