"""Behavioral coverage for diagnostics, formula samples and crash recovery files."""

import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from audit import audit_details, audit_project
from expression_sample import sample_value
from engine import compile_project, MacroError
from flow import execution_address, resolve
from sample_project import LEGACY_EXAMPLE as EXAMPLE
from workspace_state import WorkspaceState


def nested_project(value="1 / 0", condition="True"):
    project = copy.deepcopy(EXAMPLE)
    project["blocks"] = {"nested": [{"type": "CIRCLE", "x": "0", "y": "0", "r": value}]}
    project["presets"] = [
        {
            "name": "nested",
            "commands": [
                {
                    "type": "REPEAT",
                    "count": "2",
                    "commands": [
                        {
                            "type": "IF",
                            "condition": condition,
                            "commands": [{"type": "BLOCK", "name": "nested"}],
                        }
                    ],
                }
            ],
        }
    ]
    return project


class Diagnostics(unittest.TestCase):
    def test_runtime_error_resolves_deepest_shared_command(self):
        project = nested_project()
        with self.assertRaises(MacroError) as caught:
            compile_project(project, [1])
        location = caught.exception.location
        self.assertEqual(location["row"], 1)
        self.assertEqual(location["preset_index"], 0)
        self.assertEqual(
            execution_address(project, 0, location["command_path"]),
            ("blocks", "nested", 0),
        )
        records = audit_details(project)
        self.assertEqual(records[1]["address"], ("blocks", "nested", 0))
        self.assertEqual([r["message"] for r in records], audit_project(project))

    def test_inactive_expression_and_structural_errors_are_addressable(self):
        project = nested_project("1+", "False")
        self.assertEqual(audit_details(project)[0]["address"], ("blocks", "nested", 0))
        del project["blocks"]["nested"]
        record = audit_details(project)[0]
        self.assertEqual(resolve(project, record["address"])["type"], "BLOCK")
        self.assertEqual(record["preset_index"], 0)

    def test_global_error_has_row_but_no_stale_preset(self):
        project = nested_project("5")
        project["globals"] = {"BAD": "1 / @X"}
        project["input_tables"][0]["rows"][0]["X"] = "0"
        # Row 1 has X=0 and fails before preset execution.
        with self.assertRaises(MacroError) as caught:
            compile_project(project, [0])
        self.assertIsNone(caught.exception.location["preset_index"])


class FormulaSamples(unittest.TestCase):
    def test_settings_globals_locals_and_selected_row(self):
        project = copy.deepcopy(EXAMPLE)
        project["globals"] = {"HALF": "@OD / 2"}
        local = {"PAD": "global.HALF + settings.TEXT_HEIGHT"}
        result = sample_value(project, "local.PAD * 2", 1, local)
        expected = float(project["input_tables"][0]["rows"][1]["OD"]) + 2 * float(
            project["settings"]["TEXT_HEIGHT"]
        )
        self.assertEqual(result, expected)

    def test_unsupported_and_loop_expressions_do_not_execute(self):
        for expression in ('__import__("os")', "loop.index", "1 / 0"):
            with self.assertRaises(MacroError):
                sample_value(EXAMPLE, expression)


class RecoveryFiles(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.state = WorkspaceState(self.directory.name)

    def test_independent_drafts_survive_remove_and_restart(self):
        self.state.save_recovery("one", {"data": EXAMPLE, "name": "one"})
        self.state.save_recovery("two", {"data": EXAMPLE, "name": "two"})
        self.state.save_recovery("one", {"data": EXAMPLE, "name": "updated"})
        self.state.remove_recovery("two")
        reopened = WorkspaceState(self.directory.name)
        self.assertEqual([d["name"] for d in reopened.recoveries()], ["updated"])

    def test_failed_atomic_replace_keeps_previous_draft(self):
        self.state.save_recovery("one", {"data": EXAMPLE})
        previous = self.state.path("recovery").read_bytes()
        with patch("workspace_state.os.replace", side_effect=OSError("disk failure")):
            with self.assertRaises(OSError):
                self.state.save_recovery("two", {"data": EXAMPLE})
        self.assertEqual(self.state.path("recovery").read_bytes(), previous)
        self.assertEqual(list(self.state.directory.glob("*.tmp")), [])

    def test_corrupt_workspace_is_ignored(self):
        self.state.write("view", {"geometry": "1320x840+0+0"})
        self.state.path("view").write_text("{broken", encoding="utf-8")
        self.assertIsNone(self.state.read("view"))
        self.state.write("recovery", {"drafts": None})
        self.assertEqual(self.state.recoveries(), [])
        self.state.path("view").write_text(json.dumps([1, 2]), encoding="utf-8")
        self.assertIsNone(self.state.read("view"))


if __name__ == "__main__":
    unittest.main()
