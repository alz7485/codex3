"""Japanese project-wide variable names retain the old variable scope."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from project_model import normalize_project, valid_variable_name  # noqa: E402
from project_data import add_input_table  # noqa: E402
from engine import compile_project  # noqa: E402
from expression_sample import sample_value  # noqa: E402
from input_assist import reference_groups  # noqa: E402


def example():
    return {
        "version": 6, "rows": [{"X": 10}, {"X": 20}],
        "settings": {},
        "globals": {"参照行": "2", "LEGACY": "3"},
        "blocks": {},
        "presets": [{"name": "円", "commands": [
            {"type": "CIRCLE", "x": "変数.参照行", "y": "0", "r": "2"}
        ]}],
    }


class JapaneseVariablesTests(unittest.TestCase):
    def test_valid_japanese_names_and_invalid_special_characters(self):
        for name in ("参照行", "中心座標", "列番号_2", "LEGACY"):
            self.assertTrue(valid_variable_name(name), name)
        for name in ("変数", "値 の名前", "1行", "global", "__secret", "ａｂｃ"):
            self.assertFalse(valid_variable_name(name), name)

    def test_old_and_new_namespaces_have_same_value(self):
        p = normalize_project(example())
        self.assertEqual(sample_value(p, "変数.参照行", 0), 2)
        self.assertEqual(sample_value(p, "変数.LEGACY", 0), 3)
        self.assertEqual(sample_value(p, "global.LEGACY", 0), 3)
        self.assertEqual(sample_value(p, "variable.LEGACY", 0), 3)
        self.assertEqual(sample_value(p, "変数.参照行 + global.LEGACY", 0), 5)

    def test_japanese_variable_in_other_table_row_selector(self):
        p = normalize_project(example())
        base_id = p["active_table"]
        add_input_table(p, "座標表", [{"X": 100}, {"X": 200}])
        p["active_table"] = base_id
        p["blocks"][0]["commands"][0]["x"] = "[座標表]@X{変数.参照行}"
        self.assertEqual(compile_project(p, [0])[1][0]["coords"][0], 200)
        groups = dict(reference_groups(p))
        self.assertIn("変数.参照行", groups["変数"])
        self.assertNotIn("global.LEGACY", groups["変数"])


if __name__ == "__main__":
    unittest.main()
