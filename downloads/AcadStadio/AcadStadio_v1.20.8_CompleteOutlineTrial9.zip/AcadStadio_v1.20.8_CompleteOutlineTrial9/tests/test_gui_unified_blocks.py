"""Real Tk workflows for the unified drawing/reusable block collection."""

import copy
import json
import os
from pathlib import Path
import sys
from tkinter import ttk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from test_unified_blocks import call, circle, definition, legacy, modern, preset
from macro_editor import MacroEditor, edit_command


@unittest.skipUnless(sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available")
class UnifiedBlocksGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def reusable_project(self, unused=False):
        blocks = [definition("main", "作図する形", [call("helper")]), definition("helper", "呼び出す形", [circle()], draw=False)]
        if unused:
            blocks.append(definition("unused", "未使用の形", [circle("99")], draw=False))
        return modern(*blocks)

    def edit(self, index):
        return MacroEditor(self.root, self.app.data["blocks"][index], self.app.data["blocks"], self.app.refresh, self.app.data, self.app.selected_rows())

    def test_initial_project_has_one_drawing_collection_and_no_forwarding_layer(self):
        self.assertIsInstance(self.app.data["blocks"], list)
        self.assertNotIn("presets", self.app.data)
        self.assertEqual(len(self.app.block_list.get_children()), len(self.app.data["blocks"]))
        self.assertEqual(self.app.data["blocks"][0]["commands"][0]["type"], "CIRCLE")
        self.assertTrue(self.app.block_list.winfo_ismapped())

    def test_direct_form_and_default_project_have_no_local_variable_workflow(self):
        from tkinter import Listbox
        from macro_editor import TYPE_LABELS
        self.assertTrue(all("variables" not in b for b in self.app.data["blocks"]))
        editor = self.edit(1)
        self.assertFalse(any(isinstance(w, ttk.Notebook) for w in gui.descendants(editor.win)))
        def inspect():
            win = gui.top(self.root, "コマンドの設定")
            picker = next(w for w in gui.descendants(win) if isinstance(w, ttk.Combobox) and TYPE_LABELS["LINE"] in w.cget("values"))
            self.assertNotIn(TYPE_LABELS["SET"], picker.cget("values"))
            refs = next(w for w in gui.descendants(win) if isinstance(w, Listbox))
            self.assertFalse(any(str(v).startswith("local.") for v in refs.get(0, "end")))
            gui.button(win, "キャンセル").invoke()
        self.root.after(20, inspect)
        editor.list.add()
        editor.cancel()

    def test_new_block_cancel_does_not_create_an_empty_definition(self):
        before = copy.deepcopy(self.app.data)
        self.app.add_block()
        editor = gui.top(self.root, "ブロック編集")
        gui.button(editor, "キャンセル").invoke()
        self.assertEqual(self.app.data, before)
        self.assertFalse(self.app.has_unsaved_changes())

    def test_rename_uses_stable_ids_and_can_be_undone(self):
        self.app.replace_document(self.reusable_project())
        before = self.app.compile()[0]
        editor = self.edit(1)
        editor.name.set("名前を変えても同じ形")
        editor.save()
        self.assertEqual(self.app.data["blocks"][1]["name"], "名前を変えても同じ形")
        self.assertEqual(self.app.data["blocks"][1]["id"], "helper")
        self.assertEqual(self.app.data["blocks"][0]["commands"][0]["name"], "helper")
        self.assertEqual(self.app.compile()[0], before)
        self.app.undo_project()
        self.assertEqual(self.app.data["blocks"][1]["name"], "呼び出す形")

    def test_cancel_discards_new_reusable_definition_and_command_changes(self):
        self.app.replace_document(modern(definition("main", "形", [circle("1"), circle("2")])))
        before = copy.deepcopy(self.app.data)
        editor = self.edit(0)
        editor.list.tree.selection_set("0", "1")
        with patch("tkinter.simpledialog.askstring", return_value="まとめた形"):
            editor.list.group()
        self.assertEqual(len(editor.working_blocks), 2)
        editor.cancel()
        self.assertEqual(self.app.data, before)

    def test_group_commands_creates_a_call_only_block_in_the_same_collection(self):
        self.app.replace_document(modern(definition("main", "形", [circle("1"), circle("2")])))
        before = copy.deepcopy(self.app.data)
        editor = self.edit(0)
        editor.list.tree.selection_set("0", "1")
        with patch("tkinter.simpledialog.askstring", return_value="まとめた形"):
            editor.list.group()
        editor.save()
        self.assertEqual(len(self.app.data["blocks"]), 2)
        root, helper = self.app.data["blocks"]
        self.assertFalse(helper["draw"])
        self.assertEqual(root["commands"], [call(helper["id"])])
        self.assertEqual([i["coords"][0] for i in self.app.compile()[1]], [1, 2, 1, 2])
        self.assertNotIn("presets", self.app.data)
        self.app.undo_project()
        self.assertEqual(self.app.data, before)

    def test_used_block_cannot_be_deleted_and_unused_block_deletion_is_undoable(self):
        self.app.replace_document(self.reusable_project(unused=True))
        self.app.block_list.selection_set("1")
        self.app.del_block()
        self.assertEqual(len(self.app.data["blocks"]), 3)
        self.assertIn("使用中", self.messages[-1][0])
        self.app.block_list.selection_set("2")
        self.app.del_block()
        self.assertEqual([b["id"] for b in self.app.data["blocks"]], ["main", "helper"])
        self.app.undo_project()
        self.assertEqual(self.app.data["blocks"][2]["id"], "unused")

    def test_drawing_toggle_does_not_disable_explicit_calls(self):
        self.app.replace_document(self.reusable_project())
        self.app.block_list.selection_set("1")
        self.assertEqual(len(self.app.compile()[1]), 2)
        self.app.toggle_block_draw()
        self.assertTrue(self.app.data["blocks"][1]["draw"])
        self.assertEqual(len(self.app.compile()[1]), 4)
        self.app.toggle_block_draw()
        self.assertFalse(self.app.data["blocks"][1]["draw"])
        self.assertEqual(len(self.app.compile()[1]), 2)

    def test_reading_legacy_json_does_not_rewrite_it_until_save(self):
        path = Path(self.library_dir.name) / "legacy.json"
        old = legacy(preset("外形を描く", [call("円")]), blocks={"円": [circle()]})
        path.write_text(json.dumps(old, ensure_ascii=False), encoding="utf-8")
        original = path.read_bytes()
        self.assertTrue(self.app.open_project(path))
        self.assertEqual(path.read_bytes(), original)
        self.assertEqual(self.app.data["version"], 11)
        self.assertNotIn("presets", self.app.data)
        before = self.app.compile()[0]
        self.assertTrue(self.app.save())
        saved = json.loads(path.read_text(encoding="utf-8"))
        self.assertIsInstance(saved["blocks"], list)
        self.assertNotIn("presets", saved)
        self.assertEqual(self.app.compile()[0], before)

    def test_call_selector_displays_names_and_stores_the_selected_id(self):
        self.app.replace_document(self.reusable_project(unused=True))
        observed = []

        def interact():
            win = gui.top(self.root, "コマンドの設定")
            try:
                picker = next(w for w in gui.descendants(win) if isinstance(w, ttk.Combobox) and "呼び出す形" in w["values"])
                self.assertNotIn("helper", picker["values"])
                self.assertEqual(picker.get(), "呼び出す形")
                picker.set("未使用の形")
                picker.event_generate("<<ComboboxSelected>>")
                observed.append(picker.get())
                gui.button(win, "コマンドを確定").invoke()
            except Exception:
                win.destroy()
                raise

        self.root.after(20, interact)
        result = edit_command(self.root, call("helper"), self.app.data["blocks"], self.app.data)
        self.assertEqual(observed, ["未使用の形"])
        self.assertEqual(result["name"], "unused")


if __name__ == "__main__":
    unittest.main()
