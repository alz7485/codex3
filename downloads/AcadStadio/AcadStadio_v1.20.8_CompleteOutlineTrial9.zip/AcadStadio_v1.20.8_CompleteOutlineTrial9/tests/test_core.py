"""Behavioral regression suite, runnable with the Python standard library."""

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from engine import compile_project, evaluate, MacroError
from audit import audit_project
from project_model import normalize_project, validate_project
from project_safety import atomic_save, atomic_write_script, details
from sample_project import LEGACY_EXAMPLE as EXAMPLE
from table_io import read_csv, read_excel

ROOT = Path(__file__).resolve().parents[1]


def circle(x="@X", r="2", **extra):
    return dict({"type": "CIRCLE", "layer": "0", "x": x, "y": "0", "r": r}, **extra)


def project(commands=None, rows=None):
    return {
        "version": 6,
        "rows": rows if rows is not None else [{"X": 10, "TYPE": "A"}],
        "settings": {"TEXT_HEIGHT": "3.5"},
        "globals": {},
        "blocks": {},
        "presets": [
            {
                "name": "test",
                "enabled": True,
                "condition": "",
                "variables": {},
                "commands": commands or [],
            }
        ],
    }


class Expressions(unittest.TestCase):
    def test_explicit_namespaces(self):
        v = {
            "X": 99,
            "__row__": {"X": 1},
            "__global__": {"X": 2},
            "__local__": {"X": 3},
            "__settings__": {"X": 4},
        }
        self.assertEqual(evaluate("@X+global.X+local.X+settings.X", v), 10)

    def test_short_circuit(self):
        self.assertFalse(evaluate("False and 1/0", {}))
        self.assertTrue(evaluate("True or missing", {}))

    def test_quoted_references_are_literal(self):
        self.assertEqual(evaluate('"@X global.X"', {}), "@X global.X")

    def test_functions_and_comparison(self):
        self.assertAlmostEqual(evaluate("sin(radians(90))+sqrt(9)+max(1,2)", {}), 6)
        self.assertTrue(evaluate("1 < 2 <= 2 and not False", {}))

    def test_arbitrary_code_and_private_scopes_blocked(self):
        for expr in [
            '__import__("os")',
            "(1).__class__",
            "row.__class__",
            "__row__",
            "[1,2]",
            "[x for x in y]",
            "lambda:1",
            'open("x")',
            "(lambda:1)()",
        ]:
            with self.subTest(expr=expr), self.assertRaises(MacroError):
                evaluate(expr, {"__row__": {"X": 1}})

    def test_resource_bounds(self):
        for expr in [
            "2**1000000",
            '"a"*1000000000',
            "1e309",
            "2**99",
            "1/0",
            "sqrt(-1)",
        ]:
            with self.subTest(expr=expr), self.assertRaises(MacroError):
                evaluate(expr, {})

    def test_deep_and_long_expressions(self):
        for expr in ["1+" * 2000 + "1", "not " * 80 + "True"]:
            with self.assertRaises(MacroError):
                evaluate(expr, {})


class Compiler(unittest.TestCase):
    def test_working_demo_and_legacy(self):
        script, figures = compile_project(EXAMPLE, [0, 1, 2])
        self.assertEqual(len(figures), 27)
        self.assertEqual(audit_project(EXAMPLE), [])
        legacy = json.loads(
            (ROOT / "examples/legacy_v1_5.json").read_text(encoding="utf-8")
        )
        upgraded = normalize_project(legacy)
        self.assertEqual(upgraded["version"], 11)
        self.assertEqual(legacy["version"], 5)
        self.assertEqual(len(compile_project(upgraded, [0, 1, 2])[1]), 5)

    def test_if_else_and_command_condition(self):
        p = project(
            [
                {
                    "type": "IF",
                    "condition": '@TYPE == "A"',
                    "commands": [circle("1")],
                    "else": [circle("2")],
                },
                circle("3", condition="@X > 10"),
            ],
            rows=[{"X": 10, "TYPE": "A"}, {"X": 20, "TYPE": "B"}],
        )
        _, items = compile_project(p, [0, 1])
        self.assertEqual([i["coords"][0] for i in items], [1, 2, 3])

    def test_repeat_expressions_and_preview_scr_match(self):
        p = project(
            [
                {
                    "type": "REPEAT",
                    "count": "@X / 2",
                    "commands": [circle("loop.index * 10 + loop.number")],
                }
            ]
        )
        script, items = compile_project(p, [0])
        self.assertEqual(len(items), 5)
        self.assertEqual([i["coords"][0] for i in items], [1, 12, 23, 34, 45])
        lines = script.splitlines()
        at = [i for i, s in enumerate(lines) if s == "_.CIRCLE"]
        for i, figure in zip(at, items):
            self.assertEqual(
                tuple(map(float, lines[i + 2].split(","))), figure["coords"][:2]
            )
            self.assertEqual(float(lines[i + 3]), figure["coords"][2])

    def test_nested_loop_scope_restored(self):
        p = project(
            [
                {
                    "type": "REPEAT",
                    "count": "2",
                    "commands": [
                        {
                            "type": "REPEAT",
                            "count": "3",
                            "commands": [circle("loop.index")],
                        },
                        circle("100+loop.index"),
                    ],
                }
            ]
        )
        self.assertEqual(
            [i["coords"][0] for i in compile_project(p, [0])[1]],
            [0, 1, 2, 100, 0, 1, 2, 101],
        )

    def test_loop_scope_not_leaked(self):
        p = project(
            [{"type": "REPEAT", "count": "1", "commands": []}, circle("loop.index")]
        )
        with self.assertRaises(MacroError):
            compile_project(p, [0])

    def test_repeat_invalid_values(self):
        for count in ["-1", "1001", "1.5", "True", '"a"']:
            with self.subTest(count=count), self.assertRaises(MacroError):
                compile_project(
                    project([{"type": "REPEAT", "count": count, "commands": []}]), [0]
                )

    def test_zero_repeat_and_false_branch_do_not_evaluate(self):
        p = project(
            [
                {"type": "REPEAT", "count": "0", "commands": [circle("missing")]},
                circle("1/0", condition="False"),
            ]
        )
        self.assertEqual(compile_project(p, [0])[1], [])

    def test_total_expansion_limit(self):
        p = project(
            [
                {
                    "type": "REPEAT",
                    "count": "1000",
                    "commands": [
                        {
                            "type": "REPEAT",
                            "count": "1000",
                            "commands": [{"type": "SET", "name": "A", "value": "1"}],
                        }
                    ],
                }
            ]
        )
        with self.assertRaisesRegex(MacroError, "50000"):
            compile_project(p, [0])

    def test_figure_limit(self):
        p = project(
            [{"type": "REPEAT", "count": "1000", "commands": [circle()]}],
            rows=[{"X": 1}] * 21,
        )
        with self.assertRaisesRegex(MacroError, "20000"):
            compile_project(p, range(21))

    def test_runtime_depth_limit(self):
        p = project([{"type": "BLOCK", "name": "B0"}])
        for i in range(12):
            p["blocks"]["B" + str(i)] = (
                [{"type": "BLOCK", "name": "B" + str(i + 1)}] if i < 11 else [circle()]
            )
        p["presets"][0]["commands"] = [
            {"type": "REPEAT", "count": "1", "commands": p["presets"][0]["commands"]}
        ]
        with self.assertRaisesRegex(MacroError, "12"):
            compile_project(p, [0])

    def test_set_and_local_scopes_isolated(self):
        p = project(
            [{"type": "SET", "name": "X", "value": "99"}, circle("local.X+@X")],
            rows=[{"X": 1}, {"X": 2}],
        )
        p["presets"].append(
            {
                "name": "second",
                "variables": {"X": "7"},
                "commands": [circle("local.X+@X")],
            }
        )
        self.assertEqual(
            [i["coords"][0] for i in compile_project(p, [0, 1])[1]], [100, 8, 101, 9]
        )
        self.assertEqual(p["rows"], [{"X": 1}, {"X": 2}])

    def test_global_and_local_definition_order(self):
        p = project([circle("global.B+local.A")])
        p["globals"] = {"A": "@X", "B": "global.A*2"}
        p["presets"][0]["variables"] = {"A": "global.A+1"}
        self.assertEqual(compile_project(p, [0])[1][0]["coords"][0], 31)

    def test_shared_nested_blocks_and_metadata(self):
        p = project([{"type": "BLOCK", "name": "a"}])
        p["blocks"] = {"a": [{"type": "BLOCK", "name": "b"}], "b": [circle()]}
        script, items = compile_project(p, [0])
        self.assertEqual(items[0]["coords"][0], 10)
        self.assertEqual(items[0]["command_index"], 0)
        self.assertIn("/a/", items[0]["command_path"])

    def test_layer_setting_and_text_expression(self):
        p = project(
            [
                {
                    "type": "TEXT",
                    "layer": "settings.LAYER",
                    "x": 0,
                    "y": 0,
                    "text": "=settings.TITLE",
                    "angle": "30",
                }
            ]
        )
        p["settings"].update(LAYER="LABEL", TITLE="部品A")
        script, items = compile_project(p, [0])
        self.assertIn("部品A", script)
        self.assertEqual(items[0]["angle"], 30)
        self.assertEqual(items[0]["layer"], "LABEL")

    def test_all_geometry_uses_resolved_coordinates(self):
        commands = [
            {"type": "LINE", "x1": 0, "y1": 0, "x2": 10, "y2": 20},
            {"type": "RECTANGLE", "x1": 0, "y1": 0, "x2": 10, "y2": 20},
            {
                "type": "DIMLINEAR",
                "x1": 0,
                "y1": 0,
                "x2": 10,
                "y2": 0,
                "x3": 5,
                "y3": 30,
            },
        ]
        script, items = compile_project(project(commands), [0])
        self.assertEqual([len(i["coords"]) for i in items], [4, 4, 6])
        self.assertIn("5,30", script)
        self.assertTrue(script.endswith("\n"))
        self.assertNotIn("@", script)

    def test_invalid_geometry_and_injection(self):
        for command in [
            circle(r="0"),
            circle(r="-1"),
            circle(x='"abc"'),
            circle(layer="A\n_.ERASE"),
            {"type": "TEXT", "x": 0, "y": 0, "text": "bad\n_.ERASE"},
            circle(x="1e13"),
        ]:
            with self.subTest(command=command), self.assertRaises(MacroError):
                compile_project(project([command]), [0])

    def test_degenerate_geometry_is_rejected(self):
        for command in [
            {"type": "LINE", "x1": 0, "y1": 0, "x2": 0, "y2": 0},
            {"type": "RECTANGLE", "x1": 0, "y1": 0, "x2": 0, "y2": 10},
            {"type": "DIMLINEAR", "x1": 0, "y1": 0, "x2": 0, "y2": 0, "x3": 2, "y3": 3},
        ]:
            with self.assertRaises(MacroError):
                compile_project(project([command]), [0])

    def test_zero_layer_setting_uses_autocad_zero_layer(self):
        p = project([circle(layer="settings.LAYER")])
        p["settings"]["LAYER"] = "0"
        self.assertEqual(compile_project(p, [0])[1][0]["layer"], "0")

    def test_invalid_row_indices(self):
        for index in [-1, 1, True, 1.1]:
            with self.assertRaises(MacroError):
                compile_project(project(), [index])

    def test_missing_reference_message_has_location(self):
        with self.assertRaisesRegex(MacroError, "1行目 / test / コマンド 1"):
            compile_project(project([circle("missing")]), [0])


class Audit(unittest.TestCase):
    def test_inactive_nested_missing_block_detected(self):
        p = project(
            [
                {
                    "type": "IF",
                    "condition": "False",
                    "commands": [{"type": "BLOCK", "name": "missing"}],
                }
            ]
        )
        self.assertTrue(audit_project(p))

    def test_cycles_in_unused_nested_blocks(self):
        p = project()
        p["blocks"] = {
            "a": [
                {
                    "type": "REPEAT",
                    "count": "0",
                    "commands": [{"type": "BLOCK", "name": "b"}],
                }
            ],
            "b": [{"type": "BLOCK", "name": "a"}],
        }
        self.assertTrue(any("循環" in i for i in audit_project(p)))

    def test_inactive_bad_expression_detected(self):
        p = project([circle('__import__("os")', condition="False")])
        self.assertTrue(audit_project(p))
        p = project([circle("1+", condition="False")])
        self.assertTrue(audit_project(p))

    def test_malformed_documents_and_names(self):
        for p in [
            None,
            [],
            {},
            dict(project(), rows=[[]]),
            dict(project(), blocks=[]),
            dict(project(), settings={"__row__": "bad"}),
            dict(project(), rows=[{"loop": "bad"}]),
            dict(project(), version=99),
            project([{"type": "BLOCK", "name": {}}]),
        ]:
            with self.subTest(project=p):
                self.assertTrue(validate_project(p))

    def test_unreachable_reference_value_is_documented(self):
        p = project([circle("missing", condition="False")])
        self.assertEqual(audit_project(p), [])


class Persistence(unittest.TestCase):
    def test_roundtrip_diff_and_rotation(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "a.json"
            p = copy.deepcopy(EXAMPLE)
            for i in range(8):
                p["globals"]["SCALE"] = str(i + 1)
                atomic_save(target, p)
            self.assertEqual(json.loads(target.read_text(encoding="utf-8")), p)
            backups = list((Path(folder) / "a_backups").glob("*.json"))
            self.assertEqual(len(backups), 5)
            self.assertEqual(
                sorted(
                    int(json.loads(x.read_text(encoding="utf-8"))["globals"]["SCALE"])
                    for x in backups
                ),
                [3, 4, 5, 6, 7],
            )
            self.assertTrue(details(EXAMPLE, p))
            self.assertFalse(list(Path(folder).glob("*.tmp")))

    def test_atomic_replace_failure_preserves_original(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "a.json"
            atomic_save(target, EXAMPLE)
            original = target.read_bytes()
            with patch("project_safety.os.replace", side_effect=OSError("locked")):
                with self.assertRaises(OSError):
                    atomic_save(target, project())
            self.assertEqual(target.read_bytes(), original)
            self.assertFalse(list(Path(folder).glob(".*.tmp")))

    def test_script_encoding_failure_preserves_target(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "a.scr"
            target.write_bytes(b"original")
            with self.assertRaises(UnicodeEncodeError):
                atomic_write_script(target, "emoji: \U0001f600\n")
            self.assertEqual(target.read_bytes(), b"original")
            atomic_write_script(target, "_.CIRCLE\n0,0\n2\n")
            self.assertEqual(target.read_bytes(), b"_.CIRCLE\r\n0,0\r\n2\r\n")

    def test_backup_failure_prevents_replace(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "a.json"
            atomic_save(target, EXAMPLE)
            original = target.read_bytes()
            with patch("shutil.copy2", side_effect=OSError("disk full")):
                with self.assertRaises(OSError):
                    atomic_save(target, project())
            self.assertEqual(target.read_bytes(), original)


class InputTables(unittest.TestCase):
    def test_csv_encodings(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "a.csv"
            for encoding in ["utf-8-sig", "cp932"]:
                target.write_bytes("TYPE,X\r\n部品,10\r\n".encode(encoding))
                self.assertEqual(read_csv(target), [{"TYPE": "部品", "X": "10"}])

    def test_csv_invalid_header_and_row_length(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "a.csv"
            for value in ["X,X\n1,2", "X,\n1,2", "X,Y\n1,2,3", "日本語,X\n1,2", "X\n"]:
                target.write_text(value, encoding="utf-8")
                with self.subTest(value=value), self.assertRaises(ValueError):
                    read_csv(target)

    def test_excel_read_and_no_cache_formula(self):
        try:
            from openpyxl import Workbook
        except ImportError:
            self.skipTest("openpyxl not installed")
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "a.xlsx"
            wb = Workbook()
            ws = wb.active
            ws.title = "寸法"
            ws.append(["X", "Y"])
            ws.append([1, 2])
            ws.append([None, None])
            wb.save(target)
            wb.close()
            self.assertEqual(read_excel(target, "寸法"), [{"X": 1, "Y": 2}])
            wb = Workbook()
            ws = wb.active
            ws.append(["X"])
            ws.append(["=1+1"])
            wb.save(target)
            wb.close()
            with self.assertRaisesRegex(ValueError, "計算結果"):
                read_excel(target, "Sheet")


if __name__ == "__main__":
    unittest.main(verbosity=2)
