"""Unified-block tree workflows, tested with actual Tk widgets."""

import copy
import os
from pathlib import Path
import sys
import tkinter as tk
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from project_model import normalize_project
from project_navigator import ProjectNavigator


def circle(radius="2"):
    return {"type": "CIRCLE", "x": "0", "y": "0", "r": radius}


def block(identity, commands, *, draw=True):
    return {
        "id": identity,
        "name": identity,
        "draw": draw,
        "condition": "",
        "variables": {},
        "commands": commands,
    }


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class UnifiedNavigatorGui(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.errors = []
        self.root.report_callback_exception = lambda typ, value, tb: self.errors.append(
            value
        )
        self.project = normalize_project(
            {
                "version": 11,
                "rows": [{"X": "0"}],
                "settings": {},
                "globals": {},
                "blocks": [
                    block(
                        "outer",
                        [
                            {
                                "type": "IF",
                                "condition": "True",
                                "commands": [circle()],
                                "else": [],
                            },
                            circle("3"),
                        ],
                    ),
                    block("shared", [{"type": "BLOCK", "name": "outer"}], draw=False),
                    block("last", [{"type": "BLOCK", "name": "shared"}]),
                ],
            }
        )
        self.messages = []
        self.patches = [
            patch(
                "project_navigator.messagebox.showerror",
                side_effect=lambda *a, **kw: self.messages.append(a),
            ),
            patch(
                "project_navigator.messagebox.showwarning",
                side_effect=lambda *a, **kw: self.messages.append(a),
            ),
            patch("project_navigator.messagebox.showinfo", return_value=None),
            patch("project_navigator.messagebox.askyesno", return_value=True),
        ]
        for item in self.patches:
            item.start()
        self.changed = Mock()
        self.edited = Mock()
        self.nav = ProjectNavigator(
            self.root, self.project, self.edited, Mock(), self.changed
        )
        self.root.update()

    def tearDown(self):
        self.root.destroy()
        for item in reversed(self.patches):
            item.stop()
        self.assertEqual(self.errors, [])

    def test_blocks_are_direct_children_of_project(self):
        root = self.nav.tree.get_children()[0]
        block_nodes = [
            node for node in self.nav.tree.get_children(root) if node in self.nav.nodes
        ]
        self.assertEqual(
            [self.nav.nodes[node] for node in block_nodes],
            [("block", 0), ("block", 1), ("block", 2)],
        )
        self.assertNotIn("presets", self.project)
        self.nav.choose_block(1)
        self.nav.open_selected()
        self.edited.assert_called_once_with(1)

    def test_nested_duplicate_and_undo_restore_commands(self):
        owner = ("block", 0, (0, "commands"))
        self.nav.choose(owner, 0)
        self.nav.duplicate()
        self.assertEqual(len(self.nav.commands(owner)), 2)
        self.nav.undo()
        self.assertEqual(len(self.nav.commands(owner)), 1)
        self.nav.redo()
        self.assertEqual(len(self.nav.commands(owner)), 2)

    def test_group_adds_call_only_block_and_stable_reference(self):
        self.nav.choose(("block", 0), 1)
        with patch("project_navigator.simpledialog.askstring", return_value="Group"):
            self.nav.group()
        grouped = self.project["blocks"][-1]
        self.assertFalse(grouped["draw"])
        self.assertEqual(grouped["name"], "Group")
        self.assertEqual(
            self.project["blocks"][0]["commands"][1],
            {"type": "BLOCK", "name": grouped["id"]},
        )
        self.nav.undo()
        self.assertEqual(len(self.project["blocks"]), 3)
        self.assertEqual(self.project["blocks"][0]["commands"][1], circle("3"))

    def test_stale_cut_content_is_rejected_without_losing_source(self):
        self.nav.choose(("block", 0), 1)
        self.nav.cut_commands()
        self.project["blocks"][0]["commands"].append(circle("9"))
        self.nav.choose(("block", 1), 0)
        before = copy.deepcopy(self.project)
        self.nav.paste_commands()
        self.assertEqual(self.project, before)
        self.assertIn("切り取り元", self.messages[-1][0])

    def test_stale_cut_block_identity_is_rejected_after_reorder(self):
        self.project["blocks"][1]["commands"] = copy.deepcopy(
            self.project["blocks"][0]["commands"]
        )
        self.nav.choose(("block", 0), 1)
        self.nav.cut_commands()
        self.project["blocks"][0], self.project["blocks"][1] = (
            self.project["blocks"][1],
            self.project["blocks"][0],
        )
        self.nav.choose(("block", 2), 0)
        before = copy.deepcopy(self.project)
        self.nav.paste_commands()
        self.assertEqual(self.project, before)
        self.assertIn("切り取り元", self.messages[-1][0])

    def test_cut_into_own_descendant_is_rejected(self):
        self.nav.choose(("block", 0), 0)
        self.nav.cut_commands()
        self.nav.choose(("block", 0, (0, "commands")), 0)
        before = copy.deepcopy(self.project)
        self.nav.paste_commands()
        self.assertEqual(self.project, before)
        self.assertIn("貼り付け先", self.messages[-1][0])

    def test_paste_transitive_cycle_is_transactionally_rejected(self):
        self.nav.choose(("block", 2), 0)
        self.nav.copy_commands()
        self.nav.choose(("block", 0), 1)
        before = copy.deepcopy(self.project)
        self.nav.paste_commands()
        self.assertEqual(self.project, before)
        self.assertTrue(any("循環" in str(message) for message in self.messages))

    def test_move_block_preserves_reference_ids(self):
        self.nav.choose_block(0)
        self.nav.move(1)
        self.assertEqual(self.project["blocks"][0]["id"], "shared")
        self.assertEqual(self.project["blocks"][0]["commands"][0]["name"], "outer")
        self.assertEqual(self.project["blocks"][1]["id"], "outer")

    def test_delete_used_block_keeps_whole_project(self):
        before = copy.deepcopy(self.project)
        self.nav.choose_block(0)
        self.nav.delete()
        self.assertEqual(self.project, before)
        self.assertIn("使用中", self.messages[-1][0])

    def test_root_duplicate_gets_unique_name_and_id(self):
        self.nav.choose_block(0)
        self.nav.duplicate()
        original, clone = self.project["blocks"][:2]
        self.assertNotEqual(original["id"], clone["id"])
        self.assertNotEqual(original["name"], clone["name"])
        self.assertEqual(original["commands"], clone["commands"])

    def test_invalid_direct_edit_never_changes_original(self):
        before = copy.deepcopy(self.project)
        self.nav.choose(("block", 0), 1)
        with patch(
            "project_navigator.edit_command",
            return_value={"type": "BLOCK", "name": "missing"},
        ):
            self.nav.edit()
        self.assertEqual(self.project, before)
        self.assertTrue(self.messages)

    def test_cut_into_shifted_sibling_branch_selects_real_destination(self):
        self.project["blocks"][0]["commands"].append(
            {"type": "IF", "condition": "True", "commands": [circle("4")]}
        )
        self.nav.choose(("block", 0), 1)
        self.nav.cut_commands()
        self.nav.choose(("block", 0, (2, "commands")), 0)
        self.nav.paste_commands()
        owner = ("block", 0, (1, "commands"))
        self.assertEqual(self.nav.commands(owner), [circle("4"), circle("3")])
        self.assertEqual(self.nav.selected(), [("command", owner, 1)])


if __name__ == "__main__":
    unittest.main()
