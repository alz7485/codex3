"""Folder grouping must not change block ownership, command addresses or execution."""

import copy
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from engine import compile_project
import test_gui_unified_navigator as unified_gui

circle = unified_gui.circle


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class FolderNavigatorGui(unittest.TestCase):
    setUp = unified_gui.UnifiedNavigatorGui.setUp
    tearDown = unified_gui.UnifiedNavigatorGui.tearDown

    def grouped(self):
        self.project["block_folders"] = [
            {"id": "outlines", "name": "外形", "parent_id": ""},
            {"id": "holes", "name": "穴", "parent_id": "outlines"},
            {"id": "labels", "name": "文字", "parent_id": ""},
        ]
        self.project["blocks"][0]["folder_id"] = "holes"
        self.project["blocks"][1]["folder_id"] = "labels"
        self.nav.refresh()
        self.root.update()

    def node(self, descriptor):
        return next(node for node, item in self.nav.nodes.items() if item == descriptor)

    def select(self, descriptor):
        self.nav.tree.selection_set(self.node(descriptor))

    def test_nested_folders_and_unfiled_keep_global_ordinals_and_execution(self):
        before = compile_project(self.project, [0])
        self.grouped()
        outer = self.node(("folder", "outlines"))
        holes = self.node(("folder", "holes"))
        labels = self.node(("folder", "labels"))
        unfiled = self.node(("folder", ""))
        self.assertEqual(self.nav.tree.parent(holes), outer)
        self.assertEqual(self.nav.tree.parent(self.node(("block", 0))), holes)
        self.assertEqual(self.nav.tree.parent(self.node(("block", 1))), labels)
        self.assertEqual(self.nav.tree.parent(self.node(("block", 2))), unfiled)
        self.assertTrue(self.nav.tree.item(self.node(("block", 0)), "text").startswith("01."))
        self.assertTrue(self.nav.tree.item(self.node(("block", 2)), "text").startswith("03."))
        self.assertEqual(self.nav.tree.item(outer, "values"), ("フォルダ", "1ブロック（子を含む）"))
        self.assertEqual(compile_project(self.project, [0]), before)

    def test_folder_selection_cannot_edit_delete_duplicate_toggle_or_reorder_blocks(self):
        self.grouped()
        before = copy.deepcopy(self.project)
        self.select(("folder", "holes"))
        self.nav.add()
        self.nav.delete()
        self.nav.duplicate()
        self.nav.toggle_draw()
        self.nav.move(1)
        self.assertIsNone(self.nav.command_selection())
        self.assertEqual(self.project, before)
        self.changed.assert_not_called()
        self.edited.assert_not_called()

    def test_folder_activation_toggles_once_and_never_opens_block_editor(self):
        self.grouped()
        self.select(("folder", "holes"))
        node = self.node(("folder", "holes"))
        opened = bool(self.nav.tree.item(node, "open"))
        self.assertEqual(self.nav.activate(), "break")
        self.assertEqual(bool(self.nav.tree.item(node, "open")), not opened)
        self.nav.activate()
        self.assertEqual(bool(self.nav.tree.item(node, "open")), opened)
        self.edited.assert_not_called()

    def test_folder_rename_preserves_collapse_and_selection_by_stable_id(self):
        self.grouped()
        self.select(("folder", "holes"))
        self.nav.tree.item(self.node(("folder", "holes")), open=False)
        self.project["block_folders"][1]["name"] = "等配穴"
        self.nav.refresh()
        node = self.node(("folder", "holes"))
        self.assertEqual(self.nav.tree.item(node, "text"), "等配穴")
        self.assertFalse(self.nav.tree.item(node, "open"))
        self.assertEqual(self.nav.selected(), [("folder", "holes")])

    def test_nested_command_remains_editable_at_native_address(self):
        self.grouped()
        owner = ("block", 0, (0, "commands"))
        self.nav.choose(owner, 0)
        self.assertEqual(self.nav.selected(), [("command", owner, 0)])
        with patch("project_navigator.edit_command", return_value=circle("7")) as editor:
            self.nav.edit()
        self.assertEqual(editor.call_args.kwargs["folder_id"], "holes")
        self.assertEqual(self.nav.commands(owner), [circle("7")])
        self.assertEqual(self.project["blocks"][0]["folder_id"], "holes")
        self.assertEqual(self.nav.selected(), [("command", owner, 0)])
        self.nav.undo()
        self.assertEqual(self.nav.commands(owner), [circle()])

    def test_external_reorder_preserves_selected_block_and_expansion_by_identity(self):
        self.grouped()
        self.nav.choose_block(0)
        self.nav.tree.item(self.node(("block", 0)), open=True)
        value = self.project["blocks"].pop(0)
        self.project["blocks"].append(value)
        self.nav.refresh()
        self.assertEqual(self.nav.selected(), [("block", 2)])
        self.assertTrue(self.nav.tree.item(self.node(("block", 2)), "open"))
        self.assertEqual(self.nav.tree.parent(self.node(("block", 2))), self.node(("folder", "holes")))

    def test_new_group_inherits_owning_folder_and_undo_keeps_folder_metadata(self):
        self.grouped()
        folders = copy.deepcopy(self.project["block_folders"])
        self.nav.choose(("block", 0), 1)
        with patch("project_navigator.simpledialog.askstring", return_value="共通の円"):
            self.nav.group()
        grouped = self.project["blocks"][-1]
        self.assertEqual(grouped["folder_id"], "holes")
        self.assertFalse(grouped["draw"])
        self.assertEqual(self.nav.tree.parent(self.node(("block", 3))), self.node(("folder", "holes")))
        self.nav.undo()
        self.assertEqual(len(self.project["blocks"]), 3)
        self.assertEqual(self.project["block_folders"], folders)

    def test_duplicate_keeps_folder_and_stable_call_targets(self):
        self.grouped()
        self.nav.choose_block(1)
        self.nav.duplicate()
        original, duplicate = self.project["blocks"][1:3]
        self.assertEqual(duplicate["folder_id"], "labels")
        self.assertNotEqual(original["id"], duplicate["id"])
        self.assertEqual(duplicate["commands"], [{"type": "BLOCK", "name": "outer"}])
        self.assertEqual(self.nav.tree.parent(self.node(("block", 2))), self.node(("folder", "labels")))

    def test_drag_between_blocks_changes_order_only_and_preserves_membership(self):
        self.grouped()
        source = self.project["blocks"][0]["id"]
        self.nav.drag_item = ("block", 0)
        with patch.object(self.nav.tree, "identify_row", return_value=self.node(("block", 2))):
            self.nav.drag_end(SimpleNamespace(y=0))
        self.assertEqual(self.project["blocks"][2]["id"], source)
        self.assertEqual(self.project["blocks"][2]["folder_id"], "holes")
        self.assertEqual(self.nav.selected(), [("block", 2)])
        self.assertEqual(self.nav.tree.parent(self.node(("block", 2))), self.node(("folder", "holes")))

    def test_drag_to_or_from_folder_never_moves_or_deletes_blocks(self):
        self.grouped()
        before = copy.deepcopy(self.project)
        for source, target in [(("block", 0), ("folder", "labels")), (("folder", "holes"), ("block", 1))]:
            with self.subTest(source=source):
                self.nav.drag_item = source
                with patch.object(self.nav.tree, "identify_row", return_value=self.node(target)):
                    self.nav.drag_end(SimpleNamespace(y=0))
                self.assertEqual(self.project, before)

    def test_add_command_passes_folder_context_to_nested_editor(self):
        self.grouped()
        owner = ("block", 0, (0, "commands"))
        self.nav.choose(owner, 0)
        with patch("project_navigator.edit_command", return_value=circle("9")) as editor:
            self.nav.add()
        self.assertEqual(editor.call_args.kwargs["folder_id"], "holes")
        self.assertEqual(self.nav.commands(owner), [circle(), circle("9")])
        self.assertEqual(self.project["blocks"][0]["folder_id"], "holes")

    def test_deep_valid_folder_chain_renders_and_refreshes_without_python_recursion(self):
        count = 1500
        self.project["block_folders"] = [
            {"id": f"f{index}", "name": "階層", "parent_id": f"f{index - 1}" if index else ""}
            for index in range(count)
        ]
        self.project["blocks"][0]["folder_id"] = f"f{count - 1}"
        self.nav.refresh()
        self.nav.choose_block(0)
        self.nav.refresh()
        self.assertEqual(self.nav.selected(), [("block", 0)])
        node = self.node(("block", 0))
        for index in reversed(range(count)):
            node = self.nav.tree.parent(node)
            self.assertEqual(self.nav.nodes[node], ("folder", f"f{index}"))


if __name__ == "__main__":
    unittest.main()
