"""Pure checks for the optional guided input, without requiring a desktop."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from input_assist import (  # noqa: E402
    comparison_expression, parse_simple_comparison, reference_groups,
    selected_table_reference, table_columns,
)
from engine import parse_expression  # noqa: E402


class InputAssistTests(unittest.TestCase):
    def test_text_value_is_quoted_and_escaped(self):
        value = comparison_expression("@TYPE", "==", 'A "special"', "文字")
        self.assertEqual(value, '@TYPE == "A \\"special\\""')
        parse_expression(value)

    def test_number_and_expression_are_not_quoted(self):
        self.assertEqual(
            comparison_expression("@OD", ">=", "settings.MIN_SIZE * 2", "数値・計算式"),
            "@OD >= settings.MIN_SIZE * 2",
        )

    def test_invalid_input_does_not_build_condition(self):
        with self.assertRaises(ValueError):
            comparison_expression("@X", "==", "", "文字")
        with self.assertRaises(ValueError):
            comparison_expression("@X", "=", "3", "数値・計算式")

    def test_simple_expression_is_reloaded_without_losing_type(self):
        self.assertEqual(
            parse_simple_comparison('@TYPE == "A"'),
            ("@TYPE", "==", "A", "文字"),
        )
        self.assertEqual(
            parse_simple_comparison("@OD >= settings.MIN_SIZE * 2"),
            ("@OD", ">=", "settings.MIN_SIZE * 2", "数値・計算式"),
        )
        self.assertEqual(
            parse_simple_comparison('[配管座標表]@X{@ROW} > 10'),
            ('[配管座標表]@X{@ROW}', ">", "10", "数値・計算式"),
        )
        self.assertIsNone(parse_simple_comparison('@TYPE == "A" and @OD > 3'))

    def test_available_references_are_grouped_and_deduplicated(self):
        project = {
            "input_tables": [{"id": "test", "name": "test", "rows": [{"X": "1", "OD": "2"}, {"X": "3"}]}],
            "settings": {"TEXT_HEIGHT": "3"},
            "globals": {"OFFSET": "5"},
        }
        groups = dict(reference_groups(project, ["helper", "helper"]))
        self.assertIn("@X", groups["入力表の列"])
        self.assertEqual(groups["入力表の列"].count("@X"), 1)
        self.assertNotIn("ブロック内の変数", groups)
        self.assertIn("変数.OFFSET", groups["変数"])
        self.assertIn("loop.index", groups["繰り返し"])

    def test_table_header_cell_and_variable_row_generate_distinct_references(self):
        self.assertEqual(
            selected_table_reference("配管座標表", "X"), "[配管座標表]@X"
        )
        self.assertEqual(
            selected_table_reference("配管座標表", "X", "fixed", 2),
            "[配管座標表]@X{2}",
        )
        self.assertEqual(
            selected_table_reference("配管座標表", "X", "variable", variable="参照行"),
            "[配管座標表]@X{変数.参照行}",
        )
        for mode, row, variable in (
            ("current", None, None), ("fixed", 2, None), ("variable", None, "参照行")
        ):
            parse_expression(selected_table_reference("配管座標表", "X", mode, row, variable))

    def test_table_reference_escape_and_missing_selection(self):
        self.assertEqual(
            selected_table_reference("配管]図\\面", "OD", "fixed", 10),
            r"[配管\]図\\面]@OD{10}",
        )
        for args in (
            ("配管", ""), ("配管", "OD", "fixed"),
            ("配管", "OD", "fixed", 0),
            ("配管", "OD", "variable"),
            ("配管", "Y 2"),
        ):
            with self.subTest(args=args), self.assertRaises(ValueError):
                selected_table_reference(*args)

    def test_table_columns_union_keeps_late_and_sparse_columns(self):
        self.assertEqual(
            table_columns({"rows": [{"X": "1"}, {"X": "2", "Y": "3"}, {"OD": "4"}]}),
            ["X", "Y", "OD"],
        )


if __name__ == "__main__":
    unittest.main()
