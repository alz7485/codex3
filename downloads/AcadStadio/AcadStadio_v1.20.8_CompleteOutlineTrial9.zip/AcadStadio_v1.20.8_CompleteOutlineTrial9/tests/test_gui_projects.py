"""Real sidebar navigation, disk persistence and safe document switching."""

import copy
import json
import os
from pathlib import Path
import sys
import unittest
from tkinter import ttk
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from project_library import ProjectLibrary, canonical
from sample_project import EXAMPLE


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class ProjectGui(unittest.TestCase):
    def setUp(self):
        gui.Gui.setUp(self)
        self.app.show_project_list()
        self.root.update()

    tearDown = gui.Gui.tearDown

    def file(self, name, height="9"):
        folder = self.app.project_library.ensure_directory()
        path = folder / name
        data = copy.deepcopy(EXAMPLE)
        data["settings"]["TEXT_HEIGHT"] = height
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        self.app.project_sidebar.refresh(force=True)
        self.root.update()
        return path

    def select(self, path):
        tree = self.app.project_sidebar.tree
        tree.selection_set(canonical(path))
        self.app.project_sidebar.open_selected()
        self.root.update()

    def test_single_click_opens_saved_json(self):
        path = self.file("設備A.json")
        sidebar = self.app.project_sidebar
        sidebar.tree.see(canonical(path))
        self.root.update()
        x, y, w, h = sidebar.tree.bbox(canonical(path))
        sidebar.tree.event_generate("<ButtonPress-1>", x=x + 20, y=y + h // 2)
        sidebar.tree.event_generate("<ButtonRelease-1>", x=x + 20, y=y + h // 2)
        self.root.update()
        self.assertEqual(self.app.path, str(path))
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], "9")
        self.assertEqual(self.messages, [])

    def test_cancel_switch_keeps_unsaved_changes_and_active_marker(self):
        first = self.file("一つ目.json")
        second = self.file("二つ目.json")
        self.select(first)
        self.app.data["settings"]["TEXT_HEIGHT"] = "7"
        self.app.refresh()
        with patch("tkinter.messagebox.askyesnocancel", return_value=None):
            self.select(second)
        self.assertEqual(self.app.path, str(first))
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], "7")
        self.assertEqual(self.app.project_sidebar.tree.selection(), (str(first),))
        self.assertTrue(self.app.has_unsaved_changes())

    def test_save_before_switch_preserves_project(self):
        first = self.file("first.json")
        second = self.file("second.json")
        self.select(first)
        self.app.data["settings"]["TEXT_HEIGHT"] = "12"
        self.app.refresh()
        with patch("tkinter.messagebox.askyesnocancel", return_value=True):
            self.select(second)
        self.assertEqual(json.loads(first.read_text())["settings"]["TEXT_HEIGHT"], "12")
        self.assertEqual(self.app.path, str(second))

    def test_invalid_json_never_discards_work(self):
        bad = self.file("broken.json")
        bad.write_text("{broken")
        self.app.data["settings"]["TEXT_HEIGHT"] = "12"
        before = copy.deepcopy(self.app.data)
        with patch("tkinter.messagebox.askyesnocancel") as prompt:
            self.select(bad)
        prompt.assert_not_called()
        self.assertEqual(self.app.data, before)
        self.assertIsNone(self.app.path)
        self.assertTrue(self.messages)

    def test_search_does_not_change_current_document(self):
        first = self.file("設備.json")
        second = self.file("配管.json")
        self.select(first)
        sidebar = self.app.project_sidebar
        sidebar.query.set("配管")
        self.assertEqual(sidebar.tree.get_children(), (str(second),))
        self.assertEqual(self.app.path, str(first))
        sidebar.query.set("")
        self.assertIn(str(first), sidebar.tree.get_children())

    def test_new_save_defaults_to_library_folder_and_updates_list(self):
        sidebar = self.app.project_sidebar
        gui.button(sidebar, "＋ 新規").invoke()
        path = self.app.project_library.directory / "新規.json"
        with patch(
            "tkinter.filedialog.asksaveasfilename", return_value=str(path)
        ) as dialog:
            gui.button(sidebar, "保存").invoke()
        self.assertEqual(dialog.call_args.kwargs["initialdir"], str(path.parent))
        self.assertTrue(path.is_file())
        self.assertIn(str(path), sidebar.tree.get_children())
        self.assertFalse(self.app.has_unsaved_changes())
        self.assertIn(
            str(path), ProjectLibrary(self.app.project_library.state_path).recent
        )

    def test_folder_change_and_external_open_survive_restart(self):
        folder = Path(self.library_dir.name) / "選択先"
        folder.mkdir()
        before = copy.deepcopy(self.app.data)
        with patch("tkinter.filedialog.askdirectory", return_value=str(folder)):
            gui.button(self.app.project_sidebar, "フォルダー変更").invoke()
        self.assertEqual(self.app.data, before)
        path = Path(self.library_dir.name) / "外部.json"
        path.write_text(json.dumps(EXAMPLE), encoding="utf-8")
        self.assertTrue(self.app.open_project(path))
        reloaded = ProjectLibrary(self.app.project_library.state_path)
        self.assertEqual(reloaded.directory, folder)
        self.assertIn(str(path), reloaded.files())
        self.assertIn("外部", self.app.project_sidebar.tree.item(str(path), "text"))

    def test_loading_same_file_after_save_reads_new_contents(self):
        path = self.file("same.json")
        self.select(path)
        self.app.data["settings"]["TEXT_HEIGHT"] = "11"
        self.app.refresh()
        with patch("tkinter.messagebox.askyesnocancel", return_value=True):
            self.assertTrue(self.app.open_project(path))
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], "11")

    def test_list_preferences_failure_does_not_fail_project_save(self):
        path = self.app.project_library.directory / "safe.json"
        with (
            patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)),
            patch.object(
                self.app.project_library,
                "persist",
                side_effect=PermissionError("denied"),
            ),
        ):
            self.assertTrue(self.app.save())
        self.assertTrue(path.is_file())
        self.assertFalse(self.app.has_unsaved_changes())
        self.assertIn("一覧設定の保存に失敗", self.app.status.get())

    def test_cannot_overwrite_library_preferences_with_project(self):
        self.app.project_library.remember(
            Path(self.library_dir.name) / "remembered.json"
        )
        path = self.app.project_library.state_path
        before = path.read_bytes()
        with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
            self.assertFalse(self.app.save())
        self.assertEqual(path.read_bytes(), before)
        self.assertIsNone(self.app.path)
        self.assertTrue(self.messages)

    def test_button_reuses_one_nonmodal_window(self):
        window = self.app.project_window
        self.assertIsNone(self.root.grab_current())
        gui.button(self.root, "プロジェクト一覧").invoke()
        self.root.update()
        self.assertIs(self.app.project_window, window)
        self.assertTrue(window.winfo_ismapped())

    def test_close_and_reopen_keeps_document_and_list(self):
        path = self.file("保持.json")
        self.select(path)
        self.app.data["settings"]["TEXT_HEIGHT"] = "7"
        self.app.refresh()
        before = copy.deepcopy(self.app.data)
        gui.button(self.app.project_window, "閉じる").invoke()
        self.root.update()
        self.assertEqual(self.app.project_window.state(), "withdrawn")
        self.assertEqual(self.app.data, before)
        self.app.show_project_list()
        self.root.update()
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app.project_sidebar.tree.selection(), (str(path),))

    def test_main_geometry_does_not_change_when_list_opens(self):
        self.app.project_window.withdraw()
        self.root.update()
        before = (self.root.geometry(), self.app.canvas.winfo_width())
        self.app.show_project_list()
        self.root.update()
        self.assertEqual(before, (self.root.geometry(), self.app.canvas.winfo_width()))

    def test_hidden_list_stays_hidden_after_main_save(self):
        path = self.app.project_library.directory / "main-save.json"
        self.app.project_window.withdraw()
        with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
            self.assertTrue(self.app.save())
        self.assertEqual(self.app.project_window.state(), "withdrawn")
        self.app.show_project_list()
        self.assertIn(str(path), self.app.project_sidebar.tree.get_children())

    def test_window_buttons_fit_at_minimum_size_and_dialogs_use_it(self):
        window = self.app.project_window
        window.geometry("480x560")
        self.root.update()
        self.assertIs(self.app.project_dialog_parent(), window)
        for widget in gui.descendants(window):
            if isinstance(widget, ttk.Button) and widget.winfo_ismapped():
                self.assertLessEqual(
                    widget.winfo_rooty() + widget.winfo_height(),
                    window.winfo_rooty() + window.winfo_height(),
                )
        window.withdraw()
        self.assertIs(self.app.project_dialog_parent(), self.root)


if __name__ == "__main__":
    unittest.main()
