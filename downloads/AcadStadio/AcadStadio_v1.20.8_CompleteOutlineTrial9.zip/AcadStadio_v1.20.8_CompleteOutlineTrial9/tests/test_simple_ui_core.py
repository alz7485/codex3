import ctypes
import sys
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from file_drop import enable_file_drop
from cad_setup import default_setup, validate_setup, initial_macro
from dwg_resources import merge_selected_definitions


class Function:
    def __init__(self, fn): self.fn=fn; self.calls=[]
    def __call__(self,*args): self.calls.append(args); return self.fn(*args)


class SimpleCore(unittest.TestCase):
    def test_explorer_drop_preserves_unicode_paths_and_restores_native_handler(self):
        source='C:\\図面 フォルダ\\部品 A.DWG'
        pending=[];bindings={};received=[]
        widget=SimpleNamespace(update_idletasks=lambda:None,winfo_id=lambda:100,
            winfo_exists=lambda:True,after_idle=pending.append,
            bind=lambda event,fn,**kw:bindings.update({event:fn}))
        def query(handle,index,buffer,size):
            if index==0xffffffff:return 1
            if buffer is None:return len(source)
            buffer.value=source;return len(source)
        user=SimpleNamespace(GetParent=Function(lambda h:200),
            SetWindowLongPtrW=Function(lambda *a:300),SetWindowLongW=Function(lambda *a:300),
            CallWindowProcW=Function(lambda *a:77))
        shell=SimpleNamespace(DragAcceptFiles=Function(lambda *a:None),
            DragQueryFileW=Function(query),DragFinish=Function(lambda *a:None))
        with patch('file_drop.sys.platform','win32'),patch.object(ctypes,'WinDLL',lambda n,**kw:user if n=='user32' else shell,create=True),patch.object(ctypes,'WINFUNCTYPE',ctypes.CFUNCTYPE,create=True):
            self.assertTrue(enable_file_drop(widget,received.append))
            self.assertEqual(widget._file_drop_proc(200,0x233,123,0),0)
            self.assertEqual(received,[])
            pending.pop()()
            self.assertEqual(received,[[source]])
            self.assertEqual(shell.DragFinish.calls,[(123,)])
            self.assertEqual(widget._file_drop_proc(200,1,0,0),77)
            bindings['<Destroy>'](SimpleNamespace(widget=widget))
            setter=user.SetWindowLongPtrW if ctypes.sizeof(ctypes.c_void_p)==8 else user.SetWindowLongW
            self.assertEqual(setter.calls[-1],(200,-4,300))

    def test_non_windows_does_not_try_to_hook_a_native_window(self):
        with patch('file_drop.sys.platform','linux'):
            self.assertFalse(enable_file_drop(None,None))

    def test_named_linetypes_do_not_request_or_emit_an_additional_file(self):
        setup=default_setup();setup['enabled']=True
        candidates={'linetypes':[{'name':'DASHED','values':{'name':'DASHED'}}]}
        result=merge_selected_definitions(setup,candidates,{'linetypes':['DASHED']})
        self.assertEqual(validate_setup(result),[])
        self.assertTrue(result['linetypes'][0]['existing_only'])
        self.assertNotIn('_.-LINETYPE','\n'.join(initial_macro(result)))

    def test_invalid_reference_flag_is_rejected(self):
        setup=default_setup();setup['linetypes']=[{'name':'DASHED','existing_only':'yes'}]
        self.assertTrue(validate_setup(setup))
