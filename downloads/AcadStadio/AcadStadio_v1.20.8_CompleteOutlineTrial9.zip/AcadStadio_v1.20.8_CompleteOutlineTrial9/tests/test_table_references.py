"""Cross-table references with optional 1-based row expression."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from engine import MacroError, parse_expression, compile_project  # noqa: E402
from expression_sample import sample_value  # noqa: E402
from project_model import normalize_project  # noqa: E402
from project_data import add_input_table  # noqa: E402
from table_references import (  # noqa: E402
    expand_table_references, rename_table_references,
    rename_project_table_references, is_single_table_reference,
)


def project():
    return {
        "active_table": "a",
        "input_tables": [
            {"id": "a", "name": "寸法表", "rows": [
                {"X": "10", "ROW": "2"}, {"X": "20", "ROW": "1"},
            ]},
            {"id": "b", "name": "座標表", "rows": [
                {"X": "100"}, {"X": "200"}, {"X": "300"},
            ]},
            {"id": "c", "name": "共通データ", "rows": [{"OFFSET": "7"}]},
        ],
        "settings": {"FIXED_ROW": "3"},
        "globals": {"REFERENCE_ROW": "@ROW"},
    }


class TableReferenceTests(unittest.TestCase):
    def test_compiler_uses_both_tables_and_fixed_row(self):
        p = normalize_project({
            "version": 6, "rows": [{"X": 10}, {"X": 20}],
            "settings": {}, "globals": {}, "blocks": {},
            "presets": [{"name": "circle", "commands": [
                {"type": "CIRCLE", "x": "@X{2} + [別表]@X{1}", "y": "0", "r": "2"}
            ]}],
        })
        base_id = p["active_table"]
        add_input_table(p, "別表", [{"X": 100}, {"X": 200}])
        p["active_table"] = base_id
        result = compile_project(p, [0])[1]
        self.assertEqual(result[0]["coords"][0], 120)

    def test_legacy_and_explicit_table(self):
        p = project()
        self.assertEqual(sample_value(p, "@X", 0), 10)
        self.assertEqual(sample_value(p, "[座標表]@X", 0), 100)
        self.assertEqual(sample_value(p, "[座標表]@X", 1), 200)
        self.assertEqual(sample_value(p, "[座標表]@X - @X", 1), 180)

    def test_fixed_row_accepts_ascii_and_fullwidth_braces(self):
        p = project()
        self.assertEqual(sample_value(p, "@X{2}", 0), 20)
        self.assertEqual(sample_value(p, "@X｛2｝", 0), 20)
        self.assertEqual(sample_value(p, "[座標表]@X{3}", 0), 300)
        self.assertEqual(sample_value(p, "[共通データ]@OFFSET{1}", 1), 7)

    def test_row_selector_evaluates_in_current_row_context(self):
        p = project()
        self.assertEqual(sample_value(p, "[座標表]@X{@ROW}", 0), 200)
        self.assertEqual(sample_value(p, "[座標表]@X{global.REFERENCE_ROW}", 1), 100)
        self.assertEqual(sample_value(p, "[座標表]@X{settings.FIXED_ROW}", 0), 300)
        self.assertEqual(sample_value(p, "[座標表]@X{@ROW + 1}", 1), 200)

    def test_out_of_range_and_noninteger_are_errors(self):
        p = project()
        for expression in ("[共通データ]@OFFSET", "@X{0}", "@X{3}", "@X{1.5}", "[不明]@X{1}"):
            with self.subTest(expression=expression), self.assertRaises(MacroError):
                sample_value(p, expression, 1)

    def test_quoted_text_is_not_rewritten(self):
        p = project()
        self.assertEqual(sample_value(p, '"[座標表]@X{2}"', 0), "[座標表]@X{2}")
        parse_expression('"@X{2}"')
        self.assertEqual(expand_table_references('"@X{2}"'), '"@X{2}"')
        self.assertTrue(is_single_table_reference("[座標表]@X{2}"))

    def test_quotes_in_a_table_name_do_not_break_parsing(self):
        p = project()
        p["input_tables"][1]["name"] = '座標"表'
        self.assertEqual(sample_value(p, '[座標"表]@X{2}', 0), 200)
        self.assertEqual(
            rename_table_references('[座標"表]@X{2}', '座標"表', "座標表"),
            "[座標表]@X{2}",
        )

    def test_renaming_only_changes_real_table_references(self):
        expr = '[座標表]@X{2} + @X + (1 if "[座標表]@X" else 0)'
        self.assertEqual(
            rename_table_references(expr, "座標表", "配管座標"),
            '[配管座標]@X{2} + @X + (1 if "[座標表]@X" else 0)',
        )

    def test_project_rename_keeps_blocks_and_data_intact(self):
        p = project()
        p["blocks"] = [{"name": "circle", "condition": "[座標表]@X > 0",
                        "variables": {}, "commands": [
                            {"type": "CIRCLE", "x": "[座標表]@X{@ROW}",
                             "y": "@X", "r": "2"},
                        ]}]
        rename_project_table_references(p, "座標表", "配管座標")
        p["input_tables"][1]["name"] = "配管座標"
        self.assertEqual(len(p["blocks"]), 1)
        self.assertEqual(p["blocks"][0]["commands"][0]["x"], "[配管座標]@X{@ROW}")
        self.assertEqual(sample_value(p, "[配管座標]@X{@ROW}", 0), 200)


if __name__ == "__main__":
    unittest.main()
