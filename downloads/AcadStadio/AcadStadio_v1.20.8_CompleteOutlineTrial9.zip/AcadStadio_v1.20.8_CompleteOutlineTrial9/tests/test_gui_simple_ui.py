import copy
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from tkinter import ttk

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from table_grid import GridTreeview
from cad_setup_editor import CadSetupEditor
from dwg_import_editor import DWGImportDialog


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class SimpleGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_main_preview_has_no_tabs_or_redundant_summary_labels(self):
        self.assertFalse(hasattr(self.app,'result_tabs'))
        self.assertEqual(self.app.canvas.winfo_y(),0)
        self.assertTrue(gui.button(self.root,'SCRを表示').winfo_ismapped())
        variables={str(self.app.drawing_summary),str(self.app.drawing_selection_summary)}
        self.assertFalse(any(isinstance(w,ttk.Label) and str(w.cget('textvariable')) in variables for w in gui.descendants(self.app.drawing_page)))

    def test_scr_viewer_refreshes_and_can_reopen_without_changing_targets(self):
        before=copy.deepcopy(self.app.data['drawing'])
        win=self.app.show_script();self.root.update()
        self.assertEqual(self.app.script.cget('state'),'disabled')
        old=self.app._script_text
        self.app.rows[0]['OD']='200'
        win.focus_force();self.root.update();win.event_generate('<F5>');self.root.update()
        self.assertNotEqual(self.app._script_text,old)
        self.assertEqual(self.app.script.get('1.0','end-1c'),self.app._script_text)
        win.withdraw();self.assertIs(self.app.show_script(),win)
        self.assertEqual(self.app.data['drawing'],before)

    def test_grids_follow_scroll_and_column_resize_without_changing_selection(self):
        self.app.show_input_table();self.root.update()
        tree=self.app.table
        self.assertIsInstance(tree,GridTreeview)
        tree.selection_set('1');tree.column('X',width=120);self.root.update()
        self.assertTrue(any(line.winfo_ismapped() and line.winfo_width()==1 for line in tree._grid_lines))
        self.assertTrue(any(line.winfo_ismapped() and line.winfo_height()==1 for line in tree._grid_lines))
        tree.xview_moveto(0.5);tree.yview_moveto(1);self.root.update()
        self.assertEqual(tree.selection(),('1',))

    def test_dwg_drop_accepts_one_existing_dwg_and_rejects_invalid_or_busy(self):
        editor=CadSetupEditor(self.app);dialog=DWGImportDialog(editor)
        with patch.object(dialog,'read_file') as read:
            path=Path(self.library_dir.name)/'図面 A.DWG';path.touch()
            self.assertTrue(dialog.accept_drop([str(path)]));read.assert_called_once()
            self.assertEqual(dialog.path.get(),str(path))
            read.reset_mock()
            self.assertFalse(dialog.accept_drop([str(path),str(path)]))
            self.assertFalse(dialog.accept_drop([str(path.with_suffix('.txt'))]))
            self.assertFalse(dialog.accept_drop([str(path.with_name('missing.dwg'))]))
            dialog.worker=SimpleNamespace(is_alive=lambda:True)
            self.assertFalse(dialog.accept_drop([str(path)]));read.assert_not_called()
            dialog.worker=SimpleNamespace(is_alive=lambda:False)
            dialog.read_button.state(['disabled'])
            self.assertFalse(dialog.accept_drop([str(path)]));read.assert_not_called()
        dialog.worker=None;dialog.close();editor.win.destroy()

    def test_dwg_grid_checkboxes_and_no_filter_or_lin_file_fields(self):
        editor=CadSetupEditor(self.app);dialog=DWGImportDialog(editor)
        labels=[str(w.cget('text')) for w in gui.descendants(dialog.win) if isinstance(w,ttk.Label)]
        self.assertNotIn('絞り込み',labels)
        self.assertFalse(hasattr(dialog,'lin_file'))
        for geometry in ['1020x730','800x580']:
            dialog.win.geometry(geometry);self.root.update()
            self.assertGreater(dialog.apply_button.winfo_height(),25)
            self.assertLessEqual(dialog.apply_button.winfo_rooty()+dialog.apply_button.winfo_height(),dialog.win.winfo_rooty()+dialog.win.winfo_height())
        dialog.resources['linetypes']=[{'name':'DASHED','values':{'name':'DASHED'}}]
        dialog.tabs.select(3);dialog.render_section('linetypes');self.root.update()
        tree=dialog.views['linetypes']['tree'];tree.focus('0');dialog.toggle_candidate('linetypes')
        self.assertEqual(dialog.checked['linetypes'],{'DASHED'})
        dialog.apply()
        self.assertTrue(editor.data['linetypes'][0]['existing_only'])
        self.assertNotIn('file',editor.forms['linetypes'][1])
        tree,values=editor.forms['linetypes']
        tree.selection_set('0');editor.select('linetypes')
        self.assertEqual(values['name'].get(),'DASHED')
        editor.clear('linetypes');values['name'].set('CENTER')
        self.assertTrue(editor.upsert('linetypes'))
        self.assertTrue(all(r['existing_only'] for r in editor.data['linetypes']))
        editor.win.destroy()
