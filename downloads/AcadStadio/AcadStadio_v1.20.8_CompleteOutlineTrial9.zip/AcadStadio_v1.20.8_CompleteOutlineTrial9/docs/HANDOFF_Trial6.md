# Trial6 引継ぎ

元ZIPはTrial5。現在版は1.20.5-beta6、配布名AcadStadio_v1.20.5_SimpleUITrial6。

今回の要望: レイヤー絞り込み不要、DWGドラッグ対応、追加LINファイルなし、各表罫線、メイン上部ラベルを退避してプレビューを上へ、プレビュー/SCRタブ廃止、右上からSCRを別窓で表示。

新規src/table_grid.pyはttk.Treeviewの罫線付き派生クラス。全ての表で明示的に使用し、入力・選択・階層・スクロールを維持。
新規src/file_drop.pyはWindows WM_DROPFILES。依存追加なし。DWG画面からDWGImportDialog.accept_dropに渡し、1ファイル/有効パス/ビジーを検証後に読み取り開始。
main.pyはpreview_panelとshow_script。SCR本文は_script_text、表示中のTextをset_scriptで更新。result_tabsは廃止し保存状態からも除去。
DWG表はGridTreeviewとUnicodeチェック欄。フィルタ欄とLIN指定UIを削除。linetypesはfile空・existing_only真で名前だけ登録し、冒頭マクロで追加ロードしない。
線種の形状は複製しない。使用CAD図面に同名定義が必要。この意味はユーザーへ説明済み。

core210 GUI166、計376件PASS。詳細VALIDATION.md。次にWindows+AutoCADで実ドロップ/実読取の確認が必要。
