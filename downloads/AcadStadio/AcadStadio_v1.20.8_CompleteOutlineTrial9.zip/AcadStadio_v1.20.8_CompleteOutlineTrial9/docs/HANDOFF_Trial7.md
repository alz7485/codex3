# Trial7 引継ぎ

現在版: 1.20.6-beta7。配布名: AcadStadio_v1.20.6_FlangePlanSectionTrial7。
現在の作業ディレクトリ名はAcadStadio_SimpleUIのまま。前回Trial6 ZIPは変更していません。

要望は標準サンプルの変更。三面図という最初の指示は訂正され、最終的に「平面図＋断面図の2面」。三面図は同梱しません。

src/flange_sample.pyのbuild_flange_sampleが標準の版11プロジェクトを作成。sample_project.EXAMPLEに適用します。LEGACY_EXAMPLEは独立した従来の検証用データを維持。
ブロックは平面図・断面図A-A・断面ハッチング・寸法図名の4つ。BLOCK/SET/ローカル変数は使わず、すべて通常の編集可能なコマンドです。
ID=中心穴径、T=板厚を入力表へ追加。N=4/6/8の3部品。初期対象は1行目だけ、全行選択で3部品。
断面は左右のボルト穴と中心穴を通る全断面。4つの材料区間を長方形で表現し、45度線分を各区間へクリップ。LIN追加不要。
サンプルは偶数穴で、ID/2 < PCD/2-R、PCD/2+R < OD/2、T>0を前提とします。形状不成立の自動修正なし。
共通設定VIEW_GAP=35、HATCH_PITCH=5。CAD初期設定ONでContinuousの5レイヤーを作成（既存名は上書きしない）。設定復元は既存コンパイラで継続。
JSON/CSV/Excel/CP932のSCRおよびフォルダ整理例を更新。

既存GUIテストは旧サンプルの固定図形数/旧コマンド位置/旧名への依存を更新。CAD初期設定UIの試験は空の設定を明示的に用意。新規test_flange_sample.pyの4件で寸法変更時の幾何と同梱例の整合性を検証。
core214 + GUI166 = 380 PASS。詳細はVALIDATION.md。Windows/AutoCAD実行は未検証。
