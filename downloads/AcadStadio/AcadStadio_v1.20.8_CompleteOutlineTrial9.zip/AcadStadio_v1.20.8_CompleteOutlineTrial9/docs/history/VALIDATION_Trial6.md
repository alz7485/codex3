# Trial6 検証記録

基準: 添付 AcadStadio_v1.20.4_DWGImportTrial5.zip（SHA256 718cf684ff15a6d73cad9347cba0f288d2a8d34a2f7e80437ee715ce123a421d）。基準は変更せず別作業コピーで実装しました。

- 非GUI **210件 PASS**（スキップなし）: [ログ](core-tests-Trial6.log)
- 実Tk GUI **166件 PASS**（スキップなし）: [ログ](gui-tests-Trial6.log)
- 合計 **376件 PASS**。
- Ruff F/E9、compileall、標準27図形とスモーク確認PASS。
- DWGドロップは日本語・空白のファイル名、1ファイル選択、無効パス・複数ファイル拒否、処理中および結果反映待ちの再ドロップ拒否を検証。
- Windows APIは模擬ライブラリでWM_DROPFILES→Unicodeファイル取得→イベント配送→ハンドラ復元を検証。実Explorerでのドロップは未確認。
- 全表の罫線、列幅変更・スクロール・選択保持、DWGチェック表、線種名参照と追加ファイル不要、CAD編集の選択/解除/確定を確認。
- プレビューの結果タブ撤去と上端配置、補助ラベル非表示、SCR別窓の再表示・読み取り専用・F5更新・対象行保持を確認。
- DWG登録ボタンは通常1020×730および最小800×580で枠内に表示。

GUI: Linux、Python 3.13.5、Tk8.6、Xvfb1440×1000。Windows EXEのビルド/実行、Explorerからの実ドロップ、AutoCAD実DWG読取は未検証です。
DWG画面の掲載画像は画面確認用のサンプルデータで、実DWGの読取結果ではありません。
