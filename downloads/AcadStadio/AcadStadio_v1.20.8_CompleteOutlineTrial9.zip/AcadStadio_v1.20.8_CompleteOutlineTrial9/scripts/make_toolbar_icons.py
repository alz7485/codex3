"""Generate the bundled, consistent line icons (developer tool; Pillow required)."""

from pathlib import Path
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parents[1] / "assets" / "toolbar"


def draw_icon(name, color):
    scale = 4
    image = Image.new("RGBA", (24 * scale, 24 * scale))
    draw = ImageDraw.Draw(image)

    def line(points):
        draw.line(
            [(x * scale, y * scale) for x, y in points],
            fill=color,
            width=2 * scale,
            joint="curve",
        )

    def box(bounds):
        draw.rounded_rectangle(
            tuple(v * scale for v in bounds),
            radius=scale,
            outline=color,
            width=2 * scale,
        )

    def oval(bounds):
        draw.ellipse(tuple(v * scale for v in bounds), outline=color, width=2 * scale)

    if name == "folder":
        line([(3, 19), (3, 5), (9, 5), (11, 8), (21, 8), (21, 19), (3, 19)])
        line([(4, 11), (20, 11)])
    elif name == "save":
        box((4, 3, 20, 21))
        box((8, 3, 16, 9))
        box((8, 14, 17, 21))
    elif name == "check":
        oval((3, 3, 21, 21))
        line([(7, 12), (10, 15), (17, 8)])
    elif name in ("export", "up", "down", "back"):
        if name == "export":
            line([(5, 13), (5, 20), (20, 20), (20, 13)])
            line([(12, 15), (12, 3)])
            line([(7, 8), (12, 3), (17, 8)])
        elif name == "back":
            line([(20, 12), (4, 12)])
            line([(10, 6), (4, 12), (10, 18)])
        else:
            sign = 1 if name == "up" else -1
            line([(12, 12 - sign * 8), (12, 12 + sign * 8)])
            line([(6, 12 - sign * 2), (12, 12 - sign * 8), (18, 12 - sign * 2)])
    elif name in ("projects", "commands"):
        box((4, 3, 20, 21))
        for y in (7, 12, 17):
            line([(8, y), (9, y)])
            line([(12, y), (17, y)])
    elif name == "table":
        box((3, 4, 21, 20))
        line([(3, 9), (21, 9)])
        line([(3, 14), (21, 14)])
        line([(9, 4), (9, 20)])
        line([(15, 4), (15, 20)])
    elif name == "gear":
        oval((6, 6, 18, 18))
        oval((10, 10, 14, 14))
        for a, b in [
            ((12, 2), (12, 6)),
            ((12, 18), (12, 22)),
            ((2, 12), (6, 12)),
            ((18, 12), (22, 12)),
            ((5, 5), (8, 8)),
            ((16, 16), (19, 19)),
            ((5, 19), (8, 16)),
            ((16, 8), (19, 5)),
        ]:
            line([a, b])
    elif name == "add":
        line([(12, 4), (12, 20)])
        line([(4, 12), (20, 12)])
    elif name == "edit":
        line([(4, 20), (5, 14), (17, 3), (21, 7), (9, 19), (4, 20)])
        line([(14, 6), (18, 10)])
    elif name == "eye":
        line([(2, 12), (7, 6), (17, 6), (22, 12), (17, 18), (7, 18), (2, 12)])
        oval((9, 9, 15, 15))
    elif name == "trash":
        line([(3, 6), (21, 6)])
        box((6, 6, 18, 21))
        line([(9, 3), (15, 3)])
        line([(10, 10), (10, 17)])
        line([(14, 10), (14, 17)])
    elif name == "blocks":
        box((3, 3, 10, 10))
        box((14, 3, 21, 10))
        box((3, 14, 10, 21))
        box((14, 14, 21, 21))
    elif name == "variables":
        line([(8, 5), (5, 5), (5, 10), (2, 12), (5, 14), (5, 19), (8, 19)])
        line([(16, 5), (19, 5), (19, 10), (22, 12), (19, 14), (19, 19), (16, 19)])
        line([(10, 9), (14, 15)])
        line([(14, 9), (10, 15)])
    elif name == "tree":
        box((3, 3, 9, 9))
        box((15, 3, 21, 9))
        box((15, 15, 21, 21))
        line([(6, 9), (6, 18), (15, 18)])
        line([(9, 6), (15, 6)])
    elif name == "refresh":
        line(
            [
                (20, 10),
                (19, 6),
                (15, 3),
                (8, 3),
                (4, 7),
                (3, 12),
                (5, 18),
                (10, 21),
                (16, 20),
                (20, 16),
            ]
        )
        line([(16, 9), (21, 11), (22, 5)])
    elif name == "fit":
        for points in (
            [(3, 9), (3, 3), (9, 3)],
            [(15, 3), (21, 3), (21, 9)],
            [(21, 15), (21, 21), (15, 21)],
            [(9, 21), (3, 21), (3, 15)],
        ):
            line(points)
        box((8, 8, 16, 16))
    elif name in ("copy", "duplicate"):
        box((3, 3, 15, 16))
        box((9, 8, 21, 21))
    elif name in ("undo", "redo"):
        points = [(4, 9), (15, 9), (20, 13), (20, 18), (16, 21)]
        arrow = [(9, 4), (4, 9), (9, 14)]
        if name == "redo":
            points = [(24 - x, y) for x, y in points]
            arrow = [(24 - x, y) for x, y in arrow]
        line(points)
        line(arrow)
    elif name == "script":
        box((4, 2, 20, 22))
        line([(10, 8), (7, 12), (10, 16)])
        line([(14, 8), (17, 12), (14, 16)])
    elif name == "preview":
        box((3, 3, 21, 21))
        oval((7, 7, 17, 17))
        line([(6, 18), (18, 6)])
    return image.resize((20, 20), Image.Resampling.LANCZOS)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    names = "folder save check export up down back projects commands table gear add edit eye trash blocks variables tree refresh fit copy duplicate undo redo script preview".split()
    for name in names:
        for suffix, color in (("", "#385a81"), ("_white", "#ffffff")):
            draw_icon(name, color).save(OUT / (name + suffix + ".png"))
    print(f"Generated {len(names) * 2} toolbar assets")


if __name__ == "__main__":
    main()
