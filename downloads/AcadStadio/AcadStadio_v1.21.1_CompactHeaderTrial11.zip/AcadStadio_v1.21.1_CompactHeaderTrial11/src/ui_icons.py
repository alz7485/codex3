"""Bundled toolbar icons and tooltips for mouse and keyboard navigation."""

import tkinter as tk
from tkinter import ttk
from theme import ROOT


# Text stays on the widget for accessibility and automated UI navigation.
ICONS = {
    "選択行…": ("table", False, "作図する行をチェックリストで選ぶ"),
    "SCRを表示": ("script", False, "生成SCRを別ウィンドウで表示"),
    "開く": ("folder", True, "プロジェクトを開く  Ctrl+O"),
    "保存": ("save", True, "保存  Ctrl+S"),
    "プロジェクトを検査": ("check", True, "全入力表と作図フローを検査"),
    "SCRを書き出す": ("export", False, "SCRを書き出す  Ctrl+E"),
    "プロジェクト一覧…": ("projects", False, "プロジェクト一覧を別ウィンドウで開く"),
    "CAD初期設定…": ("gear", True, "レイヤー・線種・文字/寸法スタイルの設定"),
    "入力表を編集 →": ("table", True, "入力表タブへ移動"),
    "← 作図へ戻る": ("back", False, "作図タブへ戻る"),
    "ブロック追加": ("add", False, "選択フォルダにブロックを追加"),
    "登録コマンド": ("commands", True, "ユーザーコマンドを登録・編集"),
    "編集": ("edit", True, "選択項目を編集"),
    "作図対象 / 呼出専用": (
        "eye",
        True,
        "作図対象 / 呼び出し専用を切り替え（呼び出しは維持）",
    ),
    "↑": ("up", True, "上へ移動  Alt+↑"),
    "↓": ("down", True, "下へ移動  Alt+↓"),
    "削除": ("trash", True, "選択項目を削除"),
    "複製": ("duplicate", True, "選択項目を複製"),
    "共通ブロック": ("blocks", True, "共通ブロックを編集"),
    "設定・変数": ("variables", True, "設定・変数"),
    "構成ツリー": ("tree", True, "プロジェクト構成を別ウィンドウで開く"),
    "再生成  F5": ("refresh", True, "プレビューとSCRを再生成  F5"),
    "全体を表示": ("fit", True, "図形全体を表示（プレビューのダブルクリックでも可）"),
    "選択を強調": ("eye", True, "選択行・ブロックの強調 ON / OFF"),
    "SCRをコピー": ("copy", False, "生成SCRをクリップボードへコピー"),
    "行を追加": ("add", False, "入力表に行を追加"),
    "元に戻す": ("undo", True, "元に戻す  Ctrl+Z"),
    "やり直し": ("redo", True, "やり直す  Ctrl+Y"),
}


class IconTheme:
    def __init__(self, root):
        self.root = root
        self.images = {}
        self.tooltip = None
        self.job = None
        root.bind_all("<Map>", self.mapped, add="+")
        root.bind("<Destroy>", self.destroyed, add="+")

    def get(self, name, white=False):
        key = name + ("_white" if white else "")
        if key not in self.images:
            self.images[key] = tk.PhotoImage(
                master=self.root, file=str(ROOT / "assets" / "toolbar" / (key + ".png"))
            )
        return self.images[key]

    def mapped(self, event):
        widget = event.widget
        if not isinstance(widget, (ttk.Button, ttk.Checkbutton)) or getattr(
            widget, "_icon_ready", False
        ):
            return
        label = str(widget.cget("text"))
        spec = ICONS.get(label)
        if spec is None:
            for prefix, name in (
                ("＋ Excel", "folder"),
                ("設定プリセット", "save"),
                ("サイズ・共通設定", "gear"),
                ("作図設定…", "gear"),
                ("選択した参照", "add"),
            ):
                if label.startswith(prefix):
                    spec = name, False, label
                    break
        if spec is None:
            return
        name, icon_only, tip = spec
        try:
            widget.configure(
                image=self.get(name, "Primary" in widget.cget("style")),
                compound="none" if icon_only else "left",
            )
        except tk.TclError:
            return
        if icon_only:
            if isinstance(widget, ttk.Checkbutton):
                widget.configure(style="Toggle.Toolbutton")
            else:
                widget.configure(width=3, style="Compact.TButton")
        widget._icon_ready = True
        widget.tooltip_text = tip
        widget.bind("<Enter>", lambda e: self.schedule(widget, tip), add="+")
        widget.bind("<FocusIn>", lambda e: self.schedule(widget, tip), add="+")
        for sequence in ("<Leave>", "<FocusOut>", "<ButtonPress>", "<Escape>"):
            widget.bind(sequence, lambda e: self.hide(), add="+")

    def schedule(self, widget, text):
        self.hide()
        self.job = self.root.after(450, lambda: self.show(widget, text))

    def show(self, widget, text):
        if self.job:
            self.root.after_cancel(self.job)
        self.job = None
        if not widget.winfo_exists() or not widget.winfo_ismapped():
            return
        win = self.tooltip = tk.Toplevel(self.root)
        win.overrideredirect(True)
        ttk.Label(
            win,
            text=text,
            padding=(9, 5),
            background="#233950",
            foreground="white",
            wraplength=350,
        ).pack()
        win.update_idletasks()
        x = min(
            widget.winfo_rootx(),
            self.root.winfo_screenwidth() - win.winfo_reqwidth() - 8,
        )
        y = widget.winfo_rooty() + widget.winfo_height() + 5
        if y + win.winfo_reqheight() > self.root.winfo_screenheight():
            y = widget.winfo_rooty() - win.winfo_reqheight() - 5
        win.geometry(f"+{max(0, x)}+{max(0, y)}")

    def hide(self):
        if self.job:
            self.root.after_cancel(self.job)
            self.job = None
        if self.tooltip is not None:
            try:
                self.tooltip.destroy()
            except tk.TclError:
                pass
            self.tooltip = None

    def destroyed(self, event):
        if event.widget is self.root:
            self.hide()
