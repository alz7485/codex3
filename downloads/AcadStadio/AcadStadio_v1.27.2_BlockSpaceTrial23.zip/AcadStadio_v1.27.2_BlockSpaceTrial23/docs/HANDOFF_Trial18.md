# Trial18 引継ぎ

版: 1.25.0-beta18。メインの選択フローを廃止し、ブロック一覧の操作を1行へ整理。

- block_tabs/flow_view/edit_flow_commandを削除。src/flow_view.pyも削除。代わりにblock_panel LabelFrame。
- block_actions: ブロック追加、フォルダ追加、編集、↑、↓、削除、表示。最初の6件はアイコンのみ。幅2文字で最小左ペイン300pxにも収まる。
- IconThemeはウィジェットのicon_only/icon_button_width/icon_button_styleを任意に指定可能。MainIcon.TButtonは横余白3pxで表示メニューの文字を確保。フォルダ＋は既存フォルダのコピーへ小さい＋を実行時描画。公開画像ファイルの追加・変更なし。
- BlockBrowser(actions_parent=...)で表示メニューの親を操作列へ配置。フォルダメニューボタンを削除し、検索は独立行。
- フォルダの移動・追加等の右クリックメニューは維持。全展開/全折りたたみを表示メニュー末尾にも追加。
- 検査navigate_issueはProjectNavigator.select_addressで該当コマンドを選択。所有元と入れ子の枝をdescriptorへ変換する。
- 作業状態のblock_tab保存/復元を削除。古い表示設定の項目は自然に無視される。
- 既存の検査移動・入れ子編集試験を構成ツリーへ更新。新規3件は操作順/アイコン/最小幅、追加/取消/Undo、表示/SCR/倍率/フォルダ展開。
- 左の入力表一覧、計算列、スペース付きCAD名、作図対象独立、カメラ保持を維持。既知の監査2件は修正範囲外。
