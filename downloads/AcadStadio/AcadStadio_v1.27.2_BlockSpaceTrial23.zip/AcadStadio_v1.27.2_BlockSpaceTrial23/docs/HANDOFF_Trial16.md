# Trial16 引継ぎ

版: 1.24.1-beta16。入力表の別窓で、表の選択・管理を左の一覧へ移した。

- main.App.table_list: GridTreeview、選択はtable ID。table_choiceは右見出し・メインの使用表で共有。
- refreshで一覧と選択を再構築。_syncing_optionsで再入を避け、同じ表の選択イベントは無視。
- switch_tableは表を変える前にtable_editor.finishを実行。元の表に編集を確定し、表ごとの行選択を保持。
- on_table_list_selectionはIDを取得してから切替。確定中のrefreshで一覧が再描画されても選択先を保持。
- table_list_frameは幅200px。追加/名前変更/複製/削除/読込/置換を内部へ配置。
- 旧table_pickerとtable_menuを削除。メインのdrawing_table_pickerは作図用の選択として維持。
- 名前変更アイコンはツールチップとF2対応。セルのƒと結果/薄色の式は前版のまま。
- 試験はtest_gui_workspace.pyで実クリック/上下キー/未確定値/行選択/一覧の管理/Undo/Redo/26表/保存再読込/最小画面を確認。
- 既知の監査2件は対象外。公開ZIPには画面キャプチャを含めない。
