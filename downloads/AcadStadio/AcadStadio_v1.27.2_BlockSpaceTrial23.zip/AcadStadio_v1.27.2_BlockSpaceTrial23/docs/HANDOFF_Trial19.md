# Trial19 引継ぎ

版: 1.26.0-beta19。メインの設定/表のグループ化と、サイズの設定プリセットへの統合。

- settings_group: CAD設定/設定プリセット/作図設定。table_group: 表一覧/使用表のプルダウン/PreviewRowControls。
- 狭い左ペインでは設定の3ボタンをアイコンにし、ツールチップで名前を確認可能。ブロック操作の指定順1行は維持。
- preview_row_ui.PreviewRowControlsは_preview_row_selectionと表の選択を更新。JSON・対象行・Undo履歴を変更しない。syncで表選択と同期し、resetで作図対象へ戻す。入力のNFKC処理で全角数字にも対応。
- DrawingTargetControlsは作図設定の別窓だけ。main_target_controls/range_entry/compact_choices/drawing_options_frame/adapt_drawing_optionsを削除。
- edit_drawing_settingsの別窓を削除。SettingsPresetEditorは左に現在/標準/カスタム、右に4つのサイズとその他共通設定。
- CURRENTはUI上の疑似行で、JSONのプリセットIDとしては保存しない。現在値・カスタムのサイズを直接編集し、標準はreadonly。
- flush_sizesはコピーで検証してからステージへ反映。選択変更前も確定し、不正値なら元の選択と入力を保つ。現在サイズの式はnumberで数値化。
- カスタムの空欄は未設定。現在値の既存サイズは空欄にできない。部分プリセットを自動で全項目の定義へ変えない。標準の編集保護と保存/適用の区別を維持。
- 下部は変数への直接ボタン。共通設定のメニューも設定プリセット画面へ統一。
- 新規GUI9件: 配置/最小幅、表示行とSCR独立、無効行、表の選択連動/復帰、サイズのステージ/取消/Undo、不正入力、標準保護/カスタム、部分プリセット、最小サイズ。
- Trial18はGitHubへの公開が自動承認審査で拒否され、公開先alz7485/codex3への明示承認待ち。Trial19もローカルZIPまで完成させ、承認なしで同じ公開操作を再試行しない。
- 既知の監査2件は従来の作図チェックリストと行番号スピンの問題で、今回の修正対象外。新しい表示行は別のUIである。
