# Trial21 引継ぎ

版: 1.27.0-beta21。画像の整理案をユーザーが採用。表示メニューも目アイコンに統一。

- main: Flat.TLabelframeで枠をなくし、主画面のみ左初期幅370px。設定の短いラベル、プロジェクト一覧アイコン、上部Undo/Redo。
- IconThemeはMenubuttonも対応。表示 ▾は内部テキストとtooltipを保ってeye画像だけを表示。Eye.TMenubuttonのネイティブ矢印/メニュー操作を保持。
- BlockBrowserは検索ヒントと入力時だけの×。ヒントはStringVarに入れない。名前列の幅を縮め、右の表示チェックが初期幅・300pxでも見えるようにした。
- DrawingCanvas(workspace=True)は主画面のみ。横凡例とworkspace-infoを描く。geometryタグやカメラの計算は変更しない。
- set_workspace_info(full, compact)はHUDだけを更新。短い画面では簡潔な表示を使用し、右下の操作と重ならないよう幅を制限。
- 他のプレビューはworkspace=Falseで従来の凡例・図形数を維持。HUDはgeometryと独立してズーム/パンで移動しない。
- 主画面の60px白フッターを除去し、コントロールをキャンバス内へplace。Preview用の暗いボタンと白いアイコン。Tab順と画面順を一致。
- preview_metricsに図形数/単位、preview_statusは既存の詳細メッセージを維持。エラー時はHUDとmetricsもクリア/エラーへ変更。
- sampleの名称は平面図/断面図 A-A/寸法・注記。src/flange_sampleと同梱JSONを更新。ロードしたユーザー名は加工しない。
- 新規GUI6件: 目の表示/出力独立、凡例/画面余白/最小チェック列、確認/SCRとエラー、検索、サンプル名とUndo、他プレビューと最小画面。
- engineは変更なし。前版比較時はサンプル名によるpreview metadataの名前差だけを合わせ、SCR・座標・その他情報を比較。
- 公開先alz7485/codex3は明示承認済み。ソースZIP/チェックサム/READMEだけを公開し、docsの画面キャプチャは除外。
