# Trial22 引継ぎ

版: 1.27.1-beta22。ブロックの作図画面を左コマンド・右プレビューへ変更。

- MacroEditor.command_panesはttk.Panedwindow。左右にcommand_pageとpreview_frameを追加。初期52:48、ウィンドウサイズ変更時は各ペインの最低目安320pxを保持。
- 初期幅は実際のConfigure後に設定し、未配置の幅1pxから誤った比率を作らない。ユーザーがドラッグした境界は通常のConfigureで保持する。
- プレビューはfill=both/expand=True。右上に累積表示のチェック、下端にpreview_label。状態とエラーは幅に合わせて折り返す。
- CommandList.toolbarは一覧の上へ配置。追加/編集/複製/削除/上/下/Undo/Redoの8個をすべてrow=0へ配置。分岐・反復の内部一覧にも共通適用。
- 操作名テキストは保持。ui_iconsに追加Menubuttonの＋画像・ツールチップを登録。Command.TMenubuttonで矢印を維持。
- コマンド名の列は190pxを維持し、設定/条件の列を伸縮させる。長い詳細は横スクロール。
- 通常1160×780、最小850×640。fit_windowは画面高さに応じて縮小する。下部の取消/確定は継続。
- コンパイラ、選択行、累積表示の計算、Undo/Redo、ステージされた編集・保存/取消は変更しない。
- 公開先alz7485/codex3の継続許可あり。ソースZIP/チェックサム/READMEのみ公開し、画面キャプチャは除外する。
