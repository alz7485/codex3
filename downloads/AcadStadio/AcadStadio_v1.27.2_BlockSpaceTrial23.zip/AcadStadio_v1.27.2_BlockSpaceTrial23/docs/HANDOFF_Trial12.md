# Trial12 引継ぎ

版: 1.22.0-beta12。入力表を独立した非モーダル窓に移動。メインにworkspace_tabsは存在しない。

- main.py: input_windowは起動時に生成してwithdraw、再利用する。閉じるとセルを確定する。show_drawingはメインを前面へ出す。
- block_browser.py: #0列は順。name / visible列のみ。hidden_preview_idsは端末の作業状態であり、projectに書かない。
- main.py: compile()の結果を保持し、update_preview_display()で図形のみを絞る。コンパイラ・SCR出力は表示チェックを参照しない。
- 呼出経路command_addressesの全ブロックを考慮。呼出元・中継・定義のいずれを隠しても、その経路の図形を非表示。
- preview.py: layer_orderで表示前の色割当を保持。
- GUI試験は別窓の再表示、確定、Ctrl+S、状態復元、チェック実クリック、一括、フォルダ、Space、並替追従、SCRファイル書出を含む。
- 前回軽い監査の2件（行数差によるチェック欠落、全角スピン）は今回の修正範囲に含まない。docs/VALIDATION.mdを参照。
- 配布はソースZIP。画面キャプチャを含めず、既存の必須アイコンだけを含む。Windows EXE用onedir手順を同梱。
