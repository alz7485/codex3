"""Editable stepped flange: section on the left, smooth-bore face on the right."""

import copy


def line(x1, y1, x2, y2, layer="CENTER"):
    return dict(type="LINE", layer=layer, x1=x1, y1=y1, x2=x2, y2=y2)


def repeat(count, commands):
    return dict(type="REPEAT", count=count, commands=commands)


def build_flange_sample(base):
    project = copy.deepcopy(base)
    project["settings"].update(
        VIEW_GAP="35",
        DIM_SCALE="1",
        DIM_TEXT_HEIGHT="3.5",
        ARROW_SIZE="2.5",
    )
    rows = project["input_tables"][0]["rows"]
    for row, x, bore, thickness, hub, height in zip(
        rows,
        ("100", "420", "780"),
        ("35", "40", "50"),
        ("16", "18", "20"),
        ("50", "60", "74"),
        ("10", "12", "14"),
    ):
        row.update(TYPE="FL-" + row["OD"], X=x, ID=bore, T=thickness, HUB_D=hub, H=height)
    project["input_tables"][0]["name"] = "段付きフランジ寸法表"
    project["drawing"]["targets"][project["active_table"]].update(mode="range", range="1", selected=[0])
    setup = project["cad_setup"]
    setup.update(enabled=True, legacy_make_layers=False)
    setup["linetypes"] = []
    setup["layers"] = [
        dict(
            name=name, color=color, linetype="Continuous", lineweight=weight, plot=True
        )
        for name, color, weight in (
            ("OUTLINE", "7", "35"),
            ("HOLES", "4", "25"),
            ("CENTER", "2", "13"),
            ("DIM", "6", "18"),
        )
    ]
    plan = [
        dict(type="CIRCLE", layer="OUTLINE", x="@X", y="@Y", r="@OD/2"),
        dict(type="CIRCLE", layer="OUTLINE", x="@X", y="@Y", r="@ID/2"),
        # Start at the top so the vertical cutting plane includes opposite holes.
        repeat(
            "@N",
            [
                dict(
                    type="CIRCLE",
                    layer="HOLES",
                    x="@X + @PCD/2 * sin(radians(360 * loop.index / @N))",
                    y="@Y + @PCD/2 * cos(radians(360 * loop.index / @N))",
                    r="@R",
                )
            ],
        ),
        dict(type="CIRCLE", layer="OUTLINE", x="@X", y="@Y", r="@HUB_D/2"),
        repeat(
            "36",
            [
                line(
                    "@X + @PCD/2 * cos(radians(10 * loop.index))",
                    "@Y + @PCD/2 * sin(radians(10 * loop.index))",
                    "@X + @PCD/2 * cos(radians(10 * loop.index + 6))",
                    "@Y + @PCD/2 * sin(radians(10 * loop.index + 6))",
                )
            ],
        ),
        repeat(
            "9",
            [
                line(
                    "@X - @OD/2 - 8 + (@OD+16)*loop.index/9",
                    "@Y",
                    "@X - @OD/2 - 8 + (@OD+16)*(loop.index+0.65)/9",
                    "@Y",
                ),
                line(
                    "@X",
                    "@Y - @OD/2 - 8 + (@OD+16)*loop.index/9",
                    "@X",
                    "@Y - @OD/2 - 8 + (@OD+16)*(loop.index+0.65)/9",
                ),
            ],
        ),
    ]
    # Plate rear / shoulder / hub nose. Both views share their vertical center.
    rear = "@X-@OD/2-settings.VIEW_GAP-@T-@H"
    shoulder = "@X-@OD/2-settings.VIEW_GAP-@H"
    nose = "@X-@OD/2-settings.VIEW_GAP"
    # Keep the complete exterior and end faces, including at hole openings.
    # Hole walls are separate full-length lines rather than breaks in the profile.
    profile = [
        (rear, "@Y-@OD/2"),
        (shoulder, "@Y-@OD/2"),
        (shoulder, "@Y-@HUB_D/2"),
        (nose, "@Y-@HUB_D/2"),
        (nose, "@Y+@HUB_D/2"),
        (shoulder, "@Y+@HUB_D/2"),
        (shoulder, "@Y+@OD/2"),
        (rear, "@Y+@OD/2"),
    ]
    section = [
        line(x1, y1, x2, y2, "OUTLINE")
        for (x1, y1), (x2, y2) in zip(profile, profile[1:] + profile[:1])
    ]
    for sign in ("-", "+"):
        # Central bore spans the entire thickness, including the raised hub.
        section.append(line(rear, f"@Y{sign}@ID/2", nose, f"@Y{sign}@ID/2", "HOLES"))
        # Both sides of the upper and lower mounting holes span the plate.
        for edge in ("-", "+"):
            level = f"@Y{sign}@PCD/2{edge}@R"
            section.append(line(rear, level, shoulder, level, "HOLES"))
    section.append(
        repeat(
            "9",
            [
                line(
                    f"({rear})-6+(@T+@H+12)*loop.index/9",
                    "@Y",
                    f"({rear})-6+(@T+@H+12)*(loop.index+0.65)/9",
                    "@Y",
                )
            ],
        )
    )

    def text(x, y, content):
        return dict(
            type="TEXT",
            layer="DIM",
            x=x,
            y=y,
            text=content,
            height="settings.TEXT_HEIGHT",
        )

    def dimension(x1, y1, x2, y2, x3, y3):
        return dict(
            type="DIMLINEAR", layer="DIM", x1=x1, y1=y1, x2=x2, y2=y2, x3=x3, y3=y3
        )

    notes = [
        text(f"({rear})-12", "@Y+@OD/2+25", "断面図 A-A"),
        text("@X-10", "@Y+@OD/2+25", "平面図"),
        text("@X+5", "@Y+@OD/2+10", "A"),
        text("@X+5", "@Y-@OD/2-14", "A"),
        text("@X-@OD/2", "@Y-@OD/2-27", "='PCD %g' % @PCD"),
        text("@X-@OD/2", "@Y-@OD/2-39", "=('%g-φ' % @N) + ('%g 通し' % (@R*2))"),
        text("@X-@OD/2", "@Y-@OD/2-51", "='中心穴 φ%g 通し' % @ID"),
        dimension(rear, "@Y-@OD/2", rear, "@Y+@OD/2", f"({rear})-24", "@Y"),
        dimension(nose, "@Y-@HUB_D/2", nose, "@Y+@HUB_D/2", f"({rear})-12", "@Y"),
        dimension(nose, "@Y-@ID/2", nose, "@Y+@ID/2", f"({nose})+12", "@Y"),
        dimension(
            rear, "@Y-@OD/2", shoulder, "@Y-@OD/2", f"({rear})+@T/2", "@Y-@OD/2-14"
        ),
        dimension(
            rear, "@Y-@OD/2", nose, "@Y-@OD/2", f"({rear})+(@T+@H)/2", "@Y-@OD/2-28"
        ),
    ]
    for arrow_y in ("@Y-@OD/2-8", "@Y+@OD/2+8"):
        notes.extend(
            [
                line("@X+7", arrow_y, "@X-5", arrow_y, "DIM"),
                line("@X-1", f"({arrow_y})-2", "@X-5", arrow_y, "DIM"),
                line("@X-1", f"({arrow_y})+2", "@X-5", arrow_y, "DIM"),
            ]
        )
    project["blocks"] = [
        dict(id=identity, name=name, condition="", commands=commands)
        for identity, name, commands in (
            ("flange_plan", "平面図", plan),
            ("flange_section", "断面図 A-A", section),
            ("flange_notes", "寸法・注記", notes),
        )
    ]
    return project
