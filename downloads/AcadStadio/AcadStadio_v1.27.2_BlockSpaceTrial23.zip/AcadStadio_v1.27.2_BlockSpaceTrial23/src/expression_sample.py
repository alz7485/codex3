"""Safe, side-effect-free expression samples using the compiler's interpreter."""

from engine import evaluate, row_values


def sample_value(project, expression, row_index=0, local_variables=None):
    values = dict(row_values(project, row_index), __local__={})
    for key, expr in (local_variables or {}).items():
        values["__local__"][key] = evaluate(expr, values)
        values[key] = values["__local__"][key]
    return evaluate(expression, values)
