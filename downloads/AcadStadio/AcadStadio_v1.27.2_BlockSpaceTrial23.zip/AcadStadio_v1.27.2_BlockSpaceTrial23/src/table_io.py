"""Validated CSV/XLSX imports with explicit failures rather than silent data loss."""

import csv
import io
from pathlib import Path
from project_model import valid_variable_name as valid_name

MAX_ROWS = 10000


def headers(values):
    keys = [str(x).strip() if x is not None else "" for x in values]
    if not keys or any(not x for x in keys):
        raise ValueError("列名に空欄があります。すべての列に見出しを付けてください")
    if len(set(keys)) != len(keys):
        raise ValueError("列名が重複しています。異なる列名にしてください")
    if any(not valid_name(x) for x in keys):
        raise ValueError(
            "列名は日本語・英字・_から始まる名前にしてください。空白・記号は使えません（例: 幅, OD, PART_TYPE）"
        )
    return keys


def read_csv(path):
    raw = Path(path).read_bytes()
    if len(raw) > 20 * 1024 * 1024:
        raise ValueError("CSVは20MBまでです")
    for encoding in ("utf-8-sig", "cp932"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ValueError("UTF-8 または Shift-JIS のCSVを指定してください")
    reader = csv.reader(io.StringIO(text))
    keys = headers(next(reader, []))
    rows = []
    for line, values in enumerate(reader, 2):
        if not values or not any(v.strip() for v in values):
            continue
        if len(values) != len(keys):
            raise ValueError(f"CSV {line}行目: 見出しとセル数が一致しません")
        rows.append(dict(zip(keys, values)))
        if len(rows) > MAX_ROWS:
            raise ValueError("入力表は10000行までです")
    if not rows:
        raise ValueError("データ行がありません")
    return rows


def sheet_names(path):
    from openpyxl import load_workbook

    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        return wb.sheetnames
    finally:
        wb.close()


def read_excel(path, sheet, header=1):
    from openpyxl import load_workbook

    if type(header) is not int or header < 1:
        raise ValueError("見出し行は1以上の整数です")
    wb = load_workbook(path, read_only=True, data_only=True)
    formulas = None
    try:
        if sheet not in wb.sheetnames:
            raise ValueError("指定シートがありません")
        formulas = load_workbook(path, read_only=True, data_only=False)
        iterator = wb[sheet].iter_rows(min_row=header, values_only=True)
        heads = list(next(iterator, []))
        while heads and heads[-1] is None:
            heads.pop()
        keys = headers(heads)
        formula_iter = formulas[sheet].iter_rows(min_row=header + 1)
        rows = []
        for line, (cells, sources) in enumerate(
            zip(iterator, formula_iter), header + 1
        ):
            for cell, source in zip(cells[: len(keys)], sources[: len(keys)]):
                if cell is None and source.data_type == "f":
                    raise ValueError(
                        f"Excel {line}行目: 数式の計算結果がありません。Excelで再計算・保存してから読み込んでください"
                    )
            if any(v is not None and str(v).strip() for v in cells[len(keys) :]):
                raise ValueError(f"Excel {line}行目: 見出しのない列に値があります")
            vals = list(cells[: len(keys)])
            if not any(v is not None and str(v).strip() for v in vals):
                continue
            if any(
                v is not None and not isinstance(v, (str, int, float, bool))
                for v in vals
            ):
                raise ValueError(
                    f"Excel {line}行目: 日付等を文字列または数値に変換してください"
                )
            vals += [None] * (len(keys) - len(vals))
            rows.append(dict(zip(keys, [v if v is not None else "" for v in vals])))
            if len(rows) > MAX_ROWS:
                raise ValueError("入力表は10000行までです")
        if not rows:
            raise ValueError("データ行がありません")
        return rows
    finally:
        wb.close()
        if formulas is not None:
            formulas.close()
