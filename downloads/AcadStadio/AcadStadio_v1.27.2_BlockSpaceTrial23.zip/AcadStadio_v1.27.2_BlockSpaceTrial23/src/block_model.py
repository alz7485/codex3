"""One block collection for drawing and reusable commands; legacy migration only."""

import copy
import uuid


def unified(project):
    return isinstance(project, dict) and isinstance(project.get("blocks"), list)


def nested(commands):
    for command in commands:
        yield command
        for key in ("commands", "else"):
            if key in command:
                yield from nested(command[key])


def new_block(name="新しいブロック", *, commands=None):
    result = {
        "id": "block_" + uuid.uuid4().hex,
        "name": name,
        "condition": "",
        "commands": copy.deepcopy(commands or []),
    }
    return result


def index_of(project, identity):
    return next(i for i, b in enumerate(project["blocks"]) if b["id"] == identity)


def named(blocks, identity):
    return next((b["name"] for b in blocks if b["id"] == identity), identity)


def replace_collection(target, source):
    target.clear()
    target.extend(copy.deepcopy(source)) if isinstance(target, list) else target.update(
        copy.deepcopy(source)
    )


def groups(project):
    if unified(project):
        return [(b["name"], b.get("commands", [])) for b in project["blocks"]]
    return list(project.get("blocks", {}).items()) + [
        (p["name"], p.get("commands", [])) for p in project.get("presets", [])
    ]


def references(project, identity, exclude=None):
    return [
        b["name"]
        for b in project["blocks"]
        if b["id"] != exclude
        and any(
            c.get("type", "").upper() == "BLOCK" and c.get("name") == identity
            for c in nested(b.get("commands", []))
        )
    ]


def upgrade(project):
    """Validated input only. Preserve shared definitions and collapse single-use wrappers."""
    result = copy.deepcopy(project)
    if unified(result):
        return result
    shared = result.pop("blocks")
    presets = result.pop("presets")
    uses = {name: 0 for name in shared}
    for _, commands in groups(project):
        for command in nested(commands):
            if command.get("type", "").upper() == "BLOCK":
                uses[command["name"]] += 1
    consumed = set()
    drawing = []
    for i, preset in enumerate(presets):
        block = dict(preset, id=f"draw_{i + 1}", draw=preset.get("enabled", True))
        block.pop("enabled", None)
        commands = block.get("commands", [])
        # A once-used forwarding container has no independent purpose in the new model.
        while len(commands) == 1 and commands[0].get("type", "").upper() == "BLOCK":
            call = commands[0]
            name = call["name"]
            if uses[name] != 1 or name in consumed or call.get("condition", "").strip():
                break
            consumed.add(name)
            commands = copy.deepcopy(shared[name])
        block["commands"] = commands
        drawing.append(block)
    ids = {name: f"shared_{i + 1}" for i, name in enumerate(shared)}
    names = {b["name"].casefold() for b in drawing}
    for name, commands in shared.items():
        if name in consumed:
            continue
        label = name
        suffix = 2
        while label.casefold() in names:
            label = f"{name} ({suffix})"
            suffix += 1
        names.add(label.casefold())
        drawing.append(
            dict(
                id=ids[name],
                name=label,
                draw=False,
                condition="",
                variables={},
                commands=commands,
            )
        )
    # Old presets could share display names; preserve each definition with a unique label.
    names.clear()
    for block in drawing:
        base = block["name"]
        suffix = 2
        while block["name"].casefold() in names:
            block["name"] = f"{base} ({suffix})"
            suffix += 1
        names.add(block["name"].casefold())
        block.setdefault("condition", "")
        block.setdefault("variables", {})
        for command in nested(block["commands"]):
            if command.get("type", "").upper() == "BLOCK":
                command["name"] = ids[command["name"]]
    result["blocks"] = drawing
    return result


def legacy_view(project):
    """Boundary adapter for the proven compiler/legacy validator; never persisted."""
    if not unified(project):
        return project
    result = dict(project, version=10)
    result["presets"] = [
        dict(b, enabled=b.get("draw", True)) for b in project["blocks"]
    ]
    result["blocks"] = {b["id"]: b.get("commands", []) for b in project["blocks"]}
    result["_block_definitions"] = {b["id"]: b for b in project["blocks"]}
    return result


def modern_address(project, address):
    if not address:
        return address
    if address[0] == "presets":
        return ("blocks", *address[1:])
    if address[0] == "blocks" and isinstance(address[1], str):
        return ("blocks", index_of(project, address[1]), "commands", *address[2:])
    return tuple(address)
