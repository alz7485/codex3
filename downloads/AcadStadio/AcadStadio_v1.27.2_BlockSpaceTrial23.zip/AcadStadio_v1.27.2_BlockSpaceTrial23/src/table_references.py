"""Expand explicit table/row references while leaving old @COLUMN syntax intact."""

import json
import re


# A reference can specify its table and/or a 1-based row expression.  Curly
# braces are deliberately restricted to one expression without nested braces;
# the expression can still be a variable such as @ROW or global.ROW.
REFERENCE = re.compile(
    r"(?P<table>\[(?:\\.|[^\]\\])+\])?@(?P<column>[^\W\d]\w*)"
    r"(?P<row>[{｛][^{}｛｝]*[}｝])?"
)


def _map_references(expression, replace):
    """Scan outside string literals, treating [table name] as one token."""
    result = []
    i = 0
    while i < len(expression):
        char = expression[i]
        if char in ("'", '"'):
            start, quote = i, char
            i += 1
            while i < len(expression):
                if expression[i] == "\\":
                    i += 2
                elif expression[i] == quote:
                    i += 1
                    break
                else:
                    i += 1
            result.append(expression[start:i])
            continue
        match = REFERENCE.match(expression, i)
        if match:
            result.append(replace(match))
            i = match.end()
        else:
            result.append(char)
            i += 1
    return "".join(result)


def expand_table_references(expression):
    """Translate table-qualified/row-qualified refs into private AST calls."""
    def replace(match):
        table, column, row = match.group("table", "column", "row")
        if not table and not row:
            return match.group(0)
        name = table[1:-1].replace(r"\]", "]").replace(r"\\", "\\") if table else ""
        if table and not name:
            return match.group(0)  # parser rejects invalid empty [] elsewhere
        args = [json.dumps(name, ensure_ascii=False), json.dumps(column)]
        if row is not None:
            inside = row[1:-1].strip()
            # Empty braces must not silently use the current row.
            args.append(inside if inside else "None")
        return "__table_cell__(" + ", ".join(args) + ")"

    return _map_references(expression, replace)


def is_single_table_reference(expression):
    """True for a lone reference, including a qualified or fixed-row reference."""
    return REFERENCE.fullmatch(expression) is not None


def rename_table_references(expression, old_name, new_name):
    """Change only explicit table tags, never plain text in quoted literals."""
    def replace(match):
        table = match.group("table")
        if table is None or table[1:-1].replace(r"\]", "]").casefold() != old_name.casefold():
            return match.group(0)
        escaped = new_name.replace("\\", r"\\").replace("]", r"\]")
        return "[" + escaped + "]@" + match.group("column") + (match.group("row") or "")

    return _map_references(expression, replace)


def rename_project_table_references(project, old_name, new_name):
    """Keep expression references working when the display name of a table changes."""
    def adjust(mapping):
        for key, value in mapping.items():
            if isinstance(value, str):
                mapping[key] = rename_table_references(value, old_name, new_name)

    for key in ("settings", "globals"):
        adjust(project.get(key, {}))
    from project_data import input_tables
    from table_formulas import formula_source, table_columns
    for table in input_tables(project):
        if table["rows"]:
            columns = table_columns(table)
            first = table["rows"][0]
            for column, value in first.items():
                if formula_source(value, columns) is not None:
                    first[column] = rename_table_references(value, old_name, new_name)

    def commands(items):
        for command in items:
            for key, value in command.items():
                if key in ("commands", "else") and isinstance(value, list):
                    commands(value)
                elif key == "arguments" and isinstance(value, dict):
                    adjust(value)
                elif key == "text" and isinstance(value, str):
                    if value.startswith("=") or is_single_table_reference(value):
                        command[key] = rename_table_references(value, old_name, new_name)
                elif key not in ("type", "name") and isinstance(value, str):
                    command[key] = rename_table_references(value, old_name, new_name)

    blocks = project.get("blocks", [])
    if isinstance(blocks, list):
        items = list(blocks)
    else:
        items = [{"commands": v} for v in blocks.values()]
    items += project.get("presets", [])
    for block in items:
        if isinstance(block.get("condition"), str):
            block["condition"] = rename_table_references(
                block["condition"], old_name, new_name
            )
        adjust(block.get("variables", {}))
        commands(block.get("commands", []))
