"""Two-line computed cells: result above a smaller, muted expression."""
import tkinter as tk
import time
from tkinter import ttk,font
from table_grid import GridTreeview

class FormulaGridTreeview(GridTreeview):
    def __init__(self,*args,**kwargs):
        self.formulas={}
        self.formula_cells=[]
        self.on_cell_edit=None
        self._last_formula_click=None
        super().__init__(*args,**kwargs)
        default=font.nametofont('TkDefaultFont').actual()
        self.formula_font=font.Font(root=self,family=default['family'],size=max(7,abs(default['size'])-2))
        ttk.Style(self).configure('Formula.Treeview',rowheight=52)
        self.bind('<<TreeviewSelect>>',self._queue_grid,add='+')

    def set_formulas(self,formulas):
        self.formulas=dict(formulas)
        self.configure(style='Formula.Treeview' if formulas else 'Treeview')
        self._queue_grid()

    def _forward(self,event,sequence):
        if sequence=='<B1-Motion>':self._last_formula_click=None
        if sequence in ('<ButtonPress-1>','<ButtonPress-3>'):self.focus_set()
        self.event_generate(sequence,x=event.x_root-self.winfo_rootx(),y=event.y_root-self.winfo_rooty(),
                            state=event.state,time=event.time,when='tail')
        return 'break'

    def _new_cell(self):
        frame=tk.Frame(self,borderwidth=0,takefocus=False)
        result=tk.Label(frame,borderwidth=0,anchor='center',takefocus=False)
        expression=tk.Label(frame,borderwidth=0,anchor='center',font=self.formula_font,takefocus=False)
        cell=dict(frame=frame,result=result,expression=expression,cell=None)
        for widget in (frame,result,expression):
            widget.bind('<ButtonPress-1>',lambda event,c=cell:self._press_cell(event,c))
            for seq in ('<ButtonRelease-1>','<ButtonPress-3>','<B1-Motion>'):
                widget.bind(seq,lambda event,s=seq:self._forward(event,s))
            widget.bind('<Double-1>',lambda event,c=cell:self._edit_cell(c))
            widget.bind('<MouseWheel>',lambda e:(self.yview_scroll(-1 if e.delta>0 else 1,'units'),'break')[-1])
            widget.bind('<Button-4>',lambda e:(self.yview_scroll(-1,'units'),'break')[-1])
            widget.bind('<Button-5>',lambda e:(self.yview_scroll(1,'units'),'break')[-1])
        return cell

    def _press_cell(self,event,cell):
        stamp=event.time or int(time.monotonic()*1000)
        old=self._last_formula_click
        key=cell['cell']
        if old and key==old[0] and 0<((stamp-old[1]) & 0xffffffff)<=500 and abs(event.x_root-old[2])+abs(event.y_root-old[3])<8:
            self._last_formula_click=None
            return self._edit_cell(cell)
        self._last_formula_click=(key,stamp,event.x_root,event.y_root)
        return self._forward(event,'<ButtonPress-1>')

    def _edit_cell(self,cell):
        if cell['cell'] is not None:
            row,column=cell['cell']
            self.selection_set(row)
            self.focus(row)
            if self.on_cell_edit is not None:self.on_cell_edit(row,column)
        return 'break'

    def _draw_grid(self):
        super()._draw_grid()
        if not self.winfo_exists() or not self.winfo_ismapped():
            return
        used=0
        if self.formulas:
            height,width=self.winfo_height(),self.winfo_width()
            rowheight=int(ttk.Style(self).lookup(self.cget('style'),'rowheight') or 52)
            heading=next((y for y in range(min(height,70)) if self.identify_region(4,y) in ('cell','tree')),0)
            rows={self.identify_row(min(y,height-1)) for y in range(0,height+rowheight,rowheight)}
            selected=set(self.selection())
            for row in sorted(rows):
                if not row or not self.exists(row):
                    continue
                background='white'
                for tag in self.item(row,'tags'):
                    color=self.tag_configure(tag,'background')
                    if color:background=str(color)
                if row in selected:background='#dce8ff'
                for column,expression in self.formulas.items():
                    box=self.bbox(row,column)
                    if not box:continue
                    x,y,w,h=box
                    left,top=max(0,x+1),max(heading,y+1)
                    right,bottom=min(width-1,x+w-1),min(height-1,y+h-1)
                    if right<=left or bottom<=top:continue
                    if used==len(self.formula_cells):self.formula_cells.append(self._new_cell())
                    cell=self.formula_cells[used];used+=1
                    value=self.set(row,column)
                    cell['cell']=(row,column)
                    cell['frame'].configure(bg=background)
                    cell['result'].configure(text=value,bg=background,fg='#b42318' if value=='計算エラー' else '#192c42')
                    cell['expression'].configure(text=expression,bg=background,fg='#8995a5')
                    cell['frame'].place(x=left,y=top,width=right-left,height=bottom-top)
                    cell['result'].place(x=x+1-left,y=y+3-top,width=w-2,height=24)
                    cell['expression'].place(x=x+1-left,y=y+28-top,width=w-2,height=20)
                    cell['frame'].lift()
        for cell in self.formula_cells[used:]:
            cell['frame'].place_forget();cell['cell']=None
        # Formula overlays never cover the live editor.
        for child in self.winfo_children():
            if isinstance(child,ttk.Entry):child.lift()
