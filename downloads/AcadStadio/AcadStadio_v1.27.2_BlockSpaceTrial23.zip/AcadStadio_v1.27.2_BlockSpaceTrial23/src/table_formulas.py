"""First-data-row column formulas and bounded, row-local dependency resolution."""

import re
from project_data import input_tables

QUOTED = re.compile(r'''('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")''')
COLUMN_NUMBER = re.compile(r"(?<![\w.])([0-9０-９]+)\s*列目")
TRANSLATION = str.maketrans(
    '０１２３４５６７８９＋－＊／＝（）×÷',
    '0123456789+-*/=()*/',
)
MAX_DEPENDENCY_DEPTH = 32
MAX_RESOLUTIONS = 200000


def table_columns(table):
    return list(dict.fromkeys(key for row in table['rows'] for key in row))


def formula_source(value, columns=()):
    if not isinstance(value, str):
        return None
    text = value.strip()
    if text.startswith("'"):
        return None
    if text.startswith(('=', '＝')):
        return text[1:].strip()
    if text.startswith(('変数.', 'variable.', 'global.', '@')) or re.match(r'^\[.+\]@', text):
        return text
    if any(COLUMN_NUMBER.search(part) for part in QUOTED.split(text)[::2]):
        return text
    tokens = set(re.findall(r'(?u)\b[^\W\d]\w*\b', ''.join(QUOTED.split(text)[::2])))
    if tokens.intersection(columns):
        return text
    return None


def computed_columns(table, columns=None):
    if not table['rows']:
        return {}
    columns = table_columns(table) if columns is None else columns
    return {key: expression for key, value in table['rows'][0].items()
            if (expression := formula_source(value, columns)) is not None}


def translate_columns(expression, columns, *, display=False):
    """Translate ordinal column references and full-width operators outside quotes."""
    parts = QUOTED.split(str(expression))
    for index in range(0, len(parts), 2):
        code = parts[index].translate(TRANSLATION)
        def replace(match):
            number = int(match[1])
            if not 1 <= number <= len(columns):
                raise ValueError(f'列番号は1〜{len(columns)}の範囲です: {number}列目')
            return ('' if display else '@') + columns[number - 1]
        parts[index] = COLUMN_NUMBER.sub(replace, code)
    return ''.join(parts)


def display_formula(value, table):
    source = formula_source(value, table_columns(table))
    if source is None:
        return value
    try:
        pretty = translate_columns(source, table_columns(table), display=True)
    except ValueError:
        return value
    return ('=' if str(value).strip().startswith(('=', '＝')) else '') + pretty


def is_locked_cell(table, row, column):
    return row > 0 and column in computed_columns(table)


def check_cell_input(table, row, column, value, *, columns=None, computed=None):
    columns = table_columns(table) if columns is None else columns
    computed = computed_columns(table, columns) if computed is None else computed
    if row > 0 and column in computed:
        raise ValueError(f'{column}列の2行目以降は自動計算です。式は1行目で編集してください')
    if row > 0 and formula_source(value, columns) is not None:
        raise ValueError('式・変数は1行目だけに設定してください')


class DeferredCell:
    def __init__(self, resolver, table, row, column):
        self.resolver, self.table, self.row, self.column = resolver, table, row, column

    def resolve(self):
        return self.resolver.cell(self.table, self.row, self.column)


class VariableScope(dict):
    def __init__(self, resolver, table, row):
        super().__init__(dict.fromkeys(resolver.definitions))
        self.resolver, self.table, self.row = resolver, table, row

    def __getitem__(self, key):
        if key not in self:
            raise KeyError(key)
        return self.resolver.variable(self.table, self.row, key)


class RowResolver:
    def __init__(self, project, convert, evaluate, error_type):
        self.tables = {table['name'].casefold(): table for table in input_tables(project)}
        self.definitions = project.get('globals', {})
        self.settings = {k: convert(v) for k, v in project.get('settings', {}).items()}
        self.convert, self.evaluate, self.error = convert, evaluate, error_type
        self.columns = {key: table_columns(t) for key, t in self.tables.items()}
        self.formulas = {key: computed_columns(t) for key, t in self.tables.items()}
        self.contexts, self.cache, self.stack = {}, {}, []
        self.resolutions = 0

    def context(self, table, row, *, eager=False):
        key = (table.casefold(), row)
        if key not in self.contexts:
            data = self.tables[key[0]]
            if row < 0 or (data['rows'] and row >= len(data['rows'])):
                raise self.error(f'{data["name"]} の行番号 {row + 1} は範囲外です')
            raw = data['rows'][row] if data['rows'] else {}
            values = {column: DeferredCell(self, data['name'], row, column)
                      for column in dict.fromkeys([*self.columns[key[0]], *raw])}
            scope = VariableScope(self, data['name'], row)
            self.contexts[key] = dict(
                values, __row__=values, __settings__=self.settings, __global__=scope,
                __tables__={name: t['rows'] for name, t in self.tables.items()},
                __active_table_name__=data['name'], __current_row_index__=row,
                __cell_resolver__=self.cell,
            )
        values = self.contexts[key]
        if eager:
            for name in self.definitions:
                values[name] = values['__global__'][name]
        return values

    def label(self, key):
        kind, table, row, field = key
        name = self.tables[table]['name']
        return f'[{name}] {row + 1}行目 ' + (f'変数.{field}' if kind == 'variable' else f'{field}列')

    def resolve(self, key, action):
        if key in self.cache:
            return self.cache[key]
        if key in self.stack:
            start = self.stack.index(key)
            path = self.stack[start:] + [key]
            cell = next((item for item in path if item[0] == 'cell'), None)
            location = dict(table_id=self.tables[cell[1]]['id'], row=cell[2], column=cell[3]) if cell else {}
            raise self.error('循環参照: ' + ' → '.join(self.label(item) for item in path), **location)
        if len(self.stack) >= MAX_DEPENDENCY_DEPTH:
            raise self.error(f'表・変数の参照は{MAX_DEPENDENCY_DEPTH}段までです: ' + self.label(key))
        self.resolutions += 1
        if self.resolutions > MAX_RESOLUTIONS:
            raise self.error('表・変数の計算回数が上限を超えました')
        self.stack.append(key)
        try:
            value = action()
            self.cache[key] = value
            return value
        except self.error as exc:
            if str(exc).startswith(('循環参照:', '表・変数の参照は')):
                raise
            location = dict(getattr(exc, 'location', {}))
            if key[0] == 'cell' and 'column' not in location:
                location.update(table_id=self.tables[key[1]]['id'], row=key[2], column=key[3])
            raise self.error(self.label(key) + ': ' + str(exc), **location) from exc
        finally:
            self.stack.pop()

    def expression(self, source, table, row, *, cell_formula=False):
        try:
            expression = translate_columns(source, self.columns[table.casefold()])
        except ValueError as exc:
            raise self.error(str(exc)) from exc
        values = self.context(table, row)
        if cell_formula:
            values = dict(values, __in_table_formula__=True)
        return self.evaluate(expression, values)

    def variable(self, table, row, name):
        key = ('variable', table.casefold(), row, name)
        if name not in self.definitions:
            raise self.error('未定義の変数: 変数.' + name)
        return self.resolve(key, lambda: self.expression(self.definitions[name], table, row))

    def cell(self, table, row, column):
        identity = table.casefold()
        if identity not in self.tables:
            raise self.error('入力表が見つかりません: ' + table)
        data = self.tables[identity]
        if not 0 <= row < len(data['rows']):
            raise self.error(f'{data["name"]} の行番号 {row + 1} は範囲外です')
        if column not in data['rows'][row] and column not in self.formulas[identity]:
            raise self.error(f'{data["name"]} の{row + 1}行目に列 {column} がありません')
        key = ('cell', identity, row, column)
        def calculate():
            raw = data['rows'][row].get(column, '')
            if row > 0 and formula_source(raw, self.columns[identity]) is not None:
                raise self.error('式・変数は1行目だけに設定してください')
            if column in self.formulas[identity]:
                return self.expression(self.formulas[identity][column], table, row, cell_formula=True)
            if isinstance(raw, str) and raw.startswith("'"):
                raw = raw[1:]
            return self.convert(raw)
        return self.resolve(key, calculate)
