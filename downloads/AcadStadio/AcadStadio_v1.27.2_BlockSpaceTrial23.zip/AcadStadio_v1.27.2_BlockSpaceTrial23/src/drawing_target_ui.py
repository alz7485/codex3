"""Shared single-row control and a staged checkbox list for drawing targets."""

import tkinter as tk
from tkinter import ttk, messagebox
from project_data import parse_row_number, row_title, title_table, target_settings
from table_grid import GridTreeview
from theme import fit_window


class DrawingTargetControls(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.columnconfigure(3, weight=1)
        ttk.Radiobutton(self, text="行番号", variable=app.scope, value="range").grid(
            row=0, column=0, sticky="w"
        )
        self.spin = ttk.Spinbox(
            self,
            from_=1,
            to=max(1, len(app.rows)),
            increment=1,
            textvariable=app.row_range,
            width=5,
            wrap=False,
        )
        self.spin.grid(row=0, column=1, sticky="w", padx=(0, 5))
        self.total = ttk.Label(self, style="Muted.TLabel")
        self.total.grid(row=0, column=2, sticky="w", padx=(0, 8))
        self.title = tk.StringVar()
        self.title_label = ttk.Label(self, textvariable=self.title, wraplength=205)
        self.title_label.grid(row=0, column=3, sticky="ew")
        self.title_label.bind("<Enter>", self.show_title)
        self.title_label.bind("<Leave>", lambda e: app.icons.hide())
        ttk.Radiobutton(
            self, text="チェックした行", variable=app.scope, value="selected"
        ).grid(row=1, column=0, sticky="w", pady=(7, 0))
        self.choose = ttk.Button(
            self,
            text="選択行…",
            command=lambda: app.choose_drawing_rows(self.winfo_toplevel()),
            style="Compact.TButton",
        )
        self.choose.grid(row=1, column=1, columnspan=2, sticky="w", pady=(7, 0))
        self.checked = ttk.Label(self, style="Muted.TLabel")
        self.checked.grid(row=1, column=3, sticky="w", pady=(7, 0))
        self.note = ttk.Label(self, style="Muted.TLabel", wraplength=375)
        self.note.grid(row=2, column=0, columnspan=4, sticky="w", pady=(6, 0))
        app._target_controls.append(self)
        self.bind("<Destroy>", self.destroyed)

    def destroyed(self, event):
        if event.widget is self and self in self.app._target_controls:
            self.app._target_controls.remove(self)

    def show_title(self, event):
        table, column = title_table(self.app.data)
        self.app.icons.schedule(
            self.title_label,
            f"入力表1「{table['name']}」 / {column or '左端列なし'}\n{getattr(self, 'full_title', self.title.get())[:1024]}",
        )

    def sync(self):
        count = len(self.app.rows)
        single = self.app.scope.get() == "range"
        self.spin.configure(
            to=max(1, count), state="normal" if single and count else "disabled"
        )
        self.total.configure(text=f"/ {count}行")
        self.checked.configure(
            text=f"{len(target_settings(self.app.data)['selected'])}行チェック"
        )
        if single:
            try:
                index = parse_row_number(self.app.row_range.get(), count)
                full = row_title(self.app.data, index)
                self.full_title = full
                display = " ".join(full.splitlines())
                self.title.set(
                    "タイトル: "
                    + (display if len(display) <= 22 else display[:21] + "…")
                )
                self.note.configure(
                    text="タイトルは入力表1の左端列を表示します", foreground="#67788d"
                )
            except ValueError as exc:
                self.full_title = str(exc)
                self.title.set("タイトル: —")
                self.note.configure(text=str(exc), foreground="#b42318")
        else:
            self.full_title = "行番号モードで1行を指定すると、タイトルを表示します"
            self.title.set("タイトル: —")
            self.note.configure(
                text="「選択行…」のチェックリストで作図する行を指定します",
                foreground="#67788d",
            )


class RowSelectionDialog:
    def __init__(self, app, parent):
        self.app = app
        from engine import RowResolver, convert, evaluate, MacroError
        self.resolver = RowResolver(app.data, convert, evaluate, MacroError)
        self.project = app.data
        self.table_id = app.data["active_table"]
        self.table, self.column = title_table(app.data)
        self.limit = min(len(self.table["rows"]), len(app.rows))
        self.checked = set(
            i for i in target_settings(app.data)["selected"] if i < self.limit
        )
        self.win = tk.Toplevel(parent)
        self.win.title("選択行 — 作図対象")
        self.win.transient(parent)
        fit_window(self.win, 620, 600, 520, 420)
        self.previous_grab = app.root.grab_current()
        self.win.grab_set()
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        self.win.bind("<Escape>", lambda e: self.cancel())
        self.win.bind("<Control-Return>", lambda e: self.apply())
        header = ttk.Frame(self.win, padding=(16, 14, 16, 6))
        header.pack(fill="x")
        ttk.Label(header, text="作図する行にチェック", style="Section.TLabel").pack(
            anchor="w"
        )
        ttk.Label(
            header,
            text=f"入力表1: {self.table['name']} / タイトル: {self.column or '左端列なし'}",
            wraplength=560,
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(5, 0))
        footer = ttk.Frame(self.win, padding=(16, 8, 16, 14))
        footer.pack(side="bottom", fill="x")
        ttk.Button(footer, text="キャンセル", command=self.cancel).pack(side="right")
        self.apply_button = ttk.Button(
            footer,
            text="チェックした行を適用",
            command=self.apply,
            style="Primary.TButton",
        )
        self.apply_button.pack(side="right", padx=(0, 8))
        toolbar = ttk.Frame(self.win, padding=(16, 4, 16, 8))
        toolbar.pack(fill="x")
        ttk.Button(
            toolbar,
            text="すべてチェック",
            command=self.check_all,
            style="Compact.TButton",
        ).pack(side="left")
        ttk.Button(
            toolbar, text="すべて外す", command=self.clear_all, style="Compact.TButton"
        ).pack(side="left", padx=6)
        self.count = tk.StringVar()
        ttk.Label(toolbar, textvariable=self.count, style="Muted.TLabel").pack(
            side="right"
        )
        area = ttk.Frame(self.win, padding=(16, 0, 16, 0))
        area.pack(fill="both", expand=True)
        area.rowconfigure(0, weight=1)
        area.columnconfigure(0, weight=1)
        self.tree = GridTreeview(
            area,
            columns=("check", "row", "title"),
            show="headings",
            selectmode="browse",
        )
        self.tree.heading("check", text="選択")
        self.tree.column("check", width=48, stretch=False, anchor="center")
        self.tree.heading("row", text="行番号")
        self.tree.column("row", width=65, stretch=False, anchor="center")
        self.tree.heading("title", text="タイトル")
        self.tree.column("title", width=420, minwidth=200)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(area, command=self.tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(area, orient="horizontal", command=self.tree.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=scroll.set, xscrollcommand=horizontal.set)
        self.tree.tag_configure("unavailable", foreground="#9ca8b6")
        for i in range(len(self.table["rows"])):
            self.tree.insert(
                "",
                "end",
                iid=str(i),
                values=(self.mark(i), i + 1, self.display_title(i)),
                tags=("unavailable",) if i >= self.limit else (),
            )
        self.tree.bind("<ButtonRelease-1>", self.click)
        self.tree.bind("<space>", self.toggle_focused)
        note = "クリック / Spaceで切替。適用するまで作図対象は変わりません。"
        if self.limit < len(self.table["rows"]):
            note += " 作図に使用する入力表に存在しない行は選べません。"
        ttk.Label(
            self.win, text=note, style="Muted.TLabel", wraplength=560, padding=(16, 8)
        ).pack(fill="x")
        self.update_count()
        self.tree.focus_set()

    def display_title(self, i):
        return row_title(self.app.data, i, resolver=self.resolver)

    def mark(self, i):
        return "—" if i >= self.limit else "☑" if i in self.checked else "☐"

    def update_count(self):
        self.count.set(f"{len(self.checked)} / {len(self.table['rows'])}行チェック")

    def toggle(self, i):
        if not 0 <= i < self.limit:
            return
        if i in self.checked:
            self.checked.remove(i)
        else:
            self.checked.add(i)
        self.tree.set(str(i), "check", self.mark(i))
        self.update_count()

    def click(self, event):
        row = self.tree.identify_row(event.y)
        if row and self.tree.identify_region(event.x, event.y) == "cell":
            self.tree.focus(row)
            self.tree.selection_set(row)
            self.toggle(int(row))

    def toggle_focused(self, event=None):
        row = self.tree.focus()
        if row:
            self.toggle(int(row))
        return "break"

    def check_all(self):
        self.checked = set(range(self.limit))
        self.render_checks()

    def clear_all(self):
        self.checked.clear()
        self.render_checks()

    def render_checks(self):
        for i in range(len(self.table["rows"])):
            self.tree.set(str(i), "check", self.mark(i))
        self.update_count()

    def apply(self):
        if (
            self.app.data is not self.project
            or self.app.data["active_table"] != self.table_id
        ):
            messagebox.showerror(
                "選択行",
                "入力表が変更されました。リストを開き直してください。",
                parent=self.win,
            )
            return
        self.app.set_checked_rows(sorted(self.checked))
        self.cancel()

    def cancel(self):
        self.win.destroy()
        if self.previous_grab is not None and self.previous_grab.winfo_exists():
            self.previous_grab.grab_set()


class DrawingTableTargets(ttk.Frame):
    """Read-only table tabs with staged drawing checks, separate from preview rows."""

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.project = None
        self.snapshot = []
        self.targets = {}
        self.views = {}
        self.checked = {}
        ttk.Label(self, text="入力表から対象を選ぶ（適用ボタンで反映）", style="Section.TLabel").pack(anchor="w", pady=(0, 8))
        tools = ttk.Frame(self)
        tools.pack(fill="x", pady=(0, 6))
        ttk.Button(tools, text="すべてチェック", style="Compact.TButton", command=self.check_all).pack(side="left")
        ttk.Button(tools, text="すべて外す", style="Compact.TButton", command=self.clear_all).pack(side="left", padx=6)
        self.count = tk.StringVar()
        ttk.Label(tools, textvariable=self.count, style="Muted.TLabel").pack(side="right")
        self.tabs = ttk.Notebook(self)
        self.tabs.enable_traversal()
        self.tabs.pack(fill="both", expand=True)
        self.tabs.bind("<<NotebookTabChanged>>", self.tab_changed)
        footer = ttk.Frame(self)
        footer.pack(side="bottom", fill="x", pady=(8, 0), before=self.tabs)
        ttk.Label(footer, text="クリック / Spaceでチェック。適用すると、使用する入力表もこの表に切り替わります。", style="Muted.TLabel", wraplength=650).pack(anchor="w")
        ttk.Button(footer, text="この表のチェック行を作図対象にする", style="Primary.TButton", command=self.apply).pack(anchor="e", pady=(6, 0))
        self.refresh()

    def refresh(self):
        import copy
        from project_data import input_tables
        tables = input_tables(self.app.data)
        targets = self.app.data["drawing"]["targets"]
        if self.project is self.app.data and self.snapshot == tables and self.targets == targets:
            return
        selected = self.selected_table_id() if self.project is self.app.data else None
        self.project = self.app.data
        self.snapshot = copy.deepcopy(tables)
        self.targets = copy.deepcopy(targets)
        for page in list(self.tabs.tabs()):
            self.tabs.nametowidget(page).destroy()
        self.views.clear()
        self.checked.clear()
        from project_data import parse_row_number
        for table in self.snapshot:
            page = ttk.Frame(self.tabs)
            self.tabs.add(page, text=table["name"])
            target = targets[table["id"]]
            if target["mode"] == "range":
                try:
                    checks = {parse_row_number(target["range"], len(table["rows"]))}
                except ValueError:
                    checks = set()
            else:
                checks = {i for i in target["selected"] if 0 <= i < len(table["rows"])}
            self.checked[table["id"]] = checks
            self.views[table["id"]] = dict(page=page, table=table, tree=None)
        wanted = selected if selected in self.views else self.app.data["active_table"]
        if wanted in self.views:
            self.tabs.select(self.views[wanted]["page"])
        self.tab_changed()

    def selected_table_id(self):
        page = self.tabs.select()
        return next((key for key, view in self.views.items() if str(view["page"]) == page), None)

    def tab_changed(self, event=None):
        key = self.selected_table_id()
        if key is None:
            return
        view = self.views[key]
        if view["tree"] is None:
            self.build_table(view)
        self.render_checks()

    def build_table(self, view):
        from table_formulas import table_columns, computed_columns, display_formula
        from formula_grid import FormulaGridTreeview
        from engine import RowResolver, convert, evaluate, MacroError
        table, page = view["table"], view["page"]
        columns = table_columns(table)
        identifiers = [f"value_{i}" for i in range(len(columns))]
        tree = FormulaGridTreeview(page, columns=["check", "row", *identifiers], show="headings", selectmode="extended")
        view["tree"] = tree
        for key, label, width in [("check", "選択", 48), ("row", "行", 44), *[(key, label, 100) for key, label in zip(identifiers, columns)]]:
            tree.heading(key, text=label)
            tree.column(key, width=width, minwidth=width, stretch=False, anchor="center")
        page.columnconfigure(0, weight=1)
        page.rowconfigure(0, weight=1)
        tree.grid(row=0, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(page, command=tree.yview)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(page, orient="horizontal", command=tree.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        formulas = computed_columns(table, columns)
        tree.set_formulas({key: display_formula(table['rows'][0][column], table) for key, column in zip(identifiers, columns) if column in formulas})
        resolver = RowResolver(self.app.data, convert, evaluate, MacroError) if formulas else None
        for i, row in enumerate(table["rows"]):
            cells = []
            for column in columns:
                value = row.get(column, "")
                if column in formulas:
                    try:
                        value = resolver.cell(table["name"], i, column)
                        if type(value) in (int, float):
                            value = format(value, ".12g")
                    except MacroError:
                        value = "計算エラー"
                cells.append(value)
            tree.insert("", "end", iid=str(i), values=("", i + 1, *cells))
        tree.bind("<ButtonRelease-1>", self.click)
        tree.bind("<space>", self.toggle_selected)

    def click(self, event):
        tree = event.widget
        row = tree.identify_row(event.y)
        if row and tree.identify_region(event.x, event.y) == "cell":
            self.toggle([int(row)])

    def toggle_selected(self, event):
        self.toggle([int(row) for row in event.widget.selection()])
        return "break"

    def toggle(self, rows):
        key = self.selected_table_id()
        if key is None:
            return
        for i in rows:
            if i in self.checked[key]:
                self.checked[key].remove(i)
            else:
                self.checked[key].add(i)
        self.render_checks()

    def check_all(self):
        key = self.selected_table_id()
        if key is not None:
            self.checked[key] = set(range(len(self.views[key]["table"]["rows"])))
            self.render_checks()

    def clear_all(self):
        key = self.selected_table_id()
        if key is not None:
            self.checked[key].clear()
            self.render_checks()

    def render_checks(self):
        key = self.selected_table_id()
        if key is None:
            return
        tree = self.views[key]["tree"]
        if tree is None:
            return
        for row in tree.get_children():
            tree.set(row, "check", "☑" if int(row) in self.checked[key] else "☐")
        self.count.set(f"{len(self.checked[key])} / {len(self.views[key]['table']['rows'])}行チェック")

    def apply(self):
        from project_data import input_tables
        self.app.table_editor.finish()
        if self.project is not self.app.data or self.snapshot != input_tables(self.app.data):
            self.refresh()
            messagebox.showinfo("作図対象", "入力表が変更されたため再読み込みしました。行を確認してください。", parent=self.winfo_toplevel())
            return
        key = self.selected_table_id()
        if key is None:
            return
        rows = sorted(self.checked[key])
        self.app.set_checked_rows(rows, table_id=key)
        self.refresh()
