"""Declarative, optional CAD setup macro and reusable named drawing resources."""

import json
import math
import re
from cad_state import BASE_VARIABLES

SECTIONS = {
    "linetypes": (
        "線種名",
        [("name", "線種名", "DASHED"), ("file", "LINファイル", "acad.lin")],
    ),
    "text_styles": (
        "文字スタイル",
        [
            ("name", "スタイル名", "CF_TEXT"),
            ("font", "フォントファイル", "arial.ttf"),
            ("width", "幅係数", "1"),
            ("oblique", "傾斜角度（°）", "0"),
        ],
    ),
    "layers": (
        "レイヤー",
        [
            ("name", "レイヤー名", "PARTS"),
            ("color", "色（ACI）", "7"),
            ("linetype", "線種", "Continuous"),
            ("lineweight", "線の太さ", "-3"),
            ("plot", "印刷する", True),
        ],
    ),
    "dim_styles": (
        "寸法スタイル",
        [
            ("name", "スタイル名", "CF_DIM"),
            ("base", "元のスタイル（空欄は引継ぎ）", ""),
            ("text_style", "文字スタイル（空欄は引継ぎ）", ""),
            ("scale", "寸法尺度", "1"),
            ("text_height", "文字高さ（図面単位）", "3.5"),
            ("arrow_size", "矢印サイズ（図面単位）", "2.5"),
        ],
    ),
}
STYLE_FIELDS = {
    "linetype": "linetypes",
    "text_style": "text_styles",
    "dim_style": "dim_styles",
    "layer": "layers",
}


def default_setup(legacy=False):
    return dict(enabled=False, legacy_make_layers=legacy, **{k: [] for k in SECTIONS})


def cad_name(value):
    """CAD resource names may contain ordinary or Japanese full-width spaces."""
    return (
        isinstance(value, str)
        and 0 < len(value) <= 255
        and bool(value.strip())
        and not re.search(r'[";<>/\\:*?|=\x00-\x1f\x7f]', value)
        and all(not c.isspace() or c in " \u3000" for c in value)
    )


def script_cad_name(value):
    """Keep a spaced name in a single SCR argument without changing its spelling."""
    return lisp_string(value) if " " in value or "\u3000" in value else value


def validate_setup(setup):
    if not isinstance(setup, dict):
        return ["CAD初期設定の形式が不正です"]
    if (
        type(setup.get("enabled", False)) is not bool
        or type(setup.get("legacy_make_layers", False)) is not bool
    ):
        return ["CAD初期設定の切替は真偽値にしてください"]
    errors = []
    for key, (title, fields) in SECTIONS.items():
        rows = setup.get(key, [])
        if not isinstance(rows, list) or len(rows) > 100:
            errors.append(title + ": 100件までの配列にしてください")
            continue
        names = set()
        for row in rows:
            if not isinstance(row, dict):
                errors.append(title + ": 項目の形式が不正です")
                continue
            if key == "linetypes" and type(row.get("existing_only", False)) is not bool:
                errors.append(title + ": 線種参照の指定が不正です")
            name = row.get("name", "")
            if not cad_name(name) or name.casefold() in names:
                errors.append(title + ": 名前が不正または重複しています")
            else:
                names.add(name.casefold())
            for field, label, default in fields:
                if key == "linetypes" and field == "file" and row.get("existing_only", False):
                    continue
                value = row.get(field, default)
                if field == "plot":
                    if type(value) is not bool:
                        errors.append(title + " / 印刷する: 真偽値で指定してください")
                    continue
                if (
                    not isinstance(value, (str, int, float))
                    or isinstance(value, bool)
                    or len(str(value)) > 1024
                    or any(ord(c) < 32 or ord(c) == 127 for c in str(value))
                ):
                    errors.append(title + " / " + label + ": 値の形式が不正です")
                    continue
                if field in (
                    "width",
                    "oblique",
                    "scale",
                    "text_height",
                    "arrow_size",
                    "color",
                    "lineweight",
                ):
                    try:
                        n = float(value)
                        if not math.isfinite(n) or abs(n) > 1e9:
                            raise ValueError()
                        if field == "oblique" and not -85 <= n <= 85:
                            raise ValueError()
                        if (
                            field in ("width", "scale", "text_height", "arrow_size")
                            and n <= 0
                        ):
                            raise ValueError()
                        if field == "color" and (n != int(n) or not 1 <= n <= 255):
                            raise ValueError()
                        if field == "lineweight" and n not in (
                            -3,
                            0,
                            5,
                            9,
                            13,
                            15,
                            18,
                            20,
                            25,
                            30,
                            35,
                            40,
                            50,
                            53,
                            60,
                            70,
                            80,
                            90,
                            100,
                            106,
                            120,
                            140,
                            158,
                            200,
                            211,
                        ):
                            raise ValueError()
                    except (ValueError, TypeError, OverflowError):
                        errors.append(
                            title + " / " + label + ": 数値の範囲を確認してください"
                        )
                elif field in ("base", "text_style", "linetype"):
                    if field == "linetype" and not str(value):
                        errors.append(title + " / " + label + ": 線種名が必要です")
                    elif str(value) and not cad_name(value):
                        errors.append(title + " / " + label + ": 名前が不正です")
                elif field in ("font", "file") and not str(value).strip():
                    errors.append(title + " / " + label + ": ファイル名が必要です")
                elif field in ("font", "file") and (
                    not isinstance(value, str) or len(value) > 512
                ):
                    errors.append(
                        title + " / " + label + ": ファイル名は512文字までです"
                    )
    if not errors:
        try:
            ordered_dim_styles(setup.get("dim_styles", []))
        except ValueError as exc:
            errors.append(str(exc))
    return list(dict.fromkeys(errors))[:100]


def ordered_dim_styles(rows):
    by_name = {row["name"].casefold(): row for row in rows}
    result, visiting, done = [], set(), set()

    def visit(key):
        if key in visiting:
            raise ValueError("寸法スタイルの元スタイルが循環しています")
        if key in done:
            return
        visiting.add(key)
        base = str(by_name[key].get("base", "")).casefold()
        if base in by_name:
            visit(base)
        visiting.remove(key)
        done.add(key)
        result.append(by_name[key])

    for key in by_name:
        visit(key)
    return result


def names(project, section):
    return [row["name"] for row in project.get("cad_setup", {}).get(section, [])]


def lisp_string(value):
    return json.dumps(str(value), ensure_ascii=False)


def initial_macro(setup, force=False):
    if not setup.get("enabled", False) and not force:
        return []
    errors = validate_setup(setup)
    if errors:
        raise ValueError("\n".join(errors[:12]))
    q = lisp_string
    body = []
    for row in setup.get("linetypes", []):
        if row.get("existing_only", False):
            continue
        n = q(row["name"])
        body.append(
            f'(if (not (tblsearch "LTYPE" {n})) (command-s "_.-LINETYPE" "_Load" {n} {q(row.get("file", "acad.lin"))} ""))'
        )
    for row in setup.get("text_styles", []):
        n = q(row["name"])
        width = float(row.get("width", 1))
        angle = math.radians(float(row.get("oblique", 0)))
        body.append(
            f"""(if (not (tblsearch "STYLE" {n})) (if (not (entmake (list '(0 . "STYLE") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbTextStyleTableRecord") (cons 2 {n}) '(70 . 0) '(40 . 0.0) (cons 41 {width:.12g}) (cons 50 {angle:.12g}) '(71 . 0) '(42 . 2.5) (cons 3 {q(row.get("font", "arial.ttf"))}) '(4 . "")))) (error "AcadStadio: Cannot create text style")))"""
        )
    for row in setup.get("layers", []):
        n = q(row["name"])
        lt = q(row.get("linetype", "Continuous"))
        body.append(
            f"""(if (not (tblsearch "LAYER" {n})) (progn (if (not (tblsearch "LTYPE" {lt})) (error "AcadStadio: Load the layer linetype first")) (if (not (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord") (cons 2 {n}) '(70 . 0) (cons 62 {int(float(row.get("color", 7)))}) (cons 6 {lt}) (cons 370 {int(float(row.get("lineweight", -3)))}) (cons 290 {1 if row.get("plot", True) else 0})))) (error "AcadStadio: Cannot create layer"))))"""
        )
    for row in ordered_dim_styles(setup.get("dim_styles", [])):
        n = q(row["name"])
        operations = []
        if row.get("base"):
            operations.append(f'(command-s "_.-DIMSTYLE" "_Restore" {q(row["base"])})')
        for field, var, default in [
            ("scale", "DIMSCALE", 1),
            ("text_height", "DIMTXT", 3.5),
            ("arrow_size", "DIMASZ", 2.5),
        ]:
            operations.append(f'(setvar "{var}" {float(row.get(field, default)):.12g})')
        if row.get("text_style"):
            operations.append(f'(setvar "DIMTXSTY" {q(row["text_style"])})')
        operations.append(f'(command-s "_.-DIMSTYLE" "_Save" {n})')
        body.append(
            f'(if (not (tblsearch "DIMSTYLE" {n})) (progn '
            + " ".join(operations)
            + "))"
        )
    dim_names = " ".join(q(n) for n in BASE_VARIABLES if n.startswith("DIM"))
    forms = [
        '(setq ds (getvar "DIMSTYLE"))',
        f"(setq vals (vl-remove-if 'null (mapcar '(lambda (n / v) (setq v (getvar n)) (if v (cons n v))) '({dim_names}))))",
        *body,
        '(command-s "_.-DIMSTYLE" "_Restore" ds)',
        "(foreach p vals (if (not (equal (getvar (car p)) (cdr p))) (setvar (car p) (cdr p))))",
        "(princ)",
    ]
    if not setup.get("dim_styles"):
        forms = [*body, "(princ)"]
    # Build one callable macro from quoted forms, with complete short SCR lines.
    lines = [
        "; AcadStadio CAD initialization macro (existing definitions are kept).",
        "(progn (setq *cadflow-init-body* nil) (princ))",
        *(
            "(progn (setq *cadflow-init-body* (append *cadflow-init-body* (list '"
            + form
            + "))) (princ))"
            for form in forms
        ),
        "(progn (eval (append (list 'defun 'c:CADFLOWINIT '(/ ds vals p)) *cadflow-init-body*)) (setq *cadflow-init-body* nil) (princ))",
        "(c:CADFLOWINIT)",
    ]
    if any(len(line) > 2048 for line in lines):
        raise ValueError(
            "CAD初期設定の1行が2048文字を超えました。名前・パスを短くしてください"
        )
    return lines
