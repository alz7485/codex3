from table_grid import GridTreeview
"""Folder organization and search for the ordered block collection.

Folders only classify blocks. Drawing always follows the global block number.
"""

import copy
import unicodedata
import tkinter as tk
from tkinter import font, messagebox, simpledialog, ttk

from block_folders import (
    assign_blocks,
    create_folder,
    delete_folder,
    descendant_ids,
    folder_path,
    folders,
    move_folder,
    rename_folder,
)
from project_model import validate_project
from theme import ROOT, fit_window


FOLDER_PREFIX = "folder:"
UNFILED = FOLDER_PREFIX  # Empty IDs are forbidden, so this cannot collide with a folder.


def search_text(value):
    return unicodedata.normalize("NFKC", str(value)).casefold()


class BlockBrowser(ttk.Frame):
    def __init__(
        self, parent, project_getter, on_changed, *, on_selection=None, icons=None,
        on_preview_changed=None, actions_parent=None,
    ):
        super().__init__(parent)
        self.project_getter = project_getter
        self.on_changed = on_changed
        self.on_selection = on_selection
        self.on_preview_changed = on_preview_changed
        self.hidden_preview_ids = set()
        self.search = tk.StringVar()
        self.summary = tk.StringVar()
        self._block_ids = {}
        self._open = {}
        self._filtering = False
        self._refreshing = False
        self._suspend_search = False
        self._drag = None
        self._document = None
        self._folder_image = (
            icons.get("folder")
            if icons
            else tk.PhotoImage(master=self, file=str(ROOT / "assets/toolbar/folder.png"))
        )
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        toolbar = ttk.Frame(self)
        toolbar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 2))
        self.menu = tk.Menu(self, tearoff=False, postcommand=self.prepare_menu)
        self.visibility_button = ttk.Menubutton(
            actions_parent if actions_parent is not None else toolbar,
            text="表示 ▾", style="Eye.TMenubutton", width=2,
        )
        self.visibility_button.icon_button_style = "Eye.TMenubutton"
        self.visibility_button.icon_button_width = 2
        self.visibility_button.pack(side="left", padx=(0, 6))
        self.visibility_menu = tk.Menu(
            self.visibility_button, tearoff=False, postcommand=self.prepare_visibility_menu
        )
        self.visibility_button.configure(menu=self.visibility_menu)
        self.search_entry = ttk.Entry(toolbar, textvariable=self.search, width=8)
        self.search_entry.bind("<Escape>", lambda e: self.clear_search())
        self.search_clear = ttk.Button(toolbar, text="×", width=2, style="Compact.TButton", command=self.clear_search)
        self.search_hint = ttk.Label(self.search_entry, text="⌕  ブロックを検索", foreground="#67788d", background="white")
        self.search_hint.bind("<Button-1>", lambda e: self.search_entry.focus_set())
        self.search_entry.bind("<FocusIn>", self.update_search_hint)
        self.search_entry.bind("<FocusOut>", self.update_search_hint)
        self.search_entry.pack(side="left", fill="x", expand=True)
        self.tree = GridTreeview(
            self,
            columns=("name", "visible"),
            show="tree headings",
            selectmode="extended",
            height=4,
            style="Compact.Treeview",
        )
        self.tree.heading("#0", text="順")
        self.tree.column("#0", width=60, minwidth=60, stretch=False)
        self.tree.heading("name", text="ブロック名")
        self.tree.column("name", width=150, minwidth=100, stretch=True)
        self.tree.heading("visible", text="表示")
        self.tree.column("visible", width=44, minwidth=44, stretch=False, anchor="center")
        self.tree.grid(row=1, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(self, command=self.tree.yview)
        vertical.grid(row=1, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        horizontal.grid(row=2, column=0, sticky="ew")
        self.horizontal_scroll = horizontal
        self.tree.configure(yscrollcommand=vertical.set, xscrollcommand=self.update_horizontal_scroll)
        ttk.Label(self, textvariable=self.summary, style="Muted.TLabel").grid(
            row=3, column=0, columnspan=2, sticky="w"
        )
        self.tree.tag_configure("folder", foreground="#52657d")
        self.tree.tag_configure("preview_hidden", foreground="#8a96a5")
        self.tree.bind("<ButtonPress-1>", self.click_visibility)
        self.tree.bind("<Double-1>", self.double_visibility)
        self.tree.bind("<space>", self.toggle_selection_visibility)
        self.tree.bind("<<TreeviewSelect>>", self.selection_changed)
        self.tree.bind("<Button-3>", self.context_menu)
        self.tree.bind("<F2>", self.rename_selected)
        self.tree.bind("<Return>", self.toggle_selected_folder, add="+")
        self.tree.bind("<Delete>", self.delete_selected_folder)
        self.tree.bind("<ButtonPress-1>", self.drag_start, add="+")
        self.tree.bind("<B1-Motion>", self.drag_motion, add="+")
        self.tree.bind("<ButtonRelease-1>", self.drag_end, add="+")
        self.search.trace_add("write", self._search_changed)
        self.update_search_hint()

    def update_horizontal_scroll(self, first, last):
        self.horizontal_scroll.set(first, last)
        if float(first) <= 0 and float(last) >= 1:
            self.horizontal_scroll.grid_remove()
        else:
            self.horizontal_scroll.grid()

    def update_search_hint(self, *_):
        if self.search.get():
            self.search_hint.place_forget()
            self.search_clear.pack(side="right", padx=(3, 0), before=self.search_entry)
        else:
            self.search_clear.pack_forget()
            if self.search_entry.focus_get() is self.search_entry:
                self.search_hint.place_forget()
            else:
                self.search_hint.place(x=7, rely=0.5, anchor="w")

    def _search_changed(self, *_):
        self.update_search_hint()
        if not self._suspend_search:
            self.refresh()

    def reset_view(self):
        """Start a new document with no inherited search, selection or collapsed folders."""
        self._suspend_search = True
        try:
            self.search.set("")
        finally:
            self._suspend_search = False
        self._open.clear()
        self.hidden_preview_ids.clear()
        self._block_ids.clear()
        self._filtering = False
        self.tree.selection_remove(self.tree.selection())

    def get_view(self):
        if not self._filtering:
            self._remember_open()
        selected = self.tree.selection()
        return {
            "query": self.search.get(),
            "hidden_preview_ids": sorted(self.hidden_preview_ids),
            "closed": [node[len(FOLDER_PREFIX):] for node, opened in self._open.items() if not opened],
            "selected_blocks": [self._block_ids[node] for node in selected if node in self._block_ids],
            "selected_folder": self.selected_folder()
            if len(selected) == 1 and selected[0].startswith(FOLDER_PREFIX)
            else None,
        }

    def restore_view(self, state):
        if not isinstance(state, dict):
            return
        hidden = state.get("hidden_preview_ids", [])
        self.hidden_preview_ids = {
            identity for identity in hidden if isinstance(identity, str)
        } if isinstance(hidden, list) else set()
        closed = state.get("closed", [])
        if isinstance(closed, list):
            self._open = {FOLDER_PREFIX + identity: False for identity in closed if isinstance(identity, str)}
        query = state.get("query", "")
        self._suspend_search = True
        try:
            self.search.set(query[:500] if isinstance(query, str) else "")
        finally:
            self._suspend_search = False
        # Skip collecting the old tree's expansion over the saved preferences.
        self._filtering = True
        self.refresh()
        selected_ids = state.get("selected_blocks", [])
        if not isinstance(selected_ids, list):
            selected_ids = []
        selected = [node for node, identity in self._block_ids.items() if identity in selected_ids]
        if selected:
            self.tree.selection_set(selected)
            self.tree.focus(selected[0])
        elif isinstance(state.get("selected_folder"), str):
            self.select_folder(state["selected_folder"])

    def clear_search(self):
        self.search.set("")
        return "break"

    def selected_indices(self):
        return sorted(
            int(node)
            for node in self.tree.selection()
            if node.isdigit() and int(node) < len(self.project_getter()["blocks"])
        )

    def selected_folder(self):
        selected = self.tree.selection()
        node = self.tree.focus()
        if node not in selected:
            node = selected[0] if selected else ""
        if node == UNFILED:
            return ""
        if node.startswith(FOLDER_PREFIX):
            return node[len(FOLDER_PREFIX) :]
        if node.isdigit():
            blocks = self.project_getter()["blocks"]
            if int(node) < len(blocks):
                return blocks[int(node)].get("folder_id", "")
        return ""

    def _real_folder_selection(self):
        selected = self.tree.selection()
        if len(selected) == 1 and selected[0].startswith(FOLDER_PREFIX) and selected[0] != UNFILED:
            return selected[0][len(FOLDER_PREFIX) :]
        return None

    def selection_changed(self, event=None):
        if not self._refreshing and self.on_selection:
            self.on_selection(event)

    def _remember_open(self):
        for node in self._folder_nodes():
            self._open[node] = bool(self.tree.item(node, "open"))

    def _folder_nodes(self):
        result = []
        pending = list(self.tree.get_children())
        while pending:
            node = pending.pop()
            if node.startswith(FOLDER_PREFIX):
                result.append(node)
            pending.extend(self.tree.get_children(node))
        return result

    def refresh(self, project=None, selected_index=None):
        project = project if project is not None else self.project_getter()
        self._document = project
        self.hidden_preview_ids.intersection_update(b["id"] for b in project["blocks"])
        selected_ids = {
            self._block_ids[node]
            for node in self.tree.selection()
            if node in self._block_ids
        }
        selected_folders = {
            node for node in self.tree.selection() if node.startswith(FOLDER_PREFIX)
        }
        if not self._filtering:
            self._remember_open()
        tokens = search_text(self.search.get()).split()
        filtering = bool(tokens)
        records = folders(project)
        by_id = {item["id"]: item for item in records}
        paths = {identity: folder_path(project, identity) for identity in by_id}
        depths = []
        for identity in by_id:
            seen = set()
            while identity in by_id and identity not in seen:
                seen.add(identity)
                identity = by_id[identity].get("parent_id", "")
            depths.append(len(seen))
        indent = int(ttk.Style(self).lookup("Treeview", "indent") or 20)
        number_width = font.nametofont("TkDefaultFont").measure(str(len(project["blocks"])))
        self.tree.column("#0", width=max(72, (max(depths, default=0) + 1) * indent + number_width + 16))
        matches = []
        visible_folders = set()

        def include_ancestors(identity):
            seen = set()
            while identity and identity not in seen and identity in by_id:
                seen.add(identity)
                visible_folders.add(identity)
                identity = by_id[identity].get("parent_id", "")

        for index, block in enumerate(project["blocks"]):
            identity = block.get("folder_id", "")
            haystack = search_text(
                " ".join(
                    (block["name"], str(block.get("condition", "")), paths.get(identity, "未分類"))
                )
            )
            if all(token in haystack for token in tokens):
                matches.append((index, block))
                include_ancestors(identity)
        if filtering:
            for identity, path in paths.items():
                if all(token in search_text(path) for token in tokens):
                    include_ancestors(identity)
        else:
            visible_folders.update(by_id)
        self._refreshing = True
        try:
            self.tree.delete(*self.tree.get_children())
            self._block_ids.clear()
            children = {}
            for record in records:
                children.setdefault(record.get("parent_id", ""), []).append(record)
            pending = list(reversed(children.get("", [])))
            while pending:
                record = pending.pop()
                identity = record["id"]
                if identity not in visible_folders:
                    continue
                parent_id = record.get("parent_id", "")
                node = FOLDER_PREFIX + identity
                self.tree.insert(
                    FOLDER_PREFIX + parent_id if parent_id else "",
                    "end", iid=node, text="", image=self._folder_image,
                    values=(record["name"], self.visibility_mark(self.node_block_ids(node))),
                    tags=("folder",),
                    open=True if filtering else self._open.get(node, not parent_id),
                )
                pending.extend(reversed(children.get(identity, [])))
            unfiled = [(i, block) for i, block in matches if not block.get("folder_id", "")]
            if records and unfiled:
                self.tree.insert(
                    "", "end", iid=UNFILED, text="", image=self._folder_image,
                    values=("未分類", self.visibility_mark(self.node_block_ids(UNFILED))),
                    tags=("folder",), open=True if filtering else self._open.get(UNFILED, True),
                )
            for index, block in matches:
                identity = block.get("folder_id", "")
                parent = FOLDER_PREFIX + identity if identity else UNFILED if records else ""
                label = block["name"]
                self.tree.insert(
                    parent, "end", iid=str(index), text=str(index + 1),
                    values=(label, self.visibility_mark({block["id"]})),
                    tags=("preview_hidden",) if block["id"] in self.hidden_preview_ids else (),
                )
                self._block_ids[str(index)] = block["id"]
            if selected_index is not None:
                selected = [str(selected_index)] if self.tree.exists(str(selected_index)) else []
            else:
                selected = [node for node, identity in self._block_ids.items() if identity in selected_ids]
                selected += [node for node in selected_folders if self.tree.exists(node)]
            self.tree.selection_set(selected)
            if selected:
                self.tree.focus(selected[0])
            self.summary.set(
                f"{len(matches)}件 · 表示チェックはプレビューのみ"
            )
        finally:
            self._filtering = filtering
            self._refreshing = False

    def node_block_ids(self, node):
        project = self.project_getter()
        if node.startswith(FOLDER_PREFIX):
            identity = node[len(FOLDER_PREFIX):]
            members = descendant_ids(project, identity) | {identity} if identity else {""}
            return {b["id"] for b in project["blocks"] if b.get("folder_id", "") in members}
        if node.isdigit() and int(node) < len(project["blocks"]):
            return {project["blocks"][int(node)]["id"]}
        return set()

    def visibility_mark(self, identities):
        if not identities:
            return "—"
        hidden = identities & self.hidden_preview_ids
        return "☐" if hidden == identities else "▣" if hidden else "☑"

    def visibility_hit(self, event):
        return (
            self.tree.identify_region(event.x, event.y) == "cell"
            and self.tree.identify_column(event.x) == "#2"
            and bool(self.tree.identify_row(event.y))
        )

    def click_visibility(self, event):
        if self.visibility_hit(event):
            identities = self.node_block_ids(self.tree.identify_row(event.y))
            self.set_preview_visibility(identities, bool(identities & self.hidden_preview_ids))
            return "break"

    def double_visibility(self, event):
        if self.visibility_hit(event):
            return "break"

    def selection_block_ids(self):
        result = set()
        for node in self.tree.selection():
            result.update(self.node_block_ids(node))
        return result

    def toggle_selection_visibility(self, event=None):
        identities = self.selection_block_ids()
        self.set_preview_visibility(identities, bool(identities & self.hidden_preview_ids))
        return "break"

    def set_preview_visibility(self, identities, visible):
        before = self.hidden_preview_ids.copy()
        if visible:
            self.hidden_preview_ids.difference_update(identities)
        else:
            self.hidden_preview_ids.update(identities)
        if before != self.hidden_preview_ids:
            self.refresh()
            if self.on_preview_changed:
                self.on_preview_changed()

    def prepare_visibility_menu(self):
        menu = self.visibility_menu
        menu.delete(0, "end")
        all_ids = {b["id"] for b in self.project_getter()["blocks"]}
        selected = self.selection_block_ids()
        menu.add_command(label="すべて表示", command=lambda: self.set_preview_visibility(all_ids, True))
        menu.add_command(label="すべて非表示", command=lambda: self.set_preview_visibility(all_ids, False))
        menu.add_separator()
        for label, visible in (("選択した項目を表示", True), ("選択した項目を非表示", False)):
            menu.add_command(
                label=label, command=lambda value=visible: self.set_preview_visibility(selected, value),
                state="normal" if selected else "disabled",
            )
        menu.add_separator()
        menu.add_command(label="フォルダをすべて展開", command=self.expand_all)
        menu.add_command(label="フォルダをすべて折りたたむ", command=self.collapse_all)

    def preview_items(self, items):
        hidden = {
            i for i, block in enumerate(self.project_getter()["blocks"])
            if block["id"] in self.hidden_preview_ids
        }
        return [item for item in items if item.get("block_index") not in hidden]

    def select_folder(self, identity):
        node = FOLDER_PREFIX + identity if identity else UNFILED
        if not self.tree.exists(node):
            return False
        self._expand_ancestors(node)
        self.tree.selection_set(node)
        self.tree.focus(node)
        self.tree.see(node)
        return True

    def _expand_ancestors(self, node):
        parent = self.tree.parent(node)
        while parent:
            self.tree.item(parent, open=True)
            self._open[parent] = True
            parent = self.tree.parent(parent)

    def reveal(self, index):
        if self.search.get():
            self.search.set("")
        node = str(index)
        if not self.tree.exists(node):
            return False
        self._expand_ancestors(node)
        self.tree.selection_set(node)
        self.tree.focus(node)
        self.tree.see(node)
        return True

    def expand_all(self):
        for node in self._folder_nodes():
            self.tree.item(node, open=True)
            if not self._filtering:
                self._open[node] = True

    def collapse_all(self):
        for node in self._folder_nodes():
            self.tree.item(node, open=False)
            if not self._filtering:
                self._open[node] = False

    def prepare_menu(self):
        self.menu.delete(0, "end")
        real_folder = self._real_folder_selection()
        have_blocks = bool(self.selected_indices())
        for label, action, enabled in (
            ("フォルダを追加…", lambda: self.new_folder(""), True),
            ("子フォルダを追加…", self.new_folder, bool(self.selected_folder())),
            ("フォルダの名前を変更…", self.rename_folder, real_folder is not None),
            ("フォルダを移動…", self.move_selected_folder, real_folder is not None),
            ("フォルダを削除…", self.delete_folder, real_folder is not None),
        ):
            self.menu.add_command(label=label, command=action, state="normal" if enabled else "disabled")
        self.menu.add_separator()
        self.menu.add_command(label="選択ブロックを移動…", command=self.move_selection, state="normal" if have_blocks else "disabled")
        self.menu.add_command(label="選択ブロックを未分類へ", command=lambda: self.move_selection(""), state="normal" if have_blocks else "disabled")
        self.menu.add_separator()
        self.menu.add_command(label="すべて展開", command=self.expand_all)
        self.menu.add_command(label="すべて折りたたむ", command=self.collapse_all)

    def context_menu(self, event):
        node = self.tree.identify_row(event.y)
        if node and node not in self.tree.selection():
            self.tree.selection_set(node)
        if node:
            self.tree.focus(node)
        self.prepare_menu()
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()
        return "break"

    def _apply(self, operation):
        project = self.project_getter()
        trial = copy.deepcopy(project)
        try:
            result = operation(trial)
            errors = validate_project(trial)
            if errors:
                raise ValueError("\n".join(errors[:8]))
        except ValueError as exc:
            messagebox.showerror("フォルダの設定", str(exc), parent=self.winfo_toplevel())
            return False, None
        if trial == project:
            return False, result
        project.clear()
        project.update(trial)
        self.on_changed()
        self.refresh()
        return True, result

    def new_folder(self, parent_id=None):
        parent_id = self.selected_folder() if parent_id is None else parent_id
        name = simpledialog.askstring("フォルダを追加", "フォルダ名", parent=self.winfo_toplevel())
        if name is None:
            return None
        changed, record = self._apply(lambda trial: create_folder(trial, name, parent_id))
        if changed:
            if self.search.get():
                self.search.set("")
            self.select_folder(record["id"])
            self.tree.item(FOLDER_PREFIX + record["id"], open=True)
            return record
        return None

    def rename_folder(self):
        identity = self._real_folder_selection()
        if identity is None:
            return False
        old = next(item["name"] for item in folders(self.project_getter()) if item["id"] == identity)
        name = simpledialog.askstring("フォルダの名前を変更", "フォルダ名", initialvalue=old, parent=self.winfo_toplevel())
        if name is None:
            return False
        changed, _ = self._apply(lambda trial: rename_folder(trial, identity, name))
        if changed:
            self.select_folder(identity)
        return changed

    def rename_selected(self, event=None):
        if self._real_folder_selection() is not None:
            self.rename_folder()
            return "break"

    def toggle_selected_folder(self, event=None):
        selected = self.tree.selection()
        if len(selected) == 1 and selected[0].startswith(FOLDER_PREFIX):
            node = selected[0]
            self.tree.item(node, open=not bool(self.tree.item(node, "open")))
            if not self._filtering:
                self._open[node] = bool(self.tree.item(node, "open"))
            return "break"

    def delete_selected_folder(self, event=None):
        if self._real_folder_selection() is not None:
            self.delete_folder()
            return "break"

    def delete_folder(self):
        identity = self._real_folder_selection()
        if identity is None:
            return False
        label = folder_path(self.project_getter(), identity)
        if not messagebox.askyesno(
            "フォルダを削除",
            f"「{label}」と子フォルダを削除しますか？\n中のブロックは削除せず、未分類へ移動します。",
            parent=self.winfo_toplevel(),
        ):
            return False
        changed, _ = self._apply(lambda trial: delete_folder(trial, identity))
        return changed

    def choose_destination(self, *, folder_id=None):
        project = self.project_getter()
        win = tk.Toplevel(self)
        win.title("フォルダの移動先" if folder_id is not None else "ブロックの移動先")
        fit_window(win, 480, 500, 360, 360)
        win.transient(self.winfo_toplevel())
        win.grab_set()
        ttk.Label(win, text="移動先のフォルダを選択してください。", padding=12).pack(anchor="w")
        container = ttk.Frame(win, padding=(12, 0))
        container.pack(fill="both", expand=True)
        container.columnconfigure(0, weight=1)
        container.rowconfigure(0, weight=1)
        tree = GridTreeview(container, show="tree", selectmode="browse")
        tree.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(container, command=tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        tree.configure(yscrollcommand=scroll.set)
        destination_root = "destination:root"
        tree.insert("", "end", iid=destination_root, text="最上位" if folder_id is not None else "未分類（フォルダに入れない）", open=True, image=self._folder_image)
        excluded = descendant_ids(project, folder_id) if folder_id is not None else set()
        children = {}
        for record in folders(project):
            children.setdefault(record.get("parent_id", ""), []).append(record)

        pending = list(reversed(children.get("", [])))
        while pending:
            record = pending.pop()
            if record["id"] in excluded:
                continue
            parent_id = record.get("parent_id", "")
            tree.insert(
                FOLDER_PREFIX + parent_id if parent_id else destination_root,
                "end", iid=FOLDER_PREFIX + record["id"], text=record["name"],
                open=True, image=self._folder_image,
            )
            pending.extend(reversed(children.get(record["id"], [])))
        initial = self.selected_folder() if folder_id is None else next(item.get("parent_id", "") for item in folders(project) if item["id"] == folder_id)
        initial = FOLDER_PREFIX + initial if initial else destination_root
        initial = initial if tree.exists(initial) else destination_root
        tree.selection_set(initial)
        tree.focus(initial)
        result = []

        def accept(event=None):
            selected = tree.selection()
            if selected:
                result.append("" if selected[0] == destination_root else selected[0][len(FOLDER_PREFIX):])
                win.destroy()
            return "break"

        bar = ttk.Frame(win, padding=12)
        bar.pack(fill="x")
        ttk.Button(bar, text="キャンセル", command=win.destroy).pack(side="left")
        ttk.Button(bar, text="移動", command=accept, style="Primary.TButton").pack(side="right")
        tree.bind("<Double-1>", accept)
        tree.bind("<Return>", accept)
        win.bind("<Escape>", lambda e: win.destroy())
        win.wait_window()
        return result[0] if result else None

    def move_selection(self, folder_id=None):
        indices = self.selected_indices()
        if not indices:
            return False
        identities = [self.project_getter()["blocks"][i]["id"] for i in indices]
        if folder_id is None:
            folder_id = self.choose_destination()
        if folder_id is None:
            return False
        changed, _ = self._apply(lambda trial: assign_blocks(trial, identities, folder_id))
        if changed:
            self._reveal_ids(identities)
        return changed

    def _reveal_ids(self, identities):
        if self.search.get():
            self.search.set("")
        selected = []
        for node, identity in self._block_ids.items():
            if identity in identities:
                self._expand_ancestors(node)
                selected.append(node)
        self.tree.selection_set(selected)
        if selected:
            self.tree.focus(selected[0])
            self.tree.see(selected[0])

    def move_selected_folder(self, parent_id=None):
        identity = self._real_folder_selection()
        if identity is None:
            return False
        if parent_id is None:
            parent_id = self.choose_destination(folder_id=identity)
        if parent_id is None:
            return False
        changed, _ = self._apply(lambda trial: move_folder(trial, identity, parent_id))
        if changed:
            if self.search.get():
                self.search.set("")
            self.select_folder(identity)
        return changed

    def drag_start(self, event):
        node = self.tree.identify_row(event.y)
        self._drag = (node, event.x, event.y, tuple(self.tree.selection())) if node else None

    def drag_motion(self, event):
        if self._drag and abs(event.x - self._drag[1]) + abs(event.y - self._drag[2]) > 10:
            self.tree.configure(cursor="hand2")

    def drag_end(self, event):
        drag, self._drag = self._drag, None
        self.tree.configure(cursor="")
        if not drag or abs(event.x - drag[1]) + abs(event.y - drag[2]) <= 10:
            return
        target = self.tree.identify_row(event.y)
        if not target.startswith(FOLDER_PREFIX):
            return
        folder_id = "" if target == UNFILED else target[len(FOLDER_PREFIX) :]
        source = drag[0]
        if source.startswith(FOLDER_PREFIX):
            if source != UNFILED:
                self.tree.selection_set(source)
                self.move_selected_folder(folder_id)
        else:
            selected = [node for node in drag[3] if node.isdigit()] if source in drag[3] else [source]
            self.tree.selection_set(selected)
            self.move_selection(folder_id)
        return "break"
