"""Input-table identity, drawing targets and compatibility with single-table projects."""

import copy
import re
import unicodedata
import uuid


def input_tables(project):
    if "input_tables" in project:
        return project["input_tables"]
    return [{"id": "table_1", "name": "入力表1", "rows": project.get("rows", [])}]


def current_table(project, table_id=None):
    tables = input_tables(project)
    wanted = (
        table_id
        if table_id is not None
        else project.get("active_table", tables[0]["id"])
    )
    for table in tables:
        if table["id"] == wanted:
            return table
    raise ValueError("対象の入力表がありません: " + str(wanted))


def get_rows(project, table_id=None):
    return current_table(project, table_id)["rows"]


def default_target(rows):
    return {"mode": "selected", "range": "", "selected": list(range(len(rows)))}


def target_settings(project, table_id=None):
    table = current_table(project, table_id)
    return project["drawing"]["targets"][table["id"]]


def upgrade_tables(project):
    """Called after validation; rows are stored exactly once in the new format."""
    result = copy.deepcopy(project)
    if "input_tables" not in result:
        result["input_tables"] = [
            {"id": "table_1", "name": "入力表1", "rows": result.pop("rows")}
        ]
        result["active_table"] = "table_1"
    result.setdefault("drawing", {}).setdefault("targets", {})
    for table in result["input_tables"]:
        target = result["drawing"]["targets"].setdefault(table["id"], {})
        for key, value in default_target(table["rows"]).items():
            target.setdefault(key, value)
    return result


def add_input_table(project, name, rows):
    if len(project["input_tables"]) >= 100:
        raise ValueError("入力表は100個までです")
    name = name.strip()
    if not name:
        raise ValueError("入力表の名前を入力してください")
    if any(t["name"].casefold() == name.casefold() for t in project["input_tables"]):
        raise ValueError("同じ名前の入力表があります")
    table = {
        "id": "table_" + uuid.uuid4().hex,
        "name": name,
        "rows": copy.deepcopy(rows),
    }
    project["input_tables"].append(table)
    project["drawing"]["targets"][table["id"]] = default_target(table["rows"])
    project["active_table"] = table["id"]
    return table


def unique_table_name(project, base):
    names = {t["name"].casefold() for t in input_tables(project)}
    if base.casefold() not in names:
        return base
    i = 2
    while f"{base} ({i})".casefold() in names:
        i += 1
    return f"{base} ({i})"


def parse_row_range(text, row_count):
    text = (
        unicodedata.normalize("NFKC", text)
        .replace("、", ",")
        .replace("〜", "-")
        .replace("~", "-")
        .strip()
    )
    if not text:
        raise ValueError("対象行を入力してください（例: 1-3,5）")
    if len(text) > 2048:
        raise ValueError("行番号の指定が長すぎます")
    result = set()
    for part in text.split(","):
        match = re.fullmatch(r"\s*(\d+)\s*(?:-\s*(\d+))?\s*", part)
        if not match:
            raise ValueError("行番号は 1-3,5 のように指定してください")
        start = int(match[1])
        end = int(match[2] or match[1])
        if start < 1 or end > row_count or start > end:
            raise ValueError(
                f"対象行は1〜{row_count}の範囲で、開始行≦終了行にしてください"
            )
        result.update(range(start - 1, end))
    return sorted(result)


def parse_row_number(text, row_count):
    """One drawing row; lists and ranges belong in the checkbox picker."""
    if row_count == 0:
        raise ValueError("作図に使用する入力表に行がありません")
    value = unicodedata.normalize("NFKC", str(text)).strip()
    if not re.fullmatch(r"[0-9]{1,5}", value):
        raise ValueError("行番号は1つ指定してください。複数行は「選択行…」でチェックします")
    number = int(value)
    if not 1 <= number <= row_count:
        raise ValueError(f"行番号は1〜{row_count}で指定してください")
    return number - 1


def title_table(project):
    table = input_tables(project)[0]
    column = next((key for row in table["rows"] for key in row), None)
    return table, column


def row_title(project, index, resolver=None):
    table, column = title_table(project)
    if not 0 <= index < len(table["rows"]):
        return "（入力表1に該当行なし）"
    value = table["rows"][index].get(column, "")
    from table_formulas import computed_columns
    formulas = resolver.formulas[table["name"].casefold()] if resolver is not None else computed_columns(table)
    if column in formulas:
        from engine import RowResolver, convert, evaluate, MacroError
        try:
            resolver = resolver or RowResolver(project, convert, evaluate, MacroError)
            value = resolver.cell(table["name"], index, column)
            if type(value) in (int, float):
                value = format(value, ".12g")
        except MacroError:
            return "（タイトルの計算エラー）"
    text = "" if value is None else str(value).strip()
    return text or "（タイトル未入力）"


def drawing_rows(project, table_id=None):
    rows = get_rows(project, table_id)
    target = target_settings(project, table_id)
    if target["mode"] == "all":
        return list(range(len(rows)))
    if target["mode"] == "range":
        return [parse_row_number(target["range"], len(rows))]
    return list(target["selected"])
