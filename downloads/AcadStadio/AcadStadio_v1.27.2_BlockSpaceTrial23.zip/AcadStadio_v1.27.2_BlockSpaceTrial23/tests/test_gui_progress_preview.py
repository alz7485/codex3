"""Cumulative block preview respects execution order without editing the flow."""

import copy, os, sys
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from macro_editor import MacroEditor


@unittest.skipUnless(
    os.environ.get("DISPLAY") or sys.platform == "win32", "GUI display unavailable"
)
class ProgressPreviewGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def editor(self):
        self.app.data["blocks"][0]["commands"] = [
            {"type": "LINE", "x1": "0", "y1": "0", "x2": "10", "y2": "0"},
            {"type": "CIRCLE", "x": "10", "y": "10", "r": "2"},
            {
                "type": "REPEAT",
                "count": "2",
                "commands": [
                    {"type": "CIRCLE", "x": "loop.index*10", "y": "20", "r": "3"}
                ],
            },
        ]
        return MacroEditor(
            self.root,
            self.app.data["blocks"][0],
            self.app.data["blocks"],
            self.app.refresh,
            self.app.data,
            [0],
        )

    def test_cumulative_mode_marks_and_displays_prefix_and_toggle_restores_single(self):
        editor = self.editor()
        before = copy.deepcopy(self.app.data)
        self.root.update()
        editor.preview_through.set(True)
        editor.list.tree.selection_set("2")
        self.root.update()
        editor.show_preview([2])
        self.assertEqual(len(editor.preview_canvas.items), 4)
        self.assertEqual(editor.list.indices(), [2])
        self.assertTrue(
            all("previewed" in editor.list.tree.item(str(i), "tags") for i in range(3))
        )
        self.assertIn("3/3", editor.preview_label.cget("text"))
        editor.list.tree.selection_set("0")
        self.root.update()
        editor.show_preview([0])
        self.assertEqual(len(editor.preview_canvas.items), 1)
        self.assertNotIn("previewed", editor.list.tree.item("1", "tags"))
        editor.list.tree.selection_set("1")
        self.root.update()
        editor.preview_through.set(False)
        editor.change_preview_mode()
        self.assertEqual(len(editor.preview_canvas.items), 1)
        self.assertEqual(editor.preview_canvas.items[0]["type"], "CIRCLE")
        self.assertEqual(self.app.data, before)
        editor.cancel()

    def test_unfinished_later_command_does_not_block_earlier_stage(self):
        editor = self.editor()
        editor.list.commands.append({"type": "CIRCLE", "x": "0", "y": "0", "r": "1+"})
        before = copy.deepcopy(editor.list.commands)
        editor.preview_through.set(True)
        editor.show_preview([1])
        self.assertEqual(len(editor.preview_canvas.items), 2)
        self.assertIn("2/4", editor.preview_label.cget("text"))
        self.assertEqual(editor.list.commands, before)
        editor.win.destroy()

    def test_preview_mode_is_remembered_and_pending_jobs_are_cancelled(self):
        for _ in range(5):
            editor = self.editor()
            editor.preview_through.set(True)
            editor.change_preview_mode()
            editor.queue_preview()
            self.assertIsNotNone(editor._preview_job)
            editor.win.destroy()
            self.assertIsNone(editor._preview_job)
            self.root.update()
        editor = self.editor()
        self.assertTrue(editor.preview_through.get())
        editor.win.destroy()
        self.assertTrue(self.app.persist_workspace())
        self.assertTrue(
            self.app.workspace_state.read("view", 128 * 1024)["command_preview_through"]
        )


if __name__ == "__main__":
    unittest.main()
