"""Actual Tk flows for staged setting presets and history."""

import copy
import os
import sys
from pathlib import Path
from tkinter import ttk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from settings_presets import create_preset


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class SettingsGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def manager(self):
        editor = self.app.manage_settings_presets()
        self.root.update()
        return editor

    def test_selection_cancel_never_applies_or_saves(self):
        before = copy.deepcopy(self.app.data)
        editor = self.manager()
        editor.list.selection_set("small")
        self.root.update()
        with patch("tkinter.simpledialog.askstring", return_value="保存しない設定"):
            gui.button(editor.win, "現在値から新規").invoke()
        self.assertEqual(self.app.data, before)
        gui.button(editor.win, "キャンセル").invoke()
        self.assertEqual(self.app.data, before)

    def test_apply_default_undo_redo(self):
        before = copy.deepcopy(self.app.data)
        editor = self.manager()
        editor.list.selection_set("default"); self.root.update()
        gui.button(editor.win, "選択を適用").invoke()
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], 3.5)
        self.assertIn("デフォルト", self.app.settings_preset_summary.get())
        self.app.undo_project()
        self.assertEqual(self.app.data, before)
        self.app.redo_project()
        self.assertEqual(self.app.data["active_settings_preset"], "default")

    def test_create_save_without_applying(self):
        old = copy.deepcopy(self.app.data["settings"])
        editor = self.manager()
        with patch("tkinter.simpledialog.askstring", return_value="設備図"):
            gui.button(editor.win, "現在値から新規").invoke()
        gui.button(editor.win, "保存して閉じる").invoke()
        self.assertEqual(self.app.data["settings"], old)
        self.assertEqual(self.app.data["active_settings_preset"], "")
        self.assertEqual(len(self.app.data["settings_presets"]), 1)
        self.assertTrue(self.app.has_unsaved_changes())

    def test_duplicate_standard_rename_edit_apply(self):
        editor = self.manager()
        editor.list.selection_set("default"); self.root.update()
        with patch("tkinter.simpledialog.askstring", return_value="標準を調整"):
            gui.button(editor.win, "複製").invoke()
        key = editor.selected()

        def change_values():
            win = gui.top(self.root, "設定プリセットの値")
            tree = next(w for w in gui.descendants(win) if isinstance(w, ttk.Treeview))
            item = next(
                i
                for i in tree.get_children()
                if tree.item(i, "values")[0] == "TEXT_HEIGHT"
            )
            tree.item(item, values=("TEXT_HEIGHT", "7"))
            gui.button(win, "表の内容を確定").invoke()

        self.root.after(100, change_values)
        gui.button(editor.win, "値を編集").invoke()
        self.assertEqual(self.root.grab_current(), editor.win)
        with patch("tkinter.simpledialog.askstring", return_value="調整済み"):
            gui.button(editor.win, "名前変更").invoke()
        gui.button(editor.win, "選択を適用").invoke()
        self.assertEqual(self.app.data["settings"]["TEXT_HEIGHT"], "7")
        self.assertEqual(self.app.data["active_settings_preset"], key)
        self.assertIn("調整済み", self.app.settings_preset_summary.get())
        self.assertEqual(self.messages, [])

    def test_delete_active_keeps_current_values(self):
        key = create_preset(self.app.data, "削除テスト", self.app.data["settings"])
        self.app.data["active_settings_preset"] = key
        self.app.refresh()
        before = copy.deepcopy(self.app.data["settings"])
        editor = self.manager()
        gui.button(editor.win, "削除").invoke()
        gui.button(editor.win, "保存して閉じる").invoke()
        self.assertEqual(self.app.data["settings"], before)
        self.assertEqual(self.app.data["settings_presets"], {})
        self.assertEqual(self.app.data["active_settings_preset"], "")

    def test_standard_is_protected(self):
        editor = self.manager()
        editor.list.selection_set("default"); self.root.update()
        before = copy.deepcopy(editor.data)
        gui.button(editor.win, "削除").invoke()
        gui.button(editor.win, "値を編集").invoke()
        self.assertEqual(editor.data, before)

    def test_preset_rows_and_confirm_buttons_remain_visible(self):
        editor = self.manager()
        for geometry in ("820x720", "700x640"):
            editor.win.geometry(geometry)
            self.root.update()
            self.assertTrue(editor.list.bbox("default"), geometry)
            self.assertTrue(editor.list.bbox("large"), geometry)
            confirm = gui.button(editor.win, "選択を適用")
            self.assertTrue(confirm.winfo_ismapped(), geometry)
            self.assertLessEqual(
                confirm.winfo_rooty() + confirm.winfo_height(),
                editor.win.winfo_rooty() + editor.win.winfo_height(),
                geometry,
            )

    def test_invalid_size_keeps_edit_dialog_open(self):
        key = create_preset(self.app.data, "寸法用", {"TEXT_HEIGHT": "4"})
        editor = self.manager()
        editor.list.selection_set(key)

        def try_invalid():
            win = gui.top(self.root, "設定プリセットの値")
            tree = next(w for w in gui.descendants(win) if isinstance(w, ttk.Treeview))
            tree.item(tree.get_children()[0], values=("TEXT_HEIGHT", "-2"))
            gui.button(win, "表の内容を確定").invoke()
            self.assertTrue(win.winfo_exists())
            win.destroy()

        self.root.after(100, try_invalid)
        gui.button(editor.win, "値を編集").invoke()
        self.assertTrue(self.messages)
        self.assertEqual(
            editor.data["settings_presets"][key]["values"]["TEXT_HEIGHT"], "4"
        )


if __name__ == "__main__":
    unittest.main()
