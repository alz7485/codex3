"""Real-widget workflows for finding and organizing many drawing blocks."""

import copy
import json
import os
from pathlib import Path
import sys
import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from block_browser import UNFILED
from main import App, EMPTY
from macro_editor import MacroEditor
from test_unified_blocks import circle, definition, modern


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"),
    "GUI display is not available",
)
class BlockFoldersGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def organized_project(self):
        data = modern(
            definition("outline", "外形円", [circle()]),
            definition("holes", "穴パターン", [circle("@X + 3")]),
            definition("helper", "別の円", [circle("@X + 5")]),
            definition("last", "その他", [circle("@X + 10")]),
        )
        data["block_folders"] = [
            {"id": "family", "name": "輪郭系", "parent_id": ""},
            {"id": "standard", "name": "標準", "parent_id": "family"},
            {"id": "holes_folder", "name": "穴系", "parent_id": ""},
        ]
        data["blocks"][0]["folder_id"] = "standard"
        data["blocks"][1]["folder_id"] = "holes_folder"
        data["blocks"][2]["folder_id"] = "standard"
        return data

    def load_organized(self):
        self.app.replace_document(self.organized_project())
        self.root.update()
        return self.app.block_browser

    def select(self, *nodes):
        self.app.block_list.selection_set(*nodes)
        self.root.update()

    def test_existing_projects_keep_flat_block_selection_without_extra_groups(self):
        self.assertEqual(
            self.app.block_list.get_children(),
            tuple(str(i) for i in range(len(self.app.data["blocks"]))),
        )
        self.select("1")
        self.assertEqual(self.app.selected_block(), 1)
        self.assertIn("断面図", self.app.block_list.item("1", "values")[0])

    def test_nested_folder_tree_shows_global_execution_order(self):
        project = self.organized_project()
        self.app.replace_document(project)
        self.root.update()
        tree = self.app.block_list
        self.assertEqual(tree.parent("folder:standard"), "folder:family")
        self.assertEqual(tree.parent("0"), "folder:standard")
        self.assertEqual(tree.parent("2"), "folder:standard")
        self.assertEqual(tree.parent("1"), "folder:holes_folder")
        self.assertEqual(tree.parent("3"), UNFILED)
        self.assertEqual([int(tree.item(str(i), "text")) for i in range(4)], [1, 2, 3, 4])
        self.assertEqual([b["id"] for b in self.app.data["blocks"]], ["outline", "holes", "helper", "last"])

    def test_create_nested_folder_then_rename_preserves_existing_references(self):
        browser = self.load_organized()
        before = self.app.compile()
        browser.select_folder("family")
        with patch("tkinter.simpledialog.askstring", return_value="特注"):
            browser.new_folder()
        added = next(f for f in self.app.data["block_folders"] if f["name"] == "特注")
        self.assertEqual(added["parent_id"], "family")
        browser.select_folder(added["id"])
        with patch("tkinter.simpledialog.askstring", return_value="特注品"):
            browser.rename_folder()
        renamed = next(f for f in self.app.data["block_folders"] if f["id"] == added["id"])
        self.assertEqual(renamed["name"], "特注品")
        self.assertEqual(self.app.data["blocks"][2]["name"], "別の円")
        self.assertEqual(self.app.compile(), before)

    def test_multiselect_move_is_one_undo_and_preserves_drawing_order(self):
        browser = self.load_organized()
        before = copy.deepcopy(self.app.data)
        drawing = self.app.compile()
        self.select("0", "2")
        browser.move_selection("holes_folder")
        self.root.update()
        self.assertEqual(self.app.data["blocks"][0]["folder_id"], "holes_folder")
        self.assertEqual(self.app.data["blocks"][2]["folder_id"], "holes_folder")
        self.assertEqual(self.app.block_list.parent("0"), "folder:holes_folder")
        self.assertEqual(self.app.compile(), drawing)
        self.app.undo_project()
        self.assertEqual(self.app.data, before)
        self.app.redo_project()
        self.assertEqual(self.app.data["blocks"][2]["folder_id"], "holes_folder")
        self.assertEqual(self.app.compile(), drawing)

    def test_folder_move_changes_parent_without_reordering_or_rewriting_calls(self):
        browser = self.load_organized()
        before = copy.deepcopy(self.app.data)
        drawing = self.app.compile()
        browser.select_folder("standard")
        browser.move_selected_folder("holes_folder")
        self.root.update()
        child = next(f for f in self.app.data["block_folders"] if f["id"] == "standard")
        self.assertEqual(child["parent_id"], "holes_folder")
        self.assertEqual(self.app.block_list.parent("folder:standard"), "folder:holes_folder")
        self.assertEqual(self.app.data["blocks"], before["blocks"])
        self.assertEqual(self.app.compile(), drawing)
        self.app.undo_project()
        self.assertEqual(self.app.data, before)

    def test_folder_cannot_move_into_its_descendant(self):
        browser = self.load_organized()
        before = copy.deepcopy(self.app.data)
        browser.select_folder("family")
        browser.move_selected_folder("standard")
        self.assertEqual(self.app.data, before)
        self.assertTrue(self.messages)

    def test_delete_folder_subtree_keeps_blocks_and_is_undoable(self):
        browser = self.load_organized()
        before = copy.deepcopy(self.app.data)
        drawing = self.app.compile()
        browser.select_folder("family")
        with patch("tkinter.messagebox.askyesno", return_value=False):
            browser.delete_folder()
        self.assertEqual(self.app.data, before)
        browser.delete_folder()
        self.root.update()
        self.assertEqual([f["id"] for f in self.app.data["block_folders"]], ["holes_folder"])
        self.assertEqual([b["id"] for b in self.app.data["blocks"]], [b["id"] for b in before["blocks"]])
        for index in (0, 2):
            self.assertFalse(self.app.data["blocks"][index].get("folder_id"))
            self.assertEqual(self.app.block_list.parent(str(index)), UNFILED)
        self.assertEqual(self.app.compile(), drawing)
        self.app.undo_project()
        self.assertEqual(self.app.data, before)

    def test_name_search_reveals_ancestors_and_restores_collapsed_state(self):
        browser = self.load_organized()
        tree = self.app.block_list
        tree.item("folder:family", open=False)
        browser.search.set("外形円")
        self.root.update()
        self.assertTrue(tree.exists("0"))
        self.assertFalse(tree.exists("1"))
        self.assertFalse(tree.exists("2"))
        self.assertTrue(tree.item("folder:family", "open"))
        self.assertTrue(tree.item("folder:standard", "open"))
        browser.search.set("")
        self.root.update()
        self.assertFalse(tree.item("folder:family", "open"))
        self.assertTrue(tree.exists("1"))
        self.assertTrue(tree.exists("2"))

    def test_folder_path_search_finds_nested_blocks_without_modifying_project(self):
        browser = self.load_organized()
        before = copy.deepcopy(self.app.data)
        browser.search.set("輪郭系")
        self.root.update()
        self.assertTrue(self.app.block_list.exists("0"))
        self.assertTrue(self.app.block_list.exists("2"))
        self.assertFalse(self.app.block_list.exists("1"))
        self.assertEqual(self.app.data, before)
        self.assertFalse(self.app.has_unsaved_changes())

    def test_search_hides_selection_so_actions_cannot_edit_an_unseen_block(self):
        browser = self.load_organized()
        self.select("0")
        browser.search.set("穴パターン")
        self.root.update()
        before = copy.deepcopy(self.app.data)
        self.assertIsNone(self.app.selected_block())
        self.app.del_block()
        self.assertEqual(self.app.data, before)

    def test_reveal_clears_search_and_opens_the_target_folder(self):
        browser = self.load_organized()
        browser.collapse_all()
        browser.search.set("存在しない名前")
        self.root.update()
        self.assertFalse(self.app.block_list.exists("2"))
        browser.reveal(2)
        self.root.update()
        self.assertEqual(browser.search.get(), "")
        self.assertEqual(self.app.selected_block(), 2)
        self.assertTrue(self.app.block_list.item("folder:family", "open"))
        self.assertTrue(self.app.block_list.item("folder:standard", "open"))

    def test_new_block_inherits_selected_folder_but_cancel_leaves_no_changes(self):
        browser = self.load_organized()
        browser.select_folder("standard")
        before = copy.deepcopy(self.app.data)
        self.app.add_block()
        win = gui.top(self.root, "ブロック編集")
        gui.button(win, "キャンセル").invoke()
        self.assertEqual(self.app.data, before)
        browser.select_folder("standard")
        self.app.add_block()
        win = gui.top(self.root, "ブロック編集")
        gui.button(win, "ブロックを確定").invoke()
        self.root.update()
        self.assertEqual(len(self.app.data["blocks"]), 5)
        self.assertEqual(self.app.data["blocks"][-1]["folder_id"], "standard")
        self.assertEqual(self.app.block_list.parent("4"), "folder:standard")
        self.assertEqual(self.app.selected_block(), 4)

    def test_folder_selection_never_mutates_a_block_through_main_actions(self):
        browser = self.load_organized()
        self.select("1")
        browser.select_folder("standard")
        before = copy.deepcopy(self.app.data)
        self.assertIsNone(self.app.selected_block())
        self.app.move_block(-1)
        with patch("tkinter.messagebox.askyesno", return_value=False):
            self.app.del_block()
        with patch("tkinter.simpledialog.askstring", return_value=None):
            self.app.edit_block()
        self.assertEqual(self.app.data, before)

    def test_main_delete_on_a_folder_preserves_every_block_and_call(self):
        browser = self.load_organized()
        before = copy.deepcopy(self.app.data["blocks"])
        drawing = self.app.compile()
        browser.select_folder("family")
        self.app.del_block()
        self.assertEqual([b["id"] for b in self.app.data["blocks"]], [b["id"] for b in before])
        self.assertEqual([b["commands"] for b in self.app.data["blocks"]], [b["commands"] for b in before])
        self.assertFalse(any(f["id"] == "family" for f in self.app.data["block_folders"]))
        self.assertEqual(self.app.compile(), drawing)

    def test_save_and_reopen_preserve_folder_membership_and_generated_script(self):
        self.load_organized()
        before = copy.deepcopy(self.app.data)
        drawing = self.app.compile()
        path = Path(self.library_dir.name) / "organized.json"
        with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
            self.assertTrue(self.app.save())
        saved = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(saved["block_folders"], before["block_folders"])
        self.app.replace_document(EMPTY)
        self.assertTrue(self.app.open_project(path))
        self.root.update()
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app.compile(), drawing)
        self.assertEqual(self.app.block_list.parent("2"), "folder:standard")

    def test_issue_navigation_reveals_hidden_block_without_changing_targets(self):
        browser = self.load_organized()
        target_rows = self.app.selected_rows()
        browser.collapse_all()
        browser.search.set("見つからない")
        self.root.update()
        address = ("blocks", 2, "commands", 0)
        self.app.navigate_issue({"block_index": 2, "address": address, "row": 1})
        self.root.update()
        self.assertEqual(browser.search.get(), "")
        self.assertEqual(self.app.selected_block(), 2)
        self.assertEqual(self.app.navigator.selected(), [("command", ("block", 2), 0)])
        self.assertEqual(self.app.selected_rows(), target_rows)
        self.assertTrue(self.app.navigator.winfo_ismapped())

    def test_hundreds_of_blocks_can_be_found_without_losing_identity_or_order(self):
        data = modern(*[
            definition(f"part_{i}", f"部品{i:03}", [circle(str(i))])
            for i in range(300)
        ])
        data["block_folders"] = [
            {"id": f"folder_{i}", "name": f"分類{i:02}", "parent_id": ""}
            for i in range(30)
        ]
        for i, block in enumerate(data["blocks"]):
            block["folder_id"] = f"folder_{i % 30}"
        self.app.replace_document(data)
        self.root.update()
        browser = self.app.block_browser
        before = copy.deepcopy(self.app.data)
        browser.search.set("部品247")
        self.root.update()
        self.assertTrue(self.app.block_list.exists("247"))
        self.assertFalse(self.app.block_list.exists("246"))
        self.assertEqual(self.app.block_list.parent("247"), "folder:folder_7")
        browser.reveal(247)
        self.root.update()
        self.assertEqual(self.app.selected_block(), 247)
        self.assertEqual(int(self.app.block_list.item("247", "text")), 248)
        self.assertTrue(all(self.app.block_list.exists(str(i)) for i in range(300)))
        self.assertEqual(self.app.data, before)

    def test_editing_and_adding_direct_commands_keep_the_source_folder(self):
        self.load_organized()
        editor = MacroEditor(self.root, self.app.data["blocks"][0], self.app.data["blocks"],
                             self.app.refresh, self.app.data, [0])
        editor.list.tree.selection_set("0")
        changed, added = circle("333"), circle("444")
        with patch("macro_editor.edit_command", return_value=changed):
            editor.list.edit()
        editor.list.tree.selection_remove(editor.list.tree.selection())
        with patch("macro_editor.edit_command", return_value=added):
            editor.list.add()
        editor.save()
        self.root.update()
        self.assertEqual(self.app.data["blocks"][0]["commands"], [changed, added])
        self.assertEqual(self.app.data["blocks"][0]["folder_id"], "standard")
        self.assertEqual(len(self.app.data["blocks"]), 4)


    def test_nested_if_and_repeat_keep_commands_direct_without_group_button(self):
        for typ in ("IF", "REPEAT"):
            with self.subTest(command=typ):
                self.load_organized()
                branch = dict(type=typ, commands=[circle("333"), circle("444")])
                branch.update(condition="True") if typ == "IF" else branch.update(count="2")
                self.app.data["blocks"][0]["commands"] = [branch]
                self.app.refresh()
                editor = MacroEditor(
                    self.root,
                    self.app.data["blocks"][0],
                    self.app.data["blocks"],
                    self.app.refresh,
                    self.app.data,
                    self.app.selected_rows(),
                )
                editor.list.tree.selection_set("0")

                def group_nested():
                    sub = gui.top(self.root, "IF: 実行する側" if typ == "IF" else "繰り返すコマンド")
                    try:
                        tree = next(w for w in gui.descendants(sub) if isinstance(w, ttk.Treeview))
                        tree.selection_set("0", "1")
                        self.assertFalse(any(isinstance(w, ttk.Button) and w.cget("text") == "ブロック化" for w in gui.descendants(sub)))
                        gui.button(sub, "この階層を確定").invoke()
                    finally:
                        if sub.winfo_exists():
                            sub.destroy()

                def configure_branch():
                    win = gui.top(self.root, "コマンドの設定")
                    try:
                        self.root.after(20, group_nested)
                        gui.button(win, "実行するコマンドを編集" if typ == "IF" else "繰り返すコマンドを編集").invoke()
                        gui.button(win, "コマンドを確定").invoke()
                    finally:
                        if win.winfo_exists():
                            win.destroy()

                self.root.after(20, configure_branch)
                editor.list.edit()
                editor.save()
                self.root.update()
                self.assertEqual(len(self.app.data["blocks"]), 4)
                self.assertEqual(self.app.data["blocks"][0]["folder_id"], "standard")
                self.assertEqual(self.app.data["blocks"][0]["commands"][0]["commands"], [circle("333"), circle("444")])

    def test_destination_dialog_accepts_a_real_folder_named_root(self):
        data = self.organized_project()
        data["block_folders"].append({"id": "root", "name": "移動先", "parent_id": ""})
        self.app.replace_document(data)
        self.root.update()
        browser = self.app.block_browser
        self.select("0")

        def choose():
            win = gui.top(self.root, "ブロックの移動先")
            try:
                tree = next(w for w in gui.descendants(win) if isinstance(w, ttk.Treeview))
                pending = list(tree.get_children())
                target = None
                while pending:
                    node = pending.pop()
                    if tree.item(node, "text") == "移動先":
                        target = node
                        break
                    pending.extend(tree.get_children(node))
                self.assertIsNotNone(target)
                tree.selection_set(target)
                gui.button(win, "移動").invoke()
            finally:
                if win.winfo_exists():
                    win.destroy()

        self.root.after(20, choose)
        browser.move_selection()
        self.assertEqual(self.app.data["blocks"][0]["folder_id"], "root")

    def test_search_selection_and_closed_folders_survive_a_workspace_restart(self):
        browser = self.load_organized()
        path = Path(self.library_dir.name) / "workspace-project.json"
        with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
            self.assertTrue(self.app.save())
        browser.collapse_all()
        browser.search.set("外形円")
        self.select("0")
        self.assertTrue(self.app.persist_workspace())

        def restart():
            self.root.destroy()
            self.root = tk.Tk()
            self.root.report_callback_exception = lambda typ, value, tb: self.errors.append(value)
            self.app = App(self.root, library_state_path=Path(self.library_dir.name) / "library.json")
            self.root.update()

        restart()
        browser = self.app.block_browser
        self.assertEqual(browser.search.get(), "外形円")
        self.assertEqual(self.app.selected_block(), 0)
        browser.clear_search()
        self.root.update()
        self.assertFalse(self.app.block_list.item("folder:family", "open"))
        browser.select_folder("family")
        self.assertTrue(self.app.persist_workspace())
        restart()
        self.assertEqual(self.app.block_browser.selected_folder(), "family")
        self.assertFalse(self.app.block_list.item("folder:family", "open"))

    def test_folder_projects_keep_list_space_and_drawing_settings_accessible(self):
        browser = self.load_organized()
        self.root.geometry("1320x840")
        self.root.update()
        self.assertGreater(self.app.block_list.winfo_height(), 220)
        self.assertTrue(self.app.settings_group.winfo_ismapped())
        self.assertTrue(self.app.table_group.winfo_ismapped())
        target = self.app.edit_target_settings()
        self.root.update()
        self.assertTrue(gui.button(target, "選択行").winfo_ismapped())
        self.assertTrue(gui.button(target, "閉じる").winfo_ismapped())
        radio = next(w for w in gui.descendants(target) if isinstance(w, ttk.Radiobutton) and w.cget("text") == "行番号")
        radio.invoke()
        row_entry = next(w for w in gui.descendants(target) if isinstance(w, ttk.Entry))
        row_entry.delete(0, "end")
        row_entry.insert(0, "2")
        self.assertEqual(self.app.target_rows(), [1])
        target.destroy()
        settings = self.app.manage_settings_presets()
        settings.size_vars["TEXT_HEIGHT"].set("7.5")
        gui.button(settings.win, "保存して閉じる").invoke()
        self.assertEqual(float(self.app.data["settings"]["TEXT_HEIGHT"]), 7.5)
        self.assertEqual(self.app.target_rows(), [1])
        for identity in ("family", "holes_folder"):
            browser.select_folder(identity)
            browser.delete_folder()
        self.root.update()
        self.assertTrue(self.app.settings_group.winfo_ismapped())
        self.assertTrue(self.app.table_group.winfo_ismapped())


if __name__ == "__main__":
    unittest.main()
