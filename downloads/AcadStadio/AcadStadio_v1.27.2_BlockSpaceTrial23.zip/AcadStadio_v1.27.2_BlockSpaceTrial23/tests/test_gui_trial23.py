"""Drawing source tables are staged independently from preview selection."""
import copy
import os
import sys
import json
import unittest
from pathlib import Path
from tkinter import ttk
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import test_gui as gui
from project_data import add_input_table, target_settings
from macro_editor import edit_command
from cad_colors import entity_color_label

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform == 'win32', 'GUI display unavailable')
class Trial23Gui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def manager(self):
        self.app.edit_target_settings(); self.root.update()
        return self.app.target_table_controls

    def test_checks_stage_apply_and_undo(self):
        manager = self.manager()
        before = copy.deepcopy(self.app.data); script = self.app.compile()[0]
        manager.clear_all(); manager.toggle([1, 2]); self.root.update()
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app.compile()[0], script)
        manager.apply(); self.root.update()
        self.assertEqual(self.app.target_rows(), [1, 2])
        self.app.undo_project(); self.root.update()
        self.assertEqual(self.app.data, before)

    def test_table_switch_only_applies_on_button_and_is_one_undo(self):
        first = self.app.data['active_table']
        second = add_input_table(self.app.data, '副表', copy.deepcopy(self.app.rows))
        self.app.data['active_table'] = first; self.app.refresh(); self.root.update()
        before = copy.deepcopy(self.app.data)
        manager = self.manager(); manager.tabs.select(manager.views[second['id']]['page']); self.root.update()
        manager.clear_all(); manager.toggle([2]); self.root.update()
        self.assertEqual(self.app.data, before)
        manager.apply(); self.root.update()
        self.assertEqual(self.app.data['active_table'], second['id'])
        self.assertEqual(self.app.target_rows(), [2])
        self.app.undo_project(); self.root.update()
        self.assertEqual(self.app.data, before)

    def test_click_space_all_clear_and_preview_does_not_set_target(self):
        manager = self.manager(); key = manager.selected_table_id(); tree = manager.views[key]['tree']
        manager.clear_all(); self.root.update()
        box = tree.bbox('1', 'value_0')
        tree.event_generate('<ButtonPress-1>', x=box[0]+5, y=box[1]+5)
        tree.event_generate('<ButtonRelease-1>', x=box[0]+5, y=box[1]+5); self.root.update()
        self.assertEqual(manager.checked[key], {1})
        tree.selection_set(['0', '2']); tree.focus_set(); tree.event_generate('<space>'); self.root.update()
        self.assertEqual(manager.checked[key], {0, 1, 2})
        manager.clear_all(); self.assertFalse(manager.checked[key])
        manager.check_all(); self.assertEqual(manager.checked[key], {0, 1, 2})
        before = copy.deepcopy(target_settings(self.app.data))
        self.app.show_input_table(); self.app.table.selection_set('2'); self.root.update()
        self.assertEqual(target_settings(self.app.data), before)

    def test_formulas_and_empty_table_and_external_edit_reload(self):
        p = json.loads((Path(__file__).resolve().parents[1] / 'examples/formula_columns_project.json').read_text())
        self.app.replace_document(p); self.root.update()
        manager = self.manager(); key = manager.selected_table_id(); tree = manager.views[key]['tree']
        self.assertIn('30', tree.item('1', 'values'))
        self.assertTrue(tree.formulas)
        self.assertTrue(tree.formula_cells)
        self.app.rows[0]['幅'] = '12'; self.app.refresh(); self.root.update()
        key = manager.selected_table_id(); tree = manager.views[key]['tree']
        self.assertIn('24', tree.item('0', 'values'))
        empty = add_input_table(self.app.data, '空表', []); self.app.refresh(); self.root.update()
        manager.tabs.select(manager.views[empty['id']]['page']); self.root.update()
        manager.check_all(); manager.apply(); self.root.update()
        self.assertEqual(self.app.target_rows(), [])

    def test_color_and_scale_editor_save_and_cancel(self):
        command = dict(type='LINE', x1='0', y1='0', x2='10', y2='0', color='1', linetype_scale='2')
        def choose():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                combos = [w for w in gui.descendants(win) if isinstance(w, ttk.Combobox)]
                color = next(w for w in combos if entity_color_label(256) in w.cget('values'))
                color.set(entity_color_label(256))
                entries = [w for w in gui.descendants(win) if isinstance(w, ttk.Entry) and not isinstance(w, ttk.Combobox)]
                scale = next(w for w in entries if w.get() == '2')
                scale.delete(0, 'end'); scale.insert(0, '@OD / 50')
                gui.button(win, 'コマンドを確定').invoke()
            except Exception as exc:
                self.errors.append(exc); win.destroy()
        self.root.after(80, choose)
        result = edit_command(self.root, command, self.app.data['blocks'], self.app.data)
        self.assertEqual(result['color'], '256')
        self.assertEqual(result['linetype_scale'], '@OD / 50')
        self.assertEqual(command['color'], '1')
        self.root.after(80, lambda: gui.button(gui.top(self.root, 'コマンドの設定'), 'キャンセル').invoke())
        self.assertIsNone(edit_command(self.root, command, self.app.data['blocks'], self.app.data))

    def test_minimum_target_window_fits_apply_button(self):
        manager = self.manager(); win = manager.winfo_toplevel()
        win.geometry('760x600'); self.root.update()
        apply = gui.button(manager, 'この表のチェック行')
        self.assertTrue(apply.winfo_ismapped())
        self.assertGreaterEqual(apply.winfo_height(), apply.winfo_reqheight())
        self.assertLessEqual(apply.winfo_rootx()+apply.winfo_width(), win.winfo_rootx()+win.winfo_width())
        self.assertLessEqual(apply.winfo_rooty()+apply.winfo_height(), win.winfo_rooty()+win.winfo_height())
        tree = manager.views[manager.selected_table_id()]['tree']
        self.assertGreater(tree.winfo_height(), 100)
