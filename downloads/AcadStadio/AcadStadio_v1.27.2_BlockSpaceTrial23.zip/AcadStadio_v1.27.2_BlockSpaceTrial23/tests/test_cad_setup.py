"""Optional initialization, named references, JSON migration and macro ordering."""

import copy
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cad_setup import cad_name, default_setup, initial_macro, validate_setup
from project_model import normalize_project, validate_project
from block_model import legacy_view
from engine import compile_project
from test_cad_state import read_form
from cad_colors import color_label, color_code, swatch, palette_cell


def project(enabled=True):
    setup = default_setup()
    setup.update(
        enabled=enabled,
        layers=[{"name": "PARTS", "color": 2, "linetype": "DASHED", "lineweight": 25}],
        linetypes=[{"name": "DASHED", "file": "acad.lin"}],
        text_styles=[
            {"name": "CF_TEXT", "font": "arial.ttf", "width": 1, "oblique": 0}
        ],
        dim_styles=[
            {
                "name": "CF_DIM",
                "text_style": "CF_TEXT",
                "scale": 2,
                "text_height": 3.5,
                "arrow_size": 2.5,
            }
        ],
    )
    return normalize_project(
        {
            "version": 10,
            "cad_setup": setup,
            "rows": [{"X": 0}, {"X": 20}],
            "settings": {"TEXT_HEIGHT": 3.5},
            "globals": {},
            "blocks": {},
            "presets": [
                {
                    "name": "図形",
                    "commands": [
                        {
                            "type": "LINE",
                            "layer": "PARTS",
                            "linetype": "DASHED",
                            "x1": "@X",
                            "y1": 0,
                            "x2": "@X+10",
                            "y2": 0,
                        },
                        {
                            "type": "TEXT",
                            "layer": "PARTS",
                            "text_style": "CF_TEXT",
                            "x": 0,
                            "y": 0,
                            "text": "A",
                        },
                        {
                            "type": "DIMLINEAR",
                            "layer": "PARTS",
                            "dim_style": "CF_DIM",
                            "x1": 0,
                            "y1": 0,
                            "x2": 10,
                            "y2": 0,
                            "x3": 0,
                            "y3": 5,
                        },
                    ],
                }
            ],
        }
    )


class CadSetupTests(unittest.TestCase):
    def test_cad_names_allow_spaces_without_allowing_control_or_command_separators(self):
        for name in ("MS明朝\u3000縦", "SX_FONT 縦", "部品 外形", "寸法\u3000標準"):
            with self.subTest(name=name):
                self.assertTrue(cad_name(name))
        for name in ("", " \u3000", "x\n_.LINE", "x\rname", "x\tname", "x\x7fname",
                     'x"name', "x;name", "x|name", "x/name", "x\\name", "x\u2028name", "x\u2029name"):
            with self.subTest(name=repr(name)):
                self.assertFalse(cad_name(name))

    def test_spaced_resource_names_survive_json_setup_and_scr_arguments(self):
        for enabled in (False, True):
            with self.subTest(enabled=enabled):
                p = project(enabled)
                setup = p["cad_setup"]
                setup["layers"][0].update(name="部品 外形", linetype="破線 A")
                setup["linetypes"][0]["name"] = "破線 A"
                setup["text_styles"][0]["name"] = "MS明朝\u3000縦"
                setup["text_styles"].append(dict(name="SX_FONT 縦", font="arial.ttf", width=1, oblique=0))
                setup["dim_styles"][0].update(name="寸法 標準", text_style="MS明朝\u3000縦")
                commands = p["blocks"][0]["commands"]
                for cmd in commands:
                    cmd["layer"] = "部品 外形"
                commands[0]["linetype"] = "破線 A"
                commands[1]["text_style"] = "MS明朝\u3000縦"
                commands[2]["dim_style"] = "寸法 標準"
                commands.append(dict(commands[1], text_style="SX_FONT 縦"))
                saved = json.dumps(p, ensure_ascii=False)
                p = normalize_project(json.loads(saved))
                self.assertEqual(validate_project(p), [])
                script, items = compile_project(p, [0])
                self.assertEqual(len(items), 4)
                for variable, name in (("CLAYER", "部品 外形"), ("CELTYPE", "破線 A"),
                                       ("TEXTSTYLE", "MS明朝\u3000縦"), ("TEXTSTYLE", "SX_FONT 縦")):
                    self.assertIn(f'_.SETVAR\n{variable}\n"{name}"\n', script)
                self.assertIn('_.-DIMSTYLE\n_Restore\n"寸法 標準"\n', script)
                self.assertTrue(all(item["layer"] == "部品 外形" for item in items))
                if enabled:
                    self.assertIn('(cons 2 "MS明朝\u3000縦")', script)
                    self.assertIn('(cons 2 "SX_FONT 縦")', script)
                    self.assertIn('(setvar "DIMTXSTY" "MS明朝\u3000縦")', script)
                else:
                    self.assertNotIn("CADFLOWINIT", script)
                for line in script.splitlines():
                    line.encode("cp932")
                    if line.startswith("("):
                        read_form(line)

    def test_spaced_layer_name_is_quoted_when_creating_a_layer(self):
        p = legacy_view(project(False))
        p.pop("cad_setup")
        p["version"] = 9
        p["presets"][0]["commands"][0]["layer"] = "部品 外形"
        script, items = compile_project(normalize_project(p), [0])
        self.assertIn('_.-LAYER\n_Make\n"部品 外形"\n', script)
        self.assertEqual(items[0]["layer"], "部品 外形")

    def test_palette_groups_basic_colors_then_tens_on_each_row(self):
        self.assertEqual(palette_cell(1), (0, 0))
        self.assertEqual(palette_cell(9), (8, 0))
        for first in range(10, 250, 10):
            self.assertEqual(palette_cell(first), (0, first // 10))
            self.assertEqual(palette_cell(first + 9), (9, first // 10))
        self.assertEqual(palette_cell(250), (0, 25))
        self.assertEqual(palette_cell(255), (5, 25))

    def test_aci_labels_and_swatches_keep_original_indices(self):
        self.assertIn("赤", color_label(1))
        self.assertIn("白／黒", color_label(7))
        for i in range(1, 256):
            self.assertEqual(color_code(color_label(i)), str(i))
            self.assertRegex(swatch(i), r"^#[0-9a-f]{6}$")

    def test_layer_plot_flag_defaults_true_and_can_be_disabled(self):
        p = project()
        self.assertIn("(cons 290 1)", "\n".join(initial_macro(p["cad_setup"])))
        p["cad_setup"]["layers"][0]["plot"] = False
        p = normalize_project(json.loads(json.dumps(p)))
        self.assertIs(p["cad_setup"]["layers"][0]["plot"], False)
        output = "\n".join(initial_macro(p["cad_setup"]))
        self.assertIn("(cons 290 0)", output)
        p["cad_setup"]["layers"][0]["plot"] = "false"
        self.assertTrue(validate_setup(p["cad_setup"]))

    def test_macro_executes_once_before_rows_after_state_snapshot(self):
        p = project()
        script, items = compile_project(p, [0, 1])
        self.assertEqual(len(items), 6)
        self.assertEqual(script.count("(c:CADFLOWINIT)"), 1)
        self.assertLess(script.index("(c:CADFLOWINIT)"), script.index("_.LINE\n"))
        self.assertLess(
            script.index("(setq *cadflow-capture*"), script.index("(c:CADFLOWINIT)")
        )
        self.assertEqual(script.splitlines()[-1], "(c:CADFLOWRESTORE)")

    def test_off_keeps_references_and_has_no_creation_commands(self):
        script, _ = compile_project(project(False), [0])
        self.assertNotIn("CADFLOWINIT", script)
        self.assertNotIn("entmake", script)
        self.assertNotIn("_Make", script)
        self.assertIn("_.SETVAR\nCLAYER\nPARTS", script)
        self.assertIn("_.SETVAR\nTEXTSTYLE\nCF_TEXT", script)
        self.assertIn("_.-DIMSTYLE\n_Restore\nCF_DIM", script)
        self.assertIn("_.SETVAR\nCELTYPE\nDASHED", script)

    def test_missing_definitions_only_and_dependency_order(self):
        s = "\n".join(initial_macro(project()["cad_setup"]))
        self.assertIn('(not (tblsearch "LTYPE" "DASHED"))', s)
        self.assertIn('(not (tblsearch "STYLE" "CF_TEXT"))', s)
        self.assertIn('(not (tblsearch "LAYER" "PARTS"))', s)
        self.assertIn('(not (tblsearch "DIMSTYLE" "CF_DIM"))', s)
        self.assertLess(s.index('tblsearch "LTYPE"'), s.index('tblsearch "LAYER"'))
        self.assertLess(s.index('tblsearch "STYLE"'), s.index('tblsearch "DIMSTYLE"'))
        self.assertNotIn('"_Yes"', s)
        self.assertIn("'(40 . 0.0)", s)

    def test_generated_lisp_lines_are_complete_and_cp932_safe(self):
        script, _ = compile_project(project(), [0])
        for line in script.splitlines():
            line.encode("cp932")
            self.assertLessEqual(len(line), 2048)
            if line.startswith("("):
                read_form(line)

    def test_json_roundtrip_and_definitions_survive_toggle(self):
        p = project()
        self.assertEqual(normalize_project(json.loads(json.dumps(p))), p)
        definitions = copy.deepcopy(p["cad_setup"])
        p["cad_setup"]["enabled"] = False
        p = normalize_project(p)
        p["cad_setup"]["enabled"] = True
        self.assertEqual(p["cad_setup"], definitions)

    def test_legacy_layer_creation_is_retained_until_setup_is_configured(self):
        p = legacy_view(project(False))
        p.pop("cad_setup")
        p["version"] = 9
        migrated = normalize_project(p)
        self.assertTrue(migrated["cad_setup"]["legacy_make_layers"])
        script, _ = compile_project(migrated, [0])
        self.assertIn("_.-LAYER\n_Make\nPARTS", script)

    def test_validation_rejects_duplicates_bad_numbers_and_injection(self):
        for section, row in [
            ("layers", {"name": "bad\nname"}),
            ("layers", {"name": "x", "color": 256}),
            ("text_styles", {"name": "x", "width": 0}),
            ("dim_styles", {"name": "x", "scale": float("inf")}),
            ("linetypes", {"name": "x", "file": "bad\nfile"}),
        ]:
            with self.subTest(section=section, row=row):
                s = default_setup()
                s[section] = [row]
                self.assertTrue(validate_setup(s))
        s = default_setup()
        s["layers"] = [{"name": "PARTS"}, {"name": "parts"}]
        self.assertTrue(validate_setup(s))
        p = project()
        p["blocks"][0]["commands"][1]["text_style"] = "bad\nname"
        self.assertTrue(validate_project(p))

    def test_dimension_macro_restores_current_style_and_overrides(self):
        s = "\n".join(initial_macro(project()["cad_setup"]))
        self.assertIn('(setq ds (getvar "DIMSTYLE"))', s)
        self.assertIn('"_Restore" ds', s)
        self.assertIn("(foreach p vals", s)
        self.assertLess(s.index('"_Save" "CF_DIM"'), s.index('"_Restore" ds'))

    def test_layers_only_macro_does_not_switch_dimension_style(self):
        s = default_setup()
        s["enabled"] = True
        s["layers"] = [{"name": "PARTS"}]
        self.assertNotIn("_.-DIMSTYLE", "\n".join(initial_macro(s)))

    def test_dimension_base_dependencies_are_sorted_and_cycles_rejected(self):
        setup = default_setup()
        setup["enabled"] = True
        setup["dim_styles"] = [{"name": "Child", "base": "Base"}, {"name": "Base"}]
        output = "\n".join(initial_macro(setup))
        self.assertLess(
            output.index('tblsearch "DIMSTYLE" "Base"'),
            output.index('tblsearch "DIMSTYLE" "Child"'),
        )
        setup["dim_styles"][1]["base"] = "Child"
        self.assertTrue(validate_setup(setup))


if __name__ == "__main__":
    unittest.main()
