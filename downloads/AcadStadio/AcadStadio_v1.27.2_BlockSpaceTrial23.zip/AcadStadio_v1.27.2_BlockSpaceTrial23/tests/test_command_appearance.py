"""Per-command appearance is evaluated at the drawing row and restored by SCR."""
import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from engine import compile_project, MacroError
from sample_project import EXAMPLE
from cad_state import snapshot_variables
from project_model import validate_sequential_project

LINE = dict(type='LINE', x1='0', y1='0', x2='10', y2='0')

class CommandAppearance(unittest.TestCase):
    def project(self, commands):
        p = copy.deepcopy(EXAMPLE)
        p['blocks'] = [dict(p['blocks'][0], commands=commands)]
        return p

    def test_expressions_and_restoration_and_json(self):
        p = self.project([dict(LINE, color='@N - 1', linetype_scale='@OD / 50')])
        script, items = compile_project(json.loads(json.dumps(p)), [0, 1])
        self.assertIn('_.SETVAR\nCECOLOR\n3\n', script)
        self.assertIn('_.SETVAR\nCELTSCALE\n2.4\n', script)
        self.assertEqual([i['color'] for i in items], [3, 5])
        self.assertEqual([i['linetype_scale'] for i in items], [2, 2.4])
        self.assertTrue({'CECOLOR', 'CELTSCALE'} <= set(snapshot_variables(script.splitlines())))
        self.assertIn('CADFLOWRESTORE', script)

    def test_blank_inherits_and_bylayer_resets_color(self):
        p = self.project([dict(LINE, color='1', linetype_scale='2'), dict(LINE, color='', linetype_scale=''), dict(LINE, color='ByLayer'), dict(LINE, color='ByBlock')])
        script, items = compile_project(p, [0])
        self.assertEqual([i['color'] for i in items], [1, 1, 256, 0])
        self.assertTrue(all(i['linetype_scale'] == 2 for i in items))
        self.assertEqual(script.count('_.SETVAR\nCECOLOR\n1\n'), 1)

    def test_unset_fields_preserve_existing_output(self):
        plain = self.project([LINE])
        blank = self.project([dict(LINE, color='', linetype_scale='')])
        self.assertEqual(compile_project(plain, [0]), compile_project(blank, [0]))

    def test_invalid_values_rejected_before_export(self):
        for field, values in [('color', ['-1', '257', '1.5', 'True', '1/0']), ('linetype_scale', ['0', '-1', 'True', '1/0'])]:
            for value in values:
                with self.subTest(field=field, value=value), self.assertRaises(MacroError):
                    compile_project(self.project([dict(LINE, **{field: value})]), [0])
        self.assertTrue(validate_sequential_project(self.project([dict(LINE, color=True)])))

    def test_conditions_loops_and_sysvar_state(self):
        commands = [dict(LINE, color='1'), dict(LINE, color='2', condition='False'), dict(type='REPEAT', count='2', commands=[dict(LINE, color='loop.index + 3', linetype_scale='loop.index + 1')]), dict(type='SYSVAR', name='CECOLOR', value='256', value_kind='number'), dict(LINE)]
        _, items = compile_project(self.project(commands), [0])
        self.assertEqual([i['color'] for i in items], [1, 3, 4, 256])
        self.assertEqual(items[-1]['linetype_scale'], 2)
