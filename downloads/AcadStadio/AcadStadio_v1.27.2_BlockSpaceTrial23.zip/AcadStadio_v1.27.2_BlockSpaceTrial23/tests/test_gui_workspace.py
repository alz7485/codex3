"""Drawing-first navigation and an independent full-size input-table window."""

import copy
import os
from pathlib import Path
import sys
import unittest
from tkinter import ttk
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from project_data import add_input_table, target_settings


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class WorkspaceGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_starts_with_blocks_and_preview_but_no_input_grid(self):
        self.assertFalse(hasattr(self.app, "workspace_tabs"))
        self.assertTrue(self.app.block_list.winfo_ismapped())
        self.assertNotIn("presets", self.app.data)
        self.assertIsInstance(self.app.data["blocks"], list)
        self.assertFalse(hasattr(self.app, "block_tabs"))
        self.assertFalse(hasattr(self.app, "flow_view"))
        self.assertEqual(self.app.block_panel.cget("text"), "ブロック一覧")
        self.assertTrue(self.app.canvas.winfo_ismapped())
        self.assertIsNone(self.app.project_window)
        self.assertFalse(self.app.table.winfo_ismapped())

    def test_input_window_reopen_preserves_rows_settings_script_and_history(self):
        self.app.table.selection_set("1")
        self.root.update()
        self.app.preview(quiet=True)
        before = copy.deepcopy(self.app.data)
        history = copy.deepcopy(self.app._history)
        script = self.app._script_text
        geometry = self.root.geometry()
        for _ in range(3):
            gui.button(self.app.drawing_page, "表一覧").invoke()
            self.root.update()
            self.assertTrue(self.app.table.winfo_ismapped())
            self.assertTrue(self.app.canvas.winfo_ismapped())
            self.assertIsNone(self.app.project_window)
            gui.button(self.app.input_page, "閉じる").invoke()
            self.root.update()
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app._history, history)
        self.assertEqual(self.app._script_text, script)
        self.assertEqual(self.app.selected_rows(), [1])
        self.assertEqual(self.root.geometry(), geometry)

    def test_close_commits_pending_cell_and_reuses_the_same_nonmodal_window(self):
        win = self.app.show_input_table(); self.root.update()
        self.assertIsNone(self.root.grab_current())
        self.app.table_editor.begin(cell=(0, 3))
        self.assertIsNotNone(self.app.table_editor.entry)
        self.app.table_editor.entry.delete(0, "end")
        self.app.table_editor.entry.insert(0, "155")
        self.root.tk.call(win.protocol("WM_DELETE_WINDOW"))
        self.root.update()
        self.assertEqual(str(self.app.rows[0]["OD"]), "155")
        self.assertEqual(win.state(), "withdrawn")
        self.assertIsNone(self.app.table_editor.entry)
        self.assertIs(self.app.show_input_table(), win)
        self.root.update()
        self.app.undo_project()
        self.assertEqual(str(self.app.rows[0]["OD"]), "100")
        self.assertTrue(self.app.canvas.winfo_ismapped())

    def test_input_window_ctrl_s_saves_pending_edit_without_closing_window(self):
        import json
        self.app.path = str(Path(self.library_dir.name) / "saved.json")
        self.app.show_input_table(); self.root.update()
        self.app.table_editor.begin(cell=(0, 3))
        entry = self.app.table_editor.entry
        entry.delete(0, "end"); entry.insert(0, "166")
        entry.focus_force(); self.root.update()
        entry.event_generate("<Control-s>"); self.root.update()
        saved = json.loads(Path(self.app.path).read_text())
        self.assertEqual(str(saved["input_tables"][0]["rows"][0]["OD"]), "166")
        self.assertEqual(self.app.input_window.state(), "normal")
        self.assertFalse(self.app.has_unsaved_changes())

    def test_input_window_and_preview_visibility_restore_as_workspace_preferences(self):
        import tkinter as tk
        from main import App
        identity = self.app.data["blocks"][0]["id"]
        self.app.block_browser.set_preview_visibility({identity}, False)
        self.app.show_input_table()
        self.app.input_window.geometry("830x500+40+60"); self.root.update()
        self.assertTrue(self.app.persist_workspace())
        self.root.destroy()
        self.root = tk.Tk()
        self.root.report_callback_exception = lambda t,v,b: self.errors.append(v)
        self.app = App(self.root, library_state_path=Path(self.library_dir.name)/"library.json")
        self.root.update()
        self.assertEqual(self.app.input_window.state(), "normal")
        self.assertEqual(self.app.input_window.geometry(), "830x500+40+60")
        self.assertEqual(self.app.block_browser.hidden_preview_ids, {identity})
        self.assertTrue(self.app.canvas.items)
        self.assertTrue(all(i["block_index"] != 0 for i in self.app.canvas.items))
        self.assertFalse(self.app.has_unsaved_changes())

    def test_drawing_selector_and_input_list_share_active_table(self):
        add_input_table(self.app.data, "別表", [{"X": 1}])
        self.app.refresh()
        self.app.drawing_table_picker.set(self.app.data["input_tables"][0]["name"])
        self.app.drawing_table_picker.event_generate("<<ComboboxSelected>>")
        self.root.update()
        self.assertEqual(
            self.app.table_list.selection(), (self.app.data["active_table"],)
        )
        self.assertEqual(len(self.app.rows), 3)
        self.app.show_input_table()
        identity = self.app.data["input_tables"][1]["id"]
        self.app.table_list.selection_set(identity)
        self.root.update()
        self.app.show_drawing()
        self.assertEqual(self.app.drawing_table_picker.get(), "別表")
        self.assertEqual(target_settings(self.app.data)["mode"], "selected")

    def test_table_list_is_on_the_left_with_management_inside_its_frame(self):
        self.app.show_input_table(); self.root.update()
        self.assertFalse(hasattr(self.app, "table_picker"))
        self.assertFalse(any(isinstance(w, ttk.Combobox) for w in gui.descendants(self.app.input_page)))
        self.assertLess(self.app.table_list.winfo_rootx(), self.app.table.winfo_rootx())
        for label in ("表を追加", "名前を変更", "複製", "削除", "＋ Excel", "ファイルで置換"):
            self.assertTrue(gui.button(self.app.table_list_frame, label).winfo_ismapped())

    def test_list_click_commits_old_cell_and_keeps_each_tables_selection(self):
        first = self.app.data["active_table"]
        other = add_input_table(self.app.data, "別表", copy.deepcopy(self.app.rows))
        self.app.data["active_table"] = first
        self.app.refresh(); self.app.show_input_table(); self.root.update()
        self.app.table.selection_set("1"); self.root.update()
        self.app.table_editor.begin(cell=(1, 3))
        self.app.table_editor.entry.delete(0, "end")
        self.app.table_editor.entry.insert(0, "155")
        box = self.app.table_list.bbox(other["id"])
        self.app.table_list.event_generate("<ButtonPress-1>", x=box[0]+15, y=box[1]+12)
        self.app.table_list.event_generate("<ButtonRelease-1>", x=box[0]+15, y=box[1]+12)
        self.root.update()
        self.assertEqual(self.app.data["active_table"], other["id"])
        self.assertEqual(str(self.app.data["input_tables"][0]["rows"][1]["OD"]), "155")
        self.assertEqual(str(other["rows"][1]["OD"]), "120")
        self.app.table.selection_set("2"); self.root.update()
        self.app.table_list.focus_force(); self.root.update()
        self.app.table_list.event_generate("<Up>"); self.root.update()
        self.assertEqual(self.app.data["active_table"], first)
        self.assertEqual(self.app.selected_rows(), [1])
        self.app.table_list.event_generate("<Down>"); self.root.update()
        self.assertEqual(self.app.selected_rows(), [2])

    def test_list_management_add_rename_duplicate_delete_and_undo(self):
        self.app.show_input_table(); self.root.update()
        with patch("tkinter.simpledialog.askstring", return_value="部品表"):
            gui.button(self.app.table_list_frame, "表を追加").invoke()
        self.root.update()
        identity = self.app.data["active_table"]
        self.assertEqual(self.app.table_list.selection(), (identity,))
        self.assertEqual(self.app.table_list.item(identity, "values"), ("部品表",))
        with patch("tkinter.simpledialog.askstring", return_value="部品寸法"):
            gui.button(self.app.table_list_frame, "名前を変更").invoke()
        self.root.update()
        self.assertEqual(self.app.table_list.item(identity, "values"), ("部品寸法",))
        gui.button(self.app.table_list_frame, "複製").invoke(); self.root.update()
        copied = self.app.data["active_table"]
        self.assertNotEqual(copied, identity)
        self.assertEqual(len(self.app.table_list.get_children()), 3)
        gui.button(self.app.table_list_frame, "削除").invoke(); self.root.update()
        self.assertFalse(self.app.table_list.exists(copied))
        self.app.undo_project(); self.root.update()
        self.assertEqual(self.app.table_list.selection(), (copied,))
        self.assertEqual(len(self.app.table_list.get_children()), 3)
        self.app.redo_project(); self.root.update()
        self.assertFalse(self.app.table_list.exists(copied))

    def test_many_tables_scroll_to_active_and_save_reload_by_identity(self):
        for i in range(25):
            add_input_table(self.app.data, f"部品表{i + 1}", [{"値": i}])
        self.app.refresh(); self.app.show_input_table(); self.root.update()
        identity = self.app.data["active_table"]
        self.assertTrue(self.app.table_list.bbox(identity))
        self.app.path = str(Path(self.library_dir.name) / "tables.json")
        self.assertTrue(self.app.save())
        with patch("tkinter.filedialog.askopenfilename", return_value=self.app.path):
            self.assertTrue(self.app.load())
        self.app.show_input_table(); self.root.update()
        self.assertEqual(self.app.table_list.selection(), (identity,))
        self.assertEqual(len(self.app.table_list.get_children()), 26)
        self.assertTrue(self.app.table_list.bbox(identity))

    def test_import_opens_input_window_and_project_open_hides_it(self):
        path = Path(self.library_dir.name) / "new.csv"
        path.write_text("X,Y\n1,2\n", encoding="utf-8")
        self.assertTrue(self.app.read_table(path))
        self.root.update()
        self.assertTrue(self.app.input_window.winfo_ismapped())
        self.app.replace_document(self.app.data)
        self.assertEqual(self.app.input_window.state(), "withdrawn")

    def test_both_windows_fit_minimum_size_including_footer(self):
        self.root.geometry("1040x680")
        for page in (self.app.drawing_page, self.app.input_page):
            self.app.show_input_table() if page == self.app.input_page else self.app.hide_input_table()
            self.app.input_window.geometry("780x460")
            self.root.update()
            for widget in gui.descendants(self.root):
                if not isinstance(widget, ttk.Button) or not widget.winfo_ismapped():
                    continue
                with self.subTest(page=page, button=widget.cget("text")):
                    parent = widget.master
                    self.assertLessEqual(
                        widget.winfo_rooty() + widget.winfo_height(),
                        parent.winfo_rooty() + parent.winfo_height(),
                    )
                    self.assertLessEqual(
                        widget.winfo_rootx() + widget.winfo_width(),
                        widget.winfo_toplevel().winfo_rootx() + widget.winfo_toplevel().winfo_width(),
                    )
            if page == self.app.drawing_page:
                self.assertTrue(self.app.block_list.bbox("0"))
                self.assertGreater(self.app.canvas.winfo_height(), 150)


if __name__ == "__main__":
    unittest.main()
