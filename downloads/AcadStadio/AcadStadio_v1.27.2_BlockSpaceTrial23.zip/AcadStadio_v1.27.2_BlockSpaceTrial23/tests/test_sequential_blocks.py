"""Product boundary: ordered direct blocks, including nested IF/REPEAT commands."""
import copy
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from block_model import new_block
from project_model import normalize_sequential_project,validate_sequential_project
from engine import compile_project

def project():
    return {'version':11,'rows':[{'X':'1'}],'settings':{},'globals':{},'blocks':[
        new_block('1',commands=[{'type':'CIRCLE','x':'0','y':'0','r':'1'}]),
        new_block('2',commands=[{'type':'CIRCLE','x':'0','y':'0','r':'2'}])]}

class SequentialBlocks(unittest.TestCase):
    def test_new_blocks_have_no_drawing_mode_and_execute_in_order(self):
        p=normalize_sequential_project(project())
        self.assertTrue(all('draw' not in b for b in p['blocks']))
        self.assertEqual([i['coords'][2] for i in compile_project(p,[0])[1]],[1,2])

    def test_block_reference_is_rejected_in_both_if_branches_and_repeats(self):
        for key in ('commands','else'):
            p=project();p['blocks'][0]['commands']=[{'type':'IF','condition':'True','commands':[],'else':[]}]
            p['blocks'][0]['commands'][0][key]=[{'type':'REPEAT','count':'1','commands':[{'type':'BLOCK','name':p['blocks'][1]['id']}]}]
            self.assertTrue(any('BLOCK' in e for e in validate_sequential_project(p)))
            with self.assertRaises(ValueError):normalize_sequential_project(p)

    def test_old_disabled_mode_is_not_silently_executed(self):
        p=project();p['blocks'][1]['draw']=False
        with self.assertRaises(ValueError):normalize_sequential_project(p)

    def test_normalization_does_not_change_the_source_and_removes_redundant_true_field(self):
        p=project();p['blocks'][0]['draw']=True;before=copy.deepcopy(p)
        result=normalize_sequential_project(p)
        self.assertEqual(p,before);self.assertNotIn('draw',result['blocks'][0])

    def test_conditions_if_repeat_and_input_references_are_kept(self):
        p=project();p['blocks'][1]['condition']='False'
        p['blocks'][0]['commands']=[{'type':'REPEAT','count':'2','commands':[{'type':'IF','condition':'@X == 1','commands':[{'type':'CIRCLE','x':'@X','y':'0','r':'3'}]}]}]
        p=normalize_sequential_project(p);self.assertEqual(validate_sequential_project(p),[])
        self.assertEqual(len(compile_project(p,[0])[1]),2)
