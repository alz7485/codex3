"""Computed columns are row-local and cannot be edited below the rule row."""
import copy,json,os,sys,unittest
from pathlib import Path
from tkinter import ttk
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from test_table_formulas import formula_project
from project_data import current_table
from table_formulas import formula_source,table_columns

@unittest.skipUnless(sys.platform=='win32' or os.environ.get('DISPLAY'),'GUI display unavailable')
class FormulaGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def load(self):
        self.app.replace_document(formula_project());self.app.show_input_table();self.root.update();self.app.preview(quiet=True)

    def set_cell(self,row,col,value):
        editor=self.app.table_editor;editor.begin(cell=(row,col));self.assertIsNotNone(editor.entry)
        editor.entry.delete(0,'end');editor.entry.insert(0,value);editor.finish();self.root.update()

    def test_first_row_shows_rule_and_other_rows_show_results_under_header_names(self):
        self.load();tree=self.app.table
        self.assertEqual(tree.heading('高さ','text'),'高さ ƒ')
        self.assertEqual(str(tree.item('0','values')[3]),'20')
        cell=next(c for c in tree.formula_cells if c['cell']==('0','高さ'))
        self.assertEqual(cell['result'].cget('text'),'20')
        self.assertEqual(cell['expression'].cget('text'),'幅 * 2')
        from tkinter import font
        self.assertLess(tree.formula_font.actual('size'),font.nametofont('TkDefaultFont').actual('size'))
        self.assertNotEqual(cell['expression'].cget('fg'),cell['result'].cget('fg'))
        self.assertEqual(str(tree.item('1','values')[3]),'30')
        self.assertEqual(str(tree.item('1','values')[4]),'7.5')
        self.assertEqual(current_table(self.app.data)['rows'][1]['高さ'],'')

    def test_computed_cells_are_readonly_while_normal_columns_remain_editable(self):
        self.load();editor=self.app.table_editor
        before=copy.deepcopy(self.app.data)
        editor.begin(cell=(1,2));self.assertIsNone(editor.entry)
        self.assertIn('1行目',self.app.status.get());self.assertEqual(self.app.data,before)
        self.set_cell(1,1,'20')
        self.assertEqual(str(self.app.table.item('1','values')[3]),'40')
        self.assertEqual(str(self.app.table.item('1','values')[4]),'10')

    def test_rule_edit_recalculates_all_rows_and_is_one_undoable_change(self):
        self.load();history=len(self.app._history)
        self.set_cell(0,2,'幅 * 3')
        self.assertEqual(str(self.app.table.item('1','values')[3]),'45')
        self.assertEqual(len(self.app._history),history+1)
        self.app.undo_project();self.root.update();self.assertEqual(str(self.app.table.item('1','values')[3]),'30')
        self.app.redo_project();self.root.update();self.assertEqual(str(self.app.table.item('1','values')[3]),'45')

    def test_ordinal_rule_is_committed_as_header_name(self):
        self.load();self.set_cell(0,2,'2列目＊2')
        self.assertEqual(self.app.rows[0]['高さ'],'幅*2')
        self.assertEqual(str(self.app.table.item('1','values')[3]),'30')

    def test_paste_through_readonly_column_is_atomic(self):
        self.load();self.app.table_editor.cell=(1,1);self.app.table.focus('1');before=copy.deepcopy(self.app.data)
        self.app.table_editor.paste(text='20\t999')
        self.assertEqual(self.app.data,before)
        self.assertTrue(any('自動計算' in str(m) for m in self.messages))

    def test_paste_skips_blank_placeholders_in_computed_columns(self):
        self.load();self.app.table_editor.cell=(1,1);self.app.table.focus('1')
        self.app.table_editor.paste(text='20\t\t');self.root.update()
        self.assertEqual(self.app.rows[1]['幅'],'20')
        self.assertEqual(self.app.rows[1]['高さ'],'')
        self.assertEqual(str(self.app.table.item('1','values')[3]),'40')

    def test_later_row_cannot_receive_a_formula_in_normal_column(self):
        self.load();before=copy.deepcopy(self.app.data)
        self.set_cell(1,1,'高さ * 2')
        self.assertEqual(self.app.data,before)
        self.assertTrue(any('1行目だけ' in str(m) for m in self.messages))

    def test_row_editor_keeps_computed_fields_readonly(self):
        self.load();self.app.table.selection_set('1');self.root.update();observed=[]
        def inspect():
            win=gui.top(self.root,'2行目を編集')
            try:
                for w in gui.descendants(win):
                    if isinstance(w,ttk.Entry):
                        labels=[str(c.cget('text')) for c in w.master.winfo_children() if isinstance(c,ttk.Label)]
                        if '高さ' in labels:
                            observed.append((str(w.cget('state')),w.get()))
                        if '幅' in labels:
                            w.delete(0,'end');w.insert(0,'20')
                gui.button(win,'行を確定').invoke()
            except Exception:
                win.destroy();raise
        self.root.after(30,inspect);self.app.edit_row();self.root.update()
        self.assertEqual(observed,[('readonly','30')])
        self.assertEqual(self.app.rows[1]['高さ'],'')
        self.assertEqual(str(self.app.table.item('1','values')[3]),'40')

    def test_duplicate_and_first_row_delete_keep_column_rules(self):
        self.load();self.app.table.selection_set('0');self.app.duplicate_rows();self.root.update()
        self.assertEqual(self.app.rows[1]['高さ'],'');self.assertEqual(self.app.rows[1]['半径'],'')
        self.assertEqual(str(self.app.table.item('1','values')[3]),'20')
        self.app.undo_project();self.root.update()
        self.app.table.selection_set('0');self.app.del_row();self.root.update()
        self.assertEqual(self.app.rows[0]['幅'],'15');self.assertEqual(self.app.rows[0]['高さ'],'幅 * 2')
        self.app.preview(quiet=True);self.assertEqual(self.app.compile()[1][0]['coords'],(30,0,7.5))
        self.app.undo_project();self.assertEqual(self.app.rows[0]['幅'],'10')

    def test_formula_menu_uses_headers_and_inserts_into_rule_row(self):
        self.load();editor=self.app.table_editor;tree=self.app.table
        x,y,w,h=tree.bbox('1','高さ');tree.event_generate('<ButtonPress-1>',x=x+w//2,y=y+h//2);tree.event_generate('<ButtonRelease-1>',x=x+w//2,y=y+h//2);self.root.update()
        editor.prepare_formula_menu();menu=editor.formula_menu
        columns=menu.nametowidget(menu.entrycget(2,'menu'))
        self.assertEqual([columns.entrycget(i,'label') for i in range(columns.index('end')+1)],['部品','幅','高さ','半径'])
        variables=menu.nametowidget(menu.entrycget(3,'menu'));variables.invoke(0)
        self.assertEqual(editor.cell,(0,2));self.assertEqual(editor.entry.get(),'変数.半径')
        editor.finish();self.root.update()
        self.assertEqual(str(self.app.table.item('1','values')[3]),'7.5')

    def test_save_reload_keeps_rules_and_recalculates_in_preview(self):
        self.load();path=Path(self.library_dir.name)/'formulas.json';before=copy.deepcopy(self.app.data)
        with patch('tkinter.filedialog.asksaveasfilename',return_value=str(path)):self.assertTrue(self.app.save())
        saved=json.loads(path.read_text());self.assertEqual(saved,before)
        self.assertTrue(self.app.open_project(path));self.app.show_input_table();self.root.update()
        self.app.table.selection_set('1');self.root.update();self.app.preview(quiet=True)
        self.assertEqual(self.app.canvas.items[0]['coords'],(30,0,7.5))
        self.assertEqual(self.app.target_rows(),[0])

    def test_variable_titles_are_calculated_for_row_picker(self):
        p=formula_project();p['globals']['名称']='"品-" + @区分';rows=p['input_tables'][0]['rows'];rows[0].update(部品='変数.名称',区分='A');rows[1]['区分']='B'
        self.app.replace_document(p);self.root.update();picker=self.app.choose_drawing_rows();self.root.update()
        self.assertEqual(picker.tree.item('0','values')[2],'品-A');self.assertEqual(picker.tree.item('1','values')[2],'品-B');picker.cancel()

    def test_cycles_clear_preview_and_show_errors_without_changing_input_text(self):
        self.load();self.set_cell(0,2,'高さ * 2');self.app.preview(quiet=True)
        self.assertEqual(self.app.rows[0]['高さ'],'高さ * 2')
        self.assertEqual(str(self.app.table.item('1','values')[3]),'計算エラー')
        self.assertEqual(self.app._script_text,'');self.assertEqual(self.app.canvas.items,[])
        self.assertIn('循環参照',self.app.status.get())
        self.set_cell(0,2,'幅 * 2');self.app.preview(quiet=True);self.assertTrue(self.app._script_text)

    def test_template_cells_after_first_row_are_never_stored_on_duplicate(self):
        self.load();self.app.table.selection_set('0');self.app.duplicate_rows()
        columns=table_columns(current_table(self.app.data))
        self.assertTrue(all(formula_source(value,columns) is None for row in self.app.rows[1:] for value in row.values()))

    def test_two_line_overlay_clicks_select_rows_and_only_first_row_opens_editor(self):
        self.load();tree=self.app.table
        self.app.input_window.focus_force();self.root.update()
        def double_click(row,timestamp):
            cell=next(c for c in tree.formula_cells if c['cell']==(str(row),'高さ'))
            label=cell['result']
            for when in (timestamp,timestamp+100):
                label.event_generate('<ButtonPress-1>',x=20,y=10,time=when)
                label.event_generate('<ButtonRelease-1>',x=20,y=10,time=when+10)
                self.root.update()
        double_click(1,1000)
        self.assertEqual(self.app.selected_rows(),[1]);self.assertIsNone(self.app.table_editor.entry)
        self.app.preview(quiet=True);self.assertEqual(self.app.canvas.items[0]['coords'],(30,0,7.5))
        double_click(0,3000)
        self.assertIsNotNone(self.app.table_editor.entry)
        self.assertEqual(self.app.table_editor.entry.get(),'幅 * 2')
        self.assertIs(self.root.focus_get(),self.app.table_editor.entry)
        self.app.table_editor.finish(False)

    def test_two_line_formulas_follow_scroll_column_resize_and_selection(self):
        self.load();tree=self.app.table
        self.app.rows.extend([{'部品':str(i),'幅':str(i+1),'高さ':'','半径':''} for i in range(40)])
        self.app.refresh();self.root.update()
        tree.column('高さ',width=180);tree.selection_set('20');tree.see('20');self.root.update()
        shown=[c for c in tree.formula_cells if c['cell'] is not None]
        self.assertTrue(shown)
        cell=next(c for c in shown if c['cell']==('20','高さ'))
        self.assertEqual(cell['expression'].cget('text'),'幅 * 2')
        self.assertEqual(cell['result'].cget('text'),str(tree.set('20','高さ')))
        self.assertEqual(cell['frame'].winfo_width(),178)
        self.assertEqual(cell['result'].cget('bg'),'#dce8ff')
        tree.xview_moveto(.4);self.root.update()
        self.assertEqual(tree.selection(),('20',))
