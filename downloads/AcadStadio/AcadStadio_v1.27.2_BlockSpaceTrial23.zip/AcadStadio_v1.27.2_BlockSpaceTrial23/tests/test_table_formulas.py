"""First-row, header-name formulas share the drawing interpreter and row context."""
import copy,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from engine import compile_project,MacroError
from expression_sample import sample_value
from project_model import normalize_sequential_project,validate_sequential_project
from project_data import row_title,add_input_table
from table_formulas import computed_columns,display_formula
from table_references import rename_project_table_references
from table_io import headers
from audit import audit_project

def formula_project():
    p=normalize_sequential_project({'version':11,'rows':[
        {'部品':'A','幅':'10','高さ':'幅 * 2','半径':'変数.半径'},
        {'部品':'B','幅':'15','高さ':'','半径':''}],
        'settings':{},'globals':{'半径':'@幅 / 2'},
        'blocks':[{'id':'shape','name':'円','commands':[{'type':'CIRCLE','x':'@高さ','y':'0','r':'@半径'}]}]})
    p['input_tables'][0]['name']='部品表'
    p['drawing']['targets'][p['active_table']].update({'mode':'range','range':'1','selected':[0]})
    return p

class TableFormulas(unittest.TestCase):
    def test_unregistered_headers_are_row_local_variables(self):
        p=formula_project();p['globals']={};p['input_tables'][0]['rows'][0]['半径']='幅 / 2'
        items=compile_project(p,[0,1])[1]
        self.assertEqual([i['coords'] for i in items],[(20.0,0.0,5.0),(30.0,0.0,7.5)])

    def test_registered_variable_in_cell_changes_for_each_row(self):
        p=formula_project()
        self.assertEqual([sample_value(p,'@半径',i) for i in range(2)],[5,7.5])
        self.assertEqual([i['coords'][2] for i in compile_project(p,[0,1])[1]],[5,7.5])

    def test_ordinal_input_is_shown_with_header_and_fullwidth_operator(self):
        p=formula_project();t=p['input_tables'][0];t['rows'][0]['高さ']='2列目＊2'
        self.assertEqual(display_formula(t['rows'][0]['高さ'],t),'幅*2')
        self.assertEqual(sample_value(p,'@高さ',1),30)
        t['rows'][0]['高さ']='＝２列目×３'
        self.assertEqual(display_formula(t['rows'][0]['高さ'],t),'=幅*3')
        self.assertEqual(sample_value(p,'@高さ',1),45)

    def test_dependency_chain_and_forward_column_order(self):
        p=formula_project();p['input_tables'][0]['rows'][0]['高さ']='半径 * 4'
        self.assertEqual(sample_value(p,'@高さ',1),30)
        self.assertEqual(list(computed_columns(p['input_tables'][0])),['高さ','半径'])

    def test_column_does_not_leak_between_tables(self):
        p=formula_project();active=p['active_table'];add_input_table(p,'副表',[{'幅':'40','高さ':'幅*2'},{'幅':'50','高さ':''}]);p['active_table']=active
        self.assertEqual(sample_value(p,'@高さ',1),30)
        self.assertEqual(sample_value(p,'[副表]@高さ',1),100)

    def test_fixed_row_cell_variable_uses_its_own_table_and_row(self):
        p=formula_project();active=p['active_table'];add_input_table(p,'副表',[{'幅':'40','半径':'変数.半径'},{'幅':'60','半径':''}]);p['active_table']=active
        self.assertEqual(sample_value(p,'[副表]@半径{2}',0),30)
        self.assertEqual(sample_value(p,'変数.半径',0),5)

    def test_column_wins_over_same_named_global_in_cell_formula(self):
        p=formula_project();p['globals']['幅']='1000'
        self.assertEqual(sample_value(p,'@高さ',1),30)
        self.assertEqual(sample_value(p,'変数.幅',1),1000)

    def test_string_variable_and_computed_row_titles(self):
        p=formula_project();p['globals']['名称']='"品-" + @区分';t=p['input_tables'][0]
        t['rows'][0].update(部品='変数.名称',区分='A');t['rows'][1]['区分']='B'
        self.assertEqual(row_title(p,0),'品-A');self.assertEqual(row_title(p,1),'品-B')

    def test_cycle_between_columns_has_table_row_and_headers(self):
        p=formula_project();p['input_tables'][0]['rows'][0]['高さ']='高さ*2'
        with self.assertRaises(MacroError) as caught:sample_value(p,'@高さ',1)
        self.assertIn('循環参照',str(caught.exception));self.assertIn('部品表',str(caught.exception));self.assertIn('2行目',str(caught.exception));self.assertIn('高さ',str(caught.exception))

    def test_cycle_through_variable_has_cell_location(self):
        p=formula_project();p['globals']['半径']='@半径 / 2'
        with self.assertRaises(MacroError) as caught:compile_project(p,[0])
        self.assertIn('循環参照',str(caught.exception));self.assertIn('変数.半径',str(caught.exception))
        self.assertEqual(caught.exception.location['column'],'半径')

    def test_cross_table_cycle_does_not_recurse_forever(self):
        p=formula_project();active=p['active_table'];p['input_tables'][0]['rows'][0]['高さ']='[副表]@値'
        add_input_table(p,'副表',[{'値':'[部品表]@高さ'}]);p['active_table']=active
        with self.assertRaises(MacroError) as caught:sample_value(p,'@高さ',0)
        self.assertIn('循環参照',str(caught.exception));self.assertIn('副表',str(caught.exception))

    def test_unknown_variable_and_out_of_range_column_fail_clearly(self):
        for formula,part in [('変数.不明','未定義'),('99列目*2','列番号')]:
            p=formula_project();p['input_tables'][0]['rows'][0]['高さ']=formula
            with self.assertRaises(MacroError) as caught:sample_value(p,'@高さ',0)
            self.assertIn(part,str(caught.exception))

    def test_later_rows_cannot_define_formula_even_in_another_column(self):
        p=formula_project();p['input_tables'][0]['rows'][1]['幅']='高さ*2'
        self.assertTrue(any('1行目だけ' in e for e in validate_sequential_project(p)))
        with self.assertRaises(ValueError):normalize_sequential_project(p)

    def test_literal_text_and_escaped_header_name_are_preserved(self):
        p=formula_project();t=p['input_tables'][0];t['rows'][0]['部品']="'幅"
        self.assertEqual(sample_value(p,'@部品',0),'幅')
        t['rows'][0]['部品']='FL-100';self.assertEqual(sample_value(p,'@部品',0),'FL-100')
        t['rows'][0]['高さ']='="2列目＊2"';self.assertEqual(sample_value(p,'@高さ',0),'2列目＊2')

    def test_source_and_json_are_not_overwritten_by_calculation(self):
        p=formula_project();before=copy.deepcopy(p);compile_project(p,[0,1]);sample_value(p,'@半径',1)
        self.assertEqual(p,before);q=normalize_sequential_project(json.loads(json.dumps(p,ensure_ascii=False)))
        self.assertEqual(compile_project(q,[0,1]),compile_project(p,[0,1]))
        self.assertEqual(q['input_tables'][0]['rows'][1]['高さ'],'')

    def test_renaming_table_updates_qualified_first_row_formula(self):
        p=formula_project();active=p['active_table'];add_input_table(p,'副表',[{'値':'8'}]);p['active_table']=active
        p['input_tables'][0]['rows'][0]['高さ']='[副表]@値{1}*2'
        rename_project_table_references(p,'副表','共通寸法');p['input_tables'][1]['name']='共通寸法'
        self.assertEqual(p['input_tables'][0]['rows'][0]['高さ'],'[共通寸法]@値{1}*2')
        self.assertEqual(sample_value(p,'@高さ',1),16)

    def test_audit_checks_unused_formulas_and_accepts_cross_table_references(self):
        p=formula_project();self.assertEqual(audit_project(p),[])
        p['input_tables'][0]['rows'][0]['未使用']='=1/0'
        issues=audit_project(p);self.assertTrue(any('未使用' in str(e) for e in issues))
        p['input_tables'][0]['rows'][0]['未使用']='=[部品表]@幅{1}'
        self.assertEqual(audit_project(p),[])

    def test_japanese_headers_can_be_imported_and_inserted_as_references(self):
        self.assertEqual(headers(['部品','幅','高さ']),['部品','幅','高さ'])
        from input_assist import selected_table_reference
        self.assertEqual(selected_table_reference('部品表','高さ'),'[部品表]@高さ')
        with self.assertRaises(ValueError):headers(['幅 mm'])

    def test_many_rows_are_evaluated_independently(self):
        p=formula_project();rows=p['input_tables'][0]['rows'];rows[1:]=[{'部品':str(i),'幅':str(i),'高さ':'','半径':''} for i in range(1,1001)]
        items=compile_project(p,list(range(1,1001)))[1]
        self.assertEqual(len(items),1000);self.assertEqual(items[0]['coords'],(2,0,0.5));self.assertEqual(items[-1]['coords'],(2000,0,500))

    def test_dependency_depth_is_bounded(self):
        p=formula_project();t=p['input_tables'][0];t['rows'][0]['高さ']='=C0';
        for i in range(40):t['rows'][0]['C'+str(i)]='=C'+str(i+1) if i<39 else '1'
        with self.assertRaises(MacroError) as caught:sample_value(p,'@高さ',0)
        self.assertIn('32段',str(caught.exception))
