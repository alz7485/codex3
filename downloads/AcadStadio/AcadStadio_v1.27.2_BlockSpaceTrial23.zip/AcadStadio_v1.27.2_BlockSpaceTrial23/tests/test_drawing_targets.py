"""Single-row parsing and title lookup are independent of editing selection."""

import copy
import sys
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from project_data import (
    parse_row_number,
    row_title,
    title_table,
    drawing_rows,
    add_input_table,
    target_settings,
)
from sample_project import EXAMPLE
from audit import audit_project


class DrawingTargets(unittest.TestCase):
    def test_single_number_accepts_fullwidth_and_rejects_lists_or_invalid_bounds(self):
        self.assertEqual(parse_row_number(" ２ ", 3), 1)
        for value, count in [
            ("1,3", 3),
            ("1-3", 3),
            ("1、3", 3),
            ("1.0", 3),
            ("", 3),
            ("0", 3),
            ("4", 3),
            ("1", 0),
            ("1" * 100, 3),
        ]:
            with self.subTest(value=value, count=count), self.assertRaises(ValueError):
                parse_row_number(value, count)

    def test_titles_use_the_first_table_leftmost_data_column(self):
        p = copy.deepcopy(EXAMPLE)
        p["input_tables"][0]["rows"] = [
            {"TITLE": 0, "X": 1},
            {"TITLE": "", "X": 2},
            {"X": 3},
        ]
        add_input_table(p, "別の表", [{"TITLE": "別タイトル"}])
        self.assertEqual(title_table(p)[1], "TITLE")
        self.assertEqual(row_title(p, 0), "0")
        self.assertIn("未入力", row_title(p, 1))
        self.assertIn("未入力", row_title(p, 2))
        self.assertIn("該当行なし", row_title(p, 3))

    def test_single_row_and_checkbox_rows_have_different_targets(self):
        p = copy.deepcopy(EXAMPLE)
        target_settings(p).update(mode="range", range="2", selected=[0, 2])
        self.assertEqual(drawing_rows(p), [1])
        target_settings(p)["mode"] = "selected"
        self.assertEqual(drawing_rows(p), [0, 2])
        target_settings(p)["selected"] = []
        self.assertEqual(drawing_rows(p), [])

    def test_audit_rejects_multiple_numbers_in_single_row_mode(self):
        p = copy.deepcopy(EXAMPLE)
        target_settings(p).update(mode="range", range="1,3")
        self.assertTrue(any("行番号は1つ" in str(issue) for issue in audit_project(p)))


if __name__ == "__main__":
    unittest.main()
