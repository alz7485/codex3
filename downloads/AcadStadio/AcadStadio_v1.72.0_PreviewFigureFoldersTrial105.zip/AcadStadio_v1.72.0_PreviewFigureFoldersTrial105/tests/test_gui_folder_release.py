import copy,unittest
import test_gui as gui
import test_folder_release as release_tests
from space_folders import root_for
from block_folders import create_folder

class FolderReleaseGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_right_click_release_visual_slot_undo_redo_and_script(self):
        p,root,before,target,after,child=release_tests.FolderRelease().sample();self.app.replace_document(p);self.root.update();b=self.app.block_browser;t=b.tree
        b.select_folder(target['id']);self.root.update();baseline=copy.deepcopy(self.app.data);script=self.app.compile()[0]
        old=list(t.get_children('folder:'+root));slot=old.index('folder:'+target['id']);members=list(t.get_children('folder:'+target['id']))
        b.prepare_menu();index=next(i for i in range(b.menu.index('end')+1) if b.menu.type(i)=='command' and b.menu.entrycget(i,'label')=='フォルダを解放');b.menu.invoke(index);self.root.update()
        self.assertFalse(t.exists('folder:'+target['id']));self.assertEqual(list(t.get_children('folder:'+root)),old[:slot]+members+old[slot+1:]);self.assertEqual(self.app.compile()[0],script)
        released=copy.deepcopy(self.app.data);self.app.undo_project();self.root.update();self.assertEqual(self.app.data,baseline);self.assertTrue(t.exists('folder:'+target['id']))
        self.app.redo_project();self.root.update();self.assertEqual(self.app.data,released)
    def test_dedicated_root_icons_and_normal_folder_are_distinct(self):
        from space_folders import create_layout
        p,root,*_=release_tests.FolderRelease().sample();p,layout=create_layout(p,'A4');category=create_folder(p,'分類',root)
        self.app.replace_document(p);self.root.update();b=self.app.block_browser;t=b.tree
        model=t.item('folder:'+root,'image');paper=t.item('folder:'+layout,'image');ordinary=t.item('folder:'+category['id'],'image')
        self.assertTrue(model);self.assertTrue(paper);self.assertNotEqual(model,paper);self.assertNotEqual(model,ordinary);self.assertNotEqual(paper,ordinary)
        for identity in (root,layout):
            b.select_folder(identity);b.prepare_menu();index=next(i for i in range(b.menu.index('end')+1) if b.menu.type(i)=='command' and b.menu.entrycget(i,'label')=='フォルダを解放');self.assertEqual(b.menu.entrycget(index,'state'),'disabled')
