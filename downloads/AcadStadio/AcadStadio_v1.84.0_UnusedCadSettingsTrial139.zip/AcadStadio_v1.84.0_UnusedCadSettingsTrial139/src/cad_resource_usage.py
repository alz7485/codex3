"""Conservative current-project resource use; never removes CAD definitions."""
from cad_setup import SECTIONS,STYLE_FIELDS
from command_types import DRAWING_TYPES


def analyze(project,setup=None):
    setup=setup if setup is not None else project.get('cad_setup',{})
    used={k:set() for k in SECTIONS};unknown=set()
    def mark(section,value):
        if not isinstance(value,str):unknown.add(section);return
        if not value.strip():return
        if value.startswith(('=','@','[')):unknown.add(section);return
        if section=='linetypes' and value.casefold() in ('bylayer','byblock'):return
        used[section].add(value.casefold())
    def visit(commands,state):
        for cmd in commands:
            kind=cmd.get('type','').upper()
            if kind in ('CUSTOM','INSERT'):unknown.update(SECTIONS)
            if kind=='LAYEREDIT':mark('layers',cmd.get('target_layer',''))
            dimension=cmd.get('import_source',{}).get('dimension',{})
            overrides=dimension.get('style',{})
            if 'dimtxsty' in overrides:mark('text_styles',overrides['dimtxsty'])
            for key in ('dimltype','dimltex1','dimltex2'):
                if key in overrides:mark('linetypes',overrides[key])
            for part in dimension.get('graphics',[]):
                for field,section in STYLE_FIELDS.items():
                    if part.get(field):mark(section,part[field])
            for field,section in STYLE_FIELDS.items():
                if str(cmd.get(field,'')).strip():mark(section,cmd[field])
            if kind=='APPEARANCE':state.update({k:v for k,v in cmd.items() if k in STYLE_FIELDS and str(v).strip()})
            changes=cmd.get('items',[]) if kind=='SYSVARS' else [cmd] if kind=='SYSVAR' else []
            mapping={'CLAYER':'layer','CELTYPE':'linetype','TEXTSTYLE':'text_style','DIMSTYLE':'dim_style'}
            for change in changes:
                field=mapping.get(str(change.get('name','')).upper())
                if field:
                    value=change.get('value','');mark(STYLE_FIELDS[field],value);state[field]=value
            if kind in DRAWING_TYPES:
                mark('layers',cmd.get('layer') or state.get('layer','0'))
                mark('linetypes',cmd.get('linetype') or state.get('linetype','BYLAYER'))
            if kind in ('TEXT','MTEXT','LEADER'):mark('text_styles',cmd.get('text_style') or state.get('text_style','Standard'))
            if kind in ('DIMLINEAR','DIMALIGNED','DIMRADIUS','DIMDIAMETER','LEADER'):mark('dim_styles',cmd.get('dim_style') or state.get('dim_style','Standard'))
            visit(cmd.get('commands',[]),dict(state));visit(cmd.get('else',[]),dict(state))
    state={}
    for name,field in (('CLAYER','layer'),('CELTYPE','linetype'),('TEXTSTYLE','text_style'),('DIMSTYLE','dim_style')):
        if name in setup.get('drawing_variables',{}):state[field]=setup['drawing_variables'][name]
    blocks=project.get('blocks',[])
    if isinstance(blocks,dict):blocks=[dict(commands=c) for c in blocks.values()]+project.get('presets',[])
    for block in blocks:visit(block.get('commands',[]),state)
    # Only dependencies of used definitions count. An unused layer does not
    # make its linetype used, nor an unused dimension style its text style.
    previous=None
    while previous!=(tuple((k,tuple(sorted(v))) for k,v in used.items()),tuple(sorted(unknown))):
        previous=(tuple((k,tuple(sorted(v))) for k,v in used.items()),tuple(sorted(unknown)))
        if 'layers' in unknown:unknown.add('linetypes')
        if 'dim_styles' in unknown:unknown.add('text_styles')
        for row in setup.get('layers',[]):
            if row['name'].casefold() in used['layers']:mark('linetypes',row.get('linetype','Continuous'))
        for row in setup.get('dim_styles',[]):
            if row['name'].casefold() in used['dim_styles']:
                mark('dim_styles',row.get('base',''));mark('text_styles',row.get('text_style','Standard'))
    return {section:{row['name']:('使用中' if row['name'].casefold() in used[section] else '要確認' if section in unknown else '未使用') for row in setup.get(section,[])} for section in SECTIONS}
