# 1.84.0-beta139の検証

- コア全625件成功。関連GUI6ファイル・27件成功。スモーク成功。GUI全件は今回再実行していません。
- 新規コア7件：未使用定義同士の参照、使用中寸法スタイルの依存、無効ブロック・条件分岐、動的な名前・カスタムコマンド、ステージ中の定義と大文字小文字、循環した元スタイル、読込寸法の個別文字スタイルを検証。
- 新規GUI3件：CAD設定の使用状態と灰色表示、元データを変更しないこと、ステージ中の依存変更で他の一覧の状態が更新されること、読込確認のCAD設定一覧に設定名と状態だけを表示することを確認。
- 関連GUI対象：test_gui_cad_usage139（3）、test_gui_cad_setup（10）、test_gui_cad_drawing_import（5）、test_gui_cad_output135（3）、test_gui_text_viewport137（2）、test_gui_command_groups（4）。最終変更後にCAD使用状態とCAD設定の2ファイルも再確認。
- Linux / Python 3.13 / Tkの実画面で、名前の隣の使用状態と未使用行の灰色表示を確認。画像は配布ZIPへ含めていません。
- この判定は現在のプロジェクト内の参照に基づきます。元DWGでの過去の使用回数を調べたものではありません。動的な指定などは未使用と断定しません。
- Windows実操作、AutoCAD実機での今回の再検証、EXEビルドは未確認です。

```text
python scripts/run_checks.py --mode core
python -m unittest discover -s tests -p test_gui_cad_usage139.py
python -m unittest discover -s tests -p test_gui_cad_setup.py
python tests/smoke_test.py
```
