import unittest,copy
from cad_resource_usage import analyze
from cad_setup import default_setup
from block_model import new_block

class CadUsage139(unittest.TestCase):
 def project(self,commands):
  setup=default_setup();setup.update(layers=[dict(name='A',linetype='DASH'),dict(name='B',linetype='DOT')],linetypes=[dict(name='DASH'),dict(name='DOT')],text_styles=[dict(name='JP'),dict(name='unused')],dim_styles=[dict(name='DIM',base='BASE'),dict(name='BASE',text_style='JP'),dict(name='OLD',text_style='unused')])
  return dict(blocks=[new_block('図面',commands=commands)],cad_setup=setup)
 def test_unused_definitions_do_not_keep_other_unused_definitions_used(self):
  p=self.project([dict(type='LINE',layer='a')]);r=analyze(p)
  self.assertEqual(r['layers'],{'A':'使用中','B':'未使用'});self.assertEqual(r['linetypes'],{'DASH':'使用中','DOT':'未使用'})
  self.assertEqual(r['text_styles']['unused'],'未使用')
 def test_active_dimension_style_dependencies_are_used(self):
  r=analyze(self.project([dict(type='DIMLINEAR',dim_style='dim')]))
  self.assertEqual(r['dim_styles']['BASE'],'使用中');self.assertEqual(r['text_styles']['JP'],'使用中');self.assertEqual(r['dim_styles']['OLD'],'未使用')
 def test_branches_and_disabled_blocks_are_conservatively_retained(self):
  p=self.project([dict(type='IF',condition='False',commands=[dict(type='TEXT',text_style='JP')])]);p['blocks'][0]['enabled']=False
  self.assertEqual(analyze(p)['text_styles']['JP'],'使用中')
 def test_custom_and_dynamic_names_are_not_declared_unused(self):
  r=analyze(self.project([dict(type='LINE',layer='=@L')]))
  self.assertEqual(r['layers']['A'],'要確認');self.assertEqual(r['linetypes']['DOT'],'要確認')
  r=analyze(self.project([dict(type='CUSTOM',name='anything')]))
  self.assertEqual(r['text_styles']['unused'],'要確認')
 def test_pending_definitions_and_casefold_do_not_mutate_project(self):
  p=self.project([dict(type='TEXT',text_style='jp')]);before=copy.deepcopy(p);staged=copy.deepcopy(p['cad_setup']);staged['text_styles'].append(dict(name='new'))
  r=analyze(p,staged);self.assertEqual(r['text_styles']['new'],'未使用');self.assertEqual(p,before)
 def test_circular_bases_terminate(self):
  p=self.project([dict(type='DIMLINEAR',dim_style='DIM')]);p['cad_setup']['dim_styles'][1]['base']='DIM'
  self.assertEqual(analyze(p)['dim_styles']['BASE'],'使用中')

 def test_individual_imported_dimension_settings_keep_fonts_used(self):
  p=self.project([dict(type='DIMLINEAR',dim_style='DIM',import_source=dict(dimension=dict(style=dict(dimtxsty='unused'),graphics=[])))])
  self.assertEqual(analyze(p)['text_styles']['unused'],'使用中')
