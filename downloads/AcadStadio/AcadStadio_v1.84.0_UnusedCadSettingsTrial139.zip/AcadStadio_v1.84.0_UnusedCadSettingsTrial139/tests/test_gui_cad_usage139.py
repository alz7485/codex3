import os,unittest,copy
from unittest.mock import patch
import test_gui as gui
from cad_resource_usage import analyze
from test_cad_setup import project
from cad_drawing_import import imported_project

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI required')
class CadUsageGui139(unittest.TestCase):
 setUp=gui.Gui.setUp
 tearDown=gui.Gui.tearDown
 def test_setup_shows_unused_state_without_modifying_definitions(self):
  p=project();p['cad_setup']['text_styles'].append(dict(name='unused',font='arial.ttf'))
  self.app.replace_document(p);before=copy.deepcopy(self.app.data)
  e=self.app.edit_cad_setup();self.root.update();tree,_=e.forms['text_styles']
  self.assertEqual(tree.set('0','usage'),'使用中');self.assertEqual(tree.set('1','usage'),'未使用')
  self.assertIn('unused',tree.item('1','tags'));self.assertEqual(self.app.data,before)
  e.win.destroy()
 def test_staged_dependency_change_refreshes_other_tables(self):
  self.app.replace_document(project());e=self.app.edit_cad_setup();self.root.update()
  e.data['text_styles'].append(dict(name='new',font='arial.ttf'));e.reload('text_styles')
  e.data['dim_styles'][0]['text_style']='new';e.reload('dim_styles');self.root.update()
  tree,_=e.forms['text_styles'];self.assertEqual(tree.set('1','usage'),'使用中');e.win.destroy()
 def test_import_review_has_usage_only_for_each_definition(self):
  from test_gui_cad_drawing_import import DrawingImportGui
  snapshot=DrawingImportGui.snapshot(self);dialog=self.app.import_cad_drawing(True)
  dialog.result_queue.put((True,(snapshot,[])));dialog.poll();self.root.update()
  expected=analyze(imported_project(snapshot));rows=[dialog.settings_tree.item(i,'values') for i in dialog.settings_tree.get_children()]
  self.assertEqual(len(rows),sum(len(v) for v in expected.values()))
  self.assertTrue(all(len(row)==3 for row in rows));dialog.close()
