"""Retain CAD dimension graphics; regenerate them when numerical inputs change."""
import copy
import json
import math
from functools import lru_cache


def graphics(entity, reader):
    from cad_drawing_import import DrawingReader, GROUPS, imported_project
    from engine import compile_project
    from block_model import new_block
    child=DrawingReader(reader.doc)
    parent=reader.properties(entity)
    layer=reader.doc.layers.get(parent['layer'])
    parent.update(effective_color=int(layer.color) if parent['color']=='256' else int(parent['color']),
                  effective_linetype=layer.dxf.linetype if parent['linetype'].upper()=='BYLAYER' else parent['linetype'],
                  effective_lineweight=-3)
    for part in entity.virtual_entities():
        if part.dxftype()!='POINT' and part.dxf.get('layer','').casefold()!='defpoints':
            child.read(part,parent)
    if child.total>2000:raise ValueError('寸法の構成図形が多すぎます')
    # Only text metrics are needed here; importing resources is an optional,
    # separate user action and must not be triggered by dimension extraction.
    child.setup['text_styles']=[dict(name=s.dxf.name,font=s.dxf.get('font','txt.shx'),width=str(s.dxf.get('width',1)),oblique=str(s.dxf.get('oblique',0)),bigfont=s.dxf.get('bigfont',''),use_bigfont=bool(s.dxf.get('bigfont',''))) for s in reader.doc.styles if s.dxf.get('font','')]
    snapshot=dict(blocks=[new_block('寸法表示',commands=[c for group in GROUPS for c in child.groups[group]])],cad_setup=child.setup)
    _,items=compile_project(imported_project(snapshot),[0])
    if not items:raise ValueError('寸法の描画情報がありません')
    keep=('type','coords','text','angle','width','closed','pattern','scale','start_angle','sweep','color','layer','linetype','linetype_scale','text_style',
          'text_font','text_width','text_oblique','text_generation','text_halign','text_valign','text_anchor','text_line_spacing','text_fit_length')
    return [{k:copy.deepcopy(v) for k,v in item.items() if k in keep} for item in items]


def coordinates(command):
    keys=('x1','y1','x2','y2','x3','y3') if command['type'] in ('DIMLINEAR','DIMALIGNED') else ('x','y','r','x3','y3')
    return tuple(float(command[k]) for k in keys)


def capture(entity,reader,command):
    override=entity.override()
    from dimension_styles import from_dxf
    definition=from_dxf(override.dimstyle)
    for key,native,default in (('scale','dimscale',1),('text_height','dimtxt',2.5),('arrow_size','dimasz',2.5)):
        definition[key]=str(override.dimstyle.dxf.get(native,default))
    definition['text_style']=override.dimstyle.dxf.get('dimtxsty','Standard')
    style={k:v for k,v in override.dimstyle.dxf.all_existing_dxf_attribs().items() if k.startswith('dim') and not k.endswith('_handle')}
    style.update(override.dimstyle_attribs)
    return dict(coords=coordinates(command),axis=command.get('dimension_axis',''),text=command.get('dimension_text',''),dim_style=command.get('dim_style',''),
                graphics=graphics(entity,reader),style=style,style_definition=definition,
                text_position=list(entity.ocs().to_wcs(entity.dxf.text_midpoint)) if entity.dxf.get('dimtype',0)&128 else None,
                text_rotation=entity.dxf.get('text_rotation'),
                text_styles=[dict(name=s.dxf.name,font=s.dxf.get('font',''),width=s.dxf.get('width',1)) for s in reader.doc.styles])


def regenerate(data,item):
    import ezdxf
    from cad_drawing_import import DrawingReader
    doc=ezdxf.new('R2013',setup=True)
    for style in data.get('text_styles',[]):
        target=doc.styles.get(style['name']) if doc.styles.has_entry(style['name']) else doc.styles.new(style['name'])
        for key in ('font','bigfont','width','oblique'):
            if key in style:target.dxf.set(key,float(style[key]) if key in ('width','oblique') else style[key])
    msp=doc.modelspace();c=item['coords'];kind=item['type'];text=item.get('dimension_text','<>')
    args=dict(text=text,override=data.get('style',{}))
    if kind=='DIMLINEAR':
        axis=item.get('dimension_axis','')
        angle=90 if axis=='vertical' else 0 if axis=='horizontal' else 90 if abs(c[4]-(c[0]+c[2])/2)>abs(c[5]-(c[1]+c[3])/2) else 0
        dimension=msp.add_linear_dim(base=c[4:6],p1=c[:2],p2=c[2:4],angle=angle,**args)
    elif kind=='DIMALIGNED':
        dx,dy=c[2]-c[0],c[3]-c[1];distance=((c[4]-c[0])*(-dy)+(c[5]-c[1])*dx)/math.hypot(dx,dy)
        dimension=msp.add_aligned_dim(c[:2],c[2:4],distance,**args)
    else:
        method=msp.add_radius_dim if kind=='DIMRADIUS' else msp.add_diameter_dim
        dimension=method(c[:2],radius=c[2],angle=math.degrees(math.atan2(c[4]-c[1],c[3]-c[0])),location=c[3:5],**args)
    if data.get('text_rotation') is not None:dimension.dimension.dxf.text_rotation=data['text_rotation']
    dimension.render()
    return graphics(dimension.dimension,DrawingReader(doc))


@lru_cache(maxsize=256)
def _generated(signature):
    data,item=json.loads(signature)
    return regenerate(data,item)


def generated(item,values):
    from dimension_styles import effective, override
    settings=values.get('settings',{})
    style=dict(dimlfac=1,dimdec=2,dimclrd=256,dimclre=256,dimclrt=256,dimtxt=float(settings.get('DIM_TEXT_HEIGHT',3.5)),
               dimscale=float(settings.get('DIM_SCALE',1)),dimasz=float(settings.get('ARROW_SIZE',2.5)))
    style.update(override(effective(values.get('__dim_styles__',[]),item.get('dim_style',''))))
    color=item.get('color',256)
    if isinstance(color,int) and 1<=color<=255:style.update(dimclrd=color,dimclre=color,dimclrt=color)
    data=dict(style=style,text_styles=values.get('__text_styles__',[]))
    parts=copy.deepcopy(_generated(json.dumps([data,{k:item[k] for k in ('type','coords','dimension_axis','dimension_text','dimension_angle') if k in item}],sort_keys=True)))
    for part in parts:
        if part.get('layer','0')=='0':
            part['layer']=item.get('layer','0');part['effective_layer']=item.get('effective_layer',part['layer'])
        part['color']=item.get('color',256)
    return parts


def apply(command,item,values,lines):
    data=command.get('import_source',{}).get('dimension')
    if not isinstance(data,dict) or item.get('dim_style','')!=data.get('dim_style',''):
        try:item['block_geometry']=generated(item,values)
        except (ImportError,ValueError,TypeError,KeyError,AttributeError,ArithmeticError) as exc:
            item['preview_note']='寸法の詳細表示を再生成できないため概略表示: '+str(exc)
        return
    # Preserve individual CAD overrides. Apply only definition fields the user
    # has changed since import; equal base values must not erase an override.
    baseline=data.get('style_definition',{})
    from dimension_styles import effective, override
    row=effective(values.get('__dim_styles__',[]),item.get('dim_style',''))
    changes={}
    for key,previous in baseline.items():
        if key not in row:continue
        current=row[key]
        try:equal=float(current)==float(previous)
        except (ValueError,TypeError):equal=current==previous
        if not equal:changes[key]=current
    if changes:
        data=copy.deepcopy(data);data['style'].update(override(changes))
    old=data.get('coords',[]);now=item['coords']
    same=len(old)==len(now) and all(math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-9) for a,b in zip(old,now))
    same=same and data.get('axis','')==item.get('dimension_axis','') and data.get('text','')==item.get('dimension_text','')
    same=same and not changes
    try:
        item['block_geometry']=copy.deepcopy(data['graphics']) if same else regenerate(data,item)
        for part in item['block_geometry']:
            style=next((s for s in values.get('__text_styles__',[]) if s['name'].casefold()==part.get('text_style','').casefold()),None)
            if style:part['text_font']=style.get('font','')
    except (ValueError,TypeError,KeyError,AttributeError,ArithmeticError) as exc:
        item['preview_note']='寸法の詳細表示を再生成できないため概略表示: '+str(exc)
    # DIMOVERRIDE operates on the newly created dimension and leaves system
    # variables unchanged. Names and values are quoted, never evaluated as Lisp.
    from cad_setup import lisp_string
    from cad_setup import cad_name as valid_name
    tokens=[]
    for key,value in sorted(data.get('style',{}).items(),key=lambda entry:entry[0]=='dimsah'):
        if not key.startswith('dim') or not key.isascii() or not key.isalpha():continue
        if isinstance(value,(int,float)) and math.isfinite(value):tokens.extend([lisp_string(key.upper()),str(value)])
        elif isinstance(value,str) and key in ('dimblk','dimblk1','dimblk2','dimldrblk','dimtxsty','dimltype','dimltex1','dimltex2','dimpost'):
            if key.startswith('dimblk') or key=='dimldrblk':
                from dimension_styles import cad_arrow
                value=cad_arrow(value)
            if not value or valid_name(value) or (key=='dimpost' and len(value)<=1024 and all(ord(c)>=32 for c in value)):tokens.extend([lisp_string(key.upper()),lisp_string(value)])
    if tokens:lines.append('(command-s "_.DIMOVERRIDE" '+' '.join(tokens)+' "" (entlast) "")')
    if same and data.get('text_position') is not None:
        position=data['text_position']
        if len(position)==3 and all(isinstance(n,(int,float)) and math.isfinite(n) for n in position):
            lines.append('(progn (vl-load-com) (vla-put-TextPosition (vlax-ename->vla-object (entlast)) (vlax-3d-point (list '+' '.join(format(n,'.15g') for n in position)+'))))')
    rotation=data.get('text_rotation')
    if rotation is not None and isinstance(rotation,(int,float)) and math.isfinite(rotation):
        lines.append('(progn (vl-load-com) (vla-put-TextRotation (vlax-ename->vla-object (entlast)) '+format(math.radians(rotation),'.15g')+'))')
