"""The main block toolbar stays in one row, with direct creation and visibility."""
import copy
import os
import sys
import unittest
from pathlib import Path
from tkinter import ttk
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui


@unittest.skipUnless(sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display unavailable")
class MainToolbarGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_exact_order_icons_and_single_row_at_normal_minimum_and_narrow_pane(self):
        self.assertFalse(hasattr(self.app, "block_tabs"))
        self.assertFalse(hasattr(self.app, "flow_view"))
        self.assertFalse(any(isinstance(w, ttk.Notebook) for w in gui.descendants(self.app.drawing_page)))
        buttons = [w for w in self.app.block_actions.winfo_children() if isinstance(w, (ttk.Button, ttk.Menubutton))]
        self.assertEqual([w.cget("text") for w in buttons],
                         ["ブロック追加", "フォルダ追加", "編集", "↑", "↓", "削除", "表示 ▾"])
        for w in buttons[:6]:
            self.assertTrue(w.cget("image"))
            self.assertEqual(str(w.cget("compound")), "none")
            self.assertTrue(w.tooltip_text)
        self.assertNotEqual(buttons[0].cget("image"), buttons[1].cget("image"))
        self.assertFalse(hasattr(self.app.block_browser, "folder_button"))
        for geometry, sash in (("1320x840", 430), ("1040x680", 430), ("1040x680", 300)):
            with self.subTest(geometry=geometry, sash=sash):
                self.root.geometry(geometry); self.root.update()
                self.app.drawing_panes.sashpos(0, sash); self.root.update()
                self.assertEqual(len({w.winfo_rooty() for w in buttons}), 1)
                for w in buttons:
                    self.assertTrue(w.winfo_ismapped())
                    self.assertGreaterEqual(w.winfo_width(), w.winfo_reqwidth())
                    self.assertLessEqual(w.winfo_rootx()+w.winfo_width(),
                                         self.app.block_actions.winfo_rootx()+self.app.block_actions.winfo_width())

    def test_plus_buttons_create_in_selected_folder_and_support_cancel_and_undo(self):
        with patch("tkinter.simpledialog.askstring", return_value="輪郭"):
            gui.button(self.app.block_actions, "フォルダ追加").invoke()
        self.root.update()
        folder = self.app.data["block_folders"][0]
        self.assertEqual(self.app.block_browser.selected_folder(), folder["id"])
        before = copy.deepcopy(self.app.data)
        gui.button(self.app.block_actions, "ブロック追加").invoke()
        win = gui.top(self.root, "ブロック編集")
        gui.button(win, "キャンセル").invoke()
        self.assertEqual(self.app.data, before)
        gui.button(self.app.block_actions, "ブロック追加").invoke()
        win = gui.top(self.root, "ブロック編集")
        gui.button(win, "ブロックを確定").invoke(); self.root.update()
        self.assertEqual(self.app.data["blocks"][-1]["folder_id"], folder["id"])
        self.app.undo_project(); self.root.update()
        self.assertEqual(self.app.data, before)

    def test_inline_display_menu_changes_only_preview_and_can_expand_folders(self):
        with patch("tkinter.simpledialog.askstring", return_value="輪郭"):
            gui.button(self.app.block_actions, "フォルダ追加").invoke()
        self.root.update(); self.app.preview(quiet=True)
        before = copy.deepcopy(self.app.data); script = self.app.compile()[0]
        scale = self.app.canvas.scale_value; browser = self.app.block_browser
        self.assertIs(browser.visibility_button.master, self.app.block_actions)
        browser.prepare_visibility_menu(); browser.visibility_menu.invoke(1); self.root.update()
        self.assertEqual(self.app.canvas.items, [])
        browser.visibility_menu.invoke(0); self.root.update()
        self.assertTrue(self.app.canvas.items)
        for label, opened in (("フォルダをすべて折りたたむ", False), ("フォルダをすべて展開", True)):
            menu = browser.visibility_menu
            index = next(i for i in range(menu.index("end")+1)
                         if menu.type(i) == "command" and menu.entrycget(i, "label") == label)
            menu.invoke(index); self.root.update()
            self.assertEqual(bool(browser.tree.item("folder:"+before["block_folders"][0]["id"], "open")), opened)
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app.compile()[0], script)
        self.assertEqual(self.app.canvas.scale_value, scale)
