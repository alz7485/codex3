"""Create a source ZIP and manifest, excluding documentation screenshots."""

import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
NAME = "AcadStadio_v1.65.1_TextPreviewMetricsTrial95"
EXCLUDED = {"Data", "__pycache__", ".ruff_cache", ".git", ".venv", "dist", "build"}


def main():
    output = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / (NAME + ".zip")
    files = sorted(
        p
        for p in ROOT.rglob("*")
        if p.is_file()
        and not any(
            part in EXCLUDED or part.endswith("_backups")
            for part in p.relative_to(ROOT).parts
        )
        and p.suffix not in (".pyc", ".tmp", ".zip")
        and not (
            p.relative_to(ROOT).parts[0] == "docs"
            and p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp", ".gif")
        )
        and p.name != "MANIFEST_SHA256.json"
    )
    manifest = {
        "version": 1,
        "release": "1.65.1-beta95",
        "files": {
            str(p.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(
                p.read_bytes()
            ).hexdigest()
            for p in files
        },
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in files:
            archive.write(p, NAME + "/" + p.relative_to(ROOT).as_posix())
        archive.writestr(
            NAME + "/MANIFEST_SHA256.json",
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        )
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        for path, expected in manifest["files"].items():
            assert (
                hashlib.sha256(archive.read(NAME + "/" + path)).hexdigest() == expected
            ), path
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(".zip.sha256").write_text(
        digest + "  " + output.name + "\n", encoding="ascii"
    )
    print(
        f"{output}\n{len(files) + 1} files / {output.stat().st_size:,} bytes\nSHA256 {digest}"
    )


if __name__ == "__main__":
    main()
