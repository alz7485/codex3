"""CAD text layout in drawing units with font metrics and viewport rasterization."""
from dataclasses import dataclass
from functools import lru_cache
import math
import os
from pathlib import Path
import sys
import unicodedata
from PIL import Image, ImageDraw, ImageFont

EM = 256

@lru_cache(maxsize=1)
def font_files():
    roots = [Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts'] if sys.platform == 'win32' else [Path('/usr/share/fonts'), Path('/usr/local/share/fonts'), Path.home()/'.local/share/fonts', Path('/System/Library/Fonts'), Path('/Library/Fonts')]
    return {p.name.casefold():str(p) for root in roots if root.is_dir() for p in sorted(root.rglob('*')) if p.suffix.lower() in ('.ttf','.ttc','.otf')}

@lru_cache(maxsize=64)
def load_font(path):
    return ImageFont.truetype(path,EM) if path else ImageFont.load_default(size=EM)

@lru_cache(maxsize=128)
def resolve_font(requested='',cjk=False):
    files=font_files();name=requested.replace('\\','/').rsplit('/',1)[-1].casefold();preferred=files.get(name)
    if requested and Path(requested).suffix.lower() in ('.ttf','.ttc','.otf') and Path(requested).is_file():preferred=requested
    if preferred:
        try:
            f=load_font(preferred)
            if not cjk or bytes(f.getmask('漢'))!=bytes(f.getmask('\U0010ffff')):return preferred,False
        except OSError:pass
    choices=(['meiryo.ttc','msgothic.ttc','notosanscjk-regular.ttc','hiragino sans gb.ttc'] if cjk else [])+['arial.ttf','dejavusans.ttf','liberationsans-regular.ttf','notosanscjk-regular.ttc']
    for name in choices:
        if name in files:
            try:load_font(files[name]);return files[name],True
            except OSError:pass
    return '',True

@dataclass
class TextLayout:
    lines:tuple
    font:object
    unit:float
    width_factor:float
    oblique:float
    flags:int
    origins:tuple
    box:tuple
    substituted:bool
    def transform(self,x,y):
        x=x*self.width_factor+y*math.tan(math.radians(self.oblique))
        return (-x if self.flags&2 else x),(-y if self.flags&4 else y)

def wrap_lines(text,width,font,unit):
    result=[]
    for paragraph in text.replace('\t','    ').split('\n'):
        start=0
        while start<len(paragraph):
            end=start;low=high=start+1
            while high<len(paragraph) and font.getlength(paragraph[start:high])*unit<=width:
                low=high;high=min(len(paragraph),start+2*(high-start))
            while low<=high:
                mid=(low+high)//2
                if font.getlength(paragraph[start:mid])*unit<=width:end=mid;low=mid+1
                else:high=mid-1
            end=max(start+1,end)
            if end<len(paragraph):
                space=paragraph.rfind(' ',start,end+1)
                if space>start:end=space
            result.append(paragraph[start:end]);start=end
            while start<len(paragraph) and paragraph[start]==' ':start+=1
        if not paragraph:result.append('')
    return tuple(result)

def layout(item):
    keys=('text','text_font','text_width','text_oblique','text_generation','text_halign','text_valign','text_anchor','text_line_spacing','width')
    return cached_layout(item.get('display_type',item['type']),item['coords'][2],tuple((k,item[k]) for k in keys if k in item))

@lru_cache(maxsize=256)
def cached_layout(kind,height,signature):
    item=dict(signature);text=item.get('text','');cjk=any(unicodedata.east_asian_width(c) in ('W','F') for c in text)
    path,substituted=resolve_font(item.get('text_font',''),cjk);font=load_font(path)
    cap=-font.getbbox('H',anchor='ls')[1];unit=height/max(1,cap)
    xheight=-font.getbbox('x',anchor='ls')[1]*unit;descent=font.getbbox('p',anchor='ls')[3]*unit
    factor=item.get('text_width',1.);oblique=item.get('text_oblique',0.);flags=item.get('text_generation',0)
    if kind=='MTEXT':
        lines=wrap_lines(text,item['width']/factor,font,unit);width=item['width']/factor
        step=height*item.get('text_line_spacing',5/3);anchor=item.get('text_anchor','nw')
        left=0 if 'w' in anchor else -width if 'e' in anchor else -width/2
        first=-height if 'n' in anchor else (len(lines)-1)*step+descent if 's' in anchor else ((len(lines)-1)*step-xheight)/2
        advances=[font.getlength(line)*unit for line in lines]
        origins=tuple((0 if 'w' in anchor else -w if 'e' in anchor else -w/2,first-i*step) for i,w in enumerate(advances))
        boxes=[font.getbbox(line or 'H',anchor='ls') for line in lines]
        top=max(height+first,max(-b[1]*unit+o[1] for b,o in zip(boxes,origins)))
        bottom=min(first-(len(lines)-1)*step-descent,min(-b[3]*unit+o[1] for b,o in zip(boxes,origins)))
        box=(left,bottom,left+width,top)
    else:
        lines=(text,);width=font.getlength(text)*unit;x0,y0,x1,y1=font.getbbox(text or ' ',anchor='ls')
        bottom,top=-y1*unit,-y0*unit;ha=item.get('text_halign',0);va=item.get('text_valign',0)
        x=0 if ha==0 else -width if ha==2 else -width/2
        y=descent if va==1 else -height if va==3 else -height/2 if va==2 else -xheight/2 if ha==4 else 0
        origins=((x,y),);box=(x+min(0,x0*unit),bottom+y,x+max(width,x1*unit),top+y)
    return TextLayout(lines,font,unit,factor,oblique,flags,origins,box,substituted)

def corners(item):
    data=layout(item);x,y,u,v=data.box;a=math.radians(item.get('angle',0));ca,sa=math.cos(a),math.sin(a);result=[]
    for px,py in ((x,y),(u,y),(u,v),(x,v)):
        px,py=data.transform(px,py);result.append((item['coords'][0]+px*ca-py*sa,item['coords'][1]+px*sa+py*ca))
    return result

def raster(item,color,screen_point,scale,viewport):
    data=layout(item);left,bottom,right,top=data.box
    density=min(1/data.unit,4090/max(right-left,1e-12),4090/max(top-bottom,1e-12));pad=3
    size=(max(1,math.ceil((right-left)*density)+2*pad),max(1,math.ceil((top-bottom)*density)+2*pad))
    mask=Image.new('L',size);drawing=ImageDraw.Draw(mask)
    fsize=max(1,min(EM,round(EM*data.unit*density)))
    draw_font=ImageFont.truetype(data.font.path,fsize) if getattr(data.font,'path',None) else ImageFont.load_default(size=fsize)
    for line,(x,y) in zip(data.lines,data.origins):
        if line:drawing.text(((x-left)*density+pad,(top-y)*density+pad),line,font=draw_font,fill=255,anchor='ls')
    angle=math.radians(item.get('angle',0));ca,sa=math.cos(angle),math.sin(angle)
    fx,fy=(-1 if data.flags&2 else 1),(-1 if data.flags&4 else 1);shear=math.tan(math.radians(data.oblique))
    a=scale*ca*fx*data.width_factor;b=scale*(ca*fx*shear-sa*fy);c=-scale*sa*fx*data.width_factor;d=-scale*(sa*fx*shear+ca*fy)
    ox,oy=screen_point(*item['coords'][:2]);points=[screen_point(*p) for p in corners(item)]
    x0=max(0,math.floor(min(p[0] for p in points))-2);y0=max(0,math.floor(min(p[1] for p in points))-2)
    x1=min(viewport[0],math.ceil(max(p[0] for p in points))+2);y1=min(viewport[1],math.ceil(max(p[1] for p in points))+2)
    if x1<=x0 or y1<=y0:return Image.new('RGBA',(1,1)),(0,0)
    det=a*d-b*c;aa,bb,cc,dd=d/det,-b/det,-c/det,a/det
    matrix=(density*aa,density*bb,density*(aa*(x0-ox)+bb*(y0-oy)-left)+pad,-density*cc,-density*dd,density*(top-cc*(x0-ox)-dd*(y0-oy))+pad)
    alpha=mask.transform((x1-x0,y1-y0),Image.Transform.AFFINE,matrix,Image.Resampling.BICUBIC)
    image=Image.new('RGBA',alpha.size,color);image.putalpha(alpha);return image,(x0,y0)
