"""Preview-only geometry and reversible repair of drawing-order point links."""
import ast
import copy
import io
import tokenize
from command_points import new_id, rewrite_references
from command_types import DRAWING_TYPES
from block_model import new_block, nested


def point_references(value):
    """Read only literal point-function identities, including formulas with @ columns."""
    if isinstance(value,dict):
        for key,child in value.items():
            if key in ('point_id','guide_origin'):continue
            if key in ('text','layer','linetype','text_style','dim_style') and isinstance(child,str) and not child.startswith('='):continue
            yield from point_references(child)
    elif isinstance(value,list):
        for child in value:yield from point_references(child)
    elif isinstance(value,str) and ('点(' in value or '点位置(' in value):
        try:
            tokens=list(tokenize.generate_tokens(io.StringIO(value).readline))
            for i,token in enumerate(tokens[:-2]):
                if token.type==tokenize.NAME and token.string in ('点','点位置') and tokens[i+1].string=='(' and tokens[i+2].type==tokenize.STRING:
                    identity=ast.literal_eval(tokens[i+2].string)
                    if isinstance(identity,str):yield identity
        except (SyntaxError,ValueError,tokenize.TokenError):return


def forward_links(project):
    blocks=project.get('blocks',[])
    if not isinstance(blocks,list):return []
    positions={b['id']:i for i,b in enumerate(blocks)};sources={}
    for bi,block in enumerate(blocks):
        for ci,top in enumerate(block.get('commands',[])):
            for command in nested([top]):
                if command.get('point_id'):sources[(block['id'],command['point_id'])]=(bi,ci,command)
    result=[]
    for bi,block in enumerate(blocks):
        for ci,command in enumerate(block.get('commands',[])):
            for identity in dict.fromkeys(point_references(command)):
                owner,pid=identity.split('/',1) if '/' in identity else (block['id'],identity)
                found=sources.get((owner,pid))
                if found and (found[0]>bi or (found[0]==bi and found[1]>=ci)):
                    result.append(dict(target_block=block['id'],target_index=ci,source_block=owner,source_point=pid,reference=identity,
                                       target_name=block['name'],source_name=blocks[positions[owner]]['name']))
    return result


def ensure_guide(project):
    blocks=project['blocks']
    guide=next((b for b in blocks if b.get('guide')),None)
    if guide is None:
        names={b['name'].casefold() for b in blocks};name='ガイド';suffix=1
        while name.casefold() in names:name=f'ガイド ({suffix})';suffix+=1
        guide=new_block(name);guide['guide']=True;blocks.insert(0,guide)
    return guide


def pin_guide(project):
    blocks=project.get('blocks',[])
    if isinstance(blocks,list):blocks[:]=[b for b in blocks if b.get('guide')]+[b for b in blocks if not b.get('guide')]


def copy_to_guide(project, owner_id, commands, *, local_commands=None, repair=False):
    """Mutate a staged project only; copy transitive point dependencies before users."""
    blocks=project['blocks'];owners={b['id']:b for b in blocks}
    if owners[owner_id].get('guide'):raise ValueError('このコマンドはすでにガイドです')
    registry={}
    for block in blocks:
        for command in nested(block.get('commands',[])):
            if command.get('point_id'):registry[(block['id'],command['point_id'])]=command
    for command in nested(local_commands or []):
        if command.get('point_id'):registry[(owner_id,command['point_id'])]=command
    guide=ensure_guide(project);mapping={};visiting=set();added=[]
    def convert(owner,command):
        pid=command.get('point_id');key=(owner,pid) if pid else (owner,id(command))
        if owner==guide['id'] and pid:return guide['id']+'/'+pid
        if key in mapping:return mapping[key]
        if key in visiting:raise ValueError('点参照が循環しているためガイド化できません')
        if str(command.get('type','')).upper() not in DRAWING_TYPES:raise ValueError('ガイド化できるのは線・円・寸法などの作図コマンドです')
        for field,value in command.items():
            if not isinstance(value,str) or (field in ('text','layer','linetype','text_style','dim_style','guide_origin') and not value.startswith('=')):continue
            try:
                tokens=list(tokenize.generate_tokens(io.StringIO(value).readline))
                if any(t.type==tokenize.NAME and t.string=='loop' and tokens[i+1].string=='.' for i,t in enumerate(tokens[:-1])):
                    raise ValueError('繰返しの値を使うコマンドは、ループに依存しない式にしてからガイド化してください')
            except tokenize.TokenError:pass
        visiting.add(key);replacements={}
        for identity in point_references(command):
            source,p=identity.split('/',1) if '/' in identity else (owner,identity)
            dependency=registry.get((source,p))
            if dependency is None:raise ValueError('参照元が見つからないためガイド化できません: '+identity)
            replacements[identity]=convert(source,dependency)
        clone=rewrite_references(copy.deepcopy(command),replacements)
        clone['point_id']=new_id();clone['guide_origin']=owners[owner]['name']
        guide['commands'].append(clone);added.append(clone)
        visiting.remove(key);mapping[key]=guide['id']+'/'+clone['point_id']
        return mapping[key]
    for command in commands:convert(owner_id,command)
    if repair:
        links=forward_links(project)
        for link in links:
            owner=link['source_block'];pid=link['source_point']
            replacement=convert(owner,registry[(owner,pid)])
            target=next(b for b in blocks if b['id']==link['target_block'])
            index=link['target_index']
            target['commands'][index]=rewrite_references(target['commands'][index],{link['reference']:replacement})
    pin_guide(project)
    return added


def repair_forward_links(project):
    links=forward_links(project)
    if not links:return 0
    owner=links[0]['source_block']
    added=copy_to_guide(project,owner,[],repair=True)
    return len(added)


def confirm_reference_order(parent, trial):
    from tkinter import messagebox
    pin_guide(trial)
    links=forward_links(trial)
    if not links:return True
    names='\n'.join(dict.fromkeys(f"{x['target_name']} → {x['source_name']}" for x in links))
    answer=messagebox.askyesnocancel('点参照の順序を確認',
        names+'\n\n参照元が使用するコマンドより後ろになります。\nはい：ガイドへコピーし、参照先を切り替える\nいいえ：リンクを保持して警告表示\nキャンセル：並べ替えを取り消す\n\nガイドはCADに図形を作成しません。CADで図形を選択するコマンドは、対象が先に作図済みである必要があります。',parent=parent)
    if answer is None:return False
    if answer:
        try:repair_forward_links(trial)
        except ValueError as exc:
            messagebox.showerror('ガイド化の確認',str(exc),parent=parent);return False
    return True
