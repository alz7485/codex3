from ui_icons import standard_toolbar
from table_grid import GridTreeview
"""Project → block → command tree, with transactional edits and project undo."""

import copy
import tkinter as tk
from tkinter import ttk, messagebox

from block_model import new_block, replace_collection
from macro_editor import edit_command, command_summary
from project_data import input_tables
from project_model import validate_sequential_project as validate_project


class ProjectNavigator(tk.Toplevel):
    def __init__(
        self, parent, project, on_preset, on_blocks, on_changed, undo=None, redo=None
    ):
        super().__init__(parent)
        self.title("プロジェクト構成 · AcadStadio")
        self.geometry("1000x720")
        self.project = project
        self.project_undo, self.project_redo = undo, redo
        # Keep the callback signature compatible with the main window.
        self.on_block, self.on_add_block = on_preset, on_blocks
        self.external_changed = on_changed
        self.on_changed = self.changed
        self.history, self.future = [], []
        self.nodes = {}
        self.view_keys = {}
        self.drag_item = None
        self.command_clipboard = []
        self.clipboard_cut = False
        self.clipboard_origin = None
        self.clipboard_source_id = None
        ttk.Label(
            self,
            text="ブロックは先頭の番号順に実行します。フォルダは整理用です。展開してコマンドを直接編集できます。",
        ).pack(anchor="w", padx=9, pady=7)
        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=8)
        actions = [
            ("ブロック追加", self.on_add_block),
            ("コマンド追加", self.add),
            ("編集", self.edit),
            ("複製", self.duplicate),
            ("削除", self.delete),
            ("↑", lambda: self.move(-1)),
            ("↓", lambda: self.move(1)),
            ("コピー", self.copy_commands),
            ("切り取り", self.cut_commands),
            ("貼り付け", self.paste_commands),
            ("元に戻す", self.undo),
            ("やり直し", self.redo),
        ]
        for i, (label, callback) in enumerate(actions):
            ttk.Button(bar, text=label, command=callback).grid(
                row=0, column=i, padx=2, pady=2, sticky="ew"
            )
        standard_toolbar(bar, grid=True)
        frame = ttk.Frame(self)
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.tree = GridTreeview(
            frame,
            columns=("kind", "detail"),
            show="tree headings",
            selectmode="extended",
        )
        self.tree.heading("#0", text="フォルダ / ブロック / コマンド（番号＝実行順）")
        self.tree.column("#0", width=390)
        self.tree.heading("kind", text="用途")
        self.tree.column("kind", width=100)
        self.tree.heading("detail", text="条件 / 設定")
        self.tree.column("detail", width=470, stretch=False)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(frame, command=self.tree.yview)
        horizontal = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.tree.bind("<Double-1>", self.activate)
        self.tree.bind("<Return>", self.activate)
        self.tree.bind("<ButtonPress-1>", self.drag_start, add="+")
        self.tree.bind("<ButtonRelease-1>", self.drag_end, add="+")
        ttk.Label(
            self,
            text="フォルダの整理はメイン画面のブロック一覧で行います。↑↓・ブロック間ドラッグは実行順だけを変更します。",
            wraplength=960,
        ).pack(anchor="w", padx=8, pady=(0, 8))
        self.refresh()

    def remember(self, node, descriptor):
        """Keep view state attached to stable IDs when the execution order changes."""
        self.nodes[node] = descriptor
        kind = descriptor[0]
        if kind == "folder":
            key = descriptor
        elif kind == "block":
            key = (kind, self.project["blocks"][descriptor[1]]["id"])
        else:
            owner = descriptor[1]
            key = (
                kind,
                self.project["blocks"][owner[1]]["id"],
                *owner[2:],
                *descriptor[2:],
            )
        self.view_keys[node] = key

    def activate(self, event=None):
        self.edit()
        # The Treeview class also toggles a row on double-click. Handle it once.
        return "break"

    @staticmethod
    def _commands(project, owner, create=False):
        commands = project["blocks"][owner[1]]["commands"]
        for index, key in owner[2:]:
            command = commands[index]
            commands = command.setdefault(key, []) if create else command.get(key, [])
        return commands

    def commands(self, owner):
        return self._commands(self.project, owner)

    def record(self):
        self.history.append(copy.deepcopy(self.project["blocks"]))
        self.history = self.history[-100:]
        self.future.clear()

    def changed(self):
        errors = validate_project(self.project)
        if errors:
            if self.history:
                replace_collection(self.project["blocks"], self.history.pop())
            self.refresh()
            messagebox.showerror("構成の確認", "\n".join(errors[:8]), parent=self)
            return False
        self.external_changed()
        return True

    def commit(self, trial, owner=None, index=None, selected_block=None):
        errors = validate_project(trial)
        if errors:
            messagebox.showerror("構成の確認", "\n".join(errors[:8]), parent=self)
            return False
        if trial["blocks"] == self.project["blocks"]:
            return False
        self.record()
        replace_collection(self.project["blocks"], trial["blocks"])
        self.refresh()
        self.external_changed()
        if owner is not None and index is not None:
            self.choose(owner, index)
        elif selected_block is not None:
            self.choose_block(selected_block)
        return True

    def restore(self, state):
        replace_collection(self.project["blocks"], state)
        self.refresh()
        self.external_changed()

    def undo(self):
        if self.project_undo:
            return self.project_undo()
        if self.history:
            self.future.append(copy.deepcopy(self.project["blocks"]))
            self.restore(self.history.pop())

    def redo(self):
        if self.project_redo:
            return self.project_redo()
        if self.future:
            self.history.append(copy.deepcopy(self.project["blocks"]))
            self.restore(self.future.pop())

    def add_commands(self, parent, commands, owner, stack, depth=0, readonly=False):
        if depth > 24:
            return
        for index, command in enumerate(commands):
            if readonly:
                self.reference_budget -= 1
                if self.reference_budget < 0:
                    self.tree.insert(
                        parent,
                        "end",
                        text="以後の参照展開を省略（元ブロックで確認できます）",
                    )
                    return
            typ = command.get("type", "?").upper()
            display = copy.deepcopy(command)
            node = self.tree.insert(
                parent,
                "end",
                text=f"{index + 1:02d}. {typ}"
                + (f" : {display.get('name')}" if display.get("name") else ""),
                values=(
                    "参照" if readonly else "コマンド",
                    command_summary(display)[:250],
                ),
                open=False,
            )
            if not readonly:
                self.remember(node, ("command", owner, index))
            if typ in ("IF", "REPEAT"):
                for key, label in [
                    ("commands", "条件成立時" if typ == "IF" else "繰り返すコマンド")
                ] + ([("else", "ELSE")] if typ == "IF" else []):
                    child_owner = (*owner, (index, key))
                    branch = self.tree.insert(
                        node, "end", text=label, values=("分岐", ""), open=True
                    )
                    if not readonly:
                        self.remember(branch, ("branch", child_owner))
                    self.add_commands(
                        branch,
                        command.get(key, []),
                        child_owner,
                        stack,
                        depth + 1,
                        readonly,
                    )

    def refresh(self):
        selected_paths = {
            self.view_keys[node]
            for node in self.tree.selection()
            if node in self.view_keys
        }
        open_paths = set()
        pending = list(self.tree.get_children())
        while pending:
            node = pending.pop()
            if self.tree.item(node, "open") and node in self.view_keys:
                open_paths.add(self.view_keys[node])
            pending.extend(self.tree.get_children(node))
        known_paths = set(self.view_keys.values())
        self.tree.delete(*self.tree.get_children())
        self.nodes.clear()
        self.view_keys.clear()
        self.reference_budget = 2000
        folders = self.project.get("block_folders", [])
        root = self.tree.insert(
            "",
            "end",
            text="プロジェクト（フォルダ別・番号順に実行）"
            if folders
            else "プロジェクト（ブロック実行順）",
            values=("", ""),
            open=True,
        )
        folder_nodes = {}
        if folders:
            children = {}
            for folder in folders:
                children.setdefault(folder.get("parent_id", ""), []).append(folder)
            ordered = []
            pending = list(reversed(children.get("", [])))
            while pending:
                folder = pending.pop()
                ordered.append(folder)
                pending.extend(reversed(children.get(folder["id"], [])))
            counts = {folder["id"]: 0 for folder in folders}
            for block in self.project["blocks"]:
                identity = block.get("folder_id", "")
                if identity in counts:
                    counts[identity] += 1
            for folder in reversed(ordered):
                parent = folder.get("parent_id", "")
                if parent in counts:
                    counts[parent] += counts[folder["id"]]
            for folder in ordered:
                identity = folder["id"]
                path = ("folder", identity)
                node = self.tree.insert(
                    folder_nodes.get(folder.get("parent_id", ""), root),
                    "end",
                    text=folder["name"],
                    values=("フォルダ", f"{counts[identity]}ブロック（子を含む）"),
                    open=path in open_paths or path not in known_paths,
                )
                folder_nodes[identity] = node
                self.remember(node, path)
            unfiled = self.tree.insert(
                root,
                "end",
                text="未分類",
                values=(
                    "フォルダ",
                    f"{sum(not b.get('folder_id') for b in self.project['blocks'])}ブロック",
                ),
                open=("folder", "") in open_paths
                or ("folder", "") not in known_paths,
            )
            self.remember(unfiled, ("folder", ""))
            folder_nodes[""] = unfiled
        for index, block in enumerate(self.project["blocks"]):
            node = self.tree.insert(
                folder_nodes.get(block.get("folder_id", ""), root),
                "end",
                text=f"{index + 1:02d}. {block['name']}",
                values=(
                    "ブロック",
                    block.get("condition") or "条件なし",
                ),
                open=("block", block["id"]) in open_paths,
            )
            self.remember(node, ("block", index))
            self.add_commands(
                node, block.get("commands", []), ("block", index), (block["id"],)
            )
        data = self.tree.insert(
            root, "end", text="入力表・設定", values=("データ", ""), open=False
        )
        for table in input_tables(self.project):
            self.tree.insert(
                data,
                "end",
                text=table["name"],
                values=("入力表", f"{len(table['rows'])}行"),
            )
        for label, key in (("共通設定", "settings"), ("変数", "globals")):
            self.tree.insert(
                data,
                "end",
                text=label,
                values=("設定", f"{len(self.project.get(key, {}))}件"),
            )
        for node, descriptor in self.nodes.items():
            key = self.view_keys[node]
            if key in open_paths:
                self.tree.item(node, open=True)
            if key in selected_paths:
                self.tree.selection_add(node)

    def selected(self):
        return [
            self.nodes[node] for node in self.tree.selection() if node in self.nodes
        ]

    def command_selection(self):
        selected = self.selected()
        if not selected or any(item[0] != "command" for item in selected):
            return None
        if len({item[1] for item in selected}) != 1:
            return None
        return selected[0][1], sorted({item[2] for item in selected})

    @staticmethod
    def owner_of(item):
        return (
            item[1]
            if item[0] in ("command", "branch")
            else item
            if item[0] == "block"
            else None
        )

    def choose(self, owner, index):
        self.refresh()
        self._select(("command", owner, index))

    def choose_block(self, index):
        self._select(("block", index))

    def select_address(self, address):
        """Reveal an inspected command, including nested IF / ELSE / REPEAT branches."""
        if len(address) < 4 or address[0] != "blocks" or address[2] != "commands" or len(address) % 2:
            return False
        owner = ("block", address[1], *zip(address[3:-1:2], address[4:-1:2]))
        self.refresh()
        return self._select(("command", owner, address[-1]))

    def _select(self, descriptor):
        for node, item in self.nodes.items():
            if item == descriptor:
                self.tree.selection_set(node)
                self.tree.see(node)
                return True
        return False

    def add(self):
        selected = self.selected()
        if len(selected) != 1:
            return messagebox.showinfo(
                "追加先",
                "コマンドを追加するブロックまたは分岐を1件選択してください。",
                parent=self,
            )
        item = selected[0]
        owner = self.owner_of(item)
        if owner is None:
            return
        trial = copy.deepcopy(self.project)
        local_names = trial["blocks"][owner[1]].get("variables", {})
        new = edit_command(
            self,
            {"type": "LINE"},
            trial["blocks"],
            trial,
            local_names,
            folder_id=trial["blocks"][owner[1]].get("folder_id", ""),
        )
        if new is None:
            return
        commands = self._commands(trial, owner, True)
        index = item[2] + 1 if item[0] == "command" else len(commands)
        commands.insert(index, new)
        self.commit(trial, owner, index)

    def edit(self):
        selected = self.selected()
        if len(selected) != 1:
            return
        item = selected[0]
        if item[0] != "command":
            return self.open_selected()
        owner, index = item[1:]
        trial = copy.deepcopy(self.project)
        commands = self._commands(trial, owner)
        local_names = trial["blocks"][owner[1]].get("variables", {})
        edited = edit_command(
            self,
            commands[index],
            trial["blocks"],
            trial,
            local_names,
            folder_id=trial["blocks"][owner[1]].get("folder_id", ""),
        )
        if edited is not None:
            # Nested editing may replace the catalogue contents in place.
            self._commands(trial, owner)[index] = edited
            self.commit(trial, owner, index)

    def open_selected(self):
        selected = self.selected()
        if len(selected) == 1:
            if selected[0][0] == "folder":
                node = self.tree.selection()[0]
                self.tree.item(node, open=not self.tree.item(node, "open"))
                return
            owner = self.owner_of(selected[0])
            if owner:
                self.on_block(owner[1])

    def unique_name(self, base):
        names = {block["name"].casefold() for block in self.project["blocks"]}
        name, suffix = base, 2
        while name.casefold() in names:
            name = f"{base} ({suffix})"
            suffix += 1
        return name

    def duplicate(self):
        selection = self.command_selection()
        trial = copy.deepcopy(self.project)
        if selection:
            owner, indices = selection
            commands = self._commands(trial, owner)
            for index in reversed(indices):
                commands.insert(index + 1, copy.deepcopy(commands[index]))
            return self.commit(trial, owner, indices[0] + 1)
        selected = self.selected()
        if len(selected) == 1 and selected[0][0] == "block":
            index = selected[0][1]
            clone = copy.deepcopy(trial["blocks"][index])
            clone.update(
                id=new_block()["id"], name=self.unique_name(clone["name"] + " コピー")
            )
            trial["blocks"].insert(index + 1, clone)
            self.commit(trial, selected_block=index + 1)

    def delete(self):
        selection = self.command_selection()
        trial = copy.deepcopy(self.project)
        if selection:
            owner, indices = selection
            commands = self._commands(trial, owner)
            for index in reversed(indices):
                commands.pop(index)
            return self.commit(trial)
        selected = self.selected()
        if len(selected) != 1 or selected[0][0] != "block":
            return
        index = selected[0][1]
        block = self.project["blocks"][index]
        if not messagebox.askyesno(
            "ブロックを削除", f"「{block['name']}」を削除しますか？", parent=self
        ):
            return
        trial["blocks"].pop(index)
        self.commit(trial)

    def copy_commands(self):
        selection = self.command_selection()
        if not selection:
            return messagebox.showinfo(
                "コピー",
                "同じブロック・分岐内のコマンドを選択してください。",
                parent=self,
            )
        owner, indices = selection
        self.command_clipboard = copy.deepcopy(
            [self.commands(owner)[index] for index in indices]
        )
        self.clipboard_cut = False
        self.clipboard_origin = None
        self.clipboard_source_id = None

    def cut_commands(self):
        selection = self.command_selection()
        if not selection:
            return messagebox.showinfo(
                "切り取り",
                "同じブロック・分岐内のコマンドを選択してください。",
                parent=self,
            )
        owner, indices = selection
        self.command_clipboard = copy.deepcopy(
            [self.commands(owner)[index] for index in indices]
        )
        self.clipboard_cut = True
        self.clipboard_origin = (owner, indices)
        self.clipboard_source_state = copy.deepcopy(self.commands(owner))
        self.clipboard_source_id = self.project["blocks"][owner[1]]["id"]
        # Keep the source until a validated paste succeeds.

    def paste_commands(self):
        if not self.command_clipboard:
            return messagebox.showinfo(
                "貼り付け",
                "先にコマンドをコピーまたは切り取ってください。",
                parent=self,
            )
        chosen = self.selected()
        if len(chosen) != 1:
            return messagebox.showwarning(
                "貼り付け",
                "貼り付け先のブロック・分岐・コマンドを1件選択してください。",
                parent=self,
            )
        target = chosen[0]
        owner = self.owner_of(target)
        if owner is None:
            return
        if self.clipboard_cut and self.clipboard_origin:
            old_owner, indices = self.clipboard_origin
            try:
                unchanged = (
                    self.project["blocks"][old_owner[1]]["id"]
                    == self.clipboard_source_id
                    and self.commands(old_owner) == self.clipboard_source_state
                )
            except (KeyError, IndexError, TypeError):
                unchanged = False
            if not unchanged:
                return messagebox.showerror(
                    "切り取り元が変更されました",
                    "元のコマンドをもう一度切り取ってください。",
                    parent=self,
                )
            if (
                owner[: len(old_owner)] == old_owner
                and len(owner) > len(old_owner)
                and owner[len(old_owner)][0] in indices
            ):
                return messagebox.showerror(
                    "貼り付け先の確認",
                    "切り取ったコマンドの内側には移動できません。",
                    parent=self,
                )
        trial = copy.deepcopy(self.project)
        destination = self._commands(trial, owner, True)
        position = target[2] + 1 if target[0] == "command" else len(destination)
        if self.clipboard_cut and self.clipboard_origin:
            old_owner, indices = self.clipboard_origin
            source = self._commands(trial, old_owner)
            for index in reversed(indices):
                source.pop(index)
            if destination is source:
                position -= sum(index < position for index in indices)
        position = max(0, min(position, len(destination)))
        destination[position:position] = copy.deepcopy(self.command_clipboard)
        selected_owner = owner
        if self.clipboard_cut and self.clipboard_origin:
            old_owner, indices = self.clipboard_origin
            if owner[: len(old_owner)] == old_owner and len(owner) > len(old_owner):
                parent_index, key = owner[len(old_owner)]
                shifted = parent_index - sum(index < parent_index for index in indices)
                selected_owner = (
                    *owner[: len(old_owner)],
                    (shifted, key),
                    *owner[len(old_owner) + 1 :],
                )
        if self.commit(trial, selected_owner, position):
            self.clipboard_cut = False
            self.clipboard_origin = None
            self.clipboard_source_id = None

    def move(self, delta):
        selected = self.selected()
        if len(selected) != 1:
            return
        item = selected[0]
        trial = copy.deepcopy(self.project)
        if item[0] == "command":
            owner, index = item[1:]
            commands = self._commands(trial, owner)
            other = index + delta
            if 0 <= other < len(commands):
                commands[index], commands[other] = commands[other], commands[index]
                self.commit(trial, owner, other)
        elif item[0] == "block":
            index = item[1]
            other = index + delta
            if 0 <= other < len(trial["blocks"]):
                trial["blocks"][index], trial["blocks"][other] = (
                    trial["blocks"][other],
                    trial["blocks"][index],
                )
                self.commit(trial, selected_block=other)

    def drag_start(self, event):
        self.drag_item = self.nodes.get(self.tree.identify_row(event.y))

    def drag_end(self, event):
        source, self.drag_item = self.drag_item, None
        target = self.nodes.get(self.tree.identify_row(event.y))
        if not source or not target or source == target:
            return
        trial = copy.deepcopy(self.project)
        if source[0] == target[0] == "block":
            value = trial["blocks"].pop(source[1])
            trial["blocks"].insert(target[1], value)
            self.commit(trial, selected_block=target[1])
        elif source[0] == target[0] == "command" and source[1] == target[1]:
            owner = source[1]
            commands = self._commands(trial, owner)
            commands.insert(target[2], commands.pop(source[2]))
            self.commit(trial, owner, target[2])
