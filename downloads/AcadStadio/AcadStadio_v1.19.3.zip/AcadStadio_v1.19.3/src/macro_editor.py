"""Transactional preset/block editors and nested IF/REPEAT command forms."""

from project_data import get_rows
import copy
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from engine import compile_project, parse_expression, MacroError
from project_model import validate_project, walk_commands, valid_name
from preview import DrawingCanvas
from theme import fit_window
from cad_setup import STYLE_FIELDS, names as resource_names
from expression_sample import sample_value
from block_model import new_block, index_of, named, replace_collection

FIELDS = {
    "LINE": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y"),
    ],
    "CIRCLE": [("layer", ""), ("x", "@X"), ("y", "@Y"), ("r", "@OD / 2")],
    "RECTANGLE": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y + 50"),
    ],
    "TEXT": [
        ("layer", ""),
        ("x", "@X"),
        ("y", "@Y"),
        ("height", "settings.TEXT_HEIGHT"),
        ("angle", "0"),
        ("text", "@TYPE"),
    ],
    "DIMLINEAR": [
        ("layer", ""),
        ("x1", "@X"),
        ("y1", "@Y"),
        ("x2", "@X + 100"),
        ("y2", "@Y"),
        ("x3", "@X + 50"),
        ("y3", "@Y + 30"),
    ],
    "SET": [("name", "VALUE"), ("value", "0")],
    "BLOCK": [("name", "")],
    "IF": [("condition", '@TYPE == "A"')],
    "REPEAT": [("count", "3")],
    "SYSVAR": [
        ("name", "OSMODE"),
        ("value_kind", "number"),
        ("value", "0"),
        ("execution", "per_row"),
    ],
    "CUSTOM": [],
}
TYPE_LABELS = {
    "LINE": "LINE · 線分",
    "CIRCLE": "CIRCLE · 円",
    "RECTANGLE": "RECTANGLE · 長方形",
    "TEXT": "TEXT · 文字",
    "DIMLINEAR": "DIMLINEAR · 長さ寸法",
    "SET": "SET · ローカル変数への代入",
    "BLOCK": "BLOCK · ブロック呼出",
    "IF": "IF / ELSE · 条件分岐",
    "REPEAT": "REPEAT · 繰り返し",
    "SYSVAR": "SYSVAR · システム変数変更",
    "CUSTOM": "CUSTOM · ユーザー登録コマンド",
}
LABELS = {
    "text_style": "文字スタイル",
    "dim_style": "寸法スタイル",
    "linetype": "線種",
    "layer": "レイヤー",
    "x": "中心 / 挿入 X",
    "y": "中心 / 挿入 Y",
    "x1": "始点 X",
    "y1": "始点 Y",
    "x2": "終点 X",
    "y2": "終点 Y",
    "x3": "寸法位置 X",
    "y3": "寸法位置 Y",
    "r": "半径",
    "height": "文字高さ（図面単位）",
    "angle": "回転角度（°）",
    "text": "文字列",
    "name": "名前",
    "value": "代入する式",
    "condition": "実行条件（式）",
    "count": "反復回数（式）",
    "value_kind": "値の種類",
    "execution": "実行回数",
}


def command_summary(cmd):
    typ = cmd.get("type", "?").upper()
    if typ == "IF":
        return f"{cmd.get('condition', '')}  → {len(cmd.get('commands', []))}件 / ELSE {len(cmd.get('else', []))}件"
    if typ == "REPEAT":
        return f"{cmd.get('count', '')} 回 × {len(cmd.get('commands', []))}件"
    return ", ".join(
        f"{LABELS.get(k, k)}: {v}"
        for k, v in cmd.items()
        if k not in ("type", "commands", "else")
    )


def edit_command(
    parent, current, blocks, project=None, local_names=(), *, sample_locals=None,
    folder_id="",
):
    win = tk.Toplevel(parent)
    win.title("コマンドの設定")
    fit_window(win, 860, 640, 760, 580)
    win.transient(parent.winfo_toplevel())
    win.grab_set()
    working = copy.deepcopy(current)
    result = []
    entries = {}
    variables = {}
    argument_vars = {}
    selected_custom = [current.get("name", "")]
    focused = [None]
    old_type = current.get("type", "LINE").upper()
    drafts = {old_type: copy.deepcopy(current)}
    choice = tk.StringVar(value=TYPE_LABELS.get(old_type, TYPE_LABELS["LINE"]))
    header = ttk.Frame(win, padding=(16, 14))
    header.pack(fill="x")
    ttk.Label(header, text="作図コマンド", style="Section.TLabel").pack(side="left")
    picker = ttk.Combobox(
        header,
        textvariable=choice,
        values=list(TYPE_LABELS.values()),
        state="readonly",
        width=32,
    )
    picker.pack(side="right")
    body = ttk.Frame(win, padding=(16, 0))
    body.pack(fill="both", expand=True)
    body.columnconfigure(0, weight=3)
    body.columnconfigure(1, weight=2)
    body.rowconfigure(0, weight=1)
    left = ttk.Frame(body)
    left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
    viewport = tk.Canvas(left, highlightthickness=0, bg="#f3f5f9")
    scroll = ttk.Scrollbar(left, command=viewport.yview)
    scroll.pack(side="right", fill="y")
    viewport.pack(side="left", fill="both", expand=True)
    viewport.configure(yscrollcommand=scroll.set)
    form = ttk.Frame(viewport)
    form_window = viewport.create_window(0, 0, window=form, anchor="nw")
    viewport.bind(
        "<Configure>", lambda e: viewport.itemconfigure(form_window, width=e.width)
    )
    form.bind(
        "<Configure>", lambda e: viewport.configure(scrollregion=viewport.bbox("all"))
    )

    refs = ttk.LabelFrame(body, text="参照式を挿入", padding=10)
    refs.grid(row=0, column=1, sticky="nsew")
    refs.columnconfigure(0, weight=1)
    refs.rowconfigure(2, weight=1)
    ttk.Label(
        refs,
        text="入力欄を選び、候補をダブルクリック",
        style="Muted.TLabel",
        wraplength=250,
    ).grid(row=0, column=0, sticky="w")
    query = tk.StringVar()
    ttk.Entry(refs, textvariable=query).grid(row=1, column=0, sticky="ew", pady=7)
    listing = tk.Listbox(
        refs,
        exportselection=False,
        relief="flat",
        bg="white",
        activestyle="none",
        height=10,
    )
    listing.grid(row=2, column=0, sticky="nsew")
    project = project or {}
    sample_frame = ttk.LabelFrame(refs, text="選択した入力欄の試算", padding=8)
    sample_frame.grid(row=5, column=0, sticky="ew", pady=(6, 0))
    sample_row = tk.StringVar(value="1")
    sample_picker = ttk.Combobox(
        sample_frame,
        textvariable=sample_row,
        values=[str(i + 1) for i in range(len(get_rows(project)))],
        state="readonly",
        width=8,
    )
    ttk.Label(sample_frame, text="試算する行:").pack(side="left")
    sample_picker.pack(side="left", padx=5)
    sample_result = tk.StringVar(value="数値・条件の入力欄を選択してください")
    ttk.Label(refs, textvariable=sample_result, wraplength=250).grid(
        row=6, column=0, sticky="ew", pady=6
    )
    # Expose state for keyboard/accessibility tooling and real-widget regression tests.
    win.sample_result, win.sample_row = sample_result, sample_row

    def update_sample(*_):
        key = next((k for k, widget in entries.items() if widget is focused[0]), None)
        var = variables.get(key)
        if key and key.startswith("arg:"):
            var = argument_vars.get(key[4:])
            kind = next(
                (
                    p["kind"]
                    for p in project.get("custom_commands", {})
                    .get(selected_custom[0], {})
                    .get("parameters", [])
                    if p["name"] == key[4:]
                ),
                "text",
            )
            if kind != "number":
                sample_result.set("文字引数です。数値欄を選ぶと試算できます。")
                return
        if key in STYLE_FIELDS:
            sample_result.set(
                "空欄は直前の設定を引き継ぎます。先頭ではCADの現在の設定を使います。"
            )
            return
        if key in ("name", "text", "execution", "value_kind") or var is None:
            sample_result.set("数値・条件の入力欄を選択してください")
            return
        text = var.get().strip()
        if not text and key == "condition":
            sample_result.set("条件なし: 常に実行")
            return
        if (
            key == "value"
            and active[0] == "SYSVAR"
            and variables.get("value_kind").get() == "text"
        ):
            sample_result.set("文字列の値です")
            return
        try:
            value = sample_value(
                project, text, max(0, int(sample_row.get()) - 1), sample_locals
            )
            rendered = f"{value:.12g}" if type(value) in (int, float) else str(value)
            sample_result.set(
                f"{sample_row.get()}行目 → {rendered}\nSET・loopの値は実行時に確定します。"
            )
        except (MacroError, ValueError, IndexError) as exc:
            sample_result.set("試算できません: " + str(exc))

    def focus_sample(event):
        focused[0] = event.widget
        update_sample()

    sample_row.trace_add("write", update_sample)
    keys = list(dict.fromkeys(k for row in get_rows(project) for k in row))
    candidates = (
        ["@" + k for k in keys]
        + ["settings." + k for k in project.get("settings", {})]
        + ["global." + k for k in project.get("globals", {})]
        + ["local." + k for k in local_names]
        + ["loop.index", "loop.number", "loop.count"]
    )

    def filter_refs(*_):
        listing.delete(0, "end")
        for ref in dict.fromkeys(candidates):
            if query.get().lower() in ref.lower():
                listing.insert("end", ref)

    query.trace_add("write", filter_refs)
    filter_refs()

    def insert_ref(*_):
        selected = listing.curselection()
        entry = focused[0]
        if not selected or entry is None or not entry.winfo_exists():
            return
        value = listing.get(selected[0])
        key = next((k for k, e in entries.items() if e is entry), "")
        param_kind = next(
            (
                p["kind"]
                for p in project.get("custom_commands", {})
                .get(selected_custom[0], {})
                .get("parameters", [])
                if "arg:" + p["name"] == key
            ),
            None,
        )
        is_sysvar_text = (
            key == "value"
            and active[0] == "SYSVAR"
            and variables.get("value_kind") is not None
            and variables["value_kind"].get() == "text"
        )
        if (
            key in ("text", "layer") or param_kind == "text" or is_sysvar_text
        ) and not entry.get():
            if key == "text" and value.startswith("@"):
                pass
            else:
                entry.insert(0, "=")
        entry.insert(tk.INSERT, value)
        entry.focus_set()

    listing.bind("<Double-1>", insert_ref)
    ttk.Button(
        refs, text="選択した参照を挿入", command=insert_ref, style="Compact.TButton"
    ).grid(row=3, column=0, sticky="ew", pady=(6, 0))
    ttk.Label(
        refs,
        text="loop.index: 0始まり / number: 1始まり\nloop.count: 反復回数（繰り返し内のみ）",
        style="Muted.TLabel",
        wraplength=250,
    ).grid(row=4, column=0, sticky="w", pady=(6, 0))
    active = [old_type]

    def gather():
        data = {
            "type": active[0],
            **working,
            **{k: v.get() for k, v in variables.items()},
        }
        if active[0] == "CUSTOM":
            data.update(
                name=selected_custom[0],
                arguments={k: v.get() for k, v in argument_vars.items()},
            )
        return data

    def branch(key):
        working.update({k: v.get() for k, v in variables.items()})
        staged = copy.deepcopy(working.get(key, []))
        before_blocks = copy.deepcopy(blocks)
        sub = tk.Toplevel(win)
        sub.title(
            "IF: 実行する側"
            if key == "commands" and active[0] == "IF"
            else "ELSE: 条件に合わない側"
            if key == "else"
            else "繰り返すコマンド"
        )
        sub.geometry("880x540")
        sub.transient(win)
        sub.grab_set()
        ttk.Label(
            sub, text="ここに追加したコマンドを、上から順番に実行します。", padding=12
        ).pack(anchor="w")
        editor = CommandList(
            sub,
            staged,
            blocks,
            project=project,
            local_names=sample_locals or local_names,
            folder_id=folder_id,
        )

        def cancel():
            if (
                staged != working.get(key, []) or blocks != before_blocks
            ) and not messagebox.askyesno(
                "変更の破棄", "この階層の変更を破棄しますか？", parent=sub
            ):
                return
            replace_collection(blocks, before_blocks)
            sub.destroy()

        def commit():
            working[key] = copy.deepcopy(editor.commands)
            sub.destroy()

        bar = ttk.Frame(sub, padding=10)
        bar.pack(side="bottom", fill="x", before=editor.frame)
        ttk.Button(bar, text="キャンセル", command=cancel).pack(side="left")
        ttk.Button(
            bar, text="この階層を確定", style="Primary.TButton", command=commit
        ).pack(side="right")
        sub.protocol("WM_DELETE_WINDOW", cancel)
        sub.bind("<Escape>", lambda e: cancel())
        win.wait_window(sub)
        win.grab_set()
        redraw(False)

    def redraw(changed=True):
        if changed:
            drafts[active[0]] = gather()
            typ = next(k for k, v in TYPE_LABELS.items() if v == choice.get())
            active[0] = typ
            working.clear()
            working.update(copy.deepcopy(drafts.get(typ, {"type": typ})))
        for widget in form.winfo_children():
            widget.destroy()
        entries.clear()
        variables.clear()
        argument_vars.clear()
        focused[0] = None
        typ = active[0]
        if typ == "CUSTOM":
            catalog = project.get("custom_commands", {})
            if selected_custom[0] not in catalog:
                selected_custom[0] = next(iter(catalog), "")
            row = ttk.Frame(form)
            row.pack(fill="x", pady=4)
            ttk.Label(row, text="登録したコマンド", width=18).pack(side="left")
            names = {k: d["name"] for k, d in catalog.items()}
            custom_choice = tk.StringVar(value=names.get(selected_custom[0], ""))
            combo = ttk.Combobox(
                row,
                textvariable=custom_choice,
                values=list(names.values()),
                state="readonly",
            )
            combo.pack(side="left", fill="x", expand=True)

            def choose_custom(_=None):
                working["condition"] = variables.get(
                    "condition", tk.StringVar(value="")
                ).get()
                selected_custom[0] = next(
                    (k for k, v in names.items() if v == custom_choice.get()), ""
                )
                working["name"] = selected_custom[0]
                working["arguments"] = {}
                redraw(False)

            combo.bind("<<ComboboxSelected>>", choose_custom)
            if not catalog:
                ttk.Label(
                    form,
                    text="メイン画面の「登録コマンド」から新規登録できます。",
                    wraplength=400,
                ).pack(anchor="w", pady=12)
            definition = catalog.get(selected_custom[0], {})
            ttk.Label(
                form,
                text=definition.get("description", ""),
                style="Muted.TLabel",
                wraplength=400,
            ).pack(anchor="w", pady=8)
            ttk.Label(
                form,
                text="実行: "
                + (
                    "生成全体で1回"
                    if definition.get("execution") == "once"
                    else "対象の各行"
                )
                + " / 図形プレビュー対象外",
                style="Muted.TLabel",
                wraplength=400,
            ).pack(anchor="w", pady=(0, 7))
            for param in definition.get("parameters", []):
                row = ttk.Frame(form)
                row.pack(fill="x", pady=4)
                ttk.Label(row, text=param.get("label", param["name"]), width=18).pack(
                    side="left"
                )
                original = (
                    working.get("arguments", {})
                    if working.get("name") == selected_custom[0]
                    else {}
                )
                value = tk.StringVar(
                    value=str(original.get(param["name"], param.get("default", "")))
                )
                entry = ttk.Entry(row, textvariable=value)
                entry.pack(side="left", fill="x", expand=True)
                argument_vars[param["name"]] = value
                entries["arg:" + param["name"]] = entry
                entry.bind("<FocusIn>", focus_sample)
                value.trace_add("write", update_sample)
        fields = list(FIELDS[typ])
        if typ in ("LINE", "CIRCLE", "RECTANGLE", "TEXT", "DIMLINEAR"):
            fields.insert(1, ("linetype", ""))
        if typ == "TEXT":
            fields.insert(2, ("text_style", ""))
        if typ == "DIMLINEAR":
            fields.insert(2, ("dim_style", ""))
        if typ != "IF":
            fields.append(("condition", ""))
        for key, default in fields:
            row = ttk.Frame(form)
            row.pack(fill="x", pady=4)
            ttk.Label(row, text=LABELS.get(key, key), width=18).pack(side="left")
            value = tk.StringVar(value=str(working.get(key, default)))
            if key in STYLE_FIELDS:
                entry = ttk.Combobox(
                    row,
                    textvariable=value,
                    values=["", *resource_names(project, STYLE_FIELDS[key])],
                )
            elif typ == "BLOCK" and key == "name":
                if isinstance(blocks, list):
                    labels = {b["name"]: b["id"] for b in blocks}
                    display = tk.StringVar(value=named(blocks, value.get()))
                    display.trace_add(
                        "write",
                        lambda *_, v=value, d=display, names=labels: v.set(
                            names.get(d.get(), d.get())
                        ),
                    )
                    entry = ttk.Combobox(
                        row, textvariable=display, values=list(labels), state="readonly"
                    )
                    entry._block_display = display
                else:
                    entry = ttk.Combobox(
                        row, textvariable=value, values=list(blocks), state="readonly"
                    )
            elif key in ("value_kind", "execution"):
                entry = ttk.Combobox(
                    row,
                    textvariable=value,
                    values=["number", "text"]
                    if key == "value_kind"
                    else ["per_row", "once"],
                    state="readonly",
                )
            else:
                entry = ttk.Entry(row, textvariable=value)
            entry.pack(side="left", fill="x", expand=True)
            variables[key] = value
            entries[key] = entry
            entry.bind("<FocusIn>", focus_sample)
            value.trace_add("write", update_sample)
        if typ in ("IF", "REPEAT"):
            for key, label in [
                ("commands", "実行するコマンド" if typ == "IF" else "繰り返すコマンド")
            ] + ([("else", "ELSE のコマンド")] if typ == "IF" else []):
                ttk.Button(
                    form,
                    text=f"{label}を編集（{len(working.get(key, []))}件）",
                    command=lambda k=key: branch(k),
                ).pack(fill="x", pady=(12, 0))
        tips = "条件が空欄なら常に実行。数値欄には値・列参照・計算式を入力できます。\nレイヤー・線種・スタイルの空欄は直前の設定を引き継ぎます。座標・長さは図面単位です。"
        if typ == "TEXT":
            tips += "\n文字列はそのまま入力。式で組み立てるときは = で始めます。"
        if typ == "SYSVAR":
            tips += "\nnumberは数値・式、textは文字列（=式も可）。onceは生成全体で1回。"
        if typ == "CUSTOM":
            tips += "\n数値引数は式、文字列引数はそのまま入力（=式も可）。登録内容はメイン画面で編集できます。"
        if typ == "REPEAT":
            tips += "\n回数は0〜1000の整数。内側で loop.index を参照できます。"
        ttk.Label(form, text=tips, style="Muted.TLabel", wraplength=420).pack(
            anchor="w", pady=15
        )

    redraw(False)
    picker.bind("<<ComboboxSelected>>", lambda e: redraw())
    original_blocks = copy.deepcopy(blocks)

    def cancel():
        if (
            gather() != current or blocks != original_blocks
        ) and not messagebox.askyesno(
            "変更の破棄", "コマンドの変更を破棄しますか？", parent=win
        ):
            return
        replace_collection(blocks, original_blocks)
        win.destroy()

    def accept():
        d = gather()
        d["type"] = active[0]
        if d["type"] == "BLOCK" and d.get("name") not in (
            [b["id"] for b in blocks] if isinstance(blocks, list) else blocks
        ):
            return messagebox.showerror(
                "ブロックの選択", "存在するブロックを選択してください", parent=win
            )
        if d["type"] == "SET" and not valid_name(d.get("name")):
            return messagebox.showerror(
                "変数名",
                "英数字と_の名前を指定してください。予約名は使えません",
                parent=win,
            )
        try:
            for k, v in variables.items():
                text = v.get().strip()
                if k in (
                    "name",
                    "layer",
                    "text",
                    "value_kind",
                    "execution",
                    "linetype",
                    "text_style",
                    "dim_style",
                ):
                    continue
                if (
                    k == "value"
                    and d["type"] == "SYSVAR"
                    and d.get("value_kind") == "text"
                ):
                    if text.startswith("="):
                        parse_expression(text[1:])
                    continue
                if k in ("name", "layer", "text"):
                    continue
                if not text:
                    if k == "condition" and d["type"] != "IF":
                        continue
                    raise MacroError(LABELS.get(k, k) + " を入力してください")
                parse_expression(text)
        except MacroError as exc:
            return messagebox.showerror("入力内容の確認", str(exc), parent=win)
        if d["type"] == "CUSTOM":
            catalog = project.get("custom_commands", {})
            if d.get("name") not in catalog:
                return messagebox.showerror(
                    "登録コマンド", "コマンドを登録・選択してください", parent=win
                )
            try:
                for param in catalog[d["name"]].get("parameters", []):
                    value = d["arguments"][param["name"]]
                    if param["kind"] == "number":
                        parse_expression(value)
                    elif value.startswith("="):
                        parse_expression(value[1:])
            except MacroError as exc:
                return messagebox.showerror("引数の確認", str(exc), parent=win)
        if d["type"] == "SYSVAR":
            import re

            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", d["name"]):
                return messagebox.showerror(
                    "システム変数名", "例: OSMODE / CMDECHO", parent=win
                )
        result.append(d)
        win.destroy()

    bar = ttk.Frame(win, padding=16)
    bar.pack(side="bottom", fill="x", before=body)
    ttk.Button(bar, text="キャンセル", command=cancel).pack(side="left")
    ttk.Button(
        bar, text="コマンドを確定", style="Primary.TButton", command=accept
    ).pack(side="right")
    win.protocol("WM_DELETE_WINDOW", cancel)
    win.bind("<Escape>", lambda e: cancel())
    parent.wait_window(win)
    try:
        parent.winfo_toplevel().grab_set() if parent.winfo_toplevel() is not parent._root() else None
    except tk.TclError:
        pass
    return result[0] if result else None


class CommandList:
    def __init__(
        self,
        parent,
        commands,
        blocks,
        on_select=None,
        on_change=None,
        project=None,
        local_names=(),
        folder_id="",
    ):
        self.commands = commands
        self.blocks = blocks
        self.on_select = on_select
        self.on_change = on_change
        self.project = project
        self.local_names = local_names
        self.folder_id = folder_id
        self.undo_stack = []
        self.redo_stack = []
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.frame.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)
        self.tree = ttk.Treeview(
            self.frame,
            columns=("type", "detail"),
            show="headings",
            selectmode="extended",
            height=7,
        )
        for key, label, width in [
            ("type", "コマンド", 190),
            ("detail", "設定 / 条件", 480),
        ]:
            self.tree.heading(key, text=label)
            self.tree.column(key, width=width, minwidth=120)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(self.frame, command=self.tree.yview)
        ys.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=ys.set)
        xs = ttk.Scrollbar(self.frame, orient="horizontal", command=self.tree.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.tree.configure(xscrollcommand=xs.set)
        self.tree.bind("<Double-1>", lambda e: self.edit())
        self.tree.bind("<Return>", lambda e: self.edit())
        self.tree.bind(
            "<<TreeviewSelect>>",
            lambda e: self.on_select(self.indices()) if self.on_select else None,
        )
        self.tree.bind("<Alt-Up>", lambda e: self.move(-1))
        self.tree.bind("<Alt-Down>", lambda e: self.move(1))
        self.tree.bind("<Delete>", lambda e: self.delete())
        self.tree.bind("<Control-d>", lambda e: self.duplicate())
        self.tree.bind("<Control-z>", lambda e: (self.undo(), "break")[-1])
        self.tree.bind("<Control-y>", lambda e: (self.redo(), "break")[-1])
        bar = ttk.Frame(parent)
        bar.pack(side="bottom", fill="x", padx=10, pady=5, before=self.frame)
        for i, (label, action) in enumerate(
            [
                ("追加", self.add),
                ("編集", self.edit),
                ("複製", self.duplicate),
                ("削除", self.delete),
                ("↑", lambda: self.move(-1)),
                ("↓", lambda: self.move(1)),
                ("元に戻す", self.undo),
                ("やり直し", self.redo),
            ]
        ):
            ttk.Button(
                bar, text=label, command=action, width=9 if i not in (4, 5) else 3
            ).grid(row=0 if i < 6 else 1, column=i if i < 6 else i - 6, padx=2, pady=2, sticky="ew")
        self.refresh()

    def snapshot(self):
        self.undo_stack.append(
            (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
        )
        self.undo_stack = self.undo_stack[-100:]
        self.redo_stack.clear()

    def restore(self, state):
        self.commands[:] = state[0]
        replace_collection(self.blocks, state[1])
        self.refresh()

    def undo(self):
        if self.undo_stack:
            self.redo_stack.append(
                (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
            )
            self.restore(self.undo_stack.pop())

    def redo(self):
        if self.redo_stack:
            self.undo_stack.append(
                (copy.deepcopy(self.commands), copy.deepcopy(self.blocks))
            )
            self.restore(self.redo_stack.pop())

    def indices(self):
        return sorted(int(i) for i in self.tree.selection())

    def refresh(self, selection=None):
        self.tree.delete(*self.tree.get_children())
        for i, cmd in enumerate(self.commands):
            display = dict(cmd)
            if cmd.get("type") == "BLOCK" and isinstance(self.blocks, list):
                display["name"] = named(self.blocks, cmd.get("name", ""))
            self.tree.insert(
                "",
                "end",
                iid=str(i),
                values=(
                    TYPE_LABELS.get(cmd.get("type"), cmd.get("type", "?")),
                    (self.project or {})
                    .get("custom_commands", {})
                    .get(cmd.get("name"), {})
                    .get("name", command_summary(cmd))
                    if cmd.get("type") == "CUSTOM"
                    else command_summary(display),
                ),
            )
        if selection is not None and 0 <= selection < len(self.commands):
            self.tree.selection_set(str(selection))
            self.tree.see(str(selection))
        if self.on_change:
            self.on_change()

    def names(self):
        return list(
            dict.fromkeys(
                list(self.local_names)
                + [
                    c["name"]
                    for c in walk_commands(self.commands)
                    if c.get("type", "").upper() == "SET"
                ]
            )
        )

    def add(self):
        before = copy.deepcopy(self.blocks)
        d = edit_command(
            self.frame,
            {"type": "LINE"},
            self.blocks,
            self.project,
            self.names(),
            sample_locals=self.local_names
            if isinstance(self.local_names, dict)
            else None,
            folder_id=self.folder_id,
        )
        if d is not None:
            changed = copy.deepcopy(self.blocks)
            replace_collection(self.blocks, before)
            self.snapshot()
            replace_collection(self.blocks, changed)
            ids = self.indices()
            at = ids[-1] + 1 if ids else len(self.commands)
            self.commands.insert(at, d)
            self.refresh(at)

    def edit(self):
        ids = self.indices()
        if len(ids) != 1:
            return messagebox.showinfo(
                "コマンドの選択",
                "編集するコマンドを1件選択してください",
                parent=self.frame,
            )
        before = copy.deepcopy(self.blocks)
        i = ids[0]
        d = edit_command(
            self.frame,
            self.commands[i],
            self.blocks,
            self.project,
            self.names(),
            sample_locals=self.local_names
            if isinstance(self.local_names, dict)
            else None,
            folder_id=self.folder_id,
        )
        if d is not None:
            changed = copy.deepcopy(self.blocks)
            replace_collection(self.blocks, before)
            self.snapshot()
            replace_collection(self.blocks, changed)
            self.commands[i] = d
            self.refresh(i)

    def duplicate(self):
        ids = self.indices()
        if not ids:
            return
        self.snapshot()
        for i in reversed(ids):
            self.commands.insert(i + 1, copy.deepcopy(self.commands[i]))
        self.refresh(ids[0] + 1)

    def delete(self):
        ids = self.indices()
        if not ids:
            return
        self.snapshot()
        for i in reversed(ids):
            self.commands.pop(i)
        self.refresh(min(ids[0], len(self.commands) - 1))

    def move(self, delta):
        ids = self.indices()
        if len(ids) == 1 and 0 <= ids[0] + delta < len(self.commands):
            i = ids[0]
            j = i + delta
            self.snapshot()
            self.commands[i], self.commands[j] = self.commands[j], self.commands[i]
            self.refresh(j)

    def group(self):
        ids = self.indices()
        if not ids:
            return
        if ids != list(range(ids[0], ids[-1] + 1)):
            return messagebox.showinfo(
                "連続した選択",
                "Shiftキーで連続したコマンドを選択してください",
                parent=self.frame,
            )
        name = simpledialog.askstring(
            "ブロック化", "新しいブロックの名前", parent=self.frame
        )
        if not name or not name.strip():
            return
        name = name.strip()
        if (
            any(b["name"].casefold() == name.casefold() for b in self.blocks)
            if isinstance(self.blocks, list)
            else name in self.blocks
        ):
            return messagebox.showerror(
                "名前の重複", "同名ブロックがあります", parent=self.frame
            )
        self.snapshot()
        if isinstance(self.blocks, list):
            block = new_block(
                name, draw=False, commands=self.commands[ids[0] : ids[-1] + 1]
            )
            if self.folder_id:
                block["folder_id"] = self.folder_id
            self.blocks.append(block)
            identity = block["id"]
        else:
            self.blocks[name] = copy.deepcopy(self.commands[ids[0] : ids[-1] + 1])
            identity = name
        self.commands[ids[0] : ids[-1] + 1] = [{"type": "BLOCK", "name": identity}]
        self.refresh(ids[0])


class MacroEditor:
    def __init__(
        self, parent, preset, blocks, on_close, project=None, selected_rows=None
    ):
        self.unified = isinstance(blocks, list)
        self.win = tk.Toplevel(parent)
        self.win.title(
            ("ブロック編集 · " if self.unified else "プリセット編集 · ")
            + preset.get("name", "")
        )
        fit_window(self.win, 980, 820, 850, 640)
        self.win.transient(parent)
        self.win.grab_set()
        self.preset = preset
        self.blocks = blocks
        self.working_blocks = copy.deepcopy(blocks)
        self.on_close = on_close
        self.project = project
        self.selected_rows = selected_rows or (
            [0] if project and get_rows(project) else []
        )
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        self.win.bind("<Escape>", lambda e: self.cancel())
        meta = ttk.LabelFrame(
            self.win,
            text="ブロックの作図条件" if self.unified else "プリセットの実行ルール",
            padding=10,
        )
        meta.pack(fill="x", padx=12, pady=10)
        self.name = tk.StringVar(value=preset.get("name", ""))
        self.cond = tk.StringVar(value=preset.get("condition", ""))
        self.enabled = tk.BooleanVar(
            value=preset.get("draw" if self.unified else "enabled", True)
        )
        for label, var in [("名前", self.name), ("実行条件", self.cond)]:
            row = ttk.Frame(meta)
            row.pack(fill="x", pady=2)
            ttk.Label(row, text=label, width=12).pack(side="left")
            ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True)
        ttk.Checkbutton(
            meta,
            text="このブロックを作図対象にする"
            if self.unified
            else "このプリセットを有効にする",
            variable=self.enabled,
        ).pack(anchor="w")
        ttk.Label(
            meta,
            text='条件例: @TYPE == "A" / 空欄なら全行。作図対象OFFは呼び出し専用です。'
            if self.unified
            else '条件例: @TYPE == "A"   /   空欄なら全行で実行',
            style="Muted.TLabel",
        ).pack(anchor="w")
        bar = ttk.Frame(self.win, padding=12)
        bar.pack(side="bottom", fill="x")
        ttk.Button(bar, text="キャンセル", command=self.cancel).pack(side="left")
        ttk.Button(
            bar,
            text="ブロックを確定" if self.unified else "プリセットを確定",
            style="Primary.TButton",
            command=self.save,
        ).pack(side="right")
        self.tabs = ttk.Notebook(self.win)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        command_page = ttk.Frame(self.tabs)
        varframe = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(command_page, text="作図コマンド")
        self.tabs.add(varframe, text="ローカル変数")
        ttk.Label(
            varframe,
            text="このブロックの変数を、上から順に計算します。"
            if self.unified
            else "このプリセット内だけで使う値を、上から順に計算します。",
            padding=(0, 0, 0, 10),
        ).pack(anchor="w")
        self.vartree = ttk.Treeview(
            varframe, columns=("name", "expression"), show="headings", height=5
        )
        self.vartree.heading("name", text="名前")
        self.vartree.heading("expression", text="式")
        self.vartree.column("name", width=160)
        self.vartree.column("expression", width=420)
        self.vartree.pack(fill="both", expand=True)
        for k, v in preset.get("variables", {}).items():
            self.vartree.insert("", "end", values=(k, str(v)))
        controls = ttk.Frame(varframe)
        controls.pack(fill="x", pady=8)
        for label, action in [
            ("追加", self.add_variable),
            ("編集", self.edit_variable),
            ("削除", self.delete_variable),
        ]:
            ttk.Button(controls, text=label, command=action).pack(
                side="left", padx=(0, 5)
            )
        self.vartree.bind("<Double-1>", lambda e: self.edit_variable())
        ttk.Label(
            command_page,
            text="作図コマンドを直接追加します。上から順に実行します。",
            padding=(10, 8),
        ).pack(anchor="w")
        preview_frame = ttk.Frame(command_page)
        preview_frame.pack(side="bottom", fill="x", pady=(3, 10))
        self.preview_label = ttk.Label(
            preview_frame, text="選択したコマンドのプレビュー", padding=(10, 2)
        )
        self.preview_label.pack(anchor="w")
        self.preview_canvas = DrawingCanvas(preview_frame, height=145)
        self.preview_canvas.pack(fill="x", padx=10)
        self.list = CommandList(
            command_page,
            copy.deepcopy(preset.get("commands", [])),
            self.working_blocks,
            self.show_preview,
            self.queue_preview,
            project,
            dict(preset.get("variables", {})),
            folder_id=preset.get("folder_id", ""),
        )
        for var in (self.name, self.cond, self.enabled):
            var.trace_add("write", lambda *_: self.queue_preview())
        self.queue_preview()

    def queue_preview(self):
        if hasattr(self, "preview_canvas"):
            self.win.after_idle(lambda: self.show_preview(self.list.indices()))

    def current(self):
        result = dict(
            self.preset,
            name=self.name.get().strip(),
            condition=self.cond.get().strip(),
            enabled=self.enabled.get(),
            variables={
                self.vartree.item(i, "values")[0]: self.vartree.item(i, "values")[1]
                for i in self.vartree.get_children()
            },
            commands=copy.deepcopy(self.list.commands),
        )

        if self.unified:
            result["draw"] = result.pop("enabled")
        return result

    def trial(self):
        trial = copy.deepcopy(self.project)
        if self.unified:
            trial["blocks"] = copy.deepcopy(self.working_blocks)
            index = index_of(trial, self.preset["id"])
            trial["blocks"][index] = self.current()
        else:
            index = next(
                i for i, p in enumerate(self.project["presets"]) if p is self.preset
            )
            trial["presets"][index] = self.current()
            trial["blocks"] = copy.deepcopy(self.working_blocks)
        return trial, index

    def show_preview(self, indices):
        if not hasattr(self, "preview_canvas") or not self.win.winfo_exists():
            return
        self.preview_canvas.set_items([])
        if not self.project or not self.selected_rows:
            return
        try:
            trial, pi = self.trial()
            if self.unified:
                for i, block in enumerate(trial["blocks"]):
                    block["draw"] = i == pi
            events = []
            _, items = compile_project(
                trial, self.selected_rows[:1], diagnostics=events
            )
            events = [
                e
                for e in events
                if e.get("block_index" if self.unified else "preset_index") == pi
                and (not indices or e.get("command_index") in indices)
            ]
            items = [
                a
                for a in items
                if a["block_index" if self.unified else "preset_index"] == pi
                and (not indices or a["command_index"] in indices)
            ]
            custom_count = sum(e["type"] == "CUSTOM" for e in events)
            self.preview_canvas.set_items(
                items,
                message="登録コマンドの図形はプレビュー対象外です。生成SCRで確認してください。"
                if custom_count
                else None,
            )
            self.preview_label.configure(
                text=f"編集中の値を反映 · {self.selected_rows[0] + 1}行目 / 標準{len(items)}図形"
                + (f" / 登録{custom_count}件はSCRのみ" if custom_count else "")
            )
        except Exception as exc:
            self.preview_label.configure(text="プレビュー: " + str(exc)[:110])

    def add_variable(self):
        self.change_variable()

    def edit_variable(self):
        selected = self.vartree.selection()
        if selected:
            self.change_variable(selected[0])

    def delete_variable(self):
        for item in self.vartree.selection():
            self.vartree.delete(item)
        self.queue_preview()

    def change_variable(self, item=None):
        original = self.vartree.item(item, "values") if item else ("", "0")
        name = simpledialog.askstring(
            "ローカル変数",
            "変数名（例: OFFSET）",
            initialvalue=original[0],
            parent=self.win,
        )
        if name is None:
            return
        if not valid_name(name):
            return messagebox.showerror(
                "変数名",
                "英数字と_で指定してください。予約名は使用できません",
                parent=self.win,
            )
        if any(
            self.vartree.item(i, "values")[0] == name
            for i in self.vartree.get_children()
            if i != item
        ):
            return messagebox.showerror("重複", "同名変数があります", parent=self.win)
        expr = simpledialog.askstring(
            "計算式",
            "値または式（例: @OD / 4）",
            initialvalue=original[1],
            parent=self.win,
        )
        if expr is None:
            return
        try:
            parse_expression(expr.strip())
        except MacroError as exc:
            return messagebox.showerror("計算式", str(exc), parent=self.win)
        if item:
            self.vartree.item(item, values=(name, expr.strip()))
        else:
            self.vartree.insert("", "end", values=(name, expr.strip()))
        self.list.local_names = dict(self.current()["variables"])
        self.queue_preview()

    def cancel(self):
        if (
            self.current() != self.preset or self.working_blocks != self.blocks
        ) and not messagebox.askyesno(
            "変更の破棄",
            "ブロックの変更を破棄しますか？"
            if self.unified
            else "プリセットの変更を破棄しますか？",
            parent=self.win,
        ):
            return
        self.win.destroy()

    def save(self):
        current = self.current()
        if not current["name"]:
            return messagebox.showerror(
                "名前",
                "ブロック名を入力してください"
                if self.unified
                else "プリセット名を入力してください",
                parent=self.win,
            )
        if self.project:
            trial, _ = self.trial()
            errors = validate_project(trial)
            if errors:
                return messagebox.showerror(
                    "構成の確認", "\n".join(errors[:8]), parent=self.win
                )
        if self.unified:
            if self.project:
                replace_collection(self.blocks, trial["blocks"])
            else:
                index = next(
                    i
                    for i, block in enumerate(self.working_blocks)
                    if block["id"] == current["id"]
                )
                self.working_blocks[index] = current
                replace_collection(self.blocks, self.working_blocks)
        else:
            self.preset.clear()
            self.preset.update(current)
            replace_collection(self.blocks, self.working_blocks)
        self.win.destroy()
        self.on_close()


class BlockManager:
    def __init__(self, parent, blocks, on_close, presets=None, project=None):
        self.blocks = blocks
        self.presets = presets if presets is not None else []
        self.on_close = on_close
        self.project = project
        self.working = copy.deepcopy(blocks)
        self.working_presets = copy.deepcopy(self.presets)
        self.win = tk.Toplevel(parent)
        self.win.title("共通ブロックの管理")
        self.win.geometry("960x650")
        self.win.transient(parent)
        self.win.grab_set()
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        self.win.bind("<Escape>", lambda e: self.cancel())
        ttk.Label(
            self.win,
            text="共通ブロックを変更すると、参照しているすべての箇所に反映されます。",
            padding=12,
        ).pack(anchor="w")
        bar = ttk.Frame(self.win, padding=10)
        bar.pack(fill="x")
        self.combo = ttk.Combobox(bar, state="readonly", values=list(self.working))
        self.combo.pack(side="left", fill="x", expand=True)
        self.combo.bind("<<ComboboxSelected>>", lambda e: self.select())
        for label, fn in [
            ("新規", self.new),
            ("名称変更", self.rename),
            ("使用箇所", self.show_usage),
            ("削除", self.delete),
        ]:
            ttk.Button(bar, text=label, command=fn).pack(side="left", padx=3)
        self.area = ttk.Frame(self.win)
        self.area.pack(fill="both", expand=True)
        self.current = None
        self.editor = None
        bar = ttk.Frame(self.win, padding=12)
        bar.pack(side="bottom", fill="x", before=self.area)
        ttk.Button(bar, text="キャンセル", command=self.cancel).pack(side="left")
        ttk.Button(
            bar, text="ブロックを確定", style="Primary.TButton", command=self.save
        ).pack(side="right")
        if self.working:
            self.combo.set(next(iter(self.working)))
            self.select()

    def flush(self):
        if self.current and self.editor:
            self.working[self.current] = copy.deepcopy(self.editor.commands)

    def select(self):
        self.flush()
        for widget in self.area.winfo_children():
            widget.destroy()
        self.current = self.combo.get()
        self.editor = None
        if self.current in self.working:
            self.editor = CommandList(
                self.area,
                copy.deepcopy(self.working[self.current]),
                self.working,
                project=self.project,
            )

    def new(self):
        name = simpledialog.askstring(
            "共通ブロック", "新しいブロック名", parent=self.win
        )
        if not name or not name.strip():
            return
        name = name.strip()
        if name in self.working:
            return messagebox.showerror(
                "名前の重複", "同名ブロックがあります", parent=self.win
            )
        self.flush()
        self.working[name] = []
        self.combo["values"] = list(self.working)
        self.combo.set(name)
        self.select()

    def rename(self):
        self.flush()
        old = self.current
        if old not in self.working:
            return
        new = simpledialog.askstring(
            "ブロック名の変更", "新しい名前", initialvalue=old, parent=self.win
        )
        if not new or not new.strip() or new.strip() == old:
            return
        new = new.strip()
        if new in self.working:
            return messagebox.showerror(
                "名前の重複", "同名ブロックがあります", parent=self.win
            )
        self.working[new] = self.working.pop(old)
        for commands in list(self.working.values()) + [
            p.get("commands", []) for p in self.working_presets
        ]:
            for cmd in walk_commands(commands):
                if cmd.get("type", "").upper() == "BLOCK" and cmd.get("name") == old:
                    cmd["name"] = new
        self.current = None
        self.editor = None
        self.combo["values"] = list(self.working)
        self.combo.set(new)
        self.select()

    def usages(self, name):
        self.flush()
        uses = []
        for owner, commands in list(self.working.items()) + [
            (p["name"], p.get("commands", [])) for p in self.working_presets
        ]:
            for i, cmd in enumerate(walk_commands(commands)):
                if cmd.get("type", "").upper() == "BLOCK" and cmd.get("name") == name:
                    uses.append(f"{owner} / コマンド {i + 1}")
        return uses

    def show_usage(self):
        messagebox.showinfo(
            "使用箇所",
            "\n".join(self.usages(self.current)) or "使用箇所はありません",
            parent=self.win,
        )

    def delete(self):
        name = self.current
        if name not in self.working:
            return
        uses = self.usages(name)
        if uses:
            return messagebox.showerror(
                "参照中のブロック",
                "先に呼び出し元を変更してください。\n" + "\n".join(uses),
                parent=self.win,
            )
        if not messagebox.askyesno(
            "ブロックの削除", f"「{name}」を削除しますか？", parent=self.win
        ):
            return
        self.working.pop(name)
        self.current = None
        self.editor = None
        self.combo["values"] = list(self.working)
        self.combo.set(next(iter(self.working), ""))
        self.select()

    def cancel(self):
        self.flush()
        if (
            self.working != self.blocks or self.working_presets != self.presets
        ) and not messagebox.askyesno(
            "変更の破棄", "ブロックの変更を破棄しますか？", parent=self.win
        ):
            return
        self.win.destroy()

    def save(self):
        self.flush()
        trial = (
            copy.deepcopy(self.project)
            if self.project
            else {"version": 6, "rows": [], "blocks": {}, "presets": []}
        )
        trial.update(blocks=self.working, presets=self.working_presets)
        errors = validate_project(trial)
        if errors:
            return messagebox.showerror(
                "構成の確認", "\n".join(errors[:8]), parent=self.win
            )
        replace_collection(self.blocks, copy.deepcopy(self.working))
        self.presets[:] = copy.deepcopy(self.working_presets)
        self.win.destroy()
        self.on_close()
