"""Controls for two-source point relations inside the existing point picker."""
import tkinter as tk
from tkinter import ttk
from command_points import geometry_points
from derived_points import intersection_candidates, tangent_candidates


class MenuChoice(ttk.Menubutton):
    def __init__(self,parent,values=(),**kwargs):
        kwargs.pop('state',None)
        self.value=tk.StringVar();self.values=tuple(values)
        super().__init__(parent,textvariable=self.value,**kwargs)
        self.menu=tk.Menu(self,tearoff=False);super().configure(menu=self.menu)
        self.configure(values=values)
    def configure(self,**kwargs):
        if 'values' in kwargs:
            self.values=tuple(kwargs.pop('values'));self.menu.delete(0,'end')
            for value in self.values:
                self.menu.add_radiobutton(label=value,value=value,variable=self.value,command=lambda:self.event_generate('<<ComboboxSelected>>'))
        if kwargs:super().configure(**kwargs)
    def set(self,value):self.value.set(value)
    def get(self):return self.value.get()
    def current(self,index=None):
        if index is not None:self.set(self.values[index]);return
        return self.values.index(self.get()) if self.get() in self.values else -1


class RelationPointControls(ttk.Frame):
    def __init__(self,parent,candidates,on_change,identity):
        super().__init__(parent)
        self.candidates=candidates;self.identity=identity;self.spec=None
        ttk.Label(self,text='参照点の種類',style='CardMuted.TLabel').pack(anchor='w')
        self.mode=MenuChoice(self,values=('基準点','交点','接点'))
        self.mode.set('基準点');self.mode.pack(fill='x',pady=(4,6))
        self.other=ttk.Frame(self)
        ttk.Label(self.other,text='相手のコマンド',style='CardMuted.TLabel').pack(anchor='w')
        self.second=MenuChoice(self.other,values=[d['label'] for _,d in candidates])
        self.second.current(1 if len(candidates)>1 else 0);self.second.pack(fill='x',pady=4)
        self.external_host=ttk.Frame(self.other)
        ttk.Label(self.external_host,text='円の外側の点',style='CardMuted.TLabel').pack(anchor='w')
        self.external=MenuChoice(self.external_host);self.external.pack(fill='x',pady=4)
        self.hint=ttk.Label(self.other,text='候補A/Bをプレビューで選択。交点は線分同士・線分と円・円同士。',style='CardMuted.TLabel',wraplength=480)
        self.hint.pack(fill='x',pady=4)
        def changed(event=None):
            if event is not None and event.widget is self.second:self.external.set('')
            self.sync();on_change()
        for combo in (self.mode,self.second,self.external):combo.bind('<<ComboboxSelected>>',changed)

    @property
    def active(self):return self.mode.get()!='基準点'

    def sync(self):
        if self.active:self.other.pack(fill='x')
        else:self.other.pack_forget()
        if self.mode.get()=='接点':self.external_host.pack(fill='x',before=self.hint)
        else:self.external_host.pack_forget()

    def preview(self,primary,canvas):
        self.spec=None
        secondary=self.candidates[self.second.current()][0]
        def item(index):
            found=next((i for i in reversed(canvas.items) if canvas.item_source_index(i)==index and not i.get('operation_deleted')),None)
            if found is None:raise ValueError('参照元がこの行では作図されません')
            return found
        first,second=item(primary),item(secondary)
        if primary==secondary:raise ValueError('別のコマンドを相手に指定してください')
        def shape(source):
            typ=source.get('display_type',source['type']);points=geometry_points(source)
            if typ=='CIRCLE':return 'C',('中心','右'),(points['中心'],points['右'])
            if typ in ('LINE','POLYLINE') and len(source['coords'])==4:
                return 'L',('始点','終点'),(points['始点'],points['終点'])
            raise ValueError('交点は単一の線分と円に対応しています。連続線・円弧・楕円は未対応です')
        ka,na,pa=shape(first)
        if self.mode.get()=='交点':
            kb,nb,pb=shape(second)
            result=intersection_candidates(ka+kb,*pa,*pb)
            self.spec=(ka+kb,[(primary,n) for n in na]+[(secondary,n) for n in nb])
        else:
            if ka!='C':raise ValueError('接点の参照元には円を指定してください')
            points=geometry_points(second);names=tuple(points)
            self.external.configure(values=names)
            if not self.external.get() and names:self.external.set(names[0])
            name=self.external.get()
            if name not in points:raise ValueError('外側の点が参照元に存在しません')
            result=tangent_candidates(*pa,points[name])
            self.spec=('T',[(primary,n) for n in na]+[(secondary,name)])
        return result

    def expression(self,branch,axis,dx='0',dy='0'):
        if self.spec is None:raise ValueError('交点・接点の参照元を確認してください')
        kind,refs=self.spec
        values=[f'点位置({self.identity(index)!r}, {name!r})' for index,name in refs]
        if kind!='T':values.insert(0,repr(kind))
        values.extend((repr(branch),repr(axis)))
        if dx!='0' or dy!='0':values.extend((dx,dy))
        return ('接点' if kind=='T' else '交点')+'('+', '.join(values)+')'
