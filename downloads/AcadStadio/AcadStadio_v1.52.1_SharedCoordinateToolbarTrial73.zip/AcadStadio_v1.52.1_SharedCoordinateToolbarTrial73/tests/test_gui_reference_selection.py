import os,sys,unittest,tkinter as tk
from tkinter import ttk
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from input_assist import show_table_reference_picker
from macro_editor import edit_command

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class ReferenceSelection(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_cell_highlights_only_cell_and_header_highlights_column(self):
        selected=[]
        def inspect():
            win=gui.top(self.root,'表から参照を選ぶ')
            try:
                tree=next(w for w in gui.descendants(win) if isinstance(w,ttk.Treeview))
                tree.tk.call(tree.heading('OD','command'));self.root.update()
                active=lambda:[w for w in tree.winfo_children() if isinstance(w,tk.Label) and w.place_info()]
                self.assertEqual(len(active()),3);self.assertFalse(tree.selection())
                box=tree.bbox('0','OD')
                tree.event_generate('<ButtonPress-1>',x=box[0]+8,y=box[1]+8)
                tree.event_generate('<ButtonRelease-1>',x=box[0]+8,y=box[1]+8);self.root.update()
                self.assertEqual(len(active()),1);self.assertFalse(tree.selection())
                gui.button(win,'この参照を挿入').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(100,inspect);show_table_reference_picker(self.root,self.app.data,selected.append)
        self.assertIn('@OD{1}',selected[0])

    def test_used_references_follow_source_and_insert_into_focused_axis(self):
        first=dict(type='LINE',point_id='p_'+'7'*32,x1='@X',y1='@Y',x2='@X+@OD*変数.SCALE',y2='@Y')
        second=dict(type='LINE',point_id='p_'+'8'*32,x1='@PCD',y1='@Y',x2='@PCD+10',y2='@Y')
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                before_traces=len(win.command_preview.row.trace_info())
                win.choose_command_point('x1',both=True);self.root.update();panel=win.point_panel
                entries={axis:next(w for w in gui.descendants(panel) if isinstance(w,ttk.Entry) and str(w.cget('textvariable'))==str(value)) for axis,value in panel.point_offsets.items()}
                self.assertGreater(entries['X'].winfo_width(),150)
                self.assertGreater(entries['X'].winfo_rooty(),gui.button(panel,'表').winfo_rooty())
                def choose(prefix):
                    picker=panel.used_reference_picker
                    index=next(i for i,v in enumerate(picker.cget('values')) if v.startswith(prefix))
                    picker.current(index);picker.event_generate('<<ComboboxSelected>>');self.root.update()
                entries['Y'].focus_set();entries['Y'].event_generate('<FocusIn>');self.root.update()
                choose('変数.SCALE =')
                self.assertEqual(panel.point_offsets['Y'].get(),'変数.SCALE');self.assertEqual(panel.point_offsets['X'].get(),'0')
                entries['X'].event_generate('<FocusIn>');choose('@OD =')
                self.assertEqual(panel.point_offsets['X'].get(),'@OD')
                panel.point_preview.row.set('2');self.root.update()
                self.assertTrue(any(v.startswith('@OD = 120') for v in panel.used_reference_picker.cget('values')))
                panel.source_picker.current(1);panel.source_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                self.assertTrue(any(v.startswith('@PCD =') for v in panel.used_reference_picker.cget('values')))
                self.assertFalse(any(str(w.cget('text')).startswith('@OD =') for w in gui.descendants(panel) if isinstance(w,ttk.Button)))
                win.close_point_panel();self.assertEqual(len(win.command_preview.row.trace_info()),before_traces)
                gui.button(win,'キャンセル').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(150,inspect)
        edit_command(self.root,dict(type='LINE'),self.app.data['blocks'],self.app.data,previous_blocks=[dict(id='prior',name='基準線',commands=[first,second])])
