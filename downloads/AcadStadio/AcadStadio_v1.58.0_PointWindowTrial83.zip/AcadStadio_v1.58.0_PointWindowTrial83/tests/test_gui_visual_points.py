import copy
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from tkinter import ttk
from macro_editor import edit_command
from point_preview_ui import PointReferencePreview
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class VisualPointsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_real_marker_click_sets_midpoint_x_and_preserves_y_with_offset(self):
        line=dict(type='LINE',x1='@X',y1='@Y',x2='@X+100',y2='@Y')
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.geometry('980x620');self.root.update()
                win.choose_command_point('x');self.root.update()
                dialog=gui.top(self.root,'コマンドの点を選択');visual=dialog.point_preview;c=visual.canvas
                x,y=c.screen_point(visual.points['中点'])
                c.event_generate('<ButtonPress-1>',x=int(x),y=int(y));c.event_generate('<ButtonRelease-1>',x=int(x),y=int(y));self.root.update()
                combos=[w for w in gui.descendants(dialog) if isinstance(w,ttk.Combobox)]
                self.assertEqual(dialog.point_picker.get(),'中点')
                entry=next(w for w in gui.descendants(dialog) if isinstance(w,ttk.Entry) and not isinstance(w,ttk.Combobox))
                entry.delete(0,'end');entry.insert(0,'-10');self.root.update()
                self.assertEqual(c.shifted_point,(140,100));self.assertIn('140',visual.status.get())
                for label in ['この点を使用','キャンセル']:
                    b=gui.button(dialog,label);self.assertLessEqual(b.winfo_rooty()+b.winfo_height(),dialog.winfo_rooty()+dialog.winfo_height())
                gui.button(dialog,'この点を使用').invoke();gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,inspect)
        result=edit_command(self.root,dict(type='POINT',x='0',y='25'),self.app.data['blocks'],self.app.data,point_sources=[line])
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[line,result])]
        self.assertEqual(compile_project(p,[0])[1][1]['coords'],(140,25))

    def test_row_change_error_cleanup_and_zoom_pan_marker_alignment(self):
        commands=[dict(type='LINE',x1='@X',y1='@Y',x2='@X+@OD',y2='@Y')]
        frame=PointReferencePreview(self.root,self.app.data,commands,lambda p:None);frame.pack(fill='both',expand=True)
        frame.load(0);self.root.update();c=frame.canvas
        self.assertEqual(frame.points['中点'],(150,100))
        frame.row.set('2');frame.load(0);self.root.update();self.assertEqual(frame.points['中点'],(480,100))
        before=c.screen_point(frame.points['中点']);c.zoom(SimpleNamespace(x=0,y=0,delta=120),1.15)
        after=c.screen_point(frame.points['中点']);self.assertAlmostEqual(after[0],before[0]*1.15)
        c.drag_point=(0,0);c.drag(SimpleNamespace(x=20,y=30));shifted=c.screen_point(frame.points['中点'])
        self.assertAlmostEqual(shifted[0],after[0]+20);self.assertAlmostEqual(shifted[1],after[1]+30)
        frame.update_selection('中点','X',{'value':'10000'});c.fit();self.root.update()
        sx,sy=c.screen_point(c.shifted_point)
        self.assertGreaterEqual(sx,0);self.assertLessEqual(sx,c.winfo_width())
        self.assertGreaterEqual(sy,0);self.assertLessEqual(sy,c.winfo_height())
        commands[0]['condition']='False';frame.load(0);self.root.update()
        self.assertEqual(frame.points,{});self.assertEqual(c.snap_points,{})
        self.assertIn('作図されません',frame.status.get());frame.destroy()
