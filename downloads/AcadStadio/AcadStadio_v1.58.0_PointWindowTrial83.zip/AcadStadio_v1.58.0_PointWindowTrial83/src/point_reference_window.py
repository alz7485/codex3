"""Small point-reference window sharing its owner's interactive preview."""
import tkinter as tk
from tkinter import ttk


class PointReferenceWindow(tk.Toplevel):
    """Keep the owner's grab: taking a grab here would disable its preview."""
    def __init__(self, owner, anchor, target):
        super().__init__(owner)
        self.withdraw()
        self.transient(owner)
        self.title('点参照 — ' + target)
        self.owner = owner
        self.anchor = anchor
        self._arrange_job = None
        self._positioned = False
        self.minsize(320, 200)
        self.footer = ttk.Frame(self, padding=(3, 2, 3, 3))
        self.footer.pack(side='bottom', fill='x')
        host = ttk.Frame(self, padding=(3, 3, 3, 0))
        host.pack(fill='both', expand=True)
        host.rowconfigure(0, weight=1)
        host.columnconfigure(0, weight=1)
        self.viewport = tk.Canvas(host, bg='#f3f5f9', highlightthickness=0)
        self.viewport.grid(row=0, column=0, sticky='nsew')
        scrollbar = ttk.Scrollbar(host, command=self.viewport.yview)
        self.content = ttk.Frame(self.viewport, style='PointCard.TFrame', padding=3)
        node = self.viewport.create_window(0, 0, window=self.content, anchor='nw')
        def scrolled(first, last):
            scrollbar.set(first, last)
            if float(first) > 0 or float(last) < 1:
                scrollbar.grid(row=0, column=1, sticky='ns')
            else:
                scrollbar.grid_remove()
        self.viewport.configure(yscrollcommand=scrolled)
        def size_changed(event=None):
            self.viewport.itemconfigure(node, width=self.viewport.winfo_width())
            self.viewport.configure(scrollregion=self.viewport.bbox('all'))
            self.queue_arrange()
        self.content.bind('<Configure>', size_changed)
        self.viewport.bind('<Configure>', size_changed)
        def scroll(event):
            if self.content.winfo_height() <= self.viewport.winfo_height():return
            step = -1 if event.num == 4 or event.delta > 0 else 1
            self.viewport.yview_scroll(step, 'units')
        for seq in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
            self.bind(seq, scroll, add='+')
        self.bind('<Destroy>', self._destroyed, add='+')

    def queue_arrange(self):
        if self._arrange_job is None:
            self._arrange_job = self.after_idle(self._arrange)

    def _arrange(self):
        self._arrange_job = None
        if not self.winfo_exists() or not self.owner.winfo_exists():return
        # Place near the lower part of the shared preview without resizing it.
        width = max(320, min(360, self.anchor.winfo_width()-24))
        limit = max(200, min(self.anchor.winfo_height()-36,self.owner.winfo_height()-76,self.winfo_screenheight()-90))
        height = min(limit, max(200, self.content.winfo_reqheight()+self.footer.winfo_reqheight()+8))
        if self._positioned:
            # Retain a user-moved position and width when optional controls appear.
            width = max(320, self.winfo_width())
            x=max(0,min(self.winfo_x(),self.winfo_screenwidth()-width-12))
            y=max(0,min(self.winfo_y(),self.winfo_screenheight()-height-45))
            if (self.anchor.winfo_rootx()<=x<self.anchor.winfo_rootx()+self.anchor.winfo_width()
                    and y>=self.anchor.winfo_rooty() and height<self.anchor.winfo_height()):
                y=min(y,self.anchor.winfo_rooty()+self.anchor.winfo_height()-height-48)
            self.geometry(f'{width}x{height}+{x}+{y}')
        else:
            x = max(0, min(self.anchor.winfo_rootx()+max(12,(self.anchor.winfo_width()-width)//2), self.winfo_screenwidth()-width-12))
            y = max(0, min(self.anchor.winfo_rooty()+max(8,int((self.anchor.winfo_height()-height)*0.78)), self.winfo_screenheight()-height-45))
            self.geometry(f'{width}x{height}+{x}+{y}')
            self._positioned = True
            self.deiconify()
            self.lift()

    def _destroyed(self, event):
        if event.widget is self and self._arrange_job is not None:
            self.after_cancel(self._arrange_job)
            self._arrange_job = None


class PointReferenceComparison(ttk.Frame):
    def __init__(self, parent, before):
        super().__init__(parent)
        self.before = before
        self.columnconfigure(1, weight=1)
        self.columnconfigure(2, weight=1)
        self.rows = {}
        self.values = {}
        self.previous = {}
        self.unchanged = {}
        for i, name in enumerate(('X', 'Y')):
            row = ttk.Frame(self, padding=1, style='PointCard.TFrame')
            row.grid(row=i, column=0, columnspan=3, sticky='ew', pady=1)
            row.columnconfigure((1, 3), weight=1)
            ttk.Label(row, text=name, width=2).grid(row=0, column=0, padx=2)
            old = ttk.Label(row, width=7)
            old.grid(row=0, column=1, sticky='w', padx=2)
            ttk.Label(row, text='→', width=2).grid(row=0, column=2)
            value = ttk.Label(row, width=10, style='PointResultValue.TLabel')
            value.grid(row=0, column=3, sticky='w', padx=2)
            note = ttk.Label(row, style='Muted.TLabel')
            note.grid(row=0, column=4, sticky='e', padx=2)
            self.unchanged[name] = note
            self.rows[name] = row
            self.previous[name] = old
            self.values[name] = value
        self.note = ttk.Label(self, style='Muted.TLabel', wraplength=330)
        self.note.grid(row=3, column=0, columnspan=3, sticky='w', pady=(3, 0))

    def update_values(self, origin, result, axis, status=''):
        from workbench_style import paint_card
        before = self.before()
        for i, name in enumerate(('X', 'Y')):
            active = axis in ('XY', name)
            row = self.rows[name]
            if active:row.grid()
            else:row.grid_remove()
            paint_card(row, active)
            self.unchanged[name].configure(text=('Y' if name=='X' else 'X')+'は変更しない' if active and axis!='XY' else '')
            old = before[i] if i < len(before) else '—'
            old = f'{old:.12g}' if type(old) in (float, int) else str(old)
            self.previous[name].configure(text=old if len(old) <= 16 else old[:15]+'…')
            self.values[name].configure(text=(f'{result[i]:.12g}' if result else '—') if active else '変更しない')
        text=status if not origin or not result else ''
        self.note.configure(text=text)
        if text:self.note.grid()
        else:self.note.grid_remove()
