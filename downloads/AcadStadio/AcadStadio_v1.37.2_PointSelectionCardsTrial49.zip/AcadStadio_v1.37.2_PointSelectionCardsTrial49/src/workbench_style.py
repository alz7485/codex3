"""Visual components shared by command input and in-place point selection."""
import tkinter as tk
from tkinter import ttk

BLUE='#2463eb'
INK='#192c42'
MUTED='#67788d'


def apply_workbench_styles(style,face):
    for name,bg,border in [('PointCard.TFrame','white','#d8e3f1'),('FocusPointCard.TFrame','#eff6ff',BLUE)]:
        style.configure(name,background=bg,borderwidth=1,relief='solid',bordercolor=border,lightcolor=border,darkcolor=border)
    for prefix,bg in [('Card','white'),('FocusCard','#eff6ff')]:
        style.configure(prefix+'.TFrame',background=bg)
        style.configure(prefix+'.TLabel',background=bg,foreground=INK)
        style.configure(prefix+'Muted.TLabel',background=bg,foreground=MUTED,font=(face,9))
        style.configure(prefix+'Title.TLabel',background=bg,foreground=INK,font=(face,11,'bold'))
    style.configure('ReferenceChip.TLabel',background='#eee5ff',foreground='#7942a4',padding=(7,4),font=(face,9))
    style.configure('WorkbenchRef.TButton',padding=(7,3),width=0,background='white',foreground=INK,borderwidth=1,bordercolor='#cbd8e8',relief='solid')
    style.map('WorkbenchRef.TButton',background=[('active','#eef5ff')])
    style.configure('WorkbenchPrimary.TButton',padding=(14,8),background=BLUE,foreground='white',borderwidth=1,bordercolor=BLUE)
    style.map('WorkbenchPrimary.TButton',background=[('active','#1856d4')],foreground=[('disabled','#c8d5eb')])
    style.configure('WorkbenchSecondary.TButton',padding=(14,8),background='white',foreground=BLUE,borderwidth=1,bordercolor=BLUE,lightcolor=BLUE,darkcolor=BLUE)
    style.map('WorkbenchSecondary.TButton',background=[('active','#eef5ff')])
    for selected in (False,True):
        name='WorkbenchSegmentOn.TButton' if selected else 'WorkbenchSegment.TButton'
        style.configure(name,padding=(10,6),width=0,background=BLUE if selected else 'white',foreground='white' if selected else INK,borderwidth=1,bordercolor=BLUE if selected else '#cbd8e8')
        style.map(name,background=[('active','#1856d4' if selected else '#eef5ff')])
    style.configure('PointResult.TLabelframe',background='white',borderwidth=1,relief='solid',bordercolor='#d8e3f1',lightcolor='#d8e3f1',darkcolor='#d8e3f1')
    style.configure('PointResult.TLabelframe.Label',font=(face,11,'bold'))
    style.configure('WorkbenchDetails.TLabelframe',background='white',borderwidth=1,relief='solid',bordercolor='#bfcee1',lightcolor='#bfcee1',darkcolor='#bfcee1')
    style.configure('WorkbenchDetails.TLabelframe.Label',font=(face,11,'bold'))
    style.configure('PointResultOrigin.TLabel',background='white',foreground=INK,font=(face,11))
    style.configure('PointResultValue.TLabel',background='white',foreground=BLUE,font=(face,11))
    for name in ('TEntry','TCombobox','TSpinbox'):
        style.configure(name,bordercolor='#bbcadd',lightcolor='#bbcadd',darkcolor='#bbcadd',background='white')
    style.map('TCombobox',fieldbackground=[('disabled','#edf1f6'),('readonly','white')],foreground=[('disabled',MUTED),('readonly',INK)],background=[('readonly','white')])


def paint_card(card,focused=False):
    if getattr(card,'_card_focused',None)==focused:return
    card._card_focused=focused
    card.configure(style='WorkbenchDetails.TLabelframe' if isinstance(card,ttk.LabelFrame) else 'FocusPointCard.TFrame' if focused else 'PointCard.TFrame')
    prefix='FocusCard' if focused else 'Card'
    def walk(parent):
        for widget in parent.winfo_children():
            if isinstance(widget,ttk.Frame):widget.configure(style=prefix+'.TFrame');walk(widget)
            elif isinstance(widget,ttk.Label):
                old=str(widget.cget('style'))
                if old=='ReferenceChip.TLabel':continue
                suffix='Title.TLabel' if 'Title' in old or 'Section' in old else 'Muted.TLabel' if 'Muted' in old else '.TLabel'
                widget.configure(style=prefix+suffix)
    walk(card)


class SegmentedChoice(ttk.Frame):
    def __init__(self,parent,combo):
        super().__init__(parent)
        self.combo=combo;self.buttons={};self._values=()
        self.sync()

    def sync(self):
        values=tuple(self.combo.cget('values'))
        if values!=self._values:
            for i in range(len(self._values)):self.columnconfigure(i,weight=0,uniform='')
            for child in self.winfo_children():child.destroy()
            self.buttons={};self._values=values
            for i,value in enumerate(values):
                label='XY（両方）' if value=='XY' else value
                button=ttk.Button(self,text=label,command=lambda v=value:self.choose(v))
                button.grid(row=0,column=i,sticky='ew');self.columnconfigure(i,weight=1,uniform='choice')
                self.buttons[value]=button
        for value,button in self.buttons.items():
            button.configure(style='WorkbenchSegmentOn.TButton' if value==self.combo.get() else 'WorkbenchSegment.TButton')

    def choose(self,value):
        self.combo.set(value);self.sync();self.combo.event_generate('<<ComboboxSelected>>')


class PointResultCard(ttk.Frame):
    def __init__(self,parent):
        super().__init__(parent,style='PointCard.TFrame',padding=10)
        ttk.Label(self,text='適用する座標',style='CardTitle.TLabel').pack(anchor='w',pady=(0,6))
        self.rows={};self.values={};self.origins={}
        for axis in ('X','Y'):
            frame=ttk.Frame(self,style='Card.TFrame');self.rows[axis]=frame
            ttk.Label(frame,text=axis,width=3,style='Card.TLabel').pack(side='left')
            origin=ttk.Label(frame,text='',width=12,style='PointResultOrigin.TLabel');origin.pack(side='left',padx=8);self.origins[axis]=origin
            ttk.Label(frame,text='→',style='CardMuted.TLabel').pack(side='left',padx=8)
            label=ttk.Label(frame,text='',style='PointResultValue.TLabel');label.pack(side='left',padx=8,pady=4);self.values[axis]=label
        self.note=ttk.Label(self,text='',foreground=MUTED,background='white',wraplength=380);self.note.pack(fill='x')

    def update_values(self,origin,result,axis,status=''):
        for name,frame in self.rows.items():
            if axis in ('XY',name):
                frame.pack(fill='x',before=self.note)
                i=0 if name=='X' else 1
                self.origins[name].configure(text=f'{origin[i]:.12g}' if origin else '—')
                self.values[name].configure(text=f'{result[i]:.12g}' if result else '—')
            else:frame.pack_forget()
        self.note.configure(text='' if origin and result else status)


class VerticalForm(ttk.Frame):
    """Keep a selection form scrollable without resizing its adjacent preview."""
    def __init__(self,parent):
        super().__init__(parent)
        self.columnconfigure(0,weight=1);self.rowconfigure(0,weight=1)
        self.canvas=tk.Canvas(self,background='#f3f5f9',highlightthickness=0)
        self.canvas.grid(row=0,column=0,sticky='nsew')
        self.scroll=ttk.Scrollbar(self,command=self.canvas.yview)
        self.content=ttk.Frame(self.canvas)
        self.window=self.canvas.create_window(0,0,window=self.content,anchor='nw')
        self.canvas.configure(yscrollcommand=self.scrolled)
        self.content.bind('<Configure>',self.reflow)
        self.canvas.bind('<Configure>',self.reflow)
        self.owner=self.winfo_toplevel()
        self.wheel_id=self.owner.bind('<MouseWheel>',self.wheel,add='+')
        self.bind('<Destroy>',self.cleanup,add='+')

    def reflow(self,event=None):
        width=self.canvas.winfo_width()
        self.canvas.itemconfigure(self.window,width=width)
        self.canvas.configure(scrollregion=(0,0,width,self.content.winfo_reqheight()))
        self.scrolled(*self.canvas.yview())

    def scrolled(self,first,last):
        self.scroll.set(first,last)
        if self.content.winfo_reqheight()<=self.canvas.winfo_height():
            self.scroll.grid_remove()
            if float(first)>0:self.canvas.yview_moveto(0)
        elif not self.scroll.winfo_manager():self.scroll.grid(row=0,column=1,sticky='ns')

    def wheel(self,event):
        if str(event.widget).startswith(str(self)):
            self.canvas.yview_scroll(-1 if event.delta>0 else 1,'units')
            return 'break'

    def cleanup(self,event):
        if event.widget is self:self.owner.unbind('<MouseWheel>',self.wheel_id)
