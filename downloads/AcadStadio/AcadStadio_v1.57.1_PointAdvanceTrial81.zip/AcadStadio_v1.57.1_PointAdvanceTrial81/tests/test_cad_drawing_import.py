"""Real synthetic DXF roundtrips and isolated mocked AutoCAD conversion lifecycle."""
import copy
import math
import os
from pathlib import Path
import shutil
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src'),str(Path(__file__).resolve().parents[1]/'scripts')]
try:
    import ezdxf
except ImportError:
    ezdxf=None
from cad_drawing_import import read_cad_drawing, extract_drawing, imported_project, append_drawing, DrawingImportError
from cad_setup import initial_macro, validate_setup
from engine import compile_project
from sample_project import EXAMPLE


@unittest.skipUnless(ezdxf,'ezdxf dependency not installed')
class DrawingImportTests(unittest.TestCase):
    def setUp(self):
        from build_cad_import_example import build_document
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'sample.dxf';build_document().saveas(self.path)

    def test_real_file_three_blocks_literals_and_source_unchanged(self):
        original=self.path.read_bytes();snapshot=read_cad_drawing(self.path)
        self.assertEqual(self.path.read_bytes(),original)
        self.assertEqual(snapshot['counts'],{'作図':10,'寸法':4,'テキスト':2})
        self.assertEqual([b['name'] for b in snapshot['blocks']],['作図ブロック','寸法ブロック','テキストブロック'])
        commands=[c for b in snapshot['blocks'] for c in b['commands']]
        for command in commands:
            for key,value in command.items():
                if key in ('x','y','x1','y1','x2','y2','x3','y3','r','rx','ry','height','angle','start_angle','end_angle','width'):
                    self.assertTrue(math.isfinite(float(value)))
            self.assertNotIn('点(',str(command));self.assertNotIn('loop.',str(command))
        self.assertTrue(any(n['type']=='SPLINE' for n in snapshot['issues']))
        self.assertTrue(any(n['type']=='LINE' and '3D' in n['reason'] for n in snapshot['issues']))
        project=imported_project(snapshot);script,items=compile_project(project,[0])
        self.assertEqual(len(items),16)
        self.assertEqual([i['text'] for i in items if i['type']=='TEXT'],['部品 @OD'])
        self.assertEqual([i['text_anchor'] for i in items if i['type'] in ('TEXT','MTEXT')],['center','center'])
        self.assertIn('vla-put-AttachmentPoint',script);self.assertIn('(72 . 1)',script)
        self.assertIn('_Horizontal',script)
        self.assertEqual(len(project['input_tables'][0]['rows']),1)
        self.assertNotIn('OD',project['input_tables'][0]['rows'][0])
        self.assertIn('import_source',commands[0])
        snapshot['name']='=not_a_column'
        compile_project(imported_project(snapshot),[0])

    def test_settings_patterns_and_system_variables_emit_with_restoration(self):
        snapshot=read_cad_drawing(self.path);setup=snapshot['cad_setup']
        self.assertEqual(validate_setup(setup),[])
        self.assertEqual(setup['drawing_variables']['LTSCALE'],'2.5')
        dash=next(r for r in setup['linetypes'] if r['name']=='IMPORTED_DASH')
        self.assertEqual(dash['pattern'],['8','-4']);self.assertFalse(dash['existing_only'])
        dim=next(r for r in setup['dim_styles'] if r['name']=='Import Dim')
        self.assertEqual(dim['text_style'],'Import Text');self.assertEqual(dim['scale'],'2')
        macro='\n'.join(initial_macro(setup));self.assertIn('(49 . -4)',macro);self.assertIn('(setvar "LTSCALE" 2.5)',macro)
        script,_=compile_project(imported_project(snapshot),[0]);self.assertIn('"MEASUREMENT"',script)
        self.assertIn('restore',script.lower())

    def test_drawing_only_skips_resources_and_preserves_existing_project_settings(self):
        with patch('cad_drawing_import.DrawingReader.resources') as resources:
            snapshot=read_cad_drawing(self.path,include_settings=False)
        resources.assert_not_called();self.assertIsNone(snapshot['cad_setup'])
        project=copy.deepcopy(EXAMPLE);original=copy.deepcopy(project)
        trial=append_drawing(project,snapshot)
        self.assertEqual(project,original)
        for key in project:
            if key!='blocks':self.assertEqual(trial[key],project[key])
        self.assertEqual(len(trial['blocks']),len(project['blocks'])+3)
        compile_project(trial,[0])

    def test_block_expansion_and_bulge_are_actual_transformed_geometry(self):
        snapshot=read_cad_drawing(self.path,include_settings=False)
        _,items=compile_project(imported_project(snapshot),[0])
        line=next(i for i in items if i['type']=='LINE' and abs(i['coords'][0]-200)<1e-6)
        self.assertAlmostEqual(line['coords'][2],200+20*math.cos(math.pi/6))
        self.assertAlmostEqual(line['coords'][3],10)
        self.assertEqual(line['color'],4)
        arcs=[i for i in items if i['type']=='ARC'];self.assertEqual(len(arcs),2)
        self.assertTrue(any(math.isclose(i['coords'][2],20) for i in arcs))

    def test_empty_invalid_3d_and_large_files_report_without_guessing(self):
        d=ezdxf.new();d.modelspace().add_line((0,0,5),(1,1,5))
        with self.assertRaises(DrawingImportError):extract_drawing(d,include_settings=False)
        doc=ezdxf.new();doc.blocks.new('EXTERNAL',dxfattribs={'flags':4,'xref_path':'missing.dwg'});doc.modelspace().add_blockref('EXTERNAL',(0,0));doc.modelspace().add_line((0,0),(10,0))
        result=extract_drawing(doc,include_settings=False)
        self.assertTrue(any('外部参照' in issue['reason'] for issue in result['issues']))
        bad=Path(self.temp.name)/'bad.dxf';bad.write_text('not dxf')
        with self.assertRaises(DrawingImportError):read_cad_drawing(bad)
        with bad.open('wb') as stream:stream.truncate(65*1024*1024)
        with self.assertRaisesRegex(DrawingImportError,'64MiB'):read_cad_drawing(bad)

    def test_solid_face_imports_as_solid_hatch_without_losing_fill(self):
        doc=ezdxf.new();doc.modelspace().add_solid([(0,0),(10,0),(0,5),(10,5)])
        snapshot=extract_drawing(doc,include_settings=False)
        command=snapshot['blocks'][0]['commands'][0]
        self.assertEqual(command['type'],'HATCH');self.assertEqual(command['pattern'],'SOLID')
        _,items=compile_project(imported_project(snapshot),[0]);self.assertEqual(items[0]['type'],'HATCH')

    def test_literal_layer_names_and_dimension_override_do_not_become_code(self):
        doc=ezdxf.new();doc.layers.new('@X');doc.layers.new('(quit)')
        doc.modelspace().add_line((0,0),(10,0),dxfattribs={'layer':'@X'})
        doc.modelspace().add_circle((20,0),5,dxfattribs={'layer':'(quit)'})
        dimension=doc.modelspace().add_linear_dim(base=(0,20),p1=(0,0),p2=(10,0))
        dimension.dimension.dxf.text='(literal)';dimension.render()
        result=extract_drawing(doc);script,items=compile_project(imported_project(result),[0])
        self.assertEqual(items[0]['layer'],'@X');self.assertEqual(items[1]['layer'],'(quit)')
        self.assertIn('"(quit)"',script);self.assertNotIn('\n(quit)\n',script)
        self.assertIn('(command-s "_.DIMLINEAR"',script)
        self.assertNotIn('\n(literal)\n',script)

    def fake_autocad(self, failure=False):
        source=Path(self.temp.name)/'source.dwg';source.write_bytes(b'ORIGINAL DWG')
        log=[]
        class Document:
            def SaveAs(doc,path,fmt):
                log.append(('save',path,fmt))
                if failure:raise RuntimeError('busy')
                shutil.copyfile(self.path,path)
            def Close(doc,save):log.append(('close',save))
        class Documents(list):
            def Open(docs,path,readonly):
                self.assertNotEqual(Path(path),source);self.assertEqual(Path(path).read_bytes(),b'ORIGINAL DWG')
                self.assertTrue(readonly);log.append(('open',path));return Document()
        acad=types.SimpleNamespace(Documents=Documents(),ActiveDocument=types.SimpleNamespace(Activate=lambda:log.append(('activate',))))
        pythoncom=types.SimpleNamespace(CoInitialize=lambda:log.append(('init',)),CoUninitialize=lambda:log.append(('uninit',)))
        client=types.ModuleType('win32com.client');client.GetActiveObject=lambda name:acad
        modules={'pythoncom':pythoncom,'win32com':types.ModuleType('win32com'),'win32com.client':client}
        return source,log,modules

    def test_dwg_uses_only_temporary_copy_closes_without_saving_and_restores_cad(self):
        source,log,modules=self.fake_autocad()
        with patch.dict(sys.modules,modules),patch('dwg_resources.os',types.SimpleNamespace(name='nt',path=os.path)):
            snapshot=read_cad_drawing(source)
        self.assertEqual(source.read_bytes(),b'ORIGINAL DWG');self.assertEqual(snapshot['counts']['寸法'],4)
        self.assertIn(('close',False),log);self.assertIn(('activate',),log);self.assertEqual(log[-1],('uninit',))
        self.assertEqual(next(r[2] for r in log if r[0]=='save'),61)
        self.assertFalse(Path(next(r[1] for r in log if r[0]=='open')).exists())

    def test_dwg_failed_export_still_cleans_up(self):
        source,log,modules=self.fake_autocad(True)
        with patch.dict(sys.modules,modules),patch('dwg_resources.os',types.SimpleNamespace(name='nt',path=os.path)):
            with self.assertRaisesRegex(DrawingImportError,'変換'):read_cad_drawing(source)
        self.assertIn(('close',False),log);self.assertEqual(log[-1],('uninit',));self.assertEqual(source.read_bytes(),b'ORIGINAL DWG')
