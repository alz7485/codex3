"""Real multiline input, font-colour traces and block-content rendering."""
import os,sys,unittest,copy,tkinter as tk
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
import test_gui as gui
from macro_editor import edit_command,MacroEditor
from test_native_operations import command

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class MtextGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_multiline_input_preserves_newlines_and_native_type(self):
        text='部品 A\n外径：100\n検査注記'
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                entry=w.command_entries['text'];self.assertIsInstance(entry,tk.Text)
                entry.delete(0,'end');entry.insert(0,text);self.root.update();self.assertEqual(entry.get(),text)
                w.refresh_command_preview();self.root.update();self.assertEqual(w.command_preview.canvas.items[-1]['type'],'MTEXT')
                self.assertTrue(w.command_preview.canvas.find_withtag('geometry'));gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(150,inspect);result=edit_command(self.root,command('MTEXT'),self.app.data['blocks'],self.app.data)
        self.assertIsNotNone(result);self.assertEqual(result['text'],text)
    def test_cad_block_preview_keeps_one_logical_entity_and_draws_contents(self):
        cmds=[dict(type='LINE',x1='0',y1='0',x2='20',y2='0'),command('CADBLOCK',x1='10',y1='0',x2='0',y2='0')]
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=cmds)]
        e=MacroEditor(self.root,p['blocks'][0],p['blocks'],lambda:None,p,[0]);self.root.update()
        self.assertEqual(len(e.preview_canvas.items),1);self.assertEqual(e.preview_canvas.items[0]['display_type'],'INSERT');self.assertTrue(e.preview_canvas.find_withtag('geometry'));e.cancel()
