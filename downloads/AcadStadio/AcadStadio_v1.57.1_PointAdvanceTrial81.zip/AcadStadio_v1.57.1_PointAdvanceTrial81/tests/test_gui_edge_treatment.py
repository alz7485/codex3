"""Japanese command forms, analytical results and point-count-dependent closure."""
import copy
import os
import sys
import unittest
import test_gui as gui
from macro_editor import edit_command,TYPE_LABELS
from engine import compile_project


@unittest.skipUnless(sys.platform=='win32' or os.environ.get('DISPLAY'),'GUI display unavailable')
class EdgeTreatmentGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def edit_corner(self,kind):
        sources=[dict(type='LINE',x1='@X',y1='@Y',x2='@X+100',y2='@Y'),dict(type='LINE',x1='@X',y1='@Y',x2='@X',y2='@Y+100')]
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                labels=[str(w.cget('text')) for w in gui.descendants(win) if 'text' in w.keys()]
                self.assertIn('1本目の選択点',labels);self.assertIn('2本目の選択点',labels)
                self.assertIn('丸め半径' if kind=='FILLET' else '面取り距離1',labels)
                current=win.command_preview.canvas.items[-1]
                self.assertEqual(current['display_type'],'ARC' if kind=='FILLET' else 'LINE')
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(60,inspect);result=edit_command(self.root,dict(type=kind),self.app.data['blocks'],self.app.data,point_sources=sources)
        self.assertIsNotNone(result)
        project=copy.deepcopy(self.app.data);project['blocks']=[dict(project['blocks'][0],commands=sources+[result])]
        script,items=compile_project(project,[0]);self.assertIn('"_.'+kind+'"',script)
        self.assertAlmostEqual(items[0]['coords'][0],110);self.assertAlmostEqual(items[1]['coords'][1],110)
        self.assertEqual(self.messages,[])

    def test_chamfer_form(self):self.assertEqual(TYPE_LABELS['CHAMFER'],'CHAMFER · 面取り');self.edit_corner('CHAMFER')
    def test_fillet_form(self):self.assertEqual(TYPE_LABELS['FILLET'],'FILLET · 角丸め');self.edit_corner('FILLET')

    def test_polyline_threshold_and_manual_open_choice(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                self.assertEqual(win.command_entries['closed'].get(),'0');self.assertTrue(win.closed_buttons['1'].instate(['disabled']))
                self.assertTrue(win.command_entries['closed'].reference_button.instate(['disabled']))
                win.add_vertex();self.root.update()
                for key,value in [('x3','@X+100'),('y3','@Y+50')]:win.command_entries[key].insert(0,value)
                self.assertEqual(win.command_entries['closed'].get(),'1');self.assertFalse(win.closed_buttons['1'].instate(['disabled']))
                win.closed_buttons['0'].invoke();win.add_vertex();self.root.update()
                for key,value in [('x4','@X+150'),('y4','@Y+50')]:win.command_entries[key].insert(0,value)
                self.assertEqual(win.command_entries['closed'].get(),'0')
                win.remove_vertex(3);win.remove_vertex(2);self.root.update()
                self.assertEqual(win.command_entries['closed'].get(),'0');self.assertTrue(win.closed_buttons['1'].instate(['disabled']))
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(60,inspect);result=edit_command(self.root,dict(type='POLYLINE'),self.app.data['blocks'],self.app.data)
        project=copy.deepcopy(self.app.data);project['blocks']=[dict(project['blocks'][0],commands=[result])]
        script,items=compile_project(project,[0]);self.assertFalse(items[0]['closed']);self.assertNotIn('_Close',script)
