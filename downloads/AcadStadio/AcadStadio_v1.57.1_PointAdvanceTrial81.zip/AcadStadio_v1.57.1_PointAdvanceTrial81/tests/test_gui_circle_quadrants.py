"""Visual quadrant pick, angular preview, XY insertion and retained settings."""
import copy
import os
import sys
import unittest
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project


@unittest.skipUnless(sys.platform=='win32' or os.environ.get('DISPLAY'),'GUI display unavailable')
class CircleQuadrantsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_marker_angle_xy_offsets_and_reopen(self):
        circle=dict(type='CIRCLE',x='100',y='100',r='50')
        def choose():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.choose_command_point('x');self.root.update()
                panel=win.point_panel;canvas=panel.point_preview.canvas
                self.assertEqual(tuple(panel.point_picker['values']),('中心','上','下','左','右'))
                sx,sy=canvas.screen_point(panel.point_preview.points['上'])
                canvas.event_generate('<ButtonPress-1>',x=int(sx),y=int(sy))
                canvas.event_generate('<ButtonRelease-1>',x=int(sx),y=int(sy));self.root.update()
                self.assertEqual(panel.point_picker.get(),'上')
                self.assertTrue(panel.angle_entry.winfo_ismapped())
                panel.axis_picker.set('XY');panel.axis_picker.event_generate('<<ComboboxSelected>>')
                panel.point_angle.set('90');panel.point_offsets['X'].set('3');panel.point_offsets['Y'].set('-4');self.root.update()
                x,y=canvas.shifted_point;self.assertAlmostEqual(x,53);self.assertAlmostEqual(y,96)
                gui.button(panel,'この点を使用').invoke()
                win.choose_command_point('x');self.root.update();panel=win.point_panel
                self.assertEqual(panel.point_picker.get(),'上');self.assertEqual(panel.point_angle.get(),'90')
                self.assertEqual(panel.axis_picker.get(),'XY');self.assertEqual(panel.point_offsets['Y'].get(),'-4')
                gui.button(panel,'キャンセル').invoke();gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:
                self.errors.append(exc);win.destroy()
        self.root.after(50,choose)
        result=edit_command(self.root,dict(type='POINT',x='0',y='0'),self.app.data['blocks'],self.app.data,point_sources=[circle])
        self.assertIsNotNone(result)
        project=copy.deepcopy(self.app.data);project['blocks']=[dict(project['blocks'][0],commands=[circle,result])]
        xy=compile_project(project,[0])[1][1]['coords'];self.assertAlmostEqual(xy[0],53);self.assertAlmostEqual(xy[1],96)
