"""New editing forms, erased-source display and a scrollable command palette."""
import os,sys,unittest
from pathlib import Path
from tkinter import ttk,Canvas
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
import test_gui as gui
from macro_editor import edit_command,MacroEditor,TYPE_LABELS
from test_native_operations import command

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class TransformCommandsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_forms_and_result_previews_with_deleted_source(self):
        line=dict(type='LINE',x1='0',y1='0',x2='50',y2='0')
        for kind in ('EXTEND','COPY','MIRROR'):
            prior=[line];current=command(kind,x1='20',y1='0',x2='0',y2='-10',x3='0',y3='10') if kind!='EXTEND' else command(kind,x1='100',y1='10',x2='40',y2='0')
            if kind=='EXTEND':prior+=[dict(type='LINE',x1='100',y1='-20',x2='100',y2='20')]
            if kind=='MIRROR':current['erase_source']='1'
            def inspect(kind=kind):
                w=gui.top(self.root,'コマンドの設定')
                try:
                    w.refresh_command_preview();self.root.update();canvas=w.command_preview.canvas
                    self.assertTrue(w.command_entries['x2'].reference_button.winfo_ismapped())
                    if kind=='EXTEND':
                        self.assertEqual(canvas.items[0]['coords'],(0.,0.,100.,0.))
                        canvas.fit();self.root.update()
                        notes=[n for n in canvas.find_withtag('geometry') if canvas.type(n)=='text' and '延長' in canvas.itemcget(n,'text')]
                        self.assertTrue(notes)
                        for node in notes:
                            box=canvas.bbox(node);self.assertGreaterEqual(box[0],0);self.assertLessEqual(box[2],canvas.winfo_width())
                    if kind=='COPY':self.assertEqual(canvas.items[-1]['coords'],(0.,20.,50.,20.))
                    if kind=='MIRROR':
                        self.assertEqual(len(canvas.items),1);self.assertEqual(canvas.items[0]['type'],'MIRROR');self.assertEqual(w.command_entries['erase_source'].get(),'1')
                    self.assertTrue(canvas.find_withtag('geometry'))
                    gui.button(w,'コマンドを反映').invoke()
                except Exception as exc:self.errors.append(exc);w.destroy()
            self.root.after(150,inspect);result=edit_command(self.root,current,self.app.data['blocks'],self.app.data,point_sources=prior)
            self.assertIsNotNone(result,kind)
    def test_narrow_palette_scrolls_to_last_command_and_search_resets_scroll(self):
        e=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],lambda:None,self.app.data,[0])
        def inspect():
            w=gui.top(self.root,'追加するコマンド')
            try:
                w.geometry('520x480');gui.button(w,'編集・複写').invoke();self.root.update()
                canvas=next(x for x in gui.descendants(w) if isinstance(x,Canvas))
                canvas.yview_moveto(1);self.root.update();b=gui.button(w,TYPE_LABELS['SCALE'])
                self.assertGreaterEqual(b.winfo_rooty(),canvas.winfo_rooty())
                self.assertLessEqual(b.winfo_rooty()+b.winfo_height(),canvas.winfo_rooty()+canvas.winfo_height())
                entry=next(x for x in gui.descendants(w) if isinstance(x,ttk.Entry));entry.insert(0,'ミラー');self.root.update()
                self.assertLess(canvas.yview()[0],.01)
            except Exception as exc:self.errors.append(exc)
            w.destroy()
        self.root.after(100,inspect);e.list.choose_add();e.cancel()
