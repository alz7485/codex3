import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from block_model import new_block
from sample_project import EXAMPLE
from project_data import current_table
from flow import resolve
import link_assistance as m


class LinkAssistance(unittest.TestCase):
    def project(self, commands):
        p = copy.deepcopy(EXAMPLE)
        p["blocks"] = [new_block("作図", commands=commands)]
        current_table(p)["rows"] = [
            {"名称": "基準", "外径": "100", "同径": "100", "半径": "50", "厚さ": "16"},
            {"名称": "別", "外径": "120", "同径": "120", "半径": "60", "厚さ": "20"},
        ]
        return p

    def test_usage_unique_nested_and_literals(self):
        p = self.project(
            [
                dict(
                    type="CIRCLE",
                    x="@外径",
                    y="@外径",
                    r="@外径 / 2",
                    import_source={"value": "@厚さ"},
                    link_review={"x": "@厚さ"},
                ),
                dict(
                    type="TEXT", x="0", y="0", height="3", angle="0", text="文字 @厚さ"
                ),
                dict(
                    type="IF",
                    condition="@厚さ > 0",
                    commands=[dict(type="POINT", x="@厚さ", y="0")],
                    **{"else": []},
                ),
            ]
        )
        t = current_table(p)
        u = m.table_usage(p)
        self.assertEqual(u[t["id"], "外径"], [("blocks", 0, "commands", 0)])
        self.assertEqual(len(u[t["id"], "厚さ"]), 2)
        p["globals"] = {"SIZE": "@外径 / 2"}
        p["blocks"][0]["commands"].append(dict(type="POINT", x="変数.SIZE", y="0"))
        self.assertEqual(len(m.table_usage(p)[t["id"], "外径"]), 2)

    def test_qualified_table_and_renamed_reference(self):
        p = self.project([dict(type="POINT", x="[別表]@外径", y="0")])
        other = {"id": "other", "name": "別表", "rows": [{"外径": "100"}]}
        p["input_tables"].append(other)
        self.assertEqual(
            m.table_usage(p)[("other", "外径")], [("blocks", 0, "commands", 0)]
        )
        self.assertNotIn((current_table(p)["id"], "外径"), m.table_usage(p))

    def test_candidates_are_explicit_dynamic_formulas_not_copied_numbers(self):
        p = self.project([dict(type="CIRCLE", x="0", y="0", r="50")])
        cmd = p["blocks"][0]["commands"][0]
        f = next(f for f in m.fields(cmd) if f.path == ("r",))
        cs = m.table_candidates(p, cmd, f, current_table(p)["id"], 0)
        self.assertEqual({c["column"] for c in cs}, {"外径", "同径", "半径"})
        chosen = next(c for c in cs if c["column"] == "外径")
        trial = m.checked_change(
            p, ("blocks", 0, "commands", 0), [(f, chosen["formula"])]
        )
        self.assertEqual(cmd["r"], "50")
        self.assertIn("@外径", trial["blocks"][0]["commands"][0]["r"])
        self.assertEqual(m.scenes(trial, 1)[0]["coords"][2], 60)

    def test_custom_recipe_and_invalid_formula(self):
        p = self.project([dict(type="CIRCLE", x="0", y="0", r="55")])
        cmd = p["blocks"][0]["commands"][0]
        f = next(f for f in m.fields(cmd) if f.path == ("r",))
        cs = m.table_candidates(p, cmd, f, current_table(p)["id"], 0, "値 / 2 + 5")
        self.assertEqual({c["column"] for c in cs}, {"外径", "同径"})
        for expression in ["1", "値 + unknown", '__import__("os") + 値']:
            with self.assertRaises((ValueError, m.MacroError)):
                m.table_candidates(p, cmd, f, current_table(p)["id"], 0, expression)

    def test_point_matching_atomic_xy_and_forward_rejection(self):
        p = self.project(
            [
                dict(type="LINE", x1="0", y1="0", x2="100", y2="0"),
                dict(
                    type="DIMLINEAR",
                    x1="0",
                    y1="0",
                    x2="100",
                    y2="0",
                    x3="50",
                    y3="-20",
                ),
            ]
        )
        at = ("blocks", 0, "commands", 1)
        cmd = resolve(p, at)
        pair = m.coordinate_pairs(cmd)[0]
        candidates = m.point_candidates(p, at, pair, 0)
        self.assertEqual(candidates[0]["point"], "始点")
        trial = m.checked_change(
            p, at, pair, source=(("blocks", 0, "commands", 0), "始点", "XY", ["0", "0"])
        )
        self.assertNotIn("point_id", p["blocks"][0]["commands"][0])
        self.assertIn("point_id", trial["blocks"][0]["commands"][0])
        self.assertIn("点(", resolve(trial, at)["x1"])
        self.assertIn("点(", resolve(trial, at)["y1"])
        self.assertEqual(m.status(resolve(trial, at)), (2, 6))
        with self.assertRaises(ValueError):
            m.checked_change(
                p,
                ("blocks", 0, "commands", 0),
                m.coordinate_pairs(p["blocks"][0]["commands"][0])[0],
                source=(at, "始点", "XY", ["0", "0"]),
            )

    def test_failed_change_and_fixed_review_do_not_count_stale_values(self):
        p = self.project([dict(type="CIRCLE", x="0", y="0", r="50")])
        at = ("blocks", 0, "commands", 0)
        cmd = resolve(p, at)
        f = m.fields(cmd)[0]
        cmd["link_review"] = {m.review_key(f): str(m.read(cmd, f.path))}
        self.assertEqual(m.status(cmd), (1, 3))
        m.write(cmd, f.path, "10")
        self.assertEqual(m.status(cmd), (0, 3))
        with self.assertRaises((ValueError, m.MacroError)):
            m.checked_change(p, at, [(f, "1 / 0")])
        self.assertEqual(m.read(cmd, f.path), "10")

    def test_path_vertex_edit_preserves_other_expressions(self):
        cmd = dict(type="POLYLINE", points="0,0; 10,0; 10,10", closed="1")
        fs = m.fields(cmd)
        f = fs[2]
        m.write(cmd, f.path, "@外径 / 2")
        self.assertEqual(m.read(cmd, f.path), "@外径 / 2")
        self.assertEqual(m.read(cmd, fs[3].path), "0")

    def test_cross_block_points_survive_save_and_source_change(self):
        import json

        p = self.project([dict(type="LINE", x1="0", y1="0", x2="@外径", y2="0")])
        p["blocks"].append(
            new_block(
                "寸法",
                commands=[
                    dict(
                        type="DIMLINEAR",
                        x1="0",
                        y1="0",
                        x2="100",
                        y2="0",
                        x3="50",
                        y3="-20",
                    )
                ],
            )
        )
        at = ("blocks", 1, "commands", 0)
        pair = m.coordinate_pairs(resolve(p, at))[1]
        trial = m.checked_change(
            p, at, pair, source=(("blocks", 0, "commands", 0), "終点", "XY", ["0", "0"])
        )
        trial = json.loads(json.dumps(trial))
        self.assertIn(p["blocks"][0]["id"] + "/", resolve(trial, at)["x2"])
        self.assertEqual(m.numeric_value(trial, resolve(trial, at)["x2"], 1), 120)
        resolve(trial, at)["link_review"] = {"x3": "50"}
        self.assertEqual(m.status(resolve(trial, at))[0], 3)

    def test_division_recipe_is_checked_on_real_column_values(self):
        p = self.project([dict(type="POINT", x="100 / 99", y="0")])
        cmd = resolve(p, ("blocks", 0, "commands", 0))
        f = m.fields(cmd)[0]
        cs = m.table_candidates(p, cmd, f, current_table(p)["id"], 0, "値 / (値 - 1)")
        self.assertEqual({c["column"] for c in cs}, {"外径", "同径"})
        self.assertEqual(
            m.table_candidates(p, cmd, f, current_table(p)["id"], 0, "値 / 0"), []
        )

    def test_review_metadata_and_literals_do_not_invent_links(self):
        p = self.project(
            [
                dict(
                    type="TEXT",
                    x="0",
                    y="0",
                    height="3",
                    text="'@外径",
                    layer="OUTLINE",
                    link_review={"r": "@半径"},
                )
            ]
        )
        self.assertEqual(m.table_usage(p), {})

    def test_repeated_sources_are_not_silently_bound_to_wrong_instance(self):
        p = self.project(
            [
                dict(
                    type="REPEAT",
                    count="2",
                    commands=[
                        dict(
                            type="LINE",
                            x1="loop.index * 10",
                            y1="0",
                            x2="loop.index * 10 + 5",
                            y2="0",
                        )
                    ],
                ),
                dict(type="POINT", x="0", y="0"),
            ]
        )
        at = ("blocks", 0, "commands", 1)
        pair = m.coordinate_pairs(resolve(p, at))[0]
        with self.assertRaisesRegex(ValueError, "複数"):
            m.checked_change(
                p,
                at,
                pair,
                source=(
                    ("blocks", 0, "commands", 0, "commands", 0),
                    "始点",
                    "XY",
                    ["0", "0"],
                ),
            )

    def test_x_only_offset_keeps_y_and_uses_dynamic_table_value(self):
        p = self.project(
            [
                dict(type="LINE", x1="0", y1="0", x2="100", y2="0"),
                dict(type="POINT", x="20", y="30"),
            ]
        )
        at = ("blocks", 0, "commands", 1)
        pair = m.coordinate_pairs(resolve(p, at))[0]
        trial = m.checked_change(
            p,
            at,
            pair,
            source=(("blocks", 0, "commands", 0), "始点", "X", ["@厚さ", "0"]),
        )
        self.assertEqual(resolve(trial, at)["y"], "30")
        self.assertEqual(m.scenes(trial, 1)[-1]["coords"], (20.0, 30.0))
        with self.assertRaises((ValueError, m.MacroError)):
            m.checked_change(
                p,
                at,
                pair,
                source=(("blocks", 0, "commands", 0), "始点", "XY", ["1/0", "0"]),
            )
        self.assertEqual(resolve(p, at)["x"], "20")

    def test_literal_dimension_styles_and_sysvar_text_not_counted(self):
        p = self.project(
            [
                dict(
                    type="DIMLINEAR",
                    x1="0",
                    y1="0",
                    x2="100",
                    y2="0",
                    x3="50",
                    y3="-20",
                    dimension_text="@外径",
                    text_style="@厚さ",
                    linetype="@同径",
                ),
                dict(type="SYSVAR", name="CLAYER", value_kind="text", value="@半径"),
                dict(type="TEXT", x="0", y="0", height="3", text="@外径 + 5"),
            ]
        )
        self.assertEqual(m.table_usage(p), {})
        p["blocks"][0]["commands"][1]["value"] = "=@半径"
        self.assertEqual(len(m.table_usage(p)[current_table(p)["id"], "半径"]), 1)
