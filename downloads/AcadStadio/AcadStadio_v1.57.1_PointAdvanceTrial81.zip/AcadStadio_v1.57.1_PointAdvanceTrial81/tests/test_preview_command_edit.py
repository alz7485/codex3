"""Direct geometry edits preserve addresses, original state and reference context."""
import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from block_model import new_block
from command_points import new_id
from sample_project import EXAMPLE
from engine import compile_project
from preview_command_edit import edit_rendered_command


class PreviewCommandEdit(unittest.TestCase):
    def project(self,commands):
        p=copy.deepcopy(EXAMPLE);p['blocks']=[new_block('作図',commands=commands)];return p

    def test_plain_command_transaction(self):
        p=self.project([dict(type='CIRCLE',x='0',y='0',r='10')]);before=copy.deepcopy(p)
        item=compile_project(p,[0])[1][0]
        with patch('preview_command_edit.edit_command',return_value=dict(type='CIRCLE',x='0',y='0',r='25')):
            result=edit_rendered_command(None,p,item)
        self.assertEqual(p,before);self.assertEqual(result['blocks'][0]['commands'][0]['r'],'25')

    def test_nested_else_repeat_and_clicked_row_context(self):
        p=self.project([dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),
                        dict(type='REPEAT',count='2',commands=[dict(type='IF',condition='0',commands=[],**{'else':[dict(type='CIRCLE',x='loop.index*50',y='0',r='10')]})])])
        item=next(i for i in compile_project(p,[1])[1] if i['type']=='CIRCLE')
        captured={}
        def edit(parent,command,blocks,project,*args,**kwargs):
            captured.update(kwargs);return dict(command,r='15')
        with patch('preview_command_edit.edit_command',side_effect=edit):result=edit_rendered_command(None,p,item)
        self.assertEqual(captured['initial_row'],1);self.assertEqual(captured['repeat_counts'],('2',))
        self.assertEqual(captured['point_sources'][0]['type'],'LINE')
        self.assertEqual(result['blocks'][0]['commands'][1]['commands'][0]['else'][0]['r'],'15')
        self.assertEqual(p['blocks'][0]['commands'][1]['commands'][0]['else'][0]['r'],'10')

    def test_cancel_discards_even_modified_source_ids(self):
        p=self.project([dict(type='CIRCLE',x='0',y='0',r='10')]);before=copy.deepcopy(p)
        def cancel(parent,command,blocks,*args,**kwargs):blocks[0]['name']='changed';return None
        with patch('preview_command_edit.edit_command',side_effect=cancel):self.assertIsNone(edit_rendered_command(None,p,compile_project(p,[0])[1][0]))
        self.assertEqual(p,before)

    def test_reference_id_allocated_in_prior_source_is_retained(self):
        p=self.project([dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),dict(type='POINT',x='0',y='10')]);point=new_id()
        def edit(parent,command,blocks,project,*args,**kwargs):
            kwargs['point_sources'][0]['point_id']=point
            return dict(command,x=f"点('{point}', '中点', 'X')")
        with patch('preview_command_edit.edit_command',side_effect=edit):result=edit_rendered_command(None,p,compile_project(p,[0])[1][-1])
        self.assertEqual(compile_project(result,[0])[1][-1]['coords'],(50,10))
        self.assertNotIn('point_id',p['blocks'][0]['commands'][0])
