"""The app uses one ordered collection; no reusable-block authoring workflow."""
import copy
import json
import os
from pathlib import Path
import sys
import unittest
from tkinter import ttk
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import test_gui as gui
from block_model import new_block
from macro_editor import MacroEditor, TYPE_LABELS
from project_model import normalize_sequential_project

@unittest.skipUnless(sys.platform=='win32' or os.environ.get('DISPLAY'),'GUI display unavailable')
class UnifiedBlocksGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def simple_project(self):
        return normalize_sequential_project({'version':11,'rows':[{'X':'0'}],
            'settings':{},'globals':{},'blocks':[
                new_block('円1',commands=[{'type':'CIRCLE','x':'0','y':'0','r':'1'}]),
                new_block('円2',commands=[{'type':'CIRCLE','x':'5','y':'0','r':'2'}])]})

    def edit(self,index=0):
        return MacroEditor(self.root,self.app.data['blocks'][index],self.app.data['blocks'],
                           self.app.refresh,self.app.data,[0])

    def test_initial_project_has_one_ordered_collection_without_drawing_mode_fields(self):
        self.assertIsInstance(self.app.data['blocks'],list)
        self.assertNotIn('presets',self.app.data)
        self.assertTrue(all('draw' not in b for b in self.app.data['blocks']))
        self.assertTrue(all('variables' not in b for b in self.app.data['blocks']))
        self.assertEqual(self.app.data['blocks'][0]['commands'][0]['type'],'CIRCLE')

    def test_removed_modes_are_absent_from_main_editor_and_navigator(self):
        self.assertFalse(hasattr(self.app,'toggle_block_draw'))
        editor=self.edit()
        self.assertFalse(hasattr(editor,'enabled'))
        self.assertFalse(hasattr(editor.list,'group'))
        for w in gui.descendants(editor.win):
            if isinstance(w,(ttk.Label,ttk.Checkbutton,ttk.Button)):
                self.assertNotIn('呼び出し',str(w.cget('text')))
                self.assertNotIn('作図対象にする',str(w.cget('text')))
        editor.cancel()
        self.app.open_navigator(); self.root.update()
        self.assertFalse(hasattr(self.app.navigator,'toggle_draw'))
        self.assertNotIn('group',type(self.app.navigator).__dict__)

    def test_command_picker_and_quick_add_have_no_block_reference_type(self):
        self.assertNotIn('BLOCK',TYPE_LABELS)
        editor=self.edit()
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                picker=next(w for w in gui.descendants(win) if isinstance(w,ttk.Combobox) and TYPE_LABELS['LINE'] in w.cget('values'))
                self.assertFalse(any(str(v).startswith('BLOCK ') or '呼出' in str(v) for v in picker.cget('values')))
                self.assertNotIn(TYPE_LABELS['SET'],picker.cget('values'))
            finally:
                gui.button(win,'キャンセル').invoke()
        self.root.after(20,inspect); editor.list.add(); editor.cancel()

    def test_new_block_cancel_leaves_no_data_or_history_changes(self):
        before=copy.deepcopy(self.app.data); history=copy.deepcopy(self.app._history)
        self.app.add_block(); win=gui.top(self.root,'ブロック編集')
        gui.button(win,'キャンセル').invoke()
        self.assertEqual(self.app.data,before);self.assertEqual(self.app._history,history)

    def test_rename_keeps_id_commands_and_can_be_undone(self):
        self.app.replace_document(self.simple_project());before=copy.deepcopy(self.app.data)
        editor=self.edit(); editor.name.set('新しい名前'); editor.save()
        self.assertEqual(self.app.data['blocks'][0]['id'],before['blocks'][0]['id'])
        self.assertEqual(self.app.data['blocks'][0]['commands'],before['blocks'][0]['commands'])
        self.app.undo_project();self.assertEqual(self.app.data,before)

    def test_editor_cancel_discards_direct_command_changes(self):
        before=copy.deepcopy(self.app.data);editor=self.edit()
        editor.name.set('別名');editor.list.commands.append({'type':'CIRCLE','x':'0','y':'0','r':'1'})
        editor.cancel();self.assertEqual(self.app.data,before)

    def test_saved_commands_stay_in_the_same_block_without_drawing_mode(self):
        self.app.replace_document(self.simple_project());editor=self.edit()
        command={'type':'LINE','x1':'0','y1':'0','x2':'10','y2':'10'}
        editor.list.commands.append(command);editor.save()
        self.assertEqual(len(self.app.data['blocks']),2)
        self.assertEqual(self.app.data['blocks'][0]['commands'][-1],command)
        self.assertTrue(all('draw' not in b for b in self.app.data['blocks']))

    def test_each_block_executes_once_per_target_row_in_list_order(self):
        self.app.replace_document(self.simple_project())
        items=self.app.compile()[1]
        self.assertEqual([i['coords'][2] for i in items],[1,2])
        self.app.block_list.selection_set('0');self.app.move_block(1)
        self.assertEqual([i['coords'][2] for i in self.app.compile()[1]],[2,1])

    def test_block_delete_and_undo_preserve_other_commands(self):
        self.app.replace_document(self.simple_project());before=copy.deepcopy(self.app.data)
        self.app.block_list.selection_set('0');self.app.del_block()
        self.assertEqual(self.app.data['blocks'],before['blocks'][1:])
        self.app.undo_project();self.assertEqual(self.app.data,before)

    def test_json_save_reload_keeps_direct_commands_and_omits_mode_fields(self):
        self.app.replace_document(self.simple_project())
        path=Path(self.library_dir.name)/'sequence.json'
        with patch('tkinter.filedialog.asksaveasfilename',return_value=str(path)):
            self.assertTrue(self.app.save())
        saved=json.loads(path.read_text()); self.assertTrue(all('draw' not in b for b in saved['blocks']))
        self.assertEqual(saved,self.app.data)
        self.assertTrue(self.app.open_project(path))
        self.assertEqual(self.app.data,saved)

    def test_unsupported_block_reference_file_cannot_replace_current_project(self):
        data=self.simple_project();data['blocks'][0]['commands']=[{'type':'BLOCK','name':data['blocks'][1]['id']}]
        path=Path(self.library_dir.name)/'unsupported.json';path.write_text(json.dumps(data))
        original=path.read_bytes();before=copy.deepcopy(self.app.data)
        self.assertFalse(self.app.open_project(path))
        self.assertEqual(self.app.data,before);self.assertEqual(path.read_bytes(),original)
