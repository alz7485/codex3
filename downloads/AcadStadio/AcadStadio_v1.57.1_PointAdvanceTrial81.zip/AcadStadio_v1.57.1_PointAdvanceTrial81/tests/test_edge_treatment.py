"""Trimmed corner geometry, references, native command stream and setting restore."""
import copy
import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from sample_project import EXAMPLE
from macro_editor import FIELDS
from engine import compile_project,MacroError
from command_points import new_id,reference,geometry_points
from edge_treatment import corner
from test_cad_state import read_form


def command(kind,**fields):return dict(type=kind,**dict(FIELDS[kind]))|fields

def project(commands):
    p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=commands)];return p

def lines():return [dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),dict(type='LINE',x1='0',y1='0',x2='0',y2='100')]

def operation(kind,**fields):return command(kind,**(dict(x1='50',y1='0',x2='0',y2='50')|fields))


class EdgeTreatment(unittest.TestCase):
    def test_unequal_chamfer_trims_both_lines_and_restores_settings(self):
        script,items=compile_project(project(lines()+[operation('CHAMFER',distance1='10',distance2='20')]),[0])
        self.assertEqual(items[0]['coords'],(10,0,100,0));self.assertEqual(items[1]['coords'],(0,20,0,100))
        self.assertEqual(items[2]['coords'],(10,0,0,20));self.assertEqual(items[2]['display_type'],'LINE')
        self.assertIn('"_.CHAMFER" (list first p1) (list second p2)',script)
        for name in ('CHAMMODE','TRIMMODE','CHAMFERA','CHAMFERB','FILLETRAD'):self.assertIn('"'+name+'"',script)
        self.assertIn('CADFLOWRESTORE',script)
        for text in script.splitlines():
            if text.startswith('('):read_form(text)

    def test_fillet_is_tangent_and_old_and_new_point_references_follow_result(self):
        source=lines();source[0]['point_id']=new_id();fillet=operation('FILLET',radius='10',point_id=new_id())
        marker=dict(type='POINT',x=reference(source[0]['point_id'],'始点','X'),y=reference(fillet['point_id'],'中点','Y'))
        script,items=compile_project(project(source+[fillet,marker]),[0])
        self.assertAlmostEqual(items[0]['coords'][0],10);self.assertEqual(items[0]['coords'][1:],(0,100,0))
        arc=items[2];self.assertEqual(arc['display_type'],'ARC')
        self.assertAlmostEqual(arc['coords'][0],10);self.assertAlmostEqual(arc['coords'][1],10);self.assertAlmostEqual(arc['sweep'],90)
        self.assertAlmostEqual(items[3]['coords'][0],10);self.assertAlmostEqual(items[3]['coords'][1],10-10/math.sqrt(2))
        self.assertIn('"_.FILLET"',script)
        for name,point in geometry_points(arc).items():
            if name!='中心':self.assertAlmostEqual(math.dist(point,arc['coords'][:2]),10)

    def test_oblique_lines_and_off_line_pick_use_exact_line_direction(self):
        first=(0,0,100,0);second=(0,0,50,80)
        one,two,arc=corner(first,second,(50,.001),(25.001,40),{'radius':8},'FILLET')
        center=arc['coords'][:2];a,b=one[:2],two[:2]
        self.assertAlmostEqual(a[1],0);self.assertAlmostEqual(b[1]/b[0],80/50)
        self.assertAlmostEqual(math.dist(a,center),8);self.assertAlmostEqual(math.dist(b,center),8)
        self.assertAlmostEqual((center[0]-a[0])*100,0)
        self.assertAlmostEqual((center[0]-b[0])*50+(center[1]-b[1])*80,0)

    def test_invalid_sizes_parallel_same_and_ambiguous_lines_fail(self):
        for op in (operation('CHAMFER',distance1='0'),operation('FILLET',radius='-1'),operation('FILLET',radius='200')):
            with self.assertRaises(MacroError):compile_project(project(lines()+[op]),[0])
        for source in (lines()+[lines()[0]], [lines()[0]]):
            with self.assertRaises(MacroError):compile_project(project(source+[operation('CHAMFER',x2='75',y2='0')]),[0])
        with self.assertRaisesRegex(ValueError,'平行'):corner((0,0,100,0),(0,10,100,10),(50,0),(50,10),{'radius':2},'FILLET')

    def test_external_cad_targets_do_not_get_fabricated_preview(self):
        _,items=compile_project(project([operation('FILLET')]),[0])
        self.assertNotIn('display_type',items[0]);self.assertIn('プレビュー外',items[0]['preview_note'])
