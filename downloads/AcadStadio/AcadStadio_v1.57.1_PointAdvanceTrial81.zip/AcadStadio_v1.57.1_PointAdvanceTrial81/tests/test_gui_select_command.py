"""SELECT centralizes multi-point/range editing; operators only choose a set."""
import os,sys,unittest,copy
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
import test_gui as gui
from macro_editor import edit_command
from range_selection import MODES
from test_native_operations import command
from engine import compile_project

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class SelectCommandGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_multiple_point_clicks_rectangle_remove_clear_and_undo(self):
        prior=[dict(type='LINE',x1='0',y1='0',x2='20',y2='0'),dict(type='CIRCLE',x='40',y='0',r='5')]
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.refresh_command_preview();self.root.update();canvas=w.command_preview.canvas;canvas.fit()
                gui.button(w,'プレビューで追加').invoke()
                for point in [(10,0),(45,0),(10,0)]:
                    x,y=canvas.screen_point(point);canvas.event_generate('<ButtonPress-1>',x=round(x),y=round(y));canvas.event_generate('<ButtonRelease-1>',x=round(x),y=round(y));self.root.update()
                self.assertEqual(len(w.select_editor.tree.get_children()),2)
                w.focus_force();w.event_generate('<Escape>');self.root.update();self.assertIsNone(canvas.point_callback)
                w.selection_mode_picker.set(MODES['window']);w.selection_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                for key,value in [('x1','-5'),('y1','-6'),('x4','46'),('y4','6')]:
                    e=w.command_entries[key];e.delete(0,'end');e.insert(0,value)
                gui.button(w,'入力した選択を追加').invoke();self.root.update();self.assertEqual(len(w.select_editor.tree.get_children()),3)
                w.select_editor.tree.selection_set('0');w.select_editor.remove();self.root.update();self.assertEqual(len(w.select_editor.tree.get_children()),2)
                w.select_editor.clear();self.root.update();self.assertEqual(len(w.select_editor.tree.get_children()),0)
                w.undo_draft();self.root.update();self.assertEqual(len(w.select_editor.tree.get_children()),2)
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(180,inspect);result=edit_command(self.root,dict(type='SELECT'),self.app.data['blocks'],self.app.data,point_sources=prior)
        self.assertIsNotNone(result);self.assertEqual(result['type'],'SELECT');self.assertEqual(len(result['selections']),2)
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=prior+[result])];_,items=compile_project(p,[0]);self.assertEqual(items[-1]['selected_count'],2)
    def test_operator_uses_selector_name_and_hides_target_coordinates(self):
        selector=dict(type='SELECT',point_id='p_'+'b'*32,selection_name='外形',pick_tolerance='0.01',selections=[dict(mode='point',x1='10',y1='0')])
        prior=[dict(type='LINE',x1='0',y1='0',x2='20',y2='0'),selector]
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                self.assertNotIn('x1',w.command_entries);self.assertTrue(w.selection_ref_picker.winfo_ismapped());self.assertIn('x2',w.command_entries)
                self.assertFalse(hasattr(w,'selection_mode_picker'));w.refresh_command_preview();self.root.update();gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(180,inspect);result=edit_command(self.root,dict(type='COPY',selection_ref=selector['point_id']),self.app.data['blocks'],self.app.data,point_sources=prior)
        self.assertIsNotNone(result);self.assertEqual(result['selection_ref'],selector['point_id']);self.assertNotIn('x1',result)
    def test_repeated_rectangle_drags_accumulate_and_nested_select_is_staged(self):
        prior=[dict(type='LINE',x1='0',y1='0',x2='20',y2='0'),dict(type='CIRCLE',x='40',y='0',r='5')]
        def outer():
            parent=gui.top(self.root,'コマンドの設定')
            def inner():
                from tkinter import Toplevel
                w=next(x for x in gui.descendants(parent) if isinstance(x,Toplevel) and hasattr(x,'select_editor'))
                try:
                    w.selection_mode_picker.set(MODES['window']);w.selection_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                    w.refresh_command_preview();self.root.update();canvas=w.command_preview.canvas;canvas.fit();gui.button(w,'プレビューで追加').invoke()
                    for a,b in [((-1,-1),(21,1)),((34,-6),(46,6))]:
                        x,y=canvas.screen_point(a);xx,yy=canvas.screen_point(b)
                        canvas.event_generate('<ButtonPress-1>',x=round(x),y=round(y));canvas.event_generate('<B1-Motion>',x=round(xx),y=round(yy));canvas.event_generate('<ButtonRelease-1>',x=round(xx),y=round(yy));self.root.update()
                    self.assertEqual(len(w.select_editor.tree.get_children()),2)
                    gui.button(w,'コマンドを反映').invoke()
                except Exception as exc:self.errors.append(exc);w.destroy()
            self.root.after(150,inner)
            try:
                parent.create_select();self.root.update();self.assertIn('選択',parent.selection_ref_picker.get());gui.button(parent,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);parent.destroy()
        self.root.after(150,outer)
        result=edit_command(self.root,dict(type='COPY'),self.app.data['blocks'],self.app.data,point_sources=prior)
        self.assertEqual([c['type'] for c in result],['SELECT','COPY']);self.assertEqual(result[1]['selection_ref'],result[0]['point_id'])
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=prior+result)];_,items=compile_project(p,[0]);self.assertEqual(items[2]['selected_count'],2)
    def test_select_created_after_queued_geometry_keeps_execution_order(self):
        def outer():
            parent=gui.top(self.root,'コマンドの設定')
            try:
                for key,value in [('x1','0'),('y1','0'),('x2','20'),('y2','0')]:
                    e=parent.command_entries[key];e.delete(0,'end');e.insert(0,value)
                gui.button(parent,'追加して続ける').invoke();self.root.update()
                picker=next(x for x in gui.descendants(parent) if hasattr(x,'cget') and x.winfo_class()=='TCombobox' and 'LINE · 線分' in x.cget('values'))
                from macro_editor import TYPE_LABELS
                picker.set(TYPE_LABELS['COPY']);picker.event_generate('<<ComboboxSelected>>');self.root.update()
                def inner():
                    import tkinter as tk
                    w=next(x for x in gui.descendants(parent) if isinstance(x,tk.Toplevel) and hasattr(x,'select_editor'))
                    try:
                        for key,value in [('x1','10'),('y1','0')]:
                            e=w.command_entries[key];e.delete(0,'end');e.insert(0,value)
                        w.select_editor.add_pending();gui.button(w,'コマンドを反映').invoke()
                    except Exception as exc:self.errors.append(exc);w.destroy()
                self.root.after(100,inner);parent.create_select();self.root.update();gui.button(parent,'追加して閉じる').invoke()
            except Exception as exc:self.errors.append(exc);parent.destroy()
        self.root.after(150,outer)
        result=edit_command(self.root,dict(type='LINE'),self.app.data['blocks'],self.app.data,allow_continue=True)
        self.assertEqual([c['type'] for c in result],['LINE','SELECT','COPY'])
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=result)];_,items=compile_project(p,[0]);self.assertEqual(items[1]['selected_count'],1)
