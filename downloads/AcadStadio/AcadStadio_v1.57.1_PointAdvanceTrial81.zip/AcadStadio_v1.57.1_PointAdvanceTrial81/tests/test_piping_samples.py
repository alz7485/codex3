"""Sourced fitting rows, editable flows, full-row compilation and cap geometry."""
import copy,json,math,sys,unittest
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
from sample_project import EXAMPLE
from piping_samples import build_piping_sample,catalog,BUILDERS
from project_model import validate_project
from engine import compile_project

class PipingSamples(unittest.TestCase):
    def test_sources_exclusions_and_dimensional_checks(self):
        c=catalog();self.assertEqual(set(c['catalog']),set(BUILDERS));self.assertTrue(c['excluded'])
        for family,source in c['catalog'].items():
            self.assertTrue(source['source_url'].startswith('https://fkkjp.com/'))
            seen=set()
            for row in source['rows']:
                key=(row['SCHEDULE'],row['A'],row.get('A2'),row.get('RADIUS_KIND'));self.assertNotIn(key,seen);seen.add(key)
                self.assertNotIn(row['A'],(175,225));self.assertAlmostEqual(row['OD']-row['ID'],2*row['T'],delta=.111)
                self.assertGreater(row['ID'],0)
                if 'ID2' in row:self.assertAlmostEqual(row['OD2']-row['ID2'],2*row['T2'],delta=.111)
    def test_all_variants_compile_and_json_roundtrip(self):
        p=build_piping_sample(EXAMPLE);self.assertEqual(validate_project(p),[])
        self.assertEqual(json.loads(json.dumps(p)),p)
        for table in p['input_tables']:
            probe=copy.deepcopy(p);probe['input_tables']=[dict(table,rows=[])];probe['active_table']=table['id'];probe['drawing']['targets']={table['id']:dict(mode='selected',selected=[0],range='')}
            for index,row in enumerate(table['rows']):
                probe['input_tables'][0]['rows']=[row]
                try:script,items=compile_project(probe,[0],validate=False)
                except Exception as exc:self.fail(f"{table['name']} {index+1} {row['TYPE']}: {exc}")
                self.assertTrue(items);self.assertTrue(all(i['block_index']==list(BUILDERS).index(row['FAMILY']) for i in items));self.assertIn('CADFLOWRESTORE',script)
    def test_cap_uses_length_threshold_and_true_inner_ellipse_ratio(self):
        p=build_piping_sample(EXAMPLE,['cap']);table=p['input_tables'][0];rows=table['rows']
        for schedule in ('40','80','160'):
            row=next(r for r in rows if r['A']=='50' and r['SCHEDULE']==schedule)
            table['rows']=[row];_,items=compile_project(p,[0]);curves=[i for i in items if i['type']=='POLYLINE']
            expected=float(row['E1']) if float(row['LIMIT'])>0 and float(row['T'])>float(row['LIMIT']) else float(row['E'])
            self.assertAlmostEqual(max(curves[0]['coords'][::2])-float(row['X']),expected)
            self.assertAlmostEqual(max(curves[0]['coords'][1::2])-min(curves[0]['coords'][1::2]),float(row['OD']))
            inner=curves[1]['coords'];self.assertAlmostEqual(max(inner[1::2])-min(inner[1::2]),float(row['ID']))
    def test_reducer_eccentric_flat_side_and_short_elbow_variants(self):
        p=build_piping_sample(EXAMPLE,['reducer']);table=p['input_tables'][0];row=next(r for r in table['rows'] if r['A']=='50' and r['A2']=='25' and r['SCHEDULE']=='40' and r['ECCENTRIC']=='1');table['rows']=[row]
        _,items=compile_project(p,[0]);outer=items[0]['coords'];self.assertAlmostEqual(outer[1],outer[3])
        p=build_piping_sample(EXAMPLE,['elbow']);self.assertTrue(all(float(r['H'])>0 for r in p['input_tables'][0]['rows'] if r['ANGLE']=='45'))
        for row in p['input_tables'][0]['rows']:
            if row['RADIUS_KIND']=='LONG' and row['ANGLE']=='45':
                p['input_tables'][0]['rows']=[row];_,items=compile_project(p,[0]);center=next(i for i in items if i['type']=='ARC' and i['layer']=='CENTER');self.assertAlmostEqual(center['coords'][2]*math.tan(math.radians(22.5)),float(row['H']));break
