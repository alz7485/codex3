"""Sample menu, table switching and independent export/preview selection."""
import os
import sys
import unittest
import test_gui as gui


@unittest.skipUnless(sys.platform == 'win32' or os.environ.get('DISPLAY'), 'GUI display unavailable')
class PipingSamplesGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_sample_menu_loads_all_families_and_switches_titles_and_geometry(self):
        self.app.load_piping_sample()
        self.root.update()
        for family in ('elbow', 'reducer', 'tee', 'cap'):
            self.app.switch_table('jis_' + family)
            self.root.update()
            self.app.preview(quiet=True)
            title = self.app.rows[0]['TYPE']
            self.assertEqual(self.app.preview_row_controls.full_title, title)
            self.assertTrue(self.app.canvas.items)
            self.assertEqual(self.app.target_rows(), [0])
            self.assertTrue(all(item['block_index'] == ('elbow', 'reducer', 'tee', 'cap').index(family)
                                for item in self.app.canvas.items))
        self.assertEqual(self.messages, [])

    def test_preview_row_can_change_without_changing_scr_target(self):
        self.app.load_piping_sample()
        self.root.update()
        self.app.switch_table('jis_cap')
        self.root.update()
        before = self.app.compile()[0]
        self.app.preview_row_controls.value.set('2')
        self.app.preview_row_controls.apply()
        self.root.update()
        self.app.preview(quiet=True)
        self.assertEqual(self.app.preview_rows(), [1])
        self.assertEqual(self.app.preview_row_controls.full_title, self.app.rows[1]['TYPE'])
        self.assertEqual(self.app.target_rows(), [0])
        self.assertEqual(self.app.compile()[0], before)
        self.assertEqual(self.messages, [])
