"""EXTEND/COPY/MIRROR: results, source attributes and reference lifetimes."""
import copy,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from engine import compile_project,MacroError
from command_points import reference,geometry_points
from test_native_operations import command,project
from test_cad_state import read_form,walk

class TransformCommands(unittest.TestCase):
    def line(self,**kw):return dict(type='LINE',x1='0',y1='0',x2='50',y2='0')|kw
    def test_extend_end_and_downstream_reference(self):
        identity='p_'+'d'*32
        p=project([self.line(point_id=identity),self.line(x1='100',y1='-20',x2='100',y2='20'),command('EXTEND',x1='100',y1='10',x2='40',y2='0'),dict(type='POINT',x=reference(identity,'終点','X'),y='0')])
        original=copy.deepcopy(p);script,items=compile_project(p,[0]);self.assertEqual(p,original)
        self.assertEqual(items[0]['coords'],(0.,0.,100.,0.));self.assertEqual(items[-1]['coords'],(100.,0.));self.assertIn('"_.EXTEND"',script)
    def test_extend_start_to_circle_and_finite_boundary(self):
        _,items=compile_project(project([self.line(),dict(type='CIRCLE',x='-50',y='0',r='10'),command('EXTEND',x1='-50',y1='10',x2='10',y2='0')]),[0]);self.assertAlmostEqual(items[0]['coords'][0],-40.)
        _,items=compile_project(project([self.line(),self.line(x1='100',y1='10',x2='100',y2='20'),command('EXTEND',x1='100',y1='15',x2='40',y2='0')]),[0]);self.assertNotIn('preview_applied',items[-1]);self.assertIn('CADで確認',items[-1]['preview_note'])
    def test_copy_geometry_and_original_properties(self):
        _,items=compile_project(project([self.line(layer='OUTLINE',color='2',linetype='CENTER',linetype_scale='2'),command('SYSVAR',name='CECOLOR',value='1'),command('COPY',x1='20',y1='0',x2='0',y2='0',x3='10',y3='20')]),[0])
        self.assertEqual(items[-1]['coords'],(10.,20.,60.,20.));self.assertEqual(items[-1]['color'],2);self.assertEqual(items[-1]['effective_layer'],'OUTLINE');self.assertEqual(items[-1]['linetype'],'CENTER')
        _,items=compile_project(project([self.line(),command('COPY',x1='20',y1='0',x2='0',y2='0',x3='10',y3='20',color='3',layer='COPY_LAYER')]),[0]);self.assertEqual(items[-1]['color'],3);self.assertEqual(items[-1]['effective_layer'],'COPY_LAYER')
    def test_copy_circle_center_and_point_reference(self):
        identity='p_'+'e'*32
        _,items=compile_project(project([dict(type='CIRCLE',x='0',y='0',r='10'),command('COPY',x1='0',y1='0',x2='0',y2='0',x3='40',y3='50',point_id=identity),dict(type='POINT',x=reference(identity,'中心','X'),y=reference(identity,'中心','Y'))]),[0]);self.assertEqual(items[1]['coords'],(40.,50.,10.));self.assertEqual(items[-1]['coords'],(40.,50.))
    def test_mirror_arc_reverses_angles_and_keeps_original(self):
        _,items=compile_project(project([dict(type='ARC',x='10',y='10',r='5',start_angle='0',end_angle='90'),command('MIRROR',x1='15',y1='10',x2='0',y2='0',x3='0',y3='100')]),[0]);self.assertAlmostEqual(items[1]['coords'][0],-10.);self.assertAlmostEqual(items[1]['coords'][1],10.);self.assertEqual(items[1]['coords'][2],5.);self.assertAlmostEqual(items[1]['start_angle'],90.);self.assertEqual(items[1]['sweep'],90.);self.assertNotIn('operation_deleted',items[0])
    def test_mirror_deletion_invalidates_original_but_new_reference_works(self):
        old='p_'+'1'*32;new='p_'+'2'*32
        commands=[self.line(point_id=old),command('MIRROR',x1='20',y1='0',x2='0',y2='-10',x3='0',y3='10',erase_source='1',point_id=new),dict(type='POINT',x=reference(new,'終点','X'),y='0')]
        _,items=compile_project(project(commands),[0]);self.assertTrue(items[0]['operation_deleted']);self.assertEqual(geometry_points(items[0]),{});self.assertAlmostEqual(items[-1]['coords'][0],-50)
        commands[-1]['x']=reference(old,'終点','X')
        with self.assertRaises(MacroError):compile_project(project(commands),[0])
    def test_copy_hatch_ellipse_text_and_single_line_entity(self):
        for source,pick in [(command('HATCH',points='0,0;20,0;20,20;0,20'),(20,20)),(dict(type='ELLIPSE',x='0',y='0',rx='20',ry='10',angle='30'),(0,0)),(dict(type='TEXT',x='0',y='0',text='注記',height='3'),(0,0))]:
            with self.subTest(type=source['type']):
                _,items=compile_project(project([source,command('COPY',x1=str(pick[0]),y1=str(pick[1]),x2='0',y2='0',x3='100',y3='0')]),[0]);self.assertEqual(items[-1]['display_type'],source['type'])
        _,items=compile_project(project([dict(type='LINE',vertices=[dict(x='0',y='0'),dict(x='20',y='0'),dict(x='20',y='20')],x1='0',y1='0',x2='20',y2='20'),command('COPY',x1='10',y1='0',x2='0',y2='0',x3='0',y3='40')]),[0]);self.assertEqual(items[-1]['coords'],(0.,40.,20.,40.))
    def test_degenerate_axis_and_extend_middle_rejected(self):
        for kind in ('COPY','MIRROR'):
            with self.subTest(kind=kind),self.assertRaises(MacroError):compile_project(project([command(kind,x2='0',y2='0',x3='0',y3='0')]),[0])
        with self.assertRaises(MacroError):compile_project(project([command('MIRROR',erase_source='2')]),[0])
        with self.assertRaises(MacroError):compile_project(project([self.line(),self.line(x1='100',y1='-20',x2='100',y2='20'),command('EXTEND',x1='100',y1='10',x2='25',y2='0')]),[0])
    def test_json_output_lisp_structure_and_no_implicit_attribute_override(self):
        for kind in ('EXTEND','COPY','MIRROR'):
            script,items=compile_project(json.loads(json.dumps(project([command(kind)]))),[0]);self.assertIn('"_.'+kind+'"',script)
            for line in script.splitlines():
                if line.startswith('('):
                    form=read_form(line)
                    for node in walk(form):
                        if node and node[0]=='if':self.assertIn(len(node),(3,4),node)
            if kind=='COPY':
                operation=next(line for line in script.splitlines() if 'Copy/mirror did not' in line)
                self.assertNotIn('vla-put-Color',operation);self.assertNotIn('vla-put-Layer',operation);self.assertIn('COPYMODE',script)
