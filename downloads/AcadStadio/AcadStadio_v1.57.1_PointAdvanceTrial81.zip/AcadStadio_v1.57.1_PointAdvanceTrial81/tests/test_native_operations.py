"""New native operations: output, geometry, ambiguity and downstream references."""
import copy,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from engine import compile_project,MacroError
from sample_project import EXAMPLE
from macro_editor import FIELDS
from extended_commands import TYPES,hatch_segments
from command_points import geometry_points,reference
from audit import audit_project
from test_cad_state import read_form


def command(kind,**values):return dict(type=kind,**dict(FIELDS[kind])) | values

def project(commands):
    p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=commands)];return p

class NativeOperations(unittest.TestCase):
    def test_native_commands_json_and_native_script(self):
        commands=[command(k,**({'block_name':'検査部品'} if k=='INSERT' else {})) for k in sorted(TYPES)]
        p=json.loads(json.dumps(project(commands)))
        self.assertEqual(audit_project(p),[])
        script,items=compile_project(p,[0]);self.assertEqual(len(items),len(TYPES))
        for token in ['_.-HATCH','_.SPLINE','vla-InsertBlock','_.LEADER','_.OFFSET','_.TRIM','Selection must identify exactly one curve','Trim/extend did not modify target']:
            self.assertIn(token,script)
        for line in script.splitlines():
            if line.startswith('('):read_form(line)
        for name in ['HPNAME','HPASSOC','HPANG','HPSCALE','OFFSETDIST','SPLKNOTS','TRIMEXTENDMODE','EDGEMODE','PROJMODE']:
            self.assertIn('"'+name+'"',script)

    def test_hatch_validity_and_bounded_concave_pattern(self):
        for points in ['0,0; 10,10; 0,10; 10,0','0,0; 10,0; 20,0','0,0; 10,0; 10,10; 0,0']:
            with self.subTest(points=points),self.assertRaises(MacroError):compile_project(project([command('HATCH',points=points)]),[0])
        pts=[(0,0),(10,0),(10,4),(4,4),(4,10),(0,10)]
        strokes=hatch_segments(pts,15,.000001);self.assertTrue(strokes);self.assertLessEqual(len(strokes),406)
        _,items=compile_project(project([command('HATCH',points='0,0;10,0;10,4;4,4;4,10;0,10',pattern='SOLID')]),[0])
        self.assertTrue(items[0]['closed'])

    def test_invalid_numbers_names_and_text(self):
        for c in [command('INSERT',block_name=''),command('INSERT',block_name='A',scale_x='0'),command('HATCH',scale='0'),command('HATCH',pattern='ANSI31\nLINE'),command('OFFSET',distance='-1'),command('TRIM',pick_tolerance='0'),command('LEADER',text='bad\ntext')]:
            with self.subTest(command=c),self.assertRaises(MacroError):compile_project(project([c]),[0])

    def test_spline_fit_points_and_leader_annotation(self):
        script,items=compile_project(project([command('SPLINE',points='0,0;10,20;30,0'),command('LEADER',text='=@OD')]),[0])
        spline=items[0];self.assertEqual(geometry_points(spline),{'始点':(0.,0.),'終点':(30.,0.)})
        self.assertEqual(spline['curve'][:2],(0.,0.));self.assertEqual(spline['curve'][-2:],(30.,0.));self.assertEqual(float(items[1]['text']),100)
        self.assertIn('_Knots\n_Chord',script)

    def test_line_trim_updates_preview_and_later_point_reference(self):
        identity='p_'+'a'*32
        commands=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0',point_id=identity),dict(type='LINE',x1='40',y1='-20',x2='40',y2='20'),command('TRIM',x1='40',y1='10',x2='80',y2='0'),dict(type='POINT',x=reference(identity,'終点','X'),y='0')]
        _,items=compile_project(project(commands),[0]);self.assertEqual(items[0]['coords'],(0.,0.,40.,0.));self.assertTrue(items[2]['preview_applied']);self.assertEqual(items[3]['coords'],(40.,0.))
        # Compilation does not alter source commands.
        self.assertEqual(commands[0]['x2'],'100')

    def test_offset_result_and_external_geometry_notice(self):
        _,items=compile_project(project([dict(type='LINE',x1='0',y1='0',x2='100',y2='0'),command('OFFSET',x1='50',y1='0',x2='50',y2='20',distance='10')]),[0])
        self.assertEqual(items[1]['display_type'],'LINE');self.assertEqual(items[1]['coords'],(0.,10.,100.,10.))
        _,items=compile_project(project([command('OFFSET')]),[0]);self.assertNotIn('display_type',items[0]);self.assertIn('CADで確認',items[0]['preview_note'])
        _,items=compile_project(project([dict(type='CIRCLE',x='0',y='0',r='20'),command('OFFSET',x1='20',y1='0',x2='50',y2='0',distance='5')]),[0]);self.assertEqual(items[1]['coords'],(0.,0.,25.))

    def test_trim_middle_creates_two_preview_segments(self):
        _,items=compile_project(project([dict(type='LINE',x1='-50',y1='0',x2='50',y2='0'),dict(type='CIRCLE',x='0',y='0',r='10'),command('TRIM',x1='0',y1='10',x2='0',y2='0')]),[0]);self.assertEqual(items[0]['segments'],[(-50.,0.,-10.,0.),(10.,0.,50.,0.)]);self.assertEqual(geometry_points(items[0]),{})
