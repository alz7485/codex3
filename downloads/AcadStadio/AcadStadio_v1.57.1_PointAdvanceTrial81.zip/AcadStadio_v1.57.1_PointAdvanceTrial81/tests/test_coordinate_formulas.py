"""Coordinate recipes, roundtrips and isolated repeat-editor sample contexts."""
import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from coordinate_formulas import MODES,formulas,positions,read_formulas,repeat_context
from engine import compile_project,row_values,MacroError
from sample_project import EXAMPLE


class CoordinateFormulas(unittest.TestCase):
    def test_translation_and_polar_coordinates(self):
        values=row_values(EXAMPLE,0)
        self.assertEqual(positions(MODES[0],dict(x='@X',y='@Y',dx='25',dy='-10'),values),[(125,90)])
        point=positions(MODES[1],dict(x='@X',y='@Y',distance='20',angle='90'),values)[0]
        self.assertAlmostEqual(point[0],100);self.assertAlmostEqual(point[1],120)

    def test_linear_spacing_and_circle_diameter_direction(self):
        values=row_values(EXAMPLE,0)
        self.assertEqual(positions(MODES[2],dict(x='@X',y='@Y',pitch='-25'),values,3),[(100,100),(75,100),(50,100)])
        self.assertEqual(positions(MODES[3],dict(x='@X',y='@Y',pitch='@N*10'),values,3),[(100,100),(100,140),(100,180)])
        p=dict(x='0',y='0',radius='100',angle='90',size_mode='直径',direction='時計回り')
        points=positions(MODES[4],p,values,4)
        for actual,expected in zip(points,[(0,50),(50,0),(0,-50),(-50,0)]):
            for a,b in zip(actual,expected):self.assertAlmostEqual(a,b)
        self.assertEqual(positions(MODES[4],p,values,0),[])
        with self.assertRaisesRegex(ValueError,'半径'):positions(MODES[4],dict(p,radius='-1'),values,4)

    def test_generated_recipes_reopen_without_new_json_metadata(self):
        choices=[dict(x='@X+2',y='@Y',dx='2*3',dy='4*5'),dict(x='@X',y='@Y',distance='@OD/2',angle='45'),dict(x='@X',y='@Y',pitch='@OD*変数.SCALE'),dict(x='@X',y='@Y',pitch='-10'),dict(x='@X',y='@Y',radius='@OD',angle='90',direction='時計回り',size_mode='直径')]
        for mode,params in zip(MODES,choices):
            with self.subTest(mode=mode):
                x,y=formulas(mode,params);parsed=read_formulas(x,y);self.assertIsNotNone(parsed)
                self.assertEqual(parsed[0],mode)
                original=positions(mode,params,row_values(EXAMPLE,0),4)
                reopened=positions(*parsed,row_values(EXAMPLE,0),4)
                for a,b in zip(original,reopened):
                    for aa,bb in zip(a,b):self.assertAlmostEqual(aa,bb)
        self.assertIsNone(read_formulas('@X','@Y'))

    def test_editor_context_is_first_iteration_and_does_not_change_normal_repeat(self):
        values=row_values(EXAMPLE,0);self.assertEqual(repeat_context(values,('@N','loop.number+1'))['count'],2)
        p=copy.deepcopy(EXAMPLE);x,y=formulas(MODES[2],dict(x='@X',y='@Y',pitch='25'))
        circle=dict(type='CIRCLE',x=x,y=y,r='5');p['blocks']=[dict(p['blocks'][0],commands=[circle])]
        with self.assertRaises(MacroError):compile_project(p,[0])
        _,items=compile_project(p,[0],preview_repeat_counts=('@N',));self.assertEqual(items[0]['coords'],(100,100,5))
        p['blocks'][0]['commands']=[dict(type='REPEAT',count='@N',commands=[circle])]
        _,items=compile_project(p,[0]);self.assertEqual([i['coords'][0] for i in items],[100,125,150,175])
        self.assertEqual(repeat_context(values,('0','1/0'),allow_zero=True)['count'],0)
        with self.assertRaisesRegex(MacroError,'0回'):repeat_context(values,('0',))

    def test_table_references_with_names_and_fixed_rows_survive_reopening(self):
        mode=MODES[4];p=dict(x='[入力表1]@X{1}',y='[入力表1]@Y{1}',radius='[入力表1]@OD',angle='90')
        parsed=read_formulas(*formulas(mode,p));self.assertIsNotNone(parsed)
        self.assertEqual(parsed[1]['x'],p['x']);self.assertEqual(parsed[1]['radius'],p['radius'])
