"""Persistent SELECT identities, union semantics and live entity membership."""
import json,sys,unittest
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
from test_native_operations import command,project
from engine import compile_project,MacroError
from command_points import clone_commands
from range_selection import entities
from test_cad_state import read_form,walk

class SelectCommand(unittest.TestCase):
    sid='p_'+'a'*32
    def selector(self,queries):return dict(type='SELECT',point_id=self.sid,selection_name='外形',pick_tolerance='0.01',selections=queries)
    def line(self):return dict(type='LINE',x1='0',y1='0',x2='20',y2='0')
    def test_points_and_rectangles_union_deduplicates_actual_entities(self):
        queries=[dict(mode='point',x1='10',y1='0'),dict(mode='window',x1='-1',y1='-1',x4='21',y4='1'),dict(mode='window',x1='35',y1='-6',x4='45',y4='6')]
        script,items=compile_project(project([self.line(),dict(type='CIRCLE',x='40',y='0',r='5'),self.selector(queries),command('COPY',selection_ref=self.sid,x2='0',y2='0',x3='0',y3='40')]),[0])
        self.assertEqual(items[2]['selected_count'],2);self.assertEqual(len(items[-1]['children']),2);self.assertIn('(ssadd (ssname part index) selected)',script)
        for line in script.splitlines():
            if line.startswith('('):
                for node in walk(read_form(line)):
                    if node and node[0]=='if':self.assertIn(len(node),(3,4),node)
    def test_same_selection_tracks_rotate_then_scale(self):
        cmds=[self.line(),self.selector([dict(mode='point',x1='10',y1='0')]),command('ROTATE',selection_ref=self.sid,x2='0',y2='0',angle='90'),command('SCALE',selection_ref=self.sid,x2='0',y2='0',factor='2')]
        _,items=compile_project(project(cmds),[0]);self.assertAlmostEqual(items[0]['coords'][3],40);json.dumps(items)
    def test_selected_part_of_continuous_line_tracks_changes(self):
        line=dict(type='LINE',vertices=[dict(x='0',y='0'),dict(x='20',y='0'),dict(x='20',y='20')],x1='0',y1='0',x2='20',y2='20')
        cmds=[line,self.selector([dict(mode='point',x1='10',y1='0')]),command('ROTATE',selection_ref=self.sid,x2='0',y2='0',angle='90'),command('SCALE',selection_ref=self.sid,x2='0',y2='0',factor='2')]
        _,items=compile_project(project(cmds),[0]);self.assertEqual(len(items[0]['segments']),2);self.assertAlmostEqual(items[0]['segments'][0][3],40);json.dumps(items)
    def test_copying_select_and_operation_remaps_stable_id(self):
        selector=self.selector([dict(mode='point',x1='10',y1='0')]);operation=command('COPY',selection_ref=self.sid,x2='0',y2='0',x3='0',y3='50')
        copied=clone_commands([selector,operation]);self.assertNotEqual(copied[0]['point_id'],self.sid);self.assertEqual(copied[1]['selection_ref'],copied[0]['point_id'])
        selector['selection_name']='別の名前';_,items=compile_project(project([self.line(),selector,operation]),[0]);self.assertEqual(len(items[-1]['children']),1)
    def test_previous_selection_and_deleted_members(self):
        p=project([self.line(),self.selector([dict(mode='point',x1='10',y1='0')]),command('MIRROR',selection_ref='@previous',x2='0',y2='0',x3='0',y3='100',erase_source='1'),command('COPY',selection_ref=self.sid,x2='0',y2='0',x3='0',y3='20')])
        with self.assertRaisesRegex(MacroError,'削除'):compile_project(p,[0])
    def test_offset_and_trim_use_named_selection_sets(self):
        cmds=[self.line(),self.selector([dict(mode='point',x1='10',y1='0')]),command('OFFSET',selection_ref=self.sid,x2='10',y2='10',distance='5')]
        script,items=compile_project(project(cmds),[0]);self.assertEqual(items[-1]['children'][0]['coords'],(0.,5.,20.,5.))
        for line in script.splitlines():
            if line.startswith('('):read_form(line)
    def test_empty_or_missing_selection_is_rejected_but_external_geometry_is_allowed(self):
        with self.assertRaises(MacroError):compile_project(project([self.selector([])]),[0])
        with self.assertRaisesRegex(MacroError,'先にSELECT'):compile_project(project([command('COPY',selection_ref=self.sid,x2='0',y2='0',x3='10',y3='0')]),[0])
        _,items=compile_project(project([self.selector([dict(mode='point',x1='500',y1='500')]),command('COPY',selection_ref=self.sid,x2='0',y2='0',x3='10',y3='0')]),[0]);self.assertEqual(items[0]['selected_count'],0)
