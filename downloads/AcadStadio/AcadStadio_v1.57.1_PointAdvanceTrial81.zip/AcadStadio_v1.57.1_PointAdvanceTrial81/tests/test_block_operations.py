"""Split/join preserve emitted geometry, selection IDs and stable point links."""
import copy
import unittest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"src"))
from block_model import new_block
from block_operations import split_block, join_blocks
from command_points import new_id
from engine import compile_project
from sample_project import EXAMPLE


class BlockOperations(unittest.TestCase):
    def project(self):
        project = copy.deepcopy(EXAMPLE)
        point = new_id()
        first = new_block('前半', commands=[dict(type='LINE', point_id=point, x1='0', y1='0', x2='100', y2='0'),
                                          dict(type='CIRCLE', x=f"点('{point}', '終点', 'X')", y='20', r='5')])
        project['blocks'] = [first]
        return project, point

    def geometry(self, project):
        return [(i['type'], i['coords']) for i in compile_project(project, [0])[1]]

    def test_split_local_and_external_links_then_join_roundtrip(self):
        p, point = self.project()
        other = new_block('後続', commands=[dict(type='POINT', x=f"点('{p['blocks'][0]['id']}/{point}', '中点', 'X')", y='0')])
        p['blocks'].append(other)
        original = copy.deepcopy(p)
        split = split_block(p, 0, 1, '後半')
        self.assertEqual(p, original)
        self.assertIn(p['blocks'][0]['id'] + '/', split['blocks'][1]['commands'][0]['x'])
        self.assertEqual(self.geometry(split), self.geometry(p))
        joined = join_blocks(split, [0, 1], '結合')
        self.assertEqual(self.geometry(joined), self.geometry(p))
        self.assertNotIn('/', joined['blocks'][0]['commands'][1]['x'])

    def test_moved_source_rewrites_following_blocks_and_nested_points(self):
        p, point = self.project()
        circle_id = new_id();p['blocks'][0]['commands'][1]['point_id'] = circle_id
        p['blocks'][0]['commands'].append(dict(type='IF', condition='1', commands=[dict(type='POINT', x=f"点('{circle_id}', '右', 'X')", y='0')], **{'else': []}))
        p['blocks'].append(new_block('別ブロック', commands=[dict(type='POINT', x=f"点('{p['blocks'][0]['id']}/{circle_id}', '中心', 'X')", y='0')]))
        split = split_block(p, 0, 1, '後半')
        self.assertIn(split['blocks'][1]['id'], split['blocks'][2]['commands'][0]['x'])
        self.assertEqual(self.geometry(p), self.geometry(split))
        self.assertEqual(self.geometry(p), self.geometry(join_blocks(split, [0, 1, 2], '全部')))

    def test_join_duplicate_point_ids_keeps_both_targets(self):
        p, point = self.project()
        b = new_block('別', commands=[dict(type='LINE', point_id=point, x1='200', y1='0', x2='300', y2='0'),
                                     dict(type='POINT', x=f"点('{point}', '中点', 'X')", y='0')])
        p['blocks'].append(b)
        joined = join_blocks(p, [0, 1], '結合')
        self.assertNotEqual(joined['blocks'][0]['commands'][0]['point_id'], joined['blocks'][0]['commands'][2]['point_id'])
        self.assertEqual(self.geometry(p), self.geometry(joined))

    def test_split_select_and_join_preserve_explicit_selection(self):
        p, _ = self.project();selection = new_id()
        p['blocks'][0]['commands'] += [dict(type='SELECT', point_id=selection, selection_name='線', selections=[dict(mode='point', x1='50', y1='0')], pick_tolerance='0.01'),
                                      dict(type='COPY', selection_ref=selection, x2='0', y2='0', x3='0', y3='100')]
        split = split_block(p, 0, 3, '複写')
        self.assertEqual(self.geometry(p), self.geometry(split))
        self.assertEqual(self.geometry(p), self.geometry(join_blocks(split, [0, 1], '結合')))

    def test_conditions_folders_and_rejected_changes_are_transactional(self):
        p, _ = self.project();p['blocks'][0]['condition'] = '@OD > 0'
        split = split_block(p, 0, 1, '後半')
        self.assertEqual(split['blocks'][0]['condition'], split['blocks'][1]['condition'])
        self.assertEqual(self.geometry(split), self.geometry(p))
        split['blocks'][1]['condition'] = '0';before = copy.deepcopy(split)
        with self.assertRaisesRegex(ValueError, '実行条件'):join_blocks(split, [0, 1], '結合')
        self.assertEqual(before, split)
        with self.assertRaises(ValueError):split_block(p, 0, 0, '不正')
        with self.assertRaises(ValueError):split_block(p, 0, 1, '前半')
        split['blocks'].append(new_block('最後'))
        with self.assertRaisesRegex(ValueError, '連続'):join_blocks(split, [0, 2], '結合')
        p['blocks'][0]['commands'].insert(0, dict(type='SET', name='A', value='10'))
        with self.assertRaisesRegex(ValueError, '変数'):split_block(p, 0, 1, '後半')
