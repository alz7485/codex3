"""Real candidate selection, relation reopening and relative vertex fields."""
import copy
import math
import os
import sys
import unittest
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project


@unittest.skipUnless(sys.platform=='win32' or os.environ.get('DISPLAY'),'GUI display unavailable')
class DerivedPointsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def relation(self,sources,mode,branch):
        def choose():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.choose_command_point('x');self.root.update();panel=win.point_panel
                panel.relation_controls.mode.set(mode);panel.relation_controls.mode.event_generate('<<ComboboxSelected>>');self.root.update()
                panel.axis_picker.set('XY');panel.axis_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                self.assertIn(branch,panel.point_preview.points)
                canvas=panel.point_preview.canvas;sx,sy=canvas.screen_point(panel.point_preview.points[branch])
                canvas.event_generate('<ButtonPress-1>',x=int(sx),y=int(sy));canvas.event_generate('<ButtonRelease-1>',x=int(sx),y=int(sy));self.root.update()
                self.assertEqual(panel.point_picker.get(),branch)
                gui.button(panel,'この点を使用').invoke()
                win.choose_command_point('x');self.root.update();panel=win.point_panel
                self.assertEqual(panel.relation_controls.mode.get(),mode);self.assertEqual(panel.point_picker.get(),branch)
                self.assertEqual(panel.axis_picker.get(),'XY')
                gui.button(panel,'キャンセル').invoke();gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,choose)
        result=edit_command(self.root,dict(type='POINT',x='0',y='0'),self.app.data['blocks'],self.app.data,point_sources=sources)
        self.assertIsNotNone(result)
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=sources+[result])]
        self.assertEqual(self.messages,[])
        return compile_project(p,[0])[1][-1]['coords']

    def test_line_circle_intersection_click_and_reopen(self):
        xy=self.relation([dict(type='LINE',x1='-10',y1='0',x2='10',y2='0'),dict(type='CIRCLE',x='0',y='0',r='5')],'交点','候補B')
        self.assertEqual(xy,(5,0))

    def test_tangent_click_and_reopen(self):
        xy=self.relation([dict(type='CIRCLE',x='0',y='0',r='5'),dict(type='POINT',x='10',y='0')],'接点','候補A')
        self.assertAlmostEqual(xy[0],2.5);self.assertAlmostEqual(xy[1],math.sqrt(18.75))

    def test_relative_vertex_preview_labels_and_saved_values(self):
        command=dict(type='POLYLINE',points='0,0;10,0',vertices=[dict(x='10',y='20'),dict(x='前点.X+100',y='前点.Y'),dict(x='前点.X',y='前点.Y+50')])
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                self.assertIn('110',win.field_results['x2'].cget('text'));self.assertIn('70',win.field_results['y3'].cget('text'))
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,inspect)
        result=edit_command(self.root,command,self.app.data['blocks'],self.app.data)
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[result])]
        self.assertEqual(compile_project(p,[0])[1][0]['coords'],(10,20,110,20,110,70))

    def test_previous_button_inserts_focused_axis_with_one_click(self):
        command=dict(type='POLYLINE',points='10,20;110,20;110,70',vertices=[dict(x='10',y='20'),dict(x='110',y='20'),dict(x='110',y='70')])
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                self.assertNotIn('1',win.previous_point_buttons)
                for key in ('x2','y2'):
                    entry=win.command_entries[key];entry.focus_force();self.root.update()
                    win.previous_point_buttons['2'].invoke();self.root.update()
                    self.assertEqual(entry.get(),'前点.'+key[0].upper())
                    if key=='x2':entry.insert('end',' + 100')
                win.refresh_command_preview();self.root.update()
                self.assertIn('110',win.field_results['x2'].cget('text'))
                self.assertIn('20',win.field_results['y2'].cget('text'))
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(50,inspect)
        result=edit_command(self.root,command,self.app.data['blocks'],self.app.data)
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[result])]
        self.assertEqual(compile_project(p,[0])[1][0]['coords'],(10,20,110,20,110,70))
