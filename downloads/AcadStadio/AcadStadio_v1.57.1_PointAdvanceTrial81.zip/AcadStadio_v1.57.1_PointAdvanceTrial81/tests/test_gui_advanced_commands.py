"""Every added editing operation uses the named SELECT form."""
import os,sys,unittest
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
import test_gui as gui
from macro_editor import edit_command
from test_native_operations import command

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class AdvancedCommandsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_all_six_editing_forms_use_select_and_render_results(self):
        sid='p_'+'c'*32
        for kind in ('ROTATE','ROTATECOPY','ARRAYRECT','EXPLODE','CADBLOCK','SCALE'):
            source=dict(type='POLYLINE',points='0,0;20,0;20,20',closed='0') if kind=='EXPLODE' else dict(type='LINE',x1='0',y1='0',x2='20',y2='0')
            selector=dict(type='SELECT',point_id=sid,selection_name='対象',pick_tolerance='0.01',selections=[dict(mode='point',x1='10',y1='0')])
            def inspect(kind=kind):
                w=gui.top(self.root,'コマンドの設定')
                try:
                    self.assertNotIn('x1',w.command_entries);self.assertTrue(w.selection_ref_picker.winfo_ismapped())
                    if kind=='CADBLOCK':
                        entry=w.command_entries['block_name'];entry.delete(0,'end');entry.insert(0,'検査部品 A')
                    w.refresh_command_preview();self.root.update();self.assertTrue(w.command_preview.canvas.find_withtag('geometry'))
                    gui.button(w,'コマンドを反映').invoke()
                except Exception as exc:self.errors.append(exc);w.destroy()
            self.root.after(160,inspect);result=edit_command(self.root,dict(type=kind,selection_ref=sid),self.app.data['blocks'],self.app.data,point_sources=[source,selector])
            self.assertIsNotNone(result,kind);self.assertEqual(result['selection_ref'],sid)
