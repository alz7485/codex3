"""Previous-vertex expressions remain scoped to one chain and one drawing row."""
import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from engine import compile_project, MacroError
from sample_project import EXAMPLE
from macro_editor import FIELDS


class PreviousVertex(unittest.TestCase):
    def project(self,kind):
        p=copy.deepcopy(EXAMPLE)
        command=dict(type=kind,**dict(FIELDS[kind]));command.update(points='@X,@Y;前点.X+@OD,前点.Y;前点.X,前点.Y+20',
                     vertices=[dict(x='@X',y='@Y'),dict(x='前点.X+@OD',y='前点.Y'),dict(x='前点.X',y='前点.Y+20')])
        if kind=='LEADER':command['text']='注記'
        p['blocks']=[dict(p['blocks'][0],commands=[command])]
        return p
    def test_chain_types_follow_each_row_and_same_previous_for_both_axes(self):
        for kind in ('LINE','POLYLINE','SPLINE','LEADER','HATCH'):
            with self.subTest(kind=kind):
                p=self.project(kind);_,items=compile_project(p,[0,1])
                for index,item in enumerate(items):
                    row=p['input_tables'][0]['rows'][index];x,y,d=map(float,(row['X'],row['Y'],row['OD']))
                    self.assertEqual(item['coords'],(x,y,x+d,y,x+d,y+20))
        p=self.project('LINE');p['blocks'][0]['commands'][0]['vertices'][1]=dict(x='前点.Y+10',y='前点.X+20')
        self.assertEqual(compile_project(p,[0])[1][0]['coords'][2:4],(110,120))
    def test_first_vertex_and_other_commands_cannot_use_stale_previous(self):
        p=self.project('LINE');line=p['blocks'][0]['commands'][0]
        line['vertices'][0]['x']='前点.X'
        with self.assertRaisesRegex(MacroError,'前点.X'):compile_project(p,[0])
        p=self.project('LINE');p['blocks'][0]['commands'].append(dict(type='POINT',x='前点.X',y='0'))
        with self.assertRaisesRegex(MacroError,'前点.X'):compile_project(p,[0])
