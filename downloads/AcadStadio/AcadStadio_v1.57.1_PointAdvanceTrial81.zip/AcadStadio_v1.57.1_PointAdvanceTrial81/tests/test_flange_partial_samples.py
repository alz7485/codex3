"""Partial flange samples remain explicit about missing dimensions."""
import json
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts')]
from build_flange_examples import NAMES, PRESSURES, build
from engine import compile_project
from project_model import validate_project


class FlangePartialSamples(unittest.TestCase):
    def test_every_project_rating_and_face_compiles_without_inferred_bores(self):
        for form in NAMES:
            p=build(form)
            self.assertEqual(validate_project(p),[])
            self.assertEqual([t['name'] for t in p['input_tables']],list(PRESSURES[form]))
            self.assertEqual(p['sample_info']['status'],'未完成')
            for table in p['input_tables']:
                p['active_table']=table['id']
                for index,row in enumerate(table['rows']):
                    with self.subTest(form=form,rating=table['name'],face=row['FACE']):
                        script,items=compile_project(p,[index]);self.assertTrue(items)
                        self.assertIn('CADFLOWRESTORE',script)
                        if row['DETAIL']=='0':
                            self.assertNotIn('ID',row);self.assertNotIn('T',row)
                            self.assertFalse(any(i['block_index']==1 for i in items))
                            self.assertIn('部分図',row['TYPE'])
                        else:
                            self.assertIn((form,table['name']),(('SO','5K'),('BL','20K')))
                            self.assertTrue(any(i['block_index']==1 for i in items))
                            if form=='BL':
                                outline=[i for i in items if i['block_index']==0 and i['layer']=='OUTLINE']
                                self.assertEqual(len(outline),2)  # external circle and RF, no bore
            path=ROOT/'examples'/'JISフランジ'/(form+'_'+NAMES[form]+'.json')
            saved=json.loads(path.read_text(encoding='utf-8'))
            self.assertEqual(saved,build(form))
