"""Circle quadrants are world-axis references, following each row's dimensions."""
import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from command_points import geometry_points, new_id, reference
from engine import compile_project
from sample_project import EXAMPLE


class CircleQuadrants(unittest.TestCase):
    def test_each_quadrant_tracks_center_and_radius_per_row_and_roundtrip(self):
        identity=new_id()
        circle=dict(type='CIRCLE',point_id=identity,x='@X',y='@Y',r='@OD/2')
        points=[dict(type='POINT',x=reference(identity,name,'X')+'+3',y=reference(identity,name,'Y')+'-4')
                for name in ('中心','上','下','左','右')]
        p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=[circle,*points])]
        _,items=compile_project(json.loads(json.dumps(p)),[0,1])
        for offset in (0,6):
            x,y,r=items[offset]['coords'];expected=((x,y),(x,y+r),(x,y-r),(x-r,y),(x+r,y))
            for index,(px,py) in enumerate(expected,1):self.assertEqual(items[offset+index]['coords'],(px+3,py-4))

    def test_diameter_mode_and_world_axis_points_after_transform(self):
        identity=new_id();circle=dict(type='CIRCLE',point_id=identity,x='10',y='20',circle_mode='diameter',diameter='30',r='1')
        p=copy.deepcopy(EXAMPLE);p['blocks']=[dict(p['blocks'][0],commands=[circle,dict(type='POINT',x=reference(identity,'右','X'),y=reference(identity,'右','Y'))])]
        self.assertEqual(compile_project(p,[0])[1][1]['coords'],(25,20))
        from affine_geometry import transform
        # Native geometry remains authoritative even if an old explicit map exists.
        item=dict(type='CIRCLE',coords=(30,40,5),reference_points={'中心':(0,0)})
        self.assertEqual(geometry_points(item)['上'],(30,45))
        moved=transform(item,lambda p:(-2*p[1]+100,2*p[0]+200),scale=2,turn=90)
        self.assertEqual(geometry_points(moved)['上'],(20,270))

    def test_rotation_expressions_xy_offsets_and_reference_reopening(self):
        from command_points import read_point_reference, rewrite_references
        from engine import evaluate, MacroError
        points=geometry_points(dict(type='CIRCLE',coords=(10,20,5)))
        context={'__command_points__':{'c':points},'angle':90}
        self.assertAlmostEqual(evaluate(reference('c','上','X','angle'),context),5)
        self.assertAlmostEqual(evaluate(reference('c','上','Y','angle'),context),20)
        self.assertEqual(evaluate("点位置('c','右',3,-4,90)",context),'13,21')
        self.assertAlmostEqual(evaluate(reference('c','下','X','-90'),context),5)
        for angle in (0,360,-360):self.assertAlmostEqual(evaluate(reference('c','右','X',str(angle)),context),15)
        expr=reference('c','左','X','angle / 2')+' + (@OD/10)'
        parsed=read_point_reference(expr)
        self.assertEqual(parsed['angle'],'angle / 2');self.assertEqual(parsed['offsets'],['@OD/10'])
        combined=read_point_reference("点位置('c','右',@X,変数.SCALE,30)")
        self.assertEqual(combined['angle'],'30');self.assertEqual(combined['offsets'],['@X','変数.SCALE'])
        self.assertIn("'new'",rewrite_references(expr,{'c':'new'}))
        for expr in (reference('c','中心','X','0'),reference('c','上','X',"'text'"),reference('c','上','X','True')):
            with self.assertRaises(MacroError):evaluate(expr,context)

    def test_rotation_follows_table_values_on_each_row(self):
        identity=new_id();p=copy.deepcopy(EXAMPLE)
        circle=dict(type='CIRCLE',point_id=identity,x='@X',y='@Y',r='10')
        point=dict(type='POINT',x=reference(identity,'右','X','@N*90'),y=reference(identity,'右','Y','@N*90'))
        p['blocks']=[dict(p['blocks'][0],commands=[circle,point])]
        _,items=compile_project(p,[0,1])
        import math
        for offset,index in ((0,0),(2,1)):
            row=p['input_tables'][0]['rows'][index];x,y,_=items[offset]['coords'];a=math.radians(float(row['N'])*90)
            self.assertAlmostEqual(items[offset+1]['coords'][0],x+10*math.cos(a))
            self.assertAlmostEqual(items[offset+1]['coords'][1],y+10*math.sin(a))
