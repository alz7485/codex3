"""Real rectangle drag, mode switching, persistence and camera preservation."""
import os,sys,unittest
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
import test_gui as gui
from macro_editor import edit_command
from range_selection import MODES
from test_native_operations import command

@unittest.skipUnless(os.environ.get('DISPLAY'),'GUI display unavailable')
class RangeSelectionGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown
    def test_copy_drag_rectangle_saves_coordinates_and_multiple_results(self):
        prior=[dict(type='LINE',x1='0',y1='0',x2='20',y2='0'),dict(type='CIRCLE',x='20',y='0',r='5')]
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                self.assertTrue(gui.button(w,'プレビューで追加').winfo_ismapped())
                w.selection_mode_picker.set(MODES['window']);w.selection_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                self.assertIn('x4',w.command_entries);w.refresh_command_preview();self.root.update()
                canvas=w.command_preview.canvas;canvas.view_ratio=.6;canvas.fit(preserve=True,preserve_camera=True);self.root.update()
                before=canvas.get_view();a=canvas.screen_point((-6,-6));b=canvas.screen_point((26,6))
                expected_a=canvas.world_point(round(a[0]),round(a[1]));expected_b=canvas.world_point(round(b[0]),round(b[1]))
                gui.button(w,'プレビューで追加').invoke()
                canvas.event_generate('<ButtonPress-1>',x=round(a[0]),y=round(a[1]));canvas.event_generate('<B1-Motion>',x=round(b[0]),y=round(b[1]),state=256);canvas.event_generate('<ButtonRelease-1>',x=round(b[0]),y=round(b[1]));self.root.update()
                self.assertIsNotNone(canvas.range_callback);self.assertEqual(len(canvas.items),2)
                self.assertAlmostEqual(float(w.command_entries['x1'].get()),expected_a[0]);self.assertAlmostEqual(float(w.command_entries['x4'].get()),expected_b[0])
                self.assertEqual(canvas.get_view(),before);self.assertGreaterEqual(len(canvas.find_withtag('range-overlay')),1)
                previous_box=canvas.range_box
                w.select_editor.stop();w.start_range();self.assertIsNotNone(canvas.range_callback)
                canvas.event_generate('<ButtonPress-1>',x=100,y=100);canvas.event_generate('<B1-Motion>',x=150,y=150,state=256);self.root.update()
                self.assertNotEqual(canvas.range_box,previous_box)
                w.focus_force();self.root.update();w.event_generate('<Escape>');self.root.update();self.assertTrue(w.winfo_exists());self.assertIsNone(canvas.range_callback);self.assertEqual(canvas.range_box,previous_box)
                gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(180,inspect);result=edit_command(self.root,dict(type='SELECT',selection_name='範囲選択',x1='10',y1='0'),self.app.data['blocks'],self.app.data,point_sources=prior)
        self.assertIsNotNone(result);self.assertEqual(result['selection_mode'],'window');self.assertIn('x4',result);self.assertEqual(len(result['selections']),1)
    def test_boundary_range_form_and_switch_back_preserve_draft(self):
        def inspect():
            w=gui.top(self.root,'コマンドの設定')
            try:
                w.selection_mode_picker.set(MODES['crossing']);w.selection_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update()
                for key,value in [('x4','250'),('y4','300')]:
                    entry=w.command_entries[key];entry.delete(0,'end');entry.insert(0,value)
                w.selection_mode_picker.set(MODES['point']);w.selection_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update();self.assertNotIn('x4',w.command_entries)
                w.selection_mode_picker.set(MODES['crossing']);w.selection_mode_picker.event_generate('<<ComboboxSelected>>');self.root.update();self.assertEqual(w.command_entries['x4'].get(),'250')
                self.assertTrue(w.command_entries['x1'].reference_button.winfo_ismapped());w.select_editor.add_pending();self.root.update();gui.button(w,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);w.destroy()
        self.root.after(150,inspect);result=edit_command(self.root,dict(type='SELECT',selection_name='境界'),self.app.data['blocks'],self.app.data)
        self.assertIsNotNone(result);self.assertEqual(result['selection_mode'],'crossing')
