"""Reference geometry, finite intersection branches and tangent failures."""
import copy
import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from command_points import geometry_points, reference, new_id, clone_commands
from derived_points import intersection_candidates, tangent_candidates
from engine import compile_project, evaluate, MacroError
from sample_project import EXAMPLE


class DerivedPoints(unittest.TestCase):
    def test_vertices_segment_midpoints_rectangle_and_ellipse(self):
        points=geometry_points(dict(type='POLYLINE',coords=(0,0,10,0,10,20),closed=True))
        self.assertEqual(points['頂点3'],(10,20));self.assertEqual(points['区間2中点'],(10,10));self.assertEqual(points['区間3中点'],(5,10))
        rect=geometry_points(dict(type='RECTANGLE',coords=(20,30,0,0)))
        self.assertEqual(rect['左上'],(0,30));self.assertEqual(rect['右辺中点'],(20,15))
        ellipse=geometry_points(dict(type='ELLIPSE',coords=(10,20,8,3),angle=90))
        self.assertAlmostEqual(ellipse['長軸端点1'][0],10);self.assertAlmostEqual(ellipse['長軸端点1'][1],28)
        self.assertAlmostEqual(ellipse['短軸端点1'][0],7)
        from affine_geometry import transform
        moved=geometry_points(transform(dict(type='RECTANGLE',coords=(0,0,20,30)),lambda p:(-p[1],p[0]),turn=90))
        self.assertEqual(moved['右辺中点'],(-15,20))

    def test_arc_angle_crosses_zero_and_rejects_outside(self):
        identity=new_id();p=copy.deepcopy(EXAMPLE)
        arc=dict(type='ARC',point_id=identity,x='10',y='20',r='5',start_angle='350',end_angle='10')
        point=dict(type='POINT',x=reference(identity,'角度指定点','X','0'),y=reference(identity,'角度指定点','Y','0'))
        p['blocks']=[dict(p['blocks'][0],commands=[arc,point])]
        xy=compile_project(p,[0])[1][1]['coords'];self.assertAlmostEqual(xy[0],15);self.assertAlmostEqual(xy[1],20)
        point['x']=reference(identity,'角度指定点','X','180')
        with self.assertRaisesRegex(MacroError,'範囲外'):compile_project(p,[0])

    def test_intersection_branches_do_not_fallback_and_segments_are_finite(self):
        self.assertEqual(intersection_candidates('LL',(0,0),(10,0),(5,-3),(5,3)),{'候補A':(5,0)})
        self.assertEqual(intersection_candidates('LL',(0,0),(1,0),(5,-3),(5,3)),{})
        both=intersection_candidates('LC',(-10,0),(10,0),(0,0),(5,0))
        self.assertEqual(both,{'候補A':(-5,0),'候補B':(5,0)})
        one=intersection_candidates('LC',(0,0),(10,0),(0,0),(5,0));self.assertNotIn('候補A',one);self.assertIn('候補B',one)
        with self.assertRaisesRegex(MacroError,'成立しません'):evaluate("交点('LC','0,0','10,0','0,0','5,0','候補A','X')",{})
        cc=intersection_candidates('CC',(0,0),(5,0),(6,0),(11,0))
        self.assertEqual(cc,{'候補A':(3,4),'候補B':(3,-4)})
        self.assertEqual(intersection_candidates('CC',(0,0),(5,0),(20,0),(25,0)),{})

    def test_tangents_are_on_circle_and_perpendicular(self):
        candidates=tangent_candidates((0,0),(5,0),(10,0))
        for x,y in candidates.values():
            self.assertAlmostEqual(math.hypot(x,y),5);self.assertAlmostEqual(x*(10-x)+y*(-y),0)
        for p in ((0,0),(2,0),(5,0)):
            with self.assertRaisesRegex(ValueError,'外側'):tangent_candidates((0,0),(5,0),p)

    def test_nested_command_links_clone_remap_and_lost_geometry(self):
        a,b=new_id(),new_id();p=copy.deepcopy(EXAMPLE)
        line=dict(type='LINE',point_id=a,x1='-10',y1='0',x2='10',y2='0')
        circle=dict(type='CIRCLE',point_id=b,x='0',y='0',r='5')
        args=f"'LC',点位置({a!r},'始点'),点位置({a!r},'終点'),点位置({b!r},'中心'),点位置({b!r},'右'),'候補B'"
        point=dict(type='POINT',x=f'交点({args},"X")',y=f'交点({args},"Y")')
        cmds=[line,circle,point];cloned=clone_commands(cmds)
        p['blocks']=[dict(p['blocks'][0],commands=cmds+cloned)]
        _,items=compile_project(p,[0]);self.assertEqual(items[2]['coords'],(5,0));self.assertEqual(items[5]['coords'],(5,0))
        from guide_blocks import point_references
        self.assertEqual(set(point_references(cloned[2])),{cloned[0]['point_id'],cloned[1]['point_id']})
        circle['y']='20'
        with self.assertRaisesRegex(MacroError,'成立しません'):compile_project(p,[0])
