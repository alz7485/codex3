"""Seven native additions: shape results, block definitions and real MTEXT."""
import sys,unittest,math,copy
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'src')]
from test_native_operations import command,project
from engine import compile_project,MacroError
from command_points import reference
from range_selection import entities
from test_cad_state import read_form,walk

class AdvancedCommands(unittest.TestCase):
    def line(self):return dict(type='LINE',x1='0',y1='0',x2='20',y2='0')
    def test_rotate_scale_update_original_and_later_reference(self):
        identity='p_'+'f'*32;line=self.line()|dict(point_id=identity)
        commands=[line,command('ROTATE',x1='10',y1='0',x2='0',y2='0',angle='90'),command('SCALE',x1='0',y1='10',x2='0',y2='0',factor='2'),dict(type='POINT',x=reference(identity,'終点','X'),y=reference(identity,'終点','Y'))]
        _,items=compile_project(project(commands),[0]);self.assertAlmostEqual(items[0]['coords'][3],40);self.assertAlmostEqual(items[-1]['coords'][1],40)
        self.assertEqual(line['x2'],'20')
    def test_rotated_copies_and_array_count_and_positions(self):
        _,items=compile_project(project([self.line(),command('ROTATECOPY',x1='10',y1='0',x2='0',y2='0',angle='90',copy_count='3')]),[0]);self.assertEqual(len(items[-1]['children']),3);self.assertAlmostEqual(items[-1]['children'][0]['coords'][3],20)
        _,items=compile_project(project([self.line(),command('ARRAYRECT',x1='10',y1='0',rows='2',columns='3',column_spacing='50',row_spacing='40')]),[0]);self.assertEqual(len(items[-1]['children']),5);self.assertEqual(items[-1]['children'][-1]['coords'],(100.,40.,120.,40.))
    def test_cad_block_insert_and_explode_known_geometry(self):
        commands=[self.line(),command('CADBLOCK',x1='10',y1='0',x2='0',y2='0',block_name='検査部品 A'),command('INSERT',block_name='検査部品 A',x='100',y='0'),command('EXPLODE',x1='100',y1='0')]
        script,items=compile_project(project(commands),[0]);self.assertTrue(items[0]['operation_deleted']);self.assertEqual(len(items[1]['block_geometry']),1);self.assertTrue(items[2]['operation_deleted']);self.assertEqual(items[3]['children'][0]['coords'],(100.,0.,120.,0.));self.assertIn('vla-CopyObjects',script)
    def test_polyline_explode_and_rotated_block_contents(self):
        _,items=compile_project(project([dict(type='POLYLINE',points='0,0;20,0;20,20',closed='0'),command('EXPLODE',x1='10',y1='0')]),[0]);self.assertEqual(len(items[-1]['children']),2)
        _,items=compile_project(project([self.line(),command('CADBLOCK',x1='10',y1='0',x2='0',y2='0'),command('ROTATE',x1='0',y1='0',x2='0',y2='0',angle='90')]),[0]);self.assertAlmostEqual(items[1]['block_geometry'][0]['coords'][3],20)
    def test_multiline_text_is_native_mtext_and_plain_text_stays_single_line(self):
        text='一行目 {A}\\B\n二行目'
        script,items=compile_project(project([command('MTEXT',text=text,x='0',y='0',width='40')]),[0]);self.assertEqual(items[0]['text'],text);self.assertIn('vla-AddMText',script);self.assertIn('\\\\P',script);self.assertIn('\\\\{A\\\\}',script)
        with self.assertRaises(MacroError):compile_project(project([dict(type='TEXT',x='0',y='0',text='一\n二')]),[0])
    def test_invalid_parameters_and_duplicate_block_names(self):
        for c in [command('ROTATECOPY',copy_count='1.5'),command('ARRAYRECT',rows='1',columns='1'),command('SCALE',factor='0'),command('MTEXT',width='0'),command('CADBLOCK',block_name='bad/name')]:
            with self.subTest(kind=c['type']),self.assertRaises(MacroError):compile_project(project([c]),[0])
        with self.assertRaisesRegex(MacroError,'重複'):compile_project(project([self.line(),command('CADBLOCK',x1='10',y1='0',x2='0',y2='0'),command('CADBLOCK',x1='0',y1='0',x2='0',y2='0')]),[0])
    def test_native_forms_have_valid_if_arity_and_balanced_structure(self):
        for kind in ('ROTATE','ROTATECOPY','ARRAYRECT','EXPLODE','CADBLOCK','SCALE','MTEXT'):
            for mode in ('point','window') if kind!='MTEXT' else ('point',):
                c=command(kind,selection_mode=mode,x4='300',y4='300')
                script,_=compile_project(project([c]),[0])
                for line in script.splitlines():
                    if line.startswith('('):
                        for node in walk(read_form(line)):
                            if node and node[0]=='if':self.assertIn(len(node),(3,4),node)
