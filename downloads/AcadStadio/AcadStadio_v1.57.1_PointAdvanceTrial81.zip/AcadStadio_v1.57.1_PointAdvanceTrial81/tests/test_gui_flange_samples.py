"""Open the four bundled samples through the app's actual file-opening path."""
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
import test_gui as gui


@unittest.skipUnless(sys.platform=='win32' or os.environ.get('DISPLAY'),'GUI display unavailable')
class FlangeSamplesGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_sample_chooser_opens_each_form_and_rating_tables(self):
        folder=Path(__file__).resolve().parents[1]/'examples'/'JISフランジ'
        for path in sorted(folder.glob('*.json')):
            with patch('main.filedialog.askopenfilename',return_value=str(path)) as choose:
                self.assertTrue(self.app.load_flange_sample())
            self.assertEqual(Path(choose.call_args.kwargs['initialdir']),folder)
            self.root.update();self.app.preview(quiet=True)
            self.assertTrue(self.app.canvas.items)
            self.assertEqual(self.app.data['input_tables'][0]['name'],'5K')
            self.assertEqual(self.app.data['sample_info']['status'],'未完成')
            self.assertEqual(len(self.app.data['input_tables']),4 if path.name.startswith('SW') else 5 if path.name.startswith('SO') else 7)
        self.assertEqual(self.messages,[])

    def test_cancel_keeps_current_project(self):
        before=self.app.data
        with patch('main.filedialog.askopenfilename',return_value=''):
            self.assertFalse(self.app.load_flange_sample())
        self.assertIs(self.app.data,before)
