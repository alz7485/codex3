"""Shared coordinate actions follow the explicitly selected input field."""
import os
import sys
import unittest
from unittest.mock import patch
import test_gui as gui
from macro_editor import edit_command

@unittest.skipUnless(sys.platform == 'win32' or os.environ.get('DISPLAY'), 'GUI display unavailable')
class CoordinateToolbarGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_toolbar_switches_target_and_inserts_into_selected_axis(self):
        def interact():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                self.root.update()
                self.assertTrue(win.coordinate_toolbar.winfo_ismapped())
                for key, caption in [('x1', '始点 X'), ('y2', '終点 Y')]:
                    win.coordinate_target_picker.set(caption)
                    win.coordinate_target_picker.event_generate('<<ComboboxSelected>>')
                    self.root.update()
                    button = win.command_entries[key].reference_buttons[0]
                    self.assertTrue(button.winfo_ismapped())
                    with patch('macro_editor.show_table_reference_picker',
                               side_effect=lambda parent, project, apply, **kw: apply('@OD')):
                        button.invoke()
                    self.assertEqual(win.command_entries[key].get(), '@OD')
                self.assertEqual(win.command_entries['x2'].get(), '100')
                win.command_entries['x1'].focus_force();self.root.update()
                self.assertEqual(win.coordinate_target_picker.get(), '始点 X')
                self.assertFalse(win.previous_point_buttons['2'].winfo_ismapped())
                win.command_entries['y2'].focus_force();self.root.update()
                self.assertTrue(win.previous_point_buttons['2'].winfo_ismapped())
            except Exception as exc:
                self.errors.append(exc)
            finally:
                win.destroy()
        self.root.after(50, interact)
        edit_command(self.root, dict(type='LINE', x1='0', y1='0', x2='100', y2='20'),
                     self.app.data['blocks'], self.app.data)
