"""Actual double-click opens only command editor and returns to the source UI."""
import copy
import os
import sys
import types
import unittest
import tkinter as tk
import test_gui as gui
from macro_editor import MacroEditor
from block_model import new_block


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class PreviewEditGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def install(self,overlap=False):
        p=copy.deepcopy(self.app.data)
        commands=[dict(type='CIRCLE',x='50',y='30',r='20')]
        commands.append(dict(commands[0]) if overlap else dict(type='LINE',x1='0',y1='0',x2='100',y2='0'))
        p['blocks']=[new_block('図形',commands=commands)]
        self.app.replace_document(p);self.root.update();self.app.preview(quiet=True);self.root.update()

    def pixel(self,canvas):
        node=next(n for n,i,c in canvas.geometry if i.get('type')=='CIRCLE')
        box=canvas.coords(node);return round(box[2]),round((box[1]+box[3])/2)

    def double(self,canvas):
        x,y=self.pixel(canvas)
        canvas.event_generate('<ButtonPress-1>',x=x,y=y,time=10000)
        canvas.event_generate('<ButtonRelease-1>',x=x,y=y,time=10010)
        canvas.event_generate('<ButtonPress-1>',x=x,y=y,time=10100)
        canvas.event_generate('<ButtonRelease-1>',x=x,y=y,time=10110)
        self.root.update()

    def edit_later(self,radius,*,parent=None,cancel=False):
        def edit():
            win=gui.top(self.root,'コマンドの設定')
            try:
                self.assertIs(win.master,parent or self.root)
                if parent is None:
                    self.assertFalse(any(isinstance(w,tk.Toplevel) and 'ブロック編集' in w.title() for w in gui.descendants(self.root)))
                entry=win.command_entries['r'];entry.delete(0,'end');entry.insert(0,radius)
                gui.button(win,'キャンセル' if cancel else 'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(80,edit)

    def test_main_double_click_save_return_and_project_undo(self):
        self.install();self.app.canvas.view_ratio=1.4;self.app.canvas.pan=[12,8];self.app.canvas.fit(preserve_camera=True)
        view=self.app.canvas.get_view();before=copy.deepcopy(self.app.data)
        self.edit_later('35');self.double(self.app.canvas)
        self.assertEqual(self.app.data['blocks'][0]['commands'][0]['r'],'35')
        self.assertEqual(self.app.canvas.get_view(),view)
        self.assertFalse(any(isinstance(w,tk.Toplevel) and w.winfo_ismapped() and 'コマンド' in w.title() for w in gui.descendants(self.root)))
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,before)
        self.app.redo_project();self.root.update();self.assertEqual(self.app.data['blocks'][0]['commands'][0]['r'],'35')
        self.assertEqual(self.messages,[])

    def test_main_cancel_leaves_data_unchanged(self):
        self.install();before=copy.deepcopy(self.app.data)
        self.edit_later('99',cancel=True);self.double(self.app.canvas)
        self.assertEqual(self.app.data,before);self.assertEqual(self.messages,[])

    def test_block_preview_returns_to_block_and_stages_until_block_apply(self):
        self.install();before=copy.deepcopy(self.app.data)
        ed=MacroEditor(self.root,self.app.data['blocks'][0],self.app.data['blocks'],self.app.refresh,self.app.data,[0])
        ed.list.refresh(0);ed.show_preview([0]);self.root.update()
        self.edit_later('42',parent=ed.win);self.double(ed.preview_canvas)
        self.assertTrue(ed.win.winfo_exists());self.assertEqual(ed.list.commands[0]['r'],'42');self.assertEqual(self.app.data,before)
        ed.list.undo();self.assertEqual(ed.list.commands[0]['r'],'20')
        ed.list.redo();ed.save();self.root.update();self.assertEqual(self.app.data['blocks'][0]['commands'][0]['r'],'42')
        self.assertEqual(self.messages,[])

    def test_overlap_menu_selects_the_intended_command(self):
        self.install(overlap=True);canvas=self.app.canvas;x,y=self.pixel(canvas)
        canvas.edit_on_double_click(types.SimpleNamespace(x=x,y=y,x_root=canvas.winfo_rootx()+x,y_root=canvas.winfo_rooty()+y))
        menu=canvas.edit_source_menu
        index=next(i for i in range(menu.index('end')+1) if 'コマンド2 ' in menu.entrycget(i,'label'))
        menu.unpost();menu.grab_release()
        self.edit_later('33');menu.invoke(index);self.root.update()
        self.assertEqual(self.app.data['blocks'][0]['commands'][0]['r'],'20')
        self.assertEqual(self.app.data['blocks'][0]['commands'][1]['r'],'33');self.assertEqual(self.messages,[])
