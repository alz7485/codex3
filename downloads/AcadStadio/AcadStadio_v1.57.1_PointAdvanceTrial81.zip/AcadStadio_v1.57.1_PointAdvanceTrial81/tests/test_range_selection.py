"""Range semantics, batched geometry, view restoration and entity limits."""
import copy,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from engine import compile_project,MacroError
from range_selection import entities,select_range
from command_points import geometry_points
from test_native_operations import command,project
from test_cad_state import read_form,walk

class RangeSelection(unittest.TestCase):
    def line(self,x=0,y=0,u=20,v=0):return dict(type='LINE',x1=str(x),y1=str(y),x2=str(u),y2=str(v))
    def ranged(self,kind='COPY',**kw):return command(kind,selection_mode='window',x1='-10',y1='-10',x4='30',y4='10',x2='0',y2='0',x3='0',y3='50')|kw
    def test_window_copy_multiple_entities_and_later_individual_copy(self):
        p=project([self.line(),dict(type='CIRCLE',x='20',y='0',r='5'),self.ranged()]);original=copy.deepcopy(p)
        script,items=compile_project(json.loads(json.dumps(p)),[0]);self.assertEqual(p,original)
        self.assertEqual(len(items[-1]['children']),2);self.assertEqual(geometry_points(items[-1]),{})
        flattened=list(entities(items));self.assertEqual(len(flattened),4);self.assertEqual(flattened[-2]['coords'],(0.,50.,20.,50.));self.assertEqual(flattened[-1]['coords'],(20.,50.,5.))
        p['blocks'][0]['commands'].append(command('COPY',x1='10',y1='50',x2='0',y2='0',x3='50',y3='0'))
        _,result=compile_project(p,[0]);self.assertEqual(result[-1]['coords'],(50.,50.,70.,50.))
    def test_crossing_hits_edges_but_not_enclosing_circle(self):
        items=[dict(type='LINE',coords=(-20.,0.,20.,0.)),dict(type='CIRCLE',coords=(0.,0.,100.)),dict(type='CIRCLE',coords=(5.,0.,2.))]
        self.assertEqual(select_range(items,(-1,-1,1,1),'window'),[])
        selected=select_range(items,(-1,-1,6,1),'crossing');self.assertEqual(len(selected),2);self.assertNotIn(items[1],selected)
    def test_mirror_range_erases_only_selected_line_segment(self):
        line=dict(type='LINE',vertices=[dict(x='0',y='0'),dict(x='20',y='0'),dict(x='20',y='20')],x1='0',y1='0',x2='20',y2='20')
        _,items=compile_project(project([line,self.ranged('MIRROR',x1='5',y1='-1',x4='15',y4='1',selection_mode='crossing',x2='0',y2='0',x3='0',y3='100',erase_source='1')]),[0])
        self.assertEqual(items[0]['coords'],(20.,0.,20.,20.));self.assertEqual(len(items[-1]['children']),1)
        self.assertAlmostEqual(items[-1]['children'][0]['coords'][2],-20)
        _,point_items=compile_project(project([line,command('MIRROR',x1='10',y1='0',x2='0',y2='0',x3='0',y3='100',erase_source='1')]),[0])
        self.assertEqual(point_items[0]['coords'],(20.,0.,20.,20.))
    def test_multiple_boundary_extend_and_trim(self):
        source=[self.line(0,0,50,0),self.line(80,-20,80,20),self.line(100,-20,100,20)]
        _,items=compile_project(project(source+[self.ranged('EXTEND',x1='70',y1='-30',x4='110',y4='30',x2='40',y2='0')]),[0]);self.assertEqual(items[0]['coords'],(0.,0.,80.,0.))
        source[0]=self.line(0,0,150,0)
        _,items=compile_project(project(source+[self.ranged('TRIM',x1='70',y1='-30',x4='110',y4='30',x2='90',y2='0')]),[0]);self.assertEqual(len(items[0]['segments']),2)
        for actual,expected in zip(items[0]['segments'],[(0.,0.,80.,0.),(100.,0.,150.,0.)]):
            for a,b in zip(actual,expected):self.assertAlmostEqual(a,b)
    def test_native_window_view_restoration_and_every_created_entity_override(self):
        for kind in ('COPY','MIRROR','EXTEND','TRIM'):
            script,_=compile_project(project([self.ranged(kind,color='2')]),[0])
            for line in script.splitlines():
                if line.startswith('('):
                    form=read_form(line)
                    for node in walk(form):
                        if node and node[0]=='if':self.assertIn(len(node),(3,4),node)
            self.assertIn('"_W"',script);self.assertIn('"_.-VIEW" "_Save"',script);self.assertIn('"_Restore" name',script);self.assertIn('"_Delete" name',script);self.assertIn('Range selection exceeds 1000',script)
            if kind in ('COPY','MIRROR'):self.assertIn('(setq e (entnext before)) (while e',script)
    def test_invalid_modes_degenerate_rectangle_and_limit(self):
        for cmd in [self.ranged(selection_mode='bad'),self.ranged(selection_mode=[]),self.ranged(x4='-10'),self.ranged(x4=None),command('OFFSET',selection_mode='window',x4='5',y4='5')]:
            with self.subTest(cmd=cmd),self.assertRaises(MacroError):compile_project(project([cmd]),[0])
        points=[dict(type='POINT',coords=(0.,0.)) for _ in range(1001)]
        with self.assertRaisesRegex(ValueError,'1000'):select_range(points,(-1,-1,1,1),'window')

    def test_repeated_range_copies_cannot_expand_vertices_without_bound(self):
        poly=dict(type='POLYLINE',points=';'.join(f'{i},{i%2}' for i in range(500)),closed='0')
        repeated=[self.ranged(x1='-100',y1='-100',x4='1000',y4='1000',x2='0',y2='0',x3='0',y3='10') for _ in range(7)]
        with self.assertRaisesRegex(MacroError,'頂点'):compile_project(project([poly]+repeated),[0])
