"""Known inherited values come from actual emitted command state, not CAD defaults."""
import copy
import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from block_model import new_block
from engine import compile_project
from inherited_appearance import inheritance_hint
from sample_project import EXAMPLE


class InheritedAppearance(unittest.TestCase):
    def state(self,commands,row=0):
        p=copy.deepcopy(EXAMPLE);p['blocks']=[new_block('試算',commands=commands)]
        state={};compile_project(p,[row],appearance_out=state)
        return state

    def test_evaluated_layer_color_scale_and_styles_persist(self):
        state=self.state([dict(type='TEXT',x='0',y='0',height='3',angle='0',text='文字',layer='OUTLINE',linetype='CENTER',color='2',linetype_scale='@OD / 100',text_style='TEST_FONT'),
                          dict(type='DIMLINEAR',x1='0',y1='0',x2='10',y2='0',x3='5',y3='10',layer='',dim_style='TEST_DIM')])
        self.assertEqual(state['effective_layer'],'OUTLINE');self.assertEqual(state['text_style'],'TEST_FONT')
        self.assertEqual(state['dim_style'],'TEST_DIM');self.assertEqual(state['color'],2)
        self.assertEqual(state['linetype_scale'],1)
        self.assertEqual(inheritance_hint('layer',state),'OUTLINE（現在値）')
        self.assertTrue(inheritance_hint('color',state).startswith('2'))

    def test_conditions_sysvars_custom_unknown_and_guide_isolation(self):
        state=self.state([dict(type='SYSVAR',name='TEXTSTYLE',value_kind='text',value='FONT_A'),
                          dict(type='SYSVAR',name='DIMSTYLE',value_kind='text',value='DIM_A'),
                          dict(type='CIRCLE',x='0',y='0',r='5',condition='0',layer='SKIPPED')])
        self.assertEqual(state['text_style'],'FONT_A');self.assertEqual(state['dim_style'],'DIM_A')
        self.assertNotIn('effective_layer',state)
        self.assertEqual(inheritance_hint('layer',state),'未取得（現在値）')
        p=copy.deepcopy(EXAMPLE)
        p['blocks']=[dict(new_block('ガイド',commands=[dict(type='LINE',x1='0',y1='0',x2='1',y2='0',layer='GUIDE')]),guide=True),new_block('作図')]
        state={};compile_project(p,[0],appearance_out=state);self.assertNotIn('effective_layer',state)
        p['custom_commands']['opaque']=dict(name='任意',description='',parameters=[],lines=['_.REGEN'],system_variables=['TEXTSTYLE','DIMSTYLE'])
        p['blocks']=[new_block('作図',commands=[dict(type='SYSVAR',name='TEXTSTYLE',value_kind='text',value='FONT_A'),dict(type='SYSVAR',name='DIMSTYLE',value_kind='text',value='DIM_A'),dict(type='CUSTOM',name='opaque',arguments={})])]
        state={};compile_project(p,[0],appearance_out=state)
        self.assertNotIn('text_style',state);self.assertNotIn('dim_style',state)

    def test_row_dependent_values_are_recomputed(self):
        commands=[dict(type='LINE',x1='0',y1='0',x2='10',y2='0',linetype_scale='@OD / 100')]
        self.assertNotEqual(self.state(commands,0)['linetype_scale'],self.state(commands,1)['linetype_scale'])
