"""Create placement formulas through fields and verify real repeat output."""
import copy
import os
import sys
import unittest
import test_gui as gui
from macro_editor import edit_command
from coordinate_formulas import MODES
from engine import compile_project


@unittest.skipUnless(sys.platform=='win32' or os.environ.get('DISPLAY'),'GUI display unavailable')
class CoordinateFormulaGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def test_horizontal_helper_atomic_undo_reopen_and_real_repeat(self):
        def edit():
            win=gui.top(self.root,'コマンドの設定')
            try:
                def fill():
                    dialog=gui.top(self.root,'座標の式を作る')
                    self.assertEqual(dialog.mode.get(),MODES[2]);dialog.params['pitch'].set('25');self.root.update()
                    self.assertEqual(dialog.samples,[(100,100),(125,100),(150,100),(175,100)])
                    self.assertFalse(dialog.generated.winfo_ismapped());gui.button(dialog,'X・Yに反映').invoke()
                self.root.after(60,fill);win.coordinate_formula_buttons[''].invoke();self.root.update()
                self.assertIn('loop.index',win.command_entries['x'].get())
                self.assertIn('横に等間隔',win.reference_summaries[''].cget('text'))
                win.refresh_command_preview();self.root.update();self.assertTrue(win.command_preview.canvas.items)
                win.undo_draft();self.root.update();self.assertEqual(win.command_entries['x'].get(),'@X')
                win.redo_draft();self.root.update();self.assertIn('loop.index',win.command_entries['x'].get())
                def reopen():
                    dialog=gui.top(self.root,'座標の式を作る');self.assertEqual(dialog.params['pitch'].get(),'25');gui.button(dialog,'キャンセル').invoke()
                self.root.after(60,reopen);win.make_coordinate_formula('')
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(70,edit);result=edit_command(self.root,dict(type='CIRCLE',x='@X',y='@Y',r='5'),self.app.data['blocks'],self.app.data,repeat_counts=('@N',))
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[dict(type='REPEAT',count='@N',commands=[result])])]
        self.assertEqual([i['coords'][0] for i in compile_project(p,[0])[1]],[100,125,150,175])

    def test_circle_diameter_clockwise_without_trigonometric_input(self):
        def edit():
            win=gui.top(self.root,'コマンドの設定')
            try:
                def fill():
                    dialog=gui.top(self.root,'座標の式を作る');dialog.mode.set(MODES[4]);dialog.change_mode()
                    for key,value in [('x','0'),('y','0'),('radius','100'),('angle','90')]:dialog.params[key].set(value)
                    dialog.size_mode.set('直径');dialog.direction.set('時計回り');self.root.update()
                    self.assertEqual(len(dialog.samples),4);self.assertAlmostEqual(dialog.samples[1][0],50)
                    gui.button(dialog,'X・Yに反映').invoke()
                self.root.after(60,fill);win.make_coordinate_formula('');gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(70,edit);result=edit_command(self.root,dict(type='CIRCLE',r='5'),self.app.data['blocks'],self.app.data,repeat_counts=('4',))
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[dict(type='REPEAT',count='4',commands=[result])])]
        for actual,expected in zip(compile_project(p,[0])[1],[(0,50),(50,0),(0,-50),(-50,0)]):
            for a,b in zip(actual['coords'][:2],expected):self.assertAlmostEqual(a,b)

    def test_outside_repeat_translation_and_cancel(self):
        def edit():
            win=gui.top(self.root,'コマンドの設定')
            try:
                def cancel():
                    dialog=gui.top(self.root,'座標の式を作る');self.assertEqual(tuple(dialog.mode_picker.cget('values')),MODES[:2]);dialog.params['dx'].set('500');gui.button(dialog,'キャンセル').invoke()
                self.root.after(60,cancel);win.make_coordinate_formula('');self.assertEqual(win.command_entries['x'].get(),'10')
                def fill():
                    dialog=gui.top(self.root,'座標の式を作る');dialog.params['dx'].set('25');dialog.params['dy'].set('-5');gui.button(dialog,'X・Yに反映').invoke()
                self.root.after(60,fill);win.make_coordinate_formula('');gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(70,edit);result=edit_command(self.root,dict(type='POINT',x='10',y='20'),self.app.data['blocks'],self.app.data)
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[result])]
        self.assertEqual(compile_project(p,[0])[1][0]['coords'],(35,15))

    def test_nested_repeat_editor_receives_parent_count(self):
        def edit():
            win=gui.top(self.root,'コマンドの設定')
            try:
                def inspect_branch():
                    branch=gui.top(self.root,'繰り返すコマンド')
                    try:
                        self.assertEqual(branch.command_list.repeat_counts,('@N',))
                        def inspect_child():
                            child=next(w for w in gui.descendants(self.root) if hasattr(w,'command_entries') and 'x' in w.command_entries)
                            try:
                                def fill():
                                    dialog=gui.top(self.root,'座標の式を作る');self.assertEqual(len(dialog.samples),4)
                                    dialog.params['pitch'].set('30');gui.button(dialog,'X・Yに反映').invoke()
                                self.root.after(60,fill);child.make_coordinate_formula('');gui.button(child,'コマンドを反映').invoke()
                            except Exception as exc:self.errors.append(exc);child.destroy()
                        self.root.after(60,inspect_child);branch.command_list.add('CIRCLE')
                        self.assertEqual(len(branch.command_list.commands),1)
                        gui.button(branch,'この階層を確定').invoke()
                    except Exception as exc:self.errors.append(exc);branch.destroy()
                self.root.after(70,inspect_branch);gui.button(win,'繰り返すコマンドを編集').invoke()
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(70,edit);result=edit_command(self.root,dict(type='REPEAT',count='@N',commands=[]),self.app.data['blocks'],self.app.data)
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[result])]
        self.assertEqual([i['coords'][0] for i in compile_project(p,[0])[1]],[100,130,160,190])

    def test_zero_repeat_can_still_configure_formula_without_dividing_by_zero(self):
        def edit():
            win=gui.top(self.root,'コマンドの設定')
            try:
                def fill():
                    dialog=gui.top(self.root,'座標の式を作る');dialog.mode.set(MODES[4]);dialog.change_mode();self.root.update()
                    self.assertEqual(dialog.samples,[]);self.assertIsNotNone(dialog.valid)
                    self.assertIn('0回',dialog.count_label.get());gui.button(dialog,'X・Yに反映').invoke()
                self.root.after(60,fill);win.make_coordinate_formula('');gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(70,edit);result=edit_command(self.root,dict(type='CIRCLE',r='5'),self.app.data['blocks'],self.app.data,repeat_counts=('0',))
        p=copy.deepcopy(self.app.data);p['blocks']=[dict(p['blocks'][0],commands=[dict(type='REPEAT',count='0',commands=[result])])]
        self.assertEqual(compile_project(p,[0])[1],[])
