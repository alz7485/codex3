import os
import sys
import unittest
import test_gui as gui
from project_data import current_table
from block_model import new_block
from link_assistance_ui import LinkAssistanceWindow


@unittest.skipUnless(
    os.environ.get("DISPLAY") or sys.platform == "win32", "GUI display unavailable"
)
class LinkAssistanceGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def prepare(self):
        current_table(self.app.data)["rows"] = [
            {"名称": "基準", "外径": "100"},
            {"名称": "別", "外径": "120"},
        ]
        self.app.data["blocks"] = [
            new_block(
                "作図",
                commands=[
                    dict(type="LINE", x1="0", y1="0", x2="100", y2="0"),
                    dict(type="CIRCLE", x="50", y="0", r="50"),
                    dict(
                        type="DIMLINEAR",
                        x1="0",
                        y1="0",
                        x2="100",
                        y2="0",
                        x3="50",
                        y3="-20",
                    ),
                ],
            )
        ]
        self.app.refresh()
        self.root.update()

    def test_table_apply_updates_ordinary_headers_and_usage_navigation_undo(self):
        self.prepare()
        win = LinkAssistanceWindow(self.app, ("blocks", 0, "commands", 1))
        self.root.update()
        win.field_picker.current(
            next(i for i, f in enumerate(win.target_fields) if f.path == ("r",))
        )
        win.target_changed()
        self.root.update()
        self.assertEqual(len(win.candidates), 1)
        win.candidate_tree.selection_set("0")
        win.candidate_selected()
        self.root.update()
        self.assertFalse(win.apply_button.instate(("disabled",)))
        win.apply()
        self.root.update()
        win.close()
        self.assertIn("🔗1", self.app.table.heading("外径", "text"))
        usage = self.app.show_column_usage(current_table(self.app.data)["id"], "外径")
        self.root.update()
        self.assertEqual(len(usage.addresses), 1)
        usage.locate()
        usage.destroy()
        self.app.undo_project()
        self.root.update()
        self.assertNotIn("🔗", self.app.table.heading("外径", "text"))

    def test_point_mode_candidates_batch_and_fixed_confirmation(self):
        self.prepare()
        win = LinkAssistanceWindow(self.app, ("blocks", 0, "commands", 2))
        self.root.update()
        win.mode.set("コマンドの点")
        win.mode_changed()
        self.root.update()
        self.assertTrue(win.candidates)
        win.candidate_tree.selection_set("0")
        win.candidate_selected()
        self.root.update()
        self.assertTrue(win.batch_check.winfo_ismapped())
        win.batch.set(True)
        win.make_proposal()
        self.assertIsNotNone(win.trial)
        win.apply()
        self.root.update()
        cmd = self.app.data["blocks"][0]["commands"][2]
        self.assertTrue(all("点(" in cmd[k] for k in ("x1", "y1", "x2", "y2")))
        win.detail_tree.selection_set("4")
        win.confirm_fixed()
        self.root.update()
        self.assertTrue(self.app.data["blocks"][0]["commands"][2].get("link_review"))
        win.close()

    def test_small_window_footer_and_modes_do_not_overlap(self):
        self.prepare()
        win = LinkAssistanceWindow(self.app)
        win.geometry("1200x850")
        self.root.update()
        self.assertFalse(win.point_card.winfo_ismapped())
        self.assertTrue(win.table_card.winfo_ismapped())
        self.assertLess(
            win.apply_button.winfo_rooty() + win.apply_button.winfo_height(),
            win.winfo_rooty() + win.winfo_height() + 1,
        )
        win.mode.set("コマンドの点")
        win.mode_changed()
        self.root.update()
        self.assertTrue(win.point_card.winfo_ismapped())
        self.assertFalse(win.table_card.winfo_ismapped())
        win.close()
