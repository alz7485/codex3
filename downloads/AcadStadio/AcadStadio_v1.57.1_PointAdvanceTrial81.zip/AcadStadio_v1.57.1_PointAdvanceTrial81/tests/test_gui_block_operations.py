"""Main-window split/join dialogs apply atomically and participate in project undo."""
import copy
import os
import sys
import unittest
import test_gui as gui
from block_model import new_block
from command_points import new_id
from engine import compile_project


@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','GUI display unavailable')
class BlockOperationsGui(unittest.TestCase):
    setUp=gui.Gui.setUp
    tearDown=gui.Gui.tearDown

    def install(self):
        p=copy.deepcopy(self.app.data);point=new_id()
        p['blocks']=[new_block('元のブロック',commands=[dict(type='LINE',point_id=point,x1='0',y1='0',x2='100',y2='0'),
                  dict(type='POINT',x=f"点('{point}', '中点', 'X')",y='10'),dict(type='CIRCLE',x='150',y='0',r='20')])]
        self.app.replace_document(p);self.root.update();self.app.block_browser.reveal(0)
        return copy.deepcopy(self.app.data)

    def geometry(self):
        return [(i['type'],i['coords']) for i in compile_project(self.app.data,[0])[1]]

    def test_split_join_preserve_drawing_and_undo_redo(self):
        original=self.install();geometry=self.geometry()
        win=self.app.split_selected_block();self.root.update()
        win.command_table.selection_set('1');win.command_table.event_generate('<<TreeviewSelect>>');self.root.update()
        win.new_name.set('後半');win.apply_button.invoke();self.root.update()
        self.assertFalse(win.winfo_exists());self.assertEqual(len(self.app.data['blocks']),2)
        self.assertEqual(self.geometry(),geometry)
        split=copy.deepcopy(self.app.data)
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,original)
        self.app.redo_project();self.root.update();self.assertEqual(self.app.data,split)
        self.app.block_list.selection_set('0','1')
        win=self.app.join_selected_blocks();self.root.update()
        self.assertEqual(str(win.apply_button.cget('state')),'normal')
        win.new_name.set('結合後');win.apply_button.invoke();self.root.update()
        self.assertEqual(len(self.app.data['blocks']),1);self.assertEqual(self.geometry(),geometry)
        self.assertEqual(self.app.data['blocks'][0]['name'],'結合後')
        self.app.undo_project();self.root.update();self.assertEqual(self.app.data,split)
        self.assertEqual(self.messages,[])

    def test_invalid_selection_cancel_and_menu_access(self):
        original=self.install()
        labels=[self.app.block_auxiliary_menu.entrycget(i,'label') for i in range(self.app.block_auxiliary_menu.index('end')+1) if self.app.block_auxiliary_menu.type(i) not in ('separator','tearoff')]
        self.assertIn('ブロックを分割…',labels);self.assertIn('ブロックを結合…',labels)
        win=self.app.split_selected_block();win.command_table.selection_set('0');win.command_table.event_generate('<<TreeviewSelect>>');self.root.update()
        self.assertEqual(str(win.apply_button.cget('state')),'disabled')
        gui.button(win,'キャンセル').invoke();self.assertEqual(self.app.data,original)
        self.app.data['blocks'] += [new_block('2'),new_block('3')];self.app.refresh();self.root.update()
        win=self.app.join_selected_blocks();win.block_table.selection_set('0','2');win.block_table.event_generate('<<TreeviewSelect>>');self.root.update()
        self.assertEqual(str(win.apply_button.cget('state')),'disabled')
        before=copy.deepcopy(self.app.data);gui.button(win,'キャンセル').invoke();self.assertEqual(self.app.data,before)
