# Optional Windows build: pyinstaller --clean --noconfirm AcadStadio.spec
# Build on Windows; cross-compilation from Linux is not supported.
from pathlib import Path
base=Path(SPECPATH)
a=Analysis([str(base/'AcadStadio.pyw')],pathex=[str(base/'src')],
           binaries=[],datas=[(str(base/'assets'),'assets'),(str(base/'docs'),'docs'),(str(base/'examples'),'examples')],
           hiddenimports=['openpyxl','ezdxf','ezdxf.addons','ezdxf.math'],hookspath=[],hooksconfig={},runtime_hooks=[],excludes=[],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='AcadStadio',debug=False,
        bootloader_ignore_signals=False,strip=False,upx=False,console=False,
        icon=str(base/'assets'/'acadstadio.ico'))
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='AcadStadio')
