"""Build a public synthetic DXF and the expected AcadStadio import artifacts."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import json
import ezdxf
from ezdxf.enums import TextEntityAlignment
from cad_drawing_import import read_cad_drawing, imported_project
from engine import compile_project


def build_document():
    doc=ezdxf.new('R2013');doc.header['$INSUNITS']=4;doc.header['$LTSCALE']=2.5
    doc.layers.new('PARTS',dxfattribs={'color':3,'lineweight':25})
    doc.layers.new('ANNOTATION',dxfattribs={'color':2,'plot':1})
    doc.linetypes.new('IMPORTED_DASH',dxfattribs={'description':'simple dash','pattern':[12,8,-4]})
    doc.layers.new('AXIS',dxfattribs={'color':1,'linetype':'IMPORTED_DASH','plot':0})
    doc.styles.new('Import Text',dxfattribs={'font':'arial.ttf','width':0.9,'oblique':5})
    doc.dimstyles.new('Import Dim',dxfattribs={'dimtxt':3.5,'dimasz':2.5,'dimscale':2,'dimtxsty':'Import Text'})
    m=doc.modelspace();style={'layer':'PARTS'}
    m.add_line((0,0),(100,0),dxfattribs=style)
    m.add_circle((50,50),20,dxfattribs=style)
    m.add_arc((0,0),10,10,160,dxfattribs=style)
    m.add_ellipse((120,50),major_axis=(30,15),ratio=0.5,dxfattribs=style)
    m.add_lwpolyline([(0,0),(20,10),(40,0)],close=True,dxfattribs=style)
    m.add_lwpolyline([(0,-20,1),(40,-20,0)],format='xyb',dxfattribs=style)
    m.add_point((12,15),dxfattribs=style)
    m.add_text('部品 @OD',dxfattribs={'height':4,'style':'Import Text','layer':'ANNOTATION'}).set_placement((50,85),align=TextEntityAlignment.MIDDLE_CENTER)
    m.add_mtext('1行目\\P2行目',dxfattribs={'insert':(140,90),'char_height':4,'width':60,'style':'Import Text','attachment_point':5,'rotation':15,'layer':'ANNOTATION'})
    block=doc.blocks.new('SMALL_PART');block.add_line((0,0),(10,0),dxfattribs={'color':0});block.add_circle((5,5),2,dxfattribs={'color':0})
    m.add_blockref('SMALL_PART',(200,0),dxfattribs={'rotation':30,'xscale':2,'yscale':2,'layer':'PARTS','color':4})
    for make in [lambda:m.add_linear_dim(base=(0,30),p1=(0,0),p2=(100,0),dimstyle='Import Dim'),
                 lambda:m.add_aligned_dim(p1=(0,0),p2=(40,30),distance=15,dimstyle='Import Dim'),
                 lambda:m.add_radius_dim(center=(50,50),radius=20,angle=45,dimstyle='Import Dim'),
                 lambda:m.add_diameter_dim(center=(120,50),radius=15,angle=45,dimstyle='Import Dim')]:
        make().render()
    hatch=m.add_hatch(color=5);hatch.paths.add_polyline_path([(170,20),(190,20),(190,40),(170,40)],is_closed=True)
    # Deliberate unsupported items, to verify the report does not silently omit them.
    m.add_line((0,0,5),(10,0,5))
    m.add_spline(fit_points=[(0,0),(10,10),(20,0)])
    return doc


def main():
    root=Path(__file__).resolve().parents[1]/'examples'/'CAD読込サンプル';root.mkdir(exist_ok=True)
    path=root/'CAD_import_example.dxf';build_document().saveas(path)
    result=read_cad_drawing(path);result['source']=path.name;project=imported_project(result)
    (root/'import_snapshot.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (root/'project.json').write_text(json.dumps(project,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (root/'import_report.json').write_text(json.dumps({'counts':result['counts'],'issues':result['issues']},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    script,items=compile_project(project,[0]);(root/'output.scr').write_text(script,encoding='utf-8')
    print(result['counts']);print(result['issues']);print('Preview figures:',len(items))

if __name__=='__main__':main()
