"""Rebuild editable JIS fitting projects and first-row SCR examples."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from engine import compile_project
from piping_samples import BUILDERS, build_piping_sample
from sample_project import EXAMPLE


def main():
    output = ROOT / 'examples'
    for family in [None, *BUILDERS]:
        project = build_piping_sample(EXAMPLE, [family] if family else None)
        stem = 'jis_' + (family or 'piping')
        (output / (stem + '_project.json')).write_text(
            json.dumps(project, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        if family:
            script, _ = compile_project(project, [0])
            # SCR is intended for Windows AutoCAD, UTF-8 with Windows newlines.
            (output / (stem + '_output.scr')).write_bytes(script.replace('\r\n', '\n').replace('\n', '\r\n').encode('utf-8'))
        print(stem, {t['name']: len(t['rows']) for t in project['input_tables']})


if __name__ == '__main__':
    main()
