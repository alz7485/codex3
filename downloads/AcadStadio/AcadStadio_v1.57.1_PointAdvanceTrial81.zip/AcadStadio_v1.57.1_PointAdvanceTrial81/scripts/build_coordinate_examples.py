"""Regenerate examples created by the plain-language placement recipes."""
import copy
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from sample_project import EXAMPLE
from coordinate_formulas import MODES,formulas
from engine import compile_project


def main():
    p=copy.deepcopy(EXAMPLE)
    rows=[dict(TYPE='4個の配置',X='100',Y='100',N='4',間隔='30',配置円直径='100'),dict(TYPE='6個の配置',X='100',Y='300',N='6',間隔='30',配置円直径='100')]
    p['input_tables']=[dict(id='placement_inputs',name='配置の入力値',rows=rows)];p['active_table']='placement_inputs'
    p['drawing']={'targets':{'placement_inputs':dict(mode='selected',range='',selected=[0])}}
    p['blocks']=[]
    choices=[(MODES[2],dict(x='@X',y='@Y',pitch='@間隔')),(MODES[3],dict(x='@X+180',y='@Y',pitch='@間隔')),(MODES[4],dict(x='@X+400',y='@Y+50',radius='@配置円直径',angle='90',direction='時計回り',size_mode='直径'))]
    for index,(mode,params) in enumerate(choices):
        x,y=formulas(mode,params)
        commands=[]
        if mode==MODES[4]:commands.append(dict(type='CIRCLE',layer='CENTER',linetype='CENTER',x=params['x'],y=params['y'],r='@配置円直径/2',circle_mode='diameter',diameter='@配置円直径'))
        commands.append(dict(type='REPEAT',count='@N',commands=[dict(type='CIRCLE',layer='OUTLINE',x=x,y=y,r='5')]))
        p['blocks'].append(dict(id='placement_'+str(index),name=mode,condition='',commands=commands))
    script,items=compile_project(p,[0]);assert len(items)==13
    output=ROOT/'examples'
    (output/'coordinate_placement_project.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (output/'coordinate_placement_output.scr').write_bytes(script.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
    print('Three editable placement recipes, 13 figures in first row')


if __name__=='__main__':main()
