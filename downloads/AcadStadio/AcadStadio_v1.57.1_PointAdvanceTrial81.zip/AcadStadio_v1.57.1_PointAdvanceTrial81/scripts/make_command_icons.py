"""Build bundled 20px command glyphs. Pillow is only needed to rebuild assets."""
import math
from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'assets'/'commands'
S=5;INK='#3568a6';MUTED='#9aacc2'

def build(kind):
    image=Image.new('RGBA',(20*S,20*S));draw=ImageDraw.Draw(image)
    def line(points,fill=INK,width=1.35):
        draw.line([(round(x*S),round(y*S)) for x,y in points],fill=fill,width=round(width*S),joint='curve')
    def box(bounds,fill=INK):
        x,y,u,v=bounds;line([(x,y),(u,y),(u,v),(x,v),(x,y)],fill)
    def ellipse(bounds,fill=INK):draw.ellipse(tuple(round(v*S) for v in bounds),outline=fill,width=round(1.35*S))
    def dot(x,y):draw.ellipse(((x-1.3)*S,(y-1.3)*S,(x+1.3)*S,(y+1.3)*S),fill=INK)
    def arrow(a,b,fill=INK):
        line([a,b],fill);t=math.atan2(b[1]-a[1],b[0]-a[0]);length=3
        line([(b[0]-length*math.cos(t-.55),b[1]-length*math.sin(t-.55)),b,(b[0]-length*math.cos(t+.55),b[1]-length*math.sin(t+.55))],fill)
    def arc(center,r,start,end):
        points=[(center[0]+r*math.cos(math.radians(start+(end-start)*i/40)),center[1]+r*math.sin(math.radians(start+(end-start)*i/40))) for i in range(41)]
        line(points);arrow(points[-5],points[-1])
    if kind=='LINE':line([(3,16),(17,4)]);dot(3,16);dot(17,4)
    elif kind=='POLYLINE':
        points=[(2,16),(7,5),(12,14),(18,3)];line(points)
        for x,y in points:dot(x,y)
    elif kind=='CIRCLE':ellipse((3,3,17,17))
    elif kind=='ARC':
        points=[(10+7*math.cos(t*math.pi/40),12-7*math.sin(t*math.pi/40)) for t in range(41)];line(points);dot(*points[0]);dot(*points[-1])
    elif kind=='ELLIPSE':ellipse((2,5,18,15))
    elif kind=='RECTANGLE':box((3,4,17,16))
    elif kind=='POINT':line([(10,3),(10,17)]);line([(3,10),(17,10)]);ellipse((7,7,13,13))
    elif kind=='SPLINE':
        points=[]
        for i in range(61):
            t=i/60;points.append((2+16*t,10+6*math.sin(2*math.pi*t)))
        line(points);dot(2,10);dot(18,10)
    elif kind=='HATCH':
        box((3,3,17,17))
        for offset in (-8,-3,2,7,12):
            a=max(3,3+offset);b=min(17,17+offset)
            if a<b:line([(a,17-max(0,-offset)),(b,3+max(0,offset))],width=.85)
    elif kind=='SELECT':
        for a,b in [((2,6),(2,2)),((2,2),(7,2)),((10,2),(16,2)),((17,2),(17,7)),((2,10),(2,16)),((2,17),(7,17))]:line([a,b],width=1)
        line([(9,7),(10,17),(12,14),(15,18),(17,17),(14,13),(18,12),(9,7)])
    elif kind=='OFFSET':line([(3,4),(17,4)]);line([(3,15),(17,15)]);arrow((10,6),(10,13))
    elif kind=='TRIM':
        line([(11,2),(11,18)],MUTED);line([(2,10),(11,10)])
        for x in (13,17):line([(x,10),(x+1,10)],MUTED)
        line([(5,4),(8,7)]);line([(8,4),(5,7)])
    elif kind=='EXTEND':line([(17,2),(17,18)],MUTED);line([(2,10),(8,10)]);arrow((8,10),(17,10))
    elif kind in ('CHAMFER','FILLET'):
        line([(3,11),(3,17),(9,17)],MUTED,width=.8)
        line([(3,3),(3,11)]);line([(9,17),(17,17)])
        if kind=='CHAMFER':line([(3,11),(9,17)])
        else:line([(9+6*math.cos(math.radians(180-i*90/40)),11+6*math.sin(math.radians(180-i*90/40))) for i in range(41)])
    elif kind=='COPY':box((2,2,12,12),MUTED);box((7,7,17,17));arrow((3,17),(6,17))
    elif kind=='MIRROR':
        for y in (2,7,12,17):line([(10,y),(10,y+2)],MUTED,width=1)
        line([(2,15),(7,5),(7,15),(2,15)]);line([(18,15),(13,5),(13,15),(18,15)])
    elif kind in ('ROTATE','ROTATECOPY'):
        arc((10,10),7,190,350)
        if kind=='ROTATECOPY':box((3,11,8,16),MUTED)
        line([(11,9),(17,12),(14,18),(8,15),(11,9)])
        if kind=='ROTATE':dot(6,14)
    elif kind=='ARRAYRECT':
        for y in (4,12):
            for x in (2,8,14):box((x,y,x+4,y+4))
    elif kind=='INSERT':box((8,8,18,18));arrow((2,2),(12,12))
    elif kind=='CADBLOCK':
        line([(3,6),(10,2),(17,6),(17,14),(10,18),(3,14),(3,6),(10,10),(17,6)])
        line([(10,10),(10,18)])
    elif kind=='EXPLODE':
        line([(2,7),(2,2),(7,2)]);line([(13,2),(18,2),(18,7)]);line([(2,13),(2,18),(7,18)]);line([(13,18),(18,18),(18,13)])
        arrow((10,10),(5,5));arrow((10,10),(15,15))
    elif kind=='SCALE':box((2,10,10,18),MUTED);box((7,2,18,13));arrow((7,13),(17,3))
    elif kind=='TEXT':line([(3,4),(17,4)]);line([(10,4),(10,17)]);line([(7,17),(13,17)])
    elif kind=='MTEXT':
        box((3,2,17,18));line([(6,5),(14,5)])
        for y in (9,12,15):line([(6,y),(14 if y!=15 else 11,y)],width=1)
    elif kind=='LEADER':arrow((9,14),(2,18));line([(9,14),(9,7),(18,7)]);line([(12,3),(18,3)]);line([(12,5),(16,5)],width=.8)
    elif kind in ('DIMLINEAR','DIMALIGNED'):
        if kind=='DIMLINEAR':
            line([(3,3),(3,17)],MUTED);line([(17,3),(17,17)],MUTED);arrow((10,7),(3,7));arrow((10,7),(17,7));line([(3,15),(17,15)],MUTED)
        else:
            line([(3,13),(7,17)],MUTED);line([(13,3),(17,7)],MUTED);arrow((10,10),(4,16));arrow((10,10),(16,4))
    elif kind in ('DIMRADIUS','DIMDIAMETER'):
        ellipse((3,3,17,17));dot(10,10);arrow((10,10),(15,5))
        if kind=='DIMDIAMETER':arrow((10,10),(5,15))
    elif kind=='IF':line([(10,2),(16,7),(10,12),(4,7),(10,2)]);line([(4,7),(2,7),(2,17),(7,17)]);arrow((16,7),(18,7));line([(18,7),(18,17),(13,17)])
    elif kind=='REPEAT':arc((10,10),7,30,190);arc((10,10),7,210,370)
    elif kind=='SYSVAR':
        for x,y in [(4,7),(10,13),(16,6)]:line([(x,2),(x,18)],MUTED);box((x-2,y-2,x+2,y+2))
    elif kind=='CUSTOM':box((2,3,18,17));line([(5,7),(8,10),(5,13)]);line([(11,13),(15,13)])
    else:raise ValueError(kind)
    return image.resize((20,20),Image.Resampling.LANCZOS)

if __name__=='__main__':
    import sys
    sys.path.insert(0,str(ROOT/'src'))
    from command_types import COMMAND_GROUPS
    DEST.mkdir(exist_ok=True)
    for _,kinds in COMMAND_GROUPS:
        for kind in kinds:build(kind).save(DEST/(kind.lower()+'.png'))
    print('Built',sum(len(kinds) for _,kinds in COMMAND_GROUPS),'command icons')
