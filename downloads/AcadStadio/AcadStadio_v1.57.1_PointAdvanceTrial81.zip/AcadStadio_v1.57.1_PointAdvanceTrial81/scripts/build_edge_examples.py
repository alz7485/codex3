"""Rebuild editable examples for chamfer and fillet of two LINE entities."""
import copy
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from sample_project import EXAMPLE
from macro_editor import FIELDS
from engine import compile_project


def main():
    p=copy.deepcopy(EXAMPLE)
    rows=[dict(TYPE='面取り10×20・角丸めR15',X='100',Y='100',D1='10',D2='20',R='15'),dict(TYPE='面取り20×20・角丸めR25',X='100',Y='260',D1='20',D2='20',R='25')]
    p['input_tables']=[dict(id='corner_dimensions',name='面取り・角丸め',rows=rows)];p['active_table']='corner_dimensions'
    p['drawing']={'targets':{'corner_dimensions':dict(mode='selected',range='',selected=[0])}}
    p['blocks']=[]
    for kind,x in [('CHAMFER','@X'),('FILLET','@X+180')]:
        commands=[dict(type='LINE',layer='OUTLINE',x1=x,y1='@Y',x2=f'({x})+100',y2='@Y'),dict(type='LINE',layer='OUTLINE',x1=x,y1='@Y',x2=x,y2='@Y+100')]
        treatment=dict(type=kind,**dict(FIELDS[kind]));treatment.update(layer='OUTLINE',x1=f'({x})+50',y1='@Y',x2=x,y2='@Y+50')
        treatment.update({'distance1':'@D1','distance2':'@D2'} if kind=='CHAMFER' else {'radius':'@R'})
        commands.append(treatment);p['blocks'].append(dict(id=kind.lower()+'_example',name='面取り' if kind=='CHAMFER' else '角丸め',condition='',commands=commands))
    script,items=compile_project(p,[0]);assert len(items)==6
    output=ROOT/'examples'
    (output/'edge_treatment_project.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (output/'edge_treatment_output.scr').write_bytes(script.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
    print('Chamfer and fillet example generated')


if __name__=='__main__':main()
