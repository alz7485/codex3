"""Build four partial flange projects from explicitly sourced dimensions.

No generic pipe OD is used as a flange bore, and no common thickness is
silently used for BL, WN or SW. Only verified detail examples draw sections.
"""
import copy
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from engine import compile_project
from flange_sample import appearance, line
from sample_project import EXAMPLE

NAMES = {'WN': '突合せ溶接形', 'SW': 'ソケット溶接形', 'SO': 'スリップオン形', 'BL': '閉止形'}
PRESSURES = {'WN': ('5K','10K','16K','20K','30K','40K','63K'),
             'SW': ('5K','10K','16K','20K'),
             'SO': ('5K','10K','16K','20K','30K'),
             'BL': ('5K','10K','16K','20K','30K','40K','63K')}


def circle(radius, layer='OUTLINE', x='@X', y='@Y'):
    return dict(type='CIRCLE', layer=layer, x=x, y=y, r=radius, **appearance(layer))


def condition(test, yes, no=()):
    return dict(type='IF', condition=test, commands=yes, **{'else': list(no)})


def commands():
    plan = [circle('@D/2'), condition('@DETAIL == 1 and @FORM != "BL"', [circle('@ID/2')]),
            condition('@FACE == "RF"', [circle('@G/2')]), circle('@PCD/2','CENTER'),
            line('@X-@D/2-8','@Y','@X+@D/2+8','@Y'),
            line('@X','@Y-@D/2-8','@X','@Y+@D/2+8'),
            dict(type='REPEAT',count='@N',commands=[circle('@HOLE_D/2','HOLES',
                 '@X+@PCD/2*sin(radians(360*loop.index/@N))',
                 '@Y+@PCD/2*cos(radians(360*loop.index/@N))')])]
    rear='@X-@D/2-settings.VIEW_GAP-@T'
    nose='@X-@D/2-settings.VIEW_GAP'
    shoulder=f'({nose})-@F'
    ff=[(rear,'@Y-@D/2'),(nose,'@Y-@D/2'),(nose,'@Y+@D/2'),(rear,'@Y+@D/2')]
    rf=[(rear,'@Y-@D/2'),(shoulder,'@Y-@D/2'),(shoulder,'@Y-@G/2'),(nose,'@Y-@G/2'),
        (nose,'@Y+@G/2'),(shoulder,'@Y+@G/2'),(shoulder,'@Y+@D/2'),(rear,'@Y+@D/2')]
    def profile(points):
        return [line(*a,*b,'OUTLINE') for a,b in zip(points,points[1:]+points[:1])]
    section=[condition('@FACE == "RF"',profile(rf),profile(ff)),
             condition('@FORM != "BL"',[line(rear,'@Y-@ID/2',nose,'@Y-@ID/2','HOLES'),
                                       line(rear,'@Y+@ID/2',nose,'@Y+@ID/2','HOLES')])]
    for sign in ('-','+'):
        for edge in ('-','+'):
            y=f'@Y{sign}@PCD/2{edge}@HOLE_D/2'
            section.append(condition('@FACE == "RF"',[line(rear,y,shoulder,y,'HOLES')],[line(rear,y,nose,y,'HOLES')]))
    section.append(line(f'({rear})-8','@Y',f'({nose})+8','@Y'))
    note=dict(type='MTEXT',layer='DIM',x='@X-@D/2',y='@Y-@D/2-15',height='4',width='260',angle='0',
              text="=@TYPE+'\\n'+@STATUS",**appearance('DIM'))
    return [dict(id='jis_flange_plan',name='平面図・確認済みの外周／穴',condition='',commands=plan),
            dict(id='jis_flange_section',name='断面図・詳細確認済みの行のみ',condition='@DETAIL == 1',commands=section),
            dict(id='jis_flange_note',name='収録範囲の注記',condition='',commands=[note])]


def build(form):
    catalog=json.loads((ROOT/'assets'/'jis_flange_partial_dimensions.json').read_text(encoding='utf-8'))
    p=copy.deepcopy(EXAMPLE)
    p['globals']={'SCALE':'1'}
    p['settings'].update(TEXT_HEIGHT='4',VIEW_GAP='35')
    p['input_tables']=[];p['drawing']={'targets':{}}
    for pressure in PRESSURES[form]:
        rows=[]
        for raw in catalog['rows']:
            if raw['PRESSURE'] != pressure:continue
            if raw['FACE']=='RF' and not (form=='WN' or pressure in ('20K','30K','40K','63K')):continue
            data={k:str(v) for k,v in raw.items() if k in ('PRESSURE','FACE','A','D','PCD','N','HOLE_D','BOLT','SOURCE_LINE')}
            data.update(FORM=('SOP' if pressure in ('5K','10K') else 'SOH') if form=='SO' else form,
                        X='180',Y='150',G=str(raw.get('G',0)),F=str(raw.get('F',0)),DETAIL='0')
            detail = form=='SO' and pressure=='5K' or form=='BL' and pressure=='20K'
            if detail:
                data.update(DETAIL='1',T='14' if form=='SO' else '18',ID='61.1' if form=='SO' else '0')
            data['STATUS']=('平面・断面の寸法確認済み' if detail else
                            '部分図：外周・ボルト穴のみ。内径・ハブ・断面は未収録' if form!='BL' else
                            '部分図：平面のみ。閉止用厚さ・断面は未収録')
            rows.append(dict(TYPE=f'{data["FORM"]} {pressure} {data["FACE"]} 50A'+('' if detail else '［部分図］'),**data))
        tid='rating_'+pressure
        p['input_tables'].append(dict(id=tid,name=pressure,rows=rows))
        p['drawing']['targets'][tid]=dict(mode='selected',range='',selected=[0])
    p['active_table']='rating_5K';p['blocks']=commands()
    p['sample_info']=dict(title=f'{form}｜{NAMES[form]}・部分サンプル',status='未完成',
        nominal_sizes='50Aのみ',sources=catalog['sources'],
        scope='形式別プロジェクト・レーティング別入力表。10K薄形は未収録。部分図は内径・ハブ・ソケット・断面を描かない。未収録値を0として推定しない。')
    return p


def main():
    output=ROOT/'examples'/'JISフランジ';output.mkdir(exist_ok=True)
    for form in NAMES:
        project=build(form)
        name=f'{form}_{NAMES[form]}'
        (output/(name+'.json')).write_text(json.dumps(project,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        script,_=compile_project(project,[0])
        (output/(name+'_5K_50A.scr')).write_bytes(script.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
        print(form,[(t['name'],len(t['rows'])) for t in project['input_tables']])


if __name__=='__main__':
    main()
