"""Small, inline readout used only while choosing a command reference point."""
from tkinter import ttk


class InlinePointResult(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        ttk.Label(self, text='取得値', width=7).pack(side='left')
        self.rows = {}
        self.values = {}
        for axis in ('X', 'Y'):
            row = ttk.Frame(self)
            ttk.Label(row, text=axis + ' =').pack(side='left')
            value = ttk.Label(row, text='—', style='PointResultValue.TLabel')
            value.pack(side='left', padx=(4, 12))
            self.rows[axis] = row
            self.values[axis] = value
        self.note = ttk.Label(self, style='Muted.TLabel', wraplength=380)

    def update_values(self, origin, result, axis, status=''):
        for name, row in self.rows.items():
            row.pack_forget()
            if axis in ('XY', name):
                row.pack(side='left')
                self.values[name].configure(text=f'{result[0 if name == "X" else 1]:.12g}' if result else '—')
        self.note.pack_forget()
        if not origin or not result:
            self.note.configure(text=status)
            self.note.pack(side='bottom', fill='x')
