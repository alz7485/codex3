"""Read model-space CAD entities into explicit numerical drawing commands.

No inference of table columns or point relationships is performed. Unsupported
entities and unrepresentable attributes are reported, never silently guessed.
"""
import copy
import math
import tempfile
from pathlib import Path
from block_model import new_block
from command_points import new_id
from cad_setup import default_setup, cad_name, validate_setup
from dwg_resources import DWGImportError, inspect_dwg

GROUPS = ('作図', '寸法', 'テキスト')
MAX_COMMANDS = 10000


class DrawingImportError(ValueError):
    pass


def number(value):
    value = float(value)
    if not math.isfinite(value) or abs(value) > 1e9:
        raise ValueError('数値が対応範囲外です')
    return format(0.0 if value == 0 else value, '.15g')


def xy(point):
    point = tuple(point)
    if len(point) > 2 and abs(float(point[2])) > 1e-8:
        raise ValueError('Z座標が0以外の3D図形は未対応です')
    return number(point[0]), number(point[1])


def point_fields(point, suffix=''):
    x, y = xy(point)
    return {'x'+suffix: x, 'y'+suffix: y}


def _load_dxf(path, settings):
    if Path(path).stat().st_size>64*1024*1024:
        raise DrawingImportError('展開後のDXFは64MiBまでです。対象を小さくして読み込んでください。')
    try:
        import ezdxf
    except ImportError as exc:
        raise DrawingImportError('DXF読込にはezdxfが必要です。requirements.txtの依存パッケージをインストールしてください。') from exc
    try:
        document = ezdxf.readfile(path)
    except (OSError, ezdxf.DXFError, UnicodeError) as exc:
        raise DrawingImportError('DXFを読み取れません: '+str(exc)) from exc
    return extract_drawing(document, include_settings=settings)


def read_cad_drawing(path, *, include_settings=True):
    file = Path(path).expanduser().resolve()
    if not file.is_file() or file.suffix.lower() not in ('.dwg', '.dxf'):
        raise DrawingImportError('DWGまたはDXFファイルを指定してください。')
    if file.stat().st_size > 64*1024*1024:
        raise DrawingImportError('読込対象は64MiBまでです。必要な図形を別ファイルへ書き出してください。')
    if file.suffix.lower() == '.dxf':
        result = _load_dxf(file, include_settings)
    else:
        with tempfile.TemporaryDirectory(prefix='AcadStadio_DXF_') as temp:
            output = Path(temp)/'drawing.dxf'
            def convert(document):
                # The document is always a temporary COPY, never the original DWG.
                try:document.SaveAs(str(output), 61)  # AutoCAD 2013 DXF
                except Exception as exc:raise DrawingImportError('DWGからDXFへ変換できません: '+str(exc)) from exc
                if not output.is_file():
                    raise DrawingImportError('AutoCADからDXFを書き出せませんでした。')
                return _load_dxf(output, include_settings)
            try:
                result = inspect_dwg(file, convert, isolate=True)
            except DWGImportError as exc:
                raise DrawingImportError(str(exc)) from exc
    result['source'] = str(file)
    result['name'] = file.stem
    return result


def extract_drawing(document, *, include_settings=True):
    reader = DrawingReader(document)
    for entity in document.modelspace():
        reader.read(entity)
    if include_settings:
        reader.resources()
    layouts = [layout.name for layout in document.layouts if layout.name != 'Model' and len(layout)]
    if layouts:
        reader.note(None, 'レイアウト空間は対象外: '+', '.join(layouts))
    if not any(reader.groups.values()):
        raise DrawingImportError('読み込める作図情報がありません。'+ (' / '.join(i['reason'] for i in reader.issues[:4])))
    return dict(blocks=[new_block(group+'ブロック', commands=reader.groups[group]) for group in GROUPS],
                cad_setup=reader.setup if include_settings else None, issues=reader.issues,
                counts={group: len(reader.groups[group]) for group in GROUPS}, source='', name='読込図面')


class DrawingReader:
    def __init__(self, document):
        self.doc = document
        self.groups = {group: [] for group in GROUPS}
        self.setup = default_setup(); self.setup['enabled'] = True
        self.issues = []
        self.visited = 0
        self.total = 0

    def note(self, entity, reason):
        if len(self.issues)==1999:
            self.issues.append(dict(type='設定',handle='',reason='注意項目は2000件まで表示します。以降の注意項目は省略しました。'))
        elif len(self.issues) < 1999:
            self.issues.append(dict(type=entity.dxftype() if entity else '設定',
                                    handle=str(entity.dxf.get('handle', '') or '') if entity else '', reason=reason))

    def normal(self, entity):
        normal = entity.dxf.get('extrusion', (0, 0, 1)) if entity.dxf.is_supported('extrusion') else (0,0,1)
        if abs(normal[0])+abs(normal[1]) > 1e-8:
            raise ValueError('傾いた作図面の3D図形は未対応です')
        if entity.dxf.is_supported('thickness') and abs(float(entity.dxf.get('thickness', 0))) > 1e-8:
            self.note(entity, '厚みは2D作図に反映しません')
        return normal[2]

    def properties(self, entity, parent=None):
        dxf = entity.dxf
        layer = str(dxf.get('layer', '0'))
        if layer == '0' and parent:
            layer = parent['layer']
        if not cad_name(layer):
            raise ValueError('レイヤー名が使用できません: '+layer)
        color = int(dxf.get('color', 256))
        if color == 0 and parent:
            color = parent['effective_color']
        linetype = str(dxf.get('linetype', 'BYLAYER'))
        if linetype.upper() == 'BYBLOCK' and parent:
            linetype = parent['effective_linetype']
        if dxf.hasattr('true_color'):
            self.note(entity, 'TrueColorは未対応のためACI／ByLayerを使用します')
        weight=int(dxf.get('lineweight',-1))
        if weight==-2 and parent:weight=parent['effective_lineweight']
        result = dict(layer=layer, color=str(color), linetype=linetype,lineweight=str(weight),
                      linetype_scale=number(dxf.get('ltscale', 1)))
        return result

    def read(self, entity, parent=None, depth=0, origin=None):
        self.visited += 1
        if self.visited > MAX_COMMANDS*2 or self.total >= MAX_COMMANDS:
            raise DrawingImportError('図形数が読込上限を超えました（コマンド10000件まで）。')
        try:
            self.normal(entity)
            if entity.dxftype() == 'INSERT':
                definition=entity.block()
                if definition is None:raise ValueError('挿入ブロックの定義がありません')
                if definition.block.dxf.flags & 12:raise ValueError('外部参照は未対応です。参照をバインドしてから読み込んでください')
                if depth >= 8:
                    raise ValueError('ブロックの入れ子は8階層までです')
                props = self.properties(entity, parent)
                layer = self.doc.layers.get(props['layer'])
                props.update(effective_color=int(layer.color) if props['color']=='256' else int(props['color']),
                             effective_linetype=layer.dxf.linetype if props['linetype'].upper()=='BYLAYER' else props['linetype'],
                             effective_lineweight=int(layer.dxf.get('lineweight',-3)) if props['lineweight']=='-1' else int(props['lineweight']))
                inserts = entity.multi_insert() if entity.mcount > 1 else (entity,)
                for insert in inserts:
                    for child in insert.virtual_entities(skipped_entity_callback=lambda e,reason:self.note(e,'ブロック変換不可: '+reason)):
                        self.read(child, props, depth+1, origin or entity.dxf.get('handle', ''))
                    for attribute in insert.attribs:
                        self.read(attribute, props, depth+1, origin or entity.dxf.get('handle', ''))
                return
            group, commands = self.convert(entity)
            props = self.properties(entity, parent)
            if len(commands)+self.total > MAX_COMMANDS:
                raise DrawingImportError('読込後のコマンドは10000件までです。')
            for command in commands:
                command = dict(command, **props)
                from table_references import is_single_table_reference
                if is_single_table_reference(command['layer']):command['layer']='='+repr(command['layer'])
                command['point_id'] = new_id()
                command['import_source'] = dict(handle=str(entity.dxf.get('handle', '') or origin or ''), type=entity.dxftype())
                self.groups[group].append(command)
            self.total += len(commands)
        except DrawingImportError:
            raise
        except Exception as exc:
            self.note(entity, str(exc) or type(exc).__name__)

    def convert(self, entity):
        typ = entity.dxftype(); d = entity.dxf
        cmd = {'type': typ}
        if typ == 'LINE':
            cmd.update(point_fields(d.start, '1'), **point_fields(d.end, '2'))
            if xy(d.start) == xy(d.end): raise ValueError('長さ0の線分は読込しません')
        elif typ in ('CIRCLE', 'ARC'):
            center = entity.ocs().to_wcs(d.center)
            cmd.update(point_fields(center), r=number(d.radius))
            if d.radius <= 0: raise ValueError('半径が0以下です')
            if typ == 'ARC':
                def angle(value):
                    a = math.radians(value); vector = entity.ocs().to_wcs((math.cos(a), math.sin(a), 0))
                    return math.degrees(math.atan2(vector.y, vector.x)) % 360
                start, end = angle(d.start_angle), angle(d.end_angle)
                if d.extrusion.z < 0: start, end = end, start
                cmd.update(start_angle=number(start), end_angle=number(end))
        elif typ == 'ELLIPSE':
            if not math.isclose((d.end_param-d.start_param) % (2*math.pi), 0, abs_tol=1e-8):
                raise ValueError('楕円弧は未対応です')
            xy(d.major_axis)
            radius = math.hypot(d.major_axis.x, d.major_axis.y)
            cmd.update(point_fields(d.center), rx=number(radius), ry=number(radius*d.ratio),
                       angle=number(math.degrees(math.atan2(d.major_axis.y, d.major_axis.x))))
        elif typ in ('LWPOLYLINE', 'POLYLINE'):
            if typ == 'POLYLINE' and not entity.is_2d_polyline:
                raise ValueError('3Dポリライン・メッシュは未対応です')
            if entity.has_arc:
                commands = []
                for segment in entity.virtual_entities():
                    _, converted = self.convert(segment); commands.extend(converted)
                return '作図', commands
            points = list(entity.vertices_in_wcs()) if typ=='LWPOLYLINE' else list(entity.points_in_wcs())
            if not 2 <= len(points) <= 500: raise ValueError('ポリラインの頂点は2〜500点までです')
            cmd.update(type='POLYLINE', points='; '.join(','.join(xy(p)) for p in points), closed='1' if entity.is_closed else '0')
            if d.get('const_width', 0) or any(v[2] or v[3] for v in entity.get_points('xyseb')) if typ=='LWPOLYLINE' else False:
                self.note(entity, 'ポリラインの幅は未対応です（中心線を読込）')
        elif typ == 'HATCH':
            if len(entity.paths)!=1 or not hasattr(entity.paths[0],'vertices'):
                raise ValueError('複数境界・曲線境界のハッチングは未対応です')
            path=entity.paths[0]
            if any(abs(v[2])>1e-12 for v in path.vertices):raise ValueError('円弧境界のハッチングは未対応です')
            elevation=d.elevation.z
            points=[entity.ocs().to_wcs((v[0],v[1],elevation)) for v in path.vertices]
            if not 3<=len(points)<=500:raise ValueError('ハッチングの頂点は3〜500点です')
            if entity.gradient:raise ValueError('グラデーションハッチングは未対応です')
            cmd.update(points='; '.join(','.join(xy(p)) for p in points),pattern='SOLID' if d.solid_fill else d.pattern_name,
                       scale=number(d.get('pattern_scale',1)),angle=number(d.get('pattern_angle',0)))
        elif typ in ('SOLID', 'TRACE'):
            points = [d.vtx0, d.vtx1, d.vtx3, d.vtx2]
            points = list(dict.fromkeys(xy(entity.ocs().to_wcs(p)) for p in points))
            cmd.update(type='HATCH', points='; '.join(','.join(p) for p in points),pattern='SOLID',scale='1',angle='0')
        elif typ == 'POINT':
            cmd.update(point_fields(d.location))
        elif typ in ('TEXT', 'ATTRIB', 'ATTDEF'):
            if typ=='ATTDEF': raise ValueError('属性定義はブロック挿入後の値を読み取ってください')
            if d.extrusion.z < 0: raise ValueError('裏向きの文字は未対応です')
            halign = int(d.get('halign', 0)); valign = int(d.get('valign', 0))
            if halign in (3, 5): raise ValueError('位置合わせ／フィットの単一行文字は未対応です')
            anchor = d.align_point if halign or valign else d.insert
            if not d.text or float(d.height)<=0:raise ValueError('文字列または文字高さが空です')
            cmd.update(type='TEXT', **point_fields(entity.ocs().to_wcs(anchor)), height=number(d.height),
                       angle=number(d.get('rotation', 0)), text='='+repr(d.text), text_style=d.get('style', 'Standard'),
                       text_halign=str(halign), text_valign=str(valign), text_width=number(d.get('width', 1)),
                       text_oblique=number(d.get('oblique', 0)), text_generation=str(d.get('text_generation_flag', 0)))
            return 'テキスト', [cmd]
        elif typ == 'MTEXT':
            content = entity.plain_text()
            if not content.strip():raise ValueError('マルチテキストが空です')
            if content != entity.text.replace('\\P', '\n'):
                self.note(entity, 'マルチテキストの部分書式は省略し、文字列・文字スタイルを読込します')
            width = d.get('width', 0)
            if width <= 0:
                width = max(float(d.char_height), max(map(len, content.splitlines()), default=1)*float(d.char_height))
                self.note(entity, '幅未指定のマルチテキストは文字数から幅を設定します')
            cmd.update(point_fields(d.insert), height=number(d.char_height), width=number(width),
                       angle=number(entity.get_rotation()), text='='+repr(content), text_style=d.get('style','Standard'), attachment=str(d.get('attachment_point',1)))
            return 'テキスト', [cmd]
        elif typ == 'DIMENSION':
            kind = entity.dimtype
            cmd['dim_style'] = d.get('dimstyle', 'Standard')
            if kind in (0, 1):
                cmd.update(type='DIMLINEAR' if kind==0 else 'DIMALIGNED', **point_fields(d.defpoint2,'1'),
                           **point_fields(d.defpoint3,'2'), **point_fields(d.defpoint,'3'))
                if kind==0:
                    rotation = float(d.get('angle', 0)) % 180
                    if not (math.isclose(rotation, 0, abs_tol=1e-8) or math.isclose(rotation, 90, abs_tol=1e-8)):
                        aligned=math.degrees(math.atan2(d.defpoint3.y-d.defpoint2.y,d.defpoint3.x-d.defpoint2.x))%180
                        if not math.isclose(rotation,aligned,abs_tol=1e-8):raise ValueError('測定点の方向と異なる回転寸法は未対応です')
                        cmd['type']='DIMALIGNED'
                    else:cmd['dimension_axis'] = 'horizontal' if math.isclose(rotation, 0, abs_tol=1e-8) else 'vertical'
            elif kind in (3, 4):
                first, second = d.defpoint, d.defpoint4
                center = first if kind==4 else (first+second)/2
                radius = (second-first).magnitude / (1 if kind==4 else 2)
                label = entity.ocs().to_wcs(d.text_midpoint)
                cmd.update(type='DIMRADIUS' if kind==4 else 'DIMDIAMETER', **point_fields(center), r=number(radius), **point_fields(label,'3'))
            else:
                raise ValueError('角度寸法・弧長寸法・座標寸法などは未対応です')
            if d.get('text', '<>') not in ('', '<>'):
                cmd['dimension_text'] = d.text
            if entity.get_xdata('ACAD') if entity.has_xdata('ACAD') else False:
                self.note(entity, '寸法の個別スタイル上書き・独自文字位置は完全には再現しません')
            return '寸法', [cmd]
        else:
            raise ValueError(typ+'は現在の作図コマンドに変換できません')
        return '作図', [cmd]

    def resources(self):
        for layer in self.doc.layers:
            d = layer.dxf
            if not cad_name(d.name): self.note(layer,'使用できないレイヤー名です'); continue
            self.setup['layers'].append(dict(name=d.name, color=str(abs(int(d.color))), linetype=d.linetype,
                                              lineweight=str(d.get('lineweight', -3)), plot=bool(d.get('plot', 1))))
            if int(d.color)<0 or d.get('flags',0)&1:
                self.note(layer,'レイヤーの非表示・フリーズ状態は読込しません')
            if d.hasattr('true_color'): self.note(layer,'レイヤーのTrueColorはACIで読込します')
        for style in self.doc.styles:
            d = style.dxf
            if not cad_name(d.name) or not d.get('font',''):
                self.note(style,'名前またはフォント名を取得できず文字スタイルを省略しました'); continue
            self.setup['text_styles'].append(dict(name=d.name,font=d.font,width=number(d.get('width',1)),oblique=number(d.get('oblique',0))))
            if d.get('height',0): self.note(style,'固定文字高さは各文字の実際の高さで指定します')
            if d.get('bigfont',''): self.note(style,'ビッグフォントは設定形式が未対応です')
        for style in self.doc.dimstyles:
            d = style.dxf
            if not cad_name(d.name): continue
            text_style = self.doc.styles.get(d.get('dimtxsty','Standard')) if self.doc.styles.has_entry(d.get('dimtxsty','Standard')) else self.doc.entitydb.get(d.get('dimtxsty_handle',''))
            if d.get('dimscale',1)==0:self.note(style,'注釈尺度0の寸法スタイルは尺度1として登録します')
            self.setup['dim_styles'].append(dict(name=d.name,base='',scale=number(d.get('dimscale',1) or 1),text_height=number(d.get('dimtxt',2.5)),
                                                arrow_size=number(d.get('dimasz',2.5)),text_style=text_style.dxf.name if text_style else ''))
        for linetype in self.doc.linetypes:
            d = linetype.dxf
            if d.name.upper() not in ('BYLAYER','BYBLOCK','CONTINUOUS') and cad_name(d.name):
                # Keep actual simple line patterns; no external LIN dependency.
                pattern = list(linetype.pattern_tags.tags)
                flags = [tag.value for tag in pattern if tag.code==74]
                elements = [number(tag.value) for tag in pattern if tag.code==49]
                row = dict(name=d.name,file='',existing_only=True)
                if elements and not any(flags): row.update(pattern=elements,existing_only=False)
                else: self.note(linetype,'複合線種は同名の既存線種を使用します')
                self.setup['linetypes'].append(row)
        self.setup['drawing_variables'] = {name[1:]:number(self.doc.header.get(name,default)) for name,default in [('$LWDEFAULT',25),('$INSUNITS',0),('$LTSCALE',1),('$PSLTSCALE',1),('$MSLTSCALE',1),('$LWDISPLAY',0),('$MEASUREMENT',1)]}
        for section in ('layers','text_styles','dim_styles','linetypes'):
            accepted=[]
            for row in self.setup[section]:
                one=default_setup();one[section]=[row]
                errors=validate_setup(one)
                if errors:
                    self.note(None,section+'「'+row['name']+'」は未登録: '+' / '.join(errors[:2]))
                elif len(accepted)<100:accepted.append(row)
                else:self.note(None,section+'「'+row['name']+'」は100件の上限により未登録')
            self.setup[section]=accepted
        from drawing_variables import validate_variables
        for name,value in list(self.setup['drawing_variables'].items()):
            if validate_variables({name:value}):
                self.note(None,name+'は設定形式の範囲外のため未登録');del self.setup['drawing_variables'][name]
        errors = validate_setup(self.setup)
        if errors:
            raise DrawingImportError('読み取った設定が現在の設定形式に収まりません:\n'+'\n'.join(errors[:8]))
        self.note(None,'寸法スタイルは尺度・文字高さ・矢印サイズ・文字スタイルを読込します。その他の寸法設定は対象外です。')


def imported_project(snapshot):
    from project_model import normalize_sequential_project
    project = dict(version=11, cad_setup=copy.deepcopy(snapshot['cad_setup'] or default_setup()), settings={'TEXT_HEIGHT':'3.5'}, globals={},
                   rows=[{'読込元':'読込図面'}], blocks=copy.deepcopy(snapshot['blocks']))
    return normalize_sequential_project(project)


def append_drawing(project, snapshot):
    from block_operations import suggested_name
    from project_model import validate_sequential_project
    trial = copy.deepcopy(project)
    for block in snapshot['blocks']:
        block = copy.deepcopy(block)
        block['name'] = suggested_name(trial, snapshot['name']+'・'+block['name'])
        trial['blocks'].append(block)
    errors = validate_sequential_project(trial)
    if errors: raise DrawingImportError('\n'.join(errors[:8]))
    return trial
