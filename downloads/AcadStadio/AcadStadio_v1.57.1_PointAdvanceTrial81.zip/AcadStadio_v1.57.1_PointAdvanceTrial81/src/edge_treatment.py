"""Chamfer and fillet of two picked 2D LINE entities, with analytical previews."""
import math

TYPES=frozenset(('CHAMFER','FILLET'))
PICKS=[('layer',''),('x1','@X+50'),('y1','@Y'),('x2','@X'),('y2','@Y+50')]
FIELDS={'CHAMFER':PICKS+[('distance1','10'),('distance2','10'),('pick_tolerance','0.01')],
        'FILLET':PICKS+[('radius','10'),('pick_tolerance','0.01')]}


def render(command,values,number):
    from extended_commands import selection_lisp,current_properties_lisp
    n=lambda key:float(number(command[key],values))
    first,second=(n('x1'),n('y1')),(n('x2'),n('y2'));tolerance=n('pick_tolerance')
    if not 0<tolerance<=100:raise ValueError('選択許容差は0より大きく100以下にしてください')
    typ=command['type'];parameters={}
    if typ=='CHAMFER':
        parameters={key:n(key) for key in ('distance1','distance2')}
        if any(v<=0 for v in parameters.values()):raise ValueError('面取り距離1・2は正の数値にしてください')
        settings=['_.SETVAR','CHAMMODE','0','_.SETVAR','CHAMFERA',str(parameters['distance1']),'_.SETVAR','CHAMFERB',str(parameters['distance2'])]
        expected='LINE'
    else:
        parameters={'radius':n('radius')}
        if parameters['radius']<=0:raise ValueError('丸め半径は正の数値にしてください')
        settings=['_.SETVAR','FILLETRAD',str(parameters['radius'])];expected='ARC'
    lp=lambda p:f'(list {p[0]:.12g} {p[1]:.12g} 0.0)'
    # Entity+pick-point lists preserve the selected side, independent of screen zoom.
    form=('((lambda (/ ss i e p q found first second p1 p2 result before cc rgb clr) (vl-load-com) '
          +selection_lisp(*first,tolerance,'first',entity_types='LINE')
          +selection_lisp(*second,tolerance,'second',entity_types='LINE')
          +'(if (eq first second) (error "AcadStadio: Pick two different lines")) '
          +f'(setq p1 {lp(first)} p2 {lp(second)} before (entlast)) '
          +f'(setq result (vl-catch-all-apply \'command-s (list "_.{typ}" (list first p1) (list second p2)))) '
          +'(if (vl-catch-all-error-p result) (error (vl-catch-all-error-message result))) '
          +f'(if (or (eq before (entlast)) (not (equal (cdr (assoc 0 (entget (entlast)))) "{expected}"))) (error "AcadStadio: Edge treatment did not create the expected entity")) '
          +current_properties_lisp('(vlax-ename->vla-object (entlast))')+'))')
    label='面取り' if typ=='CHAMFER' else '角丸め'
    return ['_.SETVAR','TRIMMODE','1',*settings,form],dict(coords=(*first,*second),**parameters,pick_tolerance=tolerance,
        preview_note=label+'：対象の線はプレビュー外です（結果はCADで確認）')


def corner(first,second,pick1,pick2,parameters,kind):
    """Return trimmed segments and joining line/arc; pick points choose kept rays."""
    a,b=first[:2],first[2:];c,d=second[:2],second[2:]
    u=(b[0]-a[0],b[1]-a[1]);v=(d[0]-c[0],d[1]-c[1]);cross=lambda x,y:x[0]*y[1]-x[1]*y[0]
    determinant=cross(u,v);scale=math.hypot(*u)*math.hypot(*v)
    if not scale or abs(determinant)<=1e-12*scale:raise ValueError('面取り・角丸めには平行でない2本の線が必要です')
    t=cross((c[0]-a[0],c[1]-a[1]),v)/determinant;origin=(a[0]+t*u[0],a[1]+t*u[1])
    def ray(pick,endpoints):
        dx,dy=endpoints[1][0]-endpoints[0][0],endpoints[1][1]-endpoints[0][1];length=math.hypot(dx,dy)
        side=((pick[0]-origin[0])*dx+(pick[1]-origin[1])*dy)/length
        if abs(side)<=1e-9:raise ValueError('交点以外の線上で、残したい側を指定してください')
        direction=1 if side>0 else -1
        unit=(direction*dx/length,direction*dy/length)
        lengths=[(p[0]-origin[0])*unit[0]+(p[1]-origin[1])*unit[1] for p in endpoints]
        index=max(range(2),key=lambda i:lengths[i])
        return unit,index,lengths[index]
    ua,ia,la=ray(pick1,(a,b));ub,ib,lb=ray(pick2,(c,d))
    if kind=='CHAMFER':ta,tb=parameters['distance1'],parameters['distance2']
    else:
        dot=max(-1,min(1,ua[0]*ub[0]+ua[1]*ub[1]));half=math.acos(dot)/2
        if not 1e-9<half<math.pi/2-1e-9:raise ValueError('角丸めの角度が成立しません')
        radius=parameters['radius'];ta=tb=radius/math.tan(half)
    if ta>=la-1e-9 or tb>=lb-1e-9:raise ValueError('面取り距離または丸め半径が大きすぎます。残す線の長さを確認してください')
    p=(origin[0]+ta*ua[0],origin[1]+ta*ua[1]);q=(origin[0]+tb*ub[0],origin[1]+tb*ub[1])
    one=(*a,*p) if ia==0 else (*p,*b);two=(*c,*q) if ib==0 else (*q,*d)
    if kind=='CHAMFER':geometry=dict(display_type='LINE',coords=(*p,*q))
    else:
        bisector=(ua[0]+ub[0],ua[1]+ub[1]);length=math.hypot(*bisector);offset=radius/math.sin(half)
        center=(origin[0]+offset*bisector[0]/length,origin[1]+offset*bisector[1]/length)
        start,end=[math.degrees(math.atan2(point[1]-center[1],point[0]-center[0]))%360 for point in (p,q)]
        if (end-start)%360>180:start,end=end,start
        geometry=dict(display_type='ARC',coords=(*center,radius),start_angle=start,sweep=(end-start)%360)
    return one,two,geometry


def apply_preview(item,items):
    from range_selection import entities
    from edit_preview import distance
    picks=item['coords'][:2],item['coords'][2:4];sources=[]
    for pick in picks:
        matches=[source for source in entities(items) if not source.get('guide') and not source.get('segments')
                 and source.get('display_type',source['type'])=='LINE' and len(source['coords'])==4
                 and distance(pick,source)<=item['pick_tolerance']]
        if len(matches)>1:raise ValueError('選択点に線が重なっています。中点など別の点を指定してください')
        if not matches:return []
        sources.append(matches[0])
    if sources[0] is sources[1]:raise ValueError('異なる2本の線を指定してください')
    first,second,geometry=corner(sources[0]['coords'],sources[1]['coords'],*picks,item,item['type'])
    sources[0]['coords']=first;sources[1]['coords']=second
    item.update(geometry,preview_note='')
    return sources
