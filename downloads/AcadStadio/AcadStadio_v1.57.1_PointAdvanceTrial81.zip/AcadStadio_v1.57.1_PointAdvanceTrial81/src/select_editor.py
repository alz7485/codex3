"""One reusable SELECT editor for accumulating points and rectangles."""
import copy
from tkinter import ttk
from table_grid import GridTreeview
from selection_sets import resolve,DXF_TYPES,snap_point,select_queries
from range_selection import MODES

class SelectionEditor:
    def __init__(self,win,get_data,apply_data,get_canvas,refresh):
        self.win=win;self.get_data=get_data;self.apply_data=apply_data;self.get_canvas=get_canvas;self.refresh=refresh
        self.capturing=False;self.updating=False
    def build(self,host):
        if self.capturing and not self.updating:self.stop()
        actions=ttk.Frame(host);actions.pack(fill='x',pady=(0,5))
        for label,fn in [('入力した選択を追加',self.add_pending),('削除',self.remove),('全解除',self.clear)]:
            ttk.Button(actions,text=label,command=fn,style='Compact.TButton').pack(side='left',padx=(0,4))
        frame=ttk.Frame(host);frame.pack(fill='x',pady=(0,6));frame.columnconfigure(0,weight=1)
        self.tree=GridTreeview(frame,columns=('kind','condition'),show='headings',height=3,selectmode='extended')
        self.tree.heading('kind',text='選択');self.tree.column('kind',width=70,minwidth=60,stretch=False)
        self.tree.heading('condition',text='追加した条件');self.tree.column('condition',width=360,minwidth=80)
        self.tree.grid(row=0,column=0,sticky='ew');scroll=ttk.Scrollbar(frame,command=self.tree.yview);scroll.grid(row=0,column=1,sticky='ns');self.tree.configure(yscrollcommand=scroll.set)
        for i,q in enumerate(self.get_data().get('selections',[])):
            mode=q.get('mode','point');text=f"({q['x1']}, {q['y1']})"
            if mode!='point':text+=f" → ({q['x4']}, {q['y4']})"
            elif q.get('entity_type'):text=q['entity_type']+' '+text
            self.tree.insert('','end',iid=str(i),values=({'point':'点','window':'窓','crossing':'交差'}[mode],text))
        self.tree.bind('<Delete>',lambda e:self.remove())
        ttk.Label(host,text='プレビューで繰り返しクリック／ドラッグして追加。Escで選択を終了します。',style='Muted.TLabel',wraplength=520).pack(fill='x',pady=(0,5))
    def change(self,data):
        self.updating=True
        try:self.apply_data(data)
        finally:self.updating=False
    def add(self,query):
        data=self.get_data();queries=copy.deepcopy(data.get('selections',[]))
        if query not in queries:
            if len(queries)>=100:
                from tkinter import messagebox
                messagebox.showinfo('選択条件の上限','点・矩形は100件まで追加できます。',parent=self.win);return
            queries.append(query)
        data['selections']=queries
        for key in ('x1','y1','x4','y4'):
            if key in query:data[key]=query[key]
        self.change(data)
    def add_pending(self):
        data=self.get_data();mode=data.get('selection_mode','point');keys=('x1','y1') if mode=='point' else ('x1','y1','x4','y4')
        self.add(dict(mode=mode,**{key:data.get(key,'0') for key in keys}))
    def remove(self):
        indices={int(i) for i in self.tree.selection()};data=self.get_data();data['selections']=[q for i,q in enumerate(data.get('selections',[])) if i not in indices];self.change(data)
    def clear(self):
        data=self.get_data();data['selections']=[];self.change(data)
    def stop(self):
        self.capturing=False
        canvas=self.get_canvas()
        if canvas is not None:canvas.cancel_range()
    def start(self,force=False):
        canvas=self.get_canvas()
        if canvas is None:return
        if self.capturing and not force:self.stop();self.refresh();return
        self.capturing=True;mode=self.get_data().get('selection_mode','point')
        if mode=='point':canvas.begin_point_selection(self.point)
        else:canvas.begin_range(self.rectangle,mode)
    def point(self,position,source):
        try:position=snap_point(position,source)
        except (ValueError,KeyError,ZeroDivisionError):return
        kind=source.get('display_type',source['type'])
        if kind not in DXF_TYPES:return
        self.add(dict(mode='point',x1=format(position[0],'.12g'),y1=format(position[1],'.12g'),entity_type=kind))
        if self.capturing:self.start(force=True)
    def rectangle(self,a,b):
        data=self.get_data();mode=data.get('selection_mode','window')
        for key,value in zip(('x1','y1','x4','y4'),(*a,*b)):data[key]=format(value,'.12g')
        query=dict(mode=mode,**{key:data[key] for key in ('x1','y1','x4','y4')})
        queries=copy.deepcopy(data.get('selections',[]))
        if query not in queries and len(queries)<100:queries.append(query)
        data['selections']=queries;self.change(data)
        if self.capturing:self.start(force=True)
    def overlays(self,context,number):
        canvas=self.get_canvas()
        if canvas is None:return
        try:queries=resolve(self.get_data(),context,number)
        except (ValueError,KeyError):queries=[]
        canvas.selection_rectangles=[(q['box'],q['mode']) for q in queries if q['mode']!='point']
        canvas.selection_points=[q['point'] for q in queries if q['mode']=='point']
        canvas.reference_bounds=[p for q in queries for p in ([q['point']] if q['mode']=='point' else [q['box'][:2],q['box'][2:]])]
        try:members=select_queries(canvas.items,queries,float(number(self.get_data().get('pick_tolerance','0.01'),context))) if queries else []
        except (ValueError,KeyError):members=[]
        canvas.selection_count=len(members)
        canvas.selected_entity_ids={id(s) for s in members if s.get('entity_parent') is None}
        canvas.selected_segments=[s['coords'] for s in members if s.get('entity_parent') is not None]
        canvas.selection_active=True
        canvas.fit(preserve=True,preserve_camera=True)
