"""Stable references to previously drawn command geometry across ordered blocks."""
import ast
import copy
import math
import io
import tokenize
import uuid

POINTS = {
    'CHAMFER': ('始点', '中点', '終点'),
    'FILLET': ('始点', '中点', '終点', '中心', '角度指定点'),
    'LINE': ('始点', '中点', '終点'),
    'POLYLINE': ('始点', '中点', '終点'),
    'SPLINE': ('始点', '終点'),
    'HATCH': ('始点',),
    'LEADER': ('始点', '中点', '終点'),
    'INSERT': ('挿入点',),
    'MTEXT': ('挿入点',),
    'CADBLOCK': ('挿入点',),
    'OFFSET': ('始点', '中点', '終点', '中心', '上', '下', '左', '右'),
    'COPY': ('始点', '中点', '終点', '中心', '上', '下', '左', '右', '位置', '挿入点', '対角点1', '対角点2'),
    'MIRROR': ('始点', '中点', '終点', '中心', '上', '下', '左', '右', '位置', '挿入点', '対角点1', '対角点2'),
    'ARC': ('始点', '中点', '終点', '中心', '角度指定点'),
    'CIRCLE': ('中心', '上', '下', '左', '右'), 'ELLIPSE': ('中心', '長軸端点1', '長軸端点2', '短軸端点1', '短軸端点2'),
    'POINT': ('位置',), 'TEXT': ('挿入点',),
    'RECTANGLE': ('対角点1', '中心', '対角点2', '左上', '右上', '左下', '右下', '上辺中点', '下辺中点', '左辺中点', '右辺中点'),
}


def new_id():
    return 'p_' + uuid.uuid4().hex


def geometry_points(item):
    c = item['coords']; typ = item.get('display_type',item['type'])
    if item.get('segments') or item.get('operation_deleted') or item.get('children'):return {}
    if typ in ('LINE','POLYLINE','LEADER'):
        from vertex_points import path_midpoint
        result={'始点': c[:2], '中点': path_midpoint(c,item.get('closed',False)), '終点': c[-2:]}
        vertices=list(zip(c[::2],c[1::2]))
        if len(vertices)==2 and not item.get('closed'):
            return result
        result.update({f'頂点{i+1}':p for i,p in enumerate(vertices)})
        pairs=list(zip(vertices,vertices[1:]))
        if item.get('closed'):pairs.append((vertices[-1],vertices[0]))
        result.update({f'区間{i+1}中点':((a[0]+b[0])/2,(a[1]+b[1])/2) for i,(a,b) in enumerate(pairs)})
        result.update(item.get('reference_points',{}))
        return result
    if typ == 'CIRCLE':
        x, y, radius = c[:3]
        return {'中心': (x, y), '上': (x, y+radius), '下': (x, y-radius),
                '左': (x-radius, y), '右': (x+radius, y)}
    if item.get('reference_points'):return item['reference_points']
    if typ == 'INSERT':return {'挿入点': c[:2]}
    if typ == 'SPLINE':return {'始点': c[:2], '終点': c[-2:]}
    if typ == 'HATCH':return {'始点': c[:2]}
    if typ == 'RECTANGLE':
        left,right=sorted((c[0],c[2]));bottom,top=sorted((c[1],c[3]));mx,my=(left+right)/2,(bottom+top)/2
        return {'対角点1': c[:2], '中心': (mx,my), '対角点2': c[2:4],
                '左上':(left,top),'右上':(right,top),'左下':(left,bottom),'右下':(right,bottom),
                '上辺中点':(mx,top),'下辺中点':(mx,bottom),'左辺中点':(left,my),'右辺中点':(right,my)}
    if typ == 'ELLIPSE':
        x,y,rx,ry=c;angle=math.radians(item.get('angle',0));a,b=math.cos(angle),math.sin(angle)
        return {'中心':(x,y),'長軸端点1':(x+rx*a,y+rx*b),'長軸端点2':(x-rx*a,y-rx*b),
                '短軸端点1':(x-ry*b,y+ry*a),'短軸端点2':(x+ry*b,y-ry*a)}
    if typ == 'ARC':
        result = {'中心': c[:2]}
        for name, fraction in [('始点',0),('中点',.5),('終点',1)]:
            a=math.radians(item['start_angle']+item['sweep']*fraction)
            result[name]=(c[0]+c[2]*math.cos(a),c[1]+c[2]*math.sin(a))
        result['角度指定点']=result['始点']
        return result
    name = {'CIRCLE':'中心','ELLIPSE':'中心','POINT':'位置','TEXT':'挿入点','MTEXT':'挿入点'}.get(typ)
    return {name: c[:2]} if name else {}


def rotated_circle_point(points, name, angle):
    """Rotate a circle quadrant about its center; positive degrees are CCW."""
    if name == '角度指定点' and all(k in points for k in ('中心','始点','終点')):
        if type(angle) not in (int,float) or not math.isfinite(angle):raise ValueError('角度は有限の数値で指定してください')
        cx,cy=points['中心'];sx,sy=points['始点'];ex,ey=points['終点']
        start=math.degrees(math.atan2(sy-cy,sx-cx))%360;end=math.degrees(math.atan2(ey-cy,ex-cx))%360
        if (angle-start)%360 > (end-start)%360+1e-8:raise ValueError('指定角度の点は円弧の範囲外です')
        radius=math.hypot(sx-cx,sy-cy);a=math.radians(angle%360)
        return cx+radius*math.cos(a),cy+radius*math.sin(a)
    if name not in ('上', '下', '左', '右') or '中心' not in points or name not in points:
        raise ValueError('回転角度は円の四半円点（上・下・左・右）で指定してください')
    if type(angle) not in (int, float) or not math.isfinite(angle):
        raise ValueError('回転角度は有限の数値で指定してください')
    cx, cy = points['中心']; x, y = points[name]
    a = math.radians(angle % 360); cosine, sine = math.cos(a), math.sin(a)
    return (cx+(x-cx)*cosine-(y-cy)*sine, cy+(x-cx)*sine+(y-cy)*cosine)


def reference(identity, point, axis, angle=None):
    extra = f', {angle}' if angle is not None else ''
    return f'点({identity!r}, {point!r}, {axis!r}{extra})'


def clone_commands(commands):
    """Give copied definitions new identities; remap references within the copy."""
    result=copy.deepcopy(commands); mapping={}
    def walk(items):
        for cmd in items:
            yield cmd
            yield from walk(cmd.get('commands',[]))
            yield from walk(cmd.get('else',[]))
    for cmd in walk(result):
        if cmd.get('point_id'):
            old=cmd['point_id'];mapping[old]=new_id();cmd['point_id']=mapping[old]
    return rewrite_references(result, mapping)


def rewrite_references(value, mapping):
    """Change only literal identities inside point functions, even beside @ columns."""
    if isinstance(value,str) and ('点(' in value or '点位置(' in value):
        try:
            tokens=list(tokenize.generate_tokens(io.StringIO(value).readline))
            for i, token in enumerate(tokens[:-2]):
                if token.type == tokenize.NAME and token.string in ('点', '点位置') and tokens[i+1].string == '(' and tokens[i+2].type == tokenize.STRING:
                    identity=ast.literal_eval(tokens[i+2].string)
                    if identity in mapping:
                        tokens[i+2]=tokens[i+2]._replace(string=repr(mapping[identity]))
            return tokenize.untokenize(tokens)
        except (SyntaxError, ValueError, tokenize.TokenError):
            return value
    if isinstance(value,dict):
        literal_fields={"text","layer","linetype","text_style","dim_style","guide_origin"}
        result = {k:(v if k in literal_fields and isinstance(v,str) and not v.startswith("=") else rewrite_references(v,mapping)) for k,v in value.items()}
        if isinstance(value.get('selection_ref'),str) and value['selection_ref'] in mapping:result['selection_ref']=mapping[value['selection_ref']]
        return result
    if isinstance(value,list):return [rewrite_references(v,mapping) for v in value]
    return value


def read_point_reference(text):
    """Read an editor-produced reference without evaluating any expression."""
    from vertex_points import split_top_level
    text=text.strip().removeprefix('=').strip()
    name='点位置' if text.startswith('点位置(') else '点'
    if not text.startswith(name+'('):return None
    quote=None;escaped=False;depth=0;end=None
    for i,char in enumerate(text[len(name):],len(name)):
        if quote:
            if escaped:escaped=False
            elif char=='\\':escaped=True
            elif char==quote:quote=None
        elif char in ('"',"'"):quote=char
        elif char=='(':depth+=1
        elif char==')':
            depth-=1
            if depth==0:end=i;break
    if end is None:return None
    try:
        args=split_top_level(text[len(name)+1:end],',')
        identity,point=map(ast.literal_eval,args[:2])
        if not isinstance(identity,str) or not isinstance(point,str):return None
        tail=text[end+1:].strip()
        if name=='点位置':
            if tail or len(args) not in (2,4,5):return None
            return dict(identity=identity,point=point,axis=None,offsets=args[2:4] or ['0','0'],angle=args[4] if len(args)==5 else '0')
        if len(args) not in (3,4):return None
        axis=ast.literal_eval(args[2])
        if axis not in ('X','Y'):return None
        shift='0'
        if tail:
            if not tail.startswith('+'):return None
            shift=tail[1:].strip()
            if shift.startswith('(') and shift.endswith(')'):shift=shift[1:-1]
        return dict(identity=identity,point=point,axis=axis,offsets=[shift],angle=args[3] if len(args)==4 else '0')
    except (ValueError,SyntaxError,IndexError):return None
