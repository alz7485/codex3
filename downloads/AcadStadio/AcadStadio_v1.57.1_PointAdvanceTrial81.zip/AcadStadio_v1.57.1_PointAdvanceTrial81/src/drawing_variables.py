"""Finite, editable drawing-wide settings imported from DXF header variables."""
import math

FIELDS = {
    'LWDEFAULT': ('既定の線の太さ（1/100mm）', 0, 211, True),
    'INSUNITS': ('挿入単位（AutoCADコード）', 0, 24, True),
    'LTSCALE': ('図面全体の線種尺度', 0, 1e9, False),
    'PSLTSCALE': ('ペーパー空間の線種尺度補正（0／1）', 0, 1, True),
    'MSLTSCALE': ('モデル空間の線種尺度補正（0／1）', 0, 1, True),
    'LWDISPLAY': ('線の太さを画面に表示（0／1）', 0, 1, True),
    'MEASUREMENT': ('線種・ハッチ単位系（0：英尺／1：メートル）', 0, 1, True),
}


def validate_variables(values):
    if not isinstance(values, dict) or set(values)-set(FIELDS):
        return ['図面設定の変数が不正です']
    errors=[]
    for name, value in values.items():
        label, low, high, integer = FIELDS[name]
        try:
            v=float(value)
            if not math.isfinite(v) or not low<=v<=high or (integer and not v.is_integer()) or (name=='LTSCALE' and v<=0):raise ValueError()
            if name=='LWDEFAULT':
                from dwg_resources import LINEWEIGHTS
                if v not in LINEWEIGHTS-{-3}:raise ValueError()
        except (TypeError,ValueError,OverflowError):errors.append('図面設定 / '+label+': 値を確認してください')
    return errors
