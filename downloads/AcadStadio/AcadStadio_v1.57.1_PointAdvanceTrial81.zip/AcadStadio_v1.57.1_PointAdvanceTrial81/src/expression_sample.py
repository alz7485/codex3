"""Safe, side-effect-free expression samples using the compiler's interpreter."""

from engine import evaluate, row_values


def sample_value(project, expression, row_index=0, local_variables=None, *, repeat_counts=()):
    values = dict(row_values(project, row_index), __local__={})
    if repeat_counts:
        from coordinate_formulas import repeat_context
        values['__loop__']=repeat_context(values,repeat_counts)
    for key, expr in (local_variables or {}).items():
        values["__local__"][key] = evaluate(expr, values)
        values[key] = values["__local__"][key]
    return evaluate(expression, values)
