"""Small reversible coordinate recipes; generated formulas use the existing engine."""
import ast
import math
import re

MODES=('指定位置から移動','距離と角度で指定','横に等間隔','縦に等間隔','円周に等間隔')
PARAMETERS={
 MODES[0]:(('x','基準のX','@X'),('y','基準のY','@Y'),('dx','Xの移動量','0'),('dy','Yの移動量','0')),
 MODES[1]:(('x','基準のX','@X'),('y','基準のY','@Y'),('distance','移動する距離','100'),('angle','角度（°）','0')),
 MODES[2]:(('x','開始位置X','@X'),('y','開始位置Y','@Y'),('pitch','Xの間隔','100')),
 MODES[3]:(('x','開始位置X','@X'),('y','開始位置Y','@Y'),('pitch','Yの間隔','100')),
 MODES[4]:(('x','中心X','@X'),('y','中心Y','@Y'),('radius','半径','50'),('angle','開始角度（°）','90')),
}


def formulas(mode,parameters):
    from engine import parse_expression
    if mode not in PARAMETERS:raise ValueError('配置方法を選択してください')
    p={key:str(parameters.get(key,default)).strip() for key,_,default in PARAMETERS[mode]}
    for value in p.values():
        if not value:raise ValueError('空欄の項目を入力してください')
        parse_expression(value)
    x,y=f"({p['x']})",f"({p['y']})"
    if mode==MODES[0]:return f"{x} + ({p['dx']})",f"{y} + ({p['dy']})"
    if mode==MODES[1]:
        a=f"radians(({p['angle']}))";distance=f"({p['distance']})"
        return f'{x} + {distance} * cos({a})',f'{y} + {distance} * sin({a})'
    if mode==MODES[2]:return f"{x} + loop.index * ({p['pitch']})",p['y']
    if mode==MODES[3]:return p['x'],f"{y} + loop.index * ({p['pitch']})"
    sign='-' if parameters.get('direction')=='時計回り' else ''
    a=f"radians(({p['angle']}) + loop.index * ({sign}360 / loop.count))"
    radius=f"({p['radius']}) / 2" if parameters.get('size_mode')=='直径' else p['radius']
    return f"{x} + ({radius}) * cos({a})",f"{y} + ({radius}) * sin({a})"


def repeat_context(values,counts,*,allow_zero=False):
    from engine import evaluate,MacroError
    context=None
    for expression in counts:
        scope=dict(values)
        scope.pop('__loop__',None)
        if context is not None:scope['__loop__']=context
        count=evaluate(str(expression),scope)
        if type(count) not in (int,float) or count!=int(count) or not 0<=count<=1000:
            raise MacroError('繰り返し回数は0〜1000の整数にしてください')
        if count==0 and not allow_zero:raise MacroError('この繰り返しは0回です。配置される図形はありません')
        context=dict(index=0,number=1,count=int(count))
        if count==0:return context
    return context


def positions(mode,parameters,values,count=1):
    from engine import evaluate
    x,y=formulas(mode,parameters)
    if type(count) is not int or not 0<=count<=1000:raise ValueError('確認回数は0〜1000の整数にしてください')
    if count==0:return []
    result=[]
    for index in range(count):
        context=dict(values,__loop__=dict(index=index,number=index+1,count=count))
        px,py=evaluate(x,context),evaluate(y,context)
        if any(type(v) not in (int,float) or not math.isfinite(v) for v in (px,py)):raise ValueError('座標は数値で指定してください')
        if mode==MODES[4] and evaluate(parameters['radius'],context)<=0:raise ValueError('半径は正の数値にしてください')
        result.append((px,py))
    return result


def read_formulas(x,y):
    """Recognize generated recipes, preserving table/point-reference source text."""
    from table_references import _map_references
    if not any('+' in value for value in (x,y)):return None
    replacements={};originals={}
    def prepare(text):
        def mapped(match):
            value=match.group(0)
            if value not in originals:
                key='_placement_ref_'+str(len(replacements));replacements[key]=value;originals[value]=key
            return originals[value]
        return _map_references(text,mapped)
    try:
        sx,sy=prepare(x),prepare(y);nx,ny=ast.parse(sx,mode='eval').body,ast.parse(sy,mode='eval').body
        if any(sum(1 for _ in ast.walk(node))>256 for node in (nx,ny)):return None
        def text(node,source):
            value=ast.get_source_segment(source,node)
            return re.sub(r'\b_placement_ref_\d+\b',lambda m:replacements[m.group()],value)
        def same(a,b):return ast.dump(a)==ast.dump(b)
        def linear(node):return isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add) and isinstance(node.right,ast.BinOp) and isinstance(node.right.op,ast.Mult) and ast.dump(node.right.left)==ast.dump(ast.parse('loop.index',mode='eval').body)
        if linear(nx):return MODES[2],dict(x=text(nx.left,sx),y=y,pitch=text(nx.right.right,sx))
        if linear(ny):return MODES[3],dict(x=x,y=text(ny.left,sy),pitch=text(ny.right.right,sy))
        if not all(isinstance(n,ast.BinOp) and isinstance(n.op,ast.Add) for n in (nx,ny)):return None
        a,b=nx.right,ny.right
        if all(isinstance(n,ast.BinOp) and isinstance(n.op,ast.Mult) and isinstance(n.right,ast.Call) and isinstance(n.right.func,ast.Name) for n in (a,b)) and a.right.func.id=='cos' and b.right.func.id=='sin':
            ca,cb=a.right,b.right
            if not all(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and len(n.args)==1 for n in (ca,cb)):return None
            if ca.func.id!='cos' or cb.func.id!='sin' or not same(a.left,b.left) or not same(ca.args[0],cb.args[0]):return None
            radians=ca.args[0]
            if not isinstance(radians,ast.Call) or not isinstance(radians.func,ast.Name) or radians.func.id!='radians':return None
            angle=radians.args[0];p=dict(x=text(nx.left,sx),y=text(ny.left,sy))
            if linear(angle):
                step=angle.right.right
                if isinstance(step,ast.BinOp) and isinstance(step.op,ast.Div) and ast.unparse(step.right)=='loop.count':
                    sign=ast.literal_eval(step.left)
                    if sign not in (-360,360):return None
                    radius=a.left;size_mode='半径'
                    if isinstance(radius,ast.BinOp) and isinstance(radius.op,ast.Div) and isinstance(radius.right,ast.Constant) and radius.right.value==2:
                        radius=radius.left;size_mode='直径'
                    p.update(radius=text(radius,sx),angle=text(angle.left,sx),direction='時計回り' if sign<0 else '反時計回り',size_mode=size_mode);return MODES[4],p
            p.update(distance=text(a.left,sx),angle=text(angle,sx));return MODES[1],p
        return MODES[0],dict(x=text(nx.left,sx),y=text(ny.left,sy),dx=text(nx.right,sx),dy=text(ny.right,sy))
    except (SyntaxError,ValueError,TypeError,KeyError,IndexError):return None
