"""Result previews for rotation, arrays, explosion and CAD block definitions."""
import copy,math
from range_selection import entities,select_range,delete_entity,MAX_SELECTED
from transform_preview import general_distance
from edit_preview import segments,distance
from affine_geometry import transform,mtext_lines


def apply(item,items,values,tolerance):
    kind=item['type'];registry=values.setdefault('__cad_blocks__',{})
    if kind=='INSERT':
        definition=registry.get(item.get('block_name',''))
        if definition and math.isclose(item['scale_x'],item['scale_y']):
            x,y=item['coords'];s=item['scale_x'];a=math.radians(item.get('angle',0));cs,sn=math.cos(a),math.sin(a)
            point=lambda p:(x+s*(p[0]*cs-p[1]*sn),y+s*(p[0]*sn+p[1]*cs))
            item['block_geometry']=[transform(child,point,s,item.get('angle',0)) for child in definition]
            item['block_definition']=copy.deepcopy(definition);item['preview_note']=''
        return []
    if kind=='MTEXT':return []
    pick=item['coords'][:2];base=item['coords'][2:4]
    if item.get('selection_ref'):
        from selection_sets import selected_members
        selected=selected_members(item,values)
    elif item.get('selection_box'):selected=select_range(items,item['selection_box'],item['selection_mode'])
    else:
        candidates=[s for s in entities(items) if not s.get('guide') and general_distance(pick,s)<=tolerance]
        selected=candidates if len(candidates)==1 else []
        if selected and selected[0].get('display_type',selected[0]['type'])=='LINE' and len(segments(selected[0]))>1:
            parent=selected[0];paths=[line for line in segments(parent) if distance(pick,dict(type='LINE',coords=line))<=tolerance]
            selected=[dict(parent,coords=paths[0],segments=[],entity_parent=parent,entity_segment=paths[0],point_id=None)] if len(paths)==1 else []
    if not selected:return []
    multiplier=item.get('copy_count',item.get('rows',1)*item.get('columns',1)-1) if kind in ('ROTATECOPY','ARRAYRECT') else 1
    if len(selected)*multiplier>MAX_SELECTED:raise ValueError('作成する複製は1000図形までです')
    if kind in ('ROTATECOPY','ARRAYRECT') and sum(len(source['coords'])//2 for source in selected)*multiplier>50000:raise ValueError('複製後の合計頂点は50000点までです')
    overrides=item.get('overrides',())
    def styled(geometry):
        for key in overrides:
            for field in (('layer','effective_layer') if key=='layer' else (key,)):
                if field in item:geometry[field]=item[field]
        return geometry
    def rotate(angle):
        a=math.radians(angle);cs,sn=math.cos(a),math.sin(a)
        return lambda p:(base[0]+(p[0]-base[0])*cs-(p[1]-base[1])*sn,base[1]+(p[0]-base[0])*sn+(p[1]-base[1])*cs)
    def child(geometry):
        return dict({key:value for key,value in item.items() if key in ('row','command_path','loop_index')},**styled(geometry))
    changed=[];children=[]
    if kind=='CADBLOCK':
        name=item['block_name']
        if name in registry:raise ValueError('CADブロック名が重複しています。行ごとに名前を変える場合は =@TYPE などを指定してください')
        definition=[transform(source,lambda p:(p[0]-base[0],p[1]-base[1])) for source in selected]
        registry[name]=copy.deepcopy(definition)
        item.update(display_type='INSERT',coords=base,text=name,block_name=name,block_definition=definition,
                    block_geometry=[transform(source,lambda p:p) for source in selected],preview_note='')
        return [delete_entity(source) for source in selected]
    for source in selected:
        source_kind=source.get('display_type',source['type'])
        if kind in ('ROTATE','SCALE'):
            factor=item.get('factor',1.);point=rotate(item['angle']) if kind=='ROTATE' else lambda p:(base[0]+(p[0]-base[0])*factor,base[1]+(p[1]-base[1])*factor)
            geometry=styled(transform(source,point,factor,item.get('angle',0)))
            if source.get('entity_parent') is not None:
                parent=source['entity_parent'];paths=[geometry['coords'] if tuple(s)==tuple(source['entity_segment']) else s for s in segments(parent)]
                parent['coords']=tuple(z for s in paths for z in s)
                if len(paths)>1:parent['segments']=paths
                else:parent.pop('segments',None)
                source.update(geometry);source['entity_segment']=tuple(geometry['coords'])
                changed.append(parent)
            else:source.update(geometry);changed.append(source)
        elif kind=='ROTATECOPY':
            for step in range(1,item['copy_count']+1):children.append(child(transform(source,rotate(item['angle']*step),turn=item['angle']*step)))
        elif kind=='ARRAYRECT':
            for row in range(item['rows']):
                for column in range(item['columns']):
                    if row==0 and column==0:continue
                    dx=column*item['column_spacing'];dy=row*item['row_spacing']
                    children.append(child(transform(source,lambda p:(p[0]+dx,p[1]+dy))))
        elif kind=='EXPLODE':
            geometries=[]
            if source_kind=='INSERT' and source.get('block_geometry'):geometries=copy.deepcopy(source['block_geometry'])
            elif source_kind in ('POLYLINE','RECTANGLE'):
                geometries=[dict(source,type='LINE',display_type='LINE',coords=s,segments=[],closed=False) for s in segments(source)]
            elif source_kind=='MTEXT':
                x,y,h=source['coords'];a=math.radians(source.get('angle',0))
                geometries=[dict(source,type='TEXT',display_type='TEXT',coords=(x+i*h*1.4*math.sin(a),y-i*h*1.4*math.cos(a),h),text=text) for i,text in enumerate(mtext_lines(source['text'],source['width'],h)) if text]
            elif source_kind in ('LINE','CIRCLE','ARC','ELLIPSE','SPLINE','POINT','TEXT'):raise ValueError('この図形は分解できません。ポリラインやCADブロックなどを選択してください')
            if geometries:
                for geometry in geometries:
                    geometry={key:value for key,value in geometry.items() if key not in ('point_id','block_index','command_index','entity_parent','entity_segment','reference_points','children')}
                    children.append(child(geometry))
                changed.append(delete_entity(source))
    if children:
        if len(children)>MAX_SELECTED:raise ValueError('作成・分解する結果は1000図形までです')
        item.update(children=children,preview_note=f'{len(children)}図形の結果を表示')
    elif changed:item.update(preview_applied=True,preview_note='操作後の形状を表示')
    return changed
