"""Describe the preview compiler's known inherited values without guessing CAD defaults."""
from cad_colors import BASIC

KEYS={'layer':'effective_layer','linetype':'linetype','color':'color',
      'linetype_scale':'linetype_scale','text_style':'text_style','dim_style':'dim_style'}


def inheritance_hint(field,state):
    value=state.get(KEYS[field])
    if value is None:
        shown='未取得'
    elif field=='color':
        code=int(value)
        name={256:'ByLayer',0:'ByBlock'}.get(code,BASIC.get(code,('',))[0])
        shown=str(code)+('：'+name if name else '')
    elif isinstance(value,(int,float)):
        shown=format(value,'.12g')
    else:
        shown=str(value)
    return shown+'（現在値）'
