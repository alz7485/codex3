"""Preserve single-line DXF text alignment and per-entity formatting in SCR."""
import math
from extended_commands import quoted, current_properties_lisp


def text_form(command, x, y, height, angle, content, number):
    def n(key, default):return float(number(command.get(key, str(default))))
    h, v = n('text_halign', 0), n('text_valign', 0)
    flags = n('text_generation', 0)
    width, oblique = n('text_width', 1), n('text_oblique', 0)
    if h not in (0,1,2,4) or v not in (0,1,2,3) or flags not in (0,2,4,6) or width<=0 or not -85<=oblique<=85:
        raise ValueError('読込文字の配置・幅・傾斜を確認してください')
    point=f'(list {x} {y} 0.0)'
    body='((lambda (/ entity result cc rgb clr) (vl-load-com) '
    body+=f'(setq entity (entmakex (list \'(0 . "TEXT") (cons 10 {point}) (cons 11 {point}) (cons 40 {height}) (cons 1 {quoted(content)}) (cons 7 (getvar "TEXTSTYLE")) (cons 50 {math.radians(float(angle)):.15g}) (cons 41 {width:.15g}) (cons 51 {math.radians(oblique):.15g}) \'(72 . {int(h)}) \'(73 . {int(v)}) \'(71 . {int(flags)})))) '
    body+='(if (not entity) (error "AcadStadio: Cannot create imported text")) (setq result (vlax-ename->vla-object entity)) '
    body+=current_properties_lisp('result')+'))'
    horizontal='w' if h==0 else 'e' if h==2 else ''
    vertical='s' if v in (0,1) else 'n' if v==3 else ''
    anchor=(vertical+horizontal) or 'center'
    return body, anchor
