"""Editable JIS fitting sample flows, built from sourced numerical tables."""
import copy,json
from theme import ROOT
from flange_sample import appearance,line

FAMILY_NAMES={'elbow':'エルボ','reducer':'レジューサ','tee':'ティー','cap':'キャップ'}


def catalog():
    return json.loads((ROOT/'assets'/'jis_fittings_dimensions.json').read_text(encoding='utf-8'))


def branch(test,yes,no=()):return dict(type='IF',condition=test,commands=yes,**{'else':list(no)})
def circle(x,y,r,layer='OUTLINE'):return dict(type='CIRCLE',layer=layer,x=x,y=y,r=r,**appearance(layer))
def poly(points,layer='OUTLINE',closed=False):return dict(type='POLYLINE',layer=layer,points=';'.join(x+','+y for x,y in points),vertices=[dict(x=x,y=y) for x,y in points],closed='1' if closed else '0',**appearance(layer))
def arc(x,y,r,start,end,layer='OUTLINE'):return dict(type='ARC',layer=layer,x=x,y=y,r=r,start_angle=start,end_angle=end,**appearance(layer))
def dim(x1,y1,x2,y2,x3,y3):return dict(type='DIMLINEAR',layer='DIM',x1=x1,y1=y1,x2=x2,y2=y2,x3=x3,y3=y3,**appearance('DIM'))
def note(x,y,text):return dict(type='MTEXT',layer='DIM',x=x,y=y,text=text,height='settings.TEXT_HEIGHT',width='300',angle='0',**appearance('DIM'))


def sample_rows(family,records):
    result=[]
    for original in records:
        data={k:'0' if v is None else format(v,'.12g') if isinstance(v,(int,float)) else str(v) for k,v in original.items()}
        a=data['A'];schedule=data['SCHEDULE']
        if family=='elbow':
            variants=[(f'{angle}° {"ロング" if data["RADIUS_KIND"]=="LONG" else "ショート"}',dict(ANGLE=str(angle))) for angle in ((45,90,180) if float(data.get('H','0'))>0 else (90,180))]
        elif family=='reducer':variants=[('同心',dict(ECCENTRIC='0')),('偏心',dict(ECCENTRIC='1'))]
        elif family=='tee':variants=[('同径' if data['A']==data['A2'] else '径違い',{})]
        else:variants=[('',{})]
        for label,extra in variants:
            size=a if 'A2' not in data else a+'×'+data['A2']
            result.append(dict(TYPE=f'{FAMILY_NAMES[family]} {label} {size}A Sch{schedule}'.replace('  ',' '),FAMILY=family,X='150',Y='100',**data,**extra))
    # Show a useful mid-size first; keep the rest ordered by source.
    def preferred(row):return row['A']=='50' and row['SCHEDULE']=='40' and (family!='elbow' or row['ANGLE']=='90' and row['RADIUS_KIND']=='LONG') and (family!='reducer' or row['A2']=='25' and row['ECCENTRIC']=='0') and (family!='tee' or row['A2']=='50')
    first=next((i for i,r in enumerate(result) if preferred(r)),0)
    if result:result.insert(0,result.pop(first))
    return result


def elbow_commands():
    r='(@F+(@H/tan(radians(22.5))-@F)*(@ANGLE==45))'
    commands=[]
    for dia,layer in [('@OD','OUTLINE'),('@ID','HOLES')]:
        for sign in ('-','+'):
            commands.append(arc('@X','@Y',f'{r}{sign}{dia}/2','0','@ANGLE',layer))
    for angle in ('0','@ANGLE'):
        commands.append(line(f'@X+({r}-@OD/2)*cos(radians({angle}))',f'@Y+({r}-@OD/2)*sin(radians({angle}))',f'@X+({r}+@OD/2)*cos(radians({angle}))',f'@Y+({r}+@OD/2)*sin(radians({angle}))','OUTLINE'))
    commands.append(arc('@X','@Y',r,'0','@ANGLE','CENTER'))
    ex=f'@X+{r}+@OD+settings.VIEW_GAP'
    commands.extend([circle(ex,'@Y','@OD/2'),circle(ex,'@Y','@ID/2','HOLES'),line(f'({ex})-@OD/2-6','@Y',f'({ex})+@OD/2+6','@Y'),line(ex,'@Y-@OD/2-6',ex,'@Y+@OD/2+6'),note('@X','@Y-@OD/2-15',"=@TYPE+'\\nJIS B 2312 / 曲げ側面・端面'"),dim(ex,'@Y-@OD/2',ex,'@Y+@OD/2',f'({ex})+@OD/2+12','@Y')])
    return commands


def reducer_commands():
    d='(-(@OD-@OD2)/2*@ECCENTRIC)'
    commands=[poly([('@X','@Y-@OD/2'),('@X+@H',f'@Y+{d}-@OD2/2'),('@X+@H',f'@Y+{d}+@OD2/2'),('@X','@Y+@OD/2')],closed=True)]
    for sign in ('-','+'):commands.append(line('@X',f'@Y{sign}@ID/2','@X+@H',f'@Y+{d}{sign}@ID2/2','HOLES'))
    commands.extend([line('@X-6','@Y','@X+@H+6',f'@Y+{d}'),dim('@X','@Y-@OD/2','@X+@H',f'@Y+{d}-@OD2/2','@X+@H/2','@Y-@OD/2-15')])
    ex='@X+@H+@OD/2+settings.VIEW_GAP'
    commands.extend([circle(ex,'@Y','@OD/2'),circle(ex,'@Y','@ID/2','HOLES'),circle(ex,f'@Y+{d}','@OD2/2'),circle(ex,f'@Y+{d}','@ID2/2','HOLES'),line(f'({ex})-@OD/2-6','@Y',f'({ex})+@OD/2+6','@Y'),line(ex,'@Y-@OD/2-6',ex,'@Y+@OD/2+6'),note('@X','@Y-@OD/2-35',"=@TYPE+'\\nJIS B 2312 / テーパ輪郭は模式表示' ")])
    return commands


def tee_commands():
    commands=[poly([('@X-@C','@Y-@OD/2'),('@X+@C','@Y-@OD/2'),('@X+@C','@Y+@OD/2'),('@X+@OD2/2','@Y+@OD/2'),('@X+@OD2/2','@Y+@M'),('@X-@OD2/2','@Y+@M'),('@X-@OD2/2','@Y+@OD/2'),('@X-@C','@Y+@OD/2')],closed=True),line('@X-@C','@Y-@ID/2','@X+@C','@Y-@ID/2','HOLES'),line('@X-@C','@Y+@ID/2','@X-@ID2/2','@Y+@ID/2','HOLES'),line('@X+@ID2/2','@Y+@ID/2','@X+@C','@Y+@ID/2','HOLES')]
    for sign in ('-','+'):commands.append(line(f'@X{sign}@ID2/2','@Y+@ID/2',f'@X{sign}@ID2/2','@Y+@M','HOLES'))
    ex='@X+@C+@OD/2+settings.VIEW_GAP'
    commands.extend([line('@X-@C-6','@Y','@X+@C+6','@Y'),line('@X','@Y-6','@X','@Y+@M+6'),circle(ex,'@Y','@OD/2'),circle(ex,'@Y','@ID/2','HOLES'),line(f'({ex})-@OD/2-6','@Y',f'({ex})+@OD/2+6','@Y'),line(ex,'@Y-@OD/2-6',ex,'@Y+@OD/2+6'),dim('@X-@C','@Y-@OD/2','@X+@C','@Y-@OD/2','@X','@Y-@OD/2-15'),note('@X-@C','@Y-@OD/2-35',"=@TYPE+'\\nJIS B 2312 / C・M・端面寸法。交差部は模式輪郭' ")])
    return commands


def cap_commands():
    length='(@E+(@E1-@E)*(@LIMIT>0 and @T>@LIMIT))'
    wall='((@OD-@ID)/2)';a='(@ID/4)';b='(@ID/2)';neck=f'({length}-{a}-{wall})'
    inside=[];outside=[]
    for degree in range(-90,91):
        c=f'cos(radians({degree}))';s=f'sin(radians({degree}))'
        norm=f'sqrt(({c}/{a})**2+({s}/{b})**2)'
        inside.append((f'@X+{neck}+{a}*{c}',f'@Y+{b}*{s}'))
        outside.append((f'@X+{neck}+{a}*{c}+{wall}*({c}/{a})/{norm}',f'@Y+{b}*{s}+{wall}*({s}/{b})/{norm}'))
    commands=[poly([('@X','@Y-@OD/2'),*outside,('@X','@Y+@OD/2')]),poly([('@X','@Y-@ID/2'),*inside,('@X','@Y+@ID/2')],'HOLES'),line('@X','@Y-@OD/2','@X','@Y+@OD/2','OUTLINE'),line('@X-6','@Y',f'@X+{length}+6','@Y')]
    ex=f'@X+{length}+@OD/2+settings.VIEW_GAP'
    commands.extend([circle(ex,'@Y','@OD/2'),circle(ex,'@Y','@ID/2','HOLES'),line(f'({ex})-@OD/2-6','@Y',f'({ex})+@OD/2+6','@Y'),line(ex,'@Y-@OD/2-6',ex,'@Y+@OD/2+6'),dim('@X','@Y-@OD/2',f'@X+{length}','@Y-@OD/2',f'@X+{length}/2','@Y-@OD/2-15'),note('@X','@Y-@OD/2-35',"=@TYPE+'\\nJIS B 2312 / E・E1を厚さで切替。内面半だ円比2:1' ")])
    return commands

BUILDERS={'elbow':elbow_commands,'reducer':reducer_commands,'tee':tee_commands,'cap':cap_commands}


def build_piping_sample(base,families=None):
    source=catalog()['catalog'];wanted=list(families or FAMILY_NAMES)
    project=copy.deepcopy(base)
    project['globals']={'SCALE':'1'}
    project['settings'].update(TEXT_HEIGHT='4',VIEW_GAP='35')
    project['input_tables']=[];project['drawing']={'targets':{}}
    for family in wanted:
        rows=sample_rows(family,source[family]['rows']);table_id='jis_'+family
        project['input_tables'].append(dict(id=table_id,name=FAMILY_NAMES[family]+'・JIS寸法',rows=rows))
        project['drawing']['targets'][table_id]=dict(mode='selected',range='',selected=[0])
    project['active_table']=project['input_tables'][0]['id']
    project['blocks']=[dict(id='jis_'+family+'_flow',name=FAMILY_NAMES[family],condition=f"@FAMILY == '{family}'",commands=BUILDERS[family]()) for family in wanted]
    project['sample_info']=dict(title='JIS配管継手',standard='JIS B 2312:2015',sources={key:source[key]['source_url'] for key in wanted},scope='出典掲載分のSch5S・10S・20S・40・80・160。JIS対象外注記の行を除外。輪郭は接続寸法の作図例で、製造用の完全な形状規定ではありません。')
    return project
