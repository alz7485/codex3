"""Transactional block split/join with command identities and point links preserved."""
import copy
from block_model import new_block, nested
from command_points import new_id, rewrite_references
from project_model import validate_sequential_project


def _ordinary(block):
    if block.get('guide'):
        raise ValueError('ガイドブロックは分割・結合できません。作図ブロックを選択してください。')
    if block.get('variables') or any(c.get('type') == 'SET' for c in nested(block.get('commands', []))):
        raise ValueError('ブロック内で定義する変数があるため、計算範囲を保って分割・結合できません。表やプロジェクトの変数に置き換えてください。')


def _name(project, name, exclude=()):
    name = name.strip()
    if not name:
        raise ValueError('ブロック名を入力してください。')
    if any(b['id'] not in exclude and b['name'].casefold() == name.casefold() for b in project['blocks']):
        raise ValueError('同じ名前のブロックがあります。別の名前を入力してください。')
    return name


def suggested_name(project, base):
    names = {b['name'].casefold() for b in project['blocks']}
    name = base
    index = 2
    while name.casefold() in names:
        name = f'{base} ({index})'; index += 1
    return name


def _remap(project, owners):
    """Owners maps original top-level command objects to their destination block IDs."""
    registry = {}
    used = {}
    selection_ids = {}
    for block in project['blocks']:
        for top in block['commands']:
            owner = owners.get(id(top), block['id'])
            for cmd in nested([top]):
                identity = cmd.get('point_id')
                if not identity:
                    continue
                taken = used.setdefault(owner, set())
                new = identity if identity not in taken else new_id()
                taken.add(new)
                registry[block['id'], identity] = (owner, new)
                if cmd.get('type') == 'SELECT':
                    if identity in selection_ids:
                        raise ValueError('SELECTの識別子が重複しています。重複したSELECTを作り直してから実行してください。')
                    selection_ids[identity] = new
    maps = {}
    for block in project['blocks']:
        old_owner = block['id']
        rewritten = []
        for top in block['commands']:
            owner = owners.get(id(top), old_owner)
            key = (old_owner, owner)
            if key not in maps:
                mapping = {}
                for (origin, identity), (destination, new) in registry.items():
                    value = new if destination == owner else destination + '/' + new
                    mapping[origin + '/' + identity] = value
                    if origin == old_owner:
                        mapping[identity] = value
                maps[key] = mapping
            mapping = maps[key]
            result = rewrite_references(top, mapping)
            for before, after in zip(nested([top]), nested([result])):
                if before.get('point_id'):
                    after['point_id'] = registry[old_owner, before['point_id']][1]
                if 'selection_ref' in before:
                    after['selection_ref'] = selection_ids.get(before['selection_ref'], before['selection_ref'])
            rewritten.append(result)
        block['commands'] = rewritten
        # Block conditions may themselves use preceding-block point references.
        absolute = {origin + '/' + identity: destination + '/' + new
                    for (origin, identity), (destination, new) in registry.items()}
        block['condition'] = rewrite_references(block.get('condition', ''), absolute)


def _checked(project):
    errors = validate_sequential_project(project)
    if errors:
        raise ValueError('\n'.join(errors[:6]))
    return project


def split_block(project, index, start, name):
    """Return a copy: start is the zero-based first command in the new second block."""
    trial = copy.deepcopy(project)
    if type(index) is not int or not 0 <= index < len(trial['blocks']):
        raise ValueError('分割するブロックを選択してください。')
    block = trial['blocks'][index]
    _ordinary(block)
    if type(start) is not int or not 1 <= start < len(block['commands']):
        raise ValueError('後半の先頭にするコマンドを、2件目以降から選択してください。')
    name = _name(trial, name)
    new = copy.deepcopy(block)
    new.update(id=new_block()['id'], name=name)
    owners = {id(command): new['id'] for command in block['commands'][start:]}
    _remap(trial, owners)
    new['commands'] = block['commands'][start:]
    block['commands'] = block['commands'][:start]
    new['condition'] = block['condition']
    trial['blocks'].insert(index + 1, new)
    return _checked(trial)


def join_blocks(project, indices, name):
    if any(type(i) is not int or not 0 <= i < len(project['blocks']) for i in indices):
        raise ValueError('結合するブロックを選択してください。')
    indices = sorted(set(indices))
    if len(indices) < 2:
        raise ValueError('結合するブロックを2件以上選択してください。')
    if indices != list(range(indices[0], indices[-1] + 1)):
        raise ValueError('作図順を保つため、一覧で連続するブロックを選択してください。')
    trial = copy.deepcopy(project)
    chosen = [trial['blocks'][i] for i in indices]
    for block in chosen:
        _ordinary(block)
    if len({b.get('condition', '').strip() for b in chosen}) != 1:
        raise ValueError('実行条件が異なります。同じ条件のブロックを選択してください。')
    first = chosen[0]
    name = _name(trial, name, [b['id'] for b in chosen])
    owners = {id(command): first['id'] for b in chosen for command in b['commands']}
    _remap(trial, owners)
    first['name'] = name
    first['commands'] = [cmd for b in chosen for cmd in b['commands']]
    del trial['blocks'][indices[0] + 1:indices[-1] + 1]
    return _checked(trial)
