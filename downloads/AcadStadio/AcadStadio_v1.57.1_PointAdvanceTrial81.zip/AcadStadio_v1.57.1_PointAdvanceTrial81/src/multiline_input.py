"""StringVar-backed text input with the small Entry API used by the workbench."""
import tkinter as tk

class MultilineInput(tk.Text):
    def __init__(self,parent,variable):
        super().__init__(parent,height=4,width=1,wrap='word',font='TkDefaultFont',background='white',foreground='#192c42',
                         relief='flat',borderwidth=0,highlightthickness=1,highlightbackground='#b8cbe1',highlightcolor='#2463eb',padx=6,pady=6)
        self.variable=variable;self.busy=True
        super().insert('1.0',variable.get());self.edit_modified(False);self.busy=False
        self.trace=variable.trace_add('write',self.from_variable)
        self.bind('<<Modified>>',self.modified)
        self.bind('<Destroy>',self.cleanup,add='+')
        self.bind('<MouseWheel>',self.wheel)
        self.bind('<Button-4>',lambda e:self.scroll(-1))
        self.bind('<Button-5>',lambda e:self.scroll(1))
    def scroll(self,direction):self.yview_scroll(direction,'units');return 'break'
    def wheel(self,event):return self.scroll(-1 if event.delta>0 else 1)
    @staticmethod
    def position(index):return '1.0' if index in (0,'0') else index
    def get(self,start='1.0',end='end-1c'):return super().get(self.position(start),self.position(end))
    def sync(self):
        if self.busy:return
        self.busy=True
        try:self.variable.set(super().get('1.0','end-1c'));self.edit_modified(False)
        finally:self.busy=False
    def insert(self,index,text,*args):
        super().insert(self.position(index),text,*args);self.sync()
    def delete(self,start,end=None):
        super().delete(self.position(start),self.position(end) if end is not None else None);self.sync()
    def from_variable(self,*_):
        if self.busy:return
        self.busy=True
        try:
            super().delete('1.0','end');super().insert('1.0',self.variable.get());self.edit_modified(False)
        finally:self.busy=False
    def modified(self,event=None):
        if self.edit_modified():self.sync()
    def selection_present(self):return bool(self.tag_ranges('sel'))
    def icursor(self,index):self.mark_set('insert',self.position(index))
    def cleanup(self,event):
        if event.widget is self:self.variable.trace_remove('write',self.trace)
