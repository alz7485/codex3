"""Edit the definition behind a rendered figure without opening a block window."""
import copy
from flow import execution_address, resolve
from project_model import validate_sequential_project
from macro_editor import edit_command


def command_address(project, item):
    traces=item.get('command_addresses')
    address=tuple(traces[-1]) if traces else execution_address(project,item['block_index'],item['command_path'])
    if len(address)<4 or address[0]!='blocks' or address[2]!='commands':
        raise ValueError('この図形の編集元を取得できません。')
    resolve(project,address)
    return address


def edit_rendered_command(parent, project, item):
    """Return a changed copy, or None on cancel. Original state is never mutated."""
    trial=copy.deepcopy(project)
    address=command_address(trial,item)
    block=trial['blocks'][address[1]];owner=block['id']
    collection=block['commands'];prefix=[];counts=[]
    for offset in range(3,len(address),2):
        index=address[offset]
        prefix.extend(collection[:index])
        if offset+1<len(address):
            command=collection[index]
            if command['type']=='REPEAT':counts.append(str(command['count']))
            collection=command[address[offset+1]]
    previous=trial['blocks'][:address[1]]
    command=resolve(trial,address)
    row=int(item.get('row',0))
    result=edit_command(parent,command,trial['blocks'],trial,
                        sample_locals=block.get('variables',{}),local_names=block.get('variables',{}),
                        folder_id=block.get('folder_id',''),point_sources=prefix,
                        previous_blocks=previous,owner_block_id=owner,
                        repeat_counts=tuple(counts),initial_row=row)
    if result is None:return None
    address=(address[0],next(i for i,b in enumerate(trial['blocks']) if b['id']==owner),*address[2:])
    target=resolve(trial,address[:-1]);target[address[-1]:address[-1]+1]=result if isinstance(result,list) else [result]
    errors=validate_sequential_project(trial)
    if errors:raise ValueError('\n'.join(errors[:6]))
    return trial
