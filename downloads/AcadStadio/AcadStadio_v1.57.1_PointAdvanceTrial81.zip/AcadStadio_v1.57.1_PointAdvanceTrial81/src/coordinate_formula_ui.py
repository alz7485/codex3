"""Plain-language coordinate recipes with a live placement preview."""
import tkinter as tk
from tkinter import ttk
from coordinate_formulas import MODES,PARAMETERS,formulas,positions,read_formulas,repeat_context
from engine import evaluate
from preview import DrawingCanvas
from theme import fit_window
from workbench_style import VerticalForm
from input_assist import show_table_reference_picker,reference_groups
from command_workbench import show_reference_list,restore_parent_grab
from reference_colors import add_reference_color
from ui_icons import icons_for


class CoordinateFormulaDialog(tk.Toplevel):
    def __init__(self,parent,project,current,context,repeat_counts=()):
        super().__init__(parent)
        self.title('座標の式を作る');self.transient(parent.winfo_toplevel());self.grab_set()
        fit_window(self,1000,740,840,560)
        self.project=project;self.context=context;self.repeat_counts=tuple(repeat_counts);self.result=None
        self.params={};self.drafts={};self.updating=True;self.valid=None;self.samples=[]
        self.mode=tk.StringVar();self.direction=tk.StringVar(value='反時計回り');self.size_mode=tk.StringVar(value='半径')
        self.show_expression=tk.BooleanVar(value=False);self.status=tk.StringVar();self.count_label=tk.StringVar()
        footer=ttk.Frame(self,padding=12);footer.pack(side='bottom',fill='x')
        ttk.Button(footer,text='キャンセル',command=self.destroy).pack(side='left')
        self.apply_button=ttk.Button(footer,text='X・Yに反映',command=self.commit,style='WorkbenchPrimary.TButton');self.apply_button.pack(side='right')
        body=ttk.Frame(self,padding=(12,12,12,0));body.pack(fill='both',expand=True)
        body.columnconfigure(0,weight=2);body.columnconfigure(1,weight=3);body.rowconfigure(0,weight=1)
        scroll=VerticalForm(body);scroll.grid(row=0,column=0,sticky='nsew',padx=(0,10));left=scroll.content
        top=ttk.Frame(left,style='PointCard.TFrame',padding=10);top.pack(fill='x',pady=(0,8))
        ttk.Label(top,text='指定方法',style='CardTitle.TLabel').pack(anchor='w',pady=(0,5))
        choices=MODES if repeat_counts else MODES[:2]
        self.mode_picker=ttk.Combobox(top,textvariable=self.mode,values=choices,state='readonly');self.mode_picker.pack(fill='x')
        self.mode_picker.bind('<<ComboboxSelected>>',self.change_mode)
        ttk.Label(top,textvariable=self.count_label,style='CardMuted.TLabel').pack(anchor='w',pady=(5,0))
        self.fields=ttk.Frame(left,style='PointCard.TFrame',padding=10);self.fields.pack(fill='x')
        self.options=ttk.Frame(left,style='PointCard.TFrame',padding=10);self.options.pack(fill='x',pady=(8,0))
        ttk.Label(self.options,text='円周の指定',style='CardTitle.TLabel').pack(anchor='w')
        for title,variable,values in [('サイズ',self.size_mode,('半径','直径')),('回る向き',self.direction,('反時計回り','時計回り'))]:
            row=ttk.Frame(self.options,style='Card.TFrame');row.pack(fill='x',pady=4)
            ttk.Label(row,text=title,width=10).pack(side='left')
            ttk.Combobox(row,textvariable=variable,values=values,state='readonly',width=12).pack(side='left',fill='x',expand=True)
        ttk.Checkbutton(left,text='作成される式を表示',variable=self.show_expression,command=self.show_generated).pack(anchor='w',pady=8)
        self.generated=ttk.Frame(left)
        self.generated_text=tk.Text(self.generated,height=5,wrap='word',relief='solid',borderwidth=1,state='disabled')
        self.generated_text.pack(fill='x')
        right=ttk.Frame(body);right.grid(row=0,column=1,sticky='nsew')
        self.canvas=DrawingCanvas(right,workspace=True);self.canvas.pack(fill='both',expand=True)
        self.table=ttk.Treeview(right,columns=('number','x','y'),show='headings',height=6)
        for key,title,width in [('number','順番',60),('x','X',150),('y','Y',150)]:self.table.heading(key,text=title);self.table.column(key,width=width,anchor='center',stretch=key!='number')
        self.table.pack(fill='x',pady=(8,0))
        ttk.Label(right,textvariable=self.status,wraplength=500,style='Muted.TLabel').pack(fill='x',pady=(6,0))
        existing=read_formulas(*current)
        selected=existing[0] if existing and existing[0] in choices else MODES[2] if repeat_counts else MODES[0]
        defaults=existing[1] if existing and selected==existing[0] else {axis:value for axis,value in zip(('x','y'),current) if 'loop.' not in value}
        self.drafts[selected]=defaults;self.mode.set(selected);self.active=selected
        self.direction.set(defaults.get('direction','反時計回り'));self.size_mode.set(defaults.get('size_mode','半径'))
        self.draw_fields();self.updating=False
        self.direction.trace_add('write',lambda *_:self.refresh());self.size_mode.trace_add('write',lambda *_:self.refresh())
        self.bind('<Escape>',lambda _:self.destroy());self.refresh()

    def change_mode(self,event=None):
        self.drafts[self.active]={key:variable.get() for key,variable in self.params.items()}
        self.active=self.mode.get();self.draw_fields();self.refresh()

    def draw_fields(self):
        self.updating=True
        for child in self.fields.winfo_children():child.destroy()
        self.params={};self.radius_label=None
        draft=self.drafts.get(self.mode.get(),{})
        for key,label,default in PARAMETERS[self.mode.get()]:
            row=ttk.Frame(self.fields,style='Card.TFrame');row.pack(fill='x',pady=(0,8))
            head=ttk.Frame(row,style='Card.TFrame');head.pack(fill='x',pady=(0,4))
            caption=ttk.Label(head,text=label,style='CardMuted.TLabel');caption.pack(side='left')
            if key=='radius':self.radius_label=caption
            variable=tk.StringVar(value=draft.get(key,default));self.params[key]=variable
            entry=ttk.Entry(row,textvariable=variable,width=1);entry.pack(fill='x')
            add_reference_color(entry,variable,self.project.get('globals',{}))
            def table(v=variable):show_table_reference_picker(self,self.project,v.set,on_replace=v.set)
            def named(v=variable):show_reference_list(self,[(title,refs) for title,refs in reference_groups(self.project) if title in ('変数','共通設定')],v.set)
            for text,icon,action in [('表','table',table),('変数','variables',named)]:
                ttk.Button(head,text=text,image=icons_for(self).get(icon),compound='left',style='WorkbenchRef.TButton',command=action).pack(side='left',padx=(4,0))
            variable.trace_add('write',lambda *_:self.refresh())
        if self.mode.get()==MODES[4]:self.options.pack(fill='x',pady=(8,0),after=self.fields)
        else:self.options.pack_forget()
        self.updating=False

    def refresh(self):
        if self.updating:return
        try:
            parameters={key:variable.get() for key,variable in self.params.items()}
            parameters.update(direction=self.direction.get(),size_mode=self.size_mode.get())
            if self.radius_label:self.radius_label.configure(text='配置円の'+self.size_mode.get())
            generated=formulas(self.mode.get(),parameters)
            context=self.context();loop=repeat_context(context,self.repeat_counts,allow_zero=True) if self.repeat_counts else None
            count=loop['count'] if loop else 1
            self.count_label.set(f'繰り返し：{count}回（親コマンドの設定）' if loop else 'この位置を1つ指定します')
            points=positions(self.mode.get(),parameters,context,count)
            if count:
                base=[evaluate(parameters[k],dict(context,__loop__=loop)) if loop else evaluate(parameters[k],context) for k in ('x','y')]
                visible=sorted(set(round(i*(count-1)/min(99,count-1)) for i in range(min(count,100)))) if count>1 else [0]
                items=[dict(type='POINT',coords=tuple(base),layer='基準位置')]+[dict(type='POINT',coords=points[i],layer='配置位置') for i in visible]
                if self.mode.get()==MODES[4]:
                    radius=evaluate(parameters['radius'],context)/(2 if self.size_mode.get()=='直径' else 1)
                    items.insert(0,dict(type='CIRCLE',coords=(*base,radius),layer='配置円'))
                self.canvas.set_items(items)
            else:self.canvas.set_items([],message='0回のため配置されません')
            self.table.delete(*self.table.get_children())
            for i,point in enumerate(points[:6]):self.table.insert('','end',values=(i+1,*[f'{v:.10g}' for v in point]))
            self.status.set('入力値からX・Yを作成します。'+('一覧は先頭6回、図は最大100点を表示。' if count>6 else ''))
            self.samples=points;self.valid=generated;self.apply_button.configure(state='normal')
            self.generated_text.configure(state='normal');self.generated_text.delete('1.0','end');self.generated_text.insert('1.0','X：'+generated[0]+'\n\nY：'+generated[1]);self.generated_text.configure(state='disabled')
        except (ValueError,TypeError,KeyError,IndexError,ZeroDivisionError) as exc:
            self.valid=None;self.samples=[];self.apply_button.configure(state='disabled');self.status.set(str(exc))
            self.canvas.set_items([],message='入力内容を確認してください');self.table.delete(*self.table.get_children())

    def show_generated(self):
        if self.show_expression.get():self.generated.pack(fill='x')
        else:self.generated.pack_forget()

    def commit(self):
        self.refresh()
        if self.valid is not None:self.result=self.valid;self.destroy()


def show_coordinate_formulas(parent,project,current,context,repeat_counts=()):
    dialog=CoordinateFormulaDialog(parent,project,current,context,repeat_counts)
    parent.wait_window(dialog);restore_parent_grab(parent)
    return dialog.result
