"""Finite line/circle intersections and tangency, with stable branch identities."""
import ast
import math
from vertex_points import split_top_level


def coordinate(value):
    if isinstance(value,str):value=value.split(',')
    if len(value)!=2:raise ValueError('座標はX,Yで指定してください')
    result=tuple(float(v) for v in value)
    if not all(math.isfinite(v) for v in result):raise ValueError('座標は有限値で指定してください')
    return result


def intersection_candidates(kind,a,b,c,d):
    a,b,c,d=map(coordinate,(a,b,c,d))
    if kind=='CL':return intersection_candidates('LC',c,d,a,b)
    if kind=='LL':
        u=(b[0]-a[0],b[1]-a[1]);v=(d[0]-c[0],d[1]-c[1]);cross=lambda x,y:x[0]*y[1]-x[1]*y[0]
        det=cross(u,v);scale=math.hypot(*u)*math.hypot(*v)
        if not scale or abs(det)<=1e-12*scale:raise ValueError('平行・重複・長さ0の線には一意な交点がありません')
        w=(c[0]-a[0],c[1]-a[1]);t,s=cross(w,v)/det,cross(w,u)/det
        return {'候補A':(a[0]+t*u[0],a[1]+t*u[1])} if -1e-9<=t<=1+1e-9 and -1e-9<=s<=1+1e-9 else {}
    if kind=='LC':
        ux,uy=b[0]-a[0],b[1]-a[1];length2=ux*ux+uy*uy;r=math.dist(c,d)
        if not length2 or not r:raise ValueError('長さ0の線・半径0の円は指定できません')
        t=((c[0]-a[0])*ux+(c[1]-a[1])*uy)/length2
        h2=r*r-(a[0]+t*ux-c[0])**2-(a[1]+t*uy-c[1])**2
        if h2 < -1e-9*max(1,r*r):return {}
        delta=math.sqrt(max(0,h2)/length2)
        return {name:(a[0]+v*ux,a[1]+v*uy) for name,v in [('候補A',t-delta),('候補B',t+delta)] if -1e-9<=v<=1+1e-9}
    if kind=='CC':
        r,s=math.dist(a,b),math.dist(c,d);ux,uy=c[0]-a[0],c[1]-a[1];distance=math.hypot(ux,uy)
        if not r or not s or distance<=1e-12:raise ValueError('同心円・重複円・半径0の円には一意な交点がありません')
        along=(r*r-s*s+distance*distance)/(2*distance);h2=r*r-along*along
        if h2 < -1e-9*max(1,r*r,s*s):return {}
        h=math.sqrt(max(0,h2));x,y=a[0]+along*ux/distance,a[1]+along*uy/distance
        return {'候補A':(x-h*uy/distance,y+h*ux/distance),'候補B':(x+h*uy/distance,y-h*ux/distance)}
    raise ValueError('交点は線分同士・線分と円・円同士に対応しています')


def tangent_candidates(center,radius_point,external):
    c,rp,p=map(coordinate,(center,radius_point,external));r=math.dist(c,rp)
    ux,uy=p[0]-c[0],p[1]-c[1];d2=ux*ux+uy*uy
    if not r or d2<=r*r+1e-10*max(1,r*r):raise ValueError('接点を求める点は円の外側に指定してください')
    a=r*r/d2;b=r*math.sqrt(d2-r*r)/d2;x,y=c[0]+a*ux,c[1]+a*uy
    return {'候補A':(x-b*uy,y+b*ux),'候補B':(x+b*uy,y-b*ux)}


def selected_value(candidates,branch,axis,dx=0,dy=0):
    if branch not in candidates:raise ValueError('選択した交点・接点の候補が成立しません。別の候補には切り替えません')
    if axis not in ('X','Y','XY'):raise ValueError('取得する座標はX・Y・XYで指定してください')
    if any(type(v) not in (int,float) or not math.isfinite(v) for v in (dx,dy)):raise ValueError('移動量は有限の数値で指定してください')
    x,y=candidates[branch];x+=dx;y+=dy
    return f'{x:.12g},{y:.12g}' if axis=='XY' else x if axis=='X' else y


def intersection(kind,a,b,c,d,branch,axis,dx=0,dy=0):
    return selected_value(intersection_candidates(kind,a,b,c,d),branch,axis,dx,dy)


def tangent(center,radius_point,external,branch,axis,dx=0,dy=0):
    return selected_value(tangent_candidates(center,radius_point,external),branch,axis,dx,dy)


def read_relation_reference(text):
    """Read generated expressions without evaluation, preserving table shorthand."""
    from command_points import read_point_reference
    text=text.strip().removeprefix('=').strip()
    function=next((name for name in ('交点','接点') if text.startswith(name+'(')),None)
    if function is None:return None
    quote=None;escaped=False;depth=0;end=None
    for i,char in enumerate(text[len(function):],len(function)):
        if quote:
            if escaped:escaped=False
            elif char=='\\':escaped=True
            elif char==quote:quote=None
        elif char in ('"',"'"):quote=char
        elif char=='(':depth+=1
        elif char==')':
            depth-=1
            if depth==0:end=i;break
    if end is None:return None
    try:
        args=split_top_level(text[len(function)+1:end],',');tail=text[end+1:].strip()
        start=1 if function=='交点' else 0;n=4 if function=='交点' else 3
        if len(args) not in (start+n+2,start+n+4):return None
        refs=[read_point_reference(a) for a in args[start:start+n]]
        if any(r is None for r in refs):return None
        branch,axis=map(ast.literal_eval,args[start+n:start+n+2])
        if branch not in ('候補A','候補B') or axis not in ('X','Y','XY'):return None
        shift=tail[1:].strip() if tail.startswith('+') else '0'
        if shift.startswith('(') and shift.endswith(')'):shift=shift[1:-1]
        if tail and not tail.startswith('+'):return None
        return dict(mode=function,primary=refs[0]['identity'],secondary=refs[2]['identity'],
                    external=refs[2]['point'],branch=branch,axis=axis,
                    offsets=args[start+n+2:] or ([shift,'0'] if axis=='X' else ['0',shift] if axis=='Y' else ['0','0']))
    except (ValueError,IndexError,SyntaxError):return None
