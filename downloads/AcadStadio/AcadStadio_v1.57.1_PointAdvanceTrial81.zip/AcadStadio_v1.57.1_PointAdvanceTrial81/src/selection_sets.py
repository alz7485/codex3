"""Reusable SELECT conditions, native entity sets and preview membership."""
import math
from range_selection import MODES,MAX_SELECTED,box_points,native_selection,select_range,entities
from edit_preview import segments,distance,projection
from transform_preview import general_distance

OPERATORS=frozenset(("COPY","MIRROR","OFFSET","TRIM","EXTEND","ROTATE","ROTATECOPY","ARRAYRECT","EXPLODE","CADBLOCK","SCALE"))
MAX_QUERIES=100
DXF_TYPES={'LINE':'LINE','POLYLINE':'LWPOLYLINE,POLYLINE','RECTANGLE':'LWPOLYLINE,POLYLINE','CIRCLE':'CIRCLE','ARC':'ARC','ELLIPSE':'ELLIPSE','SPLINE':'SPLINE','HATCH':'HATCH','TEXT':'TEXT','MTEXT':'MTEXT','POINT':'POINT','INSERT':'INSERT','LEADER':'LEADER'}


def resolve(command,values,number):
    queries=command.get('selections')
    if not isinstance(queries,list) or not 1<=len(queries)<=MAX_QUERIES:raise ValueError('点または矩形の選択を1〜100件追加してください')
    result=[]
    for query in queries:
        if not isinstance(query,dict) or not isinstance(query.get('mode','point'),str) or query.get('mode','point') not in MODES:raise ValueError('選択条件の形式が不正です')
        hint=query.get('entity_type','')
        if not isinstance(hint,str) or hint and hint not in DXF_TYPES:raise ValueError('選択条件の図形種類が不正です')
        mode=query.get('mode','point')
        if mode=='point':
            try:p=tuple(float(number(query[key],values)) for key in ('x1','y1'))
            except KeyError as exc:raise ValueError('点のXYを指定してください') from exc
            result.append(dict(mode=mode,point=p,entity_type=hint))
        else:result.append(dict(mode=mode,box=box_points(query,number,values),entity_type=hint))
    return result


def canonical_part(parent,line):
    parts=parent.setdefault('_selection_parts',[])
    for part in parts:
        if tuple(part.get('entity_segment',()))==tuple(line) and not part.get('operation_deleted'):return part
    part={key:value for key,value in parent.items() if key not in ('_selection_parts','segments','point_id')}
    part.update(coords=tuple(line),entity_parent=parent,entity_segment=tuple(line),point_id=None)
    parts.append(part);return part


def select_queries(items,queries,tolerance):
    result=[];seen=set()
    for query in queries:
        hint=query.get('entity_type','')
        pool=[s for s in entities(items) if not s.get('guide') and (not hint or s.get('display_type',s['type'])==hint or hint=='POLYLINE' and s.get('display_type',s['type'])=='RECTANGLE')]
        if query['mode']=='point':
            candidates=[s for s in pool if general_distance(query['point'],s)<=tolerance]
            selected=[]
            for source in candidates:
                if source.get('display_type',source['type'])=='LINE' and len(segments(source))>1:
                    selected.extend(canonical_part(source,line) for line in segments(source) if distance(query['point'],dict(type='LINE',coords=line))<=tolerance)
                else:selected.append(source)
            if len(selected)>1:raise ValueError('点の位置で複数図形が重なっています。別の点か矩形を指定してください')
        else:selected=select_range(pool,query['box'],query['mode'])
        for source in selected:
            if source.get('entity_parent') is not None:source=canonical_part(source['entity_parent'],source['entity_segment'])
            key=id(source)
            if key not in seen:seen.add(key);result.append(source)
        if len(result)>MAX_SELECTED:raise ValueError('選択対象は1000図形までです')
    return result


def native_collect(queries,tolerance,destination):
    from extended_commands import selection_lisp
    body='(setq selected (ssadd)) '
    for query in queries:
        if query['mode']=='point':
            body+=selection_lisp(*query['point'],tolerance,'one',general=True,entity_types=DXF_TYPES.get(query.get('entity_type','')))+'(setq part (ssadd one)) '
        else:body+=native_selection(query['box'],query['mode'],'part')
        body+='(setq index 0) (repeat (sslength part) (ssadd (ssname part index) selected) (setq index (1+ index))) '
        body+='(if (> (sslength selected) 1000) (error "AcadStadio: Selected entity count exceeds 1000")) '
    return f'(setq {destination} ((lambda (/ selected part index one ss i e p q found data kind anchor boundary pair) '+body+'selected))) '


def reference_lisp(reference,destination):
    from extended_commands import quoted
    key='*acadstadio-last-selection*' if reference=='@previous' else quoted(reference)
    return (f'(setq {destination} ((lambda (/ key saved selected name) (setq key {key} saved (cdr (assoc key *acadstadio-selections*)) selected (ssadd)) '
            '(if (not saved) (error "AcadStadio: Execute SELECT before this operation")) '
            '(foreach name saved (if (entget name) (ssadd name selected))) '
            '(if (= (sslength selected) 0) (error "AcadStadio: Selected entities were erased; execute SELECT again")) selected))) ')


def selected_members(command,values):
    state=values.setdefault('__selection_state__',dict(sets={},last=None))
    reference=command['selection_ref'];key=state['last'] if reference=='@previous' else reference
    if key not in state['sets']:raise ValueError('先にSELECTコマンドで対象を選択してください')
    result=[]
    if not state['sets'][key]:return []
    for source in state['sets'][key]:
        if source.get('operation_deleted'):continue
        parent=source.get('entity_parent')
        if parent is not None:
            if parent.get('operation_deleted'):continue
            if tuple(source['entity_segment']) not in [tuple(s) for s in segments(parent)]:raise ValueError('選択した線分が変更・分割されています。SELECTを実行し直してください')
        elif source.get('segments'):raise ValueError('選択した図形が分割されています。SELECTを実行し直してください')
        result.append(source)
    if not result:raise ValueError('選択対象が削除されています。SELECTを実行し直してください')
    return result


def emit(command,values,number,items):
    from extended_commands import quoted
    identity=command.get('point_id')
    if not identity:raise ValueError('SELECTの識別IDがありません')
    tolerance=float(number(command.get('pick_tolerance','0.01'),values))
    if not 0<tolerance<=100:raise ValueError('選択許容差は0より大きく100以下にしてください')
    queries=resolve(command,values,number);members=select_queries(items,queries,tolerance)
    state=values.setdefault('__selection_state__',dict(sets={},last=None));state['sets'][identity]=members;state['last']=identity
    body='((lambda (/ chosen index names previous entry) (vl-load-com) '+native_collect(queries,tolerance,'chosen')
    body+='(setq names nil index 0) (repeat (sslength chosen) (setq names (cons (ssname chosen index) names) index (1+ index))) '
    body+=f'(setq entry (cons {quoted(identity)} names) previous (assoc {quoted(identity)} *acadstadio-selections*) *acadstadio-selections* (if previous (subst entry previous *acadstadio-selections*) (cons entry *acadstadio-selections*)) *acadstadio-last-selection* {quoted(identity)})))'
    return [body],dict(type='SELECT',coords=(0.,0.),selection_queries=queries,selected_count=len(members))


def snap_point(point,item):
    kind=item.get('display_type',item['type']);c=item['coords']
    paths=segments(item)
    if paths:
        line=min(paths,key=lambda s:distance(point,dict(type='LINE',coords=s)))
        t=max(0,min(1,projection(point,line)))
        if kind=='LINE' and (t<.02 or t>.98):t=.5
        return (line[0]+t*(line[2]-line[0]),line[1]+t*(line[3]-line[1]))
    if kind in ('TEXT','MTEXT','POINT','INSERT'):return c[:2]
    if kind in ('CIRCLE','ARC'):
        a=math.atan2(point[1]-c[1],point[0]-c[0])
        if kind=='ARC':
            start,end=map(math.radians,c[3:5]);span=(end-start)%(2*math.pi)
            if (a-start)%(2*math.pi)>span:a=min((start,end),key=lambda t:math.dist(point,(c[0]+c[2]*math.cos(t),c[1]+c[2]*math.sin(t))))
        return (c[0]+c[2]*math.cos(a),c[1]+c[2]*math.sin(a))
    if kind=='ELLIPSE':
        a=math.radians(item.get('angle',0));x,y=point[0]-c[0],point[1]-c[1];u=x*math.cos(a)+y*math.sin(a);v=-x*math.sin(a)+y*math.cos(a);t=math.atan2(v/c[3],u/c[2])
        return (c[0]+c[2]*math.cos(t)*math.cos(a)-c[3]*math.sin(t)*math.sin(a),c[1]+c[2]*math.cos(t)*math.sin(a)+c[3]*math.sin(t)*math.cos(a))
    return min(zip(c[::2],c[1::2]),key=lambda p:math.dist(point,p))


def descriptors(previous_blocks,point_sources):
    result=[]
    def walk(commands,label):
        for index,command in enumerate(commands):
            if command.get('type')=='SELECT' and command.get('point_id'):
                result.append((command['point_id'],command.get('selection_name','選択')+' / '+label+str(index+1)))
            walk(command.get('commands',[]),label+str(index+1)+'.')
            walk(command.get('else',[]),label+str(index+1)+'.ELSE.')
    for block in previous_blocks:walk(block.get('commands',[]),block['name']+'・')
    walk(point_sources,'コマンド')
    return result
