"""Real controls for a single drawing row and separately checked drawing rows."""

import copy, json, os, sys
from pathlib import Path
import unittest
from unittest.mock import patch
from tkinter import ttk

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from main import EMPTY
from project_data import add_input_table
from engine import MacroError


@unittest.skipUnless(
    os.environ.get("DISPLAY") or sys.platform == "win32", "GUI display unavailable"
)
class DrawingTargetsGui(unittest.TestCase):
    def setUp(self):
        gui.Gui.setUp(self)
        self.app.edit_target_settings()
        self.root.update()
    tearDown = gui.Gui.tearDown

    def test_spin_buttons_change_one_row_and_its_title_and_reject_multi_input(self):
        spin = self.app.target_window_controls.spin
        self.assertIsInstance(spin, ttk.Spinbox)
        self.root.update()
        up = next(
            (x, y)
            for x in range(spin.winfo_width() - 1, -1, -1)
            for y in range(spin.winfo_height())
            if spin.identify(x, y).endswith("uparrow")
        )
        spin.event_generate("<ButtonPress-1>", x=up[0], y=up[1])
        spin.event_generate("<ButtonRelease-1>", x=up[0], y=up[1])
        self.root.update()
        self.assertEqual(self.app.target_rows(), [1])
        self.assertIn("FL-120", self.app.target_window_controls.title.get())
        self.app.preview(quiet=True)
        self.assertEqual(len(self.app.canvas.items), 45)
        self.app.row_range.set("1,3")
        self.assertIn("行番号は1つ", self.app.target_window_controls.note.cget("text"))
        with self.assertRaises(MacroError):
            self.app.compile()
        self.app.preview(quiet=True)
        self.assertEqual(self.app._script_text, "")
        self.app.row_range.set("")
        self.app.refresh()
        with self.assertRaises(MacroError):
            self.app.target_rows()

    def test_checkbox_clicks_are_staged_and_cancel_does_not_change_targets(self):
        before = copy.deepcopy(self.app.data)
        picker = self.app.choose_drawing_rows()
        self.root.update()
        self.assertEqual(tuple(picker.tree["columns"]), ("check", "row", "title"))
        self.assertEqual(picker.tree.item("1", "values")[2], "FL-120")
        picker.clear_all()
        box = picker.tree.bbox("2", "title")
        picker.tree.event_generate("<ButtonPress-1>", x=box[0] + 5, y=box[1] + 5)
        picker.tree.event_generate("<ButtonRelease-1>", x=box[0] + 5, y=box[1] + 5)
        self.root.update()
        self.assertEqual(picker.checked, {2})
        self.assertEqual(self.app.data, before)
        picker.check_all()
        self.assertEqual(picker.checked, {0, 1, 2})
        picker.cancel()
        self.assertEqual(self.app.data, before)

    def test_applied_checks_survive_edit_selection_save_reload_and_undo(self):
        before = copy.deepcopy(self.app.data)
        history = len(self.app._history)
        picker = self.app.choose_drawing_rows()
        picker.clear_all()
        picker.toggle(0)
        picker.toggle(2)
        picker.apply()
        self.root.update()
        self.assertEqual(self.app.target_rows(), [0, 2])
        self.assertEqual(len(self.app._history), history + 1)
        self.app.table.selection_set("1")
        self.root.update()
        self.assertEqual(self.app.target_rows(), [0, 2])
        self.app.undo_project()
        self.assertEqual(self.app.data, before)
        self.app.redo_project()
        self.assertEqual(self.app.target_rows(), [0, 2])
        path = Path(self.library_dir.name) / "checked.json"
        with patch("tkinter.filedialog.asksaveasfilename", return_value=str(path)):
            self.assertTrue(self.app.save())
        self.app.replace_document(EMPTY)
        with patch("tkinter.filedialog.askopenfilename", return_value=str(path)):
            self.assertTrue(self.app.load())
        self.assertEqual(self.app.target_rows(), [0, 2])
        self.assertEqual(
            json.loads(path.read_text())["drawing"]["targets"][
                self.app.data["active_table"]
            ]["selected"],
            [0, 2],
        )

    def test_all_check_and_clear_can_apply_an_empty_selection(self):
        picker = self.app.choose_drawing_rows()
        picker.check_all()
        picker.apply()
        self.app.preview(quiet=True)
        self.assertEqual(self.app.target_rows(), [0, 1, 2])
        self.assertEqual(len(self.app.canvas.items), 135)
        picker = self.app.choose_drawing_rows()
        picker.clear_all()
        picker.apply()
        self.app.preview(quiet=True)
        self.assertEqual(self.app.target_rows(), [])
        self.assertEqual(self.app.canvas.items, [])
        self.assertEqual(self.app._script_text, "")
        self.assertIn("チェック", self.app.status.get())

    def test_titles_stay_on_input_table_one_when_another_table_is_active(self):
        add_input_table(self.app.data, "別表", [{"TYPE": "別名", "X": 1}])
        self.app.refresh()
        self.app.scope.set("range")
        self.app.row_range.set("1")
        self.assertIn("FL-100", self.app.target_window_controls.title.get())
        picker = self.app.choose_drawing_rows()
        self.root.update()
        self.assertEqual(len(picker.tree.get_children()), 3)
        picker.check_all()
        self.assertEqual(picker.checked, {0})
        picker.toggle(2)
        self.assertEqual(picker.checked, {0})
        picker.cancel()

    def test_long_titles_and_both_settings_views_fit_and_do_not_leak_controllers(self):
        self.app.rows[0]["TYPE"] = "長い部品名" * 100
        self.app.refresh()
        self.root.update()
        self.assertLess(len(self.app.target_window_controls.title.get()), 35)
        for _ in range(3):
            win = self.app.edit_target_settings()
            win.geometry("520x380")
            self.root.update()
            self.assertEqual(len(self.app._target_controls), 1)
            for button in (
                gui.button(win, "選択行"),
                gui.button(win, "閉じる"),
            ):
                self.assertTrue(button.winfo_ismapped())
                self.assertLessEqual(
                    button.winfo_rooty() + button.winfo_height(),
                    win.winfo_rooty() + win.winfo_height(),
                )
                self.assertLessEqual(
                    button.winfo_rootx() + button.winfo_width(),
                    win.winfo_rootx() + win.winfo_width(),
                )
            win.destroy()
            self.assertEqual(len(self.app._target_controls), 0)
        self.assertFalse(
            any(
                isinstance(w, ttk.Radiobutton) and w.cget("text") == "全行"
                for w in gui.descendants(self.root)
            )
        )

    def test_ten_thousand_titles_can_be_checked_and_space_toggled(self):
        row = copy.deepcopy(self.app.rows[0])
        self.app.data["input_tables"][0]["rows"] = [
            dict(row, TYPE=f"部品{i + 1}") for i in range(10000)
        ]
        self.app.refresh()
        picker = self.app.choose_drawing_rows()
        self.root.update()
        self.assertEqual(len(picker.tree.get_children()), 10000)
        picker.check_all()
        self.assertEqual(len(picker.checked), 10000)
        picker.clear_all()
        self.assertEqual(picker.checked, set())
        picker.tree.focus("9999")
        picker.tree.focus_force()
        self.root.update()
        picker.tree.event_generate("<space>")
        self.root.update()
        self.assertEqual(picker.checked, {9999})
        picker.apply()
        self.assertEqual(self.app.target_rows(), [9999])

    def test_duplicate_and_delete_rows_keep_checked_parts_checked(self):
        self.app.set_checked_rows([1])
        self.app.table.selection_set("0")
        self.app.duplicate_rows()
        self.root.update()
        self.assertEqual(self.app.target_rows(), [2])
        self.assertEqual(self.app.rows[2]["TYPE"], "FL-120")
        self.app.table.selection_set("0")
        self.app.del_row()
        self.root.update()
        self.assertEqual(self.app.target_rows(), [1])
        self.assertEqual(self.app.rows[1]["TYPE"], "FL-120")

    def test_empty_input_has_a_disabled_spin_and_empty_checklist(self):
        self.app.replace_document(EMPTY)
        self.app.scope.set("range")
        self.root.update()
        self.assertIn("disabled", self.app.target_window_controls.spin.state())
        picker = self.app.choose_drawing_rows()
        picker.win.geometry("520x420")
        self.root.update()
        self.assertEqual(picker.tree.get_children(), ())
        picker.check_all()
        picker.clear_all()
        self.assertEqual(picker.checked, set())
        self.assertLessEqual(
            picker.apply_button.winfo_rooty() + picker.apply_button.winfo_height(),
            picker.win.winfo_rooty() + picker.win.winfo_height(),
        )
        picker.cancel()


if __name__ == "__main__":
    unittest.main()
