"""Preview clicks enter a compact reference mode without replacing the input form."""
import copy
import os
import sys
import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch
import test_gui as gui
from macro_editor import edit_command
from engine import compile_project


@unittest.skipUnless(sys.platform == 'win32' or os.environ.get('DISPLAY'), 'GUI display unavailable')
class InlinePointReferenceGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_preview_line_click_then_point_click_applies_and_exits(self):
        sources = [dict(type='LINE', x1='0', y1='0', x2='100', y2='0'),
                   dict(type='LINE', x1='0', y1='40', x2='100', y2='40')]
        def inspect():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                win.geometry('980x620');win.refresh_command_preview();self.root.update()
                canvas = win.command_preview.canvas
                camera = (canvas.view_ratio, list(canvas.pan))
                tops = [w for w in gui.descendants(self.root) if isinstance(w, tk.Toplevel)]
                def click(point):
                    x, y = canvas.screen_point(point)
                    canvas.event_generate('<ButtonPress-1>', x=round(x), y=round(y))
                    canvas.event_generate('<ButtonRelease-1>', x=round(x), y=round(y))
                    self.root.update()
                click((30, 0));panel = win.point_panel
                self.assertEqual(tops, [w for w in gui.descendants(self.root) if isinstance(w, tk.Toplevel)])
                self.assertTrue(win.command_viewport.winfo_ismapped())
                self.assertTrue(win.command_scrollbar.winfo_ismapped())
                self.assertIsInstance(panel.point_picker, ttk.Combobox)
                self.assertFalse(hasattr(panel, 'point_segments'))
                self.assertFalse(panel.axis_picker.winfo_ismapped())
                self.assertEqual(tuple(panel.axis_segments.buttons),('XY','X','Y'))
                for button in panel.axis_segments.buttons.values():
                    self.assertTrue(button.winfo_ismapped())
                    self.assertEqual(button.winfo_rooty(),panel.point_picker.winfo_rooty())
                    self.assertLessEqual(button.winfo_rootx()+button.winfo_width(),panel.winfo_rootx()+panel.winfo_width())
                self.assertLess(panel.winfo_height(), 320)
                self.assertLess(panel.winfo_rooty(), win.command_viewport.winfo_rooty())
                click((30, 40))
                self.assertEqual(panel.source_picker.current(), 1)
                click((100, 40))
                self.assertEqual(panel.point_picker.get(), '終点')
                panel.point_offsets['X'].set('-10')
                gui.button(panel, 'この点を使用').invoke();self.root.update()
                self.assertFalse(panel.winfo_exists())
                self.assertEqual((canvas.view_ratio, list(canvas.pan)), camera)
                self.assertEqual(str(win.command_entries['x'].cget('state')), 'normal')
                gui.button(win, 'コマンドを反映').invoke()
            except Exception as exc:
                self.errors.append(exc);win.destroy()
        self.root.after(100, inspect)
        result = edit_command(self.root, dict(type='POINT', x='150', y='100'),
                              self.app.data['blocks'], self.app.data, point_sources=sources)
        project = copy.deepcopy(self.app.data)
        project['blocks'] = [dict(project['blocks'][0], commands=sources + [result])]
        self.assertEqual(compile_project(project, [0])[1][-1]['coords'], (90, 40))

    def test_shared_table_action_targets_offset_and_escape_cancels_draft(self):
        def inspect():
            win = gui.top(self.root, 'コマンドの設定')
            try:
                win.choose_command_point('x', both=True);self.root.update();panel=win.point_panel
                offset = next(w for w in gui.descendants(panel) if isinstance(w,ttk.Entry) and str(w.cget('textvariable'))==str(panel.point_offsets['Y']))
                offset.focus_force();self.root.update()
                with patch('macro_editor.show_table_reference_picker', side_effect=lambda parent,project,**kw:kw['on_select']('@OD')):
                    win.command_entries['x'].reference_buttons[0].invoke()
                self.assertEqual(panel.point_offsets['Y'].get(),'@OD')
                self.assertEqual(panel.point_offsets['X'].get(),'0')
                self.assertIn('移動Y',win.coordinate_target_picker.get())
                win.event_generate('<Escape>');self.root.update()
                self.assertFalse(panel.winfo_exists())
                self.assertEqual(win.command_entries['x'].get(),'150')
                self.assertEqual(win.command_entries['y'].get(),'100')
                self.assertEqual(str(win.coordinate_target_picker.cget('state')),'readonly')
            except Exception as exc:self.errors.append(exc)
            finally:win.destroy()
        self.root.after(100,inspect)
        edit_command(self.root,dict(type='POINT',x='150',y='100'),self.app.data['blocks'],self.app.data,
                     point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')])

    def test_non_coordinate_focus_uses_last_coordinate_and_main_apply_commits_reference(self):
        sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')]
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                win.refresh_command_preview();self.root.update()
                win.command_entries['r'].focus_force();self.root.update()
                canvas=win.command_preview.canvas;x,y=canvas.screen_point((30,0))
                canvas.event_generate('<ButtonPress-1>',x=round(x),y=round(y))
                canvas.event_generate('<ButtonRelease-1>',x=round(x),y=round(y));self.root.update()
                panel=win.point_panel
                panel.point_picker.set('終点');panel.point_picker.event_generate('<<ComboboxSelected>>')
                panel.point_offsets['Y'].set('5')
                gui.button(win,'コマンドを反映').invoke()
            except Exception as exc:self.errors.append(exc);win.destroy()
        self.root.after(100,inspect)
        result=edit_command(self.root,dict(type='CIRCLE',x='150',y='100',r='7'),
                            self.app.data['blocks'],self.app.data,point_sources=sources)
        project=copy.deepcopy(self.app.data)
        project['blocks']=[dict(project['blocks'][0],commands=sources+[result])]
        self.assertEqual(compile_project(project,[0])[1][-1]['coords'],(100,5,7))

    def test_custom_argument_reference_exposes_shared_offset_actions_only_in_mode(self):
        def inspect():
            win=gui.top(self.root,'コマンドの設定')
            try:
                self.root.update();self.assertFalse(win.coordinate_toolbar.winfo_ismapped())
                win.choose_command_point('arg:VALUE');self.root.update();panel=win.point_panel
                self.assertTrue(win.coordinate_toolbar.winfo_ismapped())
                with patch('macro_editor.show_table_reference_picker', side_effect=lambda parent,project,**kw:kw['on_select']('@OD')):
                    gui.button(win.coordinate_toolbar,'表').invoke()
                self.assertEqual(panel.point_offsets['X'].get(),'@OD')
                win.close_point_panel();self.root.update()
                self.assertFalse(win.coordinate_toolbar.winfo_ismapped())
                self.assertEqual(str(win.command_entries['arg:VALUE'].cget('state')),'normal')
            except Exception as exc:self.errors.append(exc)
            finally:win.destroy()
        self.root.after(100,inspect)
        edit_command(self.root,dict(type='CUSTOM',name='set_ltscale',arguments={'VALUE':'1'}),
                     self.app.data['blocks'],self.app.data,
                     point_sources=[dict(type='LINE',x1='0',y1='0',x2='100',y2='0')])
