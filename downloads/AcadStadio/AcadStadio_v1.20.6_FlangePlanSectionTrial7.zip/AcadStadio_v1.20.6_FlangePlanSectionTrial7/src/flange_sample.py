"""Editable plan and diametral section, using ordinary flow commands only."""

import copy


def line(x1, y1, x2, y2, layer="CENTER"):
    return dict(type="LINE", layer=layer, x1=x1, y1=y1, x2=x2, y2=y2)


def repeat(count, commands):
    return dict(type="REPEAT", count=count, commands=commands)


def build_flange_sample(base):
    project = copy.deepcopy(base)
    project["settings"].update(
        VIEW_GAP="35",
        HATCH_PITCH="5",
        DIM_SCALE="1",
        DIM_TEXT_HEIGHT="3.5",
        ARROW_SIZE="2.5",
    )
    rows = project["input_tables"][0]["rows"]
    for row, x, bore, thickness in zip(
        rows, ("100", "420", "780"), ("35", "40", "50"), ("16", "18", "20")
    ):
        row.update(X=x, ID=bore, T=thickness)
    project["input_tables"][0]["name"] = "フランジ平断面寸法表"
    project["drawing"]["targets"][project["active_table"]]["selected"] = [0]
    setup = project["cad_setup"]
    setup.update(enabled=True, legacy_make_layers=False)
    setup["linetypes"] = []
    setup["layers"] = [
        dict(
            name=name, color=color, linetype="Continuous", lineweight=weight, plot=True
        )
        for name, color, weight in (
            ("OUTLINE", "7", "35"),
            ("HOLES", "4", "25"),
            ("CENTER", "2", "13"),
            ("HATCH", "8", "13"),
            ("DIM", "6", "18"),
        )
    ]
    plan = [
        dict(type="CIRCLE", layer="OUTLINE", x="@X", y="@Y", r="@OD/2"),
        dict(type="CIRCLE", layer="OUTLINE", x="@X", y="@Y", r="@ID/2"),
        repeat(
            "@N",
            [
                dict(
                    type="CIRCLE",
                    layer="HOLES",
                    x="@X + @PCD/2 * cos(radians(360 * loop.index / @N))",
                    y="@Y + @PCD/2 * sin(radians(360 * loop.index / @N))",
                    r="@R",
                )
            ],
        ),
        repeat(
            "36",
            [
                line(
                    "@X + @PCD/2 * cos(radians(10 * loop.index))",
                    "@Y + @PCD/2 * sin(radians(10 * loop.index))",
                    "@X + @PCD/2 * cos(radians(10 * loop.index + 6))",
                    "@Y + @PCD/2 * sin(radians(10 * loop.index + 6))",
                )
            ],
        ),
        repeat(
            "9",
            [
                line(
                    "@X - @OD/2 - 8 + (@OD+16)*loop.index/9",
                    "@Y",
                    "@X - @OD/2 - 8 + (@OD+16)*(loop.index+0.65)/9",
                    "@Y",
                ),
                line(
                    "@X",
                    "@Y - @OD/2 - 8 + (@OD+16)*loop.index/9",
                    "@X",
                    "@Y - @OD/2 - 8 + (@OD+16)*(loop.index+0.65)/9",
                ),
            ],
        ),
    ]
    # A-A passes through the two opposite bolt holes of an even-hole flange.
    # Each pair is a material interval; the bore and bolt holes stay unhatched.
    intervals = [
        ("@X-@OD/2", "@X-@PCD/2-@R"),
        ("@X-@PCD/2+@R", "@X-@ID/2"),
        ("@X+@ID/2", "@X+@PCD/2-@R"),
        ("@X+@PCD/2+@R", "@X+@OD/2"),
    ]
    bottom = "@Y-@OD/2-settings.VIEW_GAP-@T"
    top = "@Y-@OD/2-settings.VIEW_GAP"
    section, hatch = [], []
    for left, right in intervals:
        section.append(
            dict(
                type="RECTANGLE",
                layer="OUTLINE",
                x1=left,
                y1=bottom,
                x2=right,
                y2=top,
            )
        )
        width = f"(({right})-({left}))"
        step = "loop.index * settings.HATCH_PITCH"
        stroke = line(
            f"({left})+max(0, ({step})-@T)",
            f"({bottom})+min(({step}), @T)",
            f"({left})+min(({step}), {width})",
            f"({bottom})+max(0, ({step})-{width})",
            "HATCH",
        )
        stroke["condition"] = f"0 < ({step}) < {width}+@T"
        hatch.append(repeat(f"round(({width}+@T)/settings.HATCH_PITCH)+1", [stroke]))
    section.append(
        repeat(
            "5",
            [
                line(
                    "@X",
                    f"({bottom})-6+(@T+12)*loop.index/5",
                    "@X",
                    f"({bottom})-6+(@T+12)*(loop.index+0.65)/5",
                )
            ],
        )
    )

    def text(x, y, content):
        return dict(
            type="TEXT",
            layer="DIM",
            x=x,
            y=y,
            text=content,
            height="settings.TEXT_HEIGHT",
        )

    notes = [
        text("@X-10", "@Y+@OD/2+10", "平面図"),
        text("@X-20", f"({bottom})-30", "断面図 A-A"),
        text("@X-@OD/2-15", "@Y+9", "A"),
        text("@X+@OD/2+10", "@Y+9", "A"),
        text("@X+@OD/2+25", "@Y+25", "='PCD %g' % @PCD"),
        text("@X+@OD/2+25", "@Y+13", "='穴数 %g' % @N"),
        text("@X+@OD/2+25", "@Y+1", "='穴径 %g' % (@R*2)"),
        dict(
            type="DIMLINEAR",
            layer="DIM",
            x1="@X-@OD/2",
            y1="@Y",
            x2="@X+@OD/2",
            y2="@Y",
            x3="@X",
            y3="@Y-@OD/2-15",
        ),
        dict(
            type="DIMLINEAR",
            layer="DIM",
            x1="@X-@ID/2",
            y1=bottom,
            x2="@X+@ID/2",
            y2=bottom,
            x3="@X",
            y3=f"({bottom})-15",
        ),
        dict(
            type="DIMLINEAR",
            layer="DIM",
            x1="@X+@OD/2",
            y1=bottom,
            x2="@X+@OD/2",
            y2=top,
            x3="@X+@OD/2+15",
            y3=f"({bottom})+@T/2",
        ),
    ]
    for arrow_x in ("@X-@OD/2-12", "@X+@OD/2+12"):
        notes.extend(
            [
                line(arrow_x, "@Y+7", arrow_x, "@Y-5", "DIM"),
                line(f"({arrow_x})-2", "@Y-1", arrow_x, "@Y-5", "DIM"),
                line(f"({arrow_x})+2", "@Y-1", arrow_x, "@Y-5", "DIM"),
            ]
        )
    project["blocks"] = [
        dict(id=identity, name=name, draw=True, condition="", commands=commands)
        for identity, name, commands in (
            ("flange_plan", "01 平面図", plan),
            ("flange_section", "02 断面図 A-A", section),
            ("flange_hatch", "03 断面ハッチング", hatch),
            ("flange_notes", "04 寸法・図名", notes),
        )
    ]
    return project
