"""The plan, material section and hatch must agree when dimensions change."""

import copy
import json
import math
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from sample_project import EXAMPLE
from engine import compile_project
from project_model import normalize_project
from table_io import read_csv, read_excel, sheet_names
from audit import audit_project
from block_model import nested

ROOT = Path(__file__).resolve().parents[1]


class FlangeSample(unittest.TestCase):
    def test_sample_opens_one_row_and_has_two_views_without_local_variables(self):
        self.assertEqual(
            EXAMPLE["drawing"]["targets"][EXAMPLE["active_table"]]["selected"], [0]
        )
        self.assertEqual(audit_project(EXAMPLE), [])
        self.assertEqual(
            [b["name"] for b in EXAMPLE["blocks"][:2]], ["01 平面図", "02 断面図 A-A"]
        )
        for block in EXAMPLE["blocks"]:
            self.assertNotIn("variables", block)
            for command in nested(block["commands"]):
                self.assertNotIn(command["type"], ("BLOCK", "SET"))
                self.assertNotIn("local.", json.dumps(command))

    def test_dimensions_and_hatch_remain_inside_material(self):
        # Include non-integer dimensions to catch hatch clipping/rounding errors.
        cases = [copy.deepcopy(row) for row in EXAMPLE["input_tables"][0]["rows"]]
        cases.append(
            dict(cases[0], OD="160.5", ID="50.25", PCD="110", R="6.5", T="25.5")
        )
        for row in cases:
            with self.subTest(row=row):
                project = copy.deepcopy(EXAMPLE)
                project["input_tables"][0]["rows"] = [row]
                script, items = compile_project(project, [0])
                x, y, od, bore, pcd, radius, thickness = (
                    float(row[k]) for k in ("X", "Y", "OD", "ID", "PCD", "R", "T")
                )
                circles = [i for i in items if i["type"] == "CIRCLE"]
                self.assertEqual(len(circles), int(row["N"]) + 2)
                self.assertEqual(circles[0]["coords"], (x, y, od / 2))
                self.assertEqual(circles[1]["coords"], (x, y, bore / 2))
                for hole in circles[2:]:
                    hx, hy, hr = hole["coords"]
                    self.assertAlmostEqual(
                        math.hypot(hx - x, hy - y), pcd / 2, places=8
                    )
                    self.assertEqual(hr, radius)
                top = y - od / 2 - float(project["settings"]["VIEW_GAP"])
                bottom = top - thickness
                material = [
                    (x - od / 2, x - pcd / 2 - radius),
                    (x - pcd / 2 + radius, x - bore / 2),
                    (x + bore / 2, x + pcd / 2 - radius),
                    (x + pcd / 2 + radius, x + od / 2),
                ]
                rectangles = [i for i in items if i["type"] == "RECTANGLE"]
                self.assertEqual(len(rectangles), 4)
                for item, (left, right) in zip(rectangles, material):
                    self.assertEqual(item["coords"], (left, bottom, right, top))
                hatch = [i for i in items if i["layer"] == "HATCH"]
                self.assertTrue(hatch)
                covered = set()
                for item in hatch:
                    x1, y1, x2, y2 = item["coords"]
                    self.assertGreater(math.hypot(x2 - x1, y2 - y1), 0)
                    self.assertAlmostEqual(abs(x2 - x1), abs(y2 - y1), places=8)
                    self.assertTrue(bottom - 1e-8 <= y1 <= top + 1e-8)
                    self.assertTrue(bottom - 1e-8 <= y2 <= top + 1e-8)
                    matches = [
                        j
                        for j, (left, right) in enumerate(material)
                        if left - 1e-8 <= min(x1, x2) <= max(x1, x2) <= right + 1e-8
                    ]
                    self.assertEqual(len(matches), 1)
                    covered.update(matches)
                self.assertEqual(covered, {0, 1, 2, 3})
                dimensions = [i["coords"] for i in items if i["type"] == "DIMLINEAR"]
                self.assertEqual(len(dimensions), 3)
                self.assertAlmostEqual(dimensions[0][2] - dimensions[0][0], od)
                self.assertAlmostEqual(dimensions[1][2] - dimensions[1][0], bore)
                self.assertAlmostEqual(dimensions[2][3] - dimensions[2][1], thickness)
                self.assertNotIn("_.-LINETYPE", script)
                self.assertIn("(c:CADFLOWRESTORE)", script)

    def test_shipped_json_csv_excel_and_script_match_default_sample(self):
        project = normalize_project(
            json.loads(
                (ROOT / "examples/flange_project.json").read_text(encoding="utf-8")
            )
        )
        self.assertEqual(project, EXAMPLE)
        rows = EXAMPLE["input_tables"][0]["rows"]
        self.assertEqual(read_csv(ROOT / "examples/flange_input.csv"), rows)
        excel = ROOT / "examples/flange_input.xlsx"
        self.assertEqual(read_excel(excel, sheet_names(excel)[0]), rows)
        expected, _ = compile_project(EXAMPLE, [0])
        self.assertEqual(
            (ROOT / "examples/flange_output.scr")
            .read_bytes()
            .decode("cp932")
            .replace("\r\n", "\n"),
            expected + "\n",
        )

    def test_organized_sample_changes_only_folder_organization(self):
        project = normalize_project(
            json.loads(
                (ROOT / "examples/folder_organization.json").read_text(encoding="utf-8")
            )
        )
        self.assertEqual(
            compile_project(project, [0, 1, 2]), compile_project(EXAMPLE, [0, 1, 2])
        )


if __name__ == "__main__":
    unittest.main()
