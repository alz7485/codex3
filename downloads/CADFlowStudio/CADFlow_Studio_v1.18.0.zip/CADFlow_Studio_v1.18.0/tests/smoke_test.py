"""Fast compatibility check. Full regressions: python -m unittest discover -s tests."""

import copy, json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from engine import compile_project
from audit import audit_project
from sample_project import EXAMPLE
from project_model import normalize_project

script, figures = compile_project(copy.deepcopy(EXAMPLE), [0, 1, 2])
assert len(figures) == 27
assert script.count("_.CIRCLE") == 23
assert audit_project(EXAMPLE) == []
legacy = json.loads(
    (Path(__file__).resolve().parents[1] / "examples/legacy_v1_5.json").read_text(
        encoding="utf-8"
    )
)
assert len(compile_project(normalize_project(legacy), [0, 1, 2])[1]) == 5
print("PASS: v1.18 blocks, IF/ELSE, REPEAT, audit, v1.5 compatibility")
