"""Rebuild the original CADFlow vector icon. Pillow is a development dependency."""

from pathlib import Path
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
a = root / "assets"
a.mkdir(exist_ok=True)
svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" rx="56" fill="#163052"/><path d="M48 176V80l80-40 80 40v96l-80 40z" fill="none" stroke="#5b95ff" stroke-width="13" stroke-linejoin="round"/><path d="m48 80 80 45 80-45M128 125v91" fill="none" stroke="#5b95ff" stroke-width="13"/><path d="m84 154 37 21 51-29" fill="none" stroke="#5eead4" stroke-width="14" stroke-linecap="round"/><circle cx="172" cy="146" r="11" fill="#5eead4"/></svg>"""
(a / "cadflow.svg").write_text(svg, encoding="utf-8")
s = 4
image = Image.new("RGBA", (256 * s, 256 * s))
d = ImageDraw.Draw(image)


def points(seq):
    return [(int(x * s), int(y * s)) for x, y in seq]


d.rounded_rectangle((0, 0, 256 * s - 1, 256 * s - 1), radius=56 * s, fill="#163052")
d.line(
    points(
        [(48, 176), (48, 80), (128, 40), (208, 80), (208, 176), (128, 216), (48, 176)]
    ),
    fill="#5b95ff",
    width=13 * s,
    joint="curve",
)
for seq in [[(48, 80), (128, 125), (208, 80)], [(128, 125), (128, 216)]]:
    d.line(points(seq), fill="#5b95ff", width=13 * s, joint="curve")
d.line(
    points([(84, 154), (121, 175), (172, 146)]),
    fill="#5eead4",
    width=14 * s,
    joint="curve",
)
d.ellipse((161 * s, 135 * s, 183 * s, 157 * s), fill="#5eead4")
image = image.resize((256, 256), Image.Resampling.LANCZOS)
image.save(a / "cadflow.png")
image.save(
    a / "cadflow.ico",
    sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
)
print("Created PNG / ICO / SVG")
