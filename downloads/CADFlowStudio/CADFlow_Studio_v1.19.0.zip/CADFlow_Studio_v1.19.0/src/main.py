"""CADFlow Studio — a local, row-driven AutoCAD script workbench."""

import copy
import json
import re
import uuid
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from pathlib import Path
from project_safety import atomic_save, atomic_write_script, details
from project_model import normalize_project, valid_name, validate_project
from project_data import (
    current_table,
    get_rows,
    target_settings,
    add_input_table,
    unique_table_name,
    parse_row_range,
    default_target,
)
from engine import compile_project, MacroError
from macro_editor import MacroEditor
from catalog_editor import CommandCatalogManager
from settings_preset_editor import SettingsPresetEditor
from settings_presets import active_label
from project_library import ProjectLibrary, canonical
from project_sidebar import ProjectSidebar
from cad_setup import default_setup
from cad_setup_editor import CadSetupEditor
from project_navigator import ProjectNavigator
from preview import DrawingCanvas
from theme import apply_theme, fit_window, APP_NAME, APP_VERSION, ROOT
from sample_project import EXAMPLE
from table_io import read_csv, read_excel, sheet_names
from table_edit import TableEditor
from flow_view import FlowView
from flow import resolve
from workspace_state import WorkspaceState
from ui_icons import IconTheme
from block_model import new_block, references
from block_browser import BlockBrowser

EMPTY = {
    "version": 11,
    "cad_setup": default_setup(),
    "settings": {"TEXT_HEIGHT": "3.5"},
    "globals": {},
    "rows": [],
    "blocks": [],
}


class App:
    def __init__(self, root, *, library_state_path=None):
        self.root = root
        self.face = apply_theme(root)
        self.icons = IconTheme(root)
        root.title(APP_NAME)
        fit_window(root, 1320, 840, 1040, 680)
        self.project_library = ProjectLibrary(library_state_path)
        self.workspace_state = WorkspaceState(self.project_library.state_path.parent)
        self._session_job = None
        self._startup_job = None
        self._draft_id = uuid.uuid4().hex
        self._recoveries = self.workspace_state.recoveries()
        self._recovery = self._recoveries[0] if self._recoveries else None
        self.project_window = None
        self.project_sidebar = None
        self.data = copy.deepcopy(EXAMPLE)
        self.path = None
        self.document_name = "サンプルプロジェクト"
        self.navigator = None
        self._history = []
        self._future = []
        self._history_limit = 100
        self._restoring = False
        self._observed = copy.deepcopy(self.data)
        self._saved = copy.deepcopy(self.data)
        self._preview_job = None
        self.command_diagnostics = []
        self._syncing_options = False
        self._rendered_table_id = None
        self.status = tk.StringVar(
            value="サンプルを表示しています。行やブロックを編集して試せます。"
        )
        if self.project_library.warning:
            self.status.set(self.project_library.warning)
        self.document_status = tk.StringVar()
        self.selection_status = tk.StringVar()
        self.drawing_selection_summary = tk.StringVar()
        self.preview_status = tk.StringVar()
        self.highlight_enabled = tk.BooleanVar(value=True)
        self.drawing_summary = tk.StringVar()
        self.scope = tk.StringVar(value="selected")
        self.encoding = tk.StringVar(value="cp932")
        self.table_choice = tk.StringVar()
        self.table_heading = tk.StringVar(value="入力表")
        self.row_range = tk.StringVar()
        self.settings_summary = tk.StringVar()
        self.settings_preset_summary = tk.StringVar()
        root.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.build_menu()
        for key, action in [
            ("<Control-n>", self.new),
            ("<Control-o>", self.load),
            ("<Control-s>", self.save),
            ("<Control-z>", self.undo_project),
            ("<Control-y>", self.redo_project),
            ("<Control-e>", self.export),
            ("<F5>", self.preview),
            ("<F1>", self.show_help),
        ]:
            root.bind(key, lambda e, fn=action: self.shortcut(e, fn))
        header = ttk.Frame(root, padding=(20, 16))
        header.pack(fill="x")
        if hasattr(root, "_app_icon"):
            self.brand_icon = root._app_icon.subsample(4, 4)
            ttk.Label(header, image=self.brand_icon).pack(side="left", padx=(0, 12))
        brand = ttk.Frame(header)
        brand.pack(side="left")
        ttk.Label(brand, text=APP_NAME, style="Title.TLabel").pack(anchor="w")
        ttk.Label(brand, text="表から、繰り返せる作図へ。", style="Muted.TLabel").pack(
            anchor="w"
        )
        actions = ttk.Frame(header)
        actions.pack(side="right")
        for label, fn in [
            ("開く", self.load),
            ("保存", self.save),
            ("プロジェクトを検査", self.audit),
        ]:
            ttk.Button(actions, text=label, command=fn).pack(side="left", padx=4)
        ttk.Button(
            actions, text="SCRを書き出す", style="Primary.TButton", command=self.export
        ).pack(side="left", padx=(10, 0))
        info = ttk.Frame(root, padding=(20, 0, 20, 12))
        info.pack(fill="x")
        self.recovery_banner = ttk.Frame(root, padding=(20, 6))
        if self._recovery:
            self.recovery_banner.pack(fill="x")
        ttk.Label(
            self.recovery_banner,
            text="前回の未保存データがあります。",
            style="Section.TLabel",
        ).pack(side="left")
        self.recovery_choice = ttk.Combobox(
            self.recovery_banner,
            state="readonly",
            width=24,
            values=[
                f"{i + 1}. {d.get('name', 'プロジェクト')}"
                for i, d in enumerate(self._recoveries)
            ],
        )
        self.recovery_choice.pack(side="left", padx=8)
        if self._recoveries:
            self.recovery_choice.current(0)
        self.recovery_choice.bind(
            "<<ComboboxSelected>>",
            lambda e: setattr(
                self, "_recovery", self._recoveries[self.recovery_choice.current()]
            ),
        )
        ttk.Button(
            self.recovery_banner, text="内容を復元", command=self.restore_recovery
        ).pack(side="left", padx=8)
        ttk.Button(
            self.recovery_banner, text="破棄", command=self.discard_recovery
        ).pack(side="left")
        ttk.Button(info, text="プロジェクト一覧…", command=self.show_project_list).pack(
            side="left", padx=(0, 12)
        )
        ttk.Label(info, textvariable=self.document_status, style="Section.TLabel").pack(
            side="left"
        )
        ttk.Label(
            info,
            text="① 表を用意   →   ② 作図ルール   →   ③ 確認して出力",
            style="Muted.TLabel",
        ).pack(side="right")
        workspace = ttk.Frame(root)
        body = workspace
        workspace.pack(fill="both", expand=True, padx=18, pady=(0, 10))
        self.workspace_tabs = ttk.Notebook(workspace)
        self.workspace_tabs.pack(fill="both", expand=True)
        self.drawing_page = ttk.Frame(self.workspace_tabs, padding=(8, 8, 0, 0))
        self.input_page = ttk.Frame(self.workspace_tabs, padding=(8, 8, 0, 0))
        self.workspace_tabs.add(
            self.drawing_page,
            text="作図",
            image=self.icons.get("edit"),
            compound="left",
        )
        self.workspace_tabs.add(
            self.input_page,
            text="入力表",
            image=self.icons.get("table"),
            compound="left",
        )
        sourcebar = ttk.Frame(self.drawing_page)
        sourcebar.pack(fill="x", pady=(0, 8))
        ttk.Button(sourcebar, text="CAD初期設定…", command=self.edit_cad_setup).pack(
            side="right", padx=(8, 0)
        )
        ttk.Label(sourcebar, text="使用する入力表:").pack(side="left", padx=(0, 6))
        self.drawing_table_picker = ttk.Combobox(
            sourcebar, textvariable=self.table_choice, state="readonly", width=24
        )
        self.drawing_table_picker.pack(side="left")
        self.drawing_table_picker.bind(
            "<<ComboboxSelected>>", lambda e: self.switch_table_by_name()
        )
        ttk.Label(
            sourcebar, textvariable=self.drawing_selection_summary, style="Muted.TLabel"
        ).pack(side="left", padx=10)
        ttk.Button(
            sourcebar, text="入力表を編集 →", command=self.show_input_table
        ).pack(side="right")
        condition_label = ttk.Label(
            self.drawing_page,
            textvariable=self.drawing_summary,
            style="Muted.TLabel",
            wraplength=1100,
        )
        condition_label.pack(fill="x", pady=(0, 6))
        self.drawing_page.bind(
            "<Configure>",
            lambda e: condition_label.configure(wraplength=max(400, e.width - 25)),
        )
        panes = ttk.Panedwindow(self.drawing_page, orient="horizontal")
        self.drawing_panes = panes
        panes.pack(fill="both", expand=True)
        blocks_frame = ttk.Frame(panes, width=430, padding=(0, 0, 8, 0))
        blocks_frame.pack_propagate(False)
        right = ttk.Frame(panes)
        panes.add(blocks_frame, weight=0)
        panes.add(right, weight=1)

        def initialize_sash(event):
            if event.width > 700 and not getattr(panes, "_sash_initialized", False):
                panes._sash_initialized = True
                panes.sashpos(0, 430)

        panes.bind("<Configure>", initialize_sash)
        rows_frame = self.input_page
        rowhead = ttk.Frame(rows_frame)
        rowhead.pack(fill="x", pady=(0, 8))
        ttk.Label(
            rowhead, textvariable=self.table_heading, style="Section.TLabel"
        ).pack(side="left")
        ttk.Button(rowhead, text="← 作図へ戻る", command=self.show_drawing).pack(
            side="right"
        )
        ttk.Button(
            rowhead, text="＋ Excel / CSV を読込", command=self.import_table
        ).pack(side="right", padx=(0, 8))
        tablebar = ttk.Frame(rows_frame)
        tablebar.pack(fill="x", pady=(0, 6))
        ttk.Label(tablebar, text="入力表:").pack(side="left", padx=(0, 6))
        self.table_picker = ttk.Combobox(
            tablebar, textvariable=self.table_choice, state="readonly"
        )
        self.table_picker.pack(side="left", fill="x", expand=True)
        self.table_picker.bind(
            "<<ComboboxSelected>>", lambda e: self.switch_table_by_name()
        )
        ttk.Button(tablebar, text="管理 ▾", command=self.table_menu, width=7).pack(
            side="left", padx=(5, 0)
        )
        frame = ttk.Frame(rows_frame)
        self.row_table_container = frame
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.table = ttk.Treeview(
            frame, show="headings", selectmode="extended", height=4
        )
        self.table.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(frame, command=self.table.yview)
        ys.grid(row=0, column=1, sticky="ns")
        xs = ttk.Scrollbar(frame, orient="horizontal", command=self.table.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.table.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        self.table_editor = TableEditor(self)
        self.table.bind("<Return>", lambda e: self.edit_row())
        self.table.bind("<<TreeviewSelect>>", self.on_row_selection)
        self.table.bind(
            "<Control-a>",
            lambda e: (self.table.selection_set(self.table.get_children()), "break")[
                -1
            ],
        )
        rowtools = ttk.Frame(rows_frame)
        rowtools.pack(side="bottom", fill="x", pady=6, before=self.row_table_container)
        for label, fn in [
            ("行を追加", self.add_row),
            ("編集", self.edit_row),
            ("複製", self.duplicate_rows),
            ("削除", self.del_row),
        ]:
            ttk.Button(rowtools, text=label, command=fn).pack(side="left", padx=(0, 4))
        ttk.Label(
            rows_frame, textvariable=self.selection_status, style="Muted.TLabel"
        ).pack(side="bottom", anchor="w", pady=(0, 5), before=rowtools)
        phead = ttk.Frame(blocks_frame)
        phead.pack(fill="x", pady=(4, 6))
        ttk.Label(phead, text="作図ブロック", style="Section.TLabel").pack(side="left")
        ttk.Button(
            phead,
            text="＋ ブロック",
            command=self.add_block,
            style="Compact.TButton",
        ).pack(side="right")
        ttk.Button(
            phead,
            text="登録コマンド",
            command=self.manage_custom_commands,
            style="Compact.TButton",
        ).pack(side="right", padx=(0, 6))
        self.block_tabs = ttk.Notebook(blocks_frame, style="Compact.TNotebook")
        self.block_tabs.pack(fill="both", expand=True)
        frame = ttk.Frame(self.block_tabs)
        self.block_tabs.add(frame, text="ブロック一覧")
        self.flow_view = FlowView(
            self.block_tabs, self.edit_flow_command, self.highlight_preview
        )
        self.block_tabs.add(self.flow_view, text="選択フロー")
        self.block_table_container = frame
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.block_browser = BlockBrowser(
            frame, lambda: self.data, self.refresh, icons=self.icons
        )
        self.block_browser.grid(row=0, column=0, sticky="nsew")
        self.block_list = self.block_browser.tree
        self.block_list.bind("<Double-1>", self.activate_block, add="+")
        self.block_list.bind("<Return>", self.activate_block, add="+")
        self.block_list.bind("<<TreeviewSelect>>", self.on_block_selection)
        self.block_list.bind(
            "<Escape>",
            lambda e: self.block_list.selection_remove(self.block_list.selection()),
        )
        ptools = ttk.Frame(blocks_frame)
        ptools.pack(side="bottom", fill="x", pady=6, before=self.block_tabs)
        for label, fn in [
            ("編集", self.edit_block),
            ("作図対象 / 呼出専用", self.toggle_block_draw),
            ("↑", lambda: self.move_block(-1)),
            ("↓", lambda: self.move_block(1)),
            ("削除", self.del_block),
        ]:
            ttk.Button(
                ptools,
                text=label,
                command=fn,
                width=10 if len(label) > 2 else 4,
                style="Compact.TButton",
            ).pack(side="left", padx=(0, 4))
        more = ttk.Frame(ptools)
        more.pack(side="left", padx=(8, 0))
        for label, fn in [
            ("設定・変数", self.project_settings),
            ("構成ツリー", self.open_navigator),
        ]:
            ttk.Button(more, text=label, command=fn, style="Compact.TButton").pack(
                side="left", padx=(0, 4)
            )
        choices = ttk.LabelFrame(blocks_frame, text="作図設定", padding=(10, 6))
        choices.pack(side="bottom", fill="x", pady=(8, 0), before=ptools)
        targetbar = ttk.Frame(choices)
        targetbar.pack(fill="x")
        ttk.Label(targetbar, text="対象行:").pack(side="left", padx=(0, 6))
        for label, value in [
            ("選択行", "selected"),
            ("行番号", "range"),
            ("全行", "all"),
        ]:
            ttk.Radiobutton(
                targetbar, text=label, variable=self.scope, value=value
            ).pack(side="left", padx=(0, 8))
        rangebar = ttk.Frame(choices)
        rangebar.pack(fill="x", pady=(4, 0))
        ttk.Label(rangebar, text="行番号:").pack(side="left", padx=(0, 6))
        self.range_entry = ttk.Entry(rangebar, textvariable=self.row_range, width=15)
        self.range_entry.pack(side="left", fill="x", expand=True)
        ttk.Label(rangebar, text="例: 1-3,5", style="Muted.TLabel").pack(
            side="left", padx=(6, 0)
        )
        setting_presets = ttk.Frame(choices)
        setting_presets.pack(fill="x", pady=(5, 0))
        ttk.Button(
            setting_presets,
            text="設定プリセット…",
            command=self.manage_settings_presets,
            style="Compact.TButton",
        ).pack(side="left", fill="x", expand=True, padx=(0, 6))
        ttk.Button(
            setting_presets,
            text="サイズ・共通設定…",
            command=self.edit_drawing_settings,
            style="Compact.TButton",
        ).pack(side="left", fill="x", expand=True)
        sizes = ttk.Frame(choices)
        sizes.pack(fill="x", pady=(5, 0))
        ttk.Label(sizes, textvariable=self.settings_summary, style="Muted.TLabel").pack(
            side="left"
        )
        compact_choices = ttk.Frame(blocks_frame)
        ttk.Button(
            compact_choices,
            text="作図設定…（対象行・サイズ・設定プリセット）",
            command=self.edit_target_settings,
            style="Compact.TButton",
        ).pack(fill="x")
        self.compact_choices = compact_choices
        self.drawing_options_frame = choices

        def adapt_options(event=None):
            height = event.height if event is not None else blocks_frame.winfo_height()
            compact = height < 450 or bool(self.data.get("block_folders"))
            if compact != getattr(blocks_frame, "_compact", None):
                blocks_frame._compact = compact
                if compact:
                    choices.pack_forget()
                    compact_choices.pack(
                        side="bottom", fill="x", pady=(6, 0), before=ptools
                    )
                else:
                    compact_choices.pack_forget()
                    choices.pack(side="bottom", fill="x", pady=(8, 0), before=ptools)

        blocks_frame.bind("<Configure>", adapt_options)
        self.adapt_drawing_options = adapt_options
        self.result_tabs = ttk.Notebook(right)
        self.result_tabs.pack(fill="both", expand=True)
        canvaspage = ttk.Frame(self.result_tabs)
        scriptpage = ttk.Frame(self.result_tabs)
        self.result_tabs.add(
            canvaspage,
            text="作図プレビュー",
            image=self.icons.get("preview"),
            compound="left",
        )
        self.result_tabs.add(
            scriptpage, text="生成SCR", image=self.icons.get("script"), compound="left"
        )
        self.canvas = DrawingCanvas(canvaspage)
        self.canvas.pack(fill="both", expand=True)
        foot = ttk.Frame(canvaspage, padding=8)
        foot.pack(side="bottom", fill="x", before=self.canvas)
        ttk.Label(
            foot, textvariable=self.preview_status, style="Muted.TLabel", wraplength=290
        ).pack(side="left")
        ttk.Button(
            foot, text="全体を表示", command=self.canvas.fit, style="Compact.TButton"
        ).pack(side="right")
        ttk.Button(
            foot, text="再生成  F5", command=self.preview, style="Compact.TButton"
        ).pack(side="right", padx=6)
        ttk.Checkbutton(
            foot,
            text="選択を強調",
            variable=self.highlight_enabled,
            command=self.highlight_preview,
            style="Toggle.Toolbutton",
        ).pack(side="right", padx=3)
        scriptpage.rowconfigure(0, weight=1)
        scriptpage.columnconfigure(0, weight=1)
        self.script = tk.Text(
            scriptpage,
            wrap="none",
            font=("Consolas", 11),
            bg="#101d30",
            fg="#d0e1f7",
            insertbackground="white",
            relief="flat",
            padx=14,
            pady=14,
            state="disabled",
        )
        self.script.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(scriptpage, command=self.script.yview)
        ys.grid(row=0, column=1, sticky="ns")
        xs = ttk.Scrollbar(scriptpage, orient="horizontal", command=self.script.xview)
        xs.grid(row=1, column=0, sticky="ew")
        self.script.configure(xscrollcommand=xs.set, yscrollcommand=ys.set)
        scriptbar = ttk.Frame(scriptpage, padding=8)
        scriptbar.grid(row=2, column=0, sticky="ew")
        ttk.Button(scriptbar, text="SCRをコピー", command=self.copy_script).pack(
            side="left"
        )
        ttk.Button(
            scriptbar, text="再生成  F5", command=self.preview, style="Compact.TButton"
        ).pack(side="right")
        preview_note = ttk.Label(
            right,
            text="ホイール: 拡大縮小 / ドラッグ: 移動。文字・寸法は簡易2D表示です。",
            style="Muted.TLabel",
            wraplength=600,
        )
        preview_note.pack(side="bottom", fill="x", pady=5, before=self.result_tabs)
        right.bind(
            "<Configure>",
            lambda e: preview_note.configure(wraplength=max(180, e.width - 12)),
        )
        statusbar = ttk.Frame(root, padding=(18, 8))
        statusbar.pack(side="bottom", fill="x", before=body)
        ttk.Label(statusbar, textvariable=self.status, wraplength=1050).pack(
            side="left"
        )
        ttk.Label(statusbar, text="v" + APP_VERSION, style="Muted.TLabel").pack(
            side="right"
        )
        self.scope.trace_add("write", self.update_drawing_options)
        self.row_range.trace_add("write", self.update_drawing_options)
        self.refresh()
        self.queue_preview()
        root.bind("<Destroy>", self.cleanup_jobs, add="+")
        self._startup_job = root.after_idle(self.restore_workspace)
        self._session_job = root.after(15000, self.autosave_workspace)

    def build_menu(self):
        menu = tk.Menu(self.root)
        self.root.configure(menu=menu)

        def group(label, items):
            sub = tk.Menu(menu, tearoff=False)
            menu.add_cascade(label=label, menu=sub)
            for name, fn in items:
                if name is None:
                    sub.add_separator()
                else:
                    sub.add_command(label=name, command=fn)

        group(
            "ファイル",
            [
                ("プロジェクト一覧…", self.show_project_list),
                ("新規プロジェクト  Ctrl+N", self.new),
                ("サンプルを開く", self.load_sample),
                ("開く…  Ctrl+O", self.load),
                ("保存  Ctrl+S", self.save),
                ("名前を付けて保存…", self.save_as),
                (None, None),
                ("表を読み込む…", self.import_table),
                ("SCR出力…  Ctrl+E", self.export),
                (None, None),
                ("終了", self.on_exit),
            ],
        )
        group(
            "編集",
            [
                ("元に戻す  Ctrl+Z", self.undo_project),
                ("やり直し  Ctrl+Y", self.redo_project),
                ("保存済みとの変更を表示", self.show_changes),
            ],
        )
        group(
            "プロジェクト",
            [
                ("共通設定", self.edit_settings),
                ("グローバル変数", self.edit_globals),
                ("ユーザーコマンド登録", self.manage_custom_commands),
                ("構成ツリー", self.open_navigator),
                ("参照式一覧", self.reference_help),
                ("全行を検査", self.audit),
            ],
        )
        group(
            "ヘルプ",
            [
                ("使い方  F1", self.show_help),
                (
                    "このアプリについて",
                    lambda: messagebox.showinfo(
                        APP_NAME,
                        f"{APP_NAME} {APP_VERSION}\n旧名称: CADScriptMaker\n\n表の値からAutoCADのSCRを作成するローカルアプリです。\nAutoCADを自動操作する機能はありません。",
                        parent=self.root,
                    ),
                ),
            ],
        )

    def shortcut(self, event, action):
        # Text entries keep their own undo. Modal editors own their shortcuts.
        if self.root.grab_current() is not None:
            return
        if action in (self.undo_project, self.redo_project) and isinstance(
            event.widget, (tk.Text, tk.Entry, ttk.Entry, ttk.Combobox)
        ):
            return
        action()
        return "break"

    def _checkpoint(self):
        if self._restoring or self.data == self._observed:
            return False
        self._history.append(copy.deepcopy(self._observed))
        del self._history[: -self._history_limit]
        self._future.clear()
        self._observed = copy.deepcopy(self.data)
        return True

    def _restore(self, target):
        self._restoring = True
        try:
            self.close_navigator()
            self.data = copy.deepcopy(target)
            self._observed = copy.deepcopy(self.data)
            self.refresh()
        finally:
            self._restoring = False

    def undo_project(self):
        self._checkpoint()
        if self._history:
            self._future.append(copy.deepcopy(self.data))
            self._restore(self._history.pop())
            self.status.set("変更を元に戻しました")

    def redo_project(self):
        self._checkpoint()
        if self._future:
            self._history.append(copy.deepcopy(self.data))
            self._restore(self._future.pop())
            self.status.set("変更をやり直しました")

    def refresh(self):
        self.capture_selection()
        self._checkpoint()
        target = target_settings(self.data)
        target["selected"] = [i for i in target["selected"] if i < len(self.rows)]
        rows = target["selected"]
        self._syncing_options = True
        self.table_heading.set(f"入力表（{len(self.data['input_tables'])}個）")
        self.table_picker["values"] = [t["name"] for t in self.data["input_tables"]]
        self.drawing_table_picker["values"] = self.table_picker["values"]
        self.table_choice.set(current_table(self.data)["name"])
        self.scope.set(target["mode"])
        self.row_range.set(target["range"])
        self.range_entry.configure(
            state="normal" if target["mode"] == "range" else "disabled"
        )
        self.settings_summary.set(
            "文字高 "
            + str(self.data["settings"].get("TEXT_HEIGHT", "未設定"))
            + " / 寸法尺度 "
            + str(self.data["settings"].get("DIM_SCALE", "図面設定"))
        )
        self.settings_preset_summary.set("設定プリセット: " + active_label(self.data))
        self._syncing_options = False
        keys = list(dict.fromkeys(k for row in self.rows for k in row))
        self.table["columns"] = ["#row-number"] + keys
        self.table.heading("#row-number", text="行")
        self.table.column(
            "#row-number", width=42, minwidth=42, stretch=False, anchor="center"
        )
        for key in keys:
            self.table.heading(key, text=key)
            self.table.column(
                key, width=68, minwidth=60, stretch=False, anchor="center"
            )
        self.table.delete(*self.table.get_children())
        for i, row in enumerate(self.rows):
            self.table.insert(
                "",
                "end",
                iid=str(i),
                values=[i + 1] + [row.get(k, "") for k in keys],
                tags=("alternate",) if i % 2 else (),
            )
        self.table.tag_configure("alternate", background="#f5f8fc")
        self.table.selection_set([str(i) for i in rows if i < len(self.rows)])
        self.block_browser.refresh(self.data)
        self._rendered_table_id = self.data["active_table"]
        self.update_title()
        if self.navigator and self.navigator.winfo_exists():
            self.navigator.refresh()
        self.flow_view.refresh(self.data, self.selected_block())
        self.update_drawing_summary()
        self.adapt_drawing_options()
        self.queue_preview()

    def update_title(self):
        dirty = " • 未保存の変更" if self.has_unsaved_changes() else ""
        name = Path(self.path).name if self.path else self.document_name
        self.document_status.set(name + dirty)
        self.root.title(f"{'* ' if dirty else ''}{name} — {APP_NAME}")
        if self.project_sidebar is not None:
            self.project_sidebar.refresh()

    def show_project_list(self):
        modal = self.root.grab_current()
        if modal is not None:
            modal.winfo_toplevel().lift()
            return None
        if self.project_window is None or not self.project_window.winfo_exists():
            win = tk.Toplevel(self.root)
            self.project_window = win
            win.title("プロジェクト一覧 — " + APP_NAME)
            fit_window(win, 640, 720, 480, 560)
            win.transient(self.root)
            win.protocol("WM_DELETE_WINDOW", win.withdraw)
            win.bind("<Escape>", lambda e: win.withdraw())
            footer = ttk.Frame(win, padding=(14, 0, 14, 14))
            footer.pack(side="bottom", fill="x")
            ttk.Button(footer, text="閉じる", command=win.withdraw).pack(side="right")
            self.project_sidebar = ProjectSidebar(win, self)
            self.project_sidebar.pack(fill="both", expand=True, padx=14, pady=14)
        self.project_sidebar.refresh(force=True)
        current = canonical(self.path) if self.path else "unsaved"
        if self.project_sidebar.tree.exists(current):
            self.project_sidebar.tree.selection_set(current)
            self.project_sidebar.tree.see(current)
        self.project_window.deiconify()
        self.project_window.lift()
        self.project_sidebar.search.focus_set()
        return self.project_window

    @property
    def rows(self):
        return get_rows(self.data)

    def capture_selection(self):
        if self._rendered_table_id == self.data["active_table"] and not self._restoring:
            selected = [i for i in self.selected_rows() if i < len(self.rows)]
            target_settings(self.data)["selected"] = selected

    def on_row_selection(self, event=None):
        if self._syncing_options:
            return
        self.capture_selection()
        self._checkpoint()
        self.update_title()
        self.highlight_preview()
        self.update_drawing_summary()
        self.queue_preview()

    def update_drawing_options(self, *_):
        if self._syncing_options or not hasattr(self, "range_entry"):
            return
        target = target_settings(self.data)
        target["mode"] = self.scope.get()
        target["range"] = self.row_range.get()
        self.range_entry.configure(
            state="normal" if self.scope.get() == "range" else "disabled"
        )
        self.update_title()
        self.update_drawing_summary()
        self.queue_preview()

    def switch_table_by_name(self):
        table = next(
            (
                t
                for t in self.data["input_tables"]
                if t["name"] == self.table_choice.get()
            ),
            None,
        )
        if table:
            self.switch_table(table["id"])

    def switch_table(self, table_id):
        current_table(self.data, table_id)
        if table_id == self.data["active_table"]:
            return
        self.capture_selection()
        self.data["active_table"] = table_id
        self.refresh()

    def table_menu(self):
        menu = tk.Menu(self.root, tearoff=False)
        for label, fn in [
            ("空の入力表を追加", self.new_table),
            ("名前を変更", self.rename_table),
            ("この表を複製", self.duplicate_table),
            ("この表を削除", self.delete_table),
            ("この表をファイルで置き換え…", self.replace_table_file),
        ]:
            menu.add_command(label=label, command=fn)
        try:
            menu.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())
        finally:
            menu.grab_release()

    def new_table(self):
        name = simpledialog.askstring(
            "入力表を追加",
            "新しい入力表の名前",
            initialvalue=unique_table_name(self.data, "入力表"),
            parent=self.root,
        )
        if name is None:
            return
        try:
            add_input_table(self.data, name, [])
        except ValueError as exc:
            return messagebox.showerror("入力表の確認", str(exc), parent=self.root)
        self.refresh()

    def rename_table(self):
        table = current_table(self.data)
        name = simpledialog.askstring(
            "入力表の名前", "新しい名前", initialvalue=table["name"], parent=self.root
        )
        if name is None:
            return
        name = name.strip()
        if not name or any(
            t["id"] != table["id"] and t["name"].casefold() == name.casefold()
            for t in self.data["input_tables"]
        ):
            return messagebox.showerror(
                "入力表の名前", "空欄や他の表と同じ名前は使えません", parent=self.root
            )
        table["name"] = name
        self.refresh()

    def duplicate_table(self):
        self.capture_selection()
        source = current_table(self.data)
        target = copy.deepcopy(target_settings(self.data))
        try:
            table = add_input_table(
                self.data,
                unique_table_name(self.data, source["name"] + " コピー"),
                source["rows"],
            )
        except ValueError as exc:
            return messagebox.showerror("入力表の確認", str(exc), parent=self.root)
        self.data["drawing"]["targets"][table["id"]] = target
        self.refresh()

    def delete_table(self):
        if len(self.data["input_tables"]) <= 1:
            return messagebox.showinfo(
                "入力表の削除",
                "入力表は1つ以上必要です。行を削除すると空の表にできます。",
                parent=self.root,
            )
        table = current_table(self.data)
        if not messagebox.askyesno(
            "入力表を削除",
            f"「{table['name']}」を削除しますか？ 元に戻す操作で復元できます。",
            parent=self.root,
        ):
            return
        self.data["input_tables"].remove(table)
        self.data["drawing"]["targets"].pop(table["id"])
        self.data["active_table"] = self.data["input_tables"][0]["id"]
        self.refresh()

    def replace_table_file(self):
        path = filedialog.askopenfilename(
            parent=self.root, filetypes=[("入力表", "*.xlsx *.csv")]
        )
        if path:
            self.read_table(path, replace=True)

    def manage_settings_presets(self):
        return SettingsPresetEditor(self)

    def edit_drawing_settings(self):
        win = tk.Toplevel(self.root)
        win.title("作図サイズ・共通設定")
        fit_window(win, 620, 500, 560, 460)
        win.transient(self.root)
        win.grab_set()
        ttk.Label(
            win, text="入力表から独立した、プロジェクト共通の設定です。", padding=14
        ).pack(anchor="w")
        ttk.Label(
            win,
            text="文字・寸法サイズはSCRに適用します。\n図形の半径・幅などは、コマンドで settings.名前 を参照して設定できます。",
            style="Muted.TLabel",
            padding=(14, 0),
            wraplength=570,
        ).pack(anchor="w")
        fields = ttk.Frame(win, padding=14)
        fields.pack(fill="x")
        variables = {}
        for key, label, default in [
            ("TEXT_HEIGHT", "文字の高さ", "3.5"),
            ("DIM_TEXT_HEIGHT", "寸法の文字高さ", "3.5"),
            ("ARROW_SIZE", "寸法の矢印サイズ", "2.5"),
            ("DIM_SCALE", "寸法の尺度", "1"),
        ]:
            row = ttk.Frame(fields)
            row.pack(fill="x", pady=5)
            ttk.Label(row, text=label, width=22).pack(side="left")
            var = tk.StringVar(value=str(self.data["settings"].get(key, default)))
            ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True)
            variables[key] = var

        def apply():
            from engine import number

            values = {k: v.get().strip() for k, v in variables.items()}
            try:
                for key, value in values.items():
                    values[key] = number(value, {})
                    if float(values[key]) <= 0:
                        raise MacroError(key + " は正の数値にしてください")
            except MacroError as exc:
                return messagebox.showerror("サイズの確認", str(exc), parent=win)
            self.data["settings"].update(values)
            win.destroy()
            self.refresh()

        footer = ttk.Frame(win, padding=14)
        footer.pack(side="bottom", fill="x")
        ttk.Button(footer, text="キャンセル", command=win.destroy).pack(side="left")
        ttk.Button(
            footer, text="設定を適用", style="Primary.TButton", command=apply
        ).pack(side="right")
        ttk.Label(
            win,
            text="レイヤーや任意の設定値は「設定・変数 → 共通設定」で追加できます。\n文字のフォントと寸法スタイルはAutoCAD側の図面設定を使います。",
            style="Muted.TLabel",
            padding=14,
            wraplength=570,
        ).pack(anchor="w")
        win.bind("<Escape>", lambda e: win.destroy())

    def show_input_table(self):
        self.workspace_tabs.select(self.input_page)

    def edit_cad_setup(self):
        return CadSetupEditor(self)

    def show_drawing(self):
        self.workspace_tabs.select(self.drawing_page)

    def selected_rows(self):
        return sorted(int(i) for i in self.table.selection())

    def selected_block(self):
        selected = self.block_browser.selected_indices()
        return selected[0] if len(selected) == 1 else None

    def activate_block(self, event=None):
        if self.selected_block() is not None:
            self.edit_block()
            return "break"

    def has_unsaved_changes(self):
        return self.data != self._saved

    def project_dialog_parent(self):
        if (
            self.project_window is not None
            and self.project_window.winfo_exists()
            and self.project_window.state() == "normal"
        ):
            return self.project_window
        return self.root

    def confirm_discard(self, what):
        self.table_editor.finish()
        if not self.has_unsaved_changes():
            return True
        answer = messagebox.askyesnocancel(
            "未保存の変更",
            f"{what}する前に変更を保存しますか？\n\nはい: 保存する / いいえ: 変更を破棄 / キャンセル: 戻る",
            parent=self.project_dialog_parent(),
        )
        return False if answer is None else self.save() if answer else True

    def on_exit(self):
        self.table_editor.finish()
        modal = self.root.grab_current()
        if modal is not None and modal.winfo_toplevel() is not self.root:
            modal.winfo_toplevel().lift()
            modal.focus_set()
            self.status.set(
                "編集中の画面を確定またはキャンセルしてから終了してください。"
            )
            return
        if self.confirm_discard("終了"):
            self.persist_workspace()
            self.clear_current_recovery()
            if self._preview_job:
                self.root.after_cancel(self._preview_job)
            self.root.destroy()

    def replace_document(self, data, path=None, name="新規プロジェクト"):
        prepared = normalize_project(data)
        self.table_editor.finish(False)
        self.clear_current_recovery()
        self._rendered_table_id = None
        self.close_navigator()
        self.data = prepared
        self.block_browser.reset_view()
        self.path = path
        self.document_name = name
        self._history.clear()
        self._future.clear()
        self._saved = copy.deepcopy(self.data)
        self._observed = copy.deepcopy(self.data)
        self.canvas.items = []
        self.refresh()
        self.show_drawing()
        self.queue_preview()

    def new(self):
        if self.confirm_discard("新規作成"):
            self.replace_document(EMPTY)
            self.status.set("表を読み込むか、行を追加して始めてください")

    def load_sample(self):
        if self.confirm_discard("サンプルを開く"):
            self.replace_document(EXAMPLE, name="サンプルプロジェクト")
            self.status.set("条件分岐・等配穴のサンプルを開きました")

    def load(self):
        path = filedialog.askopenfilename(
            parent=self.project_dialog_parent(),
            initialdir=str(self.project_library.directory),
            filetypes=[("CADFlow プロジェクト", "*.json")],
        )
        if not path:
            return False
        return self.open_project(path)

    def remember_project(self, path):
        try:
            self.project_library.remember(path)
            return ""
        except (OSError, ValueError) as exc:
            return "（一覧設定の保存に失敗しました: " + str(exc) + "）"

    def open_project(self, path):
        try:
            path = canonical(path)
            if Path(path).stat().st_size > 20 * 1024 * 1024:
                raise ValueError("プロジェクトは20MBまでです")
            data = normalize_project(
                json.loads(Path(path).read_text(encoding="utf-8-sig"))
            )
            if not self.confirm_discard("プロジェクトを開く"):
                return False
            # A save during the confirmation may have updated this same file.
            if Path(path).stat().st_size > 20 * 1024 * 1024:
                raise ValueError("プロジェクトは20MBまでです")
            source = json.loads(Path(path).read_text(encoding="utf-8-sig"))
            migrated = "presets" in source
            data = normalize_project(source)
            self.replace_document(data, path)
            notice = self.remember_project(path)
            if self.project_sidebar is not None:
                self.project_sidebar.refresh()
            self.status.set(
                (
                    "旧JSONをブロック構造へ移行して開きました（元ファイルは保存するまで維持）: "
                    if migrated
                    else "開きました: "
                )
                + str(path)
                + notice
            )
            return True
        except Exception as exc:
            messagebox.showerror(
                "プロジェクトを開けません",
                str(exc),
                parent=self.project_dialog_parent(),
            )
            return False

    def changes(self):
        names = {
            "input_tables": "入力表",
            "active_table": "作図対象表",
            "drawing": "対象行の作図設定",
            "settings": "共通設定",
            "cad_setup": "CAD初期設定",
            "settings_presets": "設定プリセット",
            "active_settings_preset": "適用中の設定プリセット",
            "globals": "グローバル変数",
            "blocks": "ブロック",
            "custom_commands": "登録コマンド",
        }
        return [
            name + "を変更"
            for key, name in names.items()
            if self._saved.get(key) != self.data.get(key)
        ]

    def save_as(self):
        return self.save(choose_path=True)

    def save(self, choose_path=False):
        from audit import audit_project

        self.table_editor.finish()
        self.capture_selection()
        self._checkpoint()
        problems = audit_project(self.data)
        if problems and not messagebox.askyesno(
            "未解決の問題があります",
            "\n".join(problems[:8])
            + "\n\n編集途中として保存しますか？\nSCRを書き出す前に問題を解消してください。",
            parent=self.project_dialog_parent(),
        ):
            return False
        if not self.path or choose_path:
            try:
                self.project_library.ensure_directory()
            except OSError as exc:
                messagebox.showerror(
                    "保存フォルダーを用意できません",
                    str(exc),
                    parent=self.project_dialog_parent(),
                )
                return False
        path = (None if choose_path else self.path) or filedialog.asksaveasfilename(
            parent=self.project_dialog_parent(),
            defaultextension=".json",
            initialdir=str(self.project_library.directory),
            initialfile=Path(self.path).name if self.path else "project.json",
            filetypes=[("CADFlow プロジェクト", "*.json")],
        )
        if not path:
            return False
        try:
            if canonical(path) == str(self.project_library.state_path):
                raise ValueError(
                    "一覧管理用のlibrary.jsonには保存できません。別のファイル名を指定してください。"
                )
            if Path(canonical(path)).is_relative_to(
                self.workspace_state.directory.resolve()
            ):
                raise ValueError(
                    "作業状態・復元用フォルダーには保存できません。別の場所を指定してください。"
                )
            atomic_save(path, self.data)
            self.path = canonical(path)
            self._saved = copy.deepcopy(self.data)
            self.clear_current_recovery()
            notice = self.remember_project(path)
            self.refresh()
            self.status.set("保存しました: " + str(path) + notice)
            return True
        except Exception as exc:
            messagebox.showerror(
                "保存できません", str(exc), parent=self.project_dialog_parent()
            )
            return False

    def show_changes(self):
        self.show_text(
            "保存済みとの変更",
            "\n".join(details(self._saved, self.data)) or "変更はありません。",
        )

    def show_text(self, title, text):
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry("860x570")
        win.transient(self.root)
        frame = ttk.Frame(win, padding=14)
        frame.pack(fill="both", expand=True)
        body = tk.Text(frame, wrap="word", relief="flat", padx=12, pady=12)
        scroll = ttk.Scrollbar(frame, command=body.yview)
        body.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        body.pack(fill="both", expand=True)
        body.insert("1.0", text)
        body.configure(state="disabled")
        ttk.Button(win, text="閉じる", command=win.destroy).pack(pady=(0, 12))
        win.bind("<Escape>", lambda e: win.destroy())
        return win

    def import_table(self):
        path = filedialog.askopenfilename(
            parent=self.root,
            filetypes=[
                ("入力表", "*.xlsx *.csv"),
                ("Excel", "*.xlsx"),
                ("CSV", "*.csv"),
            ],
        )
        if path:
            self.read_table(path)

    def read_table(self, path, replace=False):
        try:
            if Path(path).suffix.lower() == ".csv":
                rows = read_csv(path)
            else:
                names = sheet_names(path)
                sheet = names[0] if len(names) == 1 else self.choose_sheet(names)
                if sheet is None:
                    return False
                header = simpledialog.askinteger(
                    "見出しの位置",
                    "列名がある行番号",
                    initialvalue=1,
                    minvalue=1,
                    parent=self.root,
                )
                if header is None:
                    return False
                rows = read_excel(path, sheet, header)
            if replace:
                if not messagebox.askyesno(
                    "入力表の置き換え",
                    f"「{current_table(self.data)['name']}」を{len(rows)}行の表に置き換えますか？",
                    parent=self.root,
                ):
                    return False
                current_table(self.data)["rows"] = rows
                self.data["drawing"]["targets"][self.data["active_table"]] = (
                    default_target(rows)
                )
            else:
                name = unique_table_name(
                    self.data,
                    Path(path).stem
                    + ((" / " + sheet) if Path(path).suffix.lower() != ".csv" else ""),
                )
                add_input_table(self.data, name, rows)
            self.refresh()
            self.queue_preview()
            self.show_input_table()
            self.status.set(f"{Path(path).name} から {len(rows)}行を読み込みました")
            return True
        except ImportError:
            messagebox.showerror(
                "Excel読込の準備",
                "Excelの読込には openpyxl が必要です。\nREADMEの「起動」を参照してください。",
                parent=self.root,
            )
        except Exception as exc:
            messagebox.showerror("表を読み込めません", str(exc), parent=self.root)
        return False

    def import_csv(self):
        self.import_table()

    def import_excel(self):
        self.import_table()

    def choose_sheet(self, names):
        win = tk.Toplevel(self.root)
        win.title("シートを選択")
        win.transient(self.root)
        win.grab_set()
        result = []
        ttk.Label(win, text="読み込むシート", padding=14).pack()
        value = tk.StringVar(value=names[0])
        ttk.Combobox(
            win, values=names, textvariable=value, state="readonly", width=35
        ).pack(padx=14)
        ttk.Button(
            win,
            text="次へ",
            command=lambda: (result.append(value.get()), win.destroy()),
        ).pack(pady=14)
        self.root.wait_window(win)
        return result[0] if result else None

    def edit_key_values(
        self, title, value, kind="settings", parent=None, validator=None
    ):
        parent = parent or self.root
        win = tk.Toplevel(parent)
        win.title(title)
        win.geometry("750x540")
        win.transient(parent)
        win.grab_set()
        win.bind("<Escape>", lambda e: win.destroy())
        hint = (
            "値は式として上から順に計算します。文字列には引用符を付けます。"
            if kind == "globals"
            else "設定値は数値または文字列です。settings.名前 で参照できます。"
        )
        ttk.Label(win, text=hint, padding=12, wraplength=710).pack(anchor="w")
        frame = ttk.Frame(win, padding=(12, 0))
        frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(
            frame, columns=("key", "value"), show="headings", selectmode="browse"
        )
        tree.heading("key", text="名前")
        tree.heading("value", text="式 / 値")
        tree.column("key", width=210)
        tree.column("value", width=420)
        tree.pack(fill="both", expand=True)
        for key, val in value.items():
            tree.insert("", "end", values=(key, str(val)))
        fields = ttk.Frame(win, padding=12)
        fields.pack(fill="x")
        name = tk.StringVar()
        val = tk.StringVar()
        ttk.Label(fields, text="名前").grid(row=0, column=0)
        ttk.Entry(fields, textvariable=name, width=22).grid(row=0, column=1, padx=6)
        ttk.Label(fields, text="値").grid(row=0, column=2)
        ttk.Entry(fields, textvariable=val, width=35).grid(row=0, column=3, padx=6)
        result = []

        def select(_=None):
            if tree.selection():
                a, b = tree.item(tree.selection()[0], "values")
                name.set(a)
                val.set(b)

        tree.bind("<<TreeviewSelect>>", select)

        def upsert():
            key = name.get().strip()
            selected = tree.selection()
            if not valid_name(key):
                messagebox.showerror(
                    "名前",
                    "英数字と_で指定してください。予約名は使えません",
                    parent=win,
                )
                return False
            if any(
                tree.item(i, "values")[0] == key
                for i in tree.get_children()
                if not selected or i != selected[0]
            ):
                messagebox.showerror("名前の重複", "同じ名前があります", parent=win)
                return False
            if selected:
                tree.item(selected[0], values=(key, val.get()))
            else:
                tree.selection_set(tree.insert("", "end", values=(key, val.get())))
            return True

        bar = ttk.Frame(win, padding=(12, 0))
        bar.pack(fill="x")
        ttk.Button(bar, text="入力した値を追加 / 更新", command=upsert).pack(
            side="left"
        )
        ttk.Button(
            bar,
            text="新しい項目",
            command=lambda: (
                tree.selection_remove(tree.selection()),
                name.set(""),
                val.set(""),
            ),
        ).pack(side="left", padx=4)
        ttk.Button(
            bar,
            text="選択を削除",
            command=lambda: [tree.delete(i) for i in tree.selection()],
        ).pack(side="left")

        def done():
            selected = tree.selection()
            pending = (name.get().strip(), val.get())
            original = tuple(tree.item(selected[0], "values")) if selected else ("", "")
            if pending != original and (pending[0] or pending[1]) and not upsert():
                return
            data = {
                tree.item(i, "values")[0]: tree.item(i, "values")[1]
                for i in tree.get_children()
            }
            errors = validator(data) if validator else []
            if errors:
                messagebox.showerror("設定値の確認", "\n".join(errors[:12]), parent=win)
                return
            result.append(data)
            win.destroy()

        ttk.Button(
            win, text="表の内容を確定", style="Primary.TButton", command=done
        ).pack(pady=14)
        self.root.wait_window(win)
        return result[0] if result else None

    def edit_settings(self):
        data = self.edit_key_values("プロジェクト共通設定", self.data["settings"])
        if data is not None:
            self.data["settings"] = data
            self.refresh()

    def edit_globals(self):
        data = self.edit_key_values("グローバル変数", self.data["globals"], "globals")
        if data is not None:
            self.data["globals"] = data
            self.refresh()

    def project_settings(self):
        menu = tk.Menu(self.root, tearoff=False)
        menu.add_command(label="CAD初期設定", command=self.edit_cad_setup)
        menu.add_command(label="設定プリセット", command=self.manage_settings_presets)
        menu.add_command(label="共通設定", command=self.edit_settings)
        menu.add_command(label="グローバル変数", command=self.edit_globals)
        menu.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())

    def edit_row_values(self, title, row):
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry("530x610")
        win.transient(self.root)
        win.grab_set()
        result = []
        ttk.Label(
            win,
            text="各列の値を入力してください。数値と文字列を入力できます。",
            padding=14,
            wraplength=490,
        ).pack(anchor="w")
        canvas = tk.Canvas(win, highlightthickness=0)
        scroll = ttk.Scrollbar(win, command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(fill="both", expand=True, padx=14)
        form = ttk.Frame(canvas)
        window = canvas.create_window(0, 0, window=form, anchor="nw")
        canvas.bind(
            "<Configure>", lambda e: canvas.itemconfigure(window, width=e.width)
        )
        form.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        variables = {}
        for key, value in row.items():
            field = ttk.Frame(form)
            field.pack(fill="x", pady=5)
            ttk.Label(field, text=key, width=15).pack(side="left")
            variable = tk.StringVar(value=str(value))
            ttk.Entry(field, textvariable=variable).pack(
                side="left", fill="x", expand=True
            )
            variables[key] = variable

        def done():
            result.append({k: v.get() for k, v in variables.items()})
            win.destroy()

        buttons = ttk.Frame(win, padding=14)
        buttons.pack(side="bottom", fill="x", before=canvas)
        ttk.Button(buttons, text="キャンセル", command=win.destroy).pack(side="left")
        ttk.Button(
            buttons, text="行を確定", style="Primary.TButton", command=done
        ).pack(side="right")
        self.root.wait_window(win)
        return result[0] if result else None

    def add_row(self):
        if len(self.rows) >= 10000:
            return messagebox.showerror(
                "行数の上限", "1つの入力表は10000行までです", parent=self.root
            )
        keys = list(dict.fromkeys(k for row in self.rows for k in row))
        if not keys:
            names = simpledialog.askstring(
                "入力表の列",
                "列名をカンマ区切りで入力（例: TYPE,X,Y,OD,R）",
                initialvalue="TYPE,X,Y,OD,R",
                parent=self.root,
            )
            if names is None:
                return
            from table_io import headers

            try:
                keys = headers(names.split(","))
            except ValueError as exc:
                return messagebox.showerror("列名の確認", str(exc), parent=self.root)
        data = self.edit_row_values("行を追加", dict.fromkeys(keys, "0"))
        if data is not None:
            self.rows.append(data)
            target_settings(self.data)["selected"] = [len(self.rows) - 1]
            self._rendered_table_id = None
            self.refresh()

    def edit_row(self):
        rows = self.selected_rows()
        if len(rows) != 1:
            return messagebox.showinfo(
                "行を選択", "編集する行を1つ選択してください", parent=self.root
            )
        data = self.edit_row_values(f"{rows[0] + 1}行目を編集", self.rows[rows[0]])
        if data is not None:
            self.rows[rows[0]] = data
            self.refresh()

    def duplicate_rows(self):
        ids = self.selected_rows()
        if len(self.rows) + len(ids) > 10000:
            return messagebox.showerror(
                "行数の上限", "1つの入力表は10000行までです", parent=self.root
            )
        for i in reversed(ids):
            self.rows.insert(i + 1, copy.deepcopy(self.rows[i]))
        target_settings(self.data)["selected"] = [
            i + 1 + offset for offset, i in enumerate(ids)
        ]
        self._rendered_table_id = None
        self.refresh()

    def del_row(self):
        ids = self.selected_rows()
        if not ids:
            return
        if not messagebox.askyesno(
            "行の削除",
            f"{len(ids)}行を削除しますか？ 元に戻す操作で復元できます。",
            parent=self.root,
        ):
            return
        for i in reversed(ids):
            self.rows.pop(i)
        target_settings(self.data)["selected"] = []
        self._rendered_table_id = None
        self.refresh()

    def add_block(self):
        trial = copy.deepcopy(self.data)
        block = new_block()
        folder_id = self.block_browser.selected_folder()
        if folder_id:
            block["folder_id"] = folder_id
        trial["blocks"].append(block)

        def commit():
            self.data["blocks"] = copy.deepcopy(trial["blocks"])
            self.refresh()
            self.block_browser.reveal(
                next(
                    i
                    for i, b in enumerate(self.data["blocks"])
                    if b["id"] == block["id"]
                )
            )

        MacroEditor(
            self.root, block, trial["blocks"], commit, trial, self.selected_rows()
        )

    def edit_block(self):
        index = self.selected_block()
        if index is None:
            if any(n.startswith("folder:") for n in self.block_list.selection()):
                return self.block_browser.rename_folder()
            return messagebox.showinfo(
                "ブロックを選択", "編集するブロックを選択してください", parent=self.root
            )
        self.edit_block_index(index)

    def edit_block_index(self, index):
        if 0 <= index < len(self.data["blocks"]):
            MacroEditor(
                self.root,
                self.data["blocks"][index],
                self.data["blocks"],
                self.refresh,
                self.data,
                self.selected_rows(),
            )

    def manage_custom_commands(self):
        CommandCatalogManager(self.root, self.data, self.refresh)

    def toggle_block_draw(self):
        i = self.selected_block()
        if i is not None:
            self.data["blocks"][i]["draw"] = not self.data["blocks"][i].get(
                "draw", True
            )
            self.refresh()

    def del_block(self):
        index = self.selected_block()
        if index is None:
            if any(n.startswith("folder:") for n in self.block_list.selection()):
                return self.block_browser.delete_folder()
            return
        block = self.data["blocks"][index]
        callers = references(self.data, block["id"], exclude=block["id"])
        if callers:
            return messagebox.showerror(
                "使用中のブロック",
                "先に呼び出し元を変更してください。\n" + "\n".join(callers),
                parent=self.root,
            )
        if messagebox.askyesno(
            "ブロックの削除", f"「{block['name']}」を削除しますか？", parent=self.root
        ):
            self.data["blocks"].pop(index)
            self.refresh()

    def move_block(self, delta):
        i = self.selected_block()
        if i is not None and 0 <= i + delta < len(self.data["blocks"]):
            presets = self.data["blocks"]
            presets[i], presets[i + delta] = presets[i + delta], presets[i]
            self.refresh()
            self.block_browser.reveal(i + delta)

    def open_navigator(self):
        if self.navigator and self.navigator.winfo_exists():
            self.navigator.lift()
            return
        self.navigator = ProjectNavigator(
            self.root,
            self.data,
            self.edit_block_index,
            self.add_block,
            self.refresh,
            undo=self.undo_project,
            redo=self.redo_project,
        )

    def close_navigator(self):
        if self.navigator and self.navigator.winfo_exists():
            self.navigator.destroy()
        self.navigator = None

    def reference_help(self):
        candidates = ["入力表: @列名 / row.列名"]
        candidates += [
            "@" + key for key in dict.fromkeys(k for row in self.rows for k in row)
        ]
        candidates += ["\n共通設定: settings." + k for k in self.data["settings"]]
        candidates += ["global." + k for k in self.data["globals"]]
        for preset in self.data["blocks"]:
            candidates += [
                "local." + k + "  (" + preset["name"] + ")"
                for k in preset.get("variables", {})
            ]
        candidates += ["\n繰り返しの内側: loop.index / loop.number / loop.count"]
        self.show_text("参照式の一覧", "\n".join(candidates))

    def target_rows(self, all_rows=None):
        if all_rows is True:
            return list(range(len(self.rows)))
        if all_rows is False or self.scope.get() == "selected":
            return self.selected_rows()
        if self.scope.get() == "all":
            return list(range(len(self.rows)))
        try:
            return parse_row_range(self.row_range.get(), len(self.rows))
        except ValueError as exc:
            raise MacroError(str(exc)) from exc

    def compile(self, all_rows=None):
        if not self.rows:
            raise MacroError("Excel / CSVを読み込むか、入力表に行を追加してください。")
        indices = self.target_rows(all_rows)
        if not indices:
            raise MacroError(
                "作図設定で対象行を選択してください。行番号や全行でも指定できます。"
            )
        self.command_diagnostics = []
        result = compile_project(
            self.data, indices, diagnostics=self.command_diagnostics
        )
        return result

    def queue_preview(self):
        if self._preview_job:
            self.root.after_cancel(self._preview_job)
        self._preview_job = self.root.after(180, lambda: self.preview(quiet=True))

    def set_script(self, text):
        self.script.configure(state="normal")
        self.script.delete("1.0", "end")
        self.script.insert("1.0", text)
        self.script.configure(state="disabled")

    def preview(self, quiet=False):
        self._checkpoint()
        if self._preview_job:
            self.root.after_cancel(self._preview_job)
            self._preview_job = None
        self.selection_status.set(
            f"{len(self.rows)}行中 {len(self.selected_rows())}行を選択 · Ctrl / Shift で複数選択"
        )
        self.drawing_selection_summary.set(
            f"全{len(self.rows)}行 / 選択{len(self.selected_rows())}行"
        )
        self.update_drawing_summary()
        try:
            script, items = self.compile()
            custom_count = sum(e["type"] == "CUSTOM" for e in self.command_diagnostics)
            self.canvas.set_items(
                items,
                message="登録コマンドの図形はプレビュー対象外です。生成SCRで確認してください。"
                if custom_count
                else None,
            )
            self.highlight_preview()
            self.set_script(script)
            self.preview_status.set(
                f"{current_table(self.data)['name']} · 対象{len(self.target_rows())}行 / {len(items)}図形"
            )
            if custom_count:
                self.preview_status.set(
                    self.preview_status.get() + f" / 登録{custom_count}件はSCRのみ"
                )
            self.status.set("生成結果を更新しました。SCRタブでコマンドを確認できます。")
            return script, items
        except Exception as exc:
            self.command_diagnostics = []
            self.canvas.set_items([])
            self.set_script("")
            self.preview_status.set("未生成")
            self.status.set(str(exc))
            if not quiet and self.rows:
                messagebox.showerror("生成内容の確認", str(exc), parent=self.root)
            return None

    def copy_script(self):
        result = self.preview()
        if result:
            self.root.clipboard_clear()
            self.root.clipboard_append(result[0])
            self.status.set("生成SCRをコピーしました")

    def audit(self):
        from inspection import InspectionWindow

        self.table_editor.finish()
        win = InspectionWindow(self)
        return [record["message"] for record in win.records]

    def update_drawing_summary(self):
        self.drawing_selection_summary.set(
            f"全{len(self.rows)}行 / 選択{len(self.selected_rows())}行"
        )
        try:
            target = self.target_rows()
            count = len(target)
            numbers = ",".join(str(i + 1) for i in target[:8])
            if count > 8:
                numbers += "…"
            rows = f"{count}行" + (f"（{numbers}）" if numbers else "")
        except ValueError:
            rows = "行番号を確認してください"
        mode = {"selected": "選択行", "range": "行番号", "all": "全行"}.get(
            self.scope.get(), ""
        )
        enabled = sum(p.get("draw", True) for p in self.data["blocks"])
        setup = "ON" if self.data.get("cad_setup", {}).get("enabled") else "OFF"
        self.drawing_summary.set(
            f"作図条件  |  表: {current_table(self.data)['name']}  |  対象: {mode} / {rows}  |  作図ブロック: {enabled}件  |  CAD初期設定: {setup}"
        )

    def edit_target_settings(self):
        win = getattr(self, "target_window", None)
        if win is not None and win.winfo_exists():
            win.lift()
            return win
        win = self.target_window = tk.Toplevel(self.root)
        win.title("作図設定")
        win.transient(self.root)
        fit_window(win, 610, 330, 520, 300)
        body = ttk.Frame(win, padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, textvariable=self.drawing_summary, wraplength=550).pack(
            fill="x", pady=(0, 12)
        )
        options = ttk.Frame(body)
        options.pack(fill="x")
        for text, value in (
            ("選択行", "selected"),
            ("行番号", "range"),
            ("全行", "all"),
        ):
            ttk.Radiobutton(options, text=text, variable=self.scope, value=value).pack(
                side="left", padx=(0, 12)
            )
        ranges = ttk.Frame(body)
        ranges.pack(fill="x", pady=10)
        ttk.Label(ranges, text="行番号（例: 1-3,5）:").pack(side="left")
        entry = ttk.Entry(ranges, textvariable=self.row_range, width=24)
        entry.pack(side="left", padx=8)

        def sync_range(*_):
            entry.configure(
                state="normal" if self.scope.get() == "range" else "disabled"
            )

        sync_range()
        trace = self.scope.trace_add("write", sync_range)
        win.bind(
            "<Destroy>",
            lambda e: self.scope.trace_remove("write", trace)
            if e.widget is win
            else None,
        )
        ttk.Label(body, textvariable=self.settings_preset_summary).pack(anchor="w")
        ttk.Label(body, textvariable=self.settings_summary, style="Muted.TLabel").pack(
            anchor="w"
        )
        bar = ttk.Frame(body)
        bar.pack(fill="x", pady=12)
        ttk.Button(
            bar, text="設定プリセット…", command=self.manage_settings_presets
        ).pack(side="left")
        ttk.Button(
            bar, text="サイズ・共通設定…", command=self.edit_drawing_settings
        ).pack(side="left", padx=8)
        ttk.Button(bar, text="閉じる", command=win.destroy).pack(side="right")
        win.bind("<Escape>", lambda e: win.destroy())
        return win

    def on_block_selection(self, event=None):
        self.flow_view.refresh(self.data, self.selected_block())
        self.highlight_preview()

    def highlight_preview(self, address=None):
        if self.highlight_enabled.get():
            self.canvas.highlight(self.selected_rows(), self.selected_block(), address)
        else:
            self.canvas.highlight()

    def edit_flow_command(self, address):
        from macro_editor import edit_command

        trial = copy.deepcopy(self.data)
        command = resolve(trial, address)
        preset = self.selected_block()
        local_names = (
            trial["blocks"][preset].get("variables", {}) if preset is not None else ()
        )
        edited = edit_command(
            self.root,
            command,
            trial["blocks"],
            trial,
            local_names,
            sample_locals=local_names if isinstance(local_names, dict) else None,
            folder_id=trial["blocks"][preset].get("folder_id", "")
            if preset is not None else "",
        )
        if edited is not None:
            resolve(trial, address[:-1])[address[-1]] = edited
            errors = validate_project(trial)
            if errors:
                messagebox.showerror(
                    "フローの確認", "\n".join(errors[:8]), parent=self.root
                )
                return
            self.data["blocks"] = trial["blocks"]
            self.refresh()
            self.flow_view.select_address(self.data, address)

    def navigate_issue(self, record):
        try:
            table_id = record.get("table_id")
            if table_id:
                self.switch_table(table_id)
            row = record.get("row")
            # Focus marks the erroneous row without changing the selected drawing targets.
            if row is not None:
                if not self.table.exists(str(row)):
                    raise ValueError("行が変更されています")
                self.table.focus(str(row))
                self.table.see(str(row))
                self.table.tag_configure("issue", background="#fff0bd")
                for node in self.table.get_children():
                    self.table.item(
                        node,
                        tags=tuple(
                            t for t in self.table.item(node, "tags") if t != "issue"
                        ),
                    )
                self.table.item(
                    str(row), tags=(*self.table.item(str(row), "tags"), "issue")
                )
                self.show_input_table()
            index = record.get("block_index")
            if record.get("address") and record["address"][0] == "blocks":
                index = record["address"][1]
            if index is not None:
                self.block_browser.reveal(index)
                self.flow_view.refresh(self.data, index)
                self.show_drawing()
                self.block_tabs.select(0)
            address = record.get("address")
            if address and index is not None:
                self.show_drawing()
                self.block_tabs.select(self.flow_view)
                self.flow_view.select_address(self.data, tuple(address))
            elif record.get("drawing"):
                self.show_drawing()
                if self.drawing_options_frame.winfo_ismapped():
                    self.range_entry.focus_set()
                else:
                    self.edit_target_settings()
            elif record.get("resource") == "globals":
                self.edit_globals()
            elif record.get("resource") == "settings":
                self.edit_settings()
            elif record.get("resource") == "cad_setup":
                self.edit_cad_setup()
            elif record.get("catalog"):
                self.manage_custom_commands()
            self.status.set(record["message"])
        except (KeyError, IndexError, ValueError, tk.TclError):
            self.status.set("検査後に構成が変更されています。再検査してください。")

    def cleanup_jobs(self, event):
        if event.widget is self.root:
            for name in ("_preview_job", "_session_job", "_startup_job"):
                job = getattr(self, name, None)
                if job:
                    self.root.after_cancel(job)
                    setattr(self, name, None)

    def persist_workspace(self):
        try:
            self.workspace_state.write(
                "view",
                {
                    "geometry": self.root.geometry(),
                    "path": self.path,
                    "workspace_tab": self.workspace_tabs.index("current"),
                    "result_tab": self.result_tabs.index("current"),
                    "block_tab": self.block_tabs.index("current"),
                    "block": self.selected_block(),
                    "block_browser": self.block_browser.get_view(),
                    "sash": self.drawing_panes.sashpos(0),
                    "preview": self.canvas.get_view(),
                    "highlight": self.highlight_enabled.get(),
                },
            )
            return True
        except (OSError, ValueError, tk.TclError) as exc:
            self.status.set("作業状態を保存できません: " + str(exc))
            return False

    def autosave_workspace(self, reschedule=True):
        try:
            self.persist_workspace()
            snapshot = copy.deepcopy(self.data)
            editor = self.table_editor
            if editor.entry is not None:
                row, col = editor.cell
                get_rows(snapshot)[row][editor.keys()[col]] = editor.entry.get()
            if snapshot != self._saved:
                self.workspace_state.save_recovery(
                    self._draft_id,
                    {"data": snapshot, "name": self.document_name, "source": self.path},
                )
            else:
                self.workspace_state.remove_recovery(self._draft_id)
        except (OSError, ValueError, IndexError, tk.TclError) as exc:
            self.status.set("作業の復元データを保存できません: " + str(exc))
        finally:
            if reschedule:
                self._session_job = self.root.after(15000, self.autosave_workspace)

    def restore_workspace(self):
        self._startup_job = None
        state = self.workspace_state.read("view", 128 * 1024)
        if not state:
            return
        try:
            path = state.get("path")
            if (
                isinstance(path, str)
                and Path(path).is_file()
                and Path(path).stat().st_size <= 20 * 1024 * 1024
            ):
                data = normalize_project(
                    json.loads(Path(path).read_text(encoding="utf-8-sig"))
                )
                self.replace_document(data, path)
            geometry = re.fullmatch(
                r"(\d+)x(\d+)([+-]\d+)([+-]\d+)", str(state.get("geometry", ""))
            )
            if geometry:
                w, h, x, y = map(int, geometry.groups())
                sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
                w, h = min(sw, max(1040, w)), min(sh, max(680, h))
                x, y = max(0, min(x, sw - w)), max(0, min(y, sh - h))
                self.root.geometry(f"{w}x{h}+{x}+{y}")
            for notebook, key in (
                (self.workspace_tabs, "workspace_tab"),
                (self.result_tabs, "result_tab"),
                (self.block_tabs, "block_tab"),
            ):
                index = state.get(key, 0)
                if type(index) is int and 0 <= index < len(notebook.tabs()):
                    notebook.select(index)
            self.root.update_idletasks()
            self.block_browser.restore_view(state.get("block_browser", {}))
            preset = state.get("block", state.get("preset"))
            if (
                not state.get("block_browser")
                and type(preset) is int
                and 0 <= preset < len(self.data["blocks"])
            ):
                self.block_browser.reveal(preset)
                self.flow_view.refresh(self.data, preset)
            if type(state.get("highlight")) is bool:
                self.highlight_enabled.set(state["highlight"])
            sash = state.get("sash", 430)
            if type(sash) is int:
                self.drawing_panes.sashpos(
                    0, max(300, min(sash, self.drawing_panes.winfo_width() - 350))
                )
            self.preview(quiet=True)
            self.canvas.restore_view(state.get("preview", {}))
        except (OSError, ValueError, TypeError, KeyError, tk.TclError):
            self.status.set(
                "前回の表示状態を復元できないため、既定の表示で続行します。"
            )

    def discard_recovery(self):
        if not messagebox.askyesno(
            "復元データの破棄", "前回の未保存データを破棄しますか？", parent=self.root
        ):
            return
        try:
            self.workspace_state.remove_recovery(self._recovery["id"])
            self.refresh_recovery_banner()
        except OSError as exc:
            messagebox.showerror("復元データの破棄", str(exc), parent=self.root)

    def restore_recovery(self):
        if not self._recovery:
            return
        try:
            identity = self._recovery["id"]
            data = normalize_project(self._recovery["data"])
            if not self.confirm_discard("復元"):
                return
            self.replace_document(
                data, name=str(self._recovery.get("name", "プロジェクト")) + "（復元）"
            )
            self._saved = normalize_project(EMPTY)
            self.update_title()
            # Save the restored copy before removing its previous recovery entry.
            self.workspace_state.save_recovery(
                self._draft_id,
                {"data": self.data, "name": self.document_name, "source": None},
            )
            self.workspace_state.remove_recovery(identity)
            self.refresh_recovery_banner()
            self.status.set(
                "未保存データを別のプロジェクトとして復元しました。名前を付けて保存してください。"
            )
        except (OSError, ValueError, KeyError, TypeError) as exc:
            messagebox.showerror("復元できません", str(exc), parent=self.root)

    def clear_current_recovery(self):
        try:
            self.workspace_state.remove_recovery(self._draft_id)
        except OSError as exc:
            self.status.set("復元データの更新に失敗しました: " + str(exc))

    def refresh_recovery_banner(self):
        self._recoveries = [
            d for d in self.workspace_state.recoveries() if d["id"] != self._draft_id
        ]
        self._recovery = self._recoveries[0] if self._recoveries else None
        self.recovery_choice.configure(
            values=[
                f"{i + 1}. {d.get('name', 'プロジェクト')}"
                for i, d in enumerate(self._recoveries)
            ]
        )
        if self._recoveries:
            self.recovery_choice.current(0)
        else:
            self.recovery_banner.pack_forget()

    def export(self, all_rows=None):
        try:
            script, items = self.compile(all_rows)
        except Exception as exc:
            return messagebox.showerror(
                "SCRを生成できません", str(exc), parent=self.root
            )
        win = tk.Toplevel(self.root)
        win.title("SCRを書き出す")
        fit_window(win, 560, 420, 540, 400)
        win.transient(self.root)
        win.grab_set()
        n = len(self.target_rows(all_rows))
        custom_count = sum(e["type"] == "CUSTOM" for e in self.command_diagnostics)
        ttk.Label(
            win,
            text=f"{current_table(self.data)['name']} · {n}行 / 標準{len(items)}図形"
            + (f" / 登録{custom_count}件" if custom_count else ""),
            style="Section.TLabel",
            padding=16,
        ).pack(anchor="w")
        ttk.Label(
            win, text="AutoCADの環境に合う文字コードを選んでください。", padding=(16, 0)
        ).pack(anchor="w")
        ttk.Label(
            win,
            text="CAD初期設定マクロ: "
            + (
                "ON（不足する定義を作成）"
                if self.data.get("cad_setup", {}).get("enabled", False)
                else "OFF（既存の定義を使用）"
            ),
            padding=(16, 4),
            style="Muted.TLabel",
        ).pack(anchor="w")
        for label, value in [
            ("Shift-JIS（CP932）・日本語Windows向け", "cp932"),
            ("UTF-8・対応するAutoCAD環境向け", "utf-8"),
        ]:
            ttk.Radiobutton(win, text=label, variable=self.encoding, value=value).pack(
                anchor="w", padx=18, pady=8
            )
        ttk.Label(
            win,
            text="作図後、スナップ等の設定を実行前の値へ戻します。\nAutoLISP対応のAutoCADが必要です（LTは2024以降）。\n中断した場合は、コマンド待機状態で CADFLOWRESTORE を実行。\nTEXTは高さ0の文字スタイルで実行してください。",
            style="Muted.TLabel",
            padding=(16, 8),
            wraplength=520,
        ).pack(anchor="w")

        def write():
            try:
                script.encode(self.encoding.get())
            except UnicodeEncodeError:
                return messagebox.showerror(
                    "文字コードの確認",
                    "Shift-JISに変換できない文字があります。UTF-8を選択するか、文字・レイヤー名を変更してください。",
                    parent=win,
                )
            path = filedialog.asksaveasfilename(
                parent=win,
                defaultextension=".scr",
                initialfile="drawing.scr",
                filetypes=[("AutoCAD Script", "*.scr")],
            )
            if not path:
                return
            try:
                atomic_write_script(path, script, self.encoding.get())
                win.destroy()
                self.status.set(f"SCR出力完了 · {n}行 / {len(items)}図形 · {path}")
            except Exception as exc:
                messagebox.showerror("SCRを書き込めません", str(exc), parent=win)

        ttk.Button(
            win, text="保存先を選んで書き出す", style="Primary.TButton", command=write
        ).pack(pady=10)

    def show_help(self):
        self.show_text(
            "CADFlow Studio の使い方",
            (ROOT / "docs" / "QUICK_START.txt").read_text(encoding="utf-8"),
        )


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
