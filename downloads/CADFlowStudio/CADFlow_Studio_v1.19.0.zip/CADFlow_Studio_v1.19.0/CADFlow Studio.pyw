"""Windowed Windows launcher. Run from any working directory."""

from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "src"))

if __name__ == "__main__":
    try:
        if sys.version_info < (3, 11):
            raise RuntimeError("Python 3.11以降をインストールしてください。")
        if sys.platform == "win32":
            import ctypes

            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "CADFlow.Studio.1"
            )
        from main import main

        main()
    except Exception:
        import traceback
        import tempfile

        detail = traceback.format_exc()
        log = Path(tempfile.gettempdir()) / "CADFlowStudio-startup.log"
        try:
            log.write_text(detail, encoding="utf-8")
        except OSError:
            pass
        try:
            import tkinter as tk
            from tkinter import messagebox

            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(
                "CADFlow Studio を起動できません",
                f"Pythonとtkinterのインストールを確認してください。\n\n詳細ログ: {log}\n\n{detail.splitlines()[-1]}",
                parent=root,
            )
            root.destroy()
        except Exception:
            if sys.stderr:
                print(detail, file=sys.stderr)
        sys.exit(1)
