# Optional Windows build: pyinstaller --clean --noconfirm CADFlowStudio.spec
# Build on Windows; cross-compilation from Linux is not supported.
from pathlib import Path
base=Path(SPECPATH)
a=Analysis([str(base/'CADFlow Studio.pyw')],pathex=[str(base/'src')],
           binaries=[],datas=[(str(base/'assets'),'assets'),(str(base/'docs'),'docs'),(str(base/'examples'),'examples')],
           hiddenimports=['openpyxl'],hookspath=[],hooksconfig={},runtime_hooks=[],excludes=[],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='CADFlowStudio',debug=False,
        bootloader_ignore_signals=False,strip=False,upx=False,console=False,
        icon=str(base/'assets'/'cadflow.ico'))
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='CADFlowStudio')
