# 実装と既知制約 — CADFlow Studio 1.17.0

## 構成

| ファイル | 役割 |
| --- | --- |
| `src/project_data.py` | 複数表・アクティブ表・表ごとの行指定・旧形式移行 |
| `src/command_catalog.py` | JSON登録定義の検証、初期15件の読込、衝突を避けるJSON共有 |
| `src/catalog_editor.py` | 登録コマンドの一覧・編集・引数・SCR手順のGUI |
| `src/settings_presets.py` / `src/settings_preset_editor.py` | 標準3件・カスタム最大100件、値比較、段階的確定、設定適用 |
| `src/project_library.py` / `src/project_sidebar.py` | 別窓のJSON一覧、保存フォルダーと外部履歴の永続化、一覧検索・切替 |
| `src/cad_setup.py` / `src/cad_setup_editor.py` | CAD初期定義、参照候補、任意の冒頭マクロ、既存定義の保護 |
| `src/main.py` | メインUI、表編集、保存・読込、プロジェクト履歴、対象行、出力 |
| `src/cad_state.py` | 実行前のシステム変数・UCS・寸法スタイル選択の退避、通常完了時の復元、手動復元コマンド |
| `src/engine.py` | AST式評価、スコープ、IF/REPEAT/BLOCK展開、SCR・図形情報の同時生成 |
| `src/project_model.py` | モデル版10、構造・名前検証、両分岐を含む参照グラフ、旧モデル移行 |
| `src/macro_editor.py` | モーダルで確定するコマンド・入れ子・プリセット・共有ブロック編集 |
| `src/project_navigator.py` | 入れ子の直接編集、構成表示、コピー・切り取り・移動・ブロック化 |
| `src/preview.py` | 共通2Dレンダラー、寸法の簡易表示、回転文字、ズーム・パン |
| `src/table_io.py` | CSV / Excel検証、文字コード、列名、数式キャッシュ欠損の検出 |
| `src/project_safety.py` | 原子的JSON保存、原子的SCR出力、バックアップ、詳細差分 |
| `src/audit.py` | 非実行側も含む式構文検査、構造検査、各入力行の生成検査 |
| `src/theme.py` | アプリ名、版、フォント、配色、ウィンドウ・タスクバー用アイコン |
| `src/sample_project.py` | 外形・等配穴・IF/ELSE・文字を含むサンプル |

標準ライブラリだけでCSVとGUIを利用できます。Excel読込だけopenpyxlを使用します。
`CADFlow Studio.pyw` はWindowsでコンソールを開かず起動する入口です。

## データモデル

主要キーは `version`, `settings`, `globals`, `input_tables`, `active_table`, `drawing`, `settings_presets`, `active_settings_preset`, `custom_commands`, `blocks`, `presets`。
`input_tables` は `{id, name, rows}` の配列です。行データを二重保持せず、アクティブ表はIDで参照します。
`drawing.targets[table_id]` が `{mode, range, selected}` を保持します。
旧形式の `rows` は読込時に1つの名前付き表へ移行し、旧ファイルを直接書き換えません。
作図はアクティブ表または明示したtable_idが対象。保存前検査は非アクティブ表も含めて全行を確認します。
コマンドは `LINE`, `CIRCLE`, `RECTANGLE`, `TEXT`, `DIMLINEAR`, `SET`, `BLOCK`, `IF`, `REPEAT`, `SYSVAR`, `CUSTOM`。

```json
{"type":"IF", "condition":"@TYPE == \"A\"", "commands":[], "else":[]}
```

```json
{"type":"REPEAT", "count":"@N", "commands":[
  {"type":"CIRCLE","layer":"HOLES","x":"loop.index*20","y":"0","r":"5"}
]}
```

IF以外のコマンドにも任意の `condition` を付けられます。空欄は常時実行です。
設定値はリテラル、globalsとpreset.variablesは定義順に式として計算します。
`@X` は `row.X`、`global.` は評価器内部で `global_.` として扱います。引用符内の文字列は書き換えません。
省略した名前は行 → グローバル → ローカル/SET の順で上書きされます。明示スコープの利用を推奨します。
`loop` は最内周の反復スコープで、内側終了時に外側の値を復元します。

## 登録コマンド

`custom_commands` はIDをキーに、`name`, `description`, `execution`, `parameters`, `lines` を保持します。
`parameters` は `{name, label, kind: number|text, default}`、`lines` はSCRの各応答行です。
CUSTOMの配置は `{type:"CUSTOM", name:ID, arguments:{引数名:値・式}}`。
SYSVARは `{type:"SYSVAR", name:"OSMODE", value:"0", value_kind:"number", execution:"per_row"}`。

テンプレートの `{引数名}` を解決済み文字列へ置換します。Pythonのeval/execは使いません。
任意のSCR自体はASTで式として解析せず、AutoCADへ送る文字列として出力するのみです。
実際のCAD操作はSCRをAutoCADで実行したときに発生し、図形・色・線種・寸法スタイルの任意変更はプレビューで再現しません。
`compile_project(..., diagnostics=[])` へ任意のリストを渡すと、SYSVAR/CUSTOMの出力行・行番号・呼出元を記録します。従来の返り値（SCR, 図形）は維持します。

execution=onceは配置箇所ごとに、最初に条件成立した対象行でのみ送信します。入れ子の反復でも同じ箇所は1回です。
新規寸法スタイルと既存スタイル上書きは、確認応答が異なるため登録を分けます。

## 安全上限

- 1つの式: 2048文字・256ASTノード・評価深さ30
- 中間値: 有限の±1e15以内、文字列4096文字まで。CAD数値: ±1e12以内
- 累乗指数: ±100以内
- 反復: 0〜1000の整数 / 定義コマンド: 10000件
- 実行階層: 12 / 展開コマンド: 50000 / 出力図形: 20000
- 入力表: 100個 / 各表のCSV / Excel読込: 10000行 / CSVとプロジェクトJSON読込: 20MB
- 登録200件 / 引数30個 / 1定義200行 / 1行2048文字 / SYSVAR＋CUSTOM出力合計10000行・200万文字
- プロジェクト履歴・コマンド編集履歴: 各100 / 検査結果: 最大100件

構造検査は未使用ブロックとIFの両分岐もたどります。
値に依存するエラーは実行する分岐で評価します。未実行分岐のあらゆる入力値を証明する検査ではありません。

## 保存と編集の境界

プリセットと共有ブロックは、プロジェクトとは別の作業コピーで編集します。
確定時に構造検査して反映し、キャンセル時は作業コピーを捨てます。
ブロック名変更は、IF/REPEATの内側を含む共有ブロック・全プリセット参照を更新します。
構成ツリーの直接操作は即時反映し、循環などを生む操作は直前状態に戻します。
切り取り後に元の内容が変わった場合は、再度切り取りが必要です。自己の内側への移動も防止します。

保存は同じディレクトリの一時ファイルをfsync後に置換します。既存JSONの退避に失敗したら上書きしません。
保存済みファイルの世代削除に失敗した場合は新しい保存結果を優先し、古いバックアップが残ることがあります。
SCRは文字コード変換が成功してから一時ファイルを作り、既存出力を置換します。

## 既知制約・未検証

- Windows 11 / Python 3.11での実行、Windowsのタスクバー表示、PyInstallerビルド、AutoCAD実行は未検証。
- CAD初期設定で文字/寸法スタイル・線種・レイヤーの作成とフローへの指定に対応。旧共通設定FONT / TEXT_STYLEは保持するだけ。DIM_SCALE / DIM_TEXT_HEIGHT / ARROW_SIZEはDIMSCALE / DIMTXT / DIMASZへ出力する。
- TEXTは現在の文字スタイルが固定高さ0であることを前提とする。右から左への文字組みや制御コード等の再現は保証しない。
- 簡易2D表示は文字幅や寸法外観の完全再現を行わない。プレビューとSCRの基礎座標・対象分岐は共通。
- SCRは作図中UCSをWorld、OSMODE / SNAPMODE / DYNMODEを0にし、通常完了時に元へ戻す。中断時はCADFLOWRESTOREで手動復元できる。
- RECTANGでは面取り・フィレット・幅を0に指定。その他の図面テンプレート設定による差はAutoCADで確認が必要。
- Excel数式を計算するエンジンはない。Excelで再計算・保存済みの値を利用する。
- 列名はASCII識別子。日本語列名・重複列名・予約名は読込時に案内する。
- 大規模な表/展開は同期処理。上限内でも生成中・全行検査中はUIが一時的に待機することがある。
- 入力欄の未確定テキストはプロジェクトのUndo対象外。コマンドのドラッグ移動は構成ツリーで同じ親の中のみ対応。


生成SCRの先頭と末尾にAutoLISPフォームを出力します。AutoLISP / command-s対応環境が必要です。
標準生成の副作用と、展開済みの変数指定・追加メタデータを対象に実行時の値を取得します。
読み取り専用のUCS座標・寸法スタイル名はsetvarを使わずUCS / -DIMSTYLEで選択を復元します。
復元失敗時は退避データを残し、CADFLOWRESTOREで再試行できます。
通常のSCRコマンド列にはAutoLISPのエラーハンドラが適用されないため、中断時の自動復元は保証しません。
詳細は `docs/SYSTEM_SETTINGS_RESTORE.md`。AutoCAD実機・旧LT環境で検証済みとは主張しないでください。


プロジェクトライブラリはユーザー領域のlibrary.jsonにフォルダーと最大100件の外部履歴を保存します。
本体のプロジェクトJSONやモデル版10とは独立しています。一覧のJSON内容は開く時に検証します。作業状態と復元データは別のWorkspaceフォルダーへ15秒ごとに保存します。
ファイル名検索と一覧の更新は編集中のドキュメントを変更しません。切替は既存の未保存確認を経由します。
同じファイルを保存後に読み直す場合は、保存後の内容を再取得します。設定JSONの保存失敗をプロジェクト保存の失敗と混同しません。
CADFLOW_DATA_DIRでユーザー設定領域を指定できます。テストは一時フォルダーを使い、通常のユーザー設定に影響を与えません。


メイン作業領域はworkspace_tabs（作図 / 入力表）、作図結果内はresult_tabs（作図プレビュー / 生成SCR）。
両タブとも同じ入力表Treeview・プロジェクトモデルを使い、表のコピーやタブ切替時の再生成は行いません。
表選択欄はtable_choiceを共有し、両Comboboxの候補一覧をrefreshで同期します。
JSON読込・新規作成後は作図、表ファイルの読込後は入力表を表示します。ステータスバーはルート下部に固定。


プロジェクト一覧はshow_project_listで必要時に1つだけ生成する非モーダルToplevelです。
閉じる操作はwithdrawで、Appのプロジェクトや変更履歴を閉じません。保存・読込時に既存の一覧を同期し、非表示の一覧は開き直すまで非表示を維持します。
プロジェクト関連ダイアログは一覧が表示中なら一覧を親にします。メイン画面はサイドバーを配置せず、作図・入力表へ全幅を割り当てます。


モデル版10でcad_setup（enabled、layers、text_styles、dim_styles、linetypes、旧動作互換フラグ）を追加。
冒頭マクロは宣言した値だけを引用したAutoLISPフォームから構築し、CADFLOWINITとして1回呼出します。Pythonのeval/execは使いません。
既存定義はtblsearchで検査して維持。線種・文字スタイル・レイヤー・依存順の寸法スタイルという順序です。
通常作図のlinetype/text_style/dim_styleは任意欄。既存プロジェクトのレイヤーMakeは移行直後のみ維持し、初期設定の確定後はCLAYER切替へ移行します。


## 1.17の操作・作業状態

`ui_icons.py`と同梱PNGで操作ボタンを統一し、マウス・キーボードのツールチップを付けます。生成用の`make_toolbar_icons.py`だけPillowが必要で、実行時依存には追加しません。
`flow.py`のアドレスを`flow_view.py`と`audit.py`が共有します。コンパイラのMacroError.locationは行・プリセット・展開経路を保持し、ネスト・共通ブロックの実定義へ解決します。
検査結果は変更後に再検査が必要です。行への移動はフォーカスと背景を変え、作図対象の行選択を変えません。
`table_edit.py`はセルのEntryを重ね、確定・ブロック貼り付けを1回のプロジェクトUndoへ反映します。貼り付け全体を検証してから変更します。
`expression_sample.py`は同じ安全なAST評価器を使い、行・設定・変数で試算します。先行SETや反復途中の実行状態は再現しません。
`workspace_state.py`は同一フォルダーの一時ファイルをfsync後に原子的置換します。プロジェクトのバックアップとは別に保存し、元のJSONは上書きしません。
各起動のUUIDで退避を区別し、過去の未処理退避と現在の作業を併存させます。復元コピーを退避してから元の退避を除去します。
単一ユーザー・通常1プロセスのデスクトップ利用を想定します。同一ユーザー領域で複数のアプリを同時起動する場合の復元索引の競合は未対応です。
詳細・退避の対象と間隔は`docs/USABILITY.md`。
