"""Foldable main-window view of the selected preset, including shared blocks."""

from tkinter import ttk
from flow import resolve
from macro_editor import command_summary


class FlowView(ttk.Frame):
    def __init__(self, parent, on_edit, on_select):
        super().__init__(parent)
        self.on_edit, self.on_select = on_edit, on_select
        self.addresses = {}
        self.tree = ttk.Treeview(self, show="tree", selectmode="browse")
        ys = ttk.Scrollbar(self, command=self.tree.yview)
        xs = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        self.tree.column("#0", width=620, stretch=False)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ys.grid(row=0, column=1, sticky="ns")
        xs.grid(row=1, column=0, sticky="ew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        ttk.Label(
            self,
            text="ダブルクリック: 編集 / 三角: 展開・折りたたみ",
            style="Muted.TLabel",
        ).grid(row=2, column=0, sticky="w", pady=5)
        self.tree.bind("<Double-1>", self.edit)
        self.tree.bind("<Return>", self.edit)
        self.tree.bind(
            "<<TreeviewSelect>>", lambda e: self.on_select(self.selected_address())
        )

    def selected_address(self):
        ids = self.tree.selection()
        return self.addresses.get(ids[0]) if ids else None

    def edit(self, event=None):
        address = self.selected_address()
        if address:
            self.on_edit(address)

    def refresh(self, project, index):
        opened = {
            at for node, at in self.addresses.items() if self.tree.item(node, "open")
        }
        selected = self.selected_address()
        self.tree.delete(*self.tree.get_children())
        self.addresses.clear()
        if index is None or index >= len(project["presets"]):
            self.tree.insert("", "end", text="プリセットを選択するとフローを表示します")
            return

        def add(parent, commands, address, stack=()):
            for i, cmd in enumerate(commands):
                at = (*address, i)
                typ = cmd.get("type", "?")
                node = self.tree.insert(
                    parent,
                    "end",
                    text=f"{i + 1:02d}  {typ}  {command_summary(cmd)}",
                    open=at in opened,
                )
                self.addresses[node] = at
                if at == selected:
                    self.tree.selection_set(node)
                for key, label in (("commands", "実行"), ("else", "ELSE")):
                    if key in cmd:
                        branch = self.tree.insert(node, "end", text=label, open=True)
                        add(branch, cmd[key], (*at, key), stack)
                name = cmd.get("name")
                if (
                    typ == "BLOCK"
                    and name in project["blocks"]
                    and name not in stack
                    and len(stack) < 12
                ):
                    add(node, project["blocks"][name], ("blocks", name), (*stack, name))

        preset = project["presets"][index]
        root = self.tree.insert(
            "",
            "end",
            text=preset["name"]
            + ("（無効）" if not preset.get("enabled", True) else ""),
            open=True,
        )
        add(root, preset.get("commands", []), ("presets", index, "commands"))

    def select_address(self, project, address):
        resolve(project, address)
        for node, at in self.addresses.items():
            if at == tuple(address):
                parent = self.tree.parent(node)
                while parent:
                    self.tree.item(parent, open=True)
                    parent = self.tree.parent(parent)
                self.tree.selection_set(node)
                self.tree.see(node)
                return True
        return False
