"""Shared geometry renderer. The compiler is the only source of coordinates."""

import math
import tkinter as tk

COLORS = ("#60a5fa", "#2dd4bf", "#fbbf24", "#c4b5fd", "#fb7185", "#a3e635")


class DrawingCanvas(tk.Canvas):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg="#101d30", highlightthickness=0, **kwargs)
        self.items = []
        self.scale_value = 1
        self.offset = (0, 0)
        self.view_ratio = 1.0
        self.pan = [0.0, 0.0]
        self.highlight_filter = ([], None, None)
        self.geometry = []
        self._drawing_item = None
        self.bind("<Configure>", lambda e: self.fit(preserve=True))
        self.bind("<MouseWheel>", self.zoom)
        self.bind("<Button-4>", lambda e: self.zoom(e, 1.15))
        self.bind("<Button-5>", lambda e: self.zoom(e, 1 / 1.15))
        self.bind("<ButtonPress-1>", lambda e: setattr(self, "drag_point", (e.x, e.y)))
        self.bind("<B1-Motion>", self.drag)
        self.bind("<Double-1>", lambda e: self.fit())

    def set_items(self, items, message=None):
        self.empty_message = message or "行を選択すると、ここに作図結果を表示します"
        preserve = bool(self.items) and bool(items)
        self.items = items
        self.fit(preserve=preserve)

    def _create(self, itemType, args, kw):
        node = super()._create(itemType, args, kw)
        if self._drawing_item is not None and "geometry" in self.gettags(node):
            item, color = self._drawing_item
            self.geometry.append((node, item, color))
        return node

    def bounds(self):
        points = []
        for item in self.items:
            v = item["coords"]
            typ = item["type"]
            if typ == "CIRCLE":
                points.extend([(v[0] - v[2], v[1] - v[2]), (v[0] + v[2], v[1] + v[2])])
            elif typ == "TEXT":
                angle = math.radians(item.get("angle", 0))
                width = len(item.get("text", "")) * v[2] * 0.7
                for x, y in ((0, 0), (width, 0), (0, v[2]), (width, v[2])):
                    points.append(
                        (
                            v[0] + x * math.cos(angle) - y * math.sin(angle),
                            v[1] + x * math.sin(angle) + y * math.cos(angle),
                        )
                    )
            else:
                points.extend(zip(v[::2], v[1::2]))
        return points

    def fit(self, *, preserve=False):
        view = self.get_view() if preserve else {"zoom": 1, "pan": [0, 0]}
        self.delete("all")
        self.geometry = []
        self.view_ratio = 1
        self.pan = [0.0, 0.0]
        self.xview_moveto(0)
        self.yview_moveto(0)
        w, h = max(120, self.winfo_width()), max(120, self.winfo_height())
        for x in range(20, w, 28):
            self.create_line(x, 0, x, h, fill="#192a40", tags="grid")
        for y in range(20, h, 28):
            self.create_line(0, y, w, y, fill="#192a40", tags="grid")
        if not self.items:
            self.create_text(
                w / 2,
                h / 2,
                text=getattr(
                    self, "empty_message", "行を選択すると、ここに作図結果を表示します"
                ),
                fill="#91a5bf",
                font=("TkDefaultFont", 11),
            )
            return
        pts = self.bounds()
        xmin, xmax = min(x for x, y in pts), max(x for x, y in pts)
        ymin, ymax = min(y for x, y in pts), max(y for x, y in pts)
        scale = min(
            (w - 90) / max(1, xmax - xmin),
            (h - max(44, min(100, h * 0.2))) / max(1, ymax - ymin),
        )
        self.scale_value = scale
        self.offset = (
            w / 2 - (xmin + xmax) * scale / 2,
            h / 2 + (ymin + ymax) * scale / 2,
        )
        xy = lambda x, y: (self.offset[0] + x * scale, self.offset[1] - y * scale)
        layers = list(dict.fromkeys(i.get("layer", "0") for i in self.items))
        colors = {name: COLORS[i % len(COLORS)] for i, name in enumerate(layers)}
        for item in self.items:
            v = item["coords"]
            typ = item["type"]
            color = colors[item.get("layer", "0")]
            self._drawing_item = item, color
            options = dict(fill=color, width=2, tags="geometry")
            if typ == "CIRCLE":
                self.create_oval(
                    *xy(v[0] - v[2], v[1] + v[2]),
                    *xy(v[0] + v[2], v[1] - v[2]),
                    outline=color,
                    width=2,
                    tags="geometry",
                )
            elif typ == "TEXT":
                self.create_text(
                    *xy(v[0], v[1]),
                    text=item.get("text", ""),
                    anchor="sw",
                    fill=color,
                    angle=item.get("angle", 0),
                    font=("TkDefaultFont", max(8, min(42, int(v[2] * scale)))),
                    tags="geometry",
                )
            elif typ == "LINE":
                self.create_line(*xy(v[0], v[1]), *xy(v[2], v[3]), **options)
            elif typ == "DIMLINEAR":
                x1, y1, x2, y2, x3, y3 = v
                horizontal = y1 == y2 or (x1 != x2 and min(x1, x2) <= x3 <= max(x1, x2))
                a, b = ((x1, y3), (x2, y3)) if horizontal else ((x3, y1), (x3, y2))
                self.create_line(*xy(x1, y1), *xy(*a), dash=(3, 3), **options)
                self.create_line(*xy(x2, y2), *xy(*b), dash=(3, 3), **options)
                self.create_line(*xy(*a), *xy(*b), arrow="both", **options)
                self.create_text(
                    *xy((a[0] + b[0]) / 2, (a[1] + b[1]) / 2),
                    text=f"{abs(x2 - x1) if horizontal else abs(y2 - y1):.4g}",
                    fill=color,
                    anchor="s",
                    tags="geometry",
                )
            else:
                self.create_rectangle(
                    *xy(v[0], v[1]),
                    *xy(v[2], v[3]),
                    outline=color,
                    width=2,
                    tags="geometry",
                )
        self._drawing_item = None
        self.create_text(
            18,
            h - 18,
            anchor="w",
            text=f"{len(self.items)} 図形  /  単位: 図面単位",
            fill="#91a5bf",
        )
        for i, name in enumerate(layers[:5]):
            self.create_text(
                18, 18 + i * 20, anchor="w", text="●  " + name, fill=colors[name]
            )
        self.restore_view(view)
        self.highlight(*self.highlight_filter)

    def highlight(self, rows=(), preset=None, address=None):
        self.highlight_filter = (list(rows), preset, address)
        active = bool(rows) or preset is not None
        for node, item, color in self.geometry:
            matches = (not rows or item.get("row") in rows) and (
                preset is None or item.get("preset_index") == preset
            )
            if address and len(address) >= 4 and address[0] == "presets":
                matches = matches and item.get("command_index") == address[3]
            typ = self.type(node)
            options = {
                "outline" if typ in ("oval", "rectangle") else "fill": color
                if matches or not active
                else "#3e5068"
            }
            if typ != "text":
                options["width"] = 3 if active and matches else 1.5 if active else 2
            self.itemconfigure(node, **options)

    def get_view(self):
        return {"zoom": self.view_ratio, "pan": list(self.pan)}

    def restore_view(self, view):
        try:
            ratio = float(view.get("zoom", 1))
            dx, dy = [float(v) for v in view.get("pan", [0, 0])]
            if not (
                math.isfinite(ratio)
                and 0.01 <= ratio <= 1000
                and all(math.isfinite(v) and abs(v) <= 1e7 for v in (dx, dy))
            ):
                return
        except (TypeError, ValueError, AttributeError):
            return
        w, h = self.winfo_width(), self.winfo_height()
        # Undo any existing viewport transform before applying a stored one.
        self.move("geometry", -self.pan[0], -self.pan[1])
        self.scale(
            "geometry", w / 2, h / 2, ratio / self.view_ratio, ratio / self.view_ratio
        )
        self.move("geometry", dx, dy)
        self.scale_value *= ratio / self.view_ratio
        self.view_ratio, self.pan = ratio, [dx, dy]

    def drag(self, event):
        previous = getattr(self, "drag_point", (event.x, event.y))
        dx, dy = event.x - previous[0], event.y - previous[1]
        self.move("geometry", dx, dy)
        self.pan[0] += dx
        self.pan[1] += dy
        self.drag_point = event.x, event.y

    def zoom(self, event, factor=None):
        factor = factor or (1.15 if event.delta > 0 else 1 / 1.15)
        if not 0.000001 < self.scale_value * factor < 1e8:
            return
        if not 0.01 <= self.view_ratio * factor <= 1000:
            return
        self.scale("geometry", event.x, event.y, factor, factor)
        self.pan = [
            factor * self.pan[0] + (1 - factor) * (event.x - self.winfo_width() / 2),
            factor * self.pan[1] + (1 - factor) * (event.y - self.winfo_height() / 2),
        ]
        self.view_ratio *= factor
        self.scale_value *= factor
