"""Unified project macro tree editor, with project-scope undo/redo."""

from project_data import input_tables
import copy
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from macro_editor import edit_command, command_summary
from project_model import validate_project, walk_commands


class ProjectNavigator(tk.Toplevel):
    def __init__(
        self, parent, project, on_preset, on_blocks, on_changed, undo=None, redo=None
    ):
        super().__init__(parent)
        self.title("プロジェクト構成 · CADFlow Studio")
        self.geometry("1000x720")
        self.project = project
        self.project_undo = undo
        self.project_redo = redo
        self.on_preset, self.on_blocks, self.external_changed = (
            on_preset,
            on_blocks,
            on_changed,
        )
        self.on_changed = self.changed
        self.history = []
        self.future = []
        self.nodes = {}
        self.drag_item = None
        self.command_clipboard = []
        self.clipboard_cut = False
        self.clipboard_origin = None
        ttk.Label(
            self,
            text="プリセット・ブロックを展開し、コマンドを直接編集。複数コマンドを選んでブロック化できます。",
        ).pack(anchor="w", padx=9, pady=7)
        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=8)
        actions = [
            ("追加", self.add),
            ("編集", self.edit),
            ("複製", self.duplicate),
            ("削除", self.delete),
            ("↑", lambda: self.move(-1)),
            ("↓", lambda: self.move(1)),
            ("ブロック化", self.group),
            ("コピー", self.copy_commands),
            ("切り取り", self.cut_commands),
            ("貼り付け", self.paste_commands),
            ("元に戻す", self.undo),
            ("やり直し", self.redo),
            ("専用エディタ", self.open_selected),
            ("更新", self.refresh),
        ]
        for i, (label, cb) in enumerate(actions):
            ttk.Button(bar, text=label, command=cb).grid(
                row=i // 7, column=i % 7, padx=2, pady=2, sticky="ew"
            )
        frame = ttk.Frame(self)
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        self.tree = ttk.Treeview(
            frame,
            columns=("kind", "detail"),
            show="tree headings",
            selectmode="extended",
        )
        self.tree.heading("#0", text="名前 / 実行順")
        self.tree.column("#0", width=400)
        self.tree.heading("kind", text="種類")
        self.tree.column("kind", width=90)
        self.tree.heading("detail", text="設定 / 条件")
        self.tree.column("detail", width=400)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", lambda e: self.edit())
        self.tree.bind("<ButtonPress-1>", self.drag_start, add="+")
        self.tree.bind("<ButtonRelease-1>", self.drag_end, add="+")
        ttk.Label(
            self,
            text="注意：ブロック呼び出しの展開表示は参照表示です。元のブロックを編集するには「ブロック定義」から選択してください。",
        ).pack(anchor="w", padx=8)
        self.refresh()

    def changed(self):
        errors = validate_project(self.project)
        if errors:
            if self.history:
                state = self.history.pop()
                for key, value in state.items():
                    self.project[key] = copy.deepcopy(value)
            self.refresh()
            messagebox.showerror("構成の確認", "\n".join(errors[:8]), parent=self)
            return
        self.external_changed()

    def record(self):
        self.history.append(
            copy.deepcopy({k: self.project[k] for k in ("presets", "blocks")})
        )
        self.history = self.history[-100:]
        self.future.clear()

    def restore(self, state):
        for k, v in state.items():
            self.project[k] = copy.deepcopy(v)
        self.refresh()
        self.on_changed()

    def undo(self):
        if self.project_undo:
            return self.project_undo()
        if self.history:
            self.future.append(
                copy.deepcopy({k: self.project[k] for k in ("presets", "blocks")})
            )
            self.restore(self.history.pop())

    def redo(self):
        if self.project_redo:
            return self.project_redo()
        if self.future:
            self.history.append(
                copy.deepcopy({k: self.project[k] for k in ("presets", "blocks")})
            )
            self.restore(self.future.pop())

    def add_commands(self, parent, commands, owner, stack, depth=0, readonly=False):
        if depth > 20:
            return
        for i, cmd in enumerate(commands):
            typ = cmd.get("type", "?").upper()
            name = cmd.get("name", "")
            detail = command_summary(cmd)
            node = self.tree.insert(
                parent,
                "end",
                text=f"{i + 1:02d}. {typ}" + (f" : {name}" if name else ""),
                values=("参照" if readonly else "COMMAND", detail[:200]),
                open=False,
            )
            if not readonly:
                self.nodes[node] = ("command", owner, i)
            if typ == "BLOCK":
                if name in stack:
                    self.tree.insert(
                        node,
                        "end",
                        text="循環参照",
                        values=("エラー", " → ".join(stack + [name])),
                    )
                elif name not in self.project["blocks"]:
                    self.tree.insert(
                        node, "end", text="参照先なし", values=("エラー", name)
                    )
                else:
                    self.add_commands(
                        node,
                        self.project["blocks"][name],
                        ("block", name),
                        stack + [name],
                        depth + 1,
                        True,
                    )
            elif typ in ("IF", "REPEAT"):
                for key, label in [
                    ("commands", "条件成立時" if typ == "IF" else "繰り返すコマンド")
                ] + ([("else", "ELSE")] if typ == "IF" else []):
                    child_owner = owner + ((i, key),)
                    branch = self.tree.insert(
                        node, "end", text=label, values=("BRANCH", ""), open=True
                    )
                    if not readonly:
                        self.nodes[branch] = ("branch", child_owner)
                    self.add_commands(
                        branch,
                        cmd.get(key, []),
                        child_owner,
                        stack,
                        depth + 1,
                        readonly,
                    )

    def refresh(self):
        selected_paths = set(self.selected())
        open_paths = set()
        for node in self.tree.get_children(""):

            def visit(n):
                if self.tree.item(n, "open") and n in self.nodes:
                    open_paths.add(self.nodes[n])
                for c in self.tree.get_children(n):
                    visit(c)

            visit(node)
        self.tree.delete(*self.tree.get_children())
        self.nodes.clear()
        root = self.tree.insert(
            "", "end", text="プロジェクト", values=("PROJECT", ""), open=True
        )
        presets = self.tree.insert(
            root, "end", text="プリセット（実行順）", values=("GROUP", ""), open=True
        )
        for i, p in enumerate(self.project["presets"]):
            node = self.tree.insert(
                presets,
                "end",
                text=f"{i + 1:02d}. {p.get('name', '名称なし')}",
                values=("PRESET", p.get("condition") or "常に実行"),
                open=("preset", i) in open_paths,
            )
            self.nodes[node] = ("preset", i)
            self.add_commands(node, p.get("commands", []), ("preset", i), [])
        blocks = self.tree.insert(
            root, "end", text="ブロック定義", values=("GROUP", ""), open=True
        )
        for name, cmds in self.project["blocks"].items():
            node = self.tree.insert(
                blocks,
                "end",
                text=name,
                values=("BLOCK", f"{len(cmds)}コマンド"),
                open=("block", name) in open_paths,
            )
            self.nodes[node] = ("block", name)
            self.add_commands(node, cmds, ("block", name), [name])
        for label, k in [
            ("入力表", "input_tables"),
            ("設定値テーブル", "settings"),
            ("グローバル変数", "globals"),
        ]:
            self.tree.insert(
                root,
                "end",
                text=label,
                values=("DATA", f"{len(self.project.get(k, []))}件"),
            )
        tables_node = self.tree.insert(
            root, "end", text="入力表の一覧", values=("DATA", ""), open=True
        )
        for table in input_tables(self.project):
            self.tree.insert(
                tables_node,
                "end",
                text=table["name"],
                values=("TABLE", f"{len(table['rows'])}行"),
            )
        for node, value in self.nodes.items():
            if value in selected_paths:
                self.tree.selection_add(node)

    def selected(self):
        return [self.nodes[n] for n in self.tree.selection() if n in self.nodes]

    def command_selection(self):
        selected = self.selected()
        if not selected or any(n[0] != "command" for n in selected):
            return None
        owners = {n[1] for n in selected}
        if len(owners) != 1:
            return None
        return selected[0][1], sorted(set(n[2] for n in selected))

    def commands(self, owner):
        commands = (
            self.project["presets"][owner[1]]["commands"]
            if owner[0] == "preset"
            else self.project["blocks"][owner[1]]
        )
        for index, key in owner[2:]:
            commands = commands[index].setdefault(key, [])
        return commands

    def owner_of(self, item):
        return (
            item[1]
            if item[0] in ("command", "branch")
            else item
            if item[0] in ("preset", "block")
            else None
        )

    def choose(self, owner, idx):
        self.refresh()
        for node, n in self.nodes.items():
            if n == ("command", owner, idx):
                self.tree.selection_set(node)
                self.tree.see(node)
                break

    def add(self):
        selected = self.selected()
        if not selected:
            return messagebox.showinfo(
                "選択", "プリセットまたはブロックを選択してください", parent=self
            )
        item = selected[0]
        owner = self.owner_of(item)
        if owner is None:
            return
        working_blocks = copy.deepcopy(self.project["blocks"])
        new = edit_command(self, {"type": "LINE"}, working_blocks, self.project)
        if new is None:
            return
        cmds = self.commands(owner)
        index = item[2] + 1 if item[0] == "command" else len(cmds)
        self.record()
        self.project["blocks"].clear()
        self.project["blocks"].update(working_blocks)
        cmds = self.commands(owner)
        cmds.insert(index, new)
        self.choose(owner, index)
        self.on_changed()

    def edit(self):
        chosen = self.selected()
        if len(chosen) != 1:
            return
        item = chosen[0]
        if item[0] == "command":
            owner, index = item[1:]
            cmds = self.commands(owner)
            working_blocks = copy.deepcopy(self.project["blocks"])
            new = edit_command(self, cmds[index], working_blocks, self.project)
            if new is not None:
                self.record()
                self.project["blocks"].clear()
                self.project["blocks"].update(working_blocks)
                self.commands(owner)[index] = new
                self.choose(owner, index)
                self.on_changed()
        else:
            self.open_selected()

    def open_selected(self):
        chosen = self.selected()
        if not chosen:
            return
        item = chosen[0]
        owner = self.owner_of(item)
        if owner is None:
            return
        if owner[0] == "preset":
            self.on_preset(owner[1])
        elif owner[0] == "block":
            self.on_blocks()

    def duplicate(self):
        s = self.command_selection()
        if not s:
            return
        owner, ids = s
        cmds = self.commands(owner)
        self.record()
        for i in reversed(ids):
            cmds.insert(i + 1, copy.deepcopy(cmds[i]))
        self.choose(owner, ids[-1] + 1)
        self.on_changed()

    def delete(self):
        s = self.command_selection()
        if not s:
            return
        owner, ids = s
        cmds = self.commands(owner)
        self.record()
        for i in reversed(ids):
            cmds.pop(i)
        self.refresh()
        self.on_changed()

    def group(self):
        s = self.command_selection()
        if not s:
            return messagebox.showwarning(
                "ブロック化", "同じ親にあるコマンドを選択してください", parent=self
            )
        owner, ids = s
        if ids != list(range(ids[0], ids[-1] + 1)):
            return messagebox.showwarning(
                "ブロック化", "連続したコマンドを選択してください", parent=self
            )
        name = simpledialog.askstring("ブロック化", "新しいブロック名", parent=self)
        if not name:
            return
        if name in self.project["blocks"]:
            return messagebox.showerror("重複", "同名のブロックがあります", parent=self)
        cmds = self.commands(owner)
        self.record()
        self.project["blocks"][name] = copy.deepcopy(cmds[ids[0] : ids[-1] + 1])
        cmds[ids[0] : ids[-1] + 1] = [{"type": "BLOCK", "name": name}]
        self.choose(owner, ids[0])
        self.on_changed()

    def copy_commands(self):
        selection = self.command_selection()
        if not selection:
            return messagebox.showinfo(
                "コピー",
                "同じプリセットまたはブロックのコマンドを選択してください",
                parent=self,
            )
        owner, indices = selection
        self.command_clipboard = copy.deepcopy(
            [self.commands(owner)[i] for i in indices]
        )
        self.clipboard_cut = False
        self.clipboard_origin = None

    def cut_commands(self):
        selection = self.command_selection()
        if not selection:
            return messagebox.showinfo(
                "切り取り",
                "同じプリセットまたはブロックのコマンドを選択してください",
                parent=self,
            )
        owner, indices = selection
        self.command_clipboard = copy.deepcopy(
            [self.commands(owner)[i] for i in indices]
        )
        self.clipboard_cut = True
        self.clipboard_origin = (owner, indices)
        self.clipboard_source_state = copy.deepcopy(self.commands(owner))
        # Defer deletion until paste so a cancelled paste loses nothing.

    def paste_commands(self):
        if not self.command_clipboard:
            return messagebox.showinfo(
                "貼り付け", "先にコマンドをコピーまたは切り取ってください", parent=self
            )
        chosen = self.selected()
        if len(chosen) != 1:
            return messagebox.showwarning(
                "貼り付け",
                "貼り付け先のプリセット・ブロック・コマンドを1件選択してください",
                parent=self,
            )
        target = chosen[0]
        owner = self.owner_of(target)
        if owner is None:
            return
        if self.clipboard_cut and self.clipboard_origin:
            try:
                unchanged = (
                    self.commands(self.clipboard_origin[0])
                    == self.clipboard_source_state
                )
            except (KeyError, IndexError, TypeError):
                unchanged = False
            if not unchanged:
                return messagebox.showerror(
                    "切り取り元が変更されました",
                    "元のコマンドをもう一度切り取ってください。",
                    parent=self,
                )
        pos = target[2] + 1 if target[0] == "command" else len(self.commands(owner))
        if self.clipboard_cut and self.clipboard_origin:
            old_owner, ids = self.clipboard_origin
            if (
                owner[: len(old_owner)] == old_owner
                and len(owner) > len(old_owner)
                and owner[len(old_owner)][0] in ids
            ):
                return messagebox.showerror(
                    "貼り付け先の確認",
                    "切り取ったコマンドの内側には移動できません。",
                    parent=self,
                )
        # Block definitions must not transitively reference themselves.
        if owner[0] == "block":
            target_name = owner[1]

            def reaches(name, search, stack):
                if name == search:
                    return True
                if name in stack:
                    return False
                return any(
                    c.get("type", "").upper() == "BLOCK"
                    and reaches(c.get("name", ""), search, stack | {name})
                    for c in walk_commands(self.project["blocks"].get(name, []))
                )

            if any(
                c.get("type", "").upper() == "BLOCK"
                and reaches(c.get("name", ""), target_name, set())
                for c in walk_commands(self.command_clipboard)
            ):
                return messagebox.showerror(
                    "循環参照",
                    "貼り付けるとブロックに循環参照が発生します",
                    parent=self,
                )
        self.record()
        items = copy.deepcopy(self.command_clipboard)
        dst = self.commands(owner)
        if self.clipboard_cut and self.clipboard_origin:
            old_owner, ids = self.clipboard_origin
            src = self.commands(old_owner)
            for i in reversed(ids):
                src.pop(i)
            if dst is src:
                pos -= sum(i < pos for i in ids)
        pos = max(0, min(pos, len(dst)))
        dst[pos:pos] = items
        self.clipboard_cut = False
        self.clipboard_origin = None
        self.choose(owner, pos)
        self.on_changed()

    def move(self, delta):
        selected = self.selected()
        if len(selected) != 1:
            return
        item = selected[0]
        if item[0] == "command":
            owner, i = item[1:]
            cmds = self.commands(owner)
            j = i + delta
            if 0 <= j < len(cmds):
                self.record()
                cmds[i], cmds[j] = cmds[j], cmds[i]
                self.choose(owner, j)
                self.on_changed()
        elif item[0] == "preset":
            i = item[1]
            j = i + delta
            arr = self.project["presets"]
            if 0 <= j < len(arr):
                self.record()
                arr[i], arr[j] = arr[j], arr[i]
                self.refresh()
                self.on_changed()

    def drag_start(self, e):
        node = self.tree.identify_row(e.y)
        self.drag_item = self.nodes.get(node)

    def drag_end(self, e):
        source = self.drag_item
        self.drag_item = None
        target = self.nodes.get(self.tree.identify_row(e.y))
        if not source or not target or source == target:
            return
        if source[0] == target[0] == "preset":
            a, b = source[1], target[1]
            arr = self.project["presets"]
            self.record()
            v = arr.pop(a)
            arr.insert(b, v)
            self.refresh()
            self.on_changed()
        elif source[0] == target[0] == "command" and source[1] == target[1]:
            owner = source[1]
            a, b = source[2], target[2]
            cmds = self.commands(owner)
            self.record()
            v = cmds.pop(a)
            cmds.insert(b, v)
            self.choose(owner, b)
            self.on_changed()
