"""Addresses shared by the flow view, compiler diagnostics and inspection links."""

import re


def resolve(project, address):
    value = project
    for key in address:
        value = value[key]
    return value


def walk(commands, address):
    for i, command in enumerate(commands):
        at = (*address, i)
        yield at, command
        for key in ("commands", "else"):
            if key in command:
                yield from walk(command[key], (*at, key))


def execution_address(project, preset_index, path):
    """Resolve expanded paths, including block calls and repeat iterations."""
    address = ("presets", preset_index, "commands")
    parts = path.split("/")
    address += (int(parts[0]) - 1,)
    for label, index in zip(parts[1::2], parts[2::2]):
        if label in ("IF", "ELSE") or re.fullmatch(r"REPEAT\[\d+\]", label):
            address += ("else" if label == "ELSE" else "commands", int(index) - 1)
        else:
            address = ("blocks", label, int(index) - 1)
    resolve(project, address)
    return address
