"""Drawing-first navigation and an independent full-size input-table tab."""

import copy
import os
from pathlib import Path
import sys
import unittest
from tkinter import ttk

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import test_gui as gui
from project_data import add_input_table, target_settings


@unittest.skipUnless(
    sys.platform == "win32" or os.environ.get("DISPLAY"), "GUI display is not available"
)
class WorkspaceGui(unittest.TestCase):
    setUp = gui.Gui.setUp
    tearDown = gui.Gui.tearDown

    def test_starts_with_presets_and_preview_but_no_input_grid(self):
        self.assertEqual(self.app.workspace_tabs.select(), str(self.app.drawing_page))
        self.assertTrue(self.app.presets.winfo_ismapped())
        self.assertTrue(self.app.canvas.winfo_ismapped())
        self.assertIsNone(self.app.project_window)
        self.assertFalse(self.app.table.winfo_ismapped())

    def test_tab_switch_preserves_rows_settings_script_and_history(self):
        self.app.table.selection_set("1")
        self.root.update()
        self.app.preview(quiet=True)
        before = copy.deepcopy(self.app.data)
        history = copy.deepcopy(self.app._history)
        script = self.app.script.get("1.0", "end-1c")
        geometry = self.root.geometry()
        for _ in range(3):
            gui.button(self.app.drawing_page, "入力表を編集").invoke()
            self.root.update()
            self.assertTrue(self.app.table.winfo_ismapped())
            self.assertFalse(self.app.canvas.winfo_ismapped())
            self.assertIsNone(self.app.project_window)
            gui.button(self.app.input_page, "← 作図へ戻る").invoke()
            self.root.update()
        self.assertEqual(self.app.data, before)
        self.assertEqual(self.app._history, history)
        self.assertEqual(self.app.script.get("1.0", "end-1c"), script)
        self.assertEqual(self.app.selected_rows(), [1])
        self.assertEqual(self.root.geometry(), geometry)

    def test_drawing_selector_and_input_selector_share_active_table(self):
        add_input_table(self.app.data, "別表", [{"X": 1}])
        self.app.refresh()
        self.app.drawing_table_picker.set(self.app.data["input_tables"][0]["name"])
        self.app.drawing_table_picker.event_generate("<<ComboboxSelected>>")
        self.root.update()
        self.assertEqual(
            self.app.table_picker.get(), self.app.drawing_table_picker.get()
        )
        self.assertEqual(len(self.app.rows), 3)
        self.app.show_input_table()
        self.app.table_picker.set("別表")
        self.app.table_picker.event_generate("<<ComboboxSelected>>")
        self.root.update()
        self.app.show_drawing()
        self.assertEqual(self.app.drawing_table_picker.get(), "別表")
        self.assertEqual(target_settings(self.app.data)["mode"], "selected")

    def test_import_opens_input_tab_and_project_open_returns_to_drawing(self):
        path = Path(self.library_dir.name) / "new.csv"
        path.write_text("X,Y\n1,2\n", encoding="utf-8")
        self.assertTrue(self.app.read_table(path))
        self.assertEqual(self.app.workspace_tabs.select(), str(self.app.input_page))
        self.app.replace_document(self.app.data)
        self.assertEqual(self.app.workspace_tabs.select(), str(self.app.drawing_page))

    def test_both_tabs_fit_minimum_size_including_sidebar_footer(self):
        self.root.geometry("1260x680")
        for page in (self.app.drawing_page, self.app.input_page):
            self.app.workspace_tabs.select(page)
            self.root.update()
            for widget in gui.descendants(self.root):
                if not isinstance(widget, ttk.Button) or not widget.winfo_ismapped():
                    continue
                with self.subTest(page=page, button=widget.cget("text")):
                    parent = widget.master
                    self.assertLessEqual(
                        widget.winfo_rooty() + widget.winfo_height(),
                        parent.winfo_rooty() + parent.winfo_height(),
                    )
                    self.assertLessEqual(
                        widget.winfo_rootx() + widget.winfo_width(),
                        self.root.winfo_rootx() + self.root.winfo_width(),
                    )
            if page == self.app.drawing_page:
                self.assertTrue(self.app.presets.bbox("0"))
                self.assertGreater(self.app.canvas.winfo_height(), 150)


if __name__ == "__main__":
    unittest.main()
