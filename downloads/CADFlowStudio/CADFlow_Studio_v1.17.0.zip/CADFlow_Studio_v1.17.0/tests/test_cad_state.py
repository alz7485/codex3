"""Verify emitted Lisp structure, runtime snapshot boundaries and restoration scope.

This reader checks syntax/structure, not execution inside AutoCAD.
"""

import copy
import json
from pathlib import Path
import re
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cad_state import protect_script, snapshot_variables
from command_catalog import validate_catalog, library_document
from engine import compile_project
from sample_project import EXAMPLE


def read_form(source):
    tokens = re.findall(r'"(?:\\.|[^"\\])*"|[()\']|[^\s()\']+', source)

    def read():
        token = tokens.pop(0)
        if token == "(":
            value = []
            while tokens[0] != ")":
                value.append(read())
            tokens.pop(0)
            return value
        if token == "'":
            return ["quote", read()]
        if token.startswith('"'):
            return json.loads(token)
        if token == ")":
            raise ValueError("unexpected closing parenthesis")
        return token

    form = read()
    if tokens:
        raise ValueError("multiple forms or trailing tokens")
    return form


def walk(form):
    if isinstance(form, list):
        yield form
        for child in form:
            yield from walk(child)


class CadState(unittest.TestCase):
    def setUp(self):
        self.project = copy.deepcopy(EXAMPLE)

    def test_all_generated_forms_are_complete_and_have_valid_arity(self):
        script, _ = compile_project(self.project, [0, 1, 2])
        for line in script.splitlines():
            if not line.startswith("("):
                continue
            with self.subTest(line=line[:80]):
                ast = read_form(line)
                for node in walk(ast):
                    if node and node[0] == "if":
                        self.assertIn(len(node), (3, 4), node)
                    if node and node[0] in ("setq", "cons", "assoc"):
                        self.assertEqual(len(node) % 2, 1, node)

    def test_snapshot_precedes_every_change_and_cleanup_is_last(self):
        script, _ = compile_project(self.project, [0])
        lines = script.splitlines()
        init = next(
            i for i, l in enumerate(lines) if "(if *cadflow-capture* (setq" in l
        )
        world = lines.index("_.UCS")
        self.assertLess(init, world)
        self.assertLess(lines.index('(setvar "UCSFOLLOW" 0)'), world)
        self.assertEqual(lines[-1], "(c:CADFLOWRESTORE)")
        self.assertNotIn("_.ZOOM\n_Extents", script)
        self.assertIn("_.SNAPMODE\n0", script)
        self.assertNotIn("_.SNAPMODE\n1", script)

    def test_restoration_uses_original_values_including_zero(self):
        lines = protect_script([])
        capture = " ".join(l for l in lines if "(if *cadflow-capture*" in l)
        self.assertIn("(setq v (getvar n)) (if v (cons n v))", capture)
        # AutoLISP treats 0 as true; no numeric sentinel or guessed restore value.
        restore = lines[1]
        self.assertIn("(list (car p) (cdr p))", restore)
        self.assertIn("(foreach p (cdr (assoc 'vars s))", restore)
        self.assertIn('"SNAPMODE"', capture)
        self.assertIn('"OSMODE"', capture)
        self.assertIn('"DYNMODE"', capture)

    def test_indirect_dimension_and_geometry_settings_are_covered(self):
        names = snapshot_variables([])
        for name in (
            "CLAYER",
            "CECOLOR",
            "CELTYPE",
            "CELTSCALE",
            "LTSCALE",
            "CMDECHO",
            "DIMTXT",
            "DIMASZ",
            "DIMSCALE",
            "DIMCLRD",
            "DIMTXSTY",
            "CHAMFERA",
            "FILLETRAD",
            "PLINEWID",
            "TEXTSIZE",
        ):
            self.assertIn(name, names)
        self.assertNotIn("DIMANNO", names)  # read-only, derived from active style

    def test_custom_setvar_direct_and_literal_lisp_detection(self):
        names = snapshot_variables(
            [
                "SETVAR",
                "pickfirst",
                "0",
                "_.PICKADD",
                "2",
                "FILLMODE",
                "0",
                '(setvar "HPASSOC" 0)',
            ]
        )
        for name in ("PICKFIRST", "PICKADD", "FILLMODE", "HPASSOC"):
            self.assertIn(name, names)
        self.assertEqual(len(names), len(set(names)))

    def test_custom_dynamic_variable_names_detected_after_expansion(self):
        self.project["custom_commands"]["dynamic"] = {
            "name": "動的変数",
            "parameters": [{"name": "VAR", "kind": "text", "default": "PICKFIRST"}],
            "lines": ["_.SETVAR", "{VAR}", "0"],
            "system_variables": ["SELECTIONPREVIEW"],
        }
        self.project["presets"][0]["commands"] = [{"type": "CUSTOM", "name": "dynamic"}]
        script, _ = compile_project(self.project, [0])
        self.assertIn('"PICKFIRST"', script)
        self.assertIn('"SELECTIONPREVIEW"', script)
        self.assertIn("_.SETVAR\nPICKFIRST\n0", script)

    def test_named_and_unnamed_ucs_and_dimension_style_restore(self):
        script = "\n".join(protect_script([]))
        for name in ("UCSNAME", "UCSORG", "UCSXDIR", "UCSYDIR", "DIMSTYLE"):
            self.assertIn('(getvar "' + name + '")', script)
        self.assertIn('"_3point"', script)
        self.assertIn('"_Restore" (cdr (assoc \'ucsname s))', script)
        self.assertIn('"_.-DIMSTYLE" "_Restore"', script)
        self.assertLess(script.index('"_.-DIMSTYLE"'), script.index("(foreach p"))
        self.assertNotIn('\'setvar (list "DIMSTYLE"', script)

    def test_failed_restore_keeps_state_for_retry(self):
        form = read_form(protect_script([])[1])
        conditions = [n for n in walk(form) if n and n[0] == "if"]
        cleanup = next(n for n in conditions if n[1] == "failed")
        self.assertEqual(cleanup[-1], ["setq", "*cadflow-state*", "nil"])
        self.assertIn("CADFLOWRESTORE", cleanup[2][1])
        self.assertIn("vl-catch-all-error-p", str(form))

    def test_large_metadata_is_chunked_and_ascii_encodable(self):
        lines = protect_script([], ["CUSTOM_" + str(i) for i in range(6000)])
        self.assertLess(max(map(len, lines)), 2048)
        for line in lines:
            line.encode("cp932")
            if line.startswith("("):
                read_form(line)

    def test_extra_variable_metadata_is_validated_and_shared(self):
        item = {
            "name": "外部",
            "lines": ["EXTERNAL"],
            "system_variables": ["PICKFIRST"],
        }
        self.assertEqual(
            library_document({"external": item})["commands"]["external"], item
        )
        for values in ("OSMODE", ["bad name"], ["A)"], list(map(str, range(31)))):
            invalid = dict(item, system_variables=values)
            self.assertTrue(validate_catalog({"external": invalid}))


if __name__ == "__main__":
    unittest.main()
