"""User-authored JSON definitions, SCR expansion and isolated one-time execution."""

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from command_catalog import (
    load_default_catalog,
    validate_catalog,
    library_document,
    read_library,
    merge_library,
)
from project_model import normalize_project, validate_project
from engine import compile_project, MacroError
from audit import audit_project
from project_safety import atomic_save


def project(commands):
    result = normalize_project(
        {
            "version": 7,
            "rows": [{"X": 10}, {"X": 20}, {"X": 30}],
            "settings": {"COLOR": "BYLAYER"},
            "globals": {},
            "blocks": {},
            "presets": [{"name": "設定", "commands": []}],
        }
    )
    result["presets"][0]["commands"] = commands
    return result


def custom(name="set_osmode", **args):
    return {"type": "CUSTOM", "name": name, "arguments": args}


class CustomCommands(unittest.TestCase):
    def test_defaults_cover_requested_operations(self):
        catalog = load_default_catalog()
        self.assertEqual(len(catalog), 15)
        self.assertEqual(validate_catalog(catalog), [])
        for name in [
            "layer_make",
            "set_color",
            "layer_color",
            "set_linetype",
            "layer_linetype",
            "set_ltscale",
            "set_celtscale",
            "dimstyle_create",
            "dimstyle_overwrite",
            "dimstyle_restore",
        ]:
            self.assertIn(name, catalog)

    def test_number_and_text_sysvars(self):
        p = project(
            [
                {"type": "SYSVAR", "name": "osmode", "value": "@X/10"},
                {
                    "type": "SYSVAR",
                    "name": "CECOLOR",
                    "value_kind": "text",
                    "value": "=settings.COLOR",
                },
            ]
        )
        scr, figs = compile_project(p, [0])
        self.assertIn("_.SETVAR\nOSMODE\n1\n", scr)
        self.assertIn("_.SETVAR\nCECOLOR\nBYLAYER\n", scr)
        self.assertEqual(figs, [])

    def test_sysvar_validation(self):
        for cmd in [
            {"type": "SYSVAR", "name": "x\n_.ERASE", "value": "0"},
            {"type": "SYSVAR", "name": "OSMODE", "value": '__import__("os")'},
            {
                "type": "SYSVAR",
                "name": "CECOLOR",
                "value_kind": "text",
                "value": "a\nb",
            },
            {"type": "SYSVAR", "name": "CECOLOR", "value_kind": "text", "value": ""},
        ]:
            with self.subTest(cmd=cmd), self.assertRaises(MacroError):
                compile_project(project([cmd]), [0])

    def test_numeric_reference_and_literal_text_arguments(self):
        p = project(
            [
                custom("set_ltscale", VALUE="@X/4"),
                custom("set_color", COLOR="=settings.COLOR"),
            ]
        )
        scr, _ = compile_project(p, [0])
        self.assertIn("_.SETVAR\nLTSCALE\n2.5\n", scr)
        self.assertIn("_.CECOLOR\nBYLAYER\n", scr)

    def test_blank_lines_and_literal_braces_preserved(self):
        p = project([custom("example")])
        p["custom_commands"]["example"] = {
            "name": "波括弧",
            "parameters": [],
            "lines": ["_.-LAYER", "_Make", "TEST", "", "{{literal}}", ""],
        }
        scr, _ = compile_project(p, [0])
        self.assertIn("TEST\n\n{literal}\n\n", scr)

    def test_templates_cannot_access_python_attributes(self):
        for line in ["{X.__class__}", "{X[0]}", "{X!r}", "{X:.2f}", "{MISSING}", "{"]:
            catalog = {
                "x": {
                    "name": "テスト",
                    "parameters": [{"name": "X", "kind": "number", "default": "1"}],
                    "lines": [line],
                }
            }
            with self.subTest(line=line):
                self.assertTrue(validate_catalog(catalog))

    def test_missing_registration_and_unknown_arguments_rejected(self):
        for cmd in [custom("missing"), custom("set_osmode", MISSING="1")]:
            with self.assertRaises(MacroError):
                compile_project(project([cmd]), [0])

    def test_no_geometry_is_invented_and_events_have_locations(self):
        events = []
        scr, figs = compile_project(
            project([custom("regenerate")]), [0, 1], diagnostics=events
        )
        self.assertEqual(figs, [])
        self.assertEqual(len(events), 2)
        self.assertEqual([e["row"] for e in events], [0, 1])
        self.assertEqual(events[0]["preset"], "設定")
        self.assertEqual(events[0]["command_index"], 0)
        self.assertEqual(scr.count("_.REGEN"), 2)

    def test_once_executes_on_first_requested_row(self):
        p = project([custom("dimstyle_create", NAME="STYLE", SCALE="@X/10")])
        events = []
        scr, _ = compile_project(p, [2, 0, 1], diagnostics=events)
        self.assertEqual(scr.count("_Save"), 1)
        self.assertEqual(events[0]["row"], 2)
        self.assertIn("_.DIMSCALE\n3\n", scr)
        self.assertEqual(compile_project(p, [0, 1])[0].count("_Save"), 1)

    def test_once_is_per_callsite_not_per_registration(self):
        p = project(
            [custom("dimstyle_create", NAME="A"), custom("dimstyle_create", NAME="B")]
        )
        scr, _ = compile_project(p, [0, 1, 2])
        self.assertEqual(scr.count("_Save"), 2)

    def test_once_inside_repeat_and_block(self):
        p = project(
            [
                {
                    "type": "REPEAT",
                    "count": "3",
                    "commands": [{"type": "BLOCK", "name": "setup"}],
                }
            ]
        )
        p["blocks"]["setup"] = [custom("dimstyle_create")]
        self.assertEqual(compile_project(p, [0, 1])[0].count("_Save"), 1)

    def test_once_condition_waits_for_matching_row(self):
        cmd = custom("dimstyle_create")
        cmd["condition"] = "@X >= 20"
        events = []
        compile_project(project([cmd]), [0, 1, 2], diagnostics=events)
        self.assertEqual([e["row"] for e in events], [1])

    def test_sysvar_once(self):
        p = project(
            [{"type": "SYSVAR", "name": "CMDECHO", "value": 0, "execution": "once"}]
        )
        self.assertEqual(
            compile_project(p, [0, 1, 2])[0].count("_.SETVAR\nCMDECHO\n0"), 1
        )

    def test_row_local_and_loop_values(self):
        p = project(
            [
                {"type": "SET", "name": "BASE", "value": "@X"},
                {
                    "type": "REPEAT",
                    "count": 2,
                    "commands": [custom("set_ltscale", VALUE="local.BASE+loop.index")],
                },
            ]
        )
        events = []
        compile_project(p, [0, 1], diagnostics=events)
        self.assertEqual([e["lines"][-1] for e in events], ["10", "11", "20", "21"])

    def test_custom_output_limit(self):
        p = project([{"type": "REPEAT", "count": 1000, "commands": [custom("many")]}])
        p["custom_commands"]["many"] = {
            "name": "行数テスト",
            "parameters": [],
            "lines": ["_.REGEN"] * 20,
        }
        with self.assertRaisesRegex(MacroError, "10000行"):
            compile_project(p, [0])

    def test_unused_bad_expressions_are_audited(self):
        p = project([])
        p["custom_commands"]["set_ltscale"]["parameters"][0]["default"] = (
            '__import__("os")'
        )
        self.assertTrue(audit_project(p))

    def test_literal_text_is_not_parsed_as_python(self):
        p = project([custom("set_color", COLOR="RGB:255,0,0")])
        self.assertEqual(audit_project(p), [])
        self.assertIn("RGB:255,0,0", compile_project(p, [0])[0])

    def test_sysvar_text_is_not_parsed_as_python(self):
        p = project(
            [
                {
                    "type": "SYSVAR",
                    "name": "CECOLOR",
                    "value_kind": "text",
                    "value": "RGB:255,0,0",
                }
            ]
        )
        self.assertEqual(audit_project(p), [])

    def test_layer_can_inherit_current_layer(self):
        p = project(
            [
                custom("layer_make", NAME="PARTS"),
                {"type": "LINE", "layer": "", "x1": 0, "y1": 0, "x2": 10, "y2": 0},
            ]
        )
        scr, figs = compile_project(p, [0])
        self.assertEqual(scr.count("_.-LAYER"), 1)
        self.assertIn("_Make\nPARTS\n\n_.LINE", scr)
        self.assertEqual(figs[0]["layer"], "現在のレイヤー")

    def test_new_style_and_overwrite_have_different_prompts(self):
        new = compile_project(project([custom("dimstyle_create")]), [0])[0]
        overwrite = compile_project(project([custom("dimstyle_overwrite")]), [0])[0]
        self.assertNotIn("_Yes", new)
        self.assertIn("_Yes", overwrite)

    def test_project_roundtrip_keeps_registry_and_instances(self):
        p = project([custom("set_osmode", VALUE="8")])
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "p.json"
            atomic_save(path, p)
            loaded = normalize_project(json.loads(path.read_text(encoding="utf-8")))
        self.assertEqual(p, loaded)
        self.assertEqual(compile_project(p, [0]), compile_project(loaded, [0]))

    def test_invalid_catalog_rejected_without_crashing(self):
        for catalog in [
            None,
            [],
            {"x": None},
            {"x": {"name": "test", "parameters": None, "lines": ["_.REGEN"]}},
        ]:
            p = project([custom("x")])
            p["custom_commands"] = catalog
            self.assertTrue(validate_project(p))

    def test_library_json_and_conflict_safe_import(self):
        original = load_default_catalog()
        incoming = copy.deepcopy(original)
        incoming["set_osmode"]["lines"] = ["_.REGEN"]
        merged = merge_library(original, incoming)
        self.assertEqual(merged["set_osmode"], original["set_osmode"])
        self.assertEqual(len(merged), 16)
        self.assertEqual(merge_library(merged, incoming), merged)
        self.assertEqual(validate_catalog(merged), [])
        edited = copy.deepcopy(merged)
        imported_id = next(k for k in edited if k.startswith("cmd_"))
        edited[imported_id]["lines"] = ["_.ZOOM", "_Extents"]
        imported_again = merge_library(edited, merged)
        self.assertEqual(merge_library(imported_again, merged), imported_again)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "commands.json"
            atomic_save(path, library_document(merged))
            self.assertEqual(read_library(path), merged)
            path.write_text("{}", encoding="utf-8")
            with self.assertRaises(ValueError):
                read_library(path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
