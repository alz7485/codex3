"""Multiple-table persistence and drawing-target behavior."""

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from project_model import normalize_project, validate_project
from project_data import (
    get_rows,
    add_input_table,
    target_settings,
    drawing_rows,
    parse_row_range,
)
from engine import compile_project, MacroError
from audit import audit_project
from project_safety import atomic_save


def legacy():
    return {
        "version": 6,
        "rows": [{"X": 10}, {"X": 20}, {"X": 30}],
        "settings": {},
        "globals": {},
        "blocks": {},
        "presets": [
            {"name": "円", "commands": [{"type": "CIRCLE", "x": "@X", "y": 0, "r": 2}]}
        ],
    }


class MultipleTables(unittest.TestCase):
    def test_legacy_rows_are_migrated_without_mutation(self):
        source = legacy()
        p = normalize_project(source)
        self.assertNotIn("rows", p)
        self.assertEqual(p["version"], 10)
        self.assertEqual(get_rows(p), source["rows"])
        get_rows(p)[0]["X"] = 99
        self.assertEqual(source["rows"][0]["X"], 10)
        self.assertEqual(normalize_project(p), p)

    def test_explicit_table_compile_does_not_switch_active(self):
        p = normalize_project(legacy())
        original = p["active_table"]
        new = add_input_table(p, "別表", [{"X": 100}])
        self.assertEqual(compile_project(p, [0])[1][0]["coords"][0], 100)
        self.assertEqual(
            compile_project(p, [1], table_id=original)[1][0]["coords"][0], 20
        )
        self.assertEqual(p["active_table"], new["id"])
        with self.assertRaises(MacroError):
            compile_project(p, [0], table_id="missing")

    def test_table_rows_are_independent(self):
        p = normalize_project(legacy())
        original = p["active_table"]
        source = get_rows(p)
        add_input_table(p, "コピー", source)
        get_rows(p)[0]["X"] = 999
        self.assertEqual(get_rows(p, original)[0]["X"], 10)

    def test_targets_persist_for_each_table(self):
        p = normalize_project(legacy())
        first = p["active_table"]
        target_settings(p).update(mode="range", range="1,3")
        second = add_input_table(p, "別表", [{"X": 1}, {"X": 2}])
        target_settings(p).update(mode="selected", selected=[1])
        self.assertEqual(drawing_rows(p), [1])
        self.assertEqual(drawing_rows(p, first), [0, 2])
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "p.json"
            atomic_save(path, p)
            loaded = normalize_project(json.loads(path.read_text(encoding="utf-8")))
        self.assertEqual(loaded, p)
        self.assertEqual(loaded["active_table"], second["id"])

    def test_duplicate_names_and_limits(self):
        p = normalize_project(legacy())
        with self.assertRaises(ValueError):
            add_input_table(p, "入力表1", [])
        for i in range(99):
            add_input_table(p, str(i), [])
        with self.assertRaises(ValueError):
            add_input_table(p, "too many", [])

    def test_malformed_table_references_are_rejected(self):
        cases = []
        p = normalize_project(legacy())
        bad = copy.deepcopy(p)
        bad["active_table"] = {}
        cases.append(bad)
        bad = copy.deepcopy(p)
        bad["input_tables"].append(copy.deepcopy(bad["input_tables"][0]))
        cases.append(bad)
        bad = copy.deepcopy(p)
        bad["drawing"]["targets"][p["active_table"]]["selected"] = [99]
        cases.append(bad)
        bad = copy.deepcopy(p)
        bad["drawing"]["targets"]["missing"] = {"mode": "all"}
        cases.append(bad)
        bad = copy.deepcopy(p)
        bad["rows"] = []
        cases.append(bad)
        bad = copy.deepcopy(p)
        bad["input_tables"] = []
        cases.append(bad)
        for bad in cases:
            with self.subTest(project=bad):
                self.assertTrue(validate_project(bad))

    def test_audit_checks_inactive_tables(self):
        p = normalize_project(legacy())
        first = p["active_table"]
        add_input_table(p, "エラー表", [{"X": "invalid"}])
        p["active_table"] = first
        self.assertTrue(any("エラー表" in issue for issue in audit_project(p)))

    def test_missing_optional_target_fields_are_normalized(self):
        p = normalize_project(legacy())
        p["drawing"]["targets"][p["active_table"]] = {"mode": "all"}
        p = normalize_project(p)
        self.assertEqual(target_settings(p)["range"], "")
        self.assertEqual(target_settings(p)["selected"], [0, 1, 2])

    def test_audit_reports_invalid_drawing_range(self):
        p = normalize_project(legacy())
        target_settings(p).update(mode="range", range="99")
        self.assertTrue(any("作図設定" in issue for issue in audit_project(p)))

    def test_dimension_sizes_are_emitted_and_checked(self):
        p = normalize_project(legacy())
        p["settings"].update(DIM_SCALE="2", DIM_TEXT_HEIGHT="4", ARROW_SIZE="3")
        scr, _ = compile_project(p, [0])
        self.assertIn("_.DIMSCALE\n2\n", scr)
        self.assertIn("_.DIMTXT\n4\n", scr)
        self.assertIn("_.DIMASZ\n3\n", scr)
        p["settings"]["DIM_SCALE"] = "0"
        with self.assertRaises(MacroError):
            compile_project(p, [0])


class RowRange(unittest.TestCase):
    def test_ranges_are_deduplicated_and_in_table_order(self):
        self.assertEqual(parse_row_range("3, 1-2,2", 4), [0, 1, 2])

    def test_japanese_input(self):
        self.assertEqual(parse_row_range("１〜３、５", 5), [0, 1, 2, 4])

    def test_bad_range_is_explained(self):
        for value in ["", "0", "1-99", "3-1", "x", "1,,2", "1.5", "1-2-3"]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_row_range(value, 3)

    def test_mode_all_uses_only_that_table(self):
        p = normalize_project(legacy())
        first = p["active_table"]
        target_settings(p)["mode"] = "all"
        add_input_table(p, "二行", [{"X": 1}, {"X": 2}])
        target_settings(p)["mode"] = "all"
        self.assertEqual(drawing_rows(p), [0, 1])
        self.assertEqual(drawing_rows(p, first), [0, 1, 2])


if __name__ == "__main__":
    unittest.main(verbosity=2)
